# -*- coding: utf-8 -*-
"""

    Copyright (C) 2014-2016 bromix (plugin.video.youtube)
    Copyright (C) 2016-2018 plugin.video.youtube

    SPDX-License-Identifier: GPL-2.0-only
    See LICENSES/GPL-2.0-only for more information.
"""

import xbmc
import xbmcaddon
import traceback

DEBUG = xbmc.LOGDEBUG
INFO = xbmc.LOGINFO
NOTICE = INFO
WARNING = xbmc.LOGWARNING
ERROR = xbmc.LOGERROR
FATAL = xbmc.LOGFATAL
SEVERE = FATAL
NONE = xbmc.LOGNONE

_ADDON_ID = 'plugin.video.youtube'

import os,os.path,sys
PY3 = sys.version_info >= (3, 0)
PY2 = not PY3
if PY3: text_type = str  
if PY2: text_type = unicode #this keyword will raise error in PY3

def Log2(msg='', loglevel=None, stacklevel=2):
    if not msg: msg = u""
    if not isinstance(msg, text_type):
        if PY3: msg = str(msg,'utf8','ignore')
        if PY2: msg = msg.decode('ascii','ignore').encode('utf8')
        #msg = unicode(msg.decode('utf-8', 'ignore'))
    try: 
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklevel+1)[0][0])
            ,traceback.extract_stack(limit=stacklevel+1)[0][1]
            ,msg
            )
    except:
        xbmc.log("-1 FAILED", xbmc.LOGERROR)
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
            ,traceback.extract_stack(limit=stacklevel)[0][1]
            ,msg
            )
        pass

    


    if PY3: msg = "{}: {}".format(_ADDON_ID, msg )
    if PY2: msg = "{}: {}".format(_ADDON_ID, msg.encode('utf-8',errors='ignore') )

    if  loglevel: xbmc.log(msg , loglevel)
##    elif C.DEBUG:  xbmc.log(msg , xbmc.LOGNONE)
    else:    xbmc.log(msg, xbmc.LOGNONE)
    
def log(text, log_level=DEBUG, addon_id=_ADDON_ID):
    Log2(text, loglevel=log_level, stacklevel=3)


def log_debug(text, addon_id=_ADDON_ID):
    log(text, DEBUG, addon_id)
def log_info(text, addon_id=_ADDON_ID):
    log(text, INFO, addon_id)
def log_notice(text, addon_id=_ADDON_ID):
    log(text, NOTICE, addon_id)
def log_warning(text, addon_id=_ADDON_ID):
    log(text, WARNING, addon_id)
def log_error(text, addon_id=_ADDON_ID):
    log(text, ERROR, addon_id)
