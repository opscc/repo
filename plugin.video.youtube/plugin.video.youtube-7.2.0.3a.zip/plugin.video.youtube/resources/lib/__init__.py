# -*- coding: utf-8 -*-
"""

    Copyright (C) 2014-2016 bromix (plugin.video.youtube)
    Copyright (C) 2016-2018 plugin.video.youtube

    SPDX-License-Identifier: GPL-2.0-only
    See LICENSES/GPL-2.0-only for more information.
"""

__all__ = ['youtube_plugin']


import importlib
from importlib import reload
##reload(Session)
reload(sessions)
reload(api)
from .sessions import Session, session
from .api import delete, get, head, options, patch, post, put, request
