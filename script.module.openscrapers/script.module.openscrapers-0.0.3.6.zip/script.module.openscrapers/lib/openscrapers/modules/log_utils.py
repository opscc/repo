# -*- coding: utf-8 -*-

import cProfile
import datetime
import inspect
import json
import os
import pstats
import sys
import time
import threading
import traceback
        
from openscrapers.modules import control
from openscrapers.modules import control as C

from openscrapers.modules.control import StringIO


try:
    import xbmc, xbmcvfs
    from xbmc import LOGDEBUG, LOGINFO, LOGERROR, LOGWARNING  # @UnusedImport
    LOGPATH = control.translatePath('special://logpath/')
    xbmc.log(LOGPATH,xbmc.LOGNONE)
    name = control.addonInfo('id')
except:
    raise
    xbmc = False
    LOGDEBUG = "LOGDEBUG"
    LOGERROR = "LOGERROR"
    LOGINFO = "LOGINFO"
    LOGWARNING = "LOGWARNING"
    name = "OPENSCRAPERS"


#__________________________________________________________________________
#
##LOGPATH = C.translatePath('special://logpath/')
FILENAME = name+'.log'
LOG_FILE = os.path.join(LOGPATH, FILENAME)
##xbmc.log(LOG_FILE, xbmc.LOGNONE)
try:
    cr = os.stat(LOG_FILE).st_ctime
except:
    cr = time.time()
day_in_seconds = 60*60*24
if (time.time() - cr) > day_in_seconds:
    filespec = LOG_FILE
    backup_number = 0
    name = filespec.split(os.sep)[-1]
    folder = filespec[0: (len(filespec)-len(name)) ]
    folder = folder.rstrip(os.sep)
    ext = name.split('.')[-1]
    name = name[0: (len(name)-len(ext)-len('.')) ]
    newer_filespec = '.'.join ((
        (os.sep).join( (folder,name ))
        , str(backup_number)
        , ext
        ))
    try:
        os.remove(newer_filespec)
    except:
        pass
    try:
        os.rename(LOG_FILE,newer_filespec)    
    except:
        pass

DEBUG = (control.setting('debug.enabled') == "true")
if C.PY2:
    f = open(LOG_FILE, 'a')
else:
    f = open(LOG_FILE, 'a', encoding='utf-8')
def Log(msg='', loglevel=None, stacklevel=2):
    if DEBUG and not(loglevel): loglevel = C.LOGINFO
    if not loglevel:
##        raise Exception()
##        f.write(repr(DEBUG) + '\n')
##        f.write(repr(loglevel) + '\n')
        return
##    xbmc.log(msg,C.LOGNONE)
    if not msg: msg = u""
    if not isinstance(msg, C.text_type):
        if C.PY3: msg = str(msg,'utf8','ignore')
        if C.PY2: msg = msg.decode('ascii','ignore').encode('utf8')
        #msg = unicode(msg.decode('utf-8', 'ignore'))

##    xbmc.log('0'+msg,C.LOGNONE)

    n = datetime.datetime.now()
    d =  u"{} T:{:<5}".format(
        n.isoformat(sep=' ')[:-3]
        ,threading.currentThread().ident
        )
    
    if loglevel == C.LOGWARNING: ltype = 'warning'
    elif loglevel == C.LOGERROR: ltype = 'error'
    else: ltype = 'info'

##    xbmc.log('1'+msg,C.LOGNONE)

    msg = d+ u" {} {}:{} {}\n".format(
        ltype
        , os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
        ,traceback.extract_stack(limit=stacklevel)[0][1]
        ,msg.rstrip('\r\n')[:1000]
        )
## cmtrace style
##        if loglevel in [C.LOGNONE,C.LOGNOTICE]: ltype = 1
##        elif loglevel == C.LOGWARNING: ltype = 2
##        elif loglevel == C.LOGERROR: ltype = 3
##        msg = u'<![LOG[{}]LOG]!><time="{}" date="{}" component="{}" context="{}" type="{}" thread="{}" file="{}">'.format(
##                msg
##                ,n.strftime('%H:%M:%S.%f')[:-3]+time.strftime('%z')#time
##                ,n.strftime('%m-%d-%Y') #date
##                , C.addon_id #component
##                , 'context' #context
##                ,ltype #type
##                ,threading.currentThread().native_id #thread
##                ,"{}:{}".format(os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0]), traceback.extract_stack(limit=stacklevel)[0][1])#file
##            )
    if C.PY2:
        f.write( (msg.rstrip(u"\r\n)") + u"\n").encode('utf8'))
    else:
        f.write(msg.rstrip(u"\r\n)") + u"\n")
##    xbmc.log('2'+msg,C.LOGNONE)

##    if C.PY3: msg = "{}: {}".format(C.addon_id, msg )
##    if C.PY2: msg = "{}: {}".format(C.addon_id, msg.encode('utf-8',errors='ignore') )
##    if  loglevel: xbmc.log(msg , loglevel)
##    elif C.DEBUG:  xbmc.log(msg , xbmc.LOGNONE)
##    else:    xbmc.log(msg)

#__________________________________________________________________________
#
def LogR(msg='', loglevel=None, include_type=False):
    if include_type: t = (type(msg), msg)
    else: t = (msg,)
    Log(repr(t), loglevel, stacklevel=3)
def log(msg='', loglevel=None, stacklevel=2):
    Log(msg, loglevel, stacklevel+1)
def logR(msg='', loglevel=None, include_type=False):
    if include_type: t = (type(msg), msg)
    else: t = (msg,)
    Log(repr(t), loglevel, stacklevel=3)
    
### Using color coding, for color formatted log viewers like Assassin's Tools
##DEBUGPREFIX = 'script.module.openscrapers: '#'[COLOR red][ OPENSCRAPERS DEBUG ][/COLOR]'
##def log(msg, caller=None, level=LOGINFO, stacklimit=2):
##
##    debug_enabled = (control.setting('debug.enabled') == "true")
##    if debug_enabled is False:
####        raise Exception()
##        return
##    try:
##        msg = "{}:{} {}".format(
##            os.path.basename(traceback.extract_stack(limit=stacklimit)[0][0])
##            ,traceback.extract_stack(limit=stacklimit)[0][1]
##            ,msg[:1000]
##            )
##    except:
##        pass
##
##    try:
##        if level in [xbmc.LOGERROR, xbmc.LOGINFO]: level = xbmc.LOGNONE
##        xbmc.log('%s%s' % (DEBUGPREFIX, msg), level) #xbmc.LOGNONE)
##            
##    except:
##        traceback.print_exc()
####        traceback.extract_stack()
##
##def logR(msg, caller=None, level=LOGINFO,include_type=False):
##    if include_type:
##        return log(repr((type(msg),msg)), caller, level, stacklimit=3)
##    else:
##        return log(repr(msg), caller, level, stacklimit=3)
##def LogR(msg, caller=None, level=LOGINFO,include_type=False):
##    if include_type:
##        return log(repr((type(msg),msg)), caller, level, stacklimit=3)
##    else:
##        return log(repr(msg), caller, level, stacklimit=3)
    
def error(message=None, exception=True):
    return log(repr(( type(message),message )), LOGERROR, stacklimit=3)
    
    try:
        if exception:
            t_type, value, traceback = sys.exc_info()
            addon = 'script.module.openscrapers'
            filename = (traceback.tb_frame.f_code.co_filename)
            filename = filename.split(addon)[1]
            name = traceback.tb_frame.f_code.co_name
            linenumber = traceback.tb_lineno
            errortype = t_type.__name__
            errormessage = value.message or value # sometime value.message is null while value is not
            if str(errormessage) == '':
                return
            if message:
                message += ' -> '
            else:
                message = ''
            message += str(errortype) + ' -> ' + str(errormessage)
            caller = [filename, name, linenumber]
        else:
            caller = None
        log(msg=message, caller=caller, level=LOGERROR)
        del(t_type, value, traceback) # So we don't leave our local labels/objects dangling
    except:
        traceback.print_exc()
        traceback.extract_stack()
        pass


class Profiler(object):
    def __init__(self, file_path, sort_by='time', builtins=False):
        self._profiler = cProfile.Profile(builtins=builtins)
        self.file_path = file_path
        self.sort_by = sort_by

    def profile(self, f):
        def method_profile_on(*args, **kwargs):
            try:
                self._profiler.enable()
                result = self._profiler.runcall(f, *args, **kwargs)
                self._profiler.disable()
                return result
            except Exception as e:
                log('Profiler Error: %s' % e, LOGWARNING)
                return f(*args, **kwargs)

        def method_profile_off(*args, **kwargs):
            return f(*args, **kwargs)

        if _is_debugging():
            return method_profile_on
        else:
            return method_profile_off

    def __del__(self):
        self.dump_stats()

    def dump_stats(self):
        if self._profiler is not None:
            s = StringIO()
            params = (self.sort_by,) if isinstance(self.sort_by, basestring) else self.sort_by
            ps = pstats.Stats(self._profiler, stream=s).sort_stats(*params)
            ps.print_stats()
            if self.file_path is not None:
                with open(self.file_path, 'w') as f:
                    f.write(s.getvalue())


def trace(method):
    def method_trace_on(*args, **kwargs):
        start = time.time()
        result = method(*args, **kwargs)
        end = time.time()
        log('{name!r} time: {time:2.4f}s args: |{args!r}| kwargs: |{kwargs!r}|'.format(name=method.__name__,
                                                                                       time=end - start, args=args,
                                                                                       kwargs=kwargs), LOGDEBUG)
        return result


    def method_trace_off(*args, **kwargs):
        return method(*args, **kwargs)
    if _is_debugging():
        return method_trace_on
    else:
        return method_trace_off


def _is_debugging():
    command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.getSettings',
               'params': {'filter': {'section': 'system', 'category': 'logging'}}}
    js_data = execute_jsonrpc(command)
    for item in js_data.get('result', {}).get('settings', {}):
        if item['id'] == 'debug.showloginfo':
            return item['value']
    return False


def execute_jsonrpc(command):
    if not isinstance(command, basestring):
        command = json.dumps(command)
    response = control.jsonrpc(command)
    return json.loads(response)
