# -*- coding: UTF-8 -*-

import os.path
import pkgutil, traceback
import sys

from openscrapers.modules import log_utils
from openscrapers.modules.log_utils import log as Log

try:
    import xbmcaddon
    __addon__ = xbmcaddon.Addon(id='script.module.openscrapers')
except:
    __addon__ = None
    pass

debug = __addon__.getSetting('debug.enabled') == 'true'

def sources(specified_folders=None):
    try:
        sourceDict = []
        if __addon__ is not None:
            provider = __addon__.getSetting('module.provider')
        else:
            provider = 'openscrapers'
        sourceFolder = getScraperFolder(provider)
        sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
        sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
        if specified_folders is not None:
            sourceSubFolders = specified_folders

##        Log(repr(sys.path))
##        Log(repr(len(sys.path)))
        for i in sourceSubFolders:
            #2025-09 try importing this way
            for d in [os.path.join(sourceFolderLocation, i)]:
                if not(d in sys.path):
##                    Log(d)
                    sys.path.insert(0, d)
##            Log(repr(sys.path))
##            Log(repr(len(sys.path)))            

            
            for loader, module_name, is_pkg in pkgutil.walk_packages(
                [os.path.join(sourceFolderLocation, i)]
                ):

                
                if is_pkg:
                    continue
                if enabledCheck(module_name):
                    try:
##                        Log(repr(module_name))
##                        Log(repr(dir(loader)))
##                        Log(repr(type(loader)))
                        try:
                            module = loader.find_module(module_name).load_module(module_name)
                        except:  #2025 find_module deprecated
                            module = loader.find_spec(module_name)
##                            Log(repr(module))
##                            Log(repr(module.name))
##                            Log(repr(module.loader_state))
##                            Log(repr(module.has_location))
##                            Log(repr(module.submodule_search_locations))
##                            Log(repr(type(module)))
##                            Log(repr(dir(module)))
#['__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__eq__'
#, '__firstlineno__', '__format__', '__ge__', '__getattribute__', '__getstate__'
#, '__gt__', '__hash__', '__init__', '__init_subclass__', '__le__', '__lt__'
#, '__module__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__'
#, '__setattr__', '__sizeof__', '__static_attributes__', '__str__', '__subclasshook__'
#, '__weakref__', '_cached', '_set_fileattr', '_uninitialized_submodules'
#, 'cached', 'has_location', 'loader', 'loader_state', 'name'
#, 'origin', 'parent', 'submodule_search_locations']
##                            Log(repr(type(module.loader)))                            
##                            Log(repr(dir(module.loader)))                            
#'__class__', '__delattr__', '__dict__', '__dir__', '__doc__'
##, '__eq__', '__firstlineno__', '__format__', '__ge__', '__getattribute__', '__getstate__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__le__', '__lt__', '__module__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__sizeof__', '__static_attributes__', '__str__', '__subclasshook__', '__weakref__', '_cache_bytecode'
##, 'create_module', 'exec_module'
##, 'get_code', 'get_data', 'get_filename'
##, 'get_resource_reader', 'get_source', 'is_package'
##, 'load_module', 'name', 'path', 'path_mtime'
##, 'path_stats', 'set_data', 'source_to_code']
##                            Log(repr(module.loader.path))

##                            module = module.loader.load_module(module_name)
##                            Log(repr(type(module)))
##                            Log(repr(dir(module)))

                            #2025-09 try importing this way
                            module = __import__(module_name, globals(), locals())
##                            Log(repr(type(module)))
##                            Log(repr(dir(module)))


                        sourceDict.append((module_name, module.source()))
                    except Exception as e:
                        traceback.print_exc()
                        raise    
##                        if debug:
##                            log_utils.log('Error: Loading module: "%s": %s' % (module_name, e), log_utils.LOGDEBUG)
##                        pass
        return sourceDict
    except:
        raise
        return []


def enabledCheck(module_name):
    if __addon__ is not None:
        if __addon__.getSetting('provider.' + module_name) == 'true':
            return True
        else:
            return False
    return True


def pack_sources():
    return ['7torrents', 'bitlord', 'btscene', 'idope', 'kickass2', 'limetorrents', 'magnetdl', 'piratebay',
                'skytorrents', 'solidtorrents', 'torrentapi', 'torrentdownload', 'torrentfunk', 'torrentgalaxy',
                'yourbittorrent', 'zoogle']


def providerSources():
    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    return getModuleName(sourceSubFolders)


def providerNames():
    providerList = []
    provider = __addon__.getSetting('module.provider')
    sourceFolder = getScraperFolder(provider)
    sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
    sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
    for i in sourceSubFolders:
        for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(sourceFolderLocation, i)]):
            if is_pkg:
                continue
            correctName = module_name.split('_')[0]
            providerList.append(correctName)
    return providerList


def getAllHosters():
        Log(__name__)
        def _sources(sourceFolder, appendList):
                sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
                sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
                for i in sourceSubFolders:
                        for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(sourceFolderLocation, i)]):
                            if is_pkg:
                                continue
                            try:
                                mn = str(module_name).split('_')[0]
                            except:
                                mn = str(module_name)
                            appendList.append(mn)
        sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
        appendList = []
        for item in sourceSubFolders:
                if item != 'modules':
                        _sources(item, appendList)
        log_utils.log(repr(appendList), log_utils.LOGDEBUG)
        return list(set(appendList))

def getScraperFolder(scraper_source):
    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    return [i for i in sourceSubFolders if scraper_source.lower() in i.lower()][0]


def getModuleName(scraper_folders):
    nameList = []
    for s in scraper_folders:
        try:
            nameList.append(s.split('_')[1].lower().title())
        except:
            pass
    return nameList
