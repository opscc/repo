# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################


import datetime
import json
import os
import re
import traceback
import unicodedata
import xbmc

from openscrapers.modules.log_utils import log  as Log

try: from urlparse import parse_qs, urljoin, urlsplit, urlparse
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit, urlparse
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import cache
from openscrapers.modules import source_utils
from openscrapers.modules import jsunpack

#__________________________________________________________________________
#

class source:
    def __init__(self):
        self.priority = 1
        self.provider_name = 'onionflux'
        self.language = ['en']
        self.domains = ['flixon.click']
        self.base_link = 'https://flixon.ovh/' #2025-02
        self.base_link = 'https://onflix.ovh/' #2025-04
        self.base_link = 'https://onflix.su/' #2025-05
        self.movies_templates = ['https://flixon.ovh/{}'] #2025-02
        self.movies_templates = ['https://onflix.su/{}'] #2025-05
        self.tvshow_templates = [ self.base_link+'{}']
        #"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.0.0"
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0'
        self.headers = {
            "User-Agent": self.user_agent
            ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            ,"Accept-Encoding":"gzip, deflate"
#            ,'Referer': 'https://onionplay.asia/'
            ,'Referer': 'https://onionplay.ch/'
            }
        self.play_referrer = 'https://onionflux.com/' #2025-02
        self.play_referrer = 'https://onionflixer.com/' #2025-04
        self.play_referrer = 'https://onflix.su/' #2025-05

        
#https://onionplay.asia/episodes/severance-season-2-episode-1/
#https://flixon.click/79680-4-2
#https://flixon.ovh/95557-3-5    #2025-02-28    
        self.episode_template = '{}-{}-{}'
        self.title_delete_chars = "'?,:"
        self.title_delete_doublewidechars = "-&"
        self.title_replace_chars = " "
        self.title_replace_subst = "-"
        self.title_replace_doublewidechars = "--"
        self.MAX_LINKS = 8 #make sure we don't overwhem host
#__________________________________________________________________________
#
##    def matchAlias(self, title, aliases):
##        try:
##            for alias in aliases:
##                if cleantitle.get(title) == cleantitle.get(alias['title']):
##                    return True
##        except:
##            return False
#__________________________________________________________________________
#
    def movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, title, localtitle, aliases, year))))

        movie_url = None
        movie_info = {}

        try:
            for movies_template in self.movies_templates:
                movie_url = movies_template.format(imdb)
                if movie_url: break
        except:
            traceback.print_exc()

        if not movie_url: return None

        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
        movie_info['url'] = movie_url
        movie_info = urlencode(movie_info)
        
        Log(u"movie url is {}".format(repr(movie_url)))
        Log(u"movie_info is {}".format(repr(movie_info)))
        return movie_info

#__________________________________________________________________________
#
    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        '''
            Tvshow is the base location for all episodes of a tvshow
            
            The imdb+this.provder_name will be used to find the first part of a tv show url
            Episode information will be appended to this url
            Use this to resolve any alias variance, once per tvshow, as this information will be cached
        '''
        Log(u'tvshow {}'.format(repr((imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season))))
##        traceback.print_stack()
        tvshow_url = None

        try:
            for tvshow_template in  self.tvshow_templates:
                tvshow_url = tvshow_template.format(tmdb)
        except:
            traceback.print_exc()
        Log(u"tvshow url is {}".format(repr(tvshow_url)))
        return tvshow_url
#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):

        Log(u'episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        '''
            url should be the proper starting point for this provider+tvshow;
            
            we just need to adjust some information to get episode specific information

            result should be a url that contains MP4 and HLS video links
        '''
        
        episode_url = {}
        try:

            if not url: raise ValueError
            
            probe_url = self.episode_template.format(url, season, episode)

##            r = client.request(probe_url) #validate this exists
##            if not r: raise Exception(u"improper response for episode url {}".format(repr(tvshow_url)))

            episode_url['url'] = probe_url
            episode_url['title']  = title
            episode_url['premiered'] = premiered
            episode_url['season'] = season
            episode_url['episode'] = episode

        except:
            traceback.print_exc()
##            raise

        episode_url = urlencode(episode_url)
        Log(u"episode url is {}".format(repr(episode_url)))

        return episode_url
    
#__________________________________________________________________________
#

    def sources(self, url_data, hostDict, hostprDict):
        Log(u'sources {}'.format(repr((url_data,))))#, hostDict, hostprDict))))        
        sources = []
##        traceback.print_stack()
        try:
            if not url_data: raise ValueError 
                
            hostDict =  hostDict + hostprDict

            url_data = parse_qs(url_data)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            if not 'url' in url_data: raise ValueError 
            url = url_data['url']
            is_movie = not ('season' in url_data)
            if not is_movie: episode = int(url_data['episode'])

##            Log(repr(url))
            r = client.request(url
                               , headers=self.headers
                               ,ignoreErrors=[403] #cache 403 so that we don't hammer bad requests
                               )
            if not r: raise TabError()
##            else: Log(repr(r))
            
            regex = (
                  'var \w+? = \[(.+?)\];'
                +'.+?String.fromCharCode\(parseInt\(value\) - (\d+)\)' #do some minor math with this value
                )
##            Log(repr(regex))
            codes = re.compile(regex, re.DOTALL).findall(r)
##            Log(repr(codes))
            if not codes: raise TabError()
            else: codes = codes[0]
                
            vals = list(codes[0].split(','))
            offset = int(codes[1])
##            Log(repr(offset))
##            Log(repr(vals))
            buf = ''
            for i in range(len(vals)):
                buf = buf + chr(int(vals[i])-offset)
##            Log(repr(buf))

            regex = (
                  '\.attr\("href","(https.+?)"\)\.'  #source is here
                )
##            Log(repr(regex))
            intermediate_link = re.compile(regex, re.DOTALL).findall(buf)[0]
##            Log(repr(intermediate_link))

            headers = {
                "User-Agent": self.user_agent
                #"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0"
                ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
                ,"Accept-Encoding":"gzip, deflate"
                ,"Referer": self.base_link
                ,"Priority":'u=0, i'
                }
            r = client.request(intermediate_link
                               ,headers=headers
                               )
            buf = UnJuice(r)
##            Log(repr(buf))
                          
            buf = jsunpack.unpack(buf)
##            Log(repr(buf))

            regex = (
                  '"file":"(https.+?)"'  #source is here
                )
##            Log(repr(regex))
            link = re.compile(regex, re.DOTALL).findall(buf)[0]
##            Log(repr(link))

            the_referrer = self.play_referrer
            the_referrer = 'https://{}/'.format(urlparse(intermediate_link).netloc)

            
            headers = {
                "User-Agent": self.user_agent
##                ,"Accept": "*/*"
                ,"Accept-Encoding":"gzip, deflate"
                ,"Referer": the_referrer
                ,"Accept-Language":"en-US,en;q=0.5"                
                ,"Origin": self.play_referrer.strip('/')
                #,"Origin": "null"
                ,"DNT": "1"
                ,"Sec-GPC": "1"
                ,"Connection": "keep-alive"
                ,"Sec-Fetch-Dest": "empty"
                ,"Sec-Fetch-Mode": "cors"
                ,"Sec-Fetch-Site": "same-site"
                }
            link = link + Header2pipestring(headers)

            sources.append(
                        {
                        'source': self.provider_name
                        , 'quality': 'SD'
                        , 'info': ''
                        , 'language': 'en'
                        , 'url': link
                        , 'direct': True
                        , 'debridonly': False
                        }
                       )
            
        except TabError:
            pass
        except:
            traceback.print_exc()
            source_utils.scraper_error(self.provider_name)
            
        Log(u"sources returning {}".format(repr(sources)))
##        raise Exception()
        return sources

#__________________________________________________________________________
#
    def resolve(self, url):
        return url
#__________________________________________________________________________
#
def Header2pipestring(header):
    q = "|{}".format( urlencode(header)  )
    return q
#__________________________________________________________________________
#
def UnJuice(e):
    Juice = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
    try:
        e = re.findall(r'JuicyCodes.Run\(([^\)]+)', e, re.IGNORECASE)[0]
        e = re.sub(r'\"\s*\+\s*\"', '', e)
        e = re.sub(r'[^A-Za-z0-9+\\/=]', '', e)
    except BaseException:
        raise
        return None
    t = ""
    n = r = i = s = o = u = a = f = 0
    while f < len(e):
        s = Juice.index(e[f])
        f += 1
        o = Juice.index(e[f])
        f += 1
        u = Juice.index(e[f])
        f += 1
        a = Juice.index(e[f])
        f += 1
        n = s << 2 | o >> 4
        r = (15 & o) << 4 | u >> 2
        i = (3 & u) << 6 | a
        t += chr(n)
        if 64 != u:
            t += chr(r)
        if 64 != a:
            t += chr(i)
    Log(repr(t))
    return t
#__________________________________________________________________________
#
