# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################


import datetime
import json
import os
import re
import traceback
import unicodedata
import xbmc

from openscrapers.modules.log_utils import log  as Log
from openscrapers.modules.log_utils import logR  as LogR

try: from urlparse import parse_qs, parse_qsl, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, parse_qsl, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import cache
from openscrapers.modules import source_utils
from openscrapers.modules import jsunpack

#####2025-05-05
####https://flickystream.com/player/movie/986056



##https://vidzee.wtf/movie/movie.php?id=986056 #2025-05-05

##2025-04-06
##https://vidzee.wtf/tv/tv.php?id=95396&season=1&episode=1
##Host: vidzee.wtf
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0
##Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
##Accept-Language: en-US,en;q=0.5
##Accept-Encoding: gzip, deflate, br
##DNT: 1
##Sec-GPC: 1
##Connection: keep-alive
##Referer: https://vidzee.wtf/tv/95396/1/1
##Upgrade-Insecure-Requests: 1
##Sec-Fetch-Dest: iframe
##Sec-Fetch-Mode: navigate
##Sec-Fetch-Site: same-origin
##Priority: u=4

##https://vidjoy.pro/embed/api/fetch/95396/2/6?srName=Camelot&sr=0
##Host: vidjoy.pro
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0
##Accept: */*
##Accept-Language: en-US,en;q=0.5
##Accept-Encoding: gzip, deflate, br
##Referer: https://vidjoy.pro/embed/
##DNT: 1
##Sec-GPC: 1
##Connection: keep-alive
##Sec-Fetch-Dest: empty
##Sec-Fetch-Mode: cors
##Sec-Fetch-Site: same-origin
##Priority: u=4

##https://vidjoy.pro/embed/api/fastfetch/1241982?sr=0
##Host: vidjoy.pro
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0
##Accept: */*
##Accept-Language: en-US,en;q=0.5
##Accept-Encoding: gzip, deflate, br
##Referer: https://vidjoy.pro/embed/
##DNT: 1
##Sec-GPC: 1
##Connection: keep-alive
##Sec-Fetch-Dest: empty
##Sec-Fetch-Mode: cors
##Sec-Fetch-Site: same-origin
##Priority: u=4


#__________________________________________________________________________
#

class source:
    def __init__(self):
        self.priority = 1
        self.provider_name = 'flicky'
        self.language = ['en']
        self.domains = [  'vidzee.wtf'
                          ,'flickystream.com'
##                        ,'flicky.host'
##                        ,'player.flicky.host'
                        ]

#https://player.flicky.host/Server-main.php?id=533535
#https://player.flicky.host/Server-main.php?id=1396&season=5&episode=14 HTTP/1.1
#https://v1.shaaringaton.host/nexa/?id=125988&season=2&episode=9 #2025-01
#https://flickystream.com/watch/tv/95396?s=2&ep=7 2025-02-27

##        self.base_link = 'https://player.flicky.host/' #2025-02-27
##        self.base_link = 'https://player.flickystream.host/' #2025-02-27
##        self.base_link = 'https://vidzee.wtf/' #2025-04-08
##        self.base_link = 'https://vidjoy.pro/' #2025-04-28
        self.base_link = 'https://vidzee.wtf/' #2025-05-01
        
##        #self.base_link = 'https://v1.shaaringaton.host/' #2025-01
##        #self.movies_templates = [ self.base_link+'Server-main.php?id={}']
####        self.movies_templates = [ self.base_link+'nexa/?id={}']  #2025-01
##        self.movies_templates = [ self.base_link+'multi.php/?id={}']  ##2025-02-27
####https://vidjoy.pro/embed/api/fastfetch/1241982?sr=0 #2025-04-07
##        self.movies_templates = [ 'https://vidjoy.pro/embed/api/fastfetch/{}?sr=0']  ##2025-04-08
####https://vidzee.wtf/movie/movie.php?id=986056 #2025-05-05
##        self.movies_templates = ['https://vidzee.wtf/movie/movie.php?id={}']  ##2025-05-05
        self.movies_templates = ['https://player.vidzee.wtf/embed/movie/{}']  ##2025-05-29
        
##        #self.tvshow_templates = [ self.base_link+'Server-main.php?id={}']
##        self.tvshow_templates = [ self.base_link+'nexa/?id={}']  #2025-01
##        self.tvshow_templates = [ self.base_link+'multi.php/?id={}']  ##2025-02-27
##https://vidzee.wtf/tv/tv.php?id=95396&season=1&episode=1 #2025-04
##https://vidjoy.pro/embed/api/fetch/95396/2/6?srName=Camelot&sr=0
##        self.tvshow_templates = [ self.base_link+'tv/tv.php?id={}']  ##2025-02-27
##        self.tvshow_templates = [ self.base_link+'embed/api/fetch/{}']  ##2025-04-27
#GET https://vidzee.wtf/tv/tv.php?id=83867&season=2&episode=4 HTTP/1.1 #2025-05-01
##        self.tvshow_templates = [ self.base_link+'tv/tv.php?id={}']  ##2025-05-01
        self.tvshow_templates = ['https://player.vidzee.wtf/api/server?id={}']  ##2025-05-29
##https://player.vidzee.wtf/api/server?id=1399&sr=1&ss=1&ep=1

##        self.episode_template = '{}&season={}&episode={}' ##2025-02-27
##        self.episode_template = '{}/{}/{}?srName=Camelot&sr=0' ##2025-04-27
##        self.episode_template = '{}&season={}&episode={}' ##2025-05-01
##https://player.vidzee.wtf/api/server?id=1399&sr=1&ss=1&ep=1
        self.episode_template = '{}&sr=1&&ss={}&ep={}' ##2025-05-29
        
        self.title_delete_chars = "'?,:"
        self.title_delete_doublewidechars = "-&"
        self.title_replace_chars = " "
        self.title_replace_subst = "-"
        self.title_replace_doublewidechars = "--"
        self.MAX_LINKS = 8 #make sure we don't overwhem host
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0"
            ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            ,"Accept-Encoding":"gzip"
            ,"Accept-Language":"en-US,en;q=0.5"
            ,'Referer': self.base_link    #'https://flicky.host/'
            ,'Sec-Fetch-Dest': 'iframe'
           }
#__________________________________________________________________________
#
    def movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, title, localtitle, aliases, year))))

        movie_url = None
        movie_info = {}

        try:
            for movies_template in self.movies_templates:
                movie_url = movies_template.format(tmdb)
                if movie_url: break
        except:
            traceback.print_exc()

        if not movie_url: return None

        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
        movie_info['url'] = movie_url
        movie_info = urlencode(movie_info)
        
        Log(u"movie url is {}".format(repr(movie_url)))
        Log(u"movie_info is {}".format(repr(movie_info)))
        return movie_info

#__________________________________________________________________________
#
    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        '''
            Tvshow is the base location for all episodes of a tvshow
            
            The imdb+this.provder_name will be used to find the first part of a tv show url
            Episode information will be appended to this url
            Use this to resolve any alias variance, once per tvshow, as this information will be cached
        '''
        Log(u'tvshow {}'.format(repr((imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season))))
##        traceback.print_stack()
        tvshow_url = None
        try:
            for tvshow_template in  self.tvshow_templates:
                tvshow_url = tvshow_template.format(tmdb)
        except:
            traceback.print_exc()
        Log(u"tvshow url is {}".format(repr(tvshow_url)))
        return tvshow_url
#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):

        Log(u'episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        '''
            url should be the proper starting point for this provider+tvshow;
            
            we just need to adjust some information to get episode specific information

            result should be a url that contains MP4 and HLS video links
        '''
        
        episode_url = {}
        try:

            if not url: raise ValueError
            
            probe_url = self.episode_template.format(url, season, episode)
            Log(probe_url)
##            r = client.request(probe_url) #validate this exists
##            if not r: raise Exception(u"improper response for episode url {}".format(repr(tvshow_url)))

            episode_url['url'] = probe_url
            episode_url['title']  = title
            episode_url['premiered'] = premiered
            episode_url['season'] = season
            episode_url['episode'] = episode

        except:
            traceback.print_exc()

        episode_url = urlencode(episode_url)
        Log(u"episode url is {}".format(repr(episode_url)))

        return episode_url
    
#__________________________________________________________________________
#
    def sources(self, url_data, hostDict, hostprDict):
        Log(u'sources {}'.format(repr((url_data,))))#, hostDict, hostprDict))))        
        sources = []
##        return sources
##        traceback.print_stack()
        try:
            if not url_data: raise ValueError 
                
            hostDict =  hostDict + hostprDict

            url_data = parse_qs(url_data)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            if not 'url' in url_data: raise ValueError 
            url = url_data['url']
            is_movie = not ('season' in url_data)
            if not is_movie: episode = int(url_data['episode'])



            self.headers['Referer'] = "https://player.vidzee.wtf/embed/" #"https://{}/".format(url.split("/")[2])
            LogR(self.headers)

        
            try:
                r = client.request(  url
                                   , headers = self.headers
                                   , timeout='15'
                                   )
                if not r: raise Exception('try a post')
                #I want the header + data + use_caching_for_everything..but not available at this momennt
##                h = client.request(  url
##                                   , headers = self.headers
##                                   , timeout='15'
##                                   , output = 'headers'  
##                                   ) #use the cached copy to get headers
            except:
                raise
##            LogR(r)

            try:
                regex = (
                      'const qualityOptions =(?P<json>.+?);\s*const subtitle'
                    )
                r = re.compile(regex, re.DOTALL).findall(r)[0]
            except IndexError: #regex may not be found ...maybe pure json
                pass
##            LogR(r)

            json_info = json.loads(r)
##            LogR(json_info)

##https://vidzee.wtf/tv/tv.php?id=202555&season=1&episode=5

            if 'vidzee' in url:        
                for link in json_info['url']:
##                    LogR(link)
                    url = link['link']
                    LogR(url)

##                    if C.PY2: from urllib2 import urlparse    
##                    if C.PY3: from urllib import parse as urlparse

                    url = parse_qsl(url)[0][1]
                    LogR(url)


##                    quality = source_utils.get_release_quality(link['html'])[0] #must normalize this value with this call 
                    sources.append(
                                {
                                'source': self.provider_name
                                , 'quality': "SD" #quality
                                , 'info': ''
                                , 'language': 'EN'
                                , 'url': url
                                , 'direct': True
                                , 'debridonly': False
                                }
                               )
            else:
                for link in json_info['url']:
##                    LogR(link)
                    playlink =  link['link'] #+ Header2pipestring(headers)
                    quality = source_utils.get_release_quality(link['resulation'])[0] #must normalize this value with this call
                    lang = link['lang'][0:2].upper()

                    sources.append(
                                {
                                'source': self.provider_name
                                , 'quality': quality
                                , 'info': ''
                                , 'language': lang
                                #, 'language': 'EN'
                                , 'url': playlink
                                , 'direct': True
                                , 'debridonly': False
                                }
                               )
                

##            json_info = None
##            regex = (
##                  'const streams =(?P<json>.+?);\s*const subtitles ='
##                )
##            r = re.compile(regex, re.DOTALL).findall(r)
##            if r:
##                r = r[0]
##                r = r.replace('\\/', '/')
##                json_info = json.loads(r)
##                Log(repr(json_info))
##
##            if not json_info:
##                regex = (
##                      'file: "(?P<json>.+?)"'
##                    ) #2025-01
##                json_info = re.compile(regex, re.DOTALL).findall(r)
##
##
##            Log(json_info)
##            for link in json_info:
##                url = link['url'] #+ Header2pipestring(headers)
##                Log(repr(type(link)))
##                #url = link
##                sources.append(
##                            {
##                            'source': self.provider_name
##                            , 'quality': 'SD'
##                            , 'info': ''
##                            , 'language': link['language'][0:2].upper()
##                            #, 'language': 'EN'
##                            , 'url': url
##                            , 'direct': True
##                            , 'debridonly': False
##                            }
##                           )
            
        except:
            traceback.print_exc()
            
        Log(u"sources returning {}".format(repr(sources)))
##        return
        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        return url
#__________________________________________________________________________
#
def Header2pipestring(header):
    q = "|{}".format( urlencode(header)  )
    return q
#__________________________________________________________________________
#
