# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Placenta
# Addon id: plugin.video.placenta
# Addon Provider: Mr.Blamo

import re, urlparse, urllib, base64

##from resources.lib.modules import cleantitle
##from resources.lib.modules import client
##from resources.lib.modules import cache
##from resources.lib.modules import dom_parser2
##from resources.lib.modules import cfscrape

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import cache
from openscrapers.modules import cfscrape

import traceback
from openscrapers.modules.log_utils import log as Log

#__________________________________________________________________________
#
class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['WatchSeriesHD.NET']
        self.base_link = 'https://watchserieshd.net/'
        self.search_link = '/search-movies/%s.html'
        self.scraper = cfscrape.create_scraper()
#__________________________________________________________________________
#
    def movie(self, imdb, title, localtitle, aliases, year):
        return None #cloudflare2 challengs 2021-03-31
        url = None
        try:
            scraper = cfscrape.create_scraper()
            clean_title = cleantitle.geturl(title)
            search_url = urlparse.urljoin(self.base_link, self.search_link % clean_title.replace('-', '+'))
            r = cache.get(client.request, 1, search_url)
            r = client.parseDOM(r, 'div', {'id': 'movie-featured'})
            r = [(client.parseDOM(i, 'a', ret='href'),
                  re.findall('.+?elease:\s*(\d{4})</', i),
                  re.findall('<b><i>(.+?)</i>', i)) for i in r]
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if
                 (cleantitle.get(i[2][0]) == cleantitle.get(title) and i[1][0] == year)]
            url = r[0][0]
        except:
            traceback.print_exc()
        Log("movie url='{}'".format(repr(url)))            
        return url 
#__________________________________________________________________________
#
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return None #cloudflare2 challengs 2021-03-31
        url = None        
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
        except:
            traceback.print_exc()
        Log("tvshow url='{}'".format(repr(url)))
        return url
#__________________________________________________________________________
#
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        return None #cloudflare2 challengs 2021-03-31
        if url == None: return None
        Log("episode url='{}'".format(url))
        try:
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['premiered'], url['season'], url['episode'] = premiered, season, episode
            try:
                clean_title = cleantitle.geturl(url['tvshowtitle'])+'-season-%d' % int(season)
                search_url = urlparse.urljoin(self.base_link, self.search_link % clean_title.replace('-', '+'))
                r = cache.get(client.request, 1, search_url) #, timeout='10')
                r = client.parseDOM(r, 'div', {'id': 'movie-featured'})
                r = [(client.parseDOM(i, 'a', ret='href'),
                      re.findall('<b><i>(.+?)</i>', i)) for i in r]
                r = [(i[0][0], i[1][0]) for i in r if
                     cleantitle.get(i[1][0]) == cleantitle.get(clean_title)]
                url = r[0][0]
            except:
                pass
            data = client.request(url)
            data = client.parseDOM(data, 'div', attrs={'id': 'details'})
            data = zip(client.parseDOM(data, 'a'), client.parseDOM(data, 'a', ret='href'))
            url = [(i[0], i[1]) for i in data if i[0] == str(int(episode))]

            url = url[0][1]
        except:
            traceback.print_exc()
        Log("episode url='{}'".format(repr(url)))            
        return url
#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):
        return None #cloudflare2 challengs 2021-03-31
        sources = []
        Log("sources url='{}'".format(url))
        try:
            r = cache.get(client.request, 1, url, timeout='10')
            try:
                scraper = cfscrape.create_scraper()
                v = re.findall('document.write\(Base64.decode\("(.+?)"\)', r)[0]
                b64 = base64.b64decode(v)
                url = client.parseDOM(b64, 'iframe', ret='src')[0]
                try:
                    host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    sources.append({
                        'source': host,
                        'quality': 'SD',
                        'language': 'en',
                        'url': url.replace('\/', '/'),
                        'direct': False,
                        'debridonly': False
                    })
                except:
                    pass
            except:
                pass
            r = client.parseDOM(r, 'div', {'class': 'server_line'})
            r = [(client.parseDOM(i, 'a', ret='href')[0], client.parseDOM(i, 'p', attrs={'class': 'server_servername'})[0]) for i in r]
            if r:
                for i in r:
                    try:
                        host = re.sub('Server|Link\s*\d+', '', i[1]).lower()
                        url = i[0]
                        host = client.replaceHTMLCodes(host)
                        host = host.encode('utf-8')
                        if 'other'in host: continue
                        sources.append({
                            'source': host,
                            'quality': 'SD',
                            'language': 'en',
                            'url': url.replace('\/', '/'),
                            'direct': False,
                            'debridonly': False
                        })
                    except:
                        pass
        except:
            traceback.print_exc()

        Log("sources sources='{}'".format(repr(sources)))
        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        return None #cloudflare2 challengs 2021-03-31
        Log("resolve url='{}'".format(url))

        try:
            self_domain = False
            for a in self.domains:
                if a in url:
                    self_domain = True
                    break
            if not self_domain:
                self_domain = (self.base_link in url)
            Log("resolve self_domain='{}'".format(repr(self_domain)))
            if self_domain:
    ##            url = client.request(url)
                r = cache.get(client.request, 1, url)
                v = re.findall('document.write\(Base64.decode\("(.+?)"\)', r)
                if v:
                    v = v[0]
                    b64 = base64.b64decode(v)
                    url = client.parseDOM(b64, 'iframe', ret='src')
                    if url:
                        url = url[0]
                    else:
                        url = client.parseDOM(b64, 'a', ret='href')[0]
                else:
                    url = ""
                url = url.replace("///", "//") #this provider ues tripple slashes to make things hard
        except:
            url = ""
            traceback.print_exc()

        Log("resolve url='{}'".format(url))
        return url
#__________________________________________________________________________
#
