# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import json
import traceback
from openscrapers.modules.log_utils import log as Log


try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 32
        self.language = ['en']
        self.domains = ['vidnext.net']
        self.base_link = 'https://vidnext.net/'
        self.search_link = 'search.html?keyword=%s'
#https://vidnext.net/?keyword_search=wandavision
#https://vidnext.net/search.html?keyword=wandavision
#https://vidnext.net/videos/marvels-wandavision-season-1-episode-8
        
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            Log("vidnext tvshow url='{}'".format(repr(url)))
            url = urlencode(url)
            return url
        except:
            source_utils.scraper_error('VIDNEXT')
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            Log("vidnext episode url='{}'".format(repr(url)))
            return url
        except:
            source_utils.scraper_error('VIDNEXT')
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []

        proxy = None
##        proxy = '127.0.0.1:1025' #development

        try:

            if url is None:
                return sources

##            Log("url='{}'".format(repr(url)))
##            Log("hostDict='{}'".format(repr(hostDict)))
##            Log("hostprDict='{}'".format(repr(hostprDict)))
            
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            Log("parse_qs data='{}'".format(repr(data)))

            title = data['tvshowtitle']
            title2 = u"/{}-season-{}-".format(cleantitle.getsearch(title).lower().replace(" ", "-"), int(data['season']))
            Log("title2 data='{}'".format(repr(title2)))
            hdlr = 's%02de%02d' % (int(data['season']), int(data['episode']))
            hdlr2 = u"season-{}-episode-{}".format(int(data['season']), int(data['episode']))
##            Log("hdlr='{}'".format(repr(hdlr)))
            Log("hdlr2='{}'".format(repr(hdlr2)))
            query = quote_plus(cleantitle.getsearch(title))
            search_url = urljoin(self.base_link, self.search_link % query)
##            Log("search_url='{}'".format(repr(search_url)))

            r = client.request(search_url, proxy=proxy)  #, XHR=True  #adds X-Requested-With: XMLHttpRequest
##            Log("r='{}'".format(repr(r)))

            # the site's 'search' will not find what we need and the url names are random..
            # at best we can discover a link to the season we are looking for
            # then open that URL and search it for the episode we want
            data = client.parseDOM(r, 'ul', {'class': r'listing items'})
            Log("data='{}'".format(repr(data)))
            #epis = [client.parseDOM(i, 'a', ret='href' )[0] for i in data if i]
            season_url = None
            for i in data:
                if i:
                    for href in client.parseDOM(i, 'a', ret='href' ):
##                        Log("href='{}'".format(repr(href)))
                        if title2 in href:
                            Log("href='{}'".format(repr(href)))
                            season_url = href
                            break
                    if season_url: break
            Log("season_url='{}'".format(repr(season_url)))
            if not season_url:
                return sources
            if season_url.startswith("/"): season_url = urljoin(self.base_link, season_url)
            Log("season_url='{}'".format(repr(season_url)))



            r = client.request(season_url, proxy=proxy)
##            Log("r='{}'".format(repr(r)))
            data = client.parseDOM(r, 'ul', {'class': r'listing items lists'})
            episode_url = None
            for i in data:
##                Log("i='{}'".format(repr(i)))
                if i:
                    for href in client.parseDOM(i, 'a', ret='href' ):
##                        Log("href='{}'".format(repr(href)))
                        if (title2 in href) and (hdlr2 in href):
                            Log("href='{}'".format(repr(href)))
                            episode_url = href
                            break
                    if episode_url: break
            Log("episode_url='{}'".format(repr(episode_url)))
            if not episode_url:
                return sources
            if episode_url.startswith("/"): episode_url = urljoin(self.base_link, episode_url)
            Log("episode_url='{}'".format(repr(episode_url)))




            # now we have an acutal episode url
            #   the url contains another link to the sources
            r = client.request(episode_url, proxy=proxy)
            if r.startswith("404"): #call actually failed, but source does not use normal status code
                #sometimes the site will ned append -tba to the URL...
                r = client.request(episode_url+"-tba", proxy=proxy)
                if r.startswith("404"):
                    raise Exception("Episode not found '{}'".format(episode_url))
##            Log("r='{}'".format(repr(r)))
            
            #the sources are inside this page
            data = client.parseDOM(r, 'iframe', ret='src')
##            Log("data='{}'".format(repr(data)))
            if data:
                sources_url = data[0]
            else:
                sources_url = ""
                Log("episode_url='{}'".format(repr(episode_url)))
                Log("data='{}'".format(repr(data)))
                Log("r='{}'".format(repr(r)))
                pass
            if sources_url.startswith("//"): sources_url = "https:" + sources_url

            sources_html = client.request(sources_url, referer=episode_url, proxy=proxy)
##            Log("sources_html='{}'".format(repr(sources_html)))

            links = client.parseDOM(sources_html, 'li', {'data-status': '1'}, ret='data-video')
##            Log("links='{}'".format(repr(links)))

            for url in links:
                try:
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if not valid:
##                        Log("invalid host ='{}'".format(repr(host)))
##                        Log("invalid url ='{}'".format(repr(url)))
                        try:
                            if host == "vidnext.net":
                                if url.startswith("/"): url = urljoin(self.base_link, url)
##                                Log("url='{}'".format(repr(url)))
                                r = client.request(url, referer=episode_url, proxy=proxy)
                                alt_url = re.compile(r"sources:.+?file: '([^']+?)'", re.DOTALL | re.IGNORECASE).findall(r)
                                if alt_url: alt_url=alt_url[0]
##                                Log("alt_url='{}'".format(repr(alt_url)))
                                valid, host = source_utils.is_host_valid(alt_url, hostDict)
                                if valid: url = alt_url
                        except:
                            traceback.print_exc()
                        if not valid:
                            continue  #skip this url; only return file hosters we understand
                    sources.append({
                        'source': host
                        , 'quality': 'SD'
                        , 'info': ''
                        , 'language': 'en'
                        , 'url': url
                        , 'direct': False
                        , 'debridonly': False
                        })
                except:
                    traceback.print_exc()
                    source_utils.scraper_error('VIDNEXT')
                    return sources

##            Log("sources='{}'".format(repr(sources)))
            return sources
            
##            r = r['series']
##
##        
##            for i in r:
##                tit = i['value']
##
##                if cleantitle.get(title) != cleantitle.get(tit):
##                    continue
##                slink = i['seo']
##                slink = urljoin(self.base_link, slink)
##                r = client.request(slink)
##
##                if not data['imdb'] in r:
##                    continue
##
##                data = client.parseDOM(r, 'div', {'class': 'el-item\s*'})
##                epis = [client.parseDOM(i, 'a', ret='href')[0] for i in data if i]
##                epis = [i for i in epis if hdlr in i.lower()][0]
##
##                r = client.request(epis)
##                links = client.parseDOM(r, 'a', ret='data-actuallink')
##
##                for url in links:
##                    try:
##                        valid, host = source_utils.is_host_valid(url, hostDict)
##                        if not valid:
##                            continue
##                        sources.append({'source': host, 'quality': 'SD', 'info': '', 'language': 'en', 'url': url,
##                                        'direct': False, 'debridonly': False})
##                    except:
##                        source_utils.scraper_error('VIDNEXT')
##                        return sources
##            return sources
        except:
##            traceback.print_exc()
            source_utils.scraper_error('VIDNEXT')
            return sources


    def resolve(self, url):
        Log("vidnext resolve url='{}'".format(repr(url)))
        return url
