# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
https://github.com/Ciarands


    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import base64
import json
import os
import re
import traceback

from openscrapers.modules.log_utils import log  as Log
    

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote_plus, unquote
except ImportError: from urllib.parse import urlencode, quote_plus, unquote

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils

from openscrapers.modules import jsunpack


import sys
if sys.version_info >= (3,):
    def b(x):
        return x
else:
    import array
    def b(x):
        return array.array('B', x)
        #return codecs.latin_1_encode(x)[0]
    def u(x):
        if isinstance(x, unicode):
            return x.encode('ascii','ignore')
        else:
            return x

#c:\python312\python.exe "C:\Users\poq\Downloads\vidsrc-to-resolver-main (1)\vidsrc-to-resolver-main\vidsrc.py"   -src F2Cloud -getsubs -type movie -id 786892

#https://github.com/Ciarands/vidsrc-to-resolver
#https://github.com/movie-cat/providers        
class source:
    def __init__(self):
        self.priority = 32
        self.language = ['en']
        self.domains = ['vidsrc.to']
        self.base_link = 'https://vidsrc.to'
        self.KEY_URL = "https://github.com/Ciarands/vidsrc-keys/blob/main/keys.json"
        self.DEFAULT_KEY = "WXrUARXb1aDLaZjI"
        self.PROVIDER_URL = "https://vid2v11.site" #"https://vidplay.online" # vidplay.site / vidplay.online / vidplay.lol
        self.search_link = 'browse?q=%s'

        self.headers = {'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/128.0"  #"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
                        ,'Referer': self.base_link
                        ,'Accept-Encoding': 'gzip'
                        }
        self.KEYS = {}

###__________________________________________________________________________
## make sure this exists if we can find Movies here
    def _movie(self, imdb, tmdb, title, localtitle, aliases, year):
        return None #site not working #2024-11
        Log(u'movie {}'.format(repr((imdb, localtitle, aliases, year))))
        url = None
	try:
            url = {
                'imdb': imdb
                , 'tmdb': tmdb
                , 'title': title
                , 'aliases': aliases
                , 'year': year
                }
            url['episode_url'] = '{}/embed/movie/{}'.format(self.base_link, tmdb)
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
###__________________________________________________________________________
## make sure this exists if we can find TV here
    def _tvshow(self, imdb,  tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        return None #site not working #2024-11
        Log(u'TVshow {}'.format(repr((imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))))
        url = None
        try:
            url = {  'imdb': imdb
                   , 'tmdb': tmdb
                   , 'tvdb': tvdb
                   , 'tvshowtitle': tvshowtitle
                   , 'localtvshowtitle': localtvshowtitle
                   , 'aliases': aliases
                   , 'year': year
                     }
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url            
#__________________________________________________________________________
## make sure this exists if we can find Episodes here
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
        return None #site not working #2024-11
        Log(u'Episode {}'.format(repr((url, imdb, tmdb, tvdb, title, premiered, season, episode))))
        if url is None: return None
        try:
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url['episode_url'] = '{}/embed/tv/{}/{}/{}'.format(self.base_link, tmdb, season, episode)
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url
#__________________________________________________________________________
#
    def decode_data(self, key, data):
##        Log('decode_data')
        key_bytes = b(u(key)) #python2
        data = b(u(data)) #python2
        #s = bytearray(range(256)) #python3
        s = bytearray(range(256))
        j = 0

        for i in range(256):
            j = (j + s[i] + key_bytes[i % len(key_bytes)]) & 0xff
            s[i], s[j] = s[j], s[i]

        decoded = bytearray(len(data))
        i = 0
        k = 0

        for index in range(len(data)):
            i = (i + 1) & 0xff
            k = (k + s[i]) & 0xff
            s[i], s[k] = s[k], s[i]
            t = (s[i] + s[k]) & 0xff

            if isinstance(data[index], str):
                decoded[index] = ord(data[index]) ^ s[t]
            elif isinstance(data[index], int):
                decoded[index] = data[index] ^ s[t]
            else:
                raise Exception("RC4DecodeError:Unsupported data type in the input")

##        Log(repr(decoded))
        return decoded

#__________________________________________________________________________
#
    def decode_base64_url_safe(self, s): #str) -> bytearray:
        standardized_input = s.replace('_', '/').replace('-', '+')
        binary_data = base64.b64decode(standardized_input)
        return bytearray(binary_data)
#__________________________________________________________________________
#
    def get_key(self, keys, enc, num):
        return keys["encrypt" if enc else "decrypt"][num]
#__________________________________________________________________________
#
    def get_encryption_key(self):
        return self.get_key(self.KEYS, enc=True, num=0)
#__________________________________________________________________________
#
    def get_decryption_key(self):
        return self.get_key(self.KEYS, enc=False, num=0)
#__________________________________________________________________________
#
    def get_embed_decryption_key(self):
        return self.get_key(self.KEYS, enc=False, num=1)
#__________________________________________________________________________
#
    def get_embed_encryption_key(self):
        return self.get_key(self.KEYS, enc=True, num=1)
#__________________________________________________________________________
#
    def get_h_encryption_key(self):
        return self.get_key(self.KEYS, enc=True, num=2)
#__________________________________________________________________________
#
    def encode_id(self, video_id, encrypt, decrypt, which_encryption_key_index = 0):
##        Log('encode_id')

        if len(self.KEYS) < 1:
            r = client.request(
                self.KEY_URL
                , headers=self.headers
                )
            if not r: raise Exception("Failed to fetch github decryption keys!")
            matches = re.search(r"\"rawLines\":\s*\[\"(.+)\"\]", r)
            if not matches: raise Exception("Failed to extract rawLines from keys page!")
            keys_json = json.loads(matches.group(1).replace("\\", ""))
##            Log(repr((keys_json,)))
            self.KEYS = keys_json
        # ^^^ above here, get the keys from github


        key = self.get_key(self.KEYS, enc=False, num=1)
        if encrypt : key = self.get_key(self.KEYS, encrypt, which_encryption_key_index)
        else: key = self.get_key(self.KEYS, decrypt, which_encryption_key_index)
##        Log(repr(key))

        decoded_id = self.decode_data(key, video_id)
##        Log(repr(decoded_id))
        
        encoded_base64 = base64.b64encode(decoded_id)
        decoded_result = encoded_base64.decode("utf-8")

##        Log('return encode_id {}'.format(decoded_result))
        return decoded_result.replace("/", "_").replace("+", "-")

#__________________________________________________________________________
#
    def decrypt_source_url(self, source_url, use_embed_key = True):
        encoded = self.decode_base64_url_safe(source_url)
        if use_embed_key:
            decoded = self.decode_data(self.get_decryption_key(), encoded)
        else:
            decoded = self.decode_data(self.get_embed_decryption_key(), encoded)
        decoded_text = decoded.decode('utf-8')

        return unquote(decoded_text)
#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):

        Log(u'Sources {}'.format(repr((url, hostDict, hostprDict))))
        sources = []
##        traceback.print_stack()
        if url is None:
            return sources
 
        try:
            url_data = parse_qs(url)
            Log(u"url_data={}".format(repr(url_data)))            
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            if 'season' in url_data: season = url_data['season']
            else: season = url_data['year']
            if 'episode' in url_data: episode = url_data['episode']
            else: episode = ''
            aliases = eval(url_data['aliases'])
            if 'tvshowtitle' in url_data:
                title = url_data['tvshowtitle']
                isTVshow = True
            else:
                title = url_data['title']
                isTVshow = False
            aliases.append({'country':'fallback','title':title})

            #series_url = self.find_series_url(url_data, aliases)
            
            episode_url = url_data['episode_url'] #self.find_episode_url(series_url, title, season, episode)
##            Log(repr(episode_url))
            r = client.request(
                episode_url
                , headers=self.headers
                )


            
            sources_code = client.parseDOM(r, 'a', ret='data-id')
##            Log(repr(sources_code))
            if not sources_code:
                raise Exception('sources_code not found')
            else:
                if type(sources_code) is list:
                    sources_code = sources_code[0]
                
            sources_url = "{}/ajax/embed/episode/{}/sources?token={}".format(self.base_link
                                                                    , sources_code
                                                                    , self.encode_id(sources_code, True, False, 0)
                                                                    )
##            Log(sources_url)
            r = client.request(
                sources_url
                , headers=self.headers
                )
            sources_json = json.loads(r)
            if sources_json['status'] != 200: raise Exception('sources_json not successful {}'.format(sources_url))


        
            embed_url = ''
            for video in sources_json.get("result"):

                try: #try            ('Vidplay', 'F2Cloud','Server 1'): decryption    
##                if video["title"] in ('Vidplay', 'F2Cloud','Server 1'):
                    video_id = video["id"]
                    embed_url = "{}/ajax/embed/source/{}?token={}".format(self.base_link
                                                                 , video_id
                                                                 , self.encode_id(video_id, True, False, 0)
                                                                  )
##                    Log(repr(embed_url))
                    r = client.request(
                        embed_url
                        , headers=self.headers
                        )
                    embed_json = json.loads(r)
                    if embed_json['status'] != 200: raise Exception('embed_url not successful {}'.format(embed_url))

                    encrypted_source_url = embed_json['result']['url']
                    decrypted_source_url  = self.decrypt_source_url(encrypted_source_url)

                    url_data = decrypted_source_url.split("?")
##                    Log(repr(url_data))
                    key = self.encode_id(url_data[0].split("/e/")[-1], True, False, 1)
##                    Log(repr(key))
                    h = self.encode_id(url_data[0].split("/e/")[-1], True, False, 2)
##                    Log(repr(h))

                    fu_url = "{}/mediainfo/{}?{}&autostart=true&ads=0&h={}".format(
                            self.PROVIDER_URL
                            , key
                            , url_data[1]
                            , h)
##                    Log(fu_url)
                    r = client.request(
                        fu_url
                        , referer=decrypted_source_url
                        )
                
                    result = json.loads(r)['result']
                    result = self.decrypt_source_url(result, False)
                    result = json.loads(result)
                    if (type(result) == dict):
                        for s in result["sources"]:
                            url = s["file"]
                            sources.append(
                                            {
                                            'source': 'F2Cloud'
                                            , 'quality': 'SD'
                                            , 'info': ''
                                            , 'language': 'en'
                                            , 'url': url
                                            , 'direct': True
                                            , 'debridonly': False
                                            }
                                            )
                    else:
                        
                        url = result
                        sources.append(
                                        {
                                        'source': video["title"]
                                        , 'quality': 'SD'
                                        , 'info': ''
                                        , 'language': 'en'
                                        , 'url': url
                                        , 'direct': True
                                        , 'debridonly': False
                                        }
                                        )
                                    

                        
                
                except: #filemoon decryption
                #if video["title"] in ('Filemoon','Server 2'):
                    video_id = video["id"]
                    embed_url = "{}/ajax/embed/source/{}?token={}".format(self.base_link
                                                 , video_id
                                                 , self.encode_id(video_id, True, False, 0)
                                                  )
##                    Log(repr(embed_url))
                    r = client.request(
                        embed_url
                        , headers=self.headers
                        )
                    embed_json = json.loads(r)
                    if embed_json['status'] != 200: raise Exception('embed_url not successful {}'.format(embed_url))

                    encrypted_source_url = embed_json['result']['url']
                    decrypted_source_url  = self.decrypt_source_url(encrypted_source_url)

                    embed_url = decrypted_source_url
                    r = client.request(
                        embed_url
                        , headers=self.headers
                        )
                    unpacked = jsunpack.unpack(r)

                    hls_urls = re.findall(r"\{file:\"([^\"]*)\"\}", unpacked)
                    if (type(hls_urls) in (dict,list) ): hls_urls = hls_urls[0]
    
                    sources.append(
                                    {
                                    'source': 'Filemoon'
                                    , 'quality': 'SD'
                                    , 'info': ''
                                    , 'language': 'en'
                                    , 'url': hls_urls
                                    , 'direct': False
                                    , 'debridonly': False
                                    }
                                    )
                    
            if not embed_url: raise Exception('no embed_url was found')

            


        except:
            traceback.print_exc()

        Log(repr(sources))
        return sources
    

        
#__________________________________________________________________________
#
    def resolve(self, url):
        url = "{}|{}".format( url, urlencode(self.headers)  )
        Log("{} resolved url='{}'".format(self.domains[0], repr(url)))
        return url
#__________________________________________________________________________
#
