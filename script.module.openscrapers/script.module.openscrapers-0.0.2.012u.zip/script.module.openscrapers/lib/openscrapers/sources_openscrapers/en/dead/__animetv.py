# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import os
import re
import traceback
from openscrapers.modules.log_utils import log  as Log
    

try: from urlparse import parse_qs, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.provder_name = 'animeTV'
        self.priority = 32
        self.language = ['en']
        self.domains = ['9animetv.live','9anime.to']
        self.base_link = 'https://api.9animetv.live/'
        self.search_link = 'player-json-api.php?id=%s'



#__________________________________________________________________________
#
    def movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, localtitle, aliases, year))))
        url = None
	try:
            url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
#__________________________________________________________________________
#
    def tvshow(self, imdb,  tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        Log(u'TVshow {}'.format(repr((imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))))
        url = None
        try:
            url = {'imdb': imdb
                   , 'tvdb': tvdb
                   , 'tvshowtitle': tvshowtitle
                   , 'localtvshowtitle': localtvshowtitle
                   , 'aliases': aliases
                   , 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url            
#__________________________________________________________________________
#
    def episode(self, url, imdb,  tmdb, tvdb, title, premiered, season, episode):
        Log(u'Episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        if url is None:
            return None
        try:
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url

#__________________________________________________________________________
#
    def find_series_url(self, url_data, aliases, year):
        Log(u"find_series_url() {}".format(repr((url_data, aliases))))
        find_series_url = ''
        title=''
        for alias in aliases:        
            title = alias['title']
            Log(u"testing for title alias '{}'".format(title))
            title2 = u'/tv/free-'+ cleantitle.getsearch(title).lower().replace(" ", "-").replace(".","") + '-'
            Log(u"expecting a format for this site as '{}'".format(title2))

            query = cleantitle.getsearch(title,include_colon=True).lower()
            query = quote_plus(query).replace('+','-')
            search_url = urljoin(self.base_link, self.search_link % query)
            Log(u"search_url={}".format(repr(search_url)))

            r = client.request(search_url)  #, XHR=True  #adds X-Requested-With: XMLHttpRequest
            search_result = client.parseDOM(r, 'div', {'class': 'flw-item'}  )

            series_url = ''
            for i in search_result:
                if i:
                    likely_series_url = ''
                    for href in client.parseDOM(i, 'a', ret='href' ):
                        if title2 in href:
                            likely_series_url = href
                            break
                    #confirm we are looking at correct series year
                    year_string = '<span class="fdi-item">{}</span>'.format(year)
                    for info in client.parseDOM(i, 'div', {'class': 'film-detail'} ):
                        for href in client.parseDOM(info, 'div', {'class': 'fd-infor'} ):
                            if year_string in href:
                                series_url = likely_series_url
                                break
                if series_url: break
            if series_url: break


        if '-hd-' in series_url:
            series_url = series_url.split('-hd-')[1]
            series_url = 'https://sflix.to/ajax/v2/tv/seasons/' + series_url
            
        Log(u"series_url={}".format(repr(series_url)))
        if not series_url:
            raise Exception(u"no series_url found for '{}'".format(title))
        if series_url.startswith("/"): series_url = urljoin(self.base_link, series_url)
        return series_url

#__________________________________________________________________________
#

    def find_episode_url(self, series_url, season, episode):
        Log(u"find_episode_url() {}".format(repr((series_url, season, episode))))

        episode_url = ''

        r = client.request(series_url)
        Log(repr(r))
        simple_api_info = json.loads(r)
        for info in simple_api_info['simple-api']:
            Log(repr(info))
            if 'season' in info: 
                if info['season'] == season and info['episode'] == episode:
                    episode_url = info['iframe']
                    break
            else: #a movie
                episode_url = info['iframe']
                break
                
                
        Log(u"episode_url={}".format(repr(episode_url)))
        if not episode_url: raise Exception(u"no episode_url found for {} s{}e{}'".format(repr(series_url),season,episode))
        return episode_url

#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):

        Log(u'Sources {}'.format(repr((url, hostDict, hostprDict))))
        sources = []
##        traceback.print_stack()
        if url is None:
            return sources

 
        try:
            url_data = parse_qs(url)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            imdb_id = url_data['imdb']
            if 'season' in url_data: season = url_data['season']
            else: season = url_data['year']
            if 'episode' in url_data: episode = url_data['episode']
            else:  episode = ''

            series_url = "https://api.9animetv.live/player-json-api.php?id="+imdb_id
            episode_url = self.find_episode_url(series_url, season, episode)
            r = client.request(url=episode_url
                               , referer=series_url
                               )
            links = client.parseDOM(   html=r
                                      ,name='iframe'
                                      ,attrs={'class':'vidframe'}
                                      ,ret='src'
                                      )
##            Log(repr(links))
            for url in links:
            #for link, qual, host in streams: #2022
##                host = link.split('//')[1].replace('www.', '')

                valid, host = source_utils.is_host_valid(url, hostDict)
                Log(repr((valid,host)))
                if valid:
                    sources.append(
                                    {
                                    'source': 'MyCloud'
                                    , 'quality': 'SD'
                                    , 'info': ''
                                    , 'language': 'en'
                                    , 'url': url
                                    , 'direct': False
                                    , 'debridonly': False
                                    }
                                   )
                
        except:
            traceback.print_exc()

##        Log(repr(sources))
        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        Log("{} found {}".format(self.provder_name, repr(url)))
        video_url = None
        import resolveurl
        try:
            video_url = resolveurl.resolve(url)
        except:
            traceback.print_exc()

        Log("{} resolved url={} to {}".format(self.provder_name, repr(url), repr(video_url)))

        return video_url
#__________________________________________________________________________
#
