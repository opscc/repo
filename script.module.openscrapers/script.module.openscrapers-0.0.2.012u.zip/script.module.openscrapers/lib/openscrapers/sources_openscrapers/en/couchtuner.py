# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Placenta
# Addon id: plugin.video.placenta
# Addon Provider: Mr.Blamo

import datetime
import json
import os
import re
import traceback
import unicodedata
import xbmc

from openscrapers.modules.log_utils import log  as Log

try: from urlparse import parse_qs, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from resources.lib.modules import directstream
from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import cache
from openscrapers.modules import source_utils

#__________________________________________________________________________
#

class source:
    def __init__(self):
        self.priority = 1
        self.provder_name = 'couchtuner'
        self.language = ['en']
        self.domains = ['www.couchtuner.show']
        self.base_link = 'https://www.couchtuner.show/'
##        self.search_link = '/movie/search/%s'

        self.movies_templates = ['/film/%s/watching.html']
##        self.tvshow_templates = ['/film/{}-season-{}', '/film/{}']
##        self.tvshow_templates = ['watch-series/{}/']
        self.tvshow_templates = [
            '/watch-series/{}/'
            ,'/watch-series/free-{}-online/'
##            ,'{}{}/{:02}/{}-season-{}-episode-{}/'
##            ,'{}{}/{:02}/{}-season-{}/'
            ]
        #  {:02}    need zero padding for this month
        #  (?:/|-)  usually a trailing slash is needed, but sometimes multiple episodes will packed with a dash
#https://www.couchtuner.show/2024/06/presumed-innocent-season-1-episode-1-2/
#https://www.couchtuner.show/2024/07/the-boys-season-4-episode-7/
#https://www.couchtuner.show/2024/07/house-of-the-dragon-season-2-episode-6/
#https://www.couchtuner.show/2024/06/the-bear-season-3/
        self.episode_templates = [
            '{}{}/{:02}/{}-season-{}-episode-{}/'
            ,'{}{}/{:02}/{}-season-{}/'
            ]
        self.title_delete_chars = "'?,:()"
        self.title_delete_doublewidechars = "-"
        self.title_replace_chars_1 = "&"
        self.title_replace_subst_1 = "and"
        self.title_replace_chars_2= " "
        self.title_replace_subst_2= "-"
        self.title_replace_doublewidechars = "--"
        self.title_replace_doublewidesubst = "-"
        self.MAX_LINKS = 8 #make sure we don't overwhem host


#__________________________________________________________________________
#
    def tvshow(self, imdb,  tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        '''
            Tvshow is the base location for all episodes of a tvshow
            
            The imdb+this.provder_name will be used to find the first part of a tv show url
            Episode information will be appended to this url
            Use this to resolve any alias variance, once per tvshow, as this information will be cached
        '''
        Log(u'tvshow {}'.format(repr((imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season))))
##        traceback.print_stack()
        tvshow_url = None

        try:

            year_list = ['',year] #sometimes including year helps, but start without it 
            for year in year_list:
                year2 = ''

                aliases.insert(0, {'country':'','title':tvshowtitle})
                aliases.insert(0, {'country':'','title':localtvshowtitle})
                Log(aliases)

                for alias in aliases:
                    if year not in alias['title']:
                        if year:
                            year2 = '-' + str(year)
                            Log('trying with an appended year')
                    else:
                        year2 = ''

                    alias = alias['title'].lower()
                    for c in self.title_replace_chars_1: #perform replace before delete
                        alias = alias.replace(c,self.title_replace_subst_1)
                    for c in self.title_replace_chars_2: #perform replace before delete
                        alias = alias.replace(c,self.title_replace_subst_2)

                    for c in range(len(self.title_replace_doublewidechars) /2):
                        alias = alias.replace( self.title_replace_doublewidechars[c*2:2]  , self.title_replace_doublewidesubst)
                    for c in range(len(self.title_delete_doublewidechars) /2):
                        alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')

                    for c in self.title_delete_chars:
                        alias = alias.replace(c,'')

                    alias = alias.decode('utf8')
                    alias = unicodedata.normalize('NFKD', alias).encode('ascii','ignore')
##                    Log(alias)
                    #alias = u"{}{}".format(alias,year2)
                    #alias = self.base_link
                    Log(alias)

##                    return alias
##
##                    raise ValueError()
                    
                    for tvshow_template in self.tvshow_templates:
                        probe_url = urljoin(self.base_link, tvshow_template.format(alias, season))
                        Log(repr(probe_url))
##                        raise ValueError()
                        r = client.request(probe_url)
##                        probe_url = probe_url[0:-1] #this site works best with trailing slash, but later on, without it
                        if r and (probe_url in r): #confirm not a false positive [trim the last backslash]
    ##                    #normally I want to return a URL but this site needs
    ##                    #    premiered date which is not available here
    ##                    # for this site, just make sure we have the alias
    ##                    Log(u"tvshow ALIAS is {}".format(repr(alias)))

                            tvshow_url = alias
                        if tvshow_url: break
                    if tvshow_url: break
                if tvshow_url: break
            pass
##        except ValueError:
##            Log('ValueError')
##            pass 
        except:
            traceback.print_exc()
        Log(u"tvshow url is {}".format(repr(tvshow_url)))
        return tvshow_url

##        if not movie_url: return None
##
##        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
##        movie_info['url'] = movie_url
##        movie_info = urlencode(movie_info)
##        
##        Log(u"movie url is {}".format(repr(movie_url)))
##        Log(u"movie_info is {}".format(repr(movie_info)))
##        return movie_info

#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):

        Log(u'episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        '''
            url should be the proper starting point for this provider+tvshow;
            
            we just need to adjust some information to get episode specific information

            result should be a url that contains MP4 and HLS video links
        '''
##        raise ValueError()
        episode_url = {}
        try:

            #if not url: raise ValueError
            #url will be None for this site because I need to use information in premierd field to calculate it

            for episode_template in self.episode_templates:
##                Log(repr(episode_template))
                premiered_year = datetime.datetime.strptime(premiered, '%Y-%m-%d').year
                premiered_month = datetime.datetime.strptime(premiered, '%Y-%m-%d').month
                probe_url = episode_template.format(self.base_link
                                                    , premiered_year
                                                    , premiered_month
                                                    , url
                                                    , season
                                                    , episode)
                Log(repr(probe_url))
                r = client.request(probe_url,output='geturl')
##                Log(repr(r))
##                Log(repr(dir(r)))
                if r and (probe_url in r): #confirm not a false positive [trim the last backslash]
                    episode_url = probe_url
                if episode_url: break

                #try again with a later date in case of time zone issues
                premiered_year  = (datetime.datetime.strptime(premiered, '%Y-%m-%d')+datetime.timedelta(1)).year
                premiered_month = (datetime.datetime.strptime(premiered, '%Y-%m-%d')+datetime.timedelta(1)).month                
                probe_url = episode_template.format(self.base_link, premiered_year, premiered_month, url, season, episode)
                Log(repr(probe_url))

                #site will sometimes redirect to an old episode if new episode not yet posted
                r = client.request(probe_url,output='geturl')
                if r and (probe_url in r):
                    episode_url = probe_url

##                    #  (?:/|-)  usually a trailing slash is needed, but sometimes multiple episodes will packed with a dash
##                    s = re.search(probe_url.rstrip('/')+'(?:/|-)', r, re.I)
####                    Log(repr(s))
##                    if s: #confirm not a false positive [trim the last backslash]
##                        episode_url = probe_url
                if episode_url: break

            Log(repr(episode_url))

            r = client.request(episode_url) #validate this exists
            if not r: raise Exception(u"improper response for episode url {}".format(repr(episode_url)))

            episode_info = {}
            episode_info['url'] = episode_url
            episode_info['title']  = title
            episode_info['premiered'] = premiered
            episode_info['season'] = season
            episode_info['episode'] = episode
        except:
            traceback.print_exc()
            raise

        episode_url = urlencode(episode_info)
        Log(u"episode url is {}".format(repr(episode_url)))
##        raise Exception()

        return episode_url
    

#__________________________________________________________________________
#
##    def matchAlias(self, title, aliases):
##        try:
##            for alias in aliases:
##                if cleantitle.get(title) == cleantitle.get(alias['title']):
##                    return True
##        except:
##            return False
#__________________________________________________________________________
#
    def _movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, title, localtitle, aliases, year))))

        movie_url = None
        movie_info = {}

        try:
            year_list = ['',year] #sometimes including year helps, but start without it 
            for year in year_list:
                year2 = ''

                aliases.insert(0, {'country':'','title':localtitle})

                for alias in aliases:
                    if year not in alias['title']:
                        if year:
                            year2 = '-'+str(year)
                            Log('trying with an appended year')
                    else:
                        year2 = ''

                    alias = alias['title'].lower()
                    for c in range(len(self.title_delete_doublewidechars) /2):
                        alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')
                    for c in self.title_delete_chars:
                        alias = alias.replace(c,'')
                    for c in self.title_replace_chars: #replace before delete?
                        alias = alias.replace(c,self.title_replace_subst)                    
                    alias = alias + year2

                    for movies_template in self.movies_templates:
                        probe_url = urljoin(self.base_link, movies_template % (alias))
                        r = None
                        r = client.request(probe_url, ignoreErrors=True)
    ##                    probe_url = probe_url[0:-1] #this site works best with trailing slash, but later on, without it
                        if r and (probe_url in r): #confirm not a false positive [trim the last backslash]
##                            Log("found movie_url '{}'".format(probe_url), level=xbmc.LOGWARNING)
                            movie_url = probe_url
                        if movie_url: break
                    if movie_url: break
                if movie_url: break
            pass
        except ValueError:
            pass 
        except:
            traceback.print_exc()

        if not movie_url: return None

        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
        movie_info['url'] = movie_url
        movie_info = urlencode(movie_info)
        
        Log(u"movie url is {}".format(repr(movie_url)))
        Log(u"movie_info is {}".format(repr(movie_info)))
        return movie_info
    
#__________________________________________________________________________
#
    def searchShow2(self, title, season, aliases, headers):
        url = None
        Log(repr(year))
        Log(repr(aliases))
        Log(repr(headers))

        try:
            title = cleantitle.normalize(title)
            search = '%s Season %01d' % (title, int(season))
            url = urlparse.urljoin(self.base_link, self.search_link % cleantitle.geturl(search))
            Log(repr(url))
            r = client.request(url, headers=headers, timeout='15')
            #r = cache.get(client.request, 1, url, headers=headers, timeout='15')
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
            r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'a', ret='title'))
            r = [(i[0], i[1], re.findall('(.*?)\s+-\s+Season\s+(\d)', i[1])) for i in r]
            r = [(i[0], i[1], i[2][0]) for i in r if len(i[2]) > 0]
            url = [i[0] for i in r if self.matchAlias(i[2][0], aliases) and i[2][1] == season][0]
            url = urlparse.urljoin(self.base_link, '%s/watching.html' % url)
        except:
            traceback.print_exc()
        Log("searchShow url='{}'".format(repr(url)))            
        return url
#__________________________________________________________________________
#
    def searchMovie2(self, title, year, aliases, headers):
        url = None
##        Log(repr(year))
##        Log(repr(aliases))
##        Log(repr(headers))
        try:
            title = cleantitle.normalize(title)
            url = urlparse.urljoin(self.base_link, self.search_link % cleantitle.geturl(title))
            Log(repr(url))
            r = client.request(url, headers=headers, timeout='15')
            Log(repr(r))
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
##            Log(repr(r))
            r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'a', ret='title'))
##            Log(repr(r))
            results = [(i[0], i[1], re.findall('\((\d{4})', i[1])) for i in r]
            try:
                r = [(i[0], i[1], i[2][0]) for i in results if len(i[2]) > 0]
                url = [i[0] for i in r if self.matchAlias(i[1], aliases) and (year == i[2])][0]
            except:
                traceback.print_exc()
                url = None
                pass

            if (url == None):
                url = [i[0] for i in results if self.matchAlias(i[1], aliases)][0]

            url = urlparse.urljoin(self.base_link, '%s/watching.html' % url)
        except:
            Log(repr(title))
            Log(repr(year))
            Log(repr(aliases))
            Log(repr(headers))
            traceback.print_exc()
            
        Log("searchMovie url='{}'".format(repr(url)))            
        return url
#__________________________________________________________________________
#

    def sources(self, url_data, hostDict, hostprDict):
        Log(u'sources {}'.format(repr((url_data,))))#, hostDict, hostprDict))))        
        sources = []
##        traceback.print_stack()
        try:
            if not url_data: raise ValueError 
                
            hostDict =  hostDict + hostprDict

            url_data = parse_qs(url_data)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            is_movie = not ('season' in url_data)
            
            if not 'url'in url_data: raise ValueError 
            url = url_data['url']
            r = client.request(url)

            if not is_movie:
                episode = int(url_data['episode'])
                
            regex_tabs = (
                'class="tab'                 #distinguish between tablist and tabs
                +'.+?id="stream-{}(?:-tab|)"'.format(episode-1) #sometimes will be hiding after this
                +'.+?<iframe width.+?src="(.+?)"'     #with this being the actual urls
                )
            Log(repr(regex_tabs))

            regex_no_tabs = (
                '<iframe width.+?src="(.+?)"'     #with this being the actual urls
                )
            Log(repr(regex_no_tabs))

            links = None

            #sometimes there are entire seasons, one episode per tab
            if not ('episode-{}/'.format(episode) in url):
                Log('tabs_search match')
                links = re.compile(regex_tabs, re.DOTALL).findall(r)
            #sometimes one episode with multiple sources per tab
            if not links:
                Log('attempting no_tabs search')
                links = re.compile(regex_no_tabs, re.DOTALL).findall(r)

            try:
                Log(repr(links))

                link_count = 0
                
                for link in links:
                    Log(repr((link)))
                    link_count = link_count + 1
                    if link_count > self.MAX_LINKS: break

                    valid, hoster = source_utils.is_host_valid(link, hostDict)
                    Log(repr((valid,hoster)))
                    if valid:
                        
                        sources.append(
                                    {
                                    'source': hoster
                                    , 'quality': 'SD'
                                    , 'info': ''
                                    , 'language': 'en'
                                    , 'url': link
                                    , 'direct': True
                                    , 'debridonly': False
                                    }
                                   )
                
            except:
                traceback.print_exc()
            
        except ValueError:
            pass
        except:
            traceback.print_exc()
            source_utils.scraper_error(self.provder_name)

        Log(u"sources returning {}".format(repr(sources)))
##        raise Exception()
        return sources
            
##########    def sources(self, url, hostDict, hostprDict):
##########        sources = []
############        Log("sources url='{}'".format(url))
########        try:
########
########            if url == None: return sources
########
########            data = urlparse.parse_qs(url)
########            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
########            aliases = eval(data['aliases'])
########            Log(repr(aliases))
########            headers = {
########                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
########                ,"Accept": "*/*"
########                ,"Accept-Encoding":"gzip"
########                }
########
########            if 'tvshowtitle' in data:
########                ep = data['episode']
########
########
########
########                for alias in aliases:
########                    url = '%sfilm/%s-season-%01d/watching.html?ep=%s' % (self.base_link
########                                                                         , cleantitle.geturl(alias['title'])
########                                                                         , int(data['season'])
########                                                                         , ep)
########                    r = client.request(url, headers=headers, timeout='10', output='geturl')
########                    if r is None:
########                        url = '%sfilm/%s/watching.html?ep=%s' % (self.base_link
########                                                                             , cleantitle.geturl(alias['title'])
########                                                                             , ep)
########                        r = client.request(url, headers=headers, timeout='10', output='geturl')
########                        
########                    if r: break
########
########                    
########                if url == None:
########                    url = self.searchShow(data['tvshowtitle'], data['season'], aliases, headers)
########
########
########            else:
########                url = self.searchMovie(data['title'], data['year'], aliases, headers)
########
########            if url == None: raise Exception()
########
########            r = client.request(url, headers=headers, timeout='10')
########            r = client.parseDOM(r, 'div', attrs={'class': 'les-content'})
########            if 'tvshowtitle' in data:
########                ep = data['episode']
########                links = client.parseDOM(r, 'a', attrs={'episode-data': ep}, ret='player-data')
########            else:
########                links = client.parseDOM(r, 'a', ret='player-data')
########
########            for link in links:
########                Log(repr(link))
########                if '123movieshd' in link or 'seriesonline' in link  or 'vidembed.me' in link:
########                #if False:
########                    r = client.request(link, headers=headers, timeout='10')
########                    r = re.findall('(https:.*?redirector.*?)[\'\"]', r)
########
########
########                    for i in r:
########                        try:
########                            sources.append(
########                                {'source': 'gvideo'
########                                 , 'quality': directstream.googletag(i)[0]['quality']
########                                 , 'language': 'en'
########                                 , 'url': i
########                                 , 'direct': True
########                                 , 'debridonly': False}
########                                )
########                        except: pass
########                        
########                else:
########                    try:
########                        host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(link.strip().lower()).netloc)[0]
########                        if not host in hostDict:
########                            raise Exception("provider '{}' is not supported".format(host))
########                        host = client.replaceHTMLCodes(host)
########                        host = host.encode('utf-8')
########
########                        Log(repr(link))
########                        if not link.startswith("http"):
########                            link = "https:" + link
########                            Log(repr(link))
########                            
########
########                        sources.append(
########                            {'source': host
########                             , 'quality': 'SD'
########                             , 'language': 'en'
########                             , 'url': link
########                             , 'direct': False
########                             , 'debridonly': False}
########                            )
########                    except:
########                        pass
########
########        except:
########            traceback.print_exc()
########
##########        return None
########        Log("sources sources='{}'".format(repr(sources)))
########        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
##        return None
        try:
            video_url = ''
            if not url.startswith("http"):
                url = "https:" + url


            try:
                import resolveurl #todo; get rid of this?
                video_url = resolveurl.resolve(url)
            except:
                traceback.print_exc()
            Log("scraper {} resolved url={} to {}".format(repr(self.provder_name), repr(url), repr(video_url)))
    ##        raise Exception()
            if video_url:
                return video_url
            else:
                Log(repr(url))
                return ''
        except:
            traceback.print_exc()
            
##        if "google" in url:
##            return directstream.googlepass(url)
##        else:
##            return url
#__________________________________________________________________________
#
