# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Placenta
# Addon id: plugin.video.placenta
# Addon Provider: Mr.Blamo

import re,urllib,urlparse,time,json
import traceback
import re
from openscrapers.modules.log_utils import log as Log

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['www5.gowatchseries.tv','gowatchseries.live','gowatchseries.ch','gowatchseries.tv']
##        self.base_link = 'https://ww2.gowatchseries.co'
        self.base_link = 'https://gowatchseries.ch'
        self.base_link = 'https://www5.gowatchseries.tv'
##https://gowatchseries.live/ajax-search.html?keyword=last+week+tonight+with+john+oliver&id=-1
        #self.search_link = '/ajax-search.html?keyword=%s&id=-1'
        self.search_link = '/search.html?keyword=%s'
#__________________________________________________________________________
#
    def movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        url = None
        try:
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urllib.urlencode(url)
        except:
            traceback.print_exc()
        return url            
#__________________________________________________________________________
#
    def tvshow(self, imdb,  tmdb,  tvdb,  tvshowtitle, localtvshowtitle, aliases, year, season):
        url = None
        try:
            url = {'imdb': imdb
                   ,'tvdb': tvdb
                   ,'tvshowtitle': tvshowtitle
                   ,'aliases': aliases
                   ,'year': year}
            url = urllib.urlencode(url)
        except:
            traceback.print_exc()
        return url            
#__________________________________________________________________________
#
    def episode(self, url, imdb,  tmdb,  tvdb, title, premiered, season, episode):
        if url == None: return None
        try:
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
        except:
            traceback.print_exc()
        return url
#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url == None:
            return sources
        try:

            #raise Exception("asdfas")

            #Log("url='{}'".format(repr(url)))

            if str(url).startswith('http'):
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            Log(repr(data))
            aliases = eval(data['aliases'])
            Log(repr(aliases))

            if 'tvshowtitle' in data:
                title = data['tvshowtitle']
                isTVshow = True
            else:
                title = data['title']
                isTVshow = False
            aliases.append({'country':'fallback','title':title})
            
##            Log("title='{}'".format(repr(title)))
            if 'season' in data: season = data['season']
            if 'episode' in data: episode = data['episode']
            year = data['year']
            Log('year,season,episode='+repr((year,season,episode)))
            
            #get some cookie info before actually searhing
            Log("self.base_link='{}'".format(repr(self.base_link)))
            r = client.request(self.base_link, output='extended', timeout='10')
            #Log("r='{}'".format(repr(r)))
            cookie = r[4] ; headers = r[3] ; result = r[0]
            headers['Cookie'] = cookie

            vurl1 = None
            vurl2 = None
            Log("alias search begins")
            for alias in aliases:
                Log(repr(alias))
                alias = alias['title']
                Log("testing for alias '{}'".format(alias))
                query = urlparse.urljoin(self.base_link, self.search_link % urllib.quote_plus(cleantitle.getsearch(alias, allow_singlequote=True)))
                Log(repr(query))
                response = client.request(query, headers=headers, XHR=True)
##                Log(repr(r))
                list_items = client.parseDOM(response, 'ul', attrs = {'class': 'listing items'})
                list_items = client.parseDOM(list_items, 'a', ret='href')
                Log(repr(list_items))
                
                #we now have a search result with hopefully our show name somewhere inside
                if isTVshow:
                    cleaned_title1 = cleantitle.geturl(alias) + 'season' + season
                    cleaned_title2 = cleantitle.geturl(alias) + 'season%02d'%int(season)
                    cleaned_title3 = cleantitle.geturl(alias) + '-season-' + season
                else:
                    cleaned_title1 = cleantitle.geturl(alias)
                    cleaned_title2 = cleantitle.geturl(alias)
                    cleaned_title3 = cleantitle.geturl(alias)
                    pass
                    
                
                #Log(repr((cleaned_title3,cleaned_title2,cleaned_title1)))
                for list_item in list_items:
                    Log(repr(list_item))
                    if cleaned_title3 in list_item:
                        vurl1 = self.base_link + '/info/' + cleaned_title3
                        vurl2 = None
                        title = alias
                        break
                    if cleaned_title2 in list_item:
                        vurl1 = self.base_link + '/info/' + cleaned_title2
                        vurl2 = None
                        title = alias
                        break
                    if cleaned_title1 in list_item:
                        vurl1 = self.base_link + '/info/' + cleaned_title1
                        vurl2 = None
                        title = alias
                        break
            Log("alias search done")

                        
            Log('vurl1='+repr(vurl1))
            Log('vurl2='+repr(vurl2))

            #get the main page for this season
            r = client.request(vurl1, headers=headers)
            headers['Referer'] = vurl1

            slinks = []
            if isTVshow:
                slinks = client.parseDOM(r, 'li', attrs = {'class': 'child_episode'})
                slinks = client.parseDOM(slinks, 'a', ret='href')
            else:
                slinks = client.parseDOM(r, 'li', attrs = {'class': 'child_episode'})
                slinks = client.parseDOM(slinks, 'a', ret='href')
            Log('all links='+repr(slinks))
            slink = None
            for slink in slinks:
                if isTVshow:
                    Log('isTVshow')
                    Log(slink)
                    if  slink.endswith('-episode-' + episode):
                        if not slink.startswith('/'):
                            slink  = '/' + slink
                        slink = self.base_link + slink
                        r = client.request(slink, headers=headers)
##                        Log(repr(r))
                        break
                else:
                    if  slink.endswith('-episode-0') or slink.endswith('-episode-1'):
                        if not slink.startswith('/'):
                            slink  = '/' + slink
                        slink = self.base_link + slink
                        r = client.request(slink, headers=headers)
##                        Log(repr(r))
                        break

            Log('link found='+repr(slink))
            
            slinks = client.parseDOM(r, 'div', attrs = {'class': 'anime_muti_link'})
            slinks = client.parseDOM(slinks, 'li', ret='data-video')
            if len(slinks) == 0 and not vurl2 == None:
                r = client.request(vurl2, headers=headers)
                headers['Referer'] = vurl2
                slinks = client.parseDOM(r, 'div', attrs = {'class': 'anime_muti_link'})                
                slinks = client.parseDOM(slinks, 'li', ret='data-video')


            for slink in slinks:
                Log(repr(slink))
                try:
                    if 'vidnode.net/streaming.php' in slink:
                        r = client.request('https:%s'%slink, headers=headers)
                        clinks = re.findall(r'sources:\[(.*?)\]',r)[0]
                        clinks = re.findall(r'file:\s*\'(http[^\']+)\',label:\s*\'(\d+)', clinks)
                        for clink in clinks:
                            q = source_utils.label_to_quality(clink[1])
##                            Log(repr(clink[0]))
                            sources.append({
                                'source': 'cdn'
                                , 'quality': q
                                , 'language': 'en'
                                , 'url': clink[0]
                                , 'direct': True
                                , 'debridonly': False
                                })
                    else:
                        valid, hoster = source_utils.is_host_valid(slink, hostDict)
                        if valid:
##                            Log(repr(slink))
                            if not slink.startswith('http'): slink= 'https:' + slink
##                            Log(repr(slink))
                            sources.append({
                                'source': hoster
                                , 'quality': 'SD'
                                , 'language': 'en'
                                , 'url': slink
                                , 'direct': False
                                , 'debridonly': False
                                })
                except:
                    pass

        except:
            traceback.print_exc()
        Log(repr(sources))
        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
##        Log("resolve(self, url)" + repr((self, url)))
##        traceback.print_stack()
        return url
#__________________________________________________________________________
#



