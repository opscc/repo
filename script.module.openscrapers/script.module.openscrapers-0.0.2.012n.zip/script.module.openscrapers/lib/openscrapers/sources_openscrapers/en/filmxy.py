# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import traceback
from openscrapers.modules.log_utils import log as Log

try: from urlparse import urljoin
except ImportError: from urllib.parse import urljoin

from openscrapers.modules import cfscrape
from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils
from openscrapers.modules import client

class source(object):
#__________________________________________________________________________
#
    def __init__(self):
        self.priority = 31
        self.language = ['en']
        self.domains = ['filmxy.online','filmxy.tv', 'filmxy.me', 'filmxy.one', 'filmxy.ws', 'filmxy.live', 'filmxy.pw']
        self.base_link = 'https://www.filmxy.online'
        self.search_link = '/%s-%s/'
        self.scraper = cfscrape.create_scraper()

#__________________________________________________________________________
#
    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.geturl(title)
            url = urljoin(self.base_link, (self.search_link % (title, year)))
##            Log(repr(url))
            return url
        except:
            traceback.print_exc()
            #source_utils.scraper_error('FILEXY')
            return

#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url is None: return sources

        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
                , 'verifypeer': 'false'
                }
##            result = self.scraper.get(url, headers=headers).content
            result = client.request(url)

            if not result:
                return sources

##            regex = '<iframe src="(https://www.linkbin.me/e/\w+/)"'  #2022
            regex = '<iframe src="https://www.linkbin.me/e/(\w+/)"'  #2023-05
            intermediate_link = re.compile(regex, re.DOTALL).findall(result)
            if intermediate_link:
                intermediate_link='https://www.linkbin.me/' + intermediate_link[0]
            
            result = client.request(intermediate_link, url)

##            regex = 'option value="(.+?)".+?>(.+?)<' #2022
            regex = (
                    'class="signle-link"'
                     '.+?href="(.+?)"'
                     '.+?span>(.+?)<'
                     '.+?strong>(.+?)<'
                     ) #2023-05
            streams = re.compile(regex, re.DOTALL).findall(result)

            #for link, qual in streams: #2022
            for link, qual, host in streams: #2022
                Log(repr((link, qual, host)))
                #quality = source_utils.check_url(link)
                quality = source_utils.get_qual(qual)
##                host = link.split('//')[1].replace('www.', '')
                host = host.split('/')[0].lower()
                Log(repr((link, qual, quality,host)))

                valid, host = source_utils.is_host_valid(link, hostDict)
                Log(repr((valid,host)))
                if valid:
                    if quality == 'SD':
                        sources.append({
                            'source': host
                            , 'quality': '720p'
                            , 'info': ''
                            , 'language': 'en'
                            , 'url': link
                            , 'direct': False
                            , 'debridonly': False
                            })
                    else:
                        sources.append( {
                            'source': host
                            , 'quality': quality
                            , 'info': ''
                            , 'language': 'en'
                            , 'url': link
                            , 'direct': False
                            , 'debridonly': False
                            })

        except:
            traceback.print_exc()

        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        Log(repr(url))
        return url
#__________________________________________________________________________
#
