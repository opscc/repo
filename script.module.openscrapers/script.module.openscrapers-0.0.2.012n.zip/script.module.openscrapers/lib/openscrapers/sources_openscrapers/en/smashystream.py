# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import os
import re
import traceback
import urllib
from openscrapers.modules.log_utils import log  as Log
    

try: from urlparse import parse_qs, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.provider_name = 'SmashyStream'
        self.priority = 23
        self.language = ['en']
        self.domains = ['embed.smashystream.com']
        self.base_link = 'https://embed.smashystream.com/'
        self.search_link = 'player-json-api.php?id=%s'

## data-id="https://embed.smashystream.com/fz1.php?tmdb=392276&season=1&episode=1">Player  F<span class="float-right status-dot text-warning" > <i class="fa fa-circle"></i> </span></a><a href="javascript:void(0)" onClick="Player.play(false, this)" class="server dropdown-item "
## data-id="https://embed.smashystream.com/dud_tv.php?imdb=&season=1&episode=1">Player D (Hindi)<span class="float-right status-dot text-warning"  > <i class="fa fa-circle"></i> </span></a><a href="javascript:void(0)" onClick="Player.play(false, this)" class="server dropdown-item "
## data-id="https://embed.smashystream.com/fx555.php?tmdb=392276&season=1&episode=1">Player FX</a><a href="javascript:void(0)" onClick="Player.play(false, this)" class="server dropdown-item "
## data-id="https://embed.smashystream.com/ems.php?imdb=&season=1&episode=1">Player ES<span class="float-right status-dot text-warning"  > <i class="fa fa-circle"></i> </span></a><a href="javascript:void(0)" onClick="Player.play(false, this)" class="server dropdown-item "
## data-id="https://embed.smashystream.com/supertv.php?tmdb=392276&season=1&episode=1">Player S</a><a href="javascript:void(0)" onClick="Player.play(false, this)" class="server dropdown-item "
## data-id="https://embed.smashystream.com/cf.php?imdb=&season=1&episode=1">Player C<span class="float-right status-dot text-warning"  > <i class="fa fa-circle"></i> </span></a>
## https://embed.smashystream.com//playere.php?tmdb=93740&season=1&episode=1&button=hide                             


#__________________________________________________________________________
#
    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        #return not-none if this provider can find movies
        Log(u'movie {}'.format(repr((imdb, tmdb, localtitle, aliases, year))))
        url = None
	try:
            url = {'imdb': imdb
                   , 'tmdb': tmdb
                   , 'title': title
                   , 'aliases': aliases
                   , 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
#__________________________________________________________________________
#
    #return not-none if this provider can find tv shows
    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        Log(u'TVshow {}'.format(repr((imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))))
        url = None
        try:
            url = {'imdb': imdb
                   , 'tvdb': tvdb
                   , 'tmdb': tmdb
                   , 'tvshowtitle': tvshowtitle
                   , 'localtvshowtitle': localtvshowtitle
                   , 'aliases': aliases
                   , 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url            
#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
        #return url-encoded url pointing to a specific episode
        Log(u'Episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        if url is None:
            return None
        try:
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url

###__________________________________________________________________________
###
##    def find_series_url(self, url_data, aliases, year):
##        Log(u"find_series_url() {}".format(repr((url_data, aliases))))
##        return None
##        find_series_url = ''
##        title=''
##        for alias in aliases:        
##            title = alias['title']
##            Log(u"testing for title alias '{}'".format(title))
##            title2 = u'/tv/free-'+ cleantitle.getsearch(title).lower().replace(" ", "-").replace(".","") + '-'
##            Log(u"expecting a format for this site as '{}'".format(title2))
##
##            query = cleantitle.getsearch(title,include_colon=True).lower()
##            query = quote_plus(query).replace('+','-')
##            search_url = urljoin(self.base_link, self.search_link % query)
##            Log(u"search_url={}".format(repr(search_url)))
##
##            r = client.request(search_url)  #, XHR=True  #adds X-Requested-With: XMLHttpRequest
##            search_result = client.parseDOM(r, 'div', {'class': 'flw-item'}  )
##
##            series_url = ''
##            for i in search_result:
##                if i:
##                    likely_series_url = ''
##                    for href in client.parseDOM(i, 'a', ret='href' ):
##                        if title2 in href:
##                            likely_series_url = href
##                            break
##                    #confirm we are looking at correct series year
##                    year_string = '<span class="fdi-item">{}</span>'.format(year)
##                    for info in client.parseDOM(i, 'div', {'class': 'film-detail'} ):
##                        for href in client.parseDOM(info, 'div', {'class': 'fd-infor'} ):
##                            if year_string in href:
##                                series_url = likely_series_url
##                                break
##                if series_url: break
##            if series_url: break
##
##
##        if '-hd-' in series_url:
##            series_url = series_url.split('-hd-')[1]
##            series_url = 'https://sflix.to/ajax/v2/tv/seasons/' + series_url
##            
##        Log(u"series_url={}".format(repr(series_url)))
##        if not series_url:
##            raise Exception(u"no series_url found for '{}'".format(title))
##        if series_url.startswith("/"): series_url = urljoin(self.base_link, series_url)
##        return series_url

###__________________________________________________________________________
###
##
##    #return url-encoded url pointing to a specific episode
##    def find_episode_url(self, series_url, season, episode):
##        Log(u"find_episode_url() {}".format(repr((series_url, season, episode))))
##        return
##    
##        episode_url = ''
##
##        r = client.request(series_url)
##        Log(repr(r))
##        simple_api_info = json.loads(r)
##        for info in simple_api_info['simple-api']:
##            Log(repr(info))
##            if 'season' in info: 
##                if info['season'] == season and info['episode'] == episode:
##                    episode_url = info['iframe']
##                    break
##            else: #a movie
##                episode_url = info['iframe']
##                break
##                
##                
##        Log(u"episode_url={}".format(repr(episode_url)))
##        if not episode_url: raise Exception(u"no episode_url found for {} s{}e{}'".format(repr(series_url),season,episode))
##        return episode_url

#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):
##        traceback.print_stack()
        Log(u'Sources {}'.format(repr((url, hostDict, hostprDict))))
        sources = []

        if url is None:
            return sources

 
        try:
            url_data = parse_qs(url)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))


    
            imdb_id = url_data['imdb']
            tmdb = url_data['tmdb']
            if 'season' in url_data: season = url_data['season']
            else: season = url_data['year']
            if 'episode' in url_data: episode = url_data['episode']
            else:  episode = ''

            
        
            episode_url = "https://embed.smashystream.com//playere.php?tmdb={}&season={}&episode={}&button=hide".format(tmdb,season,episode)
            r = client.request(url=episode_url
                               #, referer=series_url
                               )
            intermediate_links = client.parseDOM(   html=r
                                      ,name='a'
                                      ,attrs={'class':'server dropdown-item '}
                                      ,ret='data-id'
                                      )
            for intermediate_link in intermediate_links:
                Log(repr(intermediate_link))
                r = client.request(url=intermediate_link
                                   , referer=episode_url
                                   )

                regex = (
                    "new Playerjs\({(.*)"
                    )
                try:
                    files = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(r)
                    if files: files = files[0]
                    else: continue
                except:
                    traceback.print_exc()
                    continue
                    files = ''

##                Log(repr(files))
                regex = (
                    '"?file"?:\s?'
                    '(.+?(?:,"|",))'
                    )
                region_arr = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(files)
                if region_arr:
                    region = ",".join(region_arr)
                else: region = ''

                regex = (
                    '(?:\[(.+?)\]|http)'
                    '(.+?),'
                    )
                links = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(region)
##                Log(repr(links))
##                for rez,u in links:
##                    Log(repr((rez,u)))


    ##            return None                
    ##            links=[]
                for rez, url in links:
                    
                    if not url.startswith('http'): url = 'http' + url
                    
                    url = url.replace('\\/','/')
                    
                    url = url.replace('\\\\/','/')

                    
                    
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    #Log(repr((valid,host,url)))

                    header = {
                        'Referer':intermediate_link
                        }
                    url = url + "|{}".format( urllib.urlencode(header)  )
                    
                    if str(rez) in ['1080']:
                        quality = '1080p'
                    elif str(rez) in ['720']:
                        quality = 'HD'
                    elif str(rez) in ['360']:
                        quality = 'SD'
                    elif str(rez) in ['auto']:
                        quality = 'SD'
                    else:
                        quality = 'SD'
                        
                    if 'dud' in intermediate_link:
                        lang = 'hi'
                    else:
                        lang = 'en'
                        
                    sources.append(
                                    {
                                    'source': host
                                    , 'quality': quality
                                    #, 'info': ''#str(rez)
                                    , 'info': str(rez)
                                    , 'language': lang
                                    , 'url': url
                                    , 'direct': True
                                    , 'debridonly': False
                                    }
                                   )
            
                
        except:
            traceback.print_exc()

        Log(repr(sources))
        #return None
        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        Log("{} found {}".format(self.provider_name, repr(url)))
        video_url = url
        
##        video_url = None
##        import resolveurl
##        try:
##            video_url = resolveurl.resolve(url)
##        except:
##            traceback.print_exc()
##
##        Log("{} resolved url={} to {}".format(self.provder_name, repr(url), repr(video_url)))

        return video_url
#__________________________________________________________________________
#
