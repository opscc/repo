# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import traceback
from openscrapers.modules.log_utils import log as Log

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import cache
from openscrapers.modules import dom_parser
from openscrapers.modules import jsunpack
from openscrapers.modules import source_utils

#__________________________________________________________________________
#
class source:
    def __init__(self):
        self.priority = 31
        self.language = ['en']
        self.domains = ['watch32hd.co']
        self.base_link = 'https://watch32hd.co/'
        self.search_link = 'results?q=%s'
#__________________________________________________________________________
#
    def movie(self, imdb, title, localtitle, aliases, year):
        url = None
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url is None: return sources
        try:

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = unicode(data['title'])
            hdlr = unicode(data['year'])
##            Log("title='{}'".format(repr(title)))
##            Log("hdlr='{}'".format(repr(hdlr)))

            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', title)
            url = self.search_link % quote_plus(query)
            url = urljoin(self.base_link, url)
##            Log("url='{}'".format(repr(url)))

            r = cache.get(client.request, 1, url)
            #r = client.request(url)
            
            if not r:
                return sources

            posts = client.parseDOM(r, 'div', attrs={'class': 'video_title'})
##            Log("posts='{}'".format(repr(posts)))

            items = []
            for post in posts:
                try:
                    data = dom_parser.parse_dom(post, 'a', req=['href', 'title'])[0]
##                    Log(repr(data))
                    t = data.content
                    #y = re.findall('\({0,1}(\d{4})\){0,1}', data.attrs['title'])[0]
                    y = re.findall(".+?\((\d+)\)", data.attrs['title'])
                    if y:
                        y=y[0]
                    else:
                        #Log("year not found in title '{}'".format(data.attrs['title']))
                        continue
                    
                    qual = data.attrs['title']
                    
                    if '-' in qual:
                        qual = qual.split('-')[1]

                    link = data.attrs['href']

##                    Log("link='{}'".format(repr(link)))
##                    Log("qual='{}'".format(repr(qual)))
##                    Log("y='{}'".format(repr(y)))
##                    Log("t='{}'".format(repr(t)))
##                    Log("cleantitle.get(t)='{}'".format(repr(cleantitle.get(t))))
##                    Log("cleantitle.get(title)='{}'".format(repr(cleantitle.get(title))))
                    if cleantitle.get(t) != cleantitle.get(title):
                        Log("title mis-match")
                        continue
                    Log(repr(hdlr))
                    Log(repr(y))
                    if (hdlr not in[None,'none','None']) and (y != hdlr):
                        Log("year mis-match")
                        continue
                
                    Log("adding {}".format(repr([(link, qual)])))
                    items += [(link, qual)]
                except:
                    traceback.print_exc()
##                    source_utils.scraper_error('WATCH32')
                    pass


##https://watch32hd.co/results?q=Wonder+Woman+1984
##<div class="video_title">
##<h3><a title="Wonder Woman 1984 (2020) Full Movie - HD 720p" href="/watch?v=Wonder_Woman_1984_2020#video=nF5QyFymG3pOACwTsTdJzhxVDFZ8AJf1hTfEAOAVo8-t8Q3cnyrHzckzyd679_18POlZM6Q">Wonder Woman 1984</a></h3>
##</div>
##<div class="video_quality">
##<b>Year</b>: 2020 - <b>Quality</b>: 720p
##opens
##https://watch32hd.co/watch?v=Wonder_Woman_1984_2020
##opens
##var frame_url = "//vidlink.org/embed/5fe6c43a00eb9d2d5c5e13dc";
##contains
##    var postID = '5fe6c43a00eb9d2d5c5e13dc';
##opens  [last part is epoch time]
##https://vidlink.org/embed/info?postID=5fe6c43a00eb9d2d5c5e13dc&1614728048
##contains json with 
##json_content['embed_urls']  =https://ronemo.com/embed/8DR3UH7Fyab
##opens 
##https://ronemo.com/api/video/get-link?idVid=8DR3UH7Fyab
##contains json with 
##json_content['link']=8DR3UH7Fyab/f/playlist.m3u8
##opens
##https://hls.ronemo.com/8DR3UH7Fyab/f/playlist.m3u8|Referer=https://ronemo.com/
                

##            Log("items='{}'".format(repr(items)))
            for item in items:
                try:
                    item_url = item[0]
                    if not item_url.startswith('http'):
                        item_url = urljoin(self.base_link, item_url)

                    r = cache.get(client.request, 1, item_url)
                    #r = client.request(item_url)

                    qual = client.parseDOM(r, 'h1')[0]
                    quality = source_utils.get_release_quality(item[1], qual)[0]

                    url = re.findall('''frame_url\s*=\s*["']([^']+)['"]\;''', r, re.DOTALL)[0]
                    url = url if url.startswith('http') else urljoin('https://', url)

                    source = {
                        'source': 'vidlink'
                        ,'quality': quality
                        ,'info': ''
                        ,'language': 'en'
                        ,'url': url
                        ,'direct': False
                        ,'debridonly': False
                        }
##                    Log("source='{}'".format(repr(source)))
                    sources.append(source)

                except:
                    traceback.print_exc()
##                    source_utils.scraper_error('WATCH32')
                    pass

        except:
            traceback.print_exc()
##            source_utils.scraper_error('WATCH32')
        return sources

#__________________________________________________________________________
#
    def resolve(self, url):
        try:

##opens  [last part is epoch time]
##https://vidlink.org/embed/info?postID=5fe6c43a00eb9d2d5c5e13dc&1614728048
##contains json with 
##json_content['embed_urls']  =https://ronemo.com/embed/8DR3UH7Fyab
##opens 
##https://ronemo.com/api/video/get-link?idVid=8DR3UH7Fyab
##contains json with 
##json_content['link']=8DR3UH7Fyab/f/playlist.m3u8
##opens
##https://hls.ronemo.com/8DR3UH7Fyab/f/playlist.m3u8|Referer=https://ronemo.com/

##            Log("url='{}'".format(repr(url)))

            if not ('vidlink' in url):
                raise Exception("expected 'vidlink' was not found in url")
                return url

            post_id = url.split('/')[-1]
##            Log("post_id='{}'".format(repr(post_id)))

            base_headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36}"
                }
            
            import time
            headers = base_headers.copy()
            headers["X-Requested-With"] = "XMLHttpRequest"
            json_url = (
                "https://vidlink.org/embed/info?postID="
                + post_id + "&"
                + str(int(time.time()))
##                + Header2pipestring(headers)
                )
##            Log("json_url='{}'".format(repr(json_url)))
##            json_html = cache.get(client.request, 1, json_url)            
            json_html = client.request(json_url, headers=headers )
            json_content = json.loads(json_html)
##            Log("json_content='{}'".format(repr(json_content)))
##            return None

            headers = base_headers.copy()
            headers["Referer"] = "https://ronemo.com/"
            json_url = (
                "https://ronemo.com/api/video/get-link?idVid="
                + json_content['embed_urls'].split('/')[-1]
##                + Header2pipestring(headers)
                )
##            Log("json_url={}".format(repr(json_url)))

##            json_html = cache.get(client.request, 1, json_url)
            json_html = client.request(json_url, headers=headers)
##            Log("json_html='{}'".format(repr(json_html)))
            json_content = json.loads(json_html)
##            Log("json_content='{}'".format(repr(json_content)))

            video_url = (
                "https://hls.ronemo.com/"
                + json_content['link']
                + Header2pipestring(headers)
                )
##            Log("video_url='{}'".format(repr(video_url)))

            return video_url
##
##            ua = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1'}
##            html = client.request(url, headers=ua)
##            postID = re.findall("postID\s*=\s*'([^']+)", html)[0]
##
##            rid = client.request('https://vidlink.org/embed/update_views', post=None, headers=ua, referer=url)
##            id_view = re.findall('''id_view['"]\s*:\s*['"]([^'"]+)['"]''', rid)[0]
##
##            plink = 'https://vidlink.org/streamdrive/info'
##            data = {'browserName': 'Firefox',
##                    'platform': 'Win32',
##                    'postID': postID,
##                    'id_view': id_view}
##            headers = ua
##            headers['X-Requested-With'] = 'XMLHttpRequest'
##            headers['Referer'] = url
##            ihtml = client.request(plink, post=data, headers=headers)
##            linkcode = jsunpack.unpack(ihtml).replace('\\', '')
##            sources = json.loads(re.findall('window\.srcs\s*=\s*([^;]+)', linkcode, re.DOTALL)[0])
##            for src in sources:
##                link = src['url']
##                return link
        except:
            traceback.print_exc()
##            source_utils.scraper_error('WATCH32')
            return None
#__________________________________________________________________________
#
def Header2pipestring(header):
    q = "|{}".format( urlencode(header)  )
    return q
#__________________________________________________________________________
#
