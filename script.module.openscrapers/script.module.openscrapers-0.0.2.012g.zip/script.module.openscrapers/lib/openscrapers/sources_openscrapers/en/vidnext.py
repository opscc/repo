# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import os
import re
import traceback
from openscrapers.modules.log_utils import log  as Log
    

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 32
        self.language = ['en']
        self.domains = ['vidnext.net']
        self.base_link = 'https://vidnext.net/'
        self.search_link = 'search.html?keyword=%s'
#https://vidnext.net/?keyword_search=wandavision
#https://vidnext.net/search.html?keyword=wandavision
#https://vidnext.net/videos/marvels-wandavision-season-1-episode-8

#__________________________________________________________________________
#
    def movie(self, imdb, title, localtitle, aliases, year):
        url = None
	try:
            url = {'imdb': imdb, 'title': title, 'year': year}
##            Log("vidnext movie url={}".format(repr(url)))
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
#__________________________________________________________________________
#
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
##        raise Exception()
        url = None
        Log(repr(aliases))
        try:
            url = {'imdb': imdb
                   , 'tvdb': tvdb
                   , 'tvshowtitle': tvshowtitle
                   , 'localtvshowtitle': localtvshowtitle
                   , 'aliases': aliases
                   , 'year': year}
##            Log("vidnext tvshow url={}".format(repr(url)))
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url            
#__________________________________________________________________________
#
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
##        raise Exception()
        if url is None:
            return None
        try:
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url
#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url is None: return sources

        try:
##            Log(u"url={}".format(repr(url)))
##            Log(u"hostDict={}".format(repr(hostDict)))
##            Log(u"hostDict={}".format(repr(hostDict)))
##            Log(u"hostprDict={}".format(repr(hostprDict)))

            data = parse_qs(url)
            Log(u"data={}".format(repr(data)))            
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            Log("parse_qs data='{}'".format(repr(data)))

            if 'tvshowtitle' in data:
                title = data['tvshowtitle']
            elif 'title' in data:
                title = data['title']
            else:
                raise Exception("No title found in url='{}'".format(repr(url)))
            Log("title='{}'".format(repr(title)))

            if 'season' in data:
                season = int(data['season'])
                title2 = "{}-season-{}-".format(cleantitle.getsearch(title).lower().replace(" ", "-"), season)
            elif 'year' in data:
                season = int(data['year'])
                title2 = "{}".format(cleantitle.getsearch(title).lower().replace(" ", "-"), season)
            else:
                raise Exception(u"No title2 found in url={}".format(repr(url)))
            Log(u"title2={}".format(repr(title2)))

            episode = None
            if 'episode' in data and 'season' in data:
                episode = int(data['episode'])
                hdlr = 's%02de%02d' % (season, episode)
                hdlr2 = u"season-{}-episode-{}".format(season, episode)
            else: #nothing required for movies
                hdlr = ""
                hdlr2 = ""
            Log("hdlr='{}'".format(repr(hdlr)))
            Log("hdlr2='{}'".format(repr(hdlr2)))

##            query = quote_plus(cleantitle.getsearch(title, allow_asterix=True))
            query = cleantitle.getsearch(title, allow_asterix=True).replace(" ", '%20')
            search_url = urljoin(self.base_link, self.search_link % query)
            Log(u"search_url={}".format(repr(search_url)))
            r = client.request(search_url)  #, XHR=True  #adds X-Requested-With: XMLHttpRequest
##            Log("r='{}'".format(repr(r)))

            # the site's 'search' will not find what we need and the url names are random..
            # at best we can discover a link to the season we are looking for
            # then open that URL and search it for the episode we want
            data = client.parseDOM(r, 'ul', {'class': r'listing items'})
            Log("data={}".format(repr(data)))
            #epis = [client.parseDOM(i, 'a', ret='href' )[0] for i in data if i]
            season_url = None
            for i in data:
                if i:
                    for href in client.parseDOM(i, 'a', ret='href' ):
##                        Log("href='{}', title2'{}'".format(repr(href),repr(title2)))
                        if title2 in href:
##                            Log("href='{}'".format(repr(href)))
                            season_url = href
                            break
                    if season_url: break
            Log(u"season_url={}".format(repr(season_url)))
            if not season_url:
                raise Exception(u"no season url found for '{}-{}'".format(title, season))
            if season_url.startswith("/"): season_url = urljoin(self.base_link, season_url)
            Log("season_url='{}'".format(repr(season_url)))


            r = client.request(season_url)
##            Log("r='{}'".format(repr(r)))
            data = client.parseDOM(r, 'ul', {'class': r'listing items lists'})
            episode_url = None
            for i in data:
##                Log("i='{}'".format(repr(i)))
                if i:
                    for href in client.parseDOM(i, 'a', ret='href' ):
                        Log("href='{}'".format(repr(href)))
                        if (title2 in href) and (hdlr2 in href):
                            Log("href='{}'".format(repr(href)))
                            episode_url = href
                            break
                    if episode_url: break
            Log("episode_url='{}'".format(repr(episode_url)))
            if not episode_url:
                raise Exception(u"no episode url found for '{}-{}'".format(title, season))
            if episode_url.startswith("/"): episode_url = urljoin(self.base_link, episode_url)
            Log(u"episode_url={}".format(repr(episode_url)))


            # now we have an acutal episode url
            #   the url contains another link to the sources
            r = client.request(episode_url)
            if r.startswith("404"): #call actually failed, but source does not use normal status code
                #sometimes the site will ned append -tba to the URL...
                r = client.request(episode_url+"-tba")
                if r.startswith("404"):
                    raise Exception(u"Episode not found {}".format(repr(episode_url)))
##            Log("r='{}'".format(repr(r)))
            
            #the sources are inside this page
            data = client.parseDOM(r, 'iframe', ret='src')
##            Log("data='{}'".format(repr(data)))
            if data:
                sources_url = data[0]
            else:
                sources_url = ""
##                Log("episode_url='{}'".format(repr(episode_url)))
##                Log("data='{}'".format(repr(data)))
##                Log("r='{}'".format(repr(r)))
                pass
            if sources_url.startswith("//"): sources_url = "https:" + sources_url

            sources_html = client.request(sources_url, referer=episode_url)
##            Log("sources_html='{}'".format(repr(sources_html)))

            links = client.parseDOM(sources_html, 'li', {'data-status': '1'}, ret='data-video')
##            Log("links='{}'".format(repr(links)))

            for url in links:
                
                valid, host = source_utils.is_host_valid(url, hostDict)
                if not valid:
                    Log("invalid host ='{}'".format(repr(host)))
                    Log("invalid url ='{}'".format(repr(url)))
                    try:
                        if host in ("vidnext.net"):
                            if url.startswith("/"):
                                url = urljoin(self.base_link, url)
                            Log("url={}".format(repr(url)))
                            r = client.request(url, referer=episode_url)
                            alt_url = re.compile(r"sources:.+?file: '([^']+?)'", re.DOTALL | re.IGNORECASE).findall(r)
                            if alt_url:
                                alt_url=alt_url[0]
##                                Log("alt_url='{}'".format(repr(alt_url)))
                            hostDict.append(host)
                            valid, host = source_utils.is_host_valid(alt_url, hostDict)
                            hostDict.remove(host)
                            
                            if valid:
                                url = alt_url
                            else:
                                Log("still not valid{}".format(repr(alt_url)))

                        if host in ("vidembed.net"):
                            if url.startswith("/"):
                                url = urljoin(self.base_link, url)
                            Log("url={}".format(repr(url)))
                            r = client.request(url, referer=episode_url)
                            alt_url = re.compile(r"sources:.+?file: '([^']+?)'", re.DOTALL | re.IGNORECASE).findall(r)
                            if alt_url:
                                alt_url=alt_url[0]
                            Log("alt_url='{}'".format(repr(alt_url)))

                            hostDict.append(host)
                            valid, host = source_utils.is_host_valid(alt_url, hostDict)
                            hostDict.remove(host)
                            
                            if valid:
                                url = alt_url
                            else:
                                Log("still not valid{}".format(repr(alt_url)))
                                
                    except:
                        traceback.print_exc()
                    if not valid:
                        continue  #skip this url; only return file hosters we understand

                sources.append(
                                {
                                'source': host
                                , 'quality': 'SD'
                                , 'info': ''
                                , 'language': 'en'
                                , 'url': url
                                , 'direct': False
                                , 'debridonly': False
                                }
                               )

        except:
            traceback.print_exc()

##        Log(repr(sources))
        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        Log("vidnext resolved url='{}'".format(repr(url)))
        return url
#__________________________________________________________________________
#
