# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import base64
import json
import os
import re
import traceback

from openscrapers.modules.log_utils import log  as Log
    

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote_plus, unquote
except ImportError: from urllib.parse import urlencode, quote_plus, unquote

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils

import sys
if sys.version_info >= (3,):
    def b(x):
        return x
else:
    import array
    def b(x):
        return array.array('B', x)
        #return codecs.latin_1_encode(x)[0]
    def u(x):
        if isinstance(x, unicode):
            return x.encode('ascii','ignore')
        else:
            return x


#https://github.com/Ciarands/vidsrc-to-resolver
class source:
    def __init__(self):
        self.priority = 32
        self.language = ['en']
        self.domains = ['vidsrc.to']
        self.base_link = 'https://vidsrc.to'
        self.KEY_URL = "https://github.com/Ciarands/vidsrc-keys/blob/main/keys.json"
        self.DEFAULT_KEY = "WXrUARXb1aDLaZjI"
        self.DEFAULT_KEY = "WXrUARXb1aDLaZjI"
        self.PROVIDER_URL = "https://vidplay.online" # vidplay.site / vidplay.online / vidplay.lol
        self.search_link = 'browse?q=%s'

        self.headers = {'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0"  #"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
                        ,'Referer': self.base_link
                        ,'Accept-Encoding': 'gzip'
                        }

###__________________________________________________________________________
## make sure this exists if we can find Movies here
    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, localtitle, aliases, year))))
        url = None
	try:
            url = {
                'imdb': imdb
                , 'tmdb': tmdb
                , 'title': title
                , 'aliases': aliases
                , 'year': year
                }
            url['episode_url'] = '{}/embed/movie/{}'.format(self.base_link, tmdb)
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
###__________________________________________________________________________
## make sure this exists if we can find TV here
    def tvshow(self, imdb,  tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        
        Log(u'TVshow {}'.format(repr((imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))))
        url = None
        try:
            url = {  'imdb': imdb
                   , 'tmdb': tmdb
                   , 'tvdb': tvdb
                   , 'tvshowtitle': tvshowtitle
                   , 'localtvshowtitle': localtvshowtitle
                   , 'aliases': aliases
                   , 'year': year
                     }
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url            
#__________________________________________________________________________
## make sure this exists if we can find Episodes here
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):

        Log(u'Episode {}'.format(repr((url, imdb, tmdb, tvdb, title, premiered, season, episode))))
        if url is None: return None
        try:
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url['episode_url'] = '{}/embed/tv/{}/{}/{}'.format(self.base_link, tmdb, season, episode)
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url

###__________________________________________________________________________
###
##    def find_series_url(self, url_data, aliases):
##        Log(u"find_series_url() {}".format(repr((url_data, aliases))))
##        find_series_url = ''
##        title=''
##
##        
##        for alias in aliases:        
##
##            title = alias['title']
##            title = title.decode('ascii','ignore')
##            
##            Log(u"testing for title alias '{}'".format(title))
##            title2 = u'/tv/'+ cleantitle.getsearch(title).lower().replace(" ", "-").replace(".","")
##            Log(u"expecting a format for this site as '{}'".format(title2))
##
##            query = cleantitle.getsearch(title,include_colon=True).lower()
####            Log(repr(query))
##            query = quote_plus(query)
##            search_url = urljoin(self.base_link, self.search_link % query)
##            Log(u"search_url={}".format(repr(search_url)))
##
####            r = client.request(search_url)  #, XHR=True  #adds X-Requested-With: XMLHttpRequest
##            r = client.request(
##                search_url
##                ,post='' #we POST instead of GET to avoid cloudflare
##                ,timeout='25'
####                ,ignoreErrors="404" #cache 404 so that we don't hammer bad requests
####                ,cache_seconds=3600
##                )
##
##            search_result = client.parseDOM(r, 'div', {'id': 'results'})
##            Log(repr(search_result))
##
##            series_url = ''
##            for i in search_result:
##                if i:
##                    Log(repr(i))
##                    for href in client.parseDOM(i, 'a', ret='href' ):
##                        Log(repr(href))
##                        if title2 in href:
##                            series_url = href
##                            break
##                        
##                if series_url:
##                    break
##
##        Log(u"series_url={}".format(repr(series_url)))
##        if not series_url:
##            raise Exception(u"no series_url found for '{}'".format(title))
##        if series_url.startswith("/"): series_url = urljoin(self.base_link, series_url)
##        return series_url
##
###__________________________________________________________________________
###
##    def find_episode_url(self, series_url, title, season, episode):
##        Log(u"find_episode_url() {}".format(repr((series_url, title, season, episode))))
##        episode_url = ''
##
##        season = "/{}".format(int(season))
##        episode = "/{}".format(int(episode))
##        episode_url = series_url+season+episode
##
##        Log(u"episode_url={}".format(repr(episode_url)))
##        if not episode_url: raise Exception(u"no episode_url found for '{} s{}e{}'".format(title,season,episode))
##
##        return episode_url


#__________________________________________________________________________
#
    def decode_data(self, key, data):
##        Log('decode_data')

##        Log(repr(key))
##        Log(repr(data))

        key_bytes = b(u(key)) #python2
        data = b(u(data)) #python2

##        Log(repr(key_bytes))
##        Log(repr(data))
       
        #s = bytearray(range(256)) #python3
        s = bytearray(range(256))
        j = 0

        for i in range(256):
            j = (j + s[i] + key_bytes[i % len(key_bytes)]) & 0xff
            s[i], s[j] = s[j], s[i]

        decoded = bytearray(len(data))
        i = 0
        k = 0

        for index in range(len(data)):
            i = (i + 1) & 0xff
            k = (k + s[i]) & 0xff
            s[i], s[k] = s[k], s[i]
            t = (s[i] + s[k]) & 0xff

            if isinstance(data[index], str):
                decoded[index] = ord(data[index]) ^ s[t]
            elif isinstance(data[index], int):
                decoded[index] = data[index] ^ s[t]
            else:
                raise Exception("RC4DecodeError:Unsupported data type in the input")

##        Log(repr(decoded))
        return decoded

#__________________________________________________________________________
#
    def decode_base64_url_safe(self, s): #str) -> bytearray:
        standardized_input = s.replace('_', '/').replace('-', '+')
        binary_data = base64.b64decode(standardized_input)
        return bytearray(binary_data)

#__________________________________________________________________________
#
    def encode_id(self, v_id):
        Log('encode_id')
        r = client.request(
            self.KEY_URL
            , headers=self.headers
            )
##        Log(dir(r))
##        Log(dir(client))
        if not r: raise Exception("Failed to fetch decryption keys!")
        
        matches = re.search(r"\"rawLines\":\s*\[\"(.+)\"\]", r)
        if not matches: raise Exception("Failed to extract rawLines from keys page!")

##        Log(repr(v_id))
        key1, key2 = json.loads(matches.group(1).replace("\\", ""))
##        Log(repr((key1, key2)))
        decoded_id = self.decode_data(key1, v_id)
##        Log(repr(decoded_id))
        encoded_result = self.decode_data(key2, decoded_id)
        
        encoded_base64 = base64.b64encode(encoded_result)
        decoded_result = encoded_base64.decode("utf-8")

##        Log('return encode_id {}'.format(decoded_result))
        return decoded_result.replace("/", "_")

#__________________________________________________________________________
#
    def decrypt_source_url(self, source_url): #-> str
        encoded = self.decode_base64_url_safe(source_url)
        decoded = self.decode_data(self.DEFAULT_KEY, encoded)
        decoded_text = decoded.decode('utf-8')

        return unquote(decoded_text)
#__________________________________________________________________________
#
    def get_futoken(self, key, refering_url): #key: str, url: str, provider_url: str) -> str:
##        req = requests.get(f"{provider_url}/futoken", headers={"Referer": url})
##        Log('get_futoken')

        Log(key)

        h = self.headers.copy()
        h["Referer"] = refering_url
        r = client.request(
            "{}/futoken".format(self.PROVIDER_URL)
            , headers=h
            )

##        Log(repr(r))        
        fu_key = re.search(r"var\s+k\s*=\s*'([^']+)'", r).group(1)
##        Log(repr(fu_key))

        futoken = fu_key
        for i in range(len(key)):
            futoken = futoken + ',' + str(ord(fu_key[i % len(fu_key)]) + ord(key[i]))
        
        Log('return get_futoken {}'.format(futoken))
        return futoken         
        #return f"{fu_key},{','.join([str(ord(fu_key[i % len(fu_key)]) + ord(key[i])) for i in range(len(key))])}"


#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):

        Log(u'Sources {}'.format(repr((url, hostDict, hostprDict))))
        sources = []
##        traceback.print_stack()
        if url is None:
            return sources
 
        try:
            url_data = parse_qs(url)
            Log(u"url_data={}".format(repr(url_data)))            
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            if 'season' in url_data: season = url_data['season']
            else: season = url_data['year']
            if 'episode' in url_data: episode = url_data['episode']
            else: episode = ''
            aliases = eval(url_data['aliases'])
            if 'tvshowtitle' in url_data:
                title = url_data['tvshowtitle']
                isTVshow = True
            else:
                title = url_data['title']
                isTVshow = False
            aliases.append({'country':'fallback','title':title})

            #series_url = self.find_series_url(url_data, aliases)
            
            episode_url = url_data['episode_url'] #self.find_episode_url(series_url, title, season, episode)
##            Log(repr(episode_url))


            r = client.request(
                episode_url
                , headers=self.headers
                )
            
            sources_code = client.parseDOM(r, 'a', ret='data-id')
##            Log(repr(sources_code))
            if not sources_code:
                raise Exception('sources_code not found')
            else:
                if type(sources_code) is list:
                    sources_code = sources_code[0]
                
            sources_url = "{}/ajax/embed/episode/{}/sources".format(self.base_link, sources_code)
            r = client.request(
                sources_url
                , headers=self.headers
                )
            sources_json = json.loads(r)
            if sources_json['status'] != 200: raise Exception('sources_json not successful {}'.format(sources_url))

            embed_url = ''
            for video in sources_json.get("result"):
                if video["title"] in ('Vidplay', 'F2Cloud'):
                    embed_url = "{}/ajax/embed/source/{}".format(self.base_link, video["id"])


                    r = client.request(
                        embed_url
                        , headers=self.headers
                        )
                    embed_json = json.loads(r)
                    if embed_json['status'] != 200: raise Exception('embed_url not successful {}'.format(embed_url))

                    encrypted_source_url = embed_json["result"]["url"]
                    futoken_referer = self.decrypt_source_url(encrypted_source_url)
        ##            Log(futoken_referer)

                    url_data = futoken_referer.split("?")
                    #Log(repr(url_data))
                    key = self.encode_id(url_data[0].split("/e/")[-1])
                    #Log(repr(key))
                
                    futoken = self.get_futoken(key, futoken_referer)
        ##            Log(repr(futoken))

                    fu_url = "{}/mediainfo/{}?{}&autostart=true".format(self.PROVIDER_URL, futoken, url_data[1])
        ##            Log(fu_url)
                
                    r = client.request(
                        fu_url
                        , referer=futoken_referer
                        )

                    try:
                        for res in json.loads(r)['result']:
                            for s in res["sources"]:
                                url = s["file"]
                                sources.append(
                                                {
                                                'source': video["title"]
                                                , 'quality': 'SD'
                                                , 'info': ''
                                                , 'language': 'en'
                                                , 'url': url
                                                , 'direct': True
                                                , 'debridonly': False
                                                }
                                                )
                    except:
                        traceback.print_exc()
                        
                

                if video["title"] == 'Filemoon':
                    embed_url = "{}/ajax/embed/source/{}".format(self.base_link, video["id"])

                    r = client.request(
                        embed_url
                        , headers=self.headers
                        )
                    embed_json = json.loads(r)
                    if embed_json['status'] != 200: raise Exception('embed_url not successful {}'.format(embed_url))

                    encrypted_source_url = embed_json["result"]["url"]
                    futoken_referer = self.decrypt_source_url(encrypted_source_url)
                    Log(futoken_referer)

                    sources.append(
                                    {
                                    'source': video["title"]
                                    , 'quality': 'SD'
                                    , 'info': ''
                                    , 'language': 'en'
                                    , 'url': futoken_referer
                                    , 'direct': False
                                    , 'debridonly': False
                                    }
                                    )
                        

##            Log(repr(embed_url))
            if not embed_url: raise Exception('embed_url not found')

            


        except:
            traceback.print_exc()

        Log(repr(sources))
        return sources
    
##        req = requests.get(
##            f"{VidSrcExtractor.BASE_URL}/ajax/embed/episode/{data_id}/sources"
##            ,headers={'user-agent': VidSrcExtractor.USER_AGENT}
##            ,proxies={'https':'127.0.0.1:1025', 'http':'127.0.0.1:1025'}
##            ,verify=False
##            )
##        if req.status_code != 200:
##            error_msg = f"Couldnt fetch {req.url}, status code: {req.status_code}..."
##            raise VidSrcError(error_msg)
##        
##        data = req.json()
##        return {video.get("title"): video.get("id") for video in data.get("result")}
    
##            return
##
##
##            links = client.parseDOM(sources_html, 'button', ret='value')
##            Log(repr(links))
##
##            for url in links:
##                valid, host = source_utils.is_host_valid(url, hostDict)
##                if not valid:
##                    Log("invalid host ='{}'".format(repr(host)))
##                    Log("invalid url ='{}'".format(repr(url)))
##                else:
##                    if 'https://filemoon' in url: #hack for this provider
##                        url = url + '$$' + self.base_link
##                    sources.append(
##                                    {
##                                    'source': host
##                                    , 'quality': 'SD'
##                                    , 'info': ''
##                                    , 'language': 'en'
##                                    , 'url': url
##                                    , 'direct': False
##                                    , 'debridonly': False
##                                    }
##                                   )
##
##        except:
##            traceback.print_exc()

        Log(repr(sources))
        return sources
    

        
##            r = client.request(season_url)
##            data = client.parseDOM(r, 'ul', {'class': r'listing items lists'})
##            episode_url = None
##            for i in data:
####                Log("i='{}'".format(repr(i)))
##                if i:
##                    for href in client.parseDOM(i, 'a', ret='href' ):
##                        Log("href='{}'".format(repr((title2,href,hdlr2,hdlr3))))
##                        Log(repr((title2 in href)))
##                        Log(repr(((hdlr2 +'-' in href))))
##                        Log(repr(href.endswith(hdlr2)))
##                        
##                        #if (title2 in href) and (hdlr2 in href):
##                        if (title2 in href) and ((hdlr3+'-' in href) or (hdlr2+'-' in href) or href.endswith(hdlr2)):
##                            Log("href='{}'".format(repr(href)))
##                            episode_url = href
##                            break
##                    if episode_url: break
##            Log("episode_url='{}'".format(repr(episode_url)))
##            if not episode_url:
##                raise Exception(u"no episode url found for '{}-{}'".format(title, season))
##            if episode_url.startswith("/"): episode_url = urljoin(self.base_link, episode_url)
##            Log(u"episode_url={}".format(repr(episode_url)))
##
##
##            # now we have an acutal episode url
##            #   the url contains another link to the sources
##            r = client.request(episode_url)
##            if r.startswith("404"): #call actually failed, but source does not use normal status code
##                #sometimes the site will ned append -tba to the URL...
##                r = client.request(episode_url+"-tba")
##                if r.startswith("404"):
##                    raise Exception(u"Episode not found {}".format(repr(episode_url)))
####            Log("r='{}'".format(repr(r)))
##            
##            #the sources are inside this page
##            data = client.parseDOM(r, 'iframe', ret='src')
####            Log("data='{}'".format(repr(data)))
##            if data:
##                sources_url = data[0]
##            else:
##                sources_url = ""
####                Log("episode_url='{}'".format(repr(episode_url)))
####                Log("data='{}'".format(repr(data)))
####                Log("r='{}'".format(repr(r)))
##                pass
##            if sources_url.startswith("//"): sources_url = "https:" + sources_url
##
##            sources_html = client.request(sources_url, referer=episode_url)
####            Log("sources_html='{}'".format(repr(sources_html)))
##
##            links = client.parseDOM(sources_html, 'li', {'data-status': '1'}, ret='data-video')
####            Log("links='{}'".format(repr(links)))
##
##            for url in links:
##                
##                valid, host = source_utils.is_host_valid(url, hostDict)
##                if not valid:
##                    Log("invalid host ='{}'".format(repr(host)))
##                    Log("invalid url ='{}'".format(repr(url)))
##                    try:
####                        if host in ("vidnext.net"):
####                            if url.startswith("/"):
####                                url = urljoin(self.base_link, url)
####                            Log("url={}".format(repr(url)))
####                            r = client.request(url, referer=episode_url)
####                            alt_url = re.compile(r"sources:.+?file: '([^']+?)'", re.DOTALL | re.IGNORECASE).findall(r)
####                            if alt_url:
####                                alt_url=alt_url[0]
######                                Log("alt_url='{}'".format(repr(alt_url)))
####                            hostDict.append(host)
####                            valid, host = source_utils.is_host_valid(alt_url, hostDict)
######                            hostDict.remove(host)
####                            
####                            if valid:
####                                url = alt_url
####                            else:
####                                Log("still not valid{}".format(repr(alt_url)))
##
##                        if host in self.domains:
##                            if url.startswith("/"):
##                                url = urljoin(self.base_link, url)
##                            Log("url={}".format(repr(url)))
##                            r = client.request(url, referer=episode_url)
##                            alt_url = re.compile(r"sources:.+?file: '([^']+?)'", re.DOTALL | re.IGNORECASE).findall(r)
##                            if alt_url:
##                                alt_url=alt_url[0]
##                            Log("alt_url='{}'".format(repr(alt_url)))
##
##                            hostDict.append(host)
##                            Log(repr(host))
##                            valid, new_host = source_utils.is_host_valid(alt_url, hostDict)
##                            Log(repr(hostDict))
##                            Log(repr((valid, new_host)))
##
####                            try:  hostDict.remove(host)
####                            except: pass
##
##                            if valid:
##                                url = alt_url
##                            else:
##                                Log("still not valid{}".format(repr(alt_url)))
##                                
##                    except:
##                        traceback.print_exc()
##                    if not valid:
##                        continue  #skip this url; only return file hosters we understand
##
##                Log("Valid host ='{}'".format(repr(host)))
##                Log("Valid url ='{}'".format(repr(url)))
##                sources.append(
##                                {
##                                'source': host
##                                , 'quality': 'SD'
##                                , 'info': ''
##                                , 'language': 'en'
##                                , 'url': url
##                                , 'direct': False
##                                , 'debridonly': False
##                                }
##                               )
##
##        except:
##            traceback.print_exc()
##
####        Log(repr(sources))
##        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        url = "{}|{}".format( url, urlencode(self.headers)  )
        Log("{} resolved url='{}'".format(self.domains[0], repr(url)))
        return url
#__________________________________________________________________________
#
