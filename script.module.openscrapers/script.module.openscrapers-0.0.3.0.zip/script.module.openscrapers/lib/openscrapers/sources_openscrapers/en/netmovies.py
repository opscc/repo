# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import base64
import json
import os
import re
import traceback
import xbmc
from openscrapers.modules.log_utils import log  as Log
from openscrapers.modules.log_utils import logR as LogR

from openscrapers.modules import control as C

try: from urlparse import parse_qs, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import dom_parser
from openscrapers.modules import source_utils

#__________________________________________________________________________
#
def RandomNumber(return_integer=True,length=18):
    import random
    nc_string = str(random.random())
    if return_integer:
        nc_string = nc_string.split('.')[1]
    while len(nc_string) < length:
        nc_string += str(random.randint(10,99))
    if len(nc_string) > length:
        nc_string = nc_string[0:length]
    return nc_string
#__________________________________________________________________________
#


class source:
    def __init__(self):
        self.provder_name = 'netmovies'
        self.priority = 31
        self.language = ['en']
        self.domains = ['netmovies.to']
        self.base_link = 'https://web.netmovies.to' #2024-06
        self.movies_template = '/%s/' #2024-06
        self.movies_template_2 = '/moviess/free-watch-%s/'        
        self.tvshow_template = ['/%s-2/'
                                ,'/%s/' ] #2025-02
        self.episode_template = '%s/' #2024-06      
        self.title_delete_chars = "'.:?,"
        self.title_delete_doublewidechars = "-&"
        self.title_replace_chars_1 = "&"
        self.title_replace_subst_1 = "and"
        self.title_replace_chars_2= " "
        self.title_replace_subst_2= "-"
        self.title_replace_doublewidechars = "--"
        self.title_replace_doublewidesubst = "-"
##        self.title_replace_chars = " "
##        self.title_replace_subst = "-"
        
        self.MAX_LINKS = 4 #make sure we don't overwhem host
#__________________________________________________________________________
#
    def movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, title, localtitle, aliases, year))))
##        return {}
        movie_url = None
        movie_info = {}

        try:
            year_list = ['',year] #sometimes including year helps, but start without it 
            for year in year_list:
                year2 = ''

                aliases.insert(0, {'country':'','title':localtitle})

                for alias in aliases:
                    if year not in alias['title']:
                        if year:
                            year2 = '-'+str(year)
                            Log('trying with an appended year')
                    else:
                        year2 = ''

                    alias = alias['title'].lower()

                    for c in self.title_replace_chars_1: #perform replace before delete
                        alias = alias.replace(c,self.title_replace_subst_1)
                    for c in self.title_replace_chars_2: #perform replace before delete
                        alias = alias.replace(c,self.title_replace_subst_2)
                    if C.PY2:
                        for c in range(len(self.title_replace_doublewidechars) /2):
                            alias = alias.replace( self.title_replace_doublewidechars[c*2:2]  , self.title_replace_doublewidesubst)
                    else:
                        for c in range(len(self.title_replace_doublewidechars) //2):
                            alias = alias.replace( self.title_replace_doublewidechars[c*2:2]  , self.title_replace_doublewidesubst)

                    if C.PY2:
                        for c in range(len(self.title_delete_doublewidechars) /2):
                            alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')
                    else:
                        for c in range(len(self.title_delete_doublewidechars) //2):
                            alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')

                    for c in self.title_delete_chars:
                        alias = alias.replace(c,'')
                    alias = alias + year2

                    probe_url = urljoin(self.base_link, self.movies_template % (alias))
                    Log(probe_url)
                    r = None
                    r = client.request(probe_url)
                    probe_url = probe_url[0:-1] #this site works best with trailing slash, but later on, without it
                    probe_url_2 = urljoin(self.base_link, (self.movies_template_2 % (alias)) ) [0:-1]
                    if r and ((probe_url in r) or (probe_url_2 in r)): #confirm not a false positive [trim the last backslash]
##                        Log("found movie_url '{}'".format(probe_url), level=xbmc.LOGWARNING)
                        movie_url = probe_url
                    if movie_url: break
                if movie_url: break
            pass
        except ValueError:
            pass 
        except:
            traceback.print_exc()

        if not movie_url: return None

        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
        movie_info['url'] = movie_url
        movie_info = urlencode(movie_info)
        
        Log(u"movie url is {}".format(repr(movie_url)))
        Log(u"movie_info is {}".format(repr(movie_info)))
        return movie_info
    
#__________________________________________________________________________
#
    def tvshow(self, imdb,  tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        '''
            The imdb+this.provder_name will be used to find the first part of a tv show url
            Episode information will be appended to this url
            Use this to resolve any alias variance, once per tvshow, as this information will be cached
        '''
        Log(u'tvshow {}'.format(repr((imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))))
##        traceback.print_stack()
        tvshow_url = None

#https://netmovies.to/tvseries/the-wheel-of-time/

        try:
            year_list = ['',year] #sometimes including year helps, but start without it 
            for year in year_list:
                year2 = ''

                aliases.insert(0, {'country':'','title':tvshowtitle})
                aliases.insert(0, {'country':'','title':localtvshowtitle})

                for alias in aliases:
                    if year not in alias['title']:
                        if year:
                            year2 = '-'+str(year)
                            Log('trying with an appended year')
                    else:
                        year2 = ''

                    alias = alias['title'].lower()
                    for c in self.title_replace_chars_1: #perform replace before delete
                        alias = alias.replace(c,self.title_replace_subst_1)
                    for c in self.title_replace_chars_2: #perform replace before delete
                        alias = alias.replace(c,self.title_replace_subst_2)
                        
                    if C.PY2:
                        for c in range(len(self.title_replace_doublewidechars) /2):
                            alias = alias.replace( self.title_replace_doublewidechars[c*2:2]  , self.title_replace_doublewidesubst)
                    else:
                        for c in range(len(self.title_replace_doublewidechars) //2):
                            alias = alias.replace( self.title_replace_doublewidechars[c*2:2]  , self.title_replace_doublewidesubst)

                    if C.PY2:
                        for c in range(len(self.title_delete_doublewidechars) /2):
                            alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')
                    else:
                        for c in range(len(self.title_delete_doublewidechars) //2):
                            alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')

                    for c in self.title_delete_chars:
                        alias = alias.replace(c,'')
                    alias = alias + year2

                    for templ in  self.tvshow_template:
                        probe_url = urljoin(self.base_link, templ % (alias))
                        r = None
                        r = client.request(probe_url, ignoreErrors={404})
                        probe_url = probe_url[0:-1] #this site works best with trailing slash, but later on, without it
                        if r and (probe_url in r): #confirm not a false positive [trim the last backslash]
                            tvshow_url = probe_url
                        if tvshow_url: break
                    if tvshow_url: break
                if tvshow_url: break
            pass
        except ValueError:
            pass 
        except:
            traceback.print_exc()
        Log(u"tvshow url is {}".format(repr(tvshow_url)))
        return tvshow_url
#__________________________________________________________________________
#
    def episode(self, url, imdb,  tmdb, tvdb, title, premiered, season, episode):
        Log(u'episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        '''
            url should be the proper starting point for this provider+tvshow;
            we just need to adjust some information to get episode specific informaiton 
        '''
        
        episode_url = {}
        try:
            if not url: raise ValueError
            
            #probe_url = self.episode_template % (url, season, episode)
            probe_url = self.episode_template % (url)

##            r = client.request(probe_url) #validate this exists
##            if not r: raise Exception(u"improper response for episode url {}".format(repr(probe_url)))

            episode_url['url'] = probe_url
            episode_url['title']  = title
            episode_url['premiered'] = premiered
            episode_url['season'] = season
            episode_url['episode'] = episode

        except ValueError:
            pass        
        except:
            traceback.print_exc()

        episode_url = urlencode(episode_url)
        Log(u"episode url is {}".format(repr(episode_url)))
##        raise Exception()
        return episode_url
#__________________________________________________________________________
#
    def sources(self, url_data, hostDict, hostprDict):
        Log(u'sources {}'.format(repr((url_data,))))#, hostDict, hostprDict))))        
        sources = []
##        return sources
##        traceback.print_stack()
        try:
            if not url_data: raise ValueError 
                
            hostDict =  hostDict + hostprDict

            url_data = parse_qs(url_data)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            if not 'url'in url_data: raise ValueError 
            url = url_data['url']
            is_episode = ('episode' in url_data)
            if is_episode:
                season = url_data['season']
                episode = url_data['episode']
            else:
                season = episode = 0
            
            r = client.request(url)
            
##            LogR(r)
            if is_episode:
                links = client.parseDOM(r, 'script', {'id':'episodes-js-after'}, 'src')
                LogR(links)
                try:
                    links = links[0][len('data:text/javascript;base64,'):]
                    links = base64.b64decode(links)
                except:
                    links = client.parseDOM(r, 'script', {'id':'episodes-js-after'})[0]
                links = links[len('var links ='):]
                links = links.replace('\\/', '/').replace('\n','')
                links = json.loads(links[:-1]) #remove trailing semicolon
                links = links['s{}_{}'.format(season, episode)]['data'][0]
                LogR(links)
            else:
                manual_servers = client.parseDOM(r, 'ul', {'class':'servers'})
                LogR(manual_servers)
                servers = client.parseDOM(manual_servers, 'span')
                LogR(servers)
                urls = client.parseDOM(manual_servers, 'li', {'id':'manual'}, 'onclick')
                LogR(urls)
                links = {}
                link_count = 0  
                for s in servers:
                    links[link_count] = {}
                    links[link_count]['server'] = s
                    links[link_count]['url'] = re.findall(r".+?'(.+?)'", urls[link_count])[0]
                    link_count += 1
                LogR(links)


            link_count = 0            
            for link_num in links:
                LogR(link_num)
                link_count = link_count + 1
                if link_count > self.MAX_LINKS: break
                sources.append(
                            {
                            'source': links[link_num]['server']
                            , 'quality': 'SD'
                            , 'info': ''
                            , 'language': 'en'
                            , 'url': links[link_num]['url']
                            , 'direct': True
                            , 'debridonly': False
                            }
                           )
                
        except ValueError:
            pass
        except:
            source_utils.scraper_error(self.provder_name)

        Log(u"sources returning {}".format(repr(sources)))
##        raise Exception()
        return sources
#__________________________________________________________________________
#
    def resolve(self, url):

        try:
            import resolveurl #todo; get rid of this?
            video_url = resolveurl.resolve(url)
        except:
            traceback.print_exc()
        Log("scraper {} resolved url={} to {}".format(repr(self.provder_name), repr(url), repr(video_url)))
##        raise Exception()
        if video_url:
            return video_url
        else:
            Log(repr(url))
            return ''            
        return video_url
    
##        video_url = ''
##        next_url, post = re.compile('([^\|]+?)\|(.+)', re.DOTALL).findall(url)[0]
##
##        headers ={
##            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
##            ,'X-Requested-With': 'XMLHttpRequest'
##            #,'User-Agent': common.RAND_UA 
##            ,'Referer': 'https://netmovies.to/'
##            ,'Accept-Encoding': 'gzip, deflate'
##            ,'Accept-Language': 'en-US,en;q=0.9'
##            }
##        Log(repr(str(post)))
##        r = client.request(
##            url=next_url+'?rnd='+str(RandomNumber())
##            , post=str(post)
##            , headers=headers
##            )
##        r = json.loads(r)
##        next_url = r['embed_url']
##
##        try:
##            import resolveurl #todo; get rid of this?
##            video_url = resolveurl.resolve(next_url)
##        except:
##            traceback.print_exc()
##        Log("scraper {} resolved url={} to {}".format(repr(self.provder_name), repr(url), repr(video_url)))
##        raise Exception()
##        if video_url:
##            return video_url
##        else:
##
##            return ''
#__________________________________________________________________________
#

