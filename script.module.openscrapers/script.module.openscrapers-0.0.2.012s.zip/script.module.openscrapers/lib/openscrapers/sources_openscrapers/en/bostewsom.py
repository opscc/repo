# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import os
import re
import traceback
import urllib
from openscrapers.modules.log_utils import log  as Log
    

try: from urlparse import parse_qs, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.provider_name = 'bostewsom'
        self.priority = 23
        self.language = ['en']
        self.domains = ['esh-bostewsom-i-273.site']
        self.base_link = 'https://esh-bostewsom-i-273.site'
        self.search_link = '/play/%s' #'player-json-api.php?id=%s'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/118.0'
                        ,'Referer': self.base_link
                        }
#__________________________________________________________________________
#
    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        #return not-none if this provider can find movies
        Log(u'movie {}'.format(repr((imdb, tmdb, localtitle, aliases, year))))
        if not imdb: return None
        url = None
	try:
            url = {'imdb': imdb
                   , 'tmdb': tmdb
                   , 'title': title
                   , 'aliases': aliases
                   , 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
#__________________________________________________________________________
#
    #return not-none if this provider can find tv shows
    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        Log(u'TVshow {}'.format(repr((imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))))
        url = None
##        return None
        try:
            url = {'imdb': imdb
                   , 'tvdb': tvdb
                   , 'tmdb': tmdb
                   , 'tvshowtitle': tvshowtitle
                   , 'localtvshowtitle': localtvshowtitle
                   , 'aliases': aliases
                   , 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url            
#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
##        return None
        #return url-encoded url pointing to a specific episode
        Log(u'Episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        if url is None: return None
        try:
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url

#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):
##        traceback.print_stack()
##        Log(u'Sources {}'.format(repr((url, hostDict, hostprDict))))
        sources = []

        if url is None: return sources
        try:
            url_data = parse_qs(url)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))
    
            imdb_id = url_data['imdb']
            tmdb = url_data['tmdb']
            if 'season' in url_data: season = url_data['season']
            else: season = url_data['year']
            if 'episode' in url_data: episode = url_data['episode']
            else:  episode = ''

##            https://esh-bostewsom-i-273.site/play/tt6166392# name=Wonka
##            https://esh-bostewsom-i-273.site/play/tt10168312 # What if???
            vid_url = self.base_link + (self.search_link % imdb_id)
            intermediate_links = client.request(
                vid_url
                , post='' 
                , headers=self.headers
                )
            
            regex = (
                '{"file":"(.+?)",'
                '.+?,"key":"(.+?)",'
                )
            intermediate_links = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(intermediate_links)

            for temp_url, temp_key in intermediate_links:
                temp_headers = self.headers.copy()
                temp_headers["X-CSRF-TOKEN"] = temp_key
                temp_headers["Referer"] = vid_url
                
                temp_url = self.base_link + temp_url.replace('\\/', '/')

                intermediate_data = client.request(
                    temp_url
                    , post='' #we POST instead of GET to avoid cloudflare - will time-out a lot
                    , headers=temp_headers
                    )                

            if intermediate_data.startswith('[{'):
               intermediate_json = json.loads(intermediate_data)
            else:
                pass


            play_headers = temp_headers.copy()
            play_headers.pop("X-CSRF-TOKEN")

            for item in intermediate_json:

                if 'file' in item:  # applies to movies
                    self._addsource(item, temp_headers, play_headers, sources)
                    
                else:  #a list of series
                    for series_item in item:
                        if (series_item == 'id') and season == item['id']:
                            for folder in item['folder']:
                                if episode == folder['episode']:
                                    Log(repr(folder))
                                    for s in folder['folder']:
                                        if s: #sometimes it is empty
                                            self._addsource(s, temp_headers, play_headers, sources)


                    
                        

        except:
            traceback.print_exc()

        Log(repr(sources))
##        return None
        return sources

#__________________________________________________________________________
#
    def _addsource(self, item, temp_headers, play_headers, sources):
        temp_url = self.base_link + '/playlist/' + item['file'][1:]+'.txt'
        playable_url = client.request(
            temp_url
            , post=''
            , headers=temp_headers
            )
        playable_url = playable_url + "|{}".format( urllib.urlencode(play_headers)  )

        quality = 'SD' #can't predict this without following url, which i don't want to do at this point
            
        lang = item['title']
        
        sources.append(
                        {
                        'source': self.provider_name
                        , 'quality': quality
                        , 'info': '' #str(rez)
                        #, 'info': str(rez)
                        , 'language': lang
                        , 'url': playable_url
                        , 'direct': True
                        , 'debridonly': False
                        }
                       )

#__________________________________________________________________________
#
    def resolve(self, url):
        Log("{} found {}".format(self.provider_name, repr(url)))
        video_url = url
        
##        video_url = None
##        import resolveurl
##        try:
##            video_url = resolveurl.resolve(url)
##        except:
##            traceback.print_exc()
##
##        Log("{} resolved url={} to {}".format(self.provder_name, repr(url), repr(video_url)))

        return video_url
                    
#__________________________________________________________________________
#
