# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import os
import re
import time
import threading
import traceback

from openscrapers.modules.log_utils import log  as Log

try: from urlparse import parse_qs, urljoin, urlsplit, urlparse
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit, urlparse
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus


from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import dom_parser
from openscrapers.modules import source_utils

from openscrapers.modules import workers

class source:
    
    def __init__(self):
        self.provder_name = 'watchseries.cyou'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0'
                        ,'Referer': 'https://watchseries.cyou/'
                        ,'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
                        }
        
        self.priority = 31
        self.language = ['en']
        self.domains = ['watchseries.cyou']
        self.base_link = 'https://watchseries.cyou'
        self.search_link = '/search/%s/'
        self.tvshow_template = '/tv-series/%s/'
        self.movie_template = '/movies/%s/'
        self.episode_template = '%s-season-%s-episode-%s/'
        self.title_delete_chars = ":()"
        self.title_delete_doublewidechars = "-&"
        self.title_replace_chars = " "
        self.title_replace_subst = "-"
        
#__________________________________________________________________________
#
##    def terminate_signaled();
##        if threading.current_thread().stop_is_set:
##            Log('terminate_signaled')
##            sys.exit()
        
#__________________________________________________________________________
#
    #disabled due to cloudflare 2024-09
    def _movie(self, imdb, tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, title, localtitle, aliases, year))))

        movie_url = {}
        try:
            year_list = [year,''] #sometimes including year helps, start with it 
            aliases.insert(0, {'country':''
                               ,'title':localtitle}
                           ) #also make sure localtitle is part of alias list
            for year in year_list:
                year2 = ''
                for alias in aliases:
                    if year not in alias['title']:
                        if year: 
                            year2 = '-'+str(year) #Log('trying with an appended year')
                    else:
                        year2 = ''
                    alias = cleantitle.getsearch(alias['title']).lower().replace(" ", "-").replace(".", "").replace(",", "").replace("&", "").replace("--", "-")+year2
                    probe_url = urljoin(self.base_link, self.movie_template % (alias))
                    Log(repr(probe_url))
                    r = None
                    r = client.request(
                        probe_url
                        ,post='' #we POST instead of GET to avoid cloudflare
                        ,timeout='25'
                        ,ignoreErrors="404" #cache 404 so that we don't hammer bad requests
                        ,cache_seconds=3600
                        )
                    ##probe_url = probe_url[0:-1] #this site works best with trailing slash, but later on, without it
                    if r and (probe_url in r): #confirm not a false positive [trim the last backslash]
##                        Log("Warning: found movie_url '{}'".format(probe_url))
##                        movie_url = probe_url
                        movie_url['url'] = probe_url
                        movie_url['imdb'] = imdb
                        movie_url['tmdb'] = tmdb
                        movie_url['title']  = title
                        movie_url['localtitle'] = localtitle
                        movie_url['year'] = year
                    else:
                        if r:
                            Log(repr((probe_url,r,)))
                            Log(repr((probe_url in r)))
                            pass
                        
                    if movie_url: break
                if movie_url: break
            pass
        except ValueError:
            pass 
        except:
            traceback.print_exc()
        if not movie_url:
            return None
        movie_url = urlencode(movie_url)
        Log(u"movie url is {}".format(repr(movie_url)))
##        raise Exception()
        return movie_url
    

#__________________________________________________________________________
#
#disabled due to cloudflare 2024-09
    def _tvshow(self, imdb,  tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        '''
            The imdb+this.provder_name will be used to find the first part of a tv show url
            Episode information will be appended to this url
            Use this to resolve any alias variance, once per tvshow, as this information will be cached
        '''
        Log(u'tvshow {}'.format(repr((imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year))))
##        traceback.print_stack()
        tvshow_url = None
        try:
            year_list = ['',year] #sometimes including year helps, but start without it 
            aliases.insert(0, {'country':'','title':tvshowtitle})
            aliases.insert(0, {'country':'','title':localtvshowtitle})
            for year in year_list:
                year2 = ''
                for alias in aliases:
                    if year not in alias['title']:
                        if year:
                            year2 = '-'+str(year)
                            Log('trying with an appended year')
                    else:
                        year2 = ''

                    alias = alias['title'].lower()
                    for c in self.title_delete_chars:
                        alias = alias.replace(c,'')
                    for c in self.title_replace_chars: #replace before delete?
                        alias = alias.replace(c,self.title_replace_subst)
                    alias = alias + year2
                    
                    #alias = alias['title'].replace(" ", "-").replace(":", "").lower()+year2
                    probe_url = urljoin(self.base_link, self.tvshow_template % (alias))
                    r = None
                    r = client.request(
                        probe_url
                        #,post='' #we POST instead of GET to avoid cloudflare
                        ,timeout='30'
                        )
                    probe_url = probe_url[0:-1] #this site works best with trailing slash, but later on, without it
                    if r and (probe_url in r): #confirm not a false positive [trim the last backslash]
##                        Log("Warning: found tvshow_url '{}'".format(probe_url))
                        tvshow_url = probe_url
                    if tvshow_url: break
                if tvshow_url: break
            pass
        except ValueError:
            pass 
        except:
            traceback.print_exc()
        Log(u"tvshow url is {}".format(repr(tvshow_url)))
        return tvshow_url
#__________________________________________________________________________
#
#disabled due to cloudflare 2024-09
    def _episode(self, url, imdb,  tmdb, tvdb, title, premiered, season, episode):
        Log(u'episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
##        traceback.print_stack()

        '''
            url should be the proper starting point for this provider+tvshow;
            we just need to adjust some information to get episode specific informaiton 
        '''
        
        episode_url = {}
        try:
            if not url: raise ValueError
            
            probe_url = self.episode_template % (url, season, episode)
##            r = client.request(probe_url) #validate this exists
##            if not r: raise Exception(u"improper response for episode url {}".format(repr(probe_url)))

            episode_url['url'] = probe_url
            episode_url['title']  = title
            episode_url['premiered'] = premiered
            episode_url['season'] = season
            episode_url['episode'] = episode

        except ValueError:
            pass        
        except:
            traceback.print_exc()

        episode_url = urlencode(episode_url)
        Log(u"episode url is {}".format(repr(episode_url)))
        return episode_url
#__________________________________________________________________________
#
    def sources(self, url_data, hostDict, hostprDict):
        Log(u'sources {}'.format(repr((url_data,))))#, hostDict, hostprDict))))        
        self.sources = []

        try:

            if not url_data: raise ValueError 
                
            hostDict =  hostDict + hostprDict

            url_data = parse_qs(url_data)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            url = url_data['url']
            r = client.request(
                url
                #,post='' #we POST instead of GET to avoid cloudflare
                ,timeout='90'
                )

##            Log(repr(r))
##            links = client.parseDOM(r, 'ul', {'id':'videolinks'})
##            Log(repr(links))
##            links = client.parseDOM(links, 'li', {'class':'nav-item'})
##            Log(repr(links))


##            links = client.parseDOM(r, 'tr', {'class':'ext_link'})
            regex = (
                  '<tr class="ext_link(.*)'
                )
##            Log(repr(regex))
            links = re.compile(regex, re.DOTALL).findall(r)[0]
##            Log(repr(links))

            
##            links = client.parseDOM(r, 'td', {'class':'linkdom w3-center'})
            Log(repr(links))
            links = client.parseDOM(links, 'a', {'class':'linkdomx button-links'}, 'href')
            Log(repr(links))

            dev_only = False
            if dev_only:            
                self.get_sources(links[1], hostDict)  #single link for development
            else:
                #outside of dev, do this
                MAX_LINKS = 7#make sure we don't overwhem host
                link_count = 0

                threads = []
                append = threads.append

                #for suburl,resolution in links:
                for suburl in links:
                    link_count = link_count + 1
                    if link_count > MAX_LINKS: break
                    append(workers.Thread(self.get_sources, suburl, hostDict))
                [i.start() for i in threads]
                
                alive = [x for x in threads if x.is_alive() is True]
                thread_time = 0.0
                max_thread_time = 600
                while alive and (thread_time < max_thread_time):
                    alive = [x for x in threads if x.is_alive() is True]
                    time.sleep(0.1)
                    thread_time += 0.1

        except SystemExit:
            pass
        except:
            traceback.print_exc()
            source_utils.scraper_error(self.provder_name)

        Log(u"sources returning {}".format(repr(self.sources)))
##        raise Exception()
        return self.sources
#__________________________________________________________________________
#
    def resolve(self, url):
        Log(repr((url,)))
        video_url = ''
        try:
            import resolveurl #todo; get rid of this?
            video_url = resolveurl.resolve(url)
        except:
            traceback.print_exc()
        Log("scraper {} resolved url={} to {}".format(repr(self.provder_name), repr(url), repr(video_url)))
        if video_url:
            return video_url
        else:
            return ''
#__________________________________________________________________________
#

    def get_sources(self, url, hostDict):
        Log('get_sources')
        Log(repr((url,)))
        try:

##            item = client.parseDOM(url, 'a', ret='href')[0]
##            hoster_name = item.split('/')[4]
##            vid_id = str(item.split('/')[3])
##            vid_url = self.base_link + '/open/site/06'+vid_id+'/'+vid_id+'/'   #where does the 06 come from, 03 has also worked, any padding to 10 chars?
            vid_url = self.base_link + url
            vid_url = vid_url.replace('/link/','/site/')
            Log(repr(vid_url))

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0"
                ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
                ,"Accept-Encoding":"gzip"
                ,"Referer":self.base_link
                }
            hoster_url = client.request(
                vid_url
                , output = 'geturl'
                #, post='' #we POST instead of GET to avoid cloudflare - will time-out a lot
                , headers=self.headers
                , timeout='30'
                )
            if not hoster_url: hoster_url = vid_url

            hoster_name = urlparse(vid_url).netloc.split("//")[-1].split("/")[0]
            Log(repr((vid_url, hoster_name, hoster_url)))

            if hoster_name in ['voe','voe.sx']:
                valid, hoster = (True,'voe')
            else:
                valid, hoster = source_utils.is_host_valid(hoster_url, hostDict)
##            Log(repr((valid,hoster)))
            if valid:
                pass
            else:
                Log(u"skipping {}".format((hoster_url,vid_url)))
                return

 
            link = hoster_url + Header2pipestring(headers)
            
            self.sources.append(
                            {
                            'source': hoster
                            , 'quality': 'SD'
                            , 'info': ''
                            , 'language': 'en'
                            , 'url': link
                            , 'direct': True
                            , 'debridonly': False
                            }
                           )

        except:
            traceback.print_exc()
            source_utils.scraper_error(self.provder_name)           

#__________________________________________________________________________
#
def Header2pipestring(header):
    q = "|{}".format( urlencode(header)  )
    return q
#__________________________________________________________________________
#
