# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################


import datetime
import json
import os
import re
import traceback
import unicodedata
import xbmc

from openscrapers.modules.log_utils import log  as Log

try: from urlparse import parse_qs, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import cache
from openscrapers.modules import source_utils
from openscrapers.modules import jsunpack

#__________________________________________________________________________
#

class source:
    def __init__(self):
        self.priority = 1
        self.provider_name = 'wafflehacker'
        self.language = ['en']
        self.domains = ['wafflehacker.io']
        self.base_link = 'https://2embed.wafflehacker.io'
        self.movies_templates = ['https://flixon.click/{}']
        self.tvshow_templates = [ self.base_link+'/scrape?id={}']
                                 
#https:///scrape?id=tt15435876&s=1&e=1
        self.episode_template = '{}&s={}&e={}'
        self.title_delete_chars = "'?,:"
        self.title_delete_doublewidechars = "-&"
        self.title_replace_chars = " "
        self.title_replace_subst = "-"
        self.title_replace_doublewidechars = "--"
        self.MAX_LINKS = 8 #make sure we don't overwhem host
#__________________________________________________________________________
#
##    def matchAlias(self, title, aliases):
##        try:
##            for alias in aliases:
##                if cleantitle.get(title) == cleantitle.get(alias['title']):
##                    return True
##        except:
##            return False
#__________________________________________________________________________
#
    def _movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, title, localtitle, aliases, year))))

        movie_url = None
        movie_info = {}

        try:
            for movies_template in self.movies_templates:
                movie_url = movies_template.format(imdb)
                if movie_url: break
        except:
            traceback.print_exc()

        if not movie_url: return None

        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
        movie_info['url'] = movie_url
        movie_info = urlencode(movie_info)
        
        Log(u"movie url is {}".format(repr(movie_url)))
        Log(u"movie_info is {}".format(repr(movie_info)))
        return movie_info

#__________________________________________________________________________
#
    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        '''
            Tvshow is the base location for all episodes of a tvshow
            
            The imdb+this.provder_name will be used to find the first part of a tv show url
            Episode information will be appended to this url
            Use this to resolve any alias variance, once per tvshow, as this information will be cached
        '''
        Log(u'tvshow {}'.format(repr((imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season))))
##        traceback.print_stack()
        tvshow_url = None

        try:
            for tvshow_template in  self.tvshow_templates:
                tvshow_url = tvshow_template.format(imdb)
        except:
            traceback.print_exc()
        Log(u"tvshow url is {}".format(repr(tvshow_url)))
        return tvshow_url
#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):

        Log(u'episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        '''
            url should be the proper starting point for this provider+tvshow;
            
            we just need to adjust some information to get episode specific information

            result should be a url that contains MP4 and HLS video links
        '''
        
        episode_url = {}
        try:

            if not url: raise ValueError
            
            probe_url = self.episode_template.format(url, season, episode)
            Log(probe_url)
##            r = client.request(probe_url) #validate this exists
##            if not r: raise Exception(u"improper response for episode url {}".format(repr(tvshow_url)))

            episode_url['url'] = probe_url
            episode_url['title']  = title
            episode_url['premiered'] = premiered
            episode_url['season'] = season
            episode_url['episode'] = episode

        except:
            traceback.print_exc()
##            raise

        episode_url = urlencode(episode_url)
        Log(u"episode url is {}".format(repr(episode_url)))

        return episode_url
    
#__________________________________________________________________________
#

    def sources(self, url_data, hostDict, hostprDict):
        Log(u'sources {}'.format(repr((url_data,))))#, hostDict, hostprDict))))        
        sources = []
##        traceback.print_stack()
        try:
            if not url_data: raise ValueError 
                
            hostDict =  hostDict + hostprDict

            url_data = parse_qs(url_data)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            if not 'url' in url_data: raise ValueError 
            url = url_data['url']
            is_movie = not ('season' in url_data)
            if not is_movie: episode = int(url_data['episode'])

##            Log(repr(url))
            r = client.request(url)
##            Log(repr(r))

            json_info = json.loads(r)
            #Log(repr(json_info))
            link = json_info['stream'][0]['playlist']
##            Log(repr(link))
            #raise Exception()

##            regex = (
##                  'var \w+? = \[(.+?)\];'
##                +'.+?String.fromCharCode\(parseInt\(value\) - (\d+)\)' #do some minor math with this value
##                )
####            Log(repr(regex))
##            codes = re.compile(regex, re.DOTALL).findall(r)[0]
####            Log(repr(codes))
##            vals = list(codes[0].split(','))
##            offset = int(codes[1])
####            Log(repr(offset))
####            Log(repr(vals))
##            buf = ''
##            for i in range(len(vals)):
##                buf = buf + chr(int(vals[i])-offset)
####            Log(repr(buf))
##
##            regex = (
##                  '\.attr\("href","(https.+?)"\)\.'  #source is here
##                )
####            Log(repr(regex))
##            intermediate_link = re.compile(regex, re.DOTALL).findall(buf)[0]
####            Log(repr(intermediate_link))
##
##            headers = {
##                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0"
##                ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
##                ,"Accept-Encoding":"gzip"
##                ,"Referer":'https://flixon.click/'
##                }
##            
##            r = client.request(intermediate_link
##                               ,headers=headers
##                               )
##            buf = UnJuice(r)
####            Log(repr(buf))
##                          
##            buf = jsunpack.unpack(buf)
####            Log(repr(buf))
##
##            regex = (
##                  '"file":"(https.+?)"'  #source is here
##                )
####            Log(repr(regex))
##            link = re.compile(regex, re.DOTALL).findall(buf)[0]
##            Log(repr(link))
##
##            headers = {
##                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0"
##                ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
##                ,"Accept-Encoding":"gzip"
##                ,"Referer":'https://onionflux.com/'
##                }
##            link = link + Header2pipestring(headers)

            sources.append(
                        {
                        'source': self.provider_name
                        , 'quality': 'SD'
                        , 'info': ''
                        , 'language': 'en'
                        , 'url': link
                        , 'direct': True
                        , 'debridonly': False
                        }
                       )
            
        except:
            traceback.print_exc()
            source_utils.scraper_error(self.provider_name)
            
        Log(u"sources returning {}".format(repr(sources)))
##        raise Exception()
        return sources

####            regex_tabs = (
####                'class="tab'                 #distinguish between tablist and tabs
####                +'.+?id="stream-{}(?:-tab|)"'.format(episode-1) #sometimes will be hiding after this
####                +'.+?<iframe width.+?src="(.+?)"'     #with this being the actual urls
####                )
####            Log(repr(regex_tabs))
####
####            regex_no_tabs = (
####                '<iframe width.+?src="(.+?)"'     #with this being the actual urls
####                )
####            Log(repr(regex_no_tabs))
##
##            links = None
##
##            #sometimes there are entire seasons, one episode per tab
##            if not ('episode-{}/'.format(episode) in url):
##                Log('tabs_search match')
##                links = re.compile(regex_tabs, re.DOTALL).findall(r)
##            #sometimes one episode with multiple sources per tab
##            if not links:
##                Log('attempting no_tabs search')
##                links = re.compile(regex_no_tabs, re.DOTALL).findall(r)
##
##            try:
##                Log(repr(links))
##
##                link_count = 0
##                
##                for link in links:
##                    Log(repr((link)))
##                    link_count = link_count + 1
##                    if link_count > self.MAX_LINKS: break
##
##                    valid, hoster = source_utils.is_host_valid(link, hostDict)
##                    Log(repr((valid,hoster)))
##                    if valid:
##                        
##                        sources.append(
##                                    {
##                                    'source': hoster
##                                    , 'quality': 'SD'
##                                    , 'info': ''
##                                    , 'language': 'en'
##                                    , 'url': link
##                                    , 'direct': True
##                                    , 'debridonly': False
##                                    }
##                                   )
##                
##            except:
##                traceback.print_exc()
##            
####        except ValueError:
####            pass
##        except:
##            traceback.print_exc()
##            source_utils.scraper_error(self.provider_name)
##
##        Log(u"sources returning {}".format(repr(sources)))
####        raise Exception()
##        return sources
##            
##########    def sources(self, url, hostDict, hostprDict):
##########        sources = []
############        Log("sources url='{}'".format(url))
########        try:
########
########            if url == None: return sources
########
########            data = urlparse.parse_qs(url)
########            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
########            aliases = eval(data['aliases'])
########            Log(repr(aliases))
########            headers = {
########                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
########                ,"Accept": "*/*"
########                ,"Accept-Encoding":"gzip"
########                }
########
########            if 'tvshowtitle' in data:
########                ep = data['episode']
########
########
########
########                for alias in aliases:
########                    url = '%sfilm/%s-season-%01d/watching.html?ep=%s' % (self.base_link
########                                                                         , cleantitle.geturl(alias['title'])
########                                                                         , int(data['season'])
########                                                                         , ep)
########                    r = client.request(url, headers=headers, timeout='10', output='geturl')
########                    if r is None:
########                        url = '%sfilm/%s/watching.html?ep=%s' % (self.base_link
########                                                                             , cleantitle.geturl(alias['title'])
########                                                                             , ep)
########                        r = client.request(url, headers=headers, timeout='10', output='geturl')
########                        
########                    if r: break
########
########                    
########                if url == None:
########                    url = self.searchShow(data['tvshowtitle'], data['season'], aliases, headers)
########
########
########            else:
########                url = self.searchMovie(data['title'], data['year'], aliases, headers)
########
########            if url == None: raise Exception()
########
########            r = client.request(url, headers=headers, timeout='10')
########            r = client.parseDOM(r, 'div', attrs={'class': 'les-content'})
########            if 'tvshowtitle' in data:
########                ep = data['episode']
########                links = client.parseDOM(r, 'a', attrs={'episode-data': ep}, ret='player-data')
########            else:
########                links = client.parseDOM(r, 'a', ret='player-data')
########
########            for link in links:
########                Log(repr(link))
########                if '123movieshd' in link or 'seriesonline' in link  or 'vidembed.me' in link:
########                #if False:
########                    r = client.request(link, headers=headers, timeout='10')
########                    r = re.findall('(https:.*?redirector.*?)[\'\"]', r)
########
########
########                    for i in r:
########                        try:
########                            sources.append(
########                                {'source': 'gvideo'
########                                 , 'quality': directstream.googletag(i)[0]['quality']
########                                 , 'language': 'en'
########                                 , 'url': i
########                                 , 'direct': True
########                                 , 'debridonly': False}
########                                )
########                        except: pass
########                        
########                else:
########                    try:
########                        host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(link.strip().lower()).netloc)[0]
########                        if not host in hostDict:
########                            raise Exception("provider '{}' is not supported".format(host))
########                        host = client.replaceHTMLCodes(host)
########                        host = host.encode('utf-8')
########
########                        Log(repr(link))
########                        if not link.startswith("http"):
########                            link = "https:" + link
########                            Log(repr(link))
########                            
########
########                        sources.append(
########                            {'source': host
########                             , 'quality': 'SD'
########                             , 'language': 'en'
########                             , 'url': link
########                             , 'direct': False
########                             , 'debridonly': False}
########                            )
########                    except:
########                        pass
########
########        except:
########            traceback.print_exc()
########
##########        return None
########        Log("sources sources='{}'".format(repr(sources)))
########        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        return url
##        try:
##            video_url = ''
##            if not url.startswith("http"):
##                url = "https:" + url
##
##
##            try:
##                import resolveurl #todo; get rid of this?
##                video_url = resolveurl.resolve(url)
##            except:
##                traceback.print_exc()
##            Log("scraper {} resolved url={} to {}".format(repr(self.provider_name), repr(url), repr(video_url)))
##    ##        raise Exception()
##            if video_url:
##                return video_url
##            else:
##                Log(repr(url))
##                return ''
##        except:
##            traceback.print_exc()
##            
####        if "google" in url:
####            return directstream.googlepass(url)
####        else:
####            return url

#__________________________________________________________________________
#
def Header2pipestring(header):
    q = "|{}".format( urlencode(header)  )
    return q
#__________________________________________________________________________
#
def UnJuice(e):
    Juice = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
    try:
        e = re.findall(r'JuicyCodes.Run\(([^\)]+)', e, re.IGNORECASE)[0]
        e = re.sub(r'\"\s*\+\s*\"', '', e)
        e = re.sub(r'[^A-Za-z0-9+\\/=]', '', e)
    except BaseException:
        raise
        return None
    t = ""
    n = r = i = s = o = u = a = f = 0
    while f < len(e):
        s = Juice.index(e[f])
        f += 1
        o = Juice.index(e[f])
        f += 1
        u = Juice.index(e[f])
        f += 1
        a = Juice.index(e[f])
        f += 1
        n = s << 2 | o >> 4
        r = (15 & o) << 4 | u >> 2
        i = (3 & u) << 6 | a
        t += chr(n)
        if 64 != u:
            t += chr(r)
        if 64 != a:
            t += chr(i)
    return t
#__________________________________________________________________________
#
