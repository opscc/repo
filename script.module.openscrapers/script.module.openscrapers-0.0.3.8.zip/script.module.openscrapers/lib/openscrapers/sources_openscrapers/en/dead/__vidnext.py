# -*- coding: utf-8 -*-

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import os
import re
import traceback
from openscrapers.modules.log_utils import log  as Log
    

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 32
        self.language = ['en']
        self.domains = ['movstreamhd.pro','membed.net', 'vidnext.net', "vidembed.net", "vidembed.cc", "vidembed.io", "vidembed.me"]
        #self.base_link = 'https://vidembed.io/'
        self.base_link = 'https://membed.net/'
        self.base_link = 'https://movstreamhd.pro/'
        
        self.search_link = 'search.html?keyword=%s'
#https://vidnext.net/?keyword_search=wandavision
#https://vidnext.net/search.html?keyword=wandavision
#https://vidnext.net/videos/marvels-wandavision-season-1-episode-8
#https://membed.net/videos/star-trek-lower-decks-season-3-episode-2

#__________________________________________________________________________
#
    def movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        url = None
	try:
            url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
#__________________________________________________________________________
#
    def tvshow(self, imdb,  tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        url = None
##        Log(repr(aliases))
        try:
            url = {'imdb': imdb
                   , 'tvdb': tvdb
                   , 'tvshowtitle': tvshowtitle
                   , 'localtvshowtitle': localtvshowtitle
                   , 'aliases': aliases
                   , 'year': year}
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url            
#__________________________________________________________________________
#
    def episode(self, url, imdb,  tmdb, tvdb, title, premiered, season, episode):
##        raise Exception()
        if url is None:
            return None
        try:
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url
#__________________________________________________________________________
#
    def sources(self, url, hostDict, hostprDict):
        sources = []
        if url is None: return sources

##        traceback.print_stack()
 
        try:
##            Log(u"url={}".format(repr(url)))
##            Log(u"hostDict={}".format(repr(hostDict)))
##            Log(u"hostprDict={}".format(repr(hostprDict)))

            url_data = parse_qs(url)
            Log(u"url_data={}".format(repr(url_data)))            
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            aliases = eval(url_data['aliases'])
##            Log(repr(aliases))
            if 'tvshowtitle' in url_data:
                title = url_data['tvshowtitle']
                isTVshow = True
            else:
                title = url_data['title']
                isTVshow = False
            aliases.append({'country':'fallback','title':title})
            

            season_url = None
            for alias in aliases:        
##                if 'tvshowtitle' in data:
##                    title = data['tvshowtitle']
##                elif 'title' in data:
##                    title = data['title']
##                else:
##                    raise Exception("No title found in url='{}'".format(repr(url)))
                title = alias['title']
                Log("testing for alias '{}'".format(title))
                Log("title='{}'".format(repr(title)))

                if 'season' in url_data:
                    Log('using season formatting')
                    season = int(url_data['season'])
                    title2 = "{}-season-{}".format(
                        cleantitle.getsearch(title).lower().replace(" ", "-").replace(".", "")
                        , season)
                elif 'year' in url_data:
                    Log('using year formatting')
                    season = int(url_data['year'])
                    title2 = "{}".format(cleantitle.getsearch(title).lower().replace(" ", "-").replace(",", ""), season)
                else:
                    raise Exception(u"No title2 found in url={}".format(repr(url)))
                Log(u"title2={}".format(repr(title2)))

                episode = None
                if 'episode' in url_data and 'season' in url_data:
                    episode = int(url_data['episode'])
                    hdlr = 's%02de%02d' % (season, episode)
                    hdlr2 = u"season-{}-episode-{}".format(season, episode)
                    hdlr3 = u"season-{}-episode-{:0>2}".format(season, episode)
    #https://membed.net/videos/star-trek-lower-decks-season-3-episode-2
                else: #nothing required for movies
                    hdlr = ""
                    hdlr2 = ""
                    hdlr3 = ""
                Log("hdlr='{}'".format(repr(hdlr)))
                Log("hdlr2='{}'".format(repr(hdlr2)))

    ##            query = quote_plus(cleantitle.getsearch(title, allow_asterix=True))
                query = cleantitle.getsearch(title, allow_asterix=True, allow_singlequote=True).replace(" ", '%20')
                search_url = urljoin(self.base_link, self.search_link % query)
                Log(u"search_url={}".format(repr(search_url)))
                r = client.request(search_url)  #, XHR=True  #adds X-Requested-With: XMLHttpRequest
    ##            Log("r='{}'".format(repr(r)))

                # the site's 'search' will not find what we need and the url names are random..
                # at best we can discover a link to the season we are looking for
                # then open that URL and search it for the episode we want
                search_result = client.parseDOM(r, 'ul', {'class': r'listing items'})
                Log("search_result={}".format(repr(search_result)))
                #epis = [client.parseDOM(i, 'a', ret='href' )[0] for i in data if i]
                season_url = None
                Log(u"title2={}".format(repr(title2)))
                for i in search_result:
                    if i:
                        for href in client.parseDOM(i, 'a', ret='href' ):
                            Log("href='{}', title2'{}'".format(repr(href),repr(title2)))
                            if title2 in href:
                                Log("season_url='{}'".format(repr(href)))
                                season_url = href
                                break
                if season_url: break




            Log(u"season_url={}".format(repr(season_url)))
            if not season_url:
                raise Exception(u"no season url found for '{}-{}'".format(title, season))
            if season_url.startswith("/"): season_url = urljoin(self.base_link, season_url)
            Log("season_url='{}'".format(repr(season_url)))


            r = client.request(season_url)
            data = client.parseDOM(r, 'ul', {'class': r'listing items lists'})
            episode_url = None
            for i in data:
##                Log("i='{}'".format(repr(i)))
                if i:
                    for href in client.parseDOM(i, 'a', ret='href' ):
                        Log("href='{}'".format(repr((title2,href,hdlr2,hdlr3))))
                        Log(repr((title2 in href)))
                        Log(repr(((hdlr2 +'-' in href))))
                        Log(repr(href.endswith(hdlr2)))
                        
                        #if (title2 in href) and (hdlr2 in href):
                        if (title2 in href) and ((hdlr3+'-' in href) or (hdlr2+'-' in href) or href.endswith(hdlr2)):
                            Log("href='{}'".format(repr(href)))
                            episode_url = href
                            break
                    if episode_url: break
            Log("episode_url='{}'".format(repr(episode_url)))
            if not episode_url:
                raise Exception(u"no episode url found for '{}-{}'".format(title, season))
            if episode_url.startswith("/"): episode_url = urljoin(self.base_link, episode_url)
            Log(u"episode_url={}".format(repr(episode_url)))


            # now we have an acutal episode url
            #   the url contains another link to the sources
            r = client.request(episode_url)
            if r.startswith("404"): #call actually failed, but source does not use normal status code
                #sometimes the site will ned append -tba to the URL...
                r = client.request(episode_url+"-tba")
                if r.startswith("404"):
                    raise Exception(u"Episode not found {}".format(repr(episode_url)))
##            Log("r='{}'".format(repr(r)))
            
            #the sources are inside this page
            data = client.parseDOM(r, 'iframe', ret='src')
##            Log("data='{}'".format(repr(data)))
            if data:
                sources_url = data[0]
            else:
                sources_url = ""
##                Log("episode_url='{}'".format(repr(episode_url)))
##                Log("data='{}'".format(repr(data)))
##                Log("r='{}'".format(repr(r)))
                pass
            if sources_url.startswith("//"): sources_url = "https:" + sources_url

            sources_html = client.request(sources_url, referer=episode_url)
##            Log("sources_html='{}'".format(repr(sources_html)))

            links = client.parseDOM(sources_html, 'li', {'data-status': '1'}, ret='data-video')
##            Log("links='{}'".format(repr(links)))

            for url in links:
                
                valid, host = source_utils.is_host_valid(url, hostDict)
                if not valid:
                    Log("invalid host ='{}'".format(repr(host)))
                    Log("invalid url ='{}'".format(repr(url)))
                    try:
##                        if host in ("vidnext.net"):
##                            if url.startswith("/"):
##                                url = urljoin(self.base_link, url)
##                            Log("url={}".format(repr(url)))
##                            r = client.request(url, referer=episode_url)
##                            alt_url = re.compile(r"sources:.+?file: '([^']+?)'", re.DOTALL | re.IGNORECASE).findall(r)
##                            if alt_url:
##                                alt_url=alt_url[0]
####                                Log("alt_url='{}'".format(repr(alt_url)))
##                            hostDict.append(host)
##                            valid, host = source_utils.is_host_valid(alt_url, hostDict)
####                            hostDict.remove(host)
##                            
##                            if valid:
##                                url = alt_url
##                            else:
##                                Log("still not valid{}".format(repr(alt_url)))

                        if host in self.domains:
                            if url.startswith("/"):
                                url = urljoin(self.base_link, url)
                            Log("url={}".format(repr(url)))
                            r = client.request(url, referer=episode_url)
                            alt_url = re.compile(r"sources:.+?file: '([^']+?)'", re.DOTALL | re.IGNORECASE).findall(r)
                            if alt_url:
                                alt_url=alt_url[0]
                            Log("alt_url='{}'".format(repr(alt_url)))

                            hostDict.append(host)
                            Log(repr(host))
                            valid, new_host = source_utils.is_host_valid(alt_url, hostDict)
                            Log(repr(hostDict))
                            Log(repr((valid, new_host)))

##                            try:  hostDict.remove(host)
##                            except: pass

                            if valid:
                                url = alt_url
                            else:
                                Log("still not valid{}".format(repr(alt_url)))
                                
                    except:
                        traceback.print_exc()
                    if not valid:
                        continue  #skip this url; only return file hosters we understand

                Log("Valid host ='{}'".format(repr(host)))
                Log("Valid url ='{}'".format(repr(url)))
                sources.append(
                                {
                                'source': host
                                , 'quality': 'SD'
                                , 'info': ''
                                , 'language': 'en'
                                , 'url': url
                                , 'direct': False
                                , 'debridonly': False
                                }
                               )

        except:
            pass
            traceback.print_exc()

##        Log(repr(sources))
        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        Log("vidnext resolved url='{}'".format(repr(url)))
        return url
#__________________________________________________________________________
#
