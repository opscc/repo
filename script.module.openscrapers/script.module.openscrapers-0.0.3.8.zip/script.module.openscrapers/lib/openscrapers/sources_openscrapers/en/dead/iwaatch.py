# -*- coding: utf-8 -*-
# modified by Venom for Openscrapers (4-20-2020)

#  ..#######.########.#######.##....#..######..######.########....###...########.#######.########..######.
#  .##.....#.##.....#.##......###...#.##....#.##....#.##.....#...##.##..##.....#.##......##.....#.##....##
#  .##.....#.##.....#.##......####..#.##......##......##.....#..##...##.##.....#.##......##.....#.##......
#  .##.....#.########.######..##.##.#..######.##......########.##.....#.########.######..########..######.
#  .##.....#.##.......##......##..###.......#.##......##...##..########.##.......##......##...##........##
#  .##.....#.##.......##......##...##.##....#.##....#.##....##.##.....#.##.......##......##....##.##....##
#  ..#######.##.......#######.##....#..######..######.##.....#.##.....#.##.......#######.##.....#..######.

'''
    OpenScrapers Project
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os.path
import re
import traceback
from openscrapers.modules.log_utils import log as Log
from openscrapers.modules.log_utils import log as LogR

try: from urlparse import parse_qs, urljoin
except ImportError: from urllib.parse import parse_qs, urljoin
try: from urllib import urlencode, quote, quote_plus
except ImportError: from urllib.parse import urlencode, quote, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import dom_parser as dom
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 32
        self.language = ['en']
        self.domains = ['iwaatch.com']
        self.base_link = 'https://iwaatch.com/'
        self.search_link = 'api/api.php?page=moviesearch&q={0}'


    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except BaseException:
            traceback.print_exc()
##            source_utils.scraper_error('IWAATCH')
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if not url:
                return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['title']
            year = data['year']
            t = title + year
##            Log(t)

            query = '%s' % data['title']
            query = re.sub(r'(…)', ' ...', query) #site does not handle this special char consistently
            query = re.sub(r'(\\\|/| -|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link.format(quote(query))
            url = urljoin(self.base_link, url)
##            LogR(url)
        
            r = client.request(url)
            if (not r) or 'Not Found' in r: return sources

            items = client.parseDOM(r, 'li')
            items = [(dom.parse_dom(i, 'a', req='href')[0]) for i in items if year in i]
            items = [(i.attrs['href'], re.sub('<.+?>|\n', '', i.content).strip()) for i in items]
##            for i in items:
##                ct_1 = cleantitle.get(t)
##                ct_2 = cleantitle.get(i[1])
##                LogR(ct_1) ; LogR(ct_2)
            #site will sometimes chop of chars at end....
            item = [i[0].replace('movie', 'view') for i in items if cleantitle.get(t) == cleantitle.get(i[1])]
            if type(item) is list: item = item[0]
            else:
                t = cleantitle.get(data['title'])[0:21] + year#site will sometimes chop of chars at end....
##                for i in items:
##                    ct_1 = cleantitle.get(t)
##                    ct_2 = cleantitle.get(i[1])
##                    LogR(ct_1) ; LogR(ct_2)
                item = [i[0].replace('movie', 'view') for i in items if cleantitle.get(t) == cleantitle.get(i[1])]
            if type(item) is list: item = item[0]                
##            Log(item)
            if (not item): return sources

            r = client.request(item)
            if (not r) or 'Not Found' in r:
                LogR(item)
                return sources
            streams = re.findall('src:\s*[\'"](.+?)[\'"].+?size:\s*[\'"](.+?)[\'"]', r, re.DOTALL)
##            LogR(streams)

            for link, label in streams:
                quality = ""
##                Log(label)
                quality = source_utils.get_release_quality(label)[0]
                link += '|User-Agent=%s&Referer=%s' % (quote(client.agent()), item)
##                Log(quality)
                sources.append(
                    {'source': 'direct'
                    ,'quality': quality
                    ,'info': ''
                    ,'language': 'en'
                    ,'url': link
                    ,'direct': True
                    ,'debridonly': False
                    }
                )

        except:
            traceback.print_exc()

##        LogR(sources); return []
        return sources


    def resolve(self, url):
        return url
