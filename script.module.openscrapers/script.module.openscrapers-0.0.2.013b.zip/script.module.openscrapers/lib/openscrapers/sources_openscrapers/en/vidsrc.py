# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

import base64
import datetime
import json
import os
import re
import traceback
import unicodedata
import xbmc

from openscrapers.modules.log_utils import log  as Log

try: from urlparse import parse_qs, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import cache
from openscrapers.modules import source_utils
from openscrapers.modules import jsunpack

#__________________________________________________________________________
#

class source:
    def __init__(self):
        self.priority = 1
        self.provider_name = 'vidsrc'
        self.language = ['en']
        self.domains = ['player.vidsrc.nl']
        self.base_link = 'https://player.vidsrc.nl/'
        self.movies_templates = ['https://bombthe.irish/embed/movie/{}']
        self.tvshow_templates = ['https://bombthe.irish/embed/tv/{}']
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"
            ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
            ,"Accept-Encoding":"gzip"
            ,"Accept-Language":"en-US,en;q=0.9"
            ,'Referer': self.base_link
           }
        self.episode_template = '{}/{}/{}'
        self.title_delete_chars = "'?,:"
        self.title_delete_doublewidechars = "-&"
        self.title_replace_chars = " "
        self.title_replace_subst = "-"
        self.title_replace_doublewidechars = "--"
        self.MAX_LINKS = 8 #make sure we don't overwhem host

#__________________________________________________________________________
#
    def movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, title, localtitle, aliases, year))))

        movie_url = None
        movie_info = {}

        try:
            for movies_template in self.movies_templates:
                movie_url = movies_template.format(tmdb)
                if movie_url: break
        except:
            traceback.print_exc()

        if not movie_url: return None

        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
        movie_info['url'] = movie_url
        movie_info = urlencode(movie_info)
        
        Log(u"movie url is {}".format(repr(movie_url)))
        Log(u"movie_info is {}".format(repr(movie_info)))
        return movie_info

#__________________________________________________________________________
#
    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        '''
            Tvshow is the base location for all episodes of a tvshow
            
            The imdb+this.provder_name will be used to find the first part of a tv show url
            Episode information will be appended to this url
            Use this to resolve any alias variance, once per tvshow, as this information will be cached
        '''
        Log(u'tvshow {}'.format(repr((imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season))))
##        traceback.print_stack()
        tvshow_url = None

        try:
            for tvshow_template in  self.tvshow_templates:
                tvshow_url = tvshow_template.format(tmdb)
        except:
            traceback.print_exc()
        Log(u"tvshow url is {}".format(repr(tvshow_url)))
        return tvshow_url
#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):

        Log(u'episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        '''
            url should be the proper starting point for this provider+tvshow;
            
            we just need to adjust some information to get episode specific information

            result should be a url that contains MP4 and HLS video links
        '''
        
        episode_url = {}
        try:

            if not url: raise ValueError
            
            probe_url = self.episode_template.format(url, season, episode)

##            r = client.request(probe_url) #validate this exists
##            if not r: raise Exception(u"improper response for episode url {}".format(repr(tvshow_url)))

            episode_url['url'] = probe_url
            episode_url['title']  = title
            episode_url['premiered'] = premiered
            episode_url['season'] = season
            episode_url['episode'] = episode

        except:
            traceback.print_exc()
##            raise

        episode_url = urlencode(episode_url)
        Log(u"episode url is {}".format(repr(episode_url)))

        return episode_url
    
#__________________________________________________________________________
#

    def sources(self, url_data, hostDict, hostprDict):
        Log(u'sources {}'.format(repr((url_data,))))#, hostDict, hostprDict))))        
        sources = []
##        traceback.print_stack()
        try:
            if not url_data: raise ValueError 
                
            hostDict =  hostDict + hostprDict

            url_data = parse_qs(url_data)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            if not 'url' in url_data: raise ValueError 
            url = url_data['url']
            is_movie = not ('season' in url_data)
            if not is_movie: episode = int(url_data['episode'])

##            Log(repr(url))
            r = client.request(url, headers=self.headers)
##            Log(repr(r))

            regex = (
                  'data-url="(?P<url>.+?)"'
                  '>(?P<name>.+?)<'
                )
##            Log(repr(regex))
            codes = re.compile(regex, re.DOTALL).findall(r)
            Log(repr(codes))

            for url, provider_name in codes:
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0"
                    ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
                    ,"Accept-Encoding":"gzip, deflate"
                    ,"Referer": "https://onionflux.com/"
                    ,"Priority":'u=0, i'
                    ,"Origin": "https://onionflux.com"
                    }
                url = url.split('url=')[1]
                url = base64.b64decode(url)
                #url = url + Header2pipestring(headers)
                
                sources.append(
                            {
                            'source': provider_name
                            , 'quality': 'SD'
                            , 'info': ''
                            , 'language': 'en'
                            , 'url': url
                            , 'direct': True
                            , 'debridonly': False
                            }
                           )
            
        except:
            traceback.print_exc()
            source_utils.scraper_error(self.provider_name)
            
        Log(u"sources returning {}".format(repr(sources)))
##        raise Exception()
        return sources

#__________________________________________________________________________
#
    def resolve(self, url):
        try:
            video_url = ''
            if not url.startswith("http"):
                url = "https:" + url
            try:
                import resolveurl #todo; get rid of this?
                video_url = resolveurl.resolve(url)
            except:
                traceback.print_exc()
            Log("scraper {} resolved url={} to {}".format(repr(self.provider_name), repr(url), repr(video_url)))
    ##        raise Exception()
            if video_url:
                return video_url
            else:
                Log(repr(url))
                return ''
        except:
            traceback.print_exc()

#__________________________________________________________________________
#
def Header2pipestring(header):
    q = "|{}".format( urlencode(header)  )
    return q
