# -*- coding: UTF-8 -*-
# modified by Venom for Fenomscrapers (updated 05-30-2022)
'''
Fenomscrapers Project
'''
import re
import time
##from urllib.parse import urljoin, quote_plus
import traceback
from openscrapers.modules.log_utils import log  as Log

try:
    from urlparse import parse_qs, urljoin
except ImportError:
    from urllib.parse import parse_qs, urljoin
try:
    from urllib import urlencode, quote_plus
except ImportError:
    from urllib.parse import urlencode, quote_plus


from openscrapers.modules import cfscrape
from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import dom_parser  # switch to client.parseDOM() to rid import
from openscrapers.modules import source_utils
from openscrapers.modules import workers


class source:
    priority = 24
    pack_capable = False
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.language = ['en']
        # self.base_link = "http://rmz.cr" # ssl cert fails
        self.provder_name = 'rapidmoviez'
        self.base_link = 'http://rapidmoviez.me/'
##        self.search_link = "/search/%s"
        self.search_link = "{}/{}"
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:100.0) Gecko/20100101 Firefox/118.0'}
        self.scraper = cfscrape.create_scraper()
        self.MAX_LINKS = 4 #make sure we don't overwhem host
#__________________________________________________________________________
#
    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        return None #site not working
        url = None
        try:
            url = {'imdb': imdb
                   , 'tmdb': tmdb
                   , 'title': title
                   , 'localtitle': title
                   , 'aliases': aliases
                   , 'year': year
                   }
            url = urlencode(url)
        except:
            traceback.print_exc()
        return url
#__________________________________________________________________________
#
    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        url = None
        return None #site not working
        ##        Log(repr(aliases))
        try:
            url = {'imdb': imdb
                   , 'tmdb': tmdb
                   , 'tvdb': tvdb
                   , 'tvshowtitle': tvshowtitle
                   , 'localtvshowtitle': localtvshowtitle
                   , 'aliases': aliases
                   , 'year': year
                   }
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url 
#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
##        raise Exception()
        return None #site not working
        if url is None: 
            return None

        try:
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
        except:
            traceback.print_exc()
        Log(repr(url))
        return url
#__________________________________________________________________________
#
    def search(self, title, year, season_episode_string, movie_or_series):
##        Log('search  2023-04-06    uses a capcha ')
##        Log(repr(season_episode_string))
        search_result = []
        try:
            url = urljoin(self.base_link, self.search_link.format(quote_plus(title).replace('+','-').lower(), movie_or_series))
##            Log(url)
            # http://rmz.cr throws "ssl.SSLCertVerificationError: [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1128)"
##            r = self.scraper.get(url, headers=self.headers, timeout=10).text
            r = client.request(url, headers=self.headers, timeout=10)
            if not r:
                raise Exception('url request failed')

            if movie_or_series == 's':
                r = client.parseDOM(r, 'ul', {'id':'episodes'})
                links = client.parseDOM(r, 'li')
                regex = (
                        '>(\d+?)p<'
                        '.+?href="(.+?)"'
                        )
                links = re.compile(regex, re.DOTALL).findall(" ".join(links))
                i=0
                for rez, link in links:
                    Log(repr((rez, link)))
                    if (season_episode_string in link.lower()):
                        search_result.append(  (urljoin(self.base_link, link),rez)  )
                        i = i + 1
                    if i>5: break

            
            elif movie_or_series == 'm':

                r = client.parseDOM(r, 'ul', {'id':'releases'})
                links = client.parseDOM(r, 'li')
                regex = (
                        #'>(\d+?)p<'
                        '()'
                        '.+?href="(.+?)"'
                        )
                links = re.compile(regex, re.DOTALL).findall(" ".join(links))
                i=0
                title = unicode(title.replace(' ', '-').lower())
                for rez, link in links:
                    Log(repr((rez, link)))
                    Log(repr((title+'_'+str(year)+'-')))
                    if (  (title+'-'+str(year)+'-') in link.lower()):
                        search_result.append(  (urljoin(self.base_link, link),rez)  )
                        i = i + 1

                    if i>5: break

##                    search_result.append( urljoin(self.base_link, link)  )
##                    break                
##                break
##            all_links = [( client.parseDOM(i, 'a', 'href')) for i in r]
####            Log(repr(all_links))
##            for i in all_links:
##                Log(repr(i))
##                if season_episode_string in i:
##                    search_result = i
##                    break

##            
##            r = dom_parser.parse_dom(r, 'div', {'class': 'list_items'})[0] # switch to client.parseDOM() to rid import
##            r = dom_parser.parse_dom(r.content, 'li')
##            r = [(dom_parser.parse_dom(i, 'a', {'class': 'title'})) for i in r]
##            r = [(i[0].attrs['href'], i[0].content) for i in r]
##            r = [(urljoin(self.base_link, i[0])) for i in r if cleantitle.get(title) in cleantitle.get(i[1]) and year in i[1]]
##            if r:
##                search_result = r[0]

        except:
            # source_utils.scraper_error('RAPIDMOVIEZ')
            traceback.print_exc()
##        Log(repr(search_result))
        return search_result
#__________________________________________________________________________
#
    def sources(self, data, hostDict, hostprDict):
        Log('sources')
        self.sources = []
        if not data: return self.sources
        self.sources_append = self.sources.append
        try:
            
##            Log(repr(data))
            data = parse_qs(data)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            Log("parse_qs data='{}'".format(repr(data)))


            if 'tvshowtitle' in data:
                self.hostDict = hostDict
            else:
                self.hostDict = data['title']

            if not('tvshowtitle' in data):
                self.title = data['title']
            
##            self.title = self.title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ')
            self.aliases = data['aliases']

##            data['season'] = 3
##            data['episode'] = 3
##            Log(repr(data))

##			self.episode_title = data['title'] if 'tvshowtitle' in data else None
            if 'tvshowtitle' in data:
                self.episode_title = data['tvshowtitle']
                movie_or_series = 's'
            else:
                self.episode_title = None
                movie_or_series = 'm'
            
            self.year = data['year']
            if 'tvshowtitle' in data:
                self.hdlr = '-s%02de%02d-' % (int(data['season']), int(data['episode']))
            else:
                self.hdlr = self.year
            imdb = data['imdb']

            links = self.search(self.title, self.year, self.hdlr, movie_or_series)
            # log_utils.log('url = %s' % url, __name__)
            if not links:
                raise Exception("title not found for year {}".format(repr(self.year)))
##                return self.sources
            Log(repr(links))

            threads = []
            append = threads.append
            for suburl,rez in links:
                append(workers.Thread(self.get_sources, rez,suburl,hostDict))
            [i.start() for i in threads]
            alive = [x for x in threads if x.is_alive() is True]
            thread_time = 0.0
            max_thread_time = 600
            while alive and (thread_time < max_thread_time):
                alive = [x for x in threads if x.is_alive() is True]
                time.sleep(0.1)
                thread_time += 0.1
            
##            link_count = 0
##            for suburl,rez in links:
##                  
##                Log(repr((suburl,rez)))
##
##                link_count = link_count + 1
##                if link_count > self.MAX_LINKS: break
##
##                hoster_url = (
##                    "https://netmovies.to/wp-admin/admin-ajax.php|"
##                    "action={}&post={}&nume={}&type={}"
##                    ).format('doo_player_ajax',post,nume,dtype)
##                Log(repr(hoster_url))
##                sources.append(
##                            {
##                            'source': self.provder_name
##                            , 'quality': 'SD'
##                            , 'info': ''
##                            , 'language': 'en'
##                            , 'url': hoster_url
##                            , 'direct': False
##                            , 'debridonly': False
##                            }
##                           )

                
##{u'http://rapidmoviez.me/release/last-week-tonight-with-john-oliver-s10e10-1080p-web-h264-cakes': u'1080', u'http://rapidmoviez.me/release/last-week-tonight-with-john-oliver-s10e10-480p-web-x264-rmteam': u'480', u'http://rapidmoviez.me/release/last-week-tonight-with-john-oliver-s10e10-720p-web-h264-cakes': u'720', u'http://rapidmoviez.me/release/last-week-tonight-with-john-oliver-s10e10-april-30-2023-1080p-hmax-webrip-dd2-0-x264-ntb': u'1080', u'http://rapidmoviez.me/release/last-week-tonight-with-john-oliver-2023-s10e10-april-30-480p-webrip-x264-rmteam': u'480', u'http://rapidmoviez.me/release/last-week-tonight-with-john-oliver-s10e10-april-30-2023-720p-hmax-webrip-dd2-0-x264-ntb': u'720', u'http://rapidmoviez.me/release/last-week-tonight-with-john-oliver-s10e10-720p-hevc-x265-megusta': u'720', u'http://rapidmoviez.me/release/last-week-tonight-with-john-oliver-s10e10-1080p-hevc-x265-megusta': u'1080'}

##
##
##            result = self.scraper.get(url, headers=self.headers, timeout=10).text
##            if not result: return self.sources
##            r_pack = None
##            if 'tvshowtitle' in data:
##                r = dom_parser.parse_dom(result, 'ul', {'id': 'episodes'})
##                    # r_pack = dom_parser.parse_dom(result, 'ul', {'id': 'packs'}) # Rapidmoviez has pack files, needs more work
##            else:
##                r = dom_parser.parse_dom(result, 'ul', {'id': 'releases'})
##
##            if not r and not r_pack: return self.sources
##            if r:
##                r = dom_parser.parse_dom(r[0].content, 'a', req=['href'])
##                r = [(i.content, urljoin(self.base_link, i.attrs['href'])) for i in r if i and i.content != 'Watch']
##                r = [(i[0], i[1]) for i in r if self.hdlr in i[0].upper()]

            # if r_pack:
                    # r_pack = dom_parser.parse_dom(r_pack[0].content, 'a', req=['href'])
                    # r_pack = [(i.content, urljoin(self.base_link, i.attrs['href'])) for i in r_pack if i and i.content != 'Watch']
                    # r += [(i[0], i[1]) for i in r_pack if 'S%02d' % int(data['season']) in i[0].upper()]
                    # r += [(i[0], i[1]) for i in r_pack if 'SEASON %02d' % int(data['season']) in i[0].upper()]
            # log_utils.log('r = %s' % r)
##
##            self.undesirables = source_utils.get_undesirables()
##            self.check_foreign_audio = source_utils.check_foreign_audio()
##            threads = []
##            append = threads.append
##            for i in r:
##                append(workers.Thread(self.get_sources, i[0], i[1]))
##            [i.start() for i in threads]
##            alive = [x for x in threads if x.is_alive() is True]
##            while alive:
##                alive = [x for x in threads if x.is_alive() is True]
##                time.sleep(0.1)


        except:
            traceback.print_exc()
            source_utils.scraper_error('RAPIDMOVIEZ')
        Log(repr(self.sources))
        return self.sources
#__________________________________________________________________________
#

    def get_sources(self, rez, url,hostDict):
##        Log('get_sources')
        Log(repr((rez,url)))
        try:

            r = client.request(
                url=url
##            url=next_url+'?rnd='+str(RandomNumber())
##            , post=str(post)
##            , headers=headers
            )

##            Log(repr(r))

            regex = (
                    '<h4 class="links">(.+?):<'
                    '.+?>(http.+?)<'
                    )
##            regex = regex.format(season_episode_string)
##            Log(repr(regex))
            links = re.compile(regex, re.DOTALL).findall(r)
            i=0
            for hoster, hoster_url in links:

                valid, hoster = source_utils.is_host_valid(hoster_url, hostDict)
##                Log(repr((valid,hoster)))
                if valid:
                    if str(rez) == '1080':
                        rez = 'FHD'
                    elif str(rez) == '720':
                        rez = 'FHD'
                    else: 
                        rez = 'SD'
                        
                    self.sources.append(
                                {
                                'source': hoster #self.provder_name
                                , 'quality': str(rez)
                                , 'info': ''
                                , 'language': 'en'
                                , 'url': hoster_url
                                , 'direct': False
                                , 'debridonly': False
                                }
                               )
                            
        except:
            traceback.print_exc()
            source_utils.scraper_error('RAPIDMOVIEZ')           

##        source_utils.scraper_error('RAPIDMOVIEZ')

    def get_sourcesX(self, name, url):
        Log('get_sources')
        try:
            r = self.scraper.get(url, headers=self.headers, timeout=10).text
            name = client.replaceHTMLCodes(name)
            if name.startswith('['): name = name.split(']')[1]
            name = name.strip().replace(' ', '.')
            name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
            if source_utils.remove_lang(name_info, self.check_foreign_audio): return
            if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): return

            l = dom_parser.parse_dom(r, 'pre', {'class': 'links'})
            if l == []: return
            s = ''
            for i in l: s += i.content
            urls = re.findall(r'''((?:http|ftp|https)://[\w_-]+(?:(?:\.[\w_-]+)+)[\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])''', i.content, flags=re.M | re.S)

            for link in urls:
                url = client.replaceHTMLCodes(str(link))
                if url in str(self.sources): continue

                valid, host = source_utils.is_host_valid(url, self.hostDict)
                if not valid: continue

                quality, info = source_utils.get_release_quality(name, url)
                try:
                    size = re.search(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|Gb|MB|MiB|Mb))', name).group(0)
                    dsize, isize = source_utils._size(size)
                    info.insert(0, isize)
                except:
                    dsize = 0
                info = ' | '.join(info)

                self.sources_append({'provider': 'rapidmoviez', 'source': host, 'name': name, 'name_info': name_info, 'quality': quality, 'language': 'en', 'url': url,
                                                                                                'info': info, 'direct': False, 'debridonly': True, 'size': dsize})
        except:
            traceback.print_exc()
            source_utils.scraper_error('RAPIDMOVIEZ')
#__________________________________________________________________________
#
    def resolve(self, url):
        
##        
##        next_url,post = re.compile('([^\|]+?)\|(.+)', re.DOTALL).findall(url)[0]
##
##        headers ={
##            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
##            ,'X-Requested-With': 'XMLHttpRequest'
##            #,'User-Agent': common.RAND_UA 
##            ,'Referer': 'https://netmovies.to/'
##            ,'Accept-Encoding': 'gzip, deflate'
##            ,'Accept-Language': 'en-US,en;q=0.9'
##            }
##        Log(repr(str(post)))
##        r = client.request(
##            url=next_url+'?rnd='+str(RandomNumber())
##            , post=str(post)
##            , headers=headers
##            )
##        r = json.loads(r)
##        next_url = r['embed_url']

        video_url = ''
        try:
            import resolveurl #todo; get rid of this?
            video_url = resolveurl.resolve(url)
        except:
            traceback.print_exc()
        Log("scraper {} resolved url={} to {}".format(repr(self.provder_name), repr(url), repr(video_url)))
##        raise Exception()
        if video_url:
            return video_url
        else:
            Log(repr(url))
            return ''
        
#__________________________________________________________________________
#

