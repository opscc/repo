# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 07-23-2019 by JewBMX in Scrubs.
# Has shows but is shitty and limited.


import re
import requests
import traceback
from openscrapers.modules.log_utils import log as Log

from openscrapers.modules import cleantitle
from openscrapers.modules import source_utils


class source:
    def __init__(self):
        self.priority = 31
        self.language = ['en']
        self.domains = ['zmovies.me']
        self.base_link = 'https://zmovies.me'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0', 'Referer': self.base_link}
        self.session = requests.Session()

#__________________________________________________________________________
#
    def movie(self, imdb, title, localtitle, aliases, year):
        url = None

        try:
            mtitle = cleantitle.geturl(title)
            url = self.base_link + '/watch-%s-%s-online-free-putlocker/' % (mtitle, year)
        except:
            traceback.print_exc()

        return url
#__________________________________________________________________________
#

    def sources(self, url, hostDict, hostprDict):
        sources = []

        #site does not exist 2021-03-03
        if url is None: return sources

        try:
            Log("url='{}'".format(repr(url)))

            hostDict = hostDict + hostprDict
            r = self.session.get(url, headers=self.headers).content
            match = re.compile('<IFRAME.+?SRC="(.+?)"', flags=re.DOTALL | re.IGNORECASE).findall(r)
            for url in match:
                url =  "https:" + url if not url.startswith('http') else url
                valid, host = source_utils.is_host_valid(url, hostDict)
                if valid:
                    quality, info = source_utils.get_release_quality(url, url)
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'info': info, 'url': url, 'direct': False, 'debridonly': False})
        except:
            traceback.print_exc()

        return sources
#__________________________________________________________________________
#
    def resolve(self, url):
        #url points to playable item - no extra steps required
        return url
#__________________________________________________________________________
#
