# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - Muad'Dib
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Placenta
# Addon id: plugin.video.placenta
# Addon Provider: Mr.Blamo

import datetime, time
import json
import os
import re
import traceback
import unicodedata
import xbmc

from openscrapers.modules import control as C
from openscrapers.modules.log_utils import Log,LogR

try: from urlparse import parse_qs, urljoin, urlsplit
except ImportError: from urllib.parse import parse_qs, urljoin, urlsplit
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

from openscrapers.modules import cleantitle
from openscrapers.modules import client
from openscrapers.modules import cache
from openscrapers.modules import source_utils

#__________________________________________________________________________
#

class source:
    def __init__(self):
        self.priority = 1
        self.provder_name = 'tvseries_in'
        self.language = ['en']
        self.domains = ['www.tvseries.in']
        self.base_link = 'https://www.tvseries.in/'
##        self.search_link = '/movie/search/%s'


        self.user_agent = 'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:126.0) Gecko/20100101 Firefox/126.0'
        self.headers = {
            "User-Agent": self.user_agent
            ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            ,"Accept-Encoding":"gzip, deflate"
            ,'Referer': self.base_link
            }


        self.movies_templates = ['/film/%s/watching.html']
##https://www.tvseries.in/subfolder-A%20Man%20on%20the%20Inside.htm
# CASE Sensitive        
        self.tvshow_templates = [
            '/subfolder-{}.htm'
            ,'/subfolder-{} {year}.htm'
##            ,'/watch-series/free-{}-online/'
##            ,'/watch-series/{}-online/'
##            ,'/watch-series/2-free-online-{}/'
##            ,'/watch-series/free-online-{}/'
##            ,'/watch-series/online-{}/'
            ]
        #  {:02}    need zero padding for this month
        #  (?:/|-)  usually a trailing slash is needed, but sometimes multiple episodes will packed with a dash
        self.episode_templates = [
            '{}{}/{:02}/{}-season-{}-episode-{}/'
            ,'{}{}/{:02}/{}-season-{}-episode-{}-{}/'
            ,'{}{}/{:02}/{}-season-{}/'
            ]
        self.title_delete_chars = "'?,:()"
        self.title_delete_doublewidechars = "-"
        self.title_replace_chars_1 = "&"
        self.title_replace_subst_1 = "and"
        self.title_replace_chars_2= " "
        self.title_replace_subst_2= "%20" #"-"
        self.title_replace_doublewidechars = "--"
        self.title_replace_doublewidesubst = "%20" #"-"
        self.MAX_LINKS = 8 #make sure we don't overwhem host


#__________________________________________________________________________
#
    def tvshow(self, imdb,  tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season):
        '''
            Tvshow is the base location for all episodes of a tvshow
            
            The imdb+this.provder_name will be used to find the first part of a tv show url
            Episode information will be appended to this url
            Use this to resolve any alias variance, once per tvshow, as this information will be cached
        '''

        Log(__name__); LogR(locals())
##        traceback.print_stack()
        tvshow_url = None

        try:

            year_list = ['',year] #sometimes including year helps, but start without it 
            for year in year_list:
                year2 = ''

                aliases.insert(0, {'country':'','title':tvshowtitle})
                aliases.insert(0, {'country':'','title':localtvshowtitle})
##                LogR(aliases)

                for alias in aliases:
                    if year not in alias['title']:
                        if year:
                            year2 = '-' + str(year)
                            Log('trying with an appended year '+str(year2))
                    else:
                        year2 = ''

                    alias = alias['title'] #.lower() #2025-12 site is case sensitive
                    for c in self.title_replace_chars_1: #perform replace before delete
                        alias = alias.replace(c,self.title_replace_subst_1)
                    for c in self.title_replace_chars_2: #perform replace before delete
                        alias = alias.replace(c,self.title_replace_subst_2)

                    if C.PY2:
                        for c in range(len(self.title_replace_doublewidechars) /2):
                            alias = alias.replace( self.title_replace_doublewidechars[c*2:2]  , self.title_replace_doublewidesubst)
                    else:
                        for c in range(len(self.title_replace_doublewidechars) //2):
                            alias = alias.replace( self.title_replace_doublewidechars[c*2:2]  , self.title_replace_doublewidesubst)

                    if C.PY2:
                        for c in range(len(self.title_delete_doublewidechars) /2):
                            alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')
                    else:
                        for c in range(len(self.title_delete_doublewidechars) //2):
                            alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')

                    for c in self.title_delete_chars:
                        alias = alias.replace(c,'')

                    if C.PY2: alias = alias.decode('utf8')
                    alias = unicodedata.normalize('NFKD', alias)
                    if C.PY2: alias = alias.encode('ascii','ignore')
##                    Log(alias)
##                    return alias
##                    raise ValueError()
                    
                    for tvshow_template in self.tvshow_templates:
                        if '{year}' in tvshow_template:
                            tvshow_template = tvshow_template.replace('{year}', year)
                            probe_url = urljoin(
                                self.base_link
                                , tvshow_template.format(alias, season)
                                )
                        else:
                            probe_url = urljoin(
                                self.base_link
                                , tvshow_template.format(alias, season)
                                )
                            
                        LogR(probe_url)
##                        raise ValueError() #testing
                        r = client.request(
                            probe_url
##                            , ignoreErrors={404}
                            , headers=self.headers
                            )
##                        probe_url = probe_url[0:-1] #this site works best with trailing slash, but later on, without it
##                        LogR((not r))
##                        LogR((probe_url in r))
##                        LogR(probe_url)
                        if r : #and (probe_url in r): #confirm not a false positive [trim the last backslash]
    ##                    Log(u"tvshow ALIAS is {}".format(repr(alias)))
                            if alias in r:
                                tvshow_url = probe_url
                        if tvshow_url: break
                    if tvshow_url: break
                if tvshow_url: break
            pass
##        except ValueError:
##            Log('ValueError')
##            pass 
        except:
            traceback.print_exc()
        Log(u"tvshow url is {}".format(repr(tvshow_url)))
        return tvshow_url

##        if not movie_url: return None
##
##        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
##        movie_info['url'] = movie_url
##        movie_info = urlencode(movie_info)
##        
##        Log(u"movie url is {}".format(repr(movie_url)))
##        Log(u"movie_info is {}".format(repr(movie_info)))
##        return movie_info

#__________________________________________________________________________
#
    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
##        Log("episode"); LogR(locals())
        Log(u'episode {}'.format(repr((url, imdb, tvdb, title, premiered, season, episode))))
        '''
            url should be the proper starting point for this provider+tvshow;
            
            we just need to adjust some information to get episode specific information

            result should be a url that contains MP4 and HLS video links
        '''
##        raise ValueError()
        episode_url = {}
        try:
##            LogR(url,C.LOGWARNING)
            r = client.request(url,headers=self.headers)
##            LogR(r)
            r = client.parseDOM(r, 'div', attrs={'itemtype': 'http://schema.org/TVSeason'})
##            LogR(r)
            r = client.parseDOM(r, 'div', attrs={'class': 'mainbox2'})
            LogR(r)
            s = client.parseDOM(r, name='span', attrs={'itemprop': 'name'})
            LogR(s)
            h = client.parseDOM(r, name='a', attrs={'itemprop': 'url'}, ret='href')
            LogR(h)
            for i in range(len(s)):
                if s[i].endswith(' '+str(season)):
                    episode_url = urljoin(
                            self.base_link
                            , h[i]
                            )
                    break
                    
                    


##
##            #if not url: raise ValueError
##            #url will be None for this site because I need to use information in premierd field to calculate it
##
##            for episode_template in self.episode_templates:
##                Log(episode_template)
##                
##                
##                try: p_d = datetime.datetime.strptime(premiered, '%Y-%m-%d')
##                except TypeError: p_d = datetime.datetime(*(time.strptime(premiered, '%Y-%m-%d')[0:6]))
##                premiered_year = p_d.year
##                premiered_month = p_d.month
##                try:
##                    probe_url = episode_template.format(self.base_link
##                                                        , premiered_year
##                                                        , premiered_month
##                                                        , url
##                                                        , season
##                                                        , episode)
##                except:
##                    probe_url = episode_template.format(self.base_link
##                                                        , premiered_year
##                                                        , premiered_month
##                                                        , url
##                                                        , season
##                                                        , int(episode)-1
##                                                        , episode
##                                                        )
##                    
##                LogR(probe_url,level=C.LOGWARNING)
##                r = client.request(probe_url,output='geturl',headers=self.headers)
##
##                #try again because site occasionally groups epsodes that are release on same day
##                # combined with redirects, the logic below can find grouped itesms
##                episode_range = 0
##                episode_range_list = [-1,-1]
##                try:
##                    if r:
##                        episode_range  = r.split('episode-')[1].strip('/')
##                        episode_range_list = [int(x) for x in episode_range.split('-')]
##                        LogR((r[:r.rindex('-')+len('-')] in r))
##                        #site will sometimes redirect to an old episode if new episode not yet posted
##                        LogR((probe_url,r))
##                        LogR((int(episode) in range(episode_range_list[0],episode_range_list[1])))
##                        LogR(episode_range_list)
##                except:
##                    pass
##                if r and \
##                   ( (  probe_url in r)    
##                     or                 
##                     (                  
##                         (probe_url[:probe_url.rindex('-')+len('-')] in r) 
##                         and            
##                         (int(episode) in range(episode_range_list[0],episode_range_list[1]))
##                     )
##                   ):
##                    Log('r and (probe_url in r)')
##                    LogR(r)
##                    episode_url = r
##                if episode_url: break
##
##
##
##                #try again with a earlier month because site is screwy
##                try:
##                    probe_url = episode_template.format(self.base_link
##                                                        , premiered_year
##                                                        , premiered_month-1
##                                                        , url
##                                                        , season
##                                                        , episode)
##                except:
##                    #try again because site occasionally groups epsodes that are release on same day
##                    probe_url = episode_template.format(self.base_link
##                                                        , premiered_year
##                                                        , premiered_month-1
##                                                        , url
##                                                        , season
##                                                        , int(episode)-1
##                                                        , episode
##                                                        )
##                LogR(probe_url)
##                r = client.request(probe_url,output='geturl',headers=self.headers)
##                #try again because site occasionally groups epsodes that are release on same day
##                # combined with redirects, the logic below can find grouped itesms
##                episode_range = 0
##                episode_range_list = [-1,-1]
##                try:
##                    if r:
##                        episode_range  = r.split('episode-')[1].strip('/')
##                        episode_range_list = [int(x) for x in episode_range.split('-')]
##                        LogR((r[:r.rindex('-')+len('-')] in r))
##                        #site will sometimes redirect to an old episode if new episode not yet posted
##                        LogR((probe_url,r))
##                        LogR((int(episode) in range(episode_range_list[0],episode_range_list[1])))
##                        LogR(episode_range_list)
##                except:
##                    pass
##                if r and \
##                   ( (  probe_url in r)    
##                     or                 
##                     (                  
##                         (probe_url[:probe_url.rindex('-')+len('-')] in r) 
##                         and            
##                         (int(episode) in range(episode_range_list[0],episode_range_list[1]))
##                     )
##                   ):
##                    Log('r and (probe_url in r)')
##                    episode_url = r
##                    break
##
##                
##                    
##                #try again with a later day in case of time zone issues
##                premiered_year  = (p_d+datetime.timedelta(1)).year
##                premiered_month = (p_d+datetime.timedelta(1)).month
##                try:
##                    probe_url = episode_template.format(self.base_link
##                                                        , premiered_year
##                                                        , premiered_month
##                                                        , url
##                                                        , season
##                                                        , episode)
##                except:
##                    #try again because site occasionally groups epsodes that are release on same day
##                    probe_url = episode_template.format(self.base_link
##                                                        , premiered_year
##                                                        , premiered_month
##                                                        , url
##                                                        , season
##                                                        , int(episode)-1
##                                                        , episode
##                                                        )
##                LogR(probe_url)
##                #try again because site occasionally groups epsodes that are release on same day
##                # combined with redirects, the logic below can find grouped itesms
##                episode_range = 0
##                episode_range_list = [-1,-1]
##                try:
##                    if r:
##                        episode_range  = r.split('episode-')[1].strip('/')
##                        episode_range_list = [int(x) for x in episode_range.split('-')]
##                        LogR((r[:r.rindex('-')+len('-')] in r))
##                        #site will sometimes redirect to an old episode if new episode not yet posted
##                        LogR((probe_url,r))
##                        LogR((int(episode) in range(episode_range_list[0],episode_range_list[1])))
##                        LogR(episode_range_list)
##                except:
##                    pass
##                if r and \
##                   ( (  probe_url in r)    
##                     or                 
##                     (                  
##                         (probe_url[:probe_url.rindex('-')+len('-')] in r) 
##                         and            
##                         (int(episode) in range(episode_range_list[0],episode_range_list[1]))
##                     )
##                   ):
##                    Log('r and (probe_url in r)')
##                    episode_url = r
##                    break
##                
##                #try again with a later month because site is screwy
##                premiered_year  = (p_d+datetime.timedelta(1)).year
##                premiered_month = premiered_month + 1
##                try:
##                    probe_url = episode_template.format(self.base_link
##                                                        , premiered_year
##                                                        , premiered_month
##                                                        , url
##                                                        , season
##                                                        , episode)
##                except:
##                    #try again because site occasionally groups epsodes that are release on same day
##                    probe_url = episode_template.format(self.base_link
##                                                        , premiered_year
##                                                        , premiered_month
##                                                        , url
##                                                        , season
##                                                        , int(episode)-1
##                                                        , episode
##                                                        )
##                LogR(probe_url)
##                #site will sometimes redirect to an old episode if new episode not yet posted
##                r = client.request(probe_url,output='geturl',headers=self.headers)
##                #try again because site occasionally groups epsodes that are release on same day
##                # combined with redirects, the logic below can find grouped itesms
##                episode_range = 0
##                episode_range_list = [-1,-1]
##                try:
##                    if r:
##                        episode_range  = r.split('episode-')[1].strip('/')
##                        episode_range_list = [int(x) for x in episode_range.split('-')]
##                        LogR((r, r[:r.rindex('-')+len('-')] in r))
##                        #site will sometimes redirect to an old episode if new episode not yet posted
##                        LogR((probe_url,r))
##                        LogR((int(episode) in range(episode_range_list[0],episode_range_list[1])))
##                        LogR(episode_range_list)
##                except:
##                    pass
##
##                if r and \
##                   ( (  probe_url in r)    
##                     or                 
##                     (                  
##                         (probe_url[:probe_url.rindex('-')+len('-')] in r) 
##                         and            
##                         (int(episode) in range(episode_range_list[0],episode_range_list[1]))
##                     )
##                   ):
##                    Log('r and (probe_url in r)')
##                    episode_url = r
##                    break
####
##                    
####
######                    #  (?:/|-)  usually a trailing slash is needed, but sometimes multiple episodes will packed with a dash
######                    s = re.search(probe_url.rstrip('/')+'(?:/|-)', r, re.I)
########                    Log(repr(s))
######                    if s: #confirm not a false positive [trim the last backslash]
######                        episode_url = probe_url


            LogR(episode_url)

            if not episode_url: raise Exception(u"episode url not found{}".format(repr(episode_url)))
            r = client.request(episode_url,headers=self.headers) #validate this exists
            if not r: raise Exception(u"improper response for episode url {}".format(repr(episode_url)))

            episode_info = {}
            episode_info['url'] = episode_url
            episode_info['title']  = title
            episode_info['premiered'] = premiered
            episode_info['season'] = season
            episode_info['episode'] = episode
        except:
            #traceback.print_exc()
            LogR(traceback.format_exc(),C.LOGERROR)
##            raise

        episode_url = urlencode(episode_info)
        Log(u"episode url is {}".format(repr(episode_url)))

        return episode_url
    

#__________________________________________________________________________
#
##    def matchAlias(self, title, aliases):
##        try:
##            for alias in aliases:
##                if cleantitle.get(title) == cleantitle.get(alias['title']):
##                    return True
##        except:
##            return False
#__________________________________________________________________________
#
    def ___movie(self, imdb,  tmdb, title, localtitle, aliases, year):
        Log(u'movie {}'.format(repr((imdb, title, localtitle, aliases, year))))

        movie_url = None
        movie_info = {}

        try:
            year_list = ['',year] #sometimes including year helps, but start without it 
            for year in year_list:
                year2 = ''

                aliases.insert(0, {'country':'','title':localtitle})

                for alias in aliases:
                    if year not in alias['title']:
                        if year:
                            year2 = '-'+str(year)
                            Log('trying with an appended year')
                    else:
                        year2 = ''

                    alias = alias['title'].lower()
                    for c in range(len(self.title_delete_doublewidechars) /2):
                        alias = alias.replace( self.title_delete_doublewidechars[c*2:2]  ,'')
                    for c in self.title_delete_chars:
                        alias = alias.replace(c,'')
                    for c in self.title_replace_chars: #replace before delete?
                        alias = alias.replace(c,self.title_replace_subst)                    
                    alias = alias + year2

                    for movies_template in self.movies_templates:
                        probe_url = urljoin(self.base_link, movies_template % (alias))
                        r = None
                        r = client.request(probe_url, ignoreErrors=True,headers=self.headers)
    ##                    probe_url = probe_url[0:-1] #this site works best with trailing slash, but later on, without it
                        if r and (probe_url in r): #confirm not a false positive [trim the last backslash]
##                            Log("found movie_url '{}'".format(probe_url), level=xbmc.LOGWARNING)
                            movie_url = probe_url
                        if movie_url: break
                    if movie_url: break
                if movie_url: break
            pass
        except ValueError:
            pass 
        except:
            traceback.print_exc()

        if not movie_url: return None

        movie_info.update(dict({'imdb': imdb, 'title': title, 'year': year}))
        movie_info['url'] = movie_url
        movie_info = urlencode(movie_info)
        
        Log(u"movie url is {}".format(repr(movie_url)))
        Log(u"movie_info is {}".format(repr(movie_info)))
        return movie_info
    
#__________________________________________________________________________
#
    def searchShow2(self, title, season, aliases, headers):
        url = None
        Log(repr(year))
        Log(repr(aliases))
        Log(repr(headers))

        try:
            title = cleantitle.normalize(title)
            search = '%s Season %01d' % (title, int(season))
            url = urlparse.urljoin(self.base_link, self.search_link % cleantitle.geturl(search))
            Log(repr(url))
            r = client.request(url, headers=headers, timeout='15')
            #r = cache.get(client.request, 1, url, headers=headers, timeout='15')
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
            r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'a', ret='title'))
            r = [(i[0], i[1], re.findall(r'(.*?)\s+-\s+Season\s+(\d)', i[1])) for i in r]
            r = [(i[0], i[1], i[2][0]) for i in r if len(i[2]) > 0]
            url = [i[0] for i in r if self.matchAlias(i[2][0], aliases) and i[2][1] == season][0]
            url = urlparse.urljoin(self.base_link, '%s/watching.html' % url)
        except:
            traceback.print_exc()
        Log("searchShow url='{}'".format(repr(url)))            
        return url
#__________________________________________________________________________
#
    def searchMovie2(self, title, year, aliases, headers):
        url = None
##        Log(repr(year))
##        Log(repr(aliases))
##        Log(repr(headers))
        try:
            title = cleantitle.normalize(title)
            url = urlparse.urljoin(self.base_link, self.search_link % cleantitle.geturl(title))
            Log(repr(url))
            r = client.request(url, headers=headers, timeout='15')
            Log(repr(r))
            r = client.parseDOM(r, 'div', attrs={'class': 'ml-item'})
##            Log(repr(r))
            r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'a', ret='title'))
##            Log(repr(r))
            results = [(i[0], i[1], re.findall(r'\((\d{4})', i[1])) for i in r]
            try:
                r = [(i[0], i[1], i[2][0]) for i in results if len(i[2]) > 0]
                url = [i[0] for i in r if self.matchAlias(i[1], aliases) and (year == i[2])][0]
            except:
                traceback.print_exc()
                url = None
                pass

            if (url == None):
                url = [i[0] for i in results if self.matchAlias(i[1], aliases)][0]

            url = urlparse.urljoin(self.base_link, '%s/watching.html' % url)
        except:
##            Log(repr(title))
##            Log(repr(year))
##            Log(repr(aliases))
##            Log(repr(headers))
            traceback.print_exc()
            
        Log("searchMovie url='{}'".format(repr(url)))            
        return url
#__________________________________________________________________________
#
    def sources(self, url_data, hostDict, hostprDict):
##        LogR(('sources',url_data),C.LOGWARNING)
        sources = []
##        traceback.print_stack()
        try:
            if not url_data: raise ValueError 
                
            hostDict =  hostDict + hostprDict

            url_data = parse_qs(url_data)
            url_data = dict([(i, url_data[i][0]) if url_data[i] else (i, '') for i in url_data])
            Log("parse_qs data='{}'".format(repr(url_data)))

            is_movie = not ('season' in url_data)
            
            if not 'url'in url_data: raise ValueError('missing url')
            url = url_data['url']
            r = client.request(url,headers=self.headers)

            if not is_movie:
                episode = int(url_data['episode'])
                season = int(url_data['season'])

####            r = client.parseDOM(r, 'div', attrs={'itemtype': 'http://schema.org/TVSeason'})
####            LogR(r)
##            r = client.parseDOM(r, 'div', attrs={'class': 'mainbox*'})
####            LogR(r)
##            LogR(len(r))
##            for ep in r:
##                #LogR(ep)
####                td = client.parseDOM(ep, name='td')
####                td = td[1]
####                LogR(td)
##                #s = client.parseDOM(ep, name='a', attrs={'href': "'episode*"})
##                #s = client.parseDOM(ep, name='a')
##                #s = client.parseDOM(ep, name='a', attrs={'href': "episode"})
##                sp = client.parseDOM(td, name='span')
##                LogR(sp)
##
##                
##                s = client.parseDOM(td, name='a', attrs={'href': 'episode.*'})
##                LogR(s)
##                break
##
##            raise ValueError()
                
            regex_outer = (
                "S{:02}E{:02}".format(season, episode)
                + ".+?"
                + "(?:div id=|<script type=\"text/javascript\"  charset=\"utf-8\">)"
                )
##            LogR(regex_outer)
            links = re.compile(regex_outer, re.DOTALL).findall(r)
##            LogR(links)
            if links:
                links = links[0]
            else:
                raise ValueError('episode links not found')
                
            regex_inner = (
                'window.location.href="(.+?ftype=2)"' #type=2 is mp4; =3 is wbem
                )
            links = re.compile(regex_inner, re.DOTALL).findall(links)
            LogR(links)

            try:

                link_count = 0
                for link in links:
##                    Log(repr((link)))
                    link_count = link_count + 1
                    if link_count > self.MAX_LINKS: break
                    link = self.base_link + link

##Referer: https://www.tvseries.in/files-A%20Man%20on%20the%20Inside--18198.htm
                    
                    valid, hoster = source_utils.is_host_valid(link, hostDict)
##                    Log(repr((valid,hoster)))
##                    if valid:
                     
                    sources.append(
                                {
                                'source': hoster + " " + str(link_count)
                                , 'quality': 'SD'
                                , 'info': ''
                                , 'language': 'en'
                                , 'url': link
                                , 'direct': True
                                , 'debridonly': False
                                }
                               )
                
            except:
                traceback.print_exc()
            
        except ValueError as ex:
            LogR(ex.args[0])
            pass
        except:
            traceback.print_exc()
##            LogR(locals(),C.LOGWARNING)
##            source_utils.scraper_error(self.provder_name)
            pass
        
        Log(u"sources returning {}".format(repr(sources)))
##        raise Exception()
        return sources
            

#__________________________________________________________________________
#
    def resolve(self, url):
##        return None
        LogR(url)
        video_url = ''
        try:
            result,response_code,response_headers,headers,cookie=client.request(
                url
                ,headers=self.headers
                ,output='extended'
                )
            regex_outer = (
                 "id='dlink"
                + ".+? href='(.+?)'"
                )
##            LogR(regex_outer)
            links = re.compile(regex_outer, re.DOTALL).findall(result.decode('utf8', 'ignore'))
            LogR(links)
            if links: links=links[0]
                

            url = self.base_link + links
            result=client.request(
                url,headers=self.headers,cookie=cookie
                
                )
##            LogR(cookie)
            regex_outer = (
                 "name='filelink' value='(.+?)'"
                )
            links = re.compile(regex_outer, re.DOTALL).findall(result)
            LogR(links)
            if links:
                if len(links) > 1:
                    for link in links:
                        Log(link)
                        try:
                            result=None
                            result=client.request(
                                link
                                ,headers=self.headers
                                ,method="HEAD"
                                ,cache_seconds = 1
                                ,timeout='5'
                                )
                        except TimeoutError as ex:
                            #ignore these
                            LogR((ex,link))
                            continue
                        #if we reach here...we have a link
                        video_url = link
                        break
                        
                else:
                    video_url = links[0]
                

        except:
            traceback.print_exc()

        Log(video_url)
##        return None
        return video_url
            

#__________________________________________________________________________
#
