"""
    Plugin for ResolveURL
    Copyright (C) 2016 script.module.resolveurl

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resolveurl.lib import helpers
from resolveurl.plugins.__resolve_generic__ import ResolveGeneric


class VidozaResolver(ResolveGeneric):
    name = 'Vidoza'
    domains = ['vidoza.net'
               , 'vidoza.co'
               , 'videzz.net'
               , '.+\.d-ld.net'
               ]
    #pattern = r'(?://|\.)((?:.+\.d-ld|vid(?:oza|ezz))\.(?:net|co))/(?:embed-)?([0-9a-zA-Z]+)'
    pattern = r'(?://|\.)((?:.+\.d-ld|vid(?:oza|ezz))\.(?:net|co))/(?:embed-|e)?(?:/)?([0-9a-zA-Z]+)'

    templates = [
        'https://{host}/embed-{media_id}.html'
        ,'https://{host}/e/{media_id}'
        ]
    def get_media_url(self, host, media_id):

        media_url = None
        for t in self.templates:
            try:
                media_url = self.get_url(host, media_id, t)

                return helpers.get_media_url(
                    #self.get_url(host, media_id),
                    media_url,
                    patterns=[r'''["']?\s*(?:file|src)\s*["']?\s*[:=,]?\s*["'](?P<url>[^"']+)(?:[^}>\]]+)["']?\s*res\s*["']?\s*[:=]\s*["']?(?P<label>[^"',]+)'''],
                    generic_patterns=False,
                    referer=False
                ).replace(' ', '%20')
    
            except:
                pass
        


    def get_url(self, host, media_id, t):
        return self._default_get_url(host, media_id, template=t)
