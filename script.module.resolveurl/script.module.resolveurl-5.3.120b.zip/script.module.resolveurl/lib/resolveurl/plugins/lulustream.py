"""
    Plugin for ResolveURL
    Copyright (C) 2023 shellc0de

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resolveurl import common
from resolveurl.lib import helpers
from resolveurl.plugins.__resolve_generic__ import ResolveGeneric


class LuluStreamResolver(ResolveGeneric):
    name = 'LuluStream'
    domains = ['lulustream.com', 'luluvdo.com', 'lulu.st', '732eg54de642sa.sbs']
    pattern = r'(?://|\.)((?:lulu(?:stream|vdo)?|732eg54de642sa)\.(?:com|sbs|st))/(?:e/|d/)?([0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id, subs=False):

        r = helpers.get_media_url(
            self.get_url(host, media_id),
            patterns=[r'''sources:\s*\[{file:\s*["'](?P<url>[^"']+)'''],
            generic_patterns=False,
            referer=False,
            subs=subs
        )
        if r:
            #2025-05 site wants useragent to match
            headers = {'User-Agent': common.RAND_UA}
            headers.update(
                {
                'Referer': 'https://{0}/'.format(host)
                ,'Origin': 'https://{0}'.format(host)
                ,'Accept-Encoding': 'gzip, deflate'
                ,'Accept-Language': 'en-US,en;q=0.9'
                }
                )
            r = r + helpers.append_headers(headers)
            return r

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/e/{media_id}')
