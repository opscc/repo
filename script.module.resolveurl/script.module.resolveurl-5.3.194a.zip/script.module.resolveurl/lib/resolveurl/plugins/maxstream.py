"""
    Plugin for ResolveURL
    Copyright (C) 2020 gujal, groggyegg

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import base64
import binascii
import random
import string
import json

from resolveurl.lib import helpers
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError


from resolveurl.lib.log_utils import Log,LogR,LOGWARNING,LOGINFO,LOGNONE
    
class maxstreamResolver(ResolveUrl):
    name = 'maxstream'
    domains = ['maxstream.org']
    pattern = r'(?://|\.)' \
              r'(maxstream\.org)' \
              r'/(?:embed[-])?([0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id):
        Log(repr((host,media_id)),LOGWARNING)
        rurl = 'https://{0}/'.format(host)
        rurl = 'https://jav.guru/'
        web_url = self.get_url(host, media_id)
##        html = self.net.http_GET(web_url).content

        headers = {
            #'Origin': rurl[:-1]
            'Referer': rurl
            , 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'
        }
##        xbmc.sleep(3000)

        html = self.net.http_GET(url=web_url,headers=headers).content
##        Log(repr((html)))
        
        if '(p,a,c,k,e,d)' in html:
            html = helpers.get_packed_data(html)
##            Log(repr((html)))
        regex = ',file:"(.+?)"'
        video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
##        Log(repr((video_url)))
        if video_url:
            Log(video_url[0] + helpers.append_headers(headers),LOGWARNING)
            return video_url[0] + helpers.append_headers(headers)

        Log('Warning {} Video not found'.format(__name__))
        return

##        rurl = 'https://{0}/'.format(host)
##        headers = {'User-Agent': common.RAND_UA,
##                   'Referer': rurl}
##        try:
##            Log('web_url'+'='+repr(web_url))
##            html = self.net.http_GET(web_url, headers=headers).content
##
##            sources = re.findall(r'download_video([^"]+).*?<span>\s*(\d+)', html, re.S)
##            if sources:
##                sources.sort(key=lambda x: int(x[1]), reverse=True)
##                sources = [(x[1] + 'p', x[0]) for x in sources]
##                code, mode, dl_hash = eval(helpers.pick_source(sources))
##                dl_url = 'https://{0}/dl?op=download_orig&id={1}&mode={2}&hash={3}'.format(host, code, mode, dl_hash)
##                html = self.net.http_GET(dl_url, headers=headers).content
##                domain = base64.b64encode((rurl[:-1] + ':443').encode('utf-8')).decode('utf-8').replace('=', '')
##                token = helpers.girc(html, rurl, domain)
##                if token:
##                    payload = helpers.get_hidden(html)
##                    payload.update({'g-recaptcha-response': token})
##                    req = self.net.http_POST(dl_url, form_data=payload, headers=headers).content
##                    r = re.search(r'href="([^"]+)"\s*class="btn\s*btn-light', req)
##                    if r:
##                        return r.group(1) + helpers.append_headers(headers)
##
##            eurl = self.get_embedurl(host, media_id)
##            headers.update({'watchsb': 'sbstream'})
##            html = self.net.http_GET(eurl, headers=headers).content
##            data = json.loads(html).get("stream_data", {})
##            strurl = data.get('file') or data.get('backup')
##            if strurl:
##                headers.pop('watchsb')
##                return strurl + helpers.append_headers(headers)
##        
##        except:
##            web_url = self.get_url2(host, media_id)
##            Log('web_url'+'='+repr(web_url))
##            html = self.net.http_GET(web_url, headers=headers).content
##            regex = r'sources: \[{file:"([^"]+)"'
##            sources = re.findall(regex, html, re.S)
##            Log('sources'+'='+repr(sources))
##            return sources[0]  + helpers.append_headers(headers)



    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/embed-{media_id}.html')
##    def get_url2(self, host, media_id):
##        return self._default_get_url(host, media_id, template='https://{host}/e/{media_id}')
    
##    def get_embedurl(self, host, media_id):
##        # Copyright (c) 2019 vb6rocod
##        def makeid(length):
##            t = string.ascii_letters + string.digits
##            return ''.join([random.choice(t) for _ in range(length)])
##
##        x = '{0}||{1}||{2}||streamsb'.format(makeid(12), media_id, makeid(12))
##        c1 = binascii.hexlify(x.encode('utf8')).decode('utf8')
##        x = '{0}||{1}||{2}||streamsb'.format(makeid(12), makeid(12), makeid(12))
##        c2 = binascii.hexlify(x.encode('utf8')).decode('utf8')
##        x = '{0}||{1}||{2}||streamsb'.format(makeid(12), c2, makeid(12))
##        c3 = binascii.hexlify(x.encode('utf8')).decode('utf8')
##        return 'https://{0}/sources50/{1}/{2}'.format(host, c1, c3)
