"""
    Plugin for ResolveURL
    Copyright (C) 2020 gujal, groggyegg

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import base64
import binascii
import random
import string
import json

from resolveurl.lib import helpers
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError

import xbmc
def Log(msg):
    xbmc.log(msg, xbmc.LOGNONE)
    
class javlesbiansResolver(ResolveUrl):
    name = 'javlesbians'
    domains = ['javlesbians.com']
    pattern = r'(?://|\.)' \
              r'(javlesbians\.com)' \
              r'/(?:embed[-]|e/)?([0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id):
##        Log(repr((host,media_id)))
        rurl = 'https://{0}/'.format(host)
        web_url = self.get_url(host, media_id)
        html = self.net.http_GET(web_url).content
##        Log(repr((html)))

        headers = {'Origin': rurl[:-1],
                   'Referer': rurl,
                   'User-Agent': common.RAND_UA}
        
        if '(p,a,c,k,e,d)' in html:
            html = helpers.get_packed_data(html)
##            Log(repr((html)))

        regex = 'sources: \[{file:"(.+?)"'
        video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
##        Log(repr((video_url)))
        if video_url:
            Log(video_url[0] + helpers.append_headers(headers))
            return video_url[0] + helpers.append_headers(headers)

        raise ResolverError('Video not found')

##        rurl = 'https://{0}/'.format(host)
##        headers = {'User-Agent': common.RAND_UA,
##                   'Referer': rurl}
##        try:
##            Log('web_url'+'='+repr(web_url))
##            html = self.net.http_GET(web_url, headers=headers).content
##
##            sources = re.findall(r'download_video([^"]+).*?<span>\s*(\d+)', html, re.S)
##            if sources:
##                sources.sort(key=lambda x: int(x[1]), reverse=True)
##                sources = [(x[1] + 'p', x[0]) for x in sources]
##                code, mode, dl_hash = eval(helpers.pick_source(sources))
##                dl_url = 'https://{0}/dl?op=download_orig&id={1}&mode={2}&hash={3}'.format(host, code, mode, dl_hash)
##                html = self.net.http_GET(dl_url, headers=headers).content
##                domain = base64.b64encode((rurl[:-1] + ':443').encode('utf-8')).decode('utf-8').replace('=', '')
##                token = helpers.girc(html, rurl, domain)
##                if token:
##                    payload = helpers.get_hidden(html)
##                    payload.update({'g-recaptcha-response': token})
##                    req = self.net.http_POST(dl_url, form_data=payload, headers=headers).content
##                    r = re.search(r'href="([^"]+)"\s*class="btn\s*btn-light', req)
##                    if r:
##                        return r.group(1) + helpers.append_headers(headers)
##
##            eurl = self.get_embedurl(host, media_id)
##            headers.update({'watchsb': 'sbstream'})
##            html = self.net.http_GET(eurl, headers=headers).content
##            data = json.loads(html).get("stream_data", {})
##            strurl = data.get('file') or data.get('backup')
##            if strurl:
##                headers.pop('watchsb')
##                return strurl + helpers.append_headers(headers)
##        
##        except:
##            web_url = self.get_url2(host, media_id)
##            Log('web_url'+'='+repr(web_url))
##            html = self.net.http_GET(web_url, headers=headers).content
##            regex = r'sources: \[{file:"([^"]+)"'
##            sources = re.findall(regex, html, re.S)
##            Log('sources'+'='+repr(sources))
##            return sources[0]  + helpers.append_headers(headers)



    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/e/{media_id}')
