"""
    Plugin for ResolveURL
    Copyright (C) 2020 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resolveurl.plugins.__resolve_generic__ import ResolveGeneric
from resolveurl.lib import helpers

import xbmc
def Log(msg):
##    return
    try:
        xbmc.log(msg, xbmc.LOGNONE)
    except:
        xbmc.log( repr( (type(msg), msg) ), xbmc.LOGNONE)


class NetembedResolver(ResolveGeneric):
    name = 'netembed'
    domains = [
        'netembed.*'
        ]
    pattern = r'(?://|\.)(netembed\.(?:club|to|net))/embed/tv/([0-9a-zA-Z\/]+)'

    def get_media_url(self, host, media_id):
        
        Log(repr((host, media_id)))
        return        

        try:
            regex = r'(?://|\.)(vidmoly\.(?:me|to|net))/(?:embed-|w/)?([0-9a-zA-Z]+)'
            html = self.net.http_GET(self.get_url(host, media_id)).content
            import re
            try0 = re.findall(regex,html)[0]
            Log(repr((try0,)))
            host_1=try0[0]
            media_id_1 = try0[1]
            try2 = helpers.get_media_url(
                self.get_url2(host_1, media_id_1),
                patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
                result_blacklist=['.mpd']
                )
            Log(repr(("50",try2,)))
            return try2
        except:
##            raise
            pass


        try:
            try1 = helpers.get_media_url(
                self.get_url(host, media_id),
                patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
                result_blacklist=['.mpd']
                )
            Log(repr((try1,)))
            return try1
        except:
            try2 = helpers.get_media_url(
                self.get_url2(host, media_id),
                patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
                result_blacklist=['.mpd']
                )
            Log(repr((try2,)))
            return try2
        
##        html = self.net.http_GET(web_url).content
##        return helpers.get_media_url(
##            self.get_url(host, media_id),
##            patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
##            result_blacklist=['.mpd']
##        )

    def get_url(self, host, media_id):
        default_get_url = self._default_get_url(host, media_id, template='https://vidmoly.me/{media_id}.html')
        Log(repr((default_get_url,)))
        return default_get_url
    def get_url2(self, host, media_id):
        default_get_url = self._default_get_url(host, media_id, template='https://vidmoly.to/embed-{media_id}.html')
        Log(repr((default_get_url,)))
        return default_get_url
