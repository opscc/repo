"""
    Plugin for ResolveURL
    Copyright (C) 2020 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resolveurl.plugins.__resolve_generic__ import ResolveGeneric
from resolveurl.lib import helpers
from resolveurl.lib.log_utils import Log,LogR,LOGWARNING,LOGINFO
import re
import traceback

##import xbmc
##def Log(msg):
####    return
##    try:
##        xbmc.log(msg, xbmc.LOGNONE)
##    except:
##        xbmc.log(repr((type(msg),msg)), xbmc.LOGNONE)


class VidMolyResolver(ResolveGeneric):
    name = 'VidMoly'
    domains = ['vidmoly.me', 'vidmoly.to', 'vidmoly.net']
    pattern = r'(?://|\.)(vidmoly\.(?:me|to|net))/(?:embed-|w/)?([0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id):
        LogR((host, media_id),LOGWARNING)

        try:
            regex = r'(?://|\.)(vidmoly\.(?:me|to|net))/(?:embed-|w/)?([0-9a-zA-Z]+)'
            html = self.net.http_GET(
                self.get_url(host, media_id)
                ).content
            #try0 = re.findall(regex,html)[0]
            try0 = re.findall(regex,html)[0]
            LogR(('try0',try0),LOGWARNING)
            host_1=try0[0]
            media_id_1 = try0[1]
            try2 = helpers.get_media_url(
                self.get_url2(host_1, media_id_1),
                patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
                result_blacklist=['.mpd']
                )
            LogR(try2,LOGWARNING)
            return try2
        except:
            traceback.print_exc()
##            raise
            pass


        try:
            Log('here',LOGWARNING)
            try1 = helpers.get_media_url(
                self.get_url(host, media_id),
                patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
                result_blacklist=['.mpd']
                )
            LogR(try1,LOGWARNING)
            return try1
        except:
            try2 = None
            try:
                import xbmc
                xbmc.Monitor().waitForAbort(2)
                html = self.net.http_GET(
                    self.get_url(host, media_id)
                    ).content
##                try2 = helpers.get_media_url(
##                    self.get_url2(host, media_id),
##                    patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
##                    result_blacklist=['.mpd']
##                    )
##            except:
##                html = self.net.http_GET(
##                    self.get_url2(host, media_id)
##                    ).content
                regex_redir = r"url \+= '(\?g=[0-9a-zA-Z]+)'"
                redirect = re.findall(regex_redir,html)
                LogR(redirect,LOGWARNING)
                if redirect:
                    xbmc.Monitor().waitForAbort(2)
                    u = self.get_url2(host, media_id)+redirect[0]
                    Log(u,LOGWARNING)
                    html = self.net.http_GET(u).content
                    regex = r'''sources:\s*\[{file:"(?P<url>[^"]+)'''
                    try2 = re.findall(regex,html)
                    LogR(try2,LOGWARNING)
##                    try2 = helpers.get_media_url(
##                        self.get_url2(host, media_id),
##                        patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
##                        result_blacklist=['.mpd']
##                        )                    
            except:
                traceback.print_exc()
            
            LogR(try2)
            return try2
        
##        html = self.net.http_GET(web_url).content
##        return helpers.get_media_url(
##            self.get_url(host, media_id),
##            patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
##            result_blacklist=['.mpd']
##        )

    def get_url(self, host, media_id):
        default_get_url = self._default_get_url(
            host
            , media_id
            , template='https://vidmoly.net/{media_id}.html'
            )
##        Log(default_get_url)
        return default_get_url
    def get_url2(self, host, media_id):
        default_get_url = self._default_get_url(
            host
            , media_id
            , template='https://vidmoly.me/embed-{media_id}.html'
            )
##        Log(repr((default_get_url,)))
        return default_get_url
