"""
    Plugin for ResolveURL
    Copyright (C) 2020 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import random
import string
import time
import traceback
from resolveurl.lib import helpers
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError

import xbmc
def Log(msg):
    xbmc.log(msg, xbmc.LOGWARNING)

class DoodStreamResolver(ResolveUrl):
    name = 'DoodStream'
    domains = [
                'dooood.com'
                , 'dooood.com'
                , 'dood.watch'
                , 'doodstream.com', 'dood.to', 'dood.so'
                , 'dood.cx', 'dood.la', 'dood.ws'
                , 'dood.sh', 'doodstream.co'
                , 'dood.pm', 'dood.wf', 'dood.re'
                , 'dood.yt'
                , 'doods.pro'
                , 'ds2play.com'
                , 'd0o0d.com'
                , 'd000d.com'
                , 'd0000d.com'
                ,'dood.*'
                ,'d-s.io'
                ,'dsvplay'
                ,'vvide0'
                ]
    pattern = r'(?://|\.)((?:d-s|vvide0|dsvplay|doods|ds2play|d(?:o|0|O)+?d(?:stream|s)?)\.(?:com|co|watch|to|s[ho]|cx|la|w[sf]|pm|re|yt|pro|io|[0-9a-zA-Z]+?))/(?:d|e)/([0-9a-zA-Z]+)'

    web_url_templates = [
         'https://{host}/e/{media_id}'
        ,'https://{host}/d/{media_id}'
        ]

    #these are banned due to ddos challenge
    bad_hosts = [
        'doodstream.com' #2025-11
        ]
    def get_media_url(self, host, media_id, subs=False):

##        Log(host)
        for t in self.web_url_templates:
           
            hosts = [
                host
                ,'dsvplay.com'
                ,'d-s.io'
                ]

            for h in hosts:

                if h in self.bad_hosts: continue
            
                web_url = self.get_url(h, media_id, t)
                rurl = 'https://{}/'.format(h)
                headers = {
                    'User-Agent': common.RAND_UA
                    ,'Referer': h
                    }
                if rurl.endswith('/'): headers['Origin']=rurl[:-1]
                else: headers['Origin']= rurl
                Log(repr(web_url))
##                Log(repr(headers))
                html = ''
                try:
                    html = self.net.http_GET(web_url, headers=headers).content
                except:
                    pass
##                Log(repr(html))
                if not html: continue

                match = re.search(r'''dsplayer\.hotkeys[^']+'([^']+).+?function\s*makePlay.+?return[^?]+([^"]+)''', html, re.DOTALL)
                if match:
                    token = match.group(2)
                    Log(token)
                    url = 'https://{0}{1}'.format(h, match.group(1))
                    html = self.net.http_GET(url, headers=headers).content
                    play_url = self.dood_decode(html) + token + str(int(time.time() * 1000)) + helpers.append_headers(headers)
                    return play_url

                    
        return ''
        raise ResolverError('Video Link Not Found')



        try:
            
            if any(host.endswith(x) for x in ['.cx', '.wf', '.pro']):
                host = 'dood.so'

            web_url = self.get_url(host, media_id)
            
                
            headers = {
                'User-Agent': common.RAND_UA
                ,'Referer': 'https://{0}/'.format(host)
                }

            try:
                r = self.net.http_GET(web_url, headers=headers)
            except:
                web_url = self.get_url2(host, media_id)
                r = self.net.http_GET(web_url, headers=headers)
                host = 'd-s.io'
                
            if r.get_url() != web_url:
                host = re.findall(r'(?://|\.)([^/]+)', r.get_url())[0]
                web_url = self.get_url(host, media_id)
            headers.update({'Referer': web_url})
            html = r.content

            match = re.search(r'<iframe\s*src="([^"]+)', html)
            if match:
                url = 'https://{0}{1}'.format(host, match.group(1))
                html = self.net.http_GET(url, headers=headers).content
            else:
                url = web_url.replace('/d/', '/e/')
                html = self.net.http_GET(url, headers=headers).content

            match = re.search(r'''dsplayer\.hotkeys[^']+'([^']+).+?function\s*makePlay.+?return[^?]+([^"]+)''', html, re.DOTALL)
            if match:
                token = match.group(2)
                url = 'https://{0}{1}'.format(host, match.group(1))
                html = self.net.http_GET(url, headers=headers).content
                play_url = self.dood_decode(html) + token + str(int(time.time() * 1000)) + helpers.append_headers(headers)
                return play_url
        except:
            traceback.print_exc()
        raise ResolverError('Video Link Not Found')

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/d/{media_id}')

    def get_url2(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://d-s.io/e/{media_id}')

    def dood_decode(self, data):
        t = string.ascii_letters + string.digits
        return data + ''.join([random.choice(t) for _ in range(10)])

    def get_url(self, host, media_id, t):
        return self._default_get_url(host, media_id, template=t)
    
