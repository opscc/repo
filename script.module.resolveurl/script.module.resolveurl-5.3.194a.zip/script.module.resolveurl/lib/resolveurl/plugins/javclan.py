"""
    Plugin for ResolveURL
    Copyright (C) 2024 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from six.moves import urllib_parse
from resolveurl.lib import helpers, jsunhunt
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError

from resolveurl.lib.log_utils import Log,LogR,LOGWARNING,LOGINFO,LOGNONE


class StreamSilkResolver(ResolveUrl):
    name = 'javclan'
    domains = ['javclan.com']
    pattern = r'(?://|\.)(javclan\.com)/(?:e)/([0-9a-zA-Z$:/.]+)'

##GET https://javclan.com/e/kbuac4hnwayb HTTP/1.1
##Host: javclan.com
##Accept-Language: en-US,en;q=0.9
##Referer: https://jav.guru/searcho/?xd=26971677e6864336165726b6
##Accept-Encoding: gzip, deflate
##Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0
##

## TODO
    

    def get_media_url(self, host, media_id):

        web_url = self.get_url(host, media_id)
        LogR(web_url,LOGWARNING)
        rurl = 'https://jav.guru/'
        headers = {
            'Referer': rurl
            ,'Accept-Language': 'en-US,en;q=0.9'
            ,'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
            , 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'
        }
        html = self.net.http_GET(url=web_url,headers=headers).content
        #Log(html,LOGNONE)
        if '(p,a,c,k,e,d)' in html:
##            Log("'(p,a,c,k,e,d)' in html",LOGNONE)
            html = helpers.get_packed_data(html)
##            Log(html,LOGWARNING)
        regex = '"hls\d":"(.+?)"'
        video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
        LogR(video_url,LOGWARNING)
        if video_url:
            for vurl in video_url:
                if vurl.startswith('http'):
                    continue
                    headers['Referer']='https://{0}/'.format(host)
                    Log(vurl + helpers.append_headers(headers))
                    return vurl + helpers.append_headers(headers)
                else:
                    vurl = 'https://'+host+vurl
                    headers['Referer']=web_url
                    Log(vurl + helpers.append_headers(headers))
                    return vurl + helpers.append_headers(headers)
                    

        Log('Warning {} Video not found'.format(__name__),LOGWARNING)
        return



        
        return
        if '$$' in media_id:
            media_id, referer = media_id.split('$$')
            referer = urllib_parse.urljoin(referer, '/')
        else:
            referer = False
        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': common.RAND_UA}
        if referer:
            headers.update({'Referer': referer})
        html = self.net.http_GET(web_url, headers=headers).content
        if jsunhunt.detect(html):
            html = jsunhunt.unhunt(html)
        r = re.search(r'urlPlay\s*=\s*"([^"]+)', html)
        if r:
            headers.update({
                'Referer': 'https://{0}/'.format(host),
                'Origin': 'https://{0}'.format(host)
            })
            return r.group(1).strip() + helpers.append_headers(headers)

        raise ResolverError('File not found')

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/e/{media_id}')
