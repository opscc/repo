"""
    Plugin for ResolveURL
    Copyright (C) 2023 shellc0de

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from six.moves import urllib_parse
from resolveurl.lib import helpers
from resolveurl.lib import jsunpack
from resolveurl.plugins.__resolve_generic__ import ResolveGeneric

from resolveurl.lib.log_utils import Log
import os,traceback,xbmc
def Log(msg,stacklevel=2):
    try: 
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
            ,traceback.extract_stack(limit=stacklevel)[0][1]
            ,msg
            )
    except:
        raise
        pass
    xbmc.log(msg, xbmc.LOGNONE)

class StreamWishResolver(ResolveGeneric):
    name = 'StreamWish'
    domains = ['streamwish.com', 'streamwish.to', 'ajmidyad.sbs', 'khadhnayad.sbs', 'yadmalik.sbs',
               'hayaatieadhab.sbs', 'kharabnahs.sbs', 'atabkhha.sbs', 'atabknha.sbs', 'atabknhk.sbs',
               'atabknhs.sbs', 'abkrzkr.sbs', 'abkrzkz.sbs', 'wishembed.pro', 'mwish.pro', 'strmwis.xyz',
               'awish.pro', 'dwish.pro', 'vidmoviesb.xyz', 'embedwish.com', 'cilootv.store',
               'tuktukcinema.store', 'doodporn.xyz', 'ankrzkz.sbs', 'volvovideo.top', 'streamwish.site',
               'wishfast.top', 'ankrznm.sbs', 'sfastwish.com', 'eghjrutf.sbs', 'eghzrutw.sbs',
               'playembed.online', 'egsyxurh.sbs', 'egtpgrvh.sbs', 'flaswish.com'
                ,'.+?wish.com'
                ,'iplayerhls.com'
                ,'sw.+?\.com'
                ,'hlsflast\.com'
                ,'dhtpre.com'
               ,'\w+pre.com'
               ,'ryderjet.com'
               ,'ghbrisk.com'
               ,'cybervynx.com'
               ,'dhcplay.com'
               ,'gradehgplus.com'
               ]
    pattern =   r'(?://|\.)((?:streamwish|ajmidyad|khadhnayad|yadmalik|hayaatieadhab|kharabnahs|' \
                r'atabkhha|atabknha|atabknhk|atabknhs|abkrzkr|abkrzkz|wishembed|[mad]wish|vidmoviesb|' \
                r'cilootv|tuktukcinema|embedwish|doodporn|ankrzkz|volvovideo|strmwis|wishfast|ankrznm|' \
                r'sfastwish|eghjrutf|eghzrutw|playembed|egsyxurh|egtpgrvh|flaswish' \
                r'|.+?wish' \
                r'|sw.*?' \
                r'|\w+pre' \
                r'|iplayerhls' \
                r'|hlsflast' \
                r'|ryderjet' \
                r'|ghbrisk' \
                r'|cybervynx' \
                r'|dhcplay' \
                r'|gradehgplus' \
                r')' \
                r'\.(?:com|to|sbs|pro|xyz|store|top|site|online))/(?:embed/|e/|f/|v/)?([0-9a-zA-Z$:/.]+)'

        
    def get_media_url(self, host, media_id):
        
        if '$$' in media_id:
            media_id, referer = media_id.split('$$')
            referer = urllib_parse.urljoin(referer, '/')
        else:
            referer = False

        templates = [
                        'https://{host}/e/{media_id}'
                        ,'https://{host}/v/{media_id}'
                     ]


        media_url = None


        for t in templates:
            Log(t)
            try:
                regex = '(?:sources:\\s*\\[{file:|links={"hls\d":)\\s*["\'](?P<url>[^"\']+)'
                media_source = None
                media_source = self.get_url(host, media_id, t)
                Log(repr(media_source))
                media_url = None
                media_url = helpers.get_media_url(
                    #self.get_url(host, media_id, t),
                    media_source
                    #patterns=[r'''sources:\s*\[{file:\s*["'](?P<url>[^"']+)'''],
                    ,patterns=[regex]
                    ,generic_patterns=False
                    ,referer=referer
                    ,log_packed_data=True
                )
                Log(repr(media_url))
                if media_url:
                    Log('warn success with method1 with template {}'.format(media_source))
                    break
            except:
                traceback.print_exc()
##                traceback.print_stack()
                pass
            if media_url:
                break

##        Log(media_url)
        return media_url
    
##        return helpers.get_media_url(
##            self.get_url(host, media_id),
##            patterns=[r'''sources:\s*\[{file:\s*["'](?P<url>[^"']+)'''],
##            generic_patterns=False,
##            referer=referer
##        )

    def get_url(self, host, media_id, t):
        return self._default_get_url(host, media_id, template=t)

    
