"""
    common XBMC Module
    Copyright (C) 2011 t0mm0

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import random
from six.moves import http_cookiejar
import gzip
import re
import json
import six
from six.moves import urllib_request, urllib_parse, urllib_error
import socket
import time
from resolveurl.lib import kodi

import cookielib
import xbmc
import requests
import urllib2
import traceback
import urlparse
my_http_session = requests.Session()
from urllib3 import ProxyManager, PoolManager
pool_proxy = PoolManager()
# Set Global timeout - Useful for slow connections and Putlocker.
socket.setdefaulttimeout(10)

BR_VERS = [
    ['%s.0' % i for i in range(18, 50)],
    ['37.0.2062.103', '37.0.2062.120', '37.0.2062.124', '38.0.2125.101', '38.0.2125.104', '38.0.2125.111', '39.0.2171.71', '39.0.2171.95', '39.0.2171.99', '40.0.2214.93', '40.0.2214.111',
     '40.0.2214.115', '42.0.2311.90', '42.0.2311.135', '42.0.2311.152', '43.0.2357.81', '43.0.2357.124', '44.0.2403.155', '44.0.2403.157', '45.0.2454.101', '45.0.2454.85', '46.0.2490.71',
     '46.0.2490.80', '46.0.2490.86', '47.0.2526.73', '47.0.2526.80', '48.0.2564.116', '49.0.2623.112', '50.0.2661.86'],
    ['11.0'],
    ['8.0', '9.0', '10.0', '10.6']]
WIN_VERS = ['Windows NT 10.0', 'Windows NT 7.0', 'Windows NT 6.3', 'Windows NT 6.2', 'Windows NT 6.1', 'Windows NT 6.0', 'Windows NT 5.1', 'Windows NT 5.0']
FEATURES = ['; WOW64', '; Win64; IA64', '; Win64; x64', '']
RAND_UAS = ['Mozilla/5.0 ({win_ver}{feature}; rv:{br_ver}) Gecko/20100101 Firefox/{br_ver}',
            'Mozilla/5.0 ({win_ver}{feature}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{br_ver} Safari/537.36',
            'Mozilla/5.0 ({win_ver}{feature}; Trident/7.0; rv:{br_ver}) like Gecko',
            'Mozilla/5.0 (compatible; MSIE {br_ver}; {win_ver}{feature}; Trident/6.0)']
CERT_FILE = kodi.translate_path('special://xbmc/system/certs/cacert.pem')


def get_ua():
    try:
        last_gen = int(kodi.get_setting('last_ua_create'))
    except:
        last_gen = 0
    if not kodi.get_setting('current_ua') or last_gen < (time.time() - (7 * 24 * 60 * 60)):
        index = random.randrange(len(RAND_UAS))
        versions = {'win_ver': random.choice(WIN_VERS), 'feature': random.choice(FEATURES), 'br_ver': random.choice(BR_VERS[index])}
        user_agent = RAND_UAS[index].format(**versions)
        # logger.log('Creating New User Agent: %s' % (user_agent), log_utils.LOGDEBUG)
        kodi.set_setting('current_ua', user_agent)
        kodi.set_setting('last_ua_create', str(int(time.time())))
    else:
        user_agent = kodi.get_setting('current_ua')
    return user_agent


class Net:
    """
    This class wraps :mod:`urllib2` and provides an easy way to make http
    requests while taking care of cookies, proxies, gzip compression and
    character encoding.

    Example::

        from addon.common.net import Net
        net = Net()
        response = net.http_GET('http://xbmc.org')
        print response.content
    """

    _cj = http_cookiejar.LWPCookieJar()
    _proxy = None
    _user_agent = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'
    _http_debug = False
    _cookie_file = None

    def __init__(self, cookie_file='', proxy='', user_agent='', ssl_verify=True, http_debug=False):
        """
        Kwargs:
            cookie_file (str): Full path to a file to be used to load and save
            cookies to.

            proxy (str): Proxy setting (eg.
            ``'http://user:pass@example.com:1234'``)

            user_agent (str): String to use as the User Agent header. If not
            supplied the class will use a default user agent (chrome)

            http_debug (bool): Set ``True`` to have HTTP header info written to
            the XBMC log for all requests.
        """
        if cookie_file:
            self.set_cookies(cookie_file)
            self._cookie_file = cookie_file
        if proxy:
            self.set_proxy(proxy)
        if user_agent:
            self.set_user_agent(user_agent)
        self._ssl_verify = ssl_verify
        self._http_debug = http_debug
        self._update_opener()

    def set_cookies(self, cookie_file):
        """
        Set the cookie file and try to load cookies from it if it exists.

        Args:
            cookie_file (str): Full path to a file to be used to load and save
            cookies to.
        """
        try:
            self._cj.load(cookie_file, ignore_discard=True)
            self._update_opener()
            return True
        except:
            return False

    def get_cookies(self, as_dict=False):
        """Returns A dictionary containing all cookie information by domain."""
        if as_dict:
            return dict((cookie.name, cookie.value) for cookie in self._cj)
        else:
            return self._cj._cookies

    def save_cookies(self, cookie_file):
        """
        Saves cookies to a file.

        Args:
            cookie_file (str): Full path to a file to save cookies to.
        """
        self._cj.save(cookie_file, ignore_discard=True)

    def set_proxy(self, proxy):
        """
        Args:
            proxy (str): Proxy setting (eg.
            ``'http://user:pass@example.com:1234'``)
        """
        self._proxy = proxy
        self._update_opener()

    def get_proxy(self):
        """Returns string containing proxy details."""
        return self._proxy

    def set_user_agent(self, user_agent):
        """
        Args:
            user_agent (str): String to use as the User Agent header.
        """
        self._user_agent = user_agent

    def get_user_agent(self):
        """Returns user agent string."""
        return self._user_agent

    def _update_opener(self, drop_tls_level=False):
        """
        Builds and installs a new opener to be used by all future calls to
        :func:`urllib2.urlopen`.
        """
        handlers = [urllib_request.HTTPCookieProcessor(self._cj), urllib_request.HTTPBasicAuthHandler()]

        if self._http_debug:
            handlers += [urllib_request.HTTPHandler(debuglevel=1)]
        else:
            handlers += [urllib_request.HTTPHandler()]

        if self._proxy:
            handlers += [urllib_request.ProxyHandler({'http': self._proxy})]

        try:
            import platform
            node = platform.node().lower()
        except:
            node = ''

        if not self._ssl_verify or node == 'xboxone':
            try:
                import ssl
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
##                if self._http_debug:
##                    handlers += [urllib_request.HTTPSHandler(context=ctx, debuglevel=1)]
##                else:
##                    handlers += [urllib_request.HTTPSHandler(context=ctx)]
##            except:
##                pass
##        else:
##            try:
##                import ssl
##                import certifi
##                ctx = ssl.create_default_context(cafile=certifi.where())
##                if drop_tls_level:
##                    ctx.protocol = ssl.PROTOCOL_TLSv1_1
##                ctx.protocol = ssl.PROTOCOL_TLSv1_1
                if self._http_debug:
                    handlers += [urllib_request.HTTPSHandler(context=ctx, debuglevel=1)]
                else:
                    handlers += [urllib_request.HTTPSHandler(context=ctx)]
            except:
                pass

        opener = urllib_request.build_opener(*handlers)
        urllib_request.install_opener(opener)

    def http_GET(self, url, headers={}, compression=True):
        """
        Perform an HTTP GET request.

        Args:
            url (str): The URL to GET.

        Kwargs:
            headers (dict): A dictionary describing any headers you would like
            to add to the request. (eg. ``{'X-Test': 'testing'}``)

            compression (bool): If ``True`` (default), try to use gzip
            compression.

        Returns:
            An :class:`HttpResponse` object containing headers and other
            meta-information about the page and the page content.
        """
        return self._fetch(url, headers=headers, compression=compression)

    def http_POST(self, url, form_data, headers={}, compression=True, jdata=False):
        """
        Perform an HTTP POST request.

        Args:
            url (str): The URL to POST.

            form_data (dict): A dictionary of form data to POST.

        Kwargs:
            headers (dict): A dictionary describing any headers you would like
            to add to the request. (eg. ``{'X-Test': 'testing'}``)

            compression (bool): If ``True`` (default), try to use gzip
            compression.

        Returns:
            An :class:`HttpResponse` object containing headers and other
            meta-information about the page and the page content.
        """
        return self._fetch(url, form_data, headers=headers, compression=compression, jdata=jdata)

    def http_HEAD(self, url, headers={}):
        """
        Perform an HTTP HEAD request.

        Args:
            url (str): The URL to GET.

        Kwargs:
            headers (dict): A dictionary describing any headers you would like
            to add to the request. (eg. ``{'X-Test': 'testing'}``)

        Returns:
            An :class:`HttpResponse` object containing headers and other
            meta-information about the page.
        """

        r = getHtml(url
                , referer=''
                , headers=headers
                , save_cookie=False
                , sent_data=None
                , ignore404=False
                , ignore403=False
                , send_back_redirect=False
                , http_timeout=10
                , sucuri_solved=False
                , method='HEAD'
                , send_back_response=True
                , auto_encode_content=True
                , cookie_file=self._cookie_file
                )
        r = HttpResponse2(r)
        return r
    
        request = urllib_request.Request(url)
        request.get_method = lambda: 'HEAD'
        request.add_header('User-Agent', self._user_agent)
        for key in headers:
            request.add_header(key, headers[key])
        response = urllib_request.urlopen(request)
        return HttpResponse(response)

    def http_DELETE(self, url, headers={}):
        """
        Perform an HTTP DELETE request.

        Args:
            url (str): The URL to GET.

        Kwargs:
            headers (dict): A dictionary describing any headers you would like
            to add to the request. (eg. ``{'X-Test': 'testing'}``)

        Returns:
            An :class:`HttpResponse` object containing headers and other
            meta-information about the page.
        """
        request = urllib_request.Request(url)
        request.get_method = lambda: 'DELETE'
        request.add_header('User-Agent', self._user_agent)
        for key in headers:
            request.add_header(key, headers[key])
        response = urllib_request.urlopen(request)
        return HttpResponse(response)

    def _fetch(self, url, form_data={}, headers={}, compression=True, jdata=False):
        """
        Perform an HTTP GET or POST request.

        Args:
            url (str): The URL to GET or POST.

            form_data (dict): A dictionary of form data to POST. If empty, the
            request will be a GET, if it contains form data it will be a POST.

        Kwargs:
            headers (dict): A dictionary describing any headers you would like
            to add to the request. (eg. ``{'X-Test': 'testing'}``)

            compression (bool): If ``True`` (default), try to use gzip
            compression.

        Returns:
            An :class:`HttpResponse` object containing headers and other
            meta-information about the page and the page content.
        """

        if form_data:
            method ="POST"
        else:
            method ="GET"

        r = getHtml(url
                , referer=''
                , headers=headers
                , save_cookie=False
                , sent_data=form_data
                , ignore404=False
                , ignore403=False
                , send_back_redirect=False
                , http_timeout=10
                , sucuri_solved=False
                , method=method
                , send_back_response=True
                , auto_encode_content=True
                , cookie_file=self._cookie_file
                )
        r = HttpResponse2(r)
        return r
        req = urllib_request.Request(url)
        if form_data:
            if jdata:
                form_data = json.dumps(form_data)
            elif isinstance(form_data, six.string_types):
                form_data = form_data
            else:
                form_data = urllib_parse.urlencode(form_data, True)
            form_data = form_data.encode('utf-8') if six.PY3 else form_data
            req = urllib_request.Request(url, form_data)
        req.add_header('User-Agent', self._user_agent)
        for key in headers:
            req.add_header(key, headers[key])
        if compression:
            req.add_header('Accept-Encoding', 'gzip')
        if jdata:
            req.add_header('Content-Type', 'application/json')
        host = req.host if six.PY3 else req.get_host()
        req.add_unredirected_header('Host', host)
        try:
            response = urllib_request.urlopen(req, timeout=15)
        except urllib_error.HTTPError as e:
            if e.code == 403 and 'cloudflare' in e.hdrs.get('Expect-CT', ''):
                import ssl
                ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
                handlers = [urllib_request.HTTPSHandler(context=ctx)]
                opener = urllib_request.build_opener(*handlers)
                try:
                    response = opener.open(req, timeout=15)
                except urllib_error.HTTPError as e:
                    if e.code == 403:
                        ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_1)
                        handlers = [urllib_request.HTTPSHandler(context=ctx)]
                        opener = urllib_request.build_opener(*handlers)
                        try:
                            response = opener.open(req, timeout=15)
                        except urllib_error.HTTPError as e:
                            response = e
            else:
                raise

        return HttpResponse(response)

class HttpResponse2:
    def __init__(self, response):
        self._response = response
        self._nodecode = False
    @property
    def content(self):
        return self._response.data
    def get_headers(self, as_dict=False):
        return self._response.headers
    def get_url(self):
##        Log(repr(dir(self._response)))
        return self._response.geturl()
    def nodecode(self, nodecode):
        self._nodecode = bool(nodecode)
        return self        
class HttpResponse:
    """
    This class represents a resoponse from an HTTP request.

    The content is examined and every attempt is made to properly decode it to
    Unicode unless the nodecode property flag is set to True.

    .. seealso::
        :meth:`Net.http_GET`, :meth:`Net.http_HEAD` and :meth:`Net.http_POST`
    """

    # content = ''
    """Unicode encoded string containing the body of the reponse."""

    def __init__(self, response):
        """
        Args:
            response (:class:`mimetools.Message`): The object returned by a call
            to :func:`urllib2.urlopen`.
        """
        self._response = response
        self._nodecode = False

    @property
    def content(self):
        html = self._response.read()
        encoding = None
        try:
            if self._response.headers['content-encoding'].lower() == 'gzip':
                html = gzip.GzipFile(fileobj=six.BytesIO(html)).read()
        except:
            pass

        if self._nodecode:
            return html

        try:
            content_type = self._response.headers['content-type']
            if 'charset=' in content_type:
                encoding = content_type.split('charset=')[-1]
        except:
            pass

        if encoding is None:
            epattern = r'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"'
            epattern = epattern.encode('utf8') if six.PY3 else epattern
            r = re.search(epattern, html, re.IGNORECASE)
            if r:
                encoding = r.group(1).decode('utf8') if six.PY3 else r.group(1)

        if encoding is not None:
            html = html.decode(encoding, errors='ignore')
        else:
            html = html.decode('ascii', errors='ignore') if six.PY3 else html
        return html

    def get_headers(self, as_dict=False):
        """Returns headers returned by the server.
        If as_dict is True, headers are returned as a dictionary otherwise a list"""
        if as_dict:
            hdrs = {}
            for item in list(self._response.info().items()):
                if item[0].title() not in list(hdrs.keys()):
                    hdrs.update({item[0].title(): item[1]})
                else:
                    hdrs.update({item[0].title(): ','.join([hdrs[item[0].title()], item[1]])})
            return hdrs
        else:
            return self._response.info()._headers if six.PY3 else [(x.split(':')[0].strip(), x.split(':')[1].strip()) for x in self._response.info().headers]

    def get_url(self):
        """
        Return the URL of the resource retrieved, commonly used to determine if
        a redirect was followed.
        """
        return self._response.geturl()

    def nodecode(self, nodecode):
        """
        Sets whether or not content returns decoded text
        nodecode (bool): Set to ``True`` to allow content to return undecoded data
        suitable to write to a binary file
        """
        self._nodecode = bool(nodecode)
        return self
#__________________________________________________________________________
# wrapper to allow cookie extraction from urllib3 proxy/socks requests
class FakeRequest(object):
    def __init__(self, full_url, headers):
        self.full_url = full_url
        self._headers = headers.copy()
    @property
    def headers(self):
        return self._headers
    @property
    def url(self):
        return self.full_url
    def get_full_url(self):
        return self.full_url
    def is_unverifiable(self, *args, **kargs):
        return True
    def get_origin_req_host(self, *args, **kargs):
        return self.full_url   
#__________________________________________________________________________
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    from xml.dom import minidom
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None
    try:
        guisettings_xml = minidom.parse(xbmc.translatePath('special://home/userdata/guisettings.xml'))
        usehttpproxy = get_gui_setting(guisettings_xml, 'usehttpproxy')
        if usehttpproxy and usehttpproxy.lower()=='true':
            httpproxytype = get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = get_gui_setting(guisettings_xml, 'httpproxypassword')
    except:
        traceback.print_exc()
##        raise
##        pass
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
##        Log(repr(proxy_info))
        return proxy_info

def Log(string, level=xbmc.LOGNONE):
    xbmc.log(repr(string), level)
def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=20
            , sucuri_solved=False
            , method="GET"
            , send_back_response=False
            , auto_encode_content=False
            , cookie_file=None):

##    Log(repr(dir(pool_proxy)), xbmc.LOGNONE)
##    return

##    Log(repr(xbmc.getIPAddress()),xbmc.LOGNONE)
    ip = xbmc.getIPAddress() #in case we don't have IP
    if not ip or ip.startswith('169.254'):
        if send_back_redirect == True:
            return None, ''
        return None

    if not cookie_file:
        import xbmcaddon, os
        profileDir = xbmcaddon.Addon().getAddonInfo('profile')
        profileDir = xbmc.translatePath(profileDir).decode("utf-8")
        cookie_file = os.path.join(profileDir, 'cookies.lwp')

    cj = cookielib.LWPCookieJar(cookie_file)
    try:
        cj.load(ignore_discard=True, ignore_expires=True)
        cj._now = int(time.time()) #module does not set this if I use internal functions
    except:
        cj.save(cookie_file, ignore_expires=True, ignore_discard=True)
        cj._now = int(time.time())
        pass
    stream=False
    response = None
    redirected_url = None

    Log("getHtml method='{}', url='{}', referer='{}', headers='{}', sent_data='{}', save_cookie='{}', sucuri_solved='{}'".format(
        repr(method)
        ,repr(url)
        ,repr(referer)
        ,repr(headers)
        ,repr(sent_data)
        ,repr(save_cookie)
        ,repr(sucuri_solved)
        )
        )

##    ##cookiedump
####    Log(C.cookiePath)
##    this_domain = urlparse.urlparse(url).netloc
####    Log(this_domain)
####    Log(repr(cj))
##    for cookie in cj:
####        Log(cookie.domain)
####        Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
##        if this_domain.endswith(cookie.domain):
##        #if cookie.domain.endswith(this_domain):
##            Log("filtered cookie={}".format(repr(cookie)), xbmc.LOGNONE)
####    return
                        
    try:
                
        if headers is None:
            pass
####            Log("copying default header dictionary")
##            getHtml_headers = C.DEFAULT_HEADERS.copy()
##            r_c_u_a = C.USER_AGENT #random.choice(C._USER_AGENTS)
##    ##        Log("r_c_u_a={}".format(r_c_u_a), xbmc.LOGNONE)
##            getHtml_headers['User-Agent'] = r_c_u_a
##    ##        Log("rand choice getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
        else:
            getHtml_headers = headers #headers.copy()
##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
            
        if len(referer) > 1:
            getHtml_headers['Referer'] = referer

        if sent_data:
##            Log(repr(sent_data))
##            if jdata:
##                form_data = json.dumps(form_data)
##            elif isinstance(form_data, six.string_types):
##                form_data = form_data
##            else:
##                form_data = urllib_parse.urlencode(form_data, True)
##            form_data = form_data.encode('utf-8') if six.PY3 else form_data
            if type(sent_data) is dict:
##                sent_data = json.dumps(sent_data)
                sent_data = urllib_parse.urlencode(sent_data, True)
##            Log(repr(sent_data))
            getHtml_headers['Content-Length'] = str(len(sent_data))
##        Log("getHtml_headers='{}'".format(getHtml_headers))



        #
        # I don't know how to use cookieJar with SOCKS proxy
        #
        socks_cookies = ''
        this_domain = urlparse.urlparse(url).netloc
##        Log(this_domain)
        temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
##        Log("type temp_cookiejar='{}'".format(type(temp_cookiejar)))
##        Log("type cj='{}'".format(type(cj)))
        if cj:
            for cookie in cj:
##                Log("pre-request cookie='{}'".format(cookie))
                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                    socks_cookies += "{}={};".format(cookie.name,cookie.value)
                    temp_cookiejar.set_cookie(cookie)
    ##                    Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)
##            Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)

##            for cookie in temp_cookiejar: #verification during development 
##                Log("temp_cookiejar_cookie={}".format(repr(cookie)))
##                pass

            if 'Cookie' in getHtml_headers:
    ##            Log("getHtml_headers['Cookie']={}".format(getHtml_headers['Cookie']), xbmc.LOGNONE)
                socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
            if not socks_cookies == '':
                getHtml_headers['Cookie'] = (socks_cookies).strip(';')


    
##        Log("final getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
##        return "" #getHtml_headers testing/dev

        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
##            Log(socks_string )
            proxy = SOCKSProxyManager(proxy_url=socks_string)

##            Log(repr(proxy) )
            
            socks_response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            data = socks_response.data
            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None



        elif (socks_proxy_info['uhp'] <= -0) :
            
            if socks_proxy_info['ps'] is not None:
                proxy_string = "http://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                proxy = ProxyManager(proxy_url=proxy_string)
                #proxy = proxy_proxy
            else:
                proxy_string = ''
                #proxy = PoolManager()
                proxy = pool_proxy

##            Log(repr(proxy) )

            response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
##            Log(repr(type(socks_response)))
##            Log(repr(socks_response.headers))
##            Log(repr(dir(socks_response)))
##            Log(repr(socks_response.DECODER_ERROR_CLASSES))
##            Log(repr(socks_response.headers['Set-Cookie']))
##            Log(repr(dir(response)))
##            Log(repr(dir(response.info())))
##            Log(repr(dir(response.retries)))
##            Log(repr(dir(response.retries.history)))
##            Log(repr(response.retries.history))
##            Log(repr(dir(response.connection)))
##            Log(repr(dir(response.get_redirect_location())))

 #'get_redirect_location', 'getheader', 'getheaders', 'geturl',
##            Log(repr(dir(response.from_httplib(response))))
##            qq = response.from_httplib(response)
##            Log(repr(dir(qq)))
 
            #make urllib3.response more like requests.response by adding cookiejar and status
            temp_jar = cookielib.LWPCookieJar()
            fake_request = FakeRequest(url, response.getheaders() )
            requests.cookies.extract_cookies_to_jar(temp_jar, fake_request, response)
            response.cookies = temp_jar
            response.status_code = response.status
            
            data = response.data

        
##            Log(data[:500])
##            Log(repr(response.getheaders()))
##            Log(repr(response.geturl()))
##            Log(repr(response.url()))
##            Log(repr(response))            
            redirected_url = response.geturl()
            if not url == redirected_url:
                if not ('http' in redirected_url):
                    if response.retries is not None and len(response.retries.history):
                        redir_domain = response.retries.history[-1].url
##                        Log(repr(redir_domain))
                        redirected_url = redir_domain #+ redirected_url
        

                    
                    
                Log("redirected_url={}".format(repr(redirected_url)))
            else:
                redirected_url = None

            
            
            
        elif (socks_proxy_info['uhp'] <= 0) :

            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
            else: proxies = {}
##            Log("proxies='{}'".format(repr(proxies)))

##            #either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
##            if C.DEBUG:
##                verify=False
##                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
##            else:
##                verify = C.certPath

            #https://requests.readthedocs.io/en/master/api/#requests.Request
            response = my_http_session.request(
                method
                , url=url
                , headers=getHtml_headers
                , data = sent_data
                , stream=stream
                , allow_redirects=True
                , proxies=proxies
                , cookies=temp_cookiejar
                , verify=verify      
                )

##            Log(repr(type(response)))
##            Log(repr(response.headers))
##            Log(repr(dir(response)))
##            Log(repr(response.headers['Set-Cookie']))
            
            if response.status_code == 429:
                response.raise_for_status()

##            if response.headers['Content-Encoding'] == 'gzip':
##                import gzip, StringIO
##                buf = StringIO.StringIO( e.read())
##                f = gzip.GzipFile(fileobj=buf)
##                data = f.read()
##                f.close()
##            else:
            data = response.content

##            Log(data[:1000])
            
            redirected_url = response.url 
            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
            else: redirected_url = None


        if auto_encode_content: 
            if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
                content_type = response.headers['Content-Type']
                if 'charset=' in content_type:
                    ct = content_type.split('charset=')[1]
##                    Log('decoding as {}'.format(repr(ct)))
                    data = data.decode(ct)
                    


            
        if sucuri_solved == False:
            if 'Server' in response.headers:
                if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                    Log(repr(response.status_code))
                    import sucuri
                    if sucuri.SCRIPT_HEADER in data:
                        cookie = sucuri.Set_Cookie(data)
                        cj.set_cookie(cookie)
                        cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
    ##                            raise
                        return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)



##            if response:
##                #Log("response='{}'".format(repr(response.info())), xbmc.LOGNONE)
##                if 'Server' in response.headers:
##                    if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
##                        Log(repr(response.status_code))
##                        import sucuri
##                        if sucuri.SCRIPT_HEADER in data:
##                            cookie = sucuri.Set_Cookie(data)
##                            cj.set_cookie(cookie)
##                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
####                            raise
##                            return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)
##            elif socks_response:
##                if 'Server' in socks_response.headers:
##                    if socks_response.status in (200,301)  and socks_response.headers[ 'Server' ] == "Sucuri/Cloudproxy":
##                        import sucuri
##                        if sucuri.SCRIPT_HEADER in data:
##                            cookie = sucuri.Set_Cookie(data)
##                            cj.set_cookie(cookie)
##                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
####                            raise
##                            return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)

##        Log("data='{}'".format(data))


        if not (save_cookie == False) and (cj is not None) :
            r = response
            this_domain = urlparse.urlparse(url).netloc
##            if isinstance(socks_response, urllib3.response.HTTPResponse):
##                r = socks_response
##            else:
##                r = response
##            if isinstance(socks_response, urllib3.response.HTTPResponse):
##                #r = socks_response
####                Log("socks_response['Set-Cookie']={}".format(repr(socks_response.headers)))
##                r = requests.Response()
####f_request = FakeRequest("https://www.porntrex.com/latest-updates/11/")
####f_response = FakeResponse( {'Set-Cookie': 'PHPSESSID=9fe8ec45a9022580c047a96a3522036c; path=/; domain=.porntrex.com; SameSite=Lax
##                #, kt_ips=76.10.152.152; expires=Fri, 12-Mar-2021 17:22:45 GMT; Max-Age=86400; path=/; domain=.porntrex.com; SameSite=Lax', 'Expires': 'Thu, 19 Nov 1981 08:52:00 GMT'
##                #, 'Vary': 'Accept-Encoding', 'Server': 'openresty', 'Connection': 'keep-alive', 'Pragma': 'no-cache', 'Cache-Control': 'no-store, no-cache, must-revalidate', 'Date': 'Thu, 11 Mar 2021 17:22:45 GMT', 'Access-Control-Allow-Origin': '*', 'Content-Type': 'text/html; charset=utf-8'} )
####Log(repr(f_request))
####Log(repr(dir(f_request)))
####Log(repr(f_request.is_unverifiable()))
####t_cj = cookielib.LWPCookieJar()
####t_cj.extract_cookies(f_response,f_request)
####Log("t_cj={}".format(repr(t_cj)))
##                f_request = FakeRequest(url)
##                f_response = FakeResponse(socks_response.headers.copy())
##                t_cj = cookielib.LWPCookieJar()
##                t_cj.extract_cookies(f_response,f_request)
##                r.cookies = t_cj
####                Log(repr(r.cookies))                
####                r.headers = socks_response.headers.copy()
####                raise Exception('cookie processing TBD once I have a socks proxy to test with')
##            else:
##                r = response
            if r is not None:
                for cookie in r.cookies:
                    Log("r.cookie={}".format(repr(cookie)))
                    if save_cookie == True: #save as this domain even if cookie is not marked so
                         cookie.domain = this_domain
                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
##                        Log("saving cookie={}".format(repr(cookie)))
                        cj.set_cookie(cookie)
                cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

##                    ### it turns out that using r.headers[ 'Set-Cookie' ] will join
##                    ###     multiple set-cookie headers using a comma, instead of ','
##                    ###   which means we loose information if I try and use some other libraries
##                    ### For now, just skip this - once I have a socks proxy to test with I can
##                    ###    try something else....
##                        
####                Log(repr(r.cookies))
####                Log(repr(r.headers))
####                for a in r.headers[ 'Set-Cookie' ]:
####                    Log(a)
##                if 'Set-Cookie' in r.headers:
##                    fake_response = FakeResponse(r.headers)
####                    Log("1fake_response={}".format(repr(fake_response)))
####                    Log("2fake_response={}".format(repr(fake_response.info())))
####                    Log("3fake_response={}".format(repr(fake_response.info().getheaders("Set-Cookie2") )))
##                    Log("4fake_response={}".format(repr(fake_response.info().getheaders("Set-Cookie") )))
##                    fake_request = FakeRequest(url)
####                    Log("1fake_request={}".format(repr(fake_request.get_full_url())))
##                    for cookie in cj.make_cookies(fake_response, fake_request):
##                        Log("fake cookie={}".format(repr(cookie)))
##                    Log('done')
##
##                    sc = [r.headers[ 'Set-Cookie' ]]
##                    Log("sc={}".format(sc))
##                    
##                    n_c_t = cj._normalized_cookie_tuples(cookielib.parse_ns_headers(sc))
##                    for tup in n_c_t:
##                        Log("tup={}".format(repr(tup)))
##                        #because i am passing request=None later; I need to makes sure that domain is part of the tupple
####                        Log("tup[2]={}".format(repr(tup[2])))
##                        if 'domain' not in tup[2]: tup[2]['domain']=this_domain
####                        Log("tup[2]={}".format(repr(tup[2])))
##                        cookie = cj._cookie_from_cookie_tuple(tup, None)
####                        Log("cookie={}".format(repr(cookie)))
##                        try:
##                            if not cookie.discard:
##                                if save_cookie == True: #save as this domain event if cookie is not marked so
##                                     cookie.domain = this_domain
##                                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
##                                    cj.set_cookie(cookie)
##                        except:
##                            traceback.print_exc()
####                            Log("sc={}".format(repr(sc)))
####                            Log("tup={}".format(repr(tup)))
####                            Log("tup[2]={}".format(repr(tup[2])))
####                            Log("cookie={}".format(repr(cookie)))
##                            raise
##                            
####                    #todo: use cookielib.make_cookies - with fake request/response if necessary
####                    for cookie in SetCookie_To_Array_Of_Cookie(r.headers[ 'Set-Cookie' ]) :
####                        Log("cookie={}".format(repr(cookie)))
####                        if not cookie.discard:
####                            if save_cookie == True: #save as this domain event if cookie is not marked so
####                                 cookie.domain = this_domain
####                            if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
####                                cj.set_cookie(cookie)
##
##                    cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
####                    Log("saving cookiejar")
####            for cookie in cj:
######                if cookie.domain.endswith(this_domain):
####                Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
####            Log("reloading cookiejar")
####            cj = None
####            cj = cookielib.LWPCookieJar(C.cookiePath)
####            cj.load(ignore_discard=True, ignore_expires=True)
####            for cookie in cj:
######                if cookie.domain.endswith(this_domain):
####                Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)                


    except requests.HTTPError as e:
        Log("repr(e)='{}'".format(repr(e)))
##        Log("dir(e)='{}'".format(dir(e)))
##        Log("dir(e.response)='{}'".format(dir(e.response)))
##        Log("e.errno='{}'".format(e.errno))
##        Log("e.response.content='{}'".format(e.response.content))
##        Log("repr(e.response)='{}'".format(repr(e.response)))
        if e.response.status_code == 429 and 'ccapimg' in e.response.content:
            keyname = re.search('key=([^"]+)"', e.response.content).group(1)
            from resolveurl.plugins.lib import captcha_lib
            img_url = referer + '/ccapimg?key=' + keyname
##            Log("img_url='{}'".format(img_url))
            img = captcha_lib.write_img(img_url)
            solution = captcha_lib.get_response(img, y=225)
            form_data = {'secimgkey': (None, keyname), 'secimginp': (None, solution)}
            hdr = getHtml_headers
            if 'Referer' in hdr:
                del hdr['Referer']
            hdr['referer'] = url
            try:
                resp = requests.post(url, files=form_data, headers=hdr)
                resp.encoding = 'ISO-8859-1'
                result = resp.text
            finally:
                if resp: resp.close()
            return result

        raise
        
    except urllib2.HTTPError as e:
        Log(repr(e.info().get('Content-Encoding')))
        
        if e.info().get('Content-Encoding') == 'gzip':
            import StringIO
            buf = StringIO.StringIO( e.read())
            import gzip
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = e.read()
        #Log(data)  #errors='ignore'
        #notify('Oh oh',data)
        if e.code == 503 and 'cf-browser-verification' in data:
            import cloudflare
            data = cloudflare.solve(url, cj, USER_AGENT)
            
        elif e.code == 404 and ignore404 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        elif e.code == 403 and ignore403 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data
            
        else:
            traceback.print_exc()
            raise urllib2.HTTPError()

    except Exception as e:
        traceback.print_exc()
        if 'SSL23_GET_SERVER_HELLO' in str(e):
            notify('Oh oh','Python version too old - update to Krypton or FTMC')
            raise urllib2.HTTPError()
        else:
##            Notify(msg="It looks like '{}' is down.".format(url), duration=200)
            raise
        return None

##    Log('here')
    if send_back_response == True:
        return response
##    Log('here2')
    if send_back_redirect == True:
        return data, redirected_url
    
    if response:
        response.close()

    return data
