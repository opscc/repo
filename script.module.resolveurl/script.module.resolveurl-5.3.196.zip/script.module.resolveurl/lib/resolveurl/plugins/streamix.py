"""
    Plugin for ResolveURL
    Copyright (C) 2026 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
from six.moves import urllib_parse
from resolveurl import common
from resolveurl.lib import helpers
from resolveurl.resolver import ResolveUrl, ResolverError

from resolveurl.lib.log_utils import Log,LogR,LOGWARNING,LOGINFO,LOGERROR
import traceback
        
class StreamixResolver(ResolveUrl):
    name = 'Streamix'
    domains = ['streamix.so', 'stmix.io', 'vidara.so', 'vidara.to']
    pattern = r'(?://|\.)((?:st(?:rea)?mix|vidara)\.(?:so|io|to))/(?:e|v)/([0-9a-zA-Z]+)'

    main_url_templates = {
        'https://{host}/api/stream'
##        , 'https://{host}/ajax/stream?filecode={media_id}'
        }

    def get_media_url(self, host, media_id, subs=False):

        for url_template in self.main_url_templates:
            Log(url_template, LOGWARNING)
            web_url = self.get_url(host, media_id, url_template)
            ref = urllib_parse.urljoin(web_url, '/')
            headers = {'User-Agent': common.FF_USER_AGENT,
                       'Referer': ref}
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0
##Accept: */*
##Accept-Language: en-US,en;q=0.9
##Accept-Encoding: gzip, deflate, br
##Referer: https://vidara.to/e/RSNi7Y1M1fB9
##Content-Type: application/json
##Content-Length: 42
##Origin: https://vidara.to
##DNT: 1
##Sec-GPC: 1
##Connection: keep-alive
##Sec-Fetch-Dest: empty
##Sec-Fetch-Mode: cors
##Sec-Fetch-Site: same-origin
##Priority: u=4
##
##{"filecode":"RSNi7Y1M1fB9","device":"web"}
            if 'filecode' not in url_template:
                headers['Accept'] = '*/*'
                headers['Accept-Language'] = 'en-US,en;q=0.9'
                headers['Accept-Encoding'] = 'gzip, deflate, br'
                headers['Referer'] = f'https://{host}/e/{media_id}'
                headers['Content-Type'] = 'application/json'
                headers['Origin'] = f'https://{host}'
                headers['DNT'] = '1'
                headers['Sec-GPC'] = '1'
                headers['Connection'] = 'keep-alive'
                headers['Sec-Fetch-Dest'] = 'empty'
                headers['Sec-Fetch-Mode'] = 'cors'
                headers['Sec-Fetch-Site'] = 'same-origin'
                headers['Priority'] = 'u=4'
                form_data = {"filecode":media_id,"device":"web"}
##                LogR(headers, LOGERROR)
##                Log(form_data, LOGERROR)
                html = self.net.http_POST(
                    web_url
                    , form_data = json.dumps(form_data)
                    , headers=headers).content
##                Log(html)
##                return
            else:
                html = self.net.http_GET(web_url, headers=headers).content
            r = json.loads(html)
            if 'streaming_url' in r.keys():
                headers.update({'Referer': ref, 'Origin': ref[:-1]})
                url = r.get('streaming_url') + helpers.append_headers(headers)
                if subs:
                    subtitles = {}
                    s = r.get('subtitles')
                    if s:
                        subtitles = {x.get('language'): x.get('file_path') for x in s}
                    return url, subtitles
                return url

        raise ResolverError("Unable to locate stream URL.")

    def get_url(self, host, media_id, template):
        #template = 'https://{host}/ajax/stream?filecode={media_id}'
        if 'vidara' in host:
            template = template.replace('/ajax/', '/api/')
        return self._default_get_url(host, media_id, template=template)
