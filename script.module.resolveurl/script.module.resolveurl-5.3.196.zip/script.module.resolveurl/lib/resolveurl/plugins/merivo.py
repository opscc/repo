"""
    Plugin for ResolveUrl
    Copyright (C) 2023 shellc0de, gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

'''
POST https://merivo.biz/api/stream HTTP/1.1
Host: merivo.biz
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0
Accept: */*
Accept-Language: en-US,en;q=0.9
Accept-Encoding: gzip, deflate, br, zstd
Referer: https://merivo.biz/e/FgLOwGGRO4YA
Content-Type: application/json
Content-Length: 42
Origin: https://merivo.biz
DNT: 1
Sec-GPC: 1
Connection: keep-alive
Cookie: vs_2852_2026-08-21=1
Sec-Fetch-Dest: empty
Sec-Fetch-Mode: cors
Sec-Fetch-Site: same-origin
Priority: u=4

{"filecode":"FgLOwGGRO4YA","device":"web"}
'''

import json
import re
from six.moves import urllib_parse
from resolveurl.lib import helpers
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError
from resolveurl.lib.log_utils import Log,LogR,LOGWARNING,LOGINFO

##import xbmc
##def Log(msg):
##    xbmc.log(msg, xbmc.LOGNONE)
#______________________________________________________________________________
# class
class MerivoResolver(ResolveUrl):
    name = 'Merivo'
    domains = [
        'merivo.biz',
        ]
    pattern = r'(?://|\.)(merivo' \
              r'\.biz)' \
              r'/e/([0-9a-zA-Z$:/._-]+)'

#______________________________________________________________________________
# get_media_url
    def get_media_url(self, host, media_id):

        LogR((self, host, media_id),LOGINFO)

##        edata = self.net.http_POST(urllib_parse.urljoin(web_url, '/dl'), pdata, headers=headers).content
##        LogR(dir(self.net.http_POST),LOGWARNING)

        web_url = self.get_url(host, media_id)
        headers = {
            'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
            'Accept' : '*/*',
            'Accept-Language' : 'en-US,en;q=0.9',
            'Accept-Encoding' : ' gzip, deflate, br',
            'Referer' : 'https://' + host + '/e/' + media_id,
            'Content-Type' : 'application/json',
            'Origin' : 'https://' + host,
            'DNT' : '1',
            'Sec-GPC' : '1',
            'Connection' : 'keep-alive',
            'Sec-Fetch-Dest' : 'empty',
            'Sec-Fetch-Mode' : 'cors',
            'Sec-Fetch-Site' : 'same-origin',
            'Priority' : 'u=4',
            }

        post_data = {
            "filecode": media_id,
            "device":"web",
            }
        edata = self.net.http_POST(
            web_url,
            form_data=json.dumps(post_data),
            headers=headers,
            ).content
##        LogR(edata,LOGINFO)
        edata = json.loads(edata)
##        LogR(edata,LOGINFO)
        surl = edata.get('streaming_url')
##        LogR(surl,LOGINFO)
        return surl

        raise ResolverError('Video not found')

        if '$$' in media_id:
            media_id, referer = media_id.split('$$')
            referer = urllib_parse.urljoin(referer, '/')
        else:
            referer = False

        if '/' in media_id:
            media_id = media_id.split('/')[0]

        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': common.RAND_UA}
        if referer:
            headers.update({'Referer': referer})

        html = self.net.http_GET(web_url, headers=headers).content
        if '<h1>Page not found</h1>' in html:
            web_url = web_url.replace('/e/', '/d/')
            html = self.net.http_GET(web_url, headers=headers).content

        regex = '<iframe src="(.+?)"'
        r = re.search(regex, html, re.DOTALL)
        if r:
            r = r.group(1)
            headers.update({'Referer': 'https://filemoon.to/'})
            headers.update({'Accept-Language': 'en-US,en;q=0.9'})
            headers.update({'Sec-Fetch-Dest': 'iframe'})
             
            html = self.net.http_GET(r, headers=headers).content


        html += helpers.get_packed_data(html)
        r = re.search(r'var\s*postData\s*=\s*(\{.+?\})', html, re.DOTALL)
        if r:
            r = r.group(1)
            pdata = {
                'b': re.findall(r"b:\s*'([^']+)", r)[0],
                'file_code': re.findall(r"file_code:\s*'([^']+)", r)[0],
                'hash': re.findall(r"hash:\s*'([^']+)", r)[0]
            }
            headers.update({
                'Referer': web_url,
                'Origin': urllib_parse.urljoin(web_url, '/')[:-1],
                'X-Requested-With': 'XMLHttpRequest'
            })
            edata = self.net.http_POST(urllib_parse.urljoin(web_url, '/dl'), pdata, headers=headers).content
            edata = json.loads(edata)[0]
            surl = helpers.tear_decode(edata.get('file'), edata.get('seed'))
            if surl:
                headers.pop('X-Requested-With')
                headers["verifypeer"] = "false"
                return surl + helpers.append_headers(headers)
        else:
            r = re.search(r'sources:\s*\[{\s*file:\s*"([^"]+)', html, re.DOTALL)
            if r:
                headers.update({
                    'Referer': web_url,
                    'Origin': urllib_parse.urljoin(web_url, '/')[:-1]
                    #,"verifypeer": "false"
                })
                return r.group(1) + helpers.append_headers(headers)
            else:
                Log('sources2 not found')
                pass
                
        Log('Video not found',LOGWARNING)
        return None
##        raise ResolverError('Video not found')

#______________________________________________________________________________
    def get_url(self, host, media_id, template='https://{host}/e/{media_id}'):
        return "https://merivo.biz/api/stream"
##        return self._default_get_url(host, media_id, template)
        #return self._default_get_url(host, media_id, template='https://{host}/ptsd/{media_id}')

#______________________________________________________________________________
# end of file
