"""
    Plugin for ResolveUrl
    Copyright (C) 2023 shellc0de, gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
import re
from six.moves import urllib_parse
from resolveurl.lib import helpers
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError
from resolveurl.lib.log_utils import Log,LogR,LOGWARNING,LOGINFO

"""
POST https://playmate.to/api/s HTTP/1.1
Host: playmate.to
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0
Accept: */*
Accept-Language: en-US,en;q=0.9
Accept-Encoding: gzip, deflate, br
Referer: https://playmate.to/embed/iGdq3gshYrcO
Content-Type: application/json
Content-Length: 30
Origin: https://playmate.to
DNT: 1
Sec-GPC: 1
Connection: keep-alive
Cookie: vs_2312_2026-08-24=1
Sec-Fetch-Dest: empty
Sec-Fetch-Mode: cors
Sec-Fetch-Site: same-origin
Priority: u=4

{"c":"iGdq3gshYrcO","d":"web"}
"""
##import xbmc
##def Log(msg):
##    xbmc.log(msg, xbmc.LOGNONE)
#______________________________________________________________________________
# class
class PlaymateResolver(ResolveUrl):
    name = 'Playmate'
    domains = [
        'playmate.to',
        ]
    pattern = r'(?://|\.)(playmate' \
              r'\.to)' \
              r'/embed/' \
              r'([0-9a-zA-Z$:/._-]+)'

#______________________________________________________________________________
# get_media_url
    def get_media_url(self, host, media_id):

        LogR((self, host, media_id),LOGINFO)

##        edata = self.net.http_POST(urllib_parse.urljoin(web_url, '/dl'), pdata, headers=headers).content
##        LogR(dir(self.net.http_POST),LOGWARNING)

        web_url = self.get_url(host, media_id)
        headers = {
            'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
            'Accept' : '*/*',
            'Accept-Language' : 'en-US,en;q=0.9',
            'Accept-Encoding' : ' gzip, deflate, br',
            'Referer' : 'https://' + host + '/embed/' + media_id,
            'Content-Type' : 'application/json',
            'Origin' : 'https://' + host,
            'DNT' : '1',
            'Sec-GPC' : '1',
            'Connection' : 'keep-alive',
            'Sec-Fetch-Dest' : 'empty',
            'Sec-Fetch-Mode' : 'cors',
            'Sec-Fetch-Site' : 'same-origin',
            'Priority' : 'u=4',
            }

        post_data = {
            "c": media_id,
            "d":"web",
            }
        edata = self.net.http_POST(
            web_url,
            form_data=json.dumps(post_data),
            headers=headers,
            ).content
##        LogR(edata,LOGINFO)
        edata = json.loads(edata)
##        LogR(edata,LOGINFO)
        surl = edata.get('sx')
##        LogR(surl,LOGINFO)

        return surl
        raise ResolverError('Video not found')
      

#______________________________________________________________________________
    def get_url(self, host, media_id, template='https://{host}/e/{media_id}'):
        return "https://playmate.to/api/s"
##        return self._default_get_url(host, media_id, template)
        #return self._default_get_url(host, media_id, template='https://{host}/ptsd/{media_id}')

#______________________________________________________________________________
# end of file
