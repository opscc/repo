"""
    Plugin for ResolveURL
    Copyright (C) 2023 shellc0de

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resolveurl.lib import helpers
from resolveurl.plugins.__resolve_generic__ import ResolveGeneric

from resolveurl.lib.log_utils import Log,LogR,LOGWARNING,LOGINFO,LOGERROR
import re
import traceback

##[{'debridonly': False, 'direct': True, 'info': ''
##  , 'language': 'en', 'quality': 'SD', 'source': 'gw3ewq421d.p2pplay.pro'
##  , 'url': 'https://gw3ewq421d.p2pplay.pro/#3pacty', 'provider': 'fastflix'}
## , {'debridonly': False, 'direct': True, 'info': '', 'language': 'en'
##    , 'quality': 'SD', 'source': 'hls.uniquestream.net',
#'url': 'https//hls.uniquestream.net/local_embed?id=H5iszo93ljqen5mybejct9'
#, 'provider': 'fastflix'},
#{'debridonly': False, 'direct': True, 'info': ''

class UniquestreamResolver(ResolveGeneric):
    name = 'Uniquestream'
    domains = [r'uniquestream\.net']
    pattern = r'(hls\.uniquestream\.net)/local_embed\?id=([0-9a-zA-Z]+)'
##
    main_url_templates = {
          r'https://{host}/local_embed?id={media_id}'
##        , r'https://{host}/ajax/stream?filecode={media_id}'
        }
            
    def get_media_url(self, host, media_id, subs=False):
        LogR((host, media_id), LOGERROR)


        for url_template in self.main_url_templates:
            Log(url_template, LOGWARNING)
            web_url = self.get_url(host, media_id, url_template)
            LogR(web_url, LOGWARNING)

            headers = {  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'
                       , 'Accept': '*/*'
                       , 'Accept-Language': 'en-US,en;q=0.9'
                       , 'Accept-Encoding': 'gzip, deflate, br'
                       , 'Sec-Fetch-Storage-Access': 'none'
                       , 'DNT': '1'
                       , 'Sec-GPC': '1'
                       , 'Connection': 'keep-alive'
                       , 'Referer': 'https://play1.netembed.club/'
                       , 'Upgrade-Insecure-Requests': '1'
                       , 'Sec-Fetch-Dest': 'iframe'
                       , 'Sec-Fetch-Mode': 'navigate'
                       , 'Sec-Fetch-Site': 'cross-site'
                       , 'Priority': 'u=4'
                    }
            html = self.net.http_GET(web_url,headers=headers).content
            LogR(html, LOGWARNING)
##url = r.get('streaming_url') + helpers.append_headers(headers)
##        media_url = None
        media_url = re.findall(r"let url = '(.+?)'", html)[0]

##        media_url = helpers.get_media_url(
##            self.get_url(host, media_id),
##            patterns=[r'''sources:\s*\[{(?:src|file):\s*["'](?P<url>[^"']+)''']
##        )

        Log(media_url, LOGWARNING)
        return media_url

    def get_url(self, host, media_id, template):
        #template = 'https://{host}/ajax/stream?filecode={media_id}'
        return self._default_get_url(host, media_id, template=template)    
