"""
Plugin for ResolveUrl
Copyright (C) 2020 gujal

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""

import json
import base64
import traceback
from resolveurl.plugins.lib import helpers
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError


class VidCloud9Resolver(ResolveUrl):
    name = "vidcloud9.com"
    domains = ['vidcloud9.com', 'vidnode.net', 'vidcloud9.co']
    pattern = r'(https?:.+?(?:vidcloud9|vidnode)\.(?:com|net|co))(?:\/public\/dist)?\/(?:streaming|load|index)\.(?:php|html)\?id=([0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        headers = {
            'User-Agent': common.FF_USER_AGENT
            ,'Referer': 'https://{0}/'.format(host)
            ,'X-Requested-With': 'XMLHttpRequest'
            }
##        import xbmc
##        xbmc.log('here'+repr(web_url),xbmc.LOGNONE)
        js_data = self.net.http_GET(web_url, headers=headers).content
##        xbmc.log(repr(js_data),xbmc.LOGNONE)
        try:
            js_data = json.loads(js_data)
            sources = js_data.get('source', None)
            if sources:
                sources = [(source.get('label'), source.get('file')) for source in sources]
                headers.pop('X-Requested-With')
                source = helpers.pick_source(helpers.sort_sources_list(sources))
                if 'goto.php' in source:
                    source = source.split('url=')[1]
                    source = base64.b64decode(source[:10] + source[53:]).decode('ascii')
                return source + helpers.append_headers(headers)
        except ValueError:
            import urllib
            url = web_url + "|{}&token=/hls/".format( urllib.urlencode(headers)  )
            return url
        except:
            traceback.print_exc()
        raise ResolverError('Video not found')

    def get_url(self, host, media_id):
        template='https://vidcloud9.com/ajax.php?id={media_id}'
        import time
        try:
            template = '{host}/playlist/{media_id}/'+str(int(time.time()) * 1000)
        except:
            traceback.print_exc()
            raise
        return self._default_get_url(host, media_id, template)
