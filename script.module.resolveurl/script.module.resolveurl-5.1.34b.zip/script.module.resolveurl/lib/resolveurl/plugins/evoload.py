"""
    Plugin for ResolveURL
    Copyright (C) 2021 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
from resolveurl.plugins.lib import helpers
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError


class EvoLoadResolver(ResolveUrl):
    name = "evoload"
    domains = ["evoload.io"]
    pattern = r'(?://|\.)(evoload\.io)/(?:e|f|v)/([0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id):

        import xbmc
        import re
        
        surl = 'https://evoload.io/SecurePlayer'
        rurl = 'https://{0}/'.format(host)
        headers = {
            'User-Agent': common.FF_USER_AGENT
            ,'Referer': rurl
            ,'Accept': '*/*'
            }

        try: #worked 2021-07
            
            jsx_url = 'https://cd2.evosrv.com/html/jsx/e.jsx'
            html = self.net.http_GET(jsx_url, headers).content
##            xbmc.log(repr(html),xbmc.LOGNONE)
            regex = "captcha_pass = '([^']+?)'"
##            xbmc.log(repr(regex),xbmc.LOGNONE)
            captcha_pass = re.findall(regex, html, re.DOTALL)
##            xbmc.log(repr(captcha_pass),xbmc.LOGNONE)
            if captcha_pass: captcha_pass=captcha_pass[0]
            xbmc.log(repr(captcha_pass),xbmc.LOGNONE)

            regex = "var csrv_token.+?get\('([^']+?)'"
##            xbmc.log(repr(regex),xbmc.LOGNONE)
            captcha_token_url = re.findall(regex, html, re.DOTALL)
##            xbmc.log(repr(captcha_token_url),xbmc.LOGNONE)
            if captcha_token_url: captcha_token_url=captcha_token_url[0]
            xbmc.log(repr(captcha_token_url),xbmc.LOGNONE)


            headers.update({
                'Origin': rurl[:-1]
                ,'Content-Type': 'application/json;charset=UTF-8'
                ,'Accept': 'application/json, text/plain, */*'
                ,'Accept-Encoding': 'gzip, deflate, br'
                ,'Accept-Language': 'en-US,en;q=0.9'
                })
            xbmc.log(repr(headers),xbmc.LOGNONE)
            csrv_token = self.net.http_GET(captcha_token_url, headers).content
            xbmc.log(repr(csrv_token),xbmc.LOGNONE)

            edata = {
                'code': media_id
                ,'token': 'ok'
                ,'csrv_token': str(csrv_token)
                ,'pass': captcha_pass
                ,'reff': ''
                }
            xbmc.log(repr(edata),xbmc.LOGNONE)
            headers.update({
                'Origin': rurl[:-1]
                ,'Content-Type': 'application/json;charset=UTF-8'
                })
            xbmc.log(repr(headers),xbmc.LOGNONE)

            shtml = self.net.http_POST(surl, form_data=edata, headers=headers, jdata=True).content
            xbmc.log(repr(shtml),xbmc.LOGNONE)
            r = json.loads(shtml).get('stream')
            xbmc.log(repr(r),xbmc.LOGNONE)
            surl = r.get('backup') if r.get('backup') else r.get('src')
            xbmc.log(repr(surl),xbmc.LOGNONE)
            if surl:
                headers.pop('Content-Type')
                headers.pop('Accept')
                headers.pop('Accept-Encoding')
                headers.update({
                    'Accept': '*/*'
                    })
                xbmc.log(repr(headers),xbmc.LOGNONE)
                surl = surl + helpers.append_headers(headers)
                xbmc.log(repr(surl),xbmc.LOGNONE)
                return surl
            
        except:
            raise
            pass

        
        #worked 2021-05
        domain = 'aHR0cHM6Ly9ldm9sb2FkLmlvOjQ0Mw..'
        web_url = self.get_url(host, media_id)

        html = self.net.http_GET(web_url, headers).content

##        xbmc.log(repr(html),xbmc.LOGNONE)
        token = helpers.girc(html, rurl, domain)
##        xbmc.log(repr(token),xbmc.LOGNONE)
        if token:
            edata = {'code': media_id,
                     'token': token}
            headers.update({'Origin': rurl[:-1],
                            'X-XSRF-TOKEN': ''})
            shtml = self.net.http_POST(surl, form_data=edata, headers=headers, jdata=True).content
            r = json.loads(shtml).get('stream')
            surl = r.get('backup') if r.get('backup') else r.get('src')
            if surl:
                headers.pop('X-XSRF-TOKEN')
                return surl + helpers.append_headers(headers)

      


        
        raise ResolverError('File Not Found or removed')

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/e/{media_id}')
