"""
    Plugin for ResolveURL
    Copyright (C) 2020 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resolveurl.plugins.__resolve_generic__ import ResolveGeneric
from resolveurl.lib import helpers

from resolveurl.lib.log_utils import Log,LogR,LOGWARNING,LOGINFO,LOGERROR

import re
import traceback

class VidMolyResolver(ResolveGeneric):
    name = 'VidMoly'
    domains = [
        'vidmoly\.[a-zA-Z]+?'
        , 'vidmoly.me'
        , 'vidmoly.to'
        , 'vidmoly.net'
        ]
    pattern = r'(?://|\.)(vidmoly\.(?:me|to|net|[a-zA-Z]+?))/(?:embed-|w/)?([0-9a-zA-Z]+)'

    def get_media_url(self, host, media_id):
        LogR((host, media_id),LOGINFO)

        patterns = [
            r'''sources:\s*\[{file:"(?P<url>[^"]+)'''
            , r"sources:\s*\[{\s*file:\s*'(?P<url>[^']+)"
            ]

        url = ''
        try:
            regex = r'(?://|\.)(vidmoly\.(?:me|to|net|[a-zA-Z]+?))/(?:embed-|w/)?([0-9a-zA-Z]+)'
            url = self.get_url(host, media_id)
            html = self.net.http_GET(url).content
            try0 = re.findall(regex,html)[0]
            LogR(try0,LOGINFO)
            host_1=try0[0]
            media_id_1 = try0[1]
            url = self.get_url2(host_1, media_id_1)
            try2 = helpers.get_media_url(
                url
                ,patterns = patterns
##                patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
                ,result_blacklist=['.mpd']
                )
            LogR((try2,url),LOGINFO)
            return try2
        except Exception as e:
            LogR((url,e),LOGERROR)
##            traceback.print_exc()
##            pass

        try:
            url = self.get_url(host, media_id)
            try1 = helpers.get_media_url(
                url
                ,patterns = patterns
##                patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
                ,result_blacklist=['.mpd']
                )
            LogR((try1,),LOGINFO)
            return try1
        except Exception as e:
            LogR((url,e),LOGERROR)
##            traceback.print_exc()
            try:
                url = self.get_url2(host, media_id)
                try2 = helpers.get_media_url(
                    self.get_url2(host, media_id)
                    ,patterns = patterns
                    #patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
                    ,result_blacklist=['.mpd']
                    )
                LogR((try2,),LOGINFO)
                return try2
            except Exception as e:
                LogR((url,e),LOGERROR)
##                traceback.print_exc()
##                pass

        Log('Warning {} Video not found'.format(__name__))
        return None
        
##        html = self.net.http_GET(web_url).content
##        return helpers.get_media_url(
##            self.get_url(host, media_id),
##            patterns=[r'''sources:\s*\[{file:"(?P<url>[^"]+)'''],
##            result_blacklist=['.mpd']
##        )

    def get_url(self, host, media_id):
        default_get_url = self._default_get_url(
            host
            , media_id
            , template='https://vidmoly.me/{media_id}.html'
            )
##        Log(default_get_url)
        return default_get_url
    def get_url2(self, host, media_id):
        default_get_url = self._default_get_url(
            host
            , media_id
            , template='https://vidmoly.me/embed-{media_id}.html'
            )
##        Log(repr((default_get_url,)))
        return default_get_url
