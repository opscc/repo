"""
    Plugin for ResolveURL
    Copyright (C) 2022 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resolveurl.plugins.__resolve_generic__ import ResolveGeneric
from resolveurl.lib import helpers

from resolveurl.lib.log_utils import Log

import traceback

class NoxxResolver(ResolveGeneric):
    name = 'Noxx'
    domains = [
        'noxx.to'
##        ,'streamingnow.mov'
        ]
    pattern = r'(?://|\.)((?:noxx|streamingnow)\.(?:to|mov))/(.+)'

       
    def get_media_url(self, host, media_id):
        Log(repr((host,media_id)))
        Log(repr(self.get_url(host, media_id)))
        media_url = ''
        try:
            patterns=[r'w=btoa\("(?P<url>.+?)"\)']
            media_url = helpers.get_media_url(
                self.get_url(host, media_id)
                ,patterns=patterns
                ,generic_patterns=False
            )
            raise Exception(media_url)  
        except:
            traceback.print_exc()
        return media_url

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/{media_id}')
