"""
    Plugin for ResolveURL
    Copyright (C) 2023 shellc0de

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resolveurl.lib import helpers
from resolveurl.plugins.__resolve_generic__ import ResolveGeneric
from six.moves import urllib_parse
from resolveurl import common

import json, re

import os,traceback,xbmc
def Log(msg,stacklevel=2):
    try: 
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
            ,traceback.extract_stack(limit=stacklevel)[0][1]
            ,msg
            )
    except:
        raise
        pass
    xbmc.log(msg, xbmc.LOGNONE)
    
class MegaPlayResolver(ResolveGeneric):
    name = 'megaplay'
    domains = [
        'megaplay.buzz'
    ]
    pattern = r'(?://|\.)(megaplay\.buzz)/(.+)'

    def get_media_url(self, host, media_id):
        Log(repr((host, media_id)))
        rurl = 'https://fastflix.top/'
        headers = {'Origin': rurl[:-1],
                   'Referer': rurl,
                   'User-Agent': common.RAND_UA}
        web_url = self.get_url(host, media_id)
        html = self.net.http_GET(url=web_url,headers=headers).content

        pattern = r'data-id="(\d+)"'
        data_id = re.compile(pattern, re.DOTALL | re.IGNORECASE).findall(html)[0]

        headers['X-Requested-With'] = 'XMLHttpRequest'
        headers['Referer'] = 'https://{}/'.format(host)
        web_url = 'https://{}/stream/getSources?id={}'.format(host,data_id)
        html = self.net.http_GET(url=web_url,headers=headers).content

        media_url = json.loads(html)['sources']['file']
        Log(media_url)

        del headers['X-Requested-With']
        media_url += helpers.append_headers(headers)
        Log(media_url)

##        regex = ['"hls[2-3]":\\s*["\'](?P<url>[^"\']+)'
##                ,r'''sources:\s*\[{file:\s*["'](?P<url>[^"']+)''']
##        media_url =  helpers.get_media_url(
##            self.get_url(host, media_id),
##            patterns=regex,
##            generic_patterns=False,
##            referer=referer
##            ,log_packed_data=True
##        )
        return media_url
    

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/{media_id}')
