"""
    Plugin for ResolveURL
    Copyright (C) 2024 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from six.moves import urllib_parse
from resolveurl.lib import helpers, jsunhunt
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError


class StreamSilkResolver(ResolveUrl):
    name = 'StreamHiHi'
    domains = ['streamhihi.com']
    pattern = r'(?://|\.)(streamhihi\.com)/(?:e)/([0-9a-zA-Z$:/.]+)'

##GET https://streamhihi.com/e/frgomq45fb2n HTTP/1.1
##Host: streamhihi.com
##Connection: keep-alive
##sec-ch-ua: "Microsoft Edge";v="135", "Not-A.Brand";v="8", "Chromium";v="135"
##sec-ch-ua-mobile: ?0
##sec-ch-ua-platform: "Windows"
##DNT: 1
##Upgrade-Insecure-Requests: 1

##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.0.0
##Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
##Sec-Fetch-Site: none
##Sec-Fetch-Mode: navigate
##Sec-Fetch-User: ?1
##Sec-Fetch-Dest: document
##Accept-Encoding: gzip, deflate, br
##Accept-Language: en-US,en;q=0.9

##    sources: [{file:"https://r3usndiyrpb1m.tnmr.org/hls2/02/01842/frgomq45fb2n_h/master.m3u8?t=Vazv87xhhscaiAA_t3ncYImbrIRURt8sU774SSB0em4&s=1744726768&e=28800&f=9210609&i=0.3&sp=0"}],
##    image: "https://img.lulucdn.com/frgomq45fb2n_xt.jpg",
##    width: "100%", 
##    height: "100%",

#user agent must match

##GET https://r3usndiyrpb1m.tnmr.org/hls2/02/01842/frgomq45fb2n_h/master.m3u8?t=Vazv87xhhscaiAA_t3ncYImbrIRURt8sU774SSB0em4&s=1744726768&e=28800&f=9210609&i=0.3&sp=0 HTTP/1.1
##Host: r3usndiyrpb1m.tnmr.org
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.0.0
##Origin: https://streamhihi.com
##Referer: https://streamhihi.com/
##Accept-Encoding: gzip, deflate
##Accept-Language: en-US,en;q=0.9



    

    def get_media_url(self, host, media_id):
        if '$$' in media_id:
            media_id, referer = media_id.split('$$')
            referer = urllib_parse.urljoin(referer, '/')
        else:
            referer = False
        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': common.RAND_UA}
        if referer:
            headers.update({'Referer': referer})
        html = self.net.http_GET(web_url, headers=headers).content
        if jsunhunt.detect(html):
            html = jsunhunt.unhunt(html)

        r = re.search(r'urlPlay\s*=\s*"([^"]+)', html)
        if not r:
            r = re.search(r'sources:\s+?\[{file:"([^"]+)', html)

        if r:
            headers.update({
                'Referer': 'https://{0}/'.format(host),
                'Origin': 'https://{0}'.format(host)
            })
            return r.group(1).strip() + helpers.append_headers(headers)

        raise ResolverError('File not found')

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/e/{media_id}')
