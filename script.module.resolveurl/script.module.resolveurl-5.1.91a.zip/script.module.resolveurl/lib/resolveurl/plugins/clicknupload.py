"""
    Plugin for ResolveURL
    Copyright (C) 2015 tknorris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from resolveurl.lib import helpers
from resolveurl.lib import captcha_lib
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError

##import xbmc
##def Log(msg):
##    xbmc.log(msg, xbmc.LOGNONE)

MAX_TRIES = 3


class ClickNUploadResolver(ResolveUrl):
    name = 'ClickNUpload'
    domains = ['clicknupload.red', 'clicknupload.click'
               , 'clicknupload.to', 'clicknupload.cc', 'clicknupload.co',
               'clicknupload.com', 'clicknupload.me', 'clicknupload.link',
               'clicknupload.org', 'clicknupload.club'
               ]
    pattern = r'(?://|\.)(clicknupload\.(?:com?|me|link|org|cc|club|to|click|red))/(?:f/)?([0-9A-Za-z]+)'

    def get_media_url(self, host, media_id):
        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': common.FF_USER_AGENT,
                   'Referer': web_url}
        html = self.net.http_GET(web_url, headers=headers).content
        if 'File Not Found' not in html:
            data = helpers.get_hidden(html)
            data2 = helpers.urllib_parse.urlencode(data)
            html = self.net.http_POST(web_url, data2, headers=headers).content
            data.update(captcha_lib.do_captcha(html))

            data.update({'adblock_detected':'0'})
            data.update({'method_premium':''})
            data.update({'op':'download2'})
            if 'fname' in data: data.pop('fname')
            hidd = helpers.get_hidden(html)
            data.update({'rand':hidd['rand']})

            tries = 2
            while tries < MAX_TRIES:
                Log('waiting 16 sec')
                common.kodi.sleep(16000) #site enforces a 15s delay before we can get URL; I added 1 extra
                
                html = self.net.http_POST(web_url, data, headers=headers).content
                r = re.search(r'''class="downloadbtn"[^>]+onClick\s*=\s*\"window\.open\('([^']+)''', html)
                if r:
                    headers.update({'verifypeer': 'false'})
                    video_url = r.group(1).replace(' ', '%20') + helpers.append_headers(headers)
                    Log(video_url)
                    return video_url
                
                tries = tries + 1

            raise ResolverError('Unable to locate link')
        else:
            raise ResolverError('File deleted')
        return

    def get_url(self, host, media_id):
        Log('{}: |{}|'.format(host,media_id))
        return self._default_get_url(host, media_id, template='https://clicknupload.red/{media_id}')

    @classmethod
    def isPopup(self):
        return True
