'''
    Plugin for ResolveURL
    Copyright (C) 2020 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''



from resolveurl.plugins.lib import helpers
from resolveurl.plugins.__resolve_generic__ import ResolveGeneric

import traceback
def Log(msg):
    #return
    import xbmc
    xbmc.log(repr(msg),xbmc.LOGNONE)
        
class SBEmbedResolver(ResolveGeneric):
    name = "sbembed"
    domains = ["sbembed.com", "sbplay.one"]
    pattern = r'(?://|\.)(sb(?:embed|play)\.(?:com|one))/(?:embed-|e|play)/?([0-9a-zA-Z]+)(?:\.html|)'

    def get_media_url(self, host, media_id):
        media_url = None
        try:
            media_url = helpers.get_media_url(self.get_url(host, media_id),
                                         patterns=[r'''sources\s*:\s*\["(?P<url>[^"]+)''',
                                                   r'''(?:file|src):\s*"(?P<url>[^"]+)'''],
                                         generic_patterns=False,
                                         result_blacklist=['dl', '.srt', '.vtt'],
                                         referer=False)
            

        except:
            traceback.print_exc()
            media_url = helpers.get_media_url(self.Oct2021_get_url(host, media_id),
                                         patterns=[r'''sources\s*:\s*\["(?P<url>[^"]+)''',
                                                   r'''(?:file|src):\s*"(?P<url>[^"]+)''',
                                                   r'"file":"(?P<url>[^"]+)"'],
                                         generic_patterns=False,
                                         result_blacklist=['dl', '.srt', '.vtt'],
                                         referer=False)
            

        Log("media_url="+repr(media_url))
        return media_url

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, template='https://{host}/play/{media_id}')
    def Oct2021_get_url(self, host, media_id):
        import codecs
        media_id = codecs.encode(media_id, 'hex_codec')
        media_id = codecs.encode(media_id, 'hex_codec')
        from resolveurl import common
        net = common.Net()
        url = "https://streamsb.com/cdn-cgi/trace"
        response = net.http_GET(url)
        html = response.content
        my_ip = html.split('ip=')[1].split('\n')[0]
        #my_ip is what outside world sees, regardless of internal proxy/NAT
        my_ip = codecs.encode(my_ip, 'hex_codec')
        my_ip = codecs.encode(my_ip, 'hex_codec')
        media_id = media_id + '/' + my_ip
        return self._default_get_url(host, media_id, template='https://{host}/sources/{media_id}')
