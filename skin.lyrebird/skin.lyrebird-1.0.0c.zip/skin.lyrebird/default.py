import json,xbmc,xbmcgui
def Log(message):
    xbmc.log(repr(message), xbmc.LOGNONE)

import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[1].replace('?', '')))
##Log(repr(params))
mode = params.get('mode').lower()


def toggle_proxy():
    val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
##    Log('proxy was: ' + repr(json.loads(val)['result']['value']))
    val = (json.loads(val)['result']['value'])
    result = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy","value":' + str(not(val)).lower() + '}, "id":1}')
##    Log(repr(result))
    val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
##    Log(repr(val))
    r = json.loads(val)
    if 'result' in r:
        Log('proxy now: ' + repr(r['result']['value']))
    elif 'error' in r:
        Log("error: {}".format(repr(r['error'])))
    else:
        Log(repr(val))

if mode == 'toggleproxy':
    toggle_proxy()
elif mode == 'refresh_progress_bar':
    #if skin command includes <onclick>Dialog.Close(all,true)</onclick>; will need to refresh this
    progress_dialog = xbmcgui.DialogProgressBG()
    progress_dialog.create('','') 
    progress_dialog.close()
else:
    Log("unknown command {}".format(repr(mode)))

