
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import urllib2
import re

import utils
from utils import Log as Log

#NB_ITEM_PAGE = 28
NB_ITEM_PAGE = 28
spacing_for_topmost = ""
spacing_for_names = ""
spacing_for_next = ""

CATEGORIES_VIDEO = "1"
LIST_ITEMS = "2"
PLAY_VIDEO = "3"
SEARCH_VIDEO = "4"


def _get_keyboard( default="", heading="", hidden=False ):
	""" shows a keyboard and returns a value """
	keyboard = xbmc.Keyboard( default, heading, hidden )
	keyboard.doModal()
	if ( keyboard.isConfirmed() ):
		return unicode( keyboard.getText(), "utf-8" )
	return default

def Root():

        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( \
            spacing_for_topmost, utils.search_text_color, "Search") \
            ,url='' \
            ,mode=SEARCH_VIDEO \
            ,iconimage=utils.search_icon \
            ,Folder=True \
            )

        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( \
            spacing_for_topmost, utils.search_text_color, "Categories") \
            ,url='' \
            ,mode=CATEGORIES_VIDEO \
            ,iconimage=utils.search_icon \
            ,Folder=True \
            )
        
	ri=[
		("Most Viewed", "https://www.tube8.com/most-viewed/", "videos_page_wrapper"),
		("Top Rated", "https://www.tube8.com/top/", "videos_page_wrapper"),
		("Most Favorited", "https://www.tube8.com/most-favorited/", "videos_page_wrapper"),
		("Most Discussed", "https://www.tube8.com/most-discussed/", "videos_page_wrapper"),
		("Most Voted", "https://www.tube8.com/most-voted/", "videos_page_wrapper"),
		("Longest", "https://www.tube8.com/longest/", "videos_page_wrapper")
		]
	for name, url, keyword in ri:
                np_url = url
                #Log("np_url='{}'".format(np_url))
                utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( \
                    spacing_for_topmost, utils.search_text_color, name) \
                    ,url=np_url \
                    ,mode=LIST_ITEMS \
                    ,iconimage=utils.search_icon \
                    ,Folder=True \
                    ,keyword=keyword
                    )

        List(pageUrl="https://www.tube8.com/newest/", subsection_filter="videos_page_wrapper")


def Categories():
        pageUrl = "https://www.tube8.com/categories.html"
        full_html = utils.getHtml(pageUrl)

        subsection_filter = "cat_page_wrapper"
        Log("subsection_filter='{}'".format(subsection_filter))
        subsection_match_pattern = subsection_filter + "(.+?)" + subsection_filter
        subsection_html=re.compile(subsection_match_pattern, re.DOTALL | re.IGNORECASE).findall(full_html)[0]

        match_pattern = 'a href="([^"]+)"' \
                        + '.+?data-thumb="([^"]+)"' \
                        + '.+?<h5>([^<]+)<' 
        matches=re.compile(match_pattern, re.DOTALL | re.IGNORECASE).findall(subsection_html)
        for url,thumb,title in matches:
                np_url = url
                #Log("np_url='{}'".format(np_url))
                utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( \
                    spacing_for_topmost, utils.search_text_color,title) \
                    ,url=np_url \
                    ,mode=LIST_ITEMS \
                    ,iconimage=thumb \
                    ,Folder=True \
                    ,keyword='cat_list_page_wrapper' \
                    )
                

def Search(page_number = 0, search_string = None):

        #Log("search_string='{}'".format(search_string))
        if not search_string:
                prev_search_string = utils.this_addon.getSetting(id='search_string')
                search_string = _get_keyboard( heading="Enter the query", default=prev_search_string  )
                if  search_string == '' :
                        return False, 0  ## if blank or the user cancelled the keyboard, return

        utils.this_addon.setSetting(id='search_string', value=search_string)
        #Log("search_string='{}'".format(search_string))
	
        #todo:
	# read appid and api-key from web page
        app_id = "BNZMZKCXIT"
        api_key = "3624454cb0b8c87da7f6100dde6ce062"
        search_url = "https://bnzmzkcxit-dsn.algolia.net/1/indexes/*/queries?x-algolia-application-id={}&x-algolia-api-key={}"
        search_url = search_url.format(app_id, api_key)
        
        items_per_page = 12
        json_string = '{{"requests":[{{"indexName":"tube8_slave_relevance","params":"query={}' + \
                        '&optionalWords=null' + \
                        '&facetFilters=%5B%22attributes.orientation%3Astraight%22%5D&facets=*' + \
                        '&page={}&hitsPerPage={}"}}]}}'
        json_string = json_string.format(urllib.quote(search_string), page_number, items_per_page)
        #Log("json_string='{}'".format(json_string))


        from requests import Request, Session
        s = Session()
        url = search_url
        headers = {"User-Agent": utils.USER_AGENT
               , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
               }
        data = json_string
        req = Request('POST', url, data=data, headers=headers)
        prepped = s.prepare_request(req)
        resp = s.send(prepped , verify=False)

        import json
        hitsPerPage = json.loads(resp.content)['results'][0]['hitsPerPage']
        nbPages = json.loads(resp.content)['results'][0]['nbPages']
        page = json.loads(resp.content)['results'][0]['page']
        np_number = page + 1
        #Log("np_number='{}'".format(np_number))
        
        hits = json.loads(resp.content)['results'][0]['hits']
        for hit in hits:
                #Log("hit='{}'".format(hit))
                name = spacing_for_names + hit['title'].encode('ascii', 'ignore').strip()
                videopage = hit['link']
                duration = str(hit['attributes']['durationInSeconds'])
                img = hit['thumbnails'][0]['urls'][0]
                utils.addDownLink(name, videopage, PLAY_VIDEO, img, '', duration=duration)

        if nbPages > (page+1):
                np_url = sys.argv[0]
                Log("np_url='{}'".format(np_url))
                utils.addDir(name="{}[COLOR {}]Next Page ({})[/COLOR]".format( \
                    spacing_for_next, utils.search_text_color, np_number) \
                    ,url=np_url \
                    ,mode=SEARCH_VIDEO \
                    ,iconimage=utils.next_icon \
                    ,page=np_number \
                    ,Folder=True \
                    ,keyword=search_string
                    )
        
def List(pageUrl, subsection_filter=None):

        Log("pageUrl='{}'".format(pageUrl))
        full_html = utils.getHtml(pageUrl)

        #note: we want to narrow down html
        #      to what we want to find via subsection_filter, otherwise we find
        #      generic movies
        if subsection_filter:
                Log("subsection_filter='{}'".format(subsection_filter))
                subsection_match_pattern = subsection_filter + "(.+?)" + subsection_filter
                subsection_html=re.compile(subsection_match_pattern, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
                Log("subsection_html.len='{}'".format(len(subsection_html)  ))
        else:
                subsection_html = full_html

        match_pattern = 'data-video_url=\"([^\"]+)\"' \
                        + '.+?data-thumb=\"([^\"]+)\"' \
                        + '.+?title=\"([^\"]+)\"' \
                        + '.+?video-duration\">([^<]+)<'

        matches=re.compile(match_pattern, re.DOTALL | re.IGNORECASE).findall(subsection_html)
        for url,thumb,title,duration in matches:
                name = spacing_for_names + title.decode('utf8', 'ignore').encode('ascii', 'ignore')
                videopage = url 
                duration = duration
                img = thumb
                Log("duration='{}'".format(duration))
                utils.addDownLink( \
                        name = name \
                        , url = videopage \
                        , mode = PLAY_VIDEO \
                        , iconimage = img \
                        , duration = duration)



        match_pattern = 'id=\"pagination\".+href=\"([^\"]+)\".id=\"pagination_next\"'
        matches=re.compile(match_pattern, re.DOTALL | re.IGNORECASE).findall(full_html)
        if matches:
                np_url = matches[0]
                Log("np_url='{}'".format(np_url))
                try:
                        np_number = np_url.split("?page=")[1]
                except:
                        np_number = np_url.split("/page/")[1].strip('/')
                        
                #Log("np_number='{}'".format(np_number))                
                utils.addDir(name="{}[COLOR {}]Next Page ({})[/COLOR]".format( \
                    spacing_for_next, utils.search_text_color, np_number) \
                    ,url=np_url \
                    ,mode=LIST_ITEMS \
                    ,iconimage=utils.next_icon \
                    ,page=np_number \
                    ,Folder=True \
                    ,keyword=subsection_filter \
                    )

def Play(pageUrl):
        Log("pageUrl='{}'".format(pageUrl))
        full_html = utils.getHtml(pageUrl)

	p=re.compile('page_params.videoUrlJS = "([^"]+)')
	match=p.findall(full_html)
	Log("match='{}'".format(match))
        try:
                video_url=match[0]
        except:
                #Log(a)
                return

	xbmc.Player().play(video_url)

def get_params(args):
	param=[]
	print "Parsing arguments: " + str(args)
	paramstring=args[2]
	if len(paramstring)>=2:
		params=args[2]
		cleanedparams=params.replace('?', '')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
		return param



def main():
        print "main"
	params=get_params(sys.argv)
	mode=None
	url=None
	page=1
	keyword=''
	
	try:
		url=urllib.unquote_plus(params["url"])
	except:
		pass
	try:
		mode=str(int(params["mode"]))
	except:
		pass
	
	try:
		page=int(params["page"])
	except:
                page = 0
		pass
	try:
		keyword=urllib.unquote_plus(params["keyword"])
	except:
                keyword=None
		pass

        

        Log( "url  '" + str(url) + "'")
        Log( "page '" + str(page) + "'" )
        Log( "mode '" + str(mode) + "'" )
        Log( "keyword '" + str(keyword) + "'")
        
	if mode==None:
		Root()
                utils.add_sort_method()
                utils.endOfDirectory()
	elif mode==CATEGORIES_VIDEO:
		Categories()
                utils.add_sort_method()
                utils.endOfDirectory()
	elif mode==LIST_ITEMS:
		List(url, keyword)
                utils.add_sort_method()
                utils.endOfDirectory()
 	elif mode==PLAY_VIDEO:
		Play(url)
	elif mode==SEARCH_VIDEO:
		Search(page, keyword)
                utils.add_sort_method()
                utils.endOfDirectory()


if __name__ == "__main__":
	main()

