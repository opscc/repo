#-*- coding: utf-8 -*-

import datetime
import io
import json
import gzip # used to compress html requests
import os.path  
import requests
import simplecache
import socket
import sys
import tempfile 
import time
import threading
import traceback
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import constants as C

#globals
t_start = datetime.datetime.now()
this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
addon_name = this_addon.getAddonInfo('name')
addon_handle = int(sys.argv[1])
debug = (this_addon.getSetting('debug').lower() == "true")
rootDir = this_addon.getAddonInfo('path')
if rootDir[-1] == ';': rootDir = rootDir[0:-1]
rootDir = C.translatePath(rootDir)
html_timeout = int(this_addon.getSetting('html_timeout'))

#socket.setdefaulttimeout(30)
DEFAULT_ICON_IMAGE = C.translatePath(os.path.join(rootDir, 'icon.png'))
DEFAULT_HTTP_HEADERS = {
    'User-Agent': "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    ,'Accept-Encoding': 'gzip,deflate'
    }



CACHEABLE_HTML_CONTENT = [
                          'application/xml'
                        , 'application/json'
                        , 'text/html'
                        , 'application/javascript'
##                        , 'application/vnd.radio-canada+json'
                        ]


from urllib3 import ProxyManager, PoolManager
if C.certPath:
    pool_proxy = PoolManager(ca_certs=C.certPath)
else:
    pool_proxy = PoolManager()


global_cache = simplecache.SimpleCache()

##import logging, logging.handlers
##my_logger = logging.getLogger(C.addon_id)
##xbmc.log(repr(my_logger) , xbmc.LOGNONE)
##xbmc.log(repr(dir(my_logger)) , xbmc.LOGNONE)
##
##fh =logging.handlers.RotatingFileHandler(
##    (C.profileDir+'example.log')
##    , mode='a'
##    , encoding='utf8'
##    , maxBytes=100000
##    , backupCount=2
##    )
##my_logger.addHandler(fh)
##my_logger.setLevel(logging.DEBUG)

##xbmc.log(C.profileDir+'example.log' , xbmc.LOGNONE)
#, encoding='utf-8'
##my_logger.basicConfig(filename=(C.profileDir+'example.log')
##                    , level=logging.NOTSET
##                    , format='%(asctime)s %(thread)d %(message)s'
##                    , datefmt='%Y-%m-%d %H:%M:%S'
##                    , force=True
##                    )

#methods
#__________________________________________________________________________
#
def Log(msg='', loglevel=None, stacklevel=2):
    if msg is None: msg = repr(msg)
    m_type = type(msg)
    
    if not (m_type in C.text_type):
        xbmc.log("converting {} to {}".format(m_type, C.text_type), C.LOGNONE)
        if C.PY3: msg = str(msg,'utf8','ignore')
        if C.PY2: msg = unicode(msg)
    try: 
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
            ,traceback.extract_stack(limit=stacklevel)[0][1]
            ,msg
            )
    except:
        xbmc.log("{} to {}".format(m_type, C.text_type), C.LOGNONE)
        raise
        pass

    msg = u"{}: {}".format(C.addon_id, msg )
    if  loglevel:  xbmc.log(msg , loglevel)
    elif C.DEBUG:  xbmc.log(msg , xbmc.LOGNONE)
    else:          xbmc.log(msg)

##    raise Exception()
#__________________________________________________________________________
#
def LogR(msg='', loglevel=None):
    return Log(repr((type(msg), msg)), loglevel, stacklevel=3)
#__________________________________________________________________________
#
def Notify(header=None, msg='', duration=C.DEFAULT_NOTIFY_TIME, sound=False, allow_all_thread_names=False):
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound, allow_all_thread_names=allow_all_thread_names)
def notify(header=None, msg='', duration=C.DEFAULT_NOTIFY_TIME, sound=False, allow_all_thread_names=False):
    debug = (C.this_addon.getSetting('debug').lower() == "true")
    if allow_all_thread_names or (threading.current_thread().name == "MainThread"):
        Log( msg, C.LOGINFO)
        if header==None or header == '':
            if len(msg) > 30:
                header = msg[0:30]
                msg = msg[-30:]
            else:
                header=msg
        xbmcgui.Dialog().notification(header, msg, C.default_icon, duration, sound=False )
    elif debug:
        Log( msg, xbmc.LOGWARNING)
        pass
#__________________________________________________________________________
#
def Header2pipestring(header=DEFAULT_HTTP_HEADERS):
    q = "|{}".format( repr(header) )
    q = q.replace( "{'", "")
    q = q.replace( "'}", "")
    q = q.replace( "': '", "=" )
    q = q.replace( "', '", "&" )
    return q
#__________________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=10):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval
#__________________________________________________________________________
#
def TimeStampFor(event_name = 'since_start_of_addon'):
    net = (datetime.datetime.now()-t_start).total_seconds()
    msg  = "milliseconds for {}={:.0f}ms".format(event_name, net*1000)
    try: #get line number that called this if possible
        msg = "{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=2)[0][0])
            ,traceback.extract_stack(limit=2)[0][1]
            ,msg
            )
    except:
        pass
    Log( msg )
#__________________________________________________________________________
#
def DecodeHtmlGzip(response):
    if response.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO( response.read())
        f = gzip.GzipFile(fileobj=buf)
        data = f.read()
        f.close()
    else:
        data = response.read()
    return data
#__________________________________________________________________________
#
def Clear_Simplecache(cache_id = addon_id):
    global_cache.set(
        endpoint = cache_id
        ,data = 0
        )
#__________________________________________________________________________
# wrapper to allow cookie extraction from urllib3 proxy/socks requests
class FakeRequest(object):
    def __init__(self, full_url, headers):
        self.full_url = full_url
        self._headers = headers.copy()
    @property
    def headers(self):
        return self._headers
    @property
    def url(self):
        return self.full_url
    def get_full_url(self):
        return self.full_url
    def is_unverifiable(self, *args, **kargs):
        return True
    def get_origin_req_host(self, *args, **kargs):
        return self.full_url   
###__________________________________________________________________
###
##        , referer = None
##        , hdr = None
##        , data = None
##        , cache_duration = html_timeout
##        , cache_id = None #specify simpl
def GetHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=17
            , sucuri_solved=False
            , method="GET"
            , send_back_response=False
            , auto_encode_content=False
##            , cookie_domain=None
            , size=8192*1000
            , start_point=None
            , preload_content=True
            , cache_duration=C.default_GETHTML_cache_duration #seconds
            , cache_id=None
            ):

##    Log(__name__)
##    LogR(locals())

    try:
        if not url:
            if send_back_redirect == True:
                return '', ''
            return ''

        cache_id = C.addon_id+'_gethtml_'+url
        if  (send_back_response == False) and \
            (cache_duration > 0) and \
            method=="GET" :
            cached_value = global_cache.get(cache_id)
            if cached_value:
                Log('value is cached {}'.format(url)
    ##                ,C.LOGNONE
                    )
                if send_back_redirect:
                    return cached_value, url
                return cached_value             


        if not Is_Online():
            if send_back_redirect == True:
                return '', ''
            return ''


##        LogR(C.cookiePath)
        cj = C.cookielib.LWPCookieJar(C.cookiePath)
        try:
            cj.load(ignore_discard=True, ignore_expires=True)
            cj._now = int(time.time()) #module does not set this if I use internal functions
        except:
            cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
            cj._now = int(time.time())
            pass
        stream=False
        response = None
        redirected_url = None

        try:

            if '|' in url:
                headers = dict(urlparse.parse_qsl( str(url.split('|')[1])))
                url = url.split('|')[0]


            if headers is None:
    ##            Log("copying default header dictionary")
                getHtml_headers = C.DEFAULT_HEADERS.copy()
                r_c_u_a = C.USER_AGENT #random.choice(C._USER_AGENTS)
        ##        Log("r_c_u_a={}".format(r_c_u_a), xbmc.LOGNONE)
                getHtml_headers['User-Agent'] = r_c_u_a
        ##        Log("rand choice getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
            else:
                getHtml_headers = headers #headers.copy()
    ##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
                
            if len(referer) > 1:
                getHtml_headers['Referer'] = referer

            if sent_data:
                getHtml_headers['Content-Length'] = str(len(sent_data))

            if start_point and int(start_point) > 0:
                getHtml_headers['Range'] = 'bytes={}-'.format(start_point)


            #
            # I don't know how to use cookieJar with SOCKS proxy
            #
            socks_cookies = ''
            if url:
                this_domain = C.urlparse.urlparse(url).netloc
            
            temp_cookiejar = C.cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
            if cj and url:
                for cookie in cj:
                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                        socks_cookies += "{}={};".format(cookie.name,cookie.value)
                        temp_cookiejar.set_cookie(cookie)
    ##            for cookie in temp_cookiejar: #verification during development 
    ##               #Log("temp_cookiejar_cookie={}".format(repr(cookie)))
    ##                pass
                if 'Cookie' in getHtml_headers:
                    socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
                if not socks_cookies == '':
                    getHtml_headers['Cookie'] = (socks_cookies).strip(';')


        
    ##       #Log("final getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
    ##        return "" #getHtml_headers testing/dev

            
            bypass_proxy_list = get_setting('bypass_proxy_list')
            if not bypass_proxy_list: bypass_proxy_list=''
    ##        Log(repr(  (bypass_proxy_list)   ))
            should_bypass_proxy = C.urlparse.urlparse(url).netloc in (bypass_proxy_list.split(','))
    ##        Log(repr(  (url,should_bypass_proxy)   ))
            
            socks_response = None
            socks_proxy_info = Socks_Proxy_Active()
    ##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
            if (socks_proxy_info['uhp'] in (4,5)) and should_bypass_proxy==False:

                #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
                from urllib3.contrib.socks import SOCKSProxyManager
                socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                if C.certPath: 
                    proxy = SOCKSProxyManager(proxy_url=socks_string, ca_certs=C.certPath)
                else:
                    proxy = SOCKSProxyManager(proxy_url=socks_string)
                
                socks_response = proxy.request(
                    method
                    ,url = url
                    ,body = sent_data
                    ,headers = getHtml_headers
                    ,timeout = http_timeout
                    ,preload_content = preload_content
                    )
                #https://requests.readthedocs.io/en/master/api/
                #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
                
                if preload_content:
                    data = socks_response.data

                redirected_url = socks_response.geturl()
                if not url == redirected_url:
                    Log(repr((url,redirected_url)))
                    Log("redirected_url='{}'".format(redirected_url))
                else:
                    redirected_url = None



            elif (socks_proxy_info['uhp'] <= -0) :

                if (socks_proxy_info['ps'] is not None) and should_bypass_proxy==False:
                    proxy_string = "http://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                    proxy = ProxyManager(proxy_url=proxy_string, ca_certs=C.certPath)
                else:
                    proxy_string = ''
                    #proxy = PoolManager()
                    proxy = pool_proxy

    ##            Log(repr(proxy) )
    ##            Log(repr(dir(proxy)) )            
    ##            Log(repr(dir(proxy)) )

                response = proxy.request(
                    method
                    ,url = url
                    ,body = sent_data
                    ,headers = getHtml_headers
                    ,timeout = http_timeout
                    ,preload_content = preload_content
                    )
                #https://requests.readthedocs.io/en/master/api/
                #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
     
                #make urllib3.response more like requests.response by adding cookiejar and status
                temp_jar = C.cookielib.LWPCookieJar()
                fake_request = FakeRequest(url, response.getheaders() )
                requests.cookies.extract_cookies_to_jar(temp_jar, fake_request, response)
                response.cookies = temp_jar
                response.status_code = response.status

                if preload_content:
                    data = response.data
    ##            Log(data[:500]) #dev trim the data to minimize logging

                redirected_url = response.geturl()
                if not (url == redirected_url):
                    if redirected_url and not (redirected_url.startswith('http')):
                        if (response.retries is not None):
                            if len(response.retries.history):
                                redirect_location = response.retries.history[-1].redirect_location
                                redirect_url = response.retries.history[-1].url
                                if not (redirected_url.startswith('http')):
                                    if not (redirect_url.startswith('http')):
                                        redir_domain = C.urlparse.urlparse(url).scheme + '://' + C.urlparse.urlparse(url).netloc
                                    else:
                                        redir_domain = C.urlparse.urlparse(redirect_url).scheme + '://' + C.urlparse.urlparse(redirect_url).netloc
                                redirected_url = redir_domain + redirected_url
                    if redirected_url and not (redirected_url.startswith('http')):
                        redir_domain = C.urlparse.urlparse(url).scheme + '://' + C.urlparse.urlparse(url).netloc
                        redirected_url = redir_domain + redirected_url
                    if (url == redirected_url): redirected_url = None
                    else: Log(u"processed redirected_url={}".format(repr(redirected_url)))
                else:
                    redirected_url = None
                    


            if auto_encode_content: 
                if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
                    content_type = response.headers['Content-Type']
                    if 'charset=' in content_type:
                        ct = content_type.split('charset=')[1]
                        data = data.decode(ct)
            elif not send_back_response:

                try:
                    data = str(data, 'utf8')
                except:
                    pass #leave it as binary; caller will have to deal with any string conversions
                
            if sucuri_solved == False:
                if response and 'Server' in response.headers:
                    if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                       #Log(repr(response.status_code))
                        import sucuri
                        if sucuri.SCRIPT_HEADER in data:
                            cookie = sucuri.Set_Cookie(data)
                            cj.set_cookie(cookie)
                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
                            return getHtml(url, referer, headers
                                           , save_cookie, sent_data
                                           , ignore404, ignore403
                                           , send_back_redirect, http_timeout
                                           , sucuri_solved = True, method=method)


            if send_back_response == True:
                if send_back_redirect == True:
                    return response, redirected_url
                else:
                    return response


            if response and not(response.status_code in (200,301)):
    ##            Log(repr(response.status_code))
                raise urllib2.HTTPError(url=url, code=response.status_code, msg=data, hdrs=response.headers, fp=None)

            if not (save_cookie == False) and (cj is not None) :
                r = response
                this_domain = urlparse.urlparse(url).netloc

                if r is not None:
                    for cookie in r.cookies:
                       #Log("r.cookie={}".format(repr(cookie)))
                        if save_cookie == True: #save as this domain even if cookie is not marked so
                             cookie.domain = this_domain
                        if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                            cj.set_cookie(cookie)
                            
                    cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

                 

            if send_back_response == True:
                if send_back_redirect == True:
                    return response, redirected_url
                else:
                    return response


            if  (send_back_response == False) and \
                (cache_duration > 0):

                if response and 'Content-Type' in response.headers:
                    ctype = response.headers['Content-Type'].lower().split('charset=utf-8')[0].rstrip(' ;')
                    if ctype and ctype in CACHEABLE_HTML_CONTENT:
                        global_cache.set(
                            endpoint = cache_id
                            ,data = data
                            ,expiration = datetime.timedelta(seconds=cache_duration)
                            )
                    else:
                        Log("not caching ctype = {}".format(repr(ctype)))
                        pass
                
            if send_back_redirect == True:
                return data, redirected_url

            if response:
                response.close()

            return data


##        except requests.HTTPError as e:
##            Log("repr(e)='{}'".format(repr(e)))
##            raise

        except C.urllib2.HTTPError as e:

            data = e.msg
##            LogR(data)

            if e.code == 503 and 'cf-browser-verification' in data:
                import cloudflare
                data = cloudflare.solve(url, cj, USER_AGENT)
                
            elif e.code == 404 and ignore404 == True:
                Log("404_e='{}'".format(url)) #e.read().decode()))
                if send_back_redirect == True:
                    return data, redirected_url
                else:
                    return data

            elif e.code == 403 and ignore403 == True:
                Log("403_e='{}'".format(url)) #e.read().decode()))
                if send_back_redirect == True:
                    return data, redirected_url
                else:
                    return data

            else:
    ##            traceback.print_exc()
    ##            return data
                raise
##                pass

        except:
##            pass
            raise

        if send_back_redirect == True:
            return None, None
        else:
            return None

    except Exception:
        LogR(locals())
##        traceback.print_exc()
        raise


##        , referer = None
##        , hdr = None
##        , data = None
##        , cache_duration = html_timeout
##        , cache_id = None #specify simplecache identifier
##        ):
##
##    if url=='':  return None
##
####    Log(repr(
####            (url
####            , referer #=None
####            , hdr #=None
####            , data #=None
####            , cache_duration #= html_timeout
####            , cache_id #= None #specify simplecache identifier
####            )
####            )
####        )
##
##    if not hdr:    req = urllib2.Request(url, data, DEFAULT_HTTP_HEADERS)
##    else:          req = urllib2.Request(url, data, hdr)
##    if referer:    req.add_header('Referer', referer)
##    if data:       req.add_header('Content-Length', len(data))
##    data = ''
##    max_retries = 3
##    retry_count = 0
##    response = None
##
##    if not cache_id: cache_id = addon_id+'_gethtml_'+url
##
##    cached_value = global_cache.get(cache_id)
##    if cached_value: return cached_value
##
##    bypass_proxy_list = this_addon.getSetting('bypass_proxy_list')
##    if not bypass_proxy_list: bypass_proxy_list=''
##    should_bypass_proxy = urlparse.urlparse(url).netloc in (bypass_proxy_list.split(','))
##
##    import xbmc,json
##    val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
##    val = (json.loads(val)['result']['value'])
##    if val == True:
##        httpproxyserver = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxyserver"},"id":1}')
##        httpproxyserver = json.loads(httpproxyserver)['result']['value']
##        httpproxyport  = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxyport"},"id":1}')
##        httpproxyport = json.loads(httpproxyport)['result']['value']
##        proxy = "{}:{}".format(httpproxyserver,httpproxyport)
##        proxies = {'https': 'https://'+proxy
##                   ,'http': 'http://'+proxy}
##    else:
##        proxy = None
##
##    handlers = []
##    if proxy is not None and should_bypass_proxy==False:
##        handlers += [urllib2.ProxyHandler(proxies)]
##        opener = urllib2.build_opener(*handlers)
##        urllib2.install_opener(opener)
##            
##    while not data and retry_count<max_retries:
##        retry_count += 1
##        Log("attempt {} for url:'{}'".format(retry_count,url))
##        try:
##            response = urllib2.urlopen(req, timeout=30)
##            if response: data = DecodeHtmlGzip(response)
##        except:
##            traceback.print_exc()
##    if response and data:
##        if 'Content-Type' in response.headers:
##            ctype = response.headers['Content-Type'].lower()
##            if ctype and ctype in CACHEABLE_HTML_CONTENT: 
##                global_cache.set(
##                    endpoint = cache_id
##                    ,data = data  
##                    ,expiration = datetime.timedelta(seconds=cache_duration)
##                    )
##            else:
##                Log("not caching ctype = {}".format(repr(ctype)))
##                pass
##                
##        response.close()
##
##
##
##    return data
#__________________________________________________________________________
#
def DownloadVideo(url, name):
#__________________________________________________________________________
#
    def _pbhook(downloaded, filesize, name=None,dp=None):
        try:
            percent = min((downloaded*100)/filesize, 100)
            currently_downloaded = float(downloaded) / (1024 * 1024)
            kbps_speed = int(downloaded / (time.clock() - start))

            if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
            else:               eta = 0

            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            mbs = name
            mbs += ' %.02f MB of %.02f MB ' % (currently_downloaded, total)
            e = 'Speed: %.02f Kb/s ' % kbps_speed
            e += 'ETA: %02d:%02d' % divmod(eta, 60)
            #dp.update(percent,'',mbs,e)
            dp.update(percent,'',mbs + e)

        except:
            traceback.print_exc()
            percent = 100
            dp.update(percent)
            dp.close()
            
        #if dp.iscanceled():
        #    dp.close()
        #    raise StopDownloading('Stopped Downloading')

#__________________________________________________________________________
#
    def getResponse(url, headers2, size):
        #Log("getResponse:{}".format(url))
        try:
            if size > 0:
                size = int(size)
                headers2['Range'] = 'bytes=%d-' % size
            req = Request(url, headers=headers2)
            #req.add_header('Range', 'bytes=0-100') #only get a few bytes to test for redirection
            resp = urlopen(req, timeout=30)
            #Log("getResponse:urlopen:{}".format(url))
            return resp
        except:
            traceback.print_exc()
            return None
#__________________________________________________________________________
#
    def doDownload(url, dest, dp, name):

        try:

            #url may have include headers to be passed during transaction
            try:
                headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
            except:
                traceback.print_exc()
                headers = dict('')


            url = url.split('|')[0]
            file = dest.rsplit(os.sep, 1)[-1]

            resp = getResponse(url, headers, 0)

            if not resp:
                Notify("Download failed: {}".format(url))
                #xbmcgui.Dialog().ok("Ultimate Whitecream", 'Download failed', 'No response from server')
                return False

            try:    content = int(resp.headers['Content-Length'])
            except: content = 0

            try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
            except: resumable = False
            if resumable: Log("Download is resumable: {}".format(url))

            if content < 1:
                Notify("Unknown filesize: {}".format(url))
                #xbmcgui.Dialog().ok("Ultimate Whitecream", 'Unknown filesize', 'Unable to download')
                #return False

            size = 8192
            mb   = content / (1024 * 1024)

            if content < size:
                size = content

            total   = 0
            errors  = 0
            count   = 0
            resume  = 0
            sleep   = 0

            Log('Download File Size : %dMB %s ' % (mb, dest))
            f = xbmcvfs.File(dest, 'w')

            chunk  = None
            chunks = []

            while True:

                # kill the download if kodi monitor tells us to
                monitor = xbmc.Monitor()
                if monitor.abortRequested():
                    if monitor.waitForAbort(1):
                        Log("shutting down '{}' download thread for '{}'".format(addon_id,url), xbmc.LOGNOTICE)
                        return
                
                downloaded = total
                for c in chunks:
                    downloaded += len(c)
                percent = min(100 * downloaded / content, 100)

                _pbhook(downloaded,content,name,dp)

                chunk = None
                error = False

                try:
                    chunk  = resp.read(size)
                    if not chunk:
                        if percent < 99:
                            error = True
                        else:
                            while len(chunks) > 0:
                                c = chunks.pop(0)
                                f.write(c)
                                del c

                            f.close()
                            Log( '%s download complete' % (dest) )
                            return True

                except Exception as e:
                    traceback.print_exc()
                    error = True
                    sleep = 10
                    errno = 0

                    if hasattr(e, 'errno'):
                        errno = e.errno

                    if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                        pass

                    if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                        errors = 10 #force resume
                        sleep  = 30

                    if errno == 11001: # 'getaddrinfo failed'
                        errors = 10 #force resume
                        sleep  = 30

                if chunk:
                    errors = 0
                    chunks.append(chunk)
                    if len(chunks) > 5:
                        c = chunks.pop(0)
                        f.write(c)
                        total += len(c)
                        del c

                if error:
                    errors += 1
                    count  += 1
                    #Log ('%d Error(s) whilst downloading %s' % (count, dest))
                    #xbmc.sleep(sleep*1000)
                    Sleep(sleep*1000)

                if (resumable and errors > 0) or errors >= 500:
                    if (not resumable and resume >= 500) or resume >= 500:
                        #Give up!
                        Log ('%s download canceled - too many error whilst downloading' % (dest))
                        f.close()
                        return False

                    resume += 1
                    errors  = 0
                    if resumable:
                        chunks  = []
                        #create new response
                        Log ('Download resumed (%d) %s' % (resume, dest) )
                        resp = getResponse(url, headers, total)
                    else:
                        #use existing response
                        pass

        except:
            traceback.print_exc()
#__________________________________________________________________________
#
    def clean_filename(s):
        if not s:
            return ''
        badchars = '\\/:*?\"<>|\''
        for c in badchars:
            s = s.replace(c, '')
        return s.strip();

    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = name.strip('\r')
    
    download_path = this_addon.getSetting('download_path')
    if download_path == '':
        try:
            download_path = xbmcgui.Dialog().browse(0, "Download Path", 'myprograms', '', False, False)
            this_addon.setSetting(id='download_path', value=download_path)
            if not os.path.exists(download_path): os.mkdir(download_path)
        except:
            raise #pass

    if download_path != '':
        dp = xbmcgui.DialogProgressBG()
        #dp = xbmcgui.DialogProgress()
        name = name.split("[")[0]
        dp.create(addon_name,name[:50])
        tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
        tmp_file = xbmc.makeLegalFilename(tmp_file)
        start = time.clock()
        try:
            downloaded = doDownload(url, tmp_file, dp, name)
            if downloaded:
                vidfile = xbmc.makeLegalFilename(download_path + clean_filename(name) + ".mp4")
                Log(vidfile)
                try:
                  os.rename(tmp_file, vidfile)
                  dp.close()
                  return vidfile
                except Exception as e:
                  traceback.print_exc()
                  Notify("'{}' name:{} tmp:{}".format(e,vidfile,tmp_file), 20000)
                  dp.close()
                  return tmp_file
            else:
                raise StopDownloading('Stopped Downloading')
        except:
            while os.path.exists(tmp_file):
                try:
                    os.remove(tmp_file)
                    dp.close()
                    break
                except:
                    traceback.print_exc()
                    break
                    pass
            dp.close()
#__________________________________________________________________
#
def Is_Online(server=C.DEFAULT_IS_ONLINE_SERVER_NAME, port=C.DEFAULT_IS_ONLINE_SERVER_PORT):

    #todo: maybe change this to be proxy aware i.e. do a http get to server
    
    #use simplecache to store last time we did a network check
    # ... works like a static var across all threads
    cache_id = C.addon_id+'.Is_Online.'+"last_online_check"
    last_online_check = global_cache.get(cache_id)
    if last_online_check:
##        Log("skip Is_Online() Error to be more obvious on logs") #dev
        return True

    
    ip = xbmc.getIPAddress() #in case we don't have IP
    if (not ip) or ip.startswith('169.254'): # or ip.startswith('172.'):
        return False

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(3)
    try:
        qq = s.connect_ex((server, int(port)))
        if not qq == 0:
            raise Exception(qq)
    except:
        if C.DEBUG: traceback.print_exc()
        try:
            Sleep(1000)
            qq = s.connect_ex((server, int(port)))
            if not qq == 0:
                raise Exception(qq)
        except:
            return False
            raise
    finally:
        s.close()

    last_online_check = datetime.datetime.now()
    global_cache.set(
        endpoint = cache_id
        ,data = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ,expiration = datetime.timedelta(seconds=C.default_ISONLINE_cache_duration)
        )
    
    return True
#__________________________________________________________________________
#
def get_setting(setting_name, auto_convert_to_type=bool):
    raw_setting = C.this_addon.getSetting(setting_name)
    if auto_convert_to_type is bool:
        if raw_setting.lower() in ['true','false']:
            return (raw_setting.lower() == 'true')
        if raw_setting.lower() in ['none']:
            return None
        if raw_setting == '':
            return None
    if auto_convert_to_type is int:
        if not raw_setting: raw_setting = 0
        return int(raw_setting)
    if auto_convert_to_type is float:
        return float(raw_setting)
    if auto_convert_to_type is str:
        return str(raw_setting)
    if auto_convert_to_type is list:
        lis = str(raw_setting).split(',')
        if lis is None: lis = ()
        return lis
    return raw_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None

    def Get_Setting_Val(setting):
        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"' +
                                  setting + '"},"id":1}')
        return json.loads(val)['result']['value']
    
    try:
        usehttpproxy = Get_Setting_Val('network.usehttpproxy')
        if usehttpproxy and str(usehttpproxy).lower()=='true':
            httpproxytype = Get_Setting_Val('network.httpproxytype') #= get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = Get_Setting_Val('network.httpproxyserver') #= get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = Get_Setting_Val('network.httpproxyport') #= get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = Get_Setting_Val('network.httpproxyusername') #= get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = Get_Setting_Val('network.httpproxypassword') #= get_gui_setting(guisettings_xml, 'httpproxypassword')

    except:
        traceback.print_exc()
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
        return proxy_info
#__________________________________________________________________________
#


