#-*- coding: utf-8 -*-
import certifi
import io
import random
import sys
import os.path
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


PY3 = sys.version_info >= (3, 0)
PY2 = not PY3

if PY3: text_type = [str,]
if PY2: text_type = [basestring,str,unicode]

LOGNONE = xbmc.LOGNONE
LOGINFO = xbmc.LOGINFO
if PY2: LOGWARNING = xbmc.LOGWARNING
if PY3: LOGWARNING = xbmc.LOGWARNING
LOGNOTICE = xbmc.LOGINFO
LOGERROR = xbmc.LOGERROR

if PY2: import cookielib
if PY3: import http.cookiejar as cookielib
if PY2: from HTMLParser import HTMLParser
if PY3: from html.parser import HTMLParser
if PY3: from xbmcvfs import makeLegalFilename
if PY2: from xbmc    import makeLegalFilename
if PY2: from urllib import quote_plus
if PY3: from urllib.parse import quote_plus
if PY2: import StringIO
if PY3: StringIO = io.StringIO
if PY3: from xbmcvfs import translatePath
if PY2: from xbmc    import translatePath
if PY2:
    import HTMLParser
    html_parser= HTMLParser.HTMLParser()
    def unescape(s):
        return html_parser.unescape(s)    
if PY3: from html.parser import unescape
if PY2: from urllib import unquote_plus
if PY3: from urllib.parse import unquote_plus
if PY2: import urllib2
if PY3: import urllib.error as urllib2
if PY2: from urllib2 import urlparse    
if PY3: from urllib import parse as urlparse



DEFAULT_IS_ONLINE_SERVER_NAME = '1.1.1.1'
DEFAULT_IS_ONLINE_SERVER_PORT = '80'


this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
profileDir = this_addon.getAddonInfo('profile')
profileDir = translatePath(profileDir)
cookiePath = os.path.join(profileDir, 'cookies.lwp')
rootDir = this_addon.getAddonInfo('path')
default_icon = translatePath(os.path.join(rootDir, 'icon.png'))
DEFAULT_NOTIFY_TIME = 2000
try: default_GETHTML_cache_duration = int(this_addon.getSetting("GETHTML_cache_duration"))
except: default_GETHTML_cache_duration = 300 #seconds
try: default_ISONLINE_cache_duration = int(this_addon.getSetting("ISONLINE_cache_duration"))
except: default_ISONLINE_cache_duration = 77 #seconds
DEBUG = (this_addon.getSetting('debug').lower() == "true")

DEFAULT_HEADERS = {
    'User-Agent': "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    ,'Accept-Encoding': 'gzip,deflate'
    }
IE_USER_AGENT = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko'
FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/{}0101 Firefox/77.0'
OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.132 Safari/537.36 OPR/67.0.3575.97'
IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1'
ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.138 Mobile Safari/537.36'
EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.102 Safari/537.36 Edge/18.18363'
CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.182 Safari/537.36'
_USER_AGENTS = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT]
rand_ff_version = random.randint(120, 128)
rand_ff_patch = random.randint(0, 1)
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{}.{}) Gecko/20100101 Firefox/{}.{}".format(rand_ff_version,rand_ff_patch,rand_ff_version,rand_ff_patch)
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"

certPath = certifi.where()
