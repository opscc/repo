'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


#from F4mProxy import f4mProxyHelper

import urllib,re
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys,os



import datetime
import base64
import traceback
import json
try: # Python 2.6-2.7 
    from HTMLParser import HTMLParser
except ImportError:
    # Python 3
    from html.parser import HTMLParser

from utils import this_addon as addon
from utils import addon_id
from utils import Log
from utils import Notify
from utils import Header2pipestring
from utils import DEFAULT_HTTP_HEADERS
from utils import Sleep
from utils import DownloadVideo
from utils import GetHtml

from myplayer import MyPlayer

MODE_MAIN = 0
MODE_PAGE = 1
MODE_IPTV = 2
MODE_PLAY = 3
MODE_SEARCH = 4
MODE_SETTINGS = 5
MODE_DOWNLOAD = 6
MODE_REFRESH = 7
MODE_RESET_PLAYCOUNT = 8

#load our configurable settings
root_url = (addon.getSetting("search_starting_point"))
root_playlist_url = (addon.getSetting("root_playlist_url"))
root_song_url_generator = (addon.getSetting("root_song_url_generator"))
root_lineups_url = (addon.getSetting("root_lineups_url"))

#set global variables
addon_handle = int(sys.argv[1])
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';': rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
DEFAULT_ICON_IMAGE = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))


#################################
#################################
#################################
#################################

def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

#################################
#################################
#################################
#################################

def AddDir(name, url, mode, iconimage, folder=True):
    if url.startswith('plugin'):
        u = url
    else:
        u = (sys.argv[0] +
             "?url=" + urllib.quote_plus(url) +
             "&mode=" + str(mode) +
             "&name=" + urllib.quote_plus(name))
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type = 'music', infoLabels={"playCount":"888888"})
    liz.setProperty("IsPlayable","false")
    if addon_handle > 0:
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=folder)

#################################
#################################
# REFRESH
#################################
#################################

def REFRESH():
    xbmc.executebuiltin('Container.Refresh')

#################################
#################################
# RESET_PLAYCOUNT
#################################
#################################

def RESET_PLAYCOUNT(name):
    addon.setSetting(urllib.quote_plus("play_count_{}".format(name)), str(0))

#################################
#################################
#################################
#################################

def MAIN(url):

    # i want the refresh item at top; the [color will force it to top in most sort modes, and hardcoding 88888 to playcount will take care of others
    AddDir('[COLOR  blue]Refresh[/COLOR]','',MODE_REFRESH,'',folder=False)

    genrelist = list(())  #html page sometimes includes duplicates; use separate list to prevent duplicates from being parsed
    lineuplist = list(()) #html page sometimes includes duplicates; use separate list to prevent duplicates from being parsed
    #read basic page
    html = GetHtml(url)
    #Log(html)

    #uid of root_playlist_url allows for non-repeats(?)
    import uuid
    myUUID = str(uuid.uuid4())

    monitor = xbmc.Monitor()
   
    #show the front page streams
    links = re.compile('data-playable-object-id="([^"]+)".+?data-playable-object-title="([^"]+)".+?data-genre="([^"]+)".+?data-component-name="GenreTags">.+?cbcrc-genretag-([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    for stream_id, stream_name, genre_name, genre_id in links:
        if monitor.waitForAbort(0.01):
            xbmcplugin.endOfDirectory( addon_handle )
        if genrelist.count(stream_id) < 1: #html page sometimes includes duplicates; 
            genrelist.append(stream_id)
            url = root_playlist_url.format(stream_id, myUUID)
            AddPlayItem([None, url, HTMLParser().unescape(stream_name), HTMLParser().unescape(genre_name) ])

    #expand subcatetories
    lineups = re.compile('data-lineupid="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    for lineup_id in lineups:
        if monitor.waitForAbort(0.01):
            xbmcplugin.endOfDirectory( addon_handle )

        if lineuplist.count(lineup_id) < 1: #html page sometimes includes duplicates; 
            lineuplist.append(lineup_id)
            for i in range(1,5):
                #if monitor.waitForAbort(1): break
                try:
                    lineup_url = root_lineups_url.format(lineup_id, i)
                    lineup_html = GetHtml(lineup_url)
                except:
                    lineup_html = ''
                    traceback.print_exc()
                    break
                if lineup_html == '': # no more line-ups to expand for this lineup id - stop loop
                    break
                
                links = re.compile('data-playable-object-id="([^"]+)".+?data-playable-object-title="([^"]+)".+?data-genre="([^"]+)".+?data-component-name="GenreTags">.+?cbcrc-genretag-([^"]+)"', re.DOTALL | re.IGNORECASE).findall(lineup_html)
                for stream_id, stream_name, genre_name, genre_id in links:
                    #if monitor.waitForAbort(0.01): break
                    if genrelist.count(stream_id) < 1: #html page sometimes includes duplicates; 
                        genrelist.append(stream_id)
                        url = root_playlist_url.format(stream_id, myUUID)
                        AddPlayItem([None, url, HTMLParser().unescape(stream_name), HTMLParser().unescape(genre_name) ])


    if addon_handle > 0:
        xbmcplugin.setContent( addon_handle, 'songs' )
        #xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=GetSortMethod() )
        SetSortMethod()
        xbmcplugin.endOfDirectory( addon_handle )
    else:
        Log("handle isnull - can't endirectory)")

#################################
#################################
#################################
#################################

def SetSortMethod():
    sort_type = (addon.getSetting("sort_type"))
    if sort_type == 'name':
        sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE
    elif sort_type == 'genre':
        sortMethod=xbmcplugin.SORT_METHOD_GENRE #=15
    elif sort_type == 'playcount':        
        sortMethod=xbmcplugin.SORT_METHOD_PLAYCOUNT #= 35
    else:
        sortMethod=xbmcplugin.SORT_METHOD_UNSORTED

    #xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=sortMethod )  
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE )
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_PLAYCOUNT )
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_GENRE )    

############################################
############################################
############################################
############################################

def Download(url, title):
    log("\n Download [{},{}]\n".format(url, title))
    try:
        url, stream_type = Probe_url(url, title)
        #url = 'http://filmes.listaccess.me:8080/series/russo/123456/10935.mp4?token=HkFcUEIJRFgSU1ZQXQ9TAFxSVVwAAgJQVVMLXFIFVAVdWwAGAllQU1QUGRFKTUdXWA5rUFBDC1NSXApQGEMURwARa1hVQ1xABQcAAQ0bGRBNCllcFlsAV1FUDVwMVFEASUFEWFVDXEAHBw0EGxUXV0EXUUtaAF09BgBPDFcEQw5HQRgTXg85BlVbVF1dGw8QCUEYG10SQUBYR20AXxIAQhMaFGJeDRMWWVlbQBlwW1EXQRgbVghFEAMRXEcOQ1AHV1QWHRMCCRdeQkdKGwMXcXhBGBtRGUUHDBZQClpDWxYIEwATHUMPEW9EUEBNS1BTVAZGGw5DAUBOR1QETD4CWwsNUVJFCAkMQxQPEQgbGRBUDFpQQA5DPRIMXUcODxRYCR4=|Accept-Encoding=gzip,deflate&User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
        DownloadVideo(url, title)
    except:
        traceback.print_exc()

############################################
############################################
############################################
############################################
    
def AddPlayItem(link_tuple):
    playable_url  = link_tuple[1]
    friendly_name = link_tuple[2]
    playlist_genre = link_tuple[3]
    try:    play_count = int(addon.getSetting(urllib.quote_plus("play_count_{}".format(friendly_name))))
    except: play_count = 0
    
    liz = xbmcgui.ListItem(friendly_name)
    liz.setInfo(
        type="music"
        , infoLabels={"title": friendly_name
                      , "genre":playlist_genre
                      , "playCount":play_count
                      , "mediatype":"music"})
    #liz.setArt( {'thumb': DEFAULT_ICON_IMAGE
    #             ,'icon': DEFAULT_ICON_IMAGE} ) 
    #liz.addStreamInfo('music' , {'codec': 'h264'})
    #liz.setProperty("IsPlayable","true")
    #liz.setProperty("playCount", str(play_count))

##https://codedocs.xyz/AlwinEsch/kodi/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
##setinfo
##racknumber	integer (8)
##discnumber	integer (2)
##duration	integer (245) - duration in seconds
##year	integer (1998)
##genre	string (Rock)
##album	string (Pulse)
##artist	string (Muse)
##title	string (American Pie)
##rating	float - range is between 0 and 10
##userrating	integer - range is 1..10
##lyrics	string (On a dark desert highway...)
##playcount	integer (2) - number of times this item has been played
##lastplayed	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
##mediatype	string - "music", "song", "album", "artist"
##dbid	integer (23) - Only add this for items which are part of the local db. You also need to set the correct 'mediatype'!
##listeners	integer (25614)
##musicbrainztrackid	string (cd1de9af-0b71-4503-9f96-9f5efe27923c)
##musicbrainzartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
##musicbrainzalbumid	string (24944755-2f68-3778-974e-f572a9e30108)
##musicbrainzalbumartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
##comment	string (This is a great song)

    contextMenuItems = []    
    if '.mp4' in playable_url:
        download_url = "{}?url={}&mode={}&name={}".format(
                    sys.argv[0]
                    ,urllib.quote_plus(playable_url.encode('utf-8'))
                    ,MODE_DOWNLOAD
                    ,urllib.quote_plus(friendly_name.encode('utf-8'))
                    )
        contextMenuItems.append(('[COLOR hotpink]Download Video[/COLOR]', 'xbmc.RunPlugin('+download_url+')'))

    reset_playcount_url = "{}?url={}&mode={}&name={}".format(
                sys.argv[0]
                ,urllib.quote_plus(playable_url.encode('utf-8'))
                ,MODE_RESET_PLAYCOUNT
                ,urllib.quote_plus(friendly_name.encode('utf-8'))
                )
    contextMenuItems.append(('[COLOR blue]Reset Playcount[/COLOR]', 'xbmc.RunPlugin('+reset_playcount_url+')'))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        

    if addon_handle > 0:
        if isinstance(friendly_name, str):  friendly_name = unicode(friendly_name, "utf-8")

        internally_redirected_url = "{}?url={}&mode={}&name={}".format(
                    sys.argv[0]
                    ,urllib.quote_plus(playable_url.encode('utf-8'))
                    ,MODE_PLAY
                    ,urllib.quote_plus(friendly_name.encode('utf-8'))
                    )

        xbmcplugin.addDirectoryItem(handle=addon_handle
                                    , url=internally_redirected_url
                                    , listitem=liz
                                    , isFolder=False)


############################################
############################################
# MyPlaylist
############################################
############################################

#class MyPlaylist(xbmc.PlayList):
class MyPlaylist():

    def __init__(self, *args, **kwargs):

        self._xbmcplaylist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        self._xbmcplaylist.clear()

        self.playlist = []
        self.playitem = 0
        self.last_resolved_play_file = None

        self.player = None

        #keep track of all the songs we have played
        self.wamIDlist = list() #make per channel?
        try:
            self.save_recent_wam_ID_list = addon.getSetting("save_recent_wam_ID_list")
        except:
            self.save_recent_wam_ID_list = True
        if self.save_recent_wam_ID_list: #if we are saving, then we are also restoring
            try:
                for s in addon.getSetting("recent_wam_ID_list").replace("&apos;", "").replace("[","").replace("]","").replace("'","").split(","):
                    self.wamIDlist.append(s.strip())
            except:
                pass
        #self.wamIDlist = ['217448', '69008', '54550', '193707', '68672', '191179', '54498', '68749', '202306', '217452', '166339', '217442', '68669', '54099', '54125', '211052', '218951', '166344', '68702', '54207', '54319', '215501', '54217', '202083', '210000', '173163', '54129', '206545', '724', '68777', '217444', '53973', '211048', '53882', '35326', '192908', '54040', '53890', '54190', '186970', '53851', '54202', '181058', '68680', '217445', '54634', '213383', '53834', '54095']

        try:
            self.max_wamIDlist_size = int(addon.getSetting("max_wamIDlist_size"))
        except:
            self.max_wamIDlist_size = 200


        #for testing #make parameter?
        self.i_max=20                
                
    def add (self, idMedia, playitem):
        self.playlist.append([idMedia, playitem])
        
    def _geturl(self):
        current_play_item = self.playlist[self.playitem]
        
        #get the link for the song
        url_generator = root_song_url_generator.format(current_play_item[0])
        html = GetHtml(url_generator)
        media = json.loads(html)
        Log("_geturl:" + repr(media))
        url = media['url']
        Log(url)
        url_split = url.split('/')
        #sometimes provider sends a url with curly brackets where they can't be ...
        url = url.replace( url_split[7],  url_split[7].replace('{', '%7B').replace('}', '%7D') )
        Log(url)
        return "{}{}".format(url, Header2pipestring())        

    def getlistitem(self, position=None):
        if self.playitem >= len(self.playlist):
            return None 

        if not position:
            current_play_item = self.playlist[self.playitem]
        else:
            current_play_item = self.playlist[position]
        
        #todo add next and prev options in set info

        listitem = xbmcgui.ListItem(name, iconImage='', thumbnailImage='')

        Log("current_play_item[0],[1]{},{}".format(current_play_item[0], current_play_item[1]))
        listitem.setInfo('music', current_play_item[1]) #current_play_item[1] contains {'title': trackTitle, 'comment': wamId, 'album': albumTitle , 'duration': duration , 'artist': performers  }   )

        listitem.setPath(self._geturl())

        if not position:
            self.playitem += 1
            
        return listitem

    def resolveNext(self):

        Log("self.resolveNext")

        current_resolved_play_file = self.last_resolved_play_file
        
        #get current playlist position
        curr_pos = int(self._xbmcplaylist.getposition())
        next_pos = curr_pos + 1
        #Log("curr_pos:{}".format(curr_pos))

        self._xbmcplaylist.remove(current_resolved_play_file)

        #fill in the correct path for the next item
        #Log("getlistitem start:{}".format(next_pos))
        listitem =  self.getlistitem(next_pos)
        self.last_resolved_play_file = listitem.getPath()
        self._xbmcplaylist.add(listitem.getPath(), listitem, next_pos)
        #Log("getlistitem end:{}".format(next_pos))


        Log("resolveNext.repr(self.playlist): " + repr(self.playlist))

    def fillPlayList(self, playlist_url):

        Log("self._xbmcplaylist.getPlayListId:{}".format(self._xbmcplaylist.getPlayListId()))

        self._xbmcplaylist.clear()
        
        #read playlist json info from url
        html = GetHtml(playlist_url)
        json_playlist = json.loads(html)['tracks']
        Log("fillPlayList.json_playlist:{}".format(repr(json_playlist)))

        item_was_added = 0
        while item_was_added == 0:        
            # sometimes we will run out of items to add; e.g. all top40 songs played;

            i=0 #used during testing; limit number of items in queue to i_max
            for playItem in json_playlist:
                i=i+1
                if len(json_playlist) == i: break     #exit last item in json; it is a cbc dud

                wamId = str(playItem['wamId'])
                trackTitle = playItem['trackTitle']
                albumTitle = playItem['albumTitle']
                duration = int(playItem['duration'])/1000
                performers = playItem['performers']
                #url_generator = root_song_url_generator.format(wamId)

                if wamId in self.wamIDlist:
                    Log("skip {} [title='{}' artist='{}'] as we have already played it".format(wamId, repr(trackTitle),repr(performers) ) )
                    continue  #skip this song if we have already played it
                else:
                    
                    Log("Adding to playlist title='{}' artist='{}' wamId='{}'".format(repr(trackTitle),repr(performers),repr(wamId)), xbmc.LOGNOTICE)
                    self.wamIDlist.append(wamId)
                    if len(self.wamIDlist) > self.max_wamIDlist_size:
                        Log("popping list")
                        self.wamIDlist.pop(0) #trim first item if getting too big
                      
                    self.add(wamId, {'title': trackTitle, 'comment': wamId, 'album': albumTitle , 'duration': duration , 'artist': performers }   )

                    item_was_added = item_was_added + 1
               
                if i > self.i_max: break #for testing

            # if we have parsed the cbc playlist _once_ without adding an item
            # then we can be fairly sure  that we need to reset the recently played list
            # and retry adding the items in the playlist
            if len(json_playlist) < 1:
                item_was_added = 1 #just incase this was null
            if item_was_added == 0 :
                Log("Clearing list because nothing was added", xbmc.LOGNOTICE)
                del self.wamIDlist[:]
        

        Log("wamIDlist {}".format(repr(self.wamIDlist)))
        if self.save_recent_wam_ID_list:
            Log("saving wamIDlist")
            addon.setSetting("recent_wam_ID_list", repr(self.wamIDlist))
                    
        Log("fillPlayList.repr(self.playlist): {}".format(repr(self.playlist)))




def PLAY(playlist_url, playlist_channel):

    Log("\n PLAY [{},{}]\n".format(playlist_url, playlist_channel))
    
    try:    play_count = int(addon.getSetting(urllib.quote_plus("play_count_{}".format(playlist_channel))))
    except: play_count = 0
    addon.setSetting(urllib.quote_plus("play_count_{}".format(playlist_channel)), str(play_count + 1))

    try:    playing_genre = addon.getSetting("playlist_channel")
    except: playing_genre = 0
    addon.setSetting("playlist_channel", playlist_channel)

    #xbmc.executebuiltin('Container.Refresh') #for updating playcount ... currently I choose not to do this because it is slow
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )


    #my_playlist = PlaylistFromJSON(playlist_url)    
    my_playlist = MyPlaylist()
    my_playlist.fillPlayList(playlist_url)

    default_playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    default_playlist.clear()

    player = MyPlayer()
    player.root_song_url_generator = root_song_url_generator
    player.set_is_active()
    player.set_playlist_pointer(my_playlist)
        
    #
    # we add one single song at a time to the [cleared] xbmc playlist because 
    # a playlist can't be edited in real-time
    # 
    # we can't add all the songs at once because the url's contents expire after
    # a few minutes
    #
    # this means no next/previous funtionality
    #
            
    monitor = xbmc.Monitor()
    while True:

        #player.is_active is used to help detect if the player object has crashed without
        # letting us know e.g. http 404 
        if player.is_active == True or player.song_skipped == True:
            listitem = my_playlist.getlistitem()
            if not listitem:
                Log("play list exausted...reloading")
                #my_playlist = None
                #Sleep(500) #allow cleanup? memory issue?
                my_playlist.fillPlayList(playlist_url)
                #my_playlist = PlaylistFromJSON(playlist_url)
                listitem = my_playlist.getlistitem()
        else:
            # - we have begun to play a song
            # - it did not end normally [playback-ended event did not occur ]
            # - and/or it was not deliberately skippped
            my_playlist._geturl() # force the time-dependent url to be recalculated

        if not listitem:
            Log("exiting play because unable to load play list information")
            break #exit if we still don't have information

        default_playlist.clear() #beause we are not acutally using playist
        default_playlist.add(listitem.getPath(), listitem)
                
        try:

            Log( "Playing: {} -- {}".format(listitem.getMusicInfoTag().getTitle(),listitem.getMusicInfoTag().getArtist()),  xbmc.LOGNOTICE)
            player.is_active = False

            if addon.getSetting("media_player").lower() == "fmproxy":
                #title_info={'title': trackTitle, 'comment': wamId, 'album': albumTitle , 'duration': duration , 'artist': performers  } 
                #stream_type = 'HLSREDIR'
                stream_type = 'HLS'
                url = listitem.getPath()
                from F4mProxy import f4mProxyHelper
                if not player.fmproxyhelper:
                    f4mp=f4mProxyHelper()
                    player.fmproxyhelper = f4mp

                f4mp.playF4mLink( url=url
                                 ,name=listitem.getMusicInfoTag().getTitle()
                                 ,proxy=None
                                 ,use_proxy_for_chunks=False
                                 ,maxbitrate=0
                                 ,simpleDownloader=False
                                 ,auth=None
                                 ,streamtype = stream_type
                                 ,setResolved=False
                                 ,swf=None
                                 ,callbackpath=""
                                 ,callbackparam=""
                                 ,iconImage=DEFAULT_ICON_IMAGE
                                 ,title_info={   'title'  :listitem.getMusicInfoTag().getTitle()   \
                                                ,'artist' :listitem.getMusicInfoTag().getArtist()  \
                                                ,'album'  :listitem.getMusicInfoTag().getAlbum()   \
                                                ,'comment':listitem.getMusicInfoTag().getComment() \
                                                 }
                                 )
                
            else:
                player.play(default_playlist)

        except:
            traceback.print_exc()

        if monitor.waitForAbort(0.1) or monitor.abortRequested == True :
            Log("ending thread {} due to abort".format(""))
            return


        try:    playing_genre = addon.getSetting("playlist_channel")
        except: playing_genre = 0
        if playing_genre != playlist_channel:
            Log("Channel changed from {} to {}. Ending thread".format(playlist_channel, playing_genre ))
            break
    
        try:
            current_play_item = player.getPlayingFile()
        except:
            pass

        while xbmc.Player().isPlaying():
            #Log("isPlaying")
            Sleep(500)

        Sleep(500) #for kodi 18.0 this sleep is required for the 'was_stopped' to be executed properly
        Log("player.song_skipped={}, player.is_active={}, player.was_stopped={},  player.continue_after_download={}".format(player.song_skipped, player.is_active, player.was_stopped, player.continue_after_download))
        #if player.is_active == True and player.was_stopped == True and not player.continue_after_download:
        if player.was_stopped == True and not player.continue_after_download:
            Log("exiting play infinite loop because was stopped")
            break

        getPlayingFile = None
        try:
            if xbmc.Player().isPlaying():
                getPlayingFile = player.getPlayingFile()
        except:
            pass

        if getPlayingFile:  #if getPlayingFile is none then that means song has 'stopped' in some way
            if current_play_item != player.getPlayingFile():    #otherwise a different player has been started 
                Log("exiting play infinite loop  because a different program is doing the playing now", xbmc.LOGNONE)
                break

############################################
############################################
# Main entry point
############################################
############################################

try:
    mode = None
    params = getParams()
    try:     url = urllib.unquote_plus(params["url"])
    except:  url = None
#"https://services.radio-canada.ca/music/dj/v1/playlists/{}?userId={}&amp;platformId=0" />
#0df2af40-cd7b-11e8-9dcf-cd1aaa6932aa
    
    try:    name = urllib.unquote_plus(params["name"])
    except: name = None
    try:    mode = int(params["mode"])
    except: mode = None
    try:     img = urllib.unquote_plus(params["img"])
    except:  img = None

    if   mode          is None: MAIN(root_url)
    elif mode ==     MODE_MAIN: MAIN(root_url)
    elif mode ==     MODE_PLAY: PLAY(url, name)
    elif mode == MODE_DOWNLOAD: Download(url, name)
    elif mode ==  MODE_REFRESH: REFRESH()
    elif mode ==  MODE_RESET_PLAYCOUNT: RESET_PLAYCOUNT(name)
    

except:
    traceback.print_exc()
    pass

############################################
############################################
# End of file
############################################
############################################
