import xbmc
import time
import os
import json

from utils import this_addon
from utils import addon_id
from utils import Log
from utils import Notify
from utils import DEFAULT_ICON_IMAGE
from utils import GetHtml
from utils import Header2pipestring

from F4mProxy import f4mProxyHelper

############################################
############################################
# MyPlayer
############################################
############################################
class MyPlayer(xbmc.Player):
    def __init__( self, *args, **kwargs):
        xbmc.Player.__init__(self, *args)
        self.is_active = True
        self.was_stopped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.play_paused_count = None
        self.continue_after_download = False
        self.playlist_pointer = None
        self.fmproxyhelper = None
        self.root_song_url_generator = None
        self.song_skipped = False

    def set_playlist_pointer( self, playlist ):
        self.playlist_pointer = playlist


    def set_is_active( self ):
        self.is_active = True


    def onPlayBackPaused( self ):
        Log("onPlayBackPaused")
        self.speedChangedTime = None
        self.speedChangedCount = None

        max_play_paused_count = 1
        max_play_paused_window = 10
        
        if self.play_paused_time:
            #Log("play_paused_time_delta: " + repr(time.time() - self.play_paused_time))

            if (time.time() - self.play_paused_time) > max_play_paused_window:
                self.play_paused_time = None
                self.play_paused_count = None
                #Log("values should be reset")
                return
            
            if self.play_paused_count:
                self.play_paused_count = self.play_paused_count + 1
            else:
                self.play_paused_count = 1

            #Log("play_paused_count" + str(self.play_paused_count))

            #save media to disk when this happens
            if self.play_paused_count >= max_play_paused_count:
                self.SaveSong()

        else:
            self.play_paused_time = time.time()


    def SaveSong( self ):
##        media_player = this_addon.getSetting("media_player").lower()
##        if media_player == "fmproxy":
##            Notify('Downloading only available with Normal player')
##            self.play_paused_time = None
##            self.play_paused_count = None
##            self.continue_after_download = True
##            self.onPlayBackResumed()
##            return


        Log("getMusicInfoTag - title:'{}'".format(self.getMusicInfoTag().getTitle()))
        Log("getMusicInfoTag - comment:'{}'".format(self.getMusicInfoTag().getComment() ) )

        if not self.getMusicInfoTag().getComment():
            Notify('Id is blank: skipping')
            return
        

        file_name = "{} - {}.ts".format(self.getMusicInfoTag().getArtist(), self.getMusicInfoTag().getTitle()).replace('/', '.')
        file_folder = this_addon.getSetting("download_path").lower()
        download_path = os.path.join(file_folder, file_name)
        Notify('Saving song to ' + download_path)

        #Log("download_path:'{}'".format(download_path))
        #url_generator = 'https://api.radio-canada.ca/validationMedia/v1/Validation.html?connectionType=broadband&output=json&multibitrate=true&deviceType=ipad&appCode=wamen&idMedia=43353'
        #html = GetHtml(url_generator)
        #media = json.loads(html)
        #_geturl = "{}".format(media['url'])

        url =  self.getPlayingFile()
        #Log("url:'{}'".format(url))

        #get new link for the song - the original may have expired
        #url_generator = root_song_url_generator.format('35823') #test data
        if self.root_song_url_generator:
            url_generator = self.root_song_url_generator.format(self.getMusicInfoTag().getComment())
            html = GetHtml(url_generator)
            media = json.loads(html)
            url = "{}{}".format(media['url'], Header2pipestring())        

        Log("url:'{}'".format(url))

        if self.fmproxyhelper:
            #stop current proxy before starting next one
            self.fmproxyhelper.seekToEnd()
        
        stream_type = 'HLS'
        if not self.fmproxyhelper:
            self.fmproxyhelper = f4mProxyHelper()



        self.fmproxyhelper.playF4mLink( \
                        url=url \
                        ,name= self.getMusicInfoTag().getTitle()
                        ,proxy=None
                        ,use_proxy_for_chunks=False
                        ,maxbitrate=0
                        ,simpleDownloader=False
                        ,auth=None
                        ,streamtype = stream_type
                        ,setResolved=False
                        ,swf=None
                        ,callbackpath=""
                        ,callbackparam=""
                        ,iconImage=DEFAULT_ICON_IMAGE
                        ,download_path=download_path
                        ,title_info={   'title'  :self.getMusicInfoTag().getTitle()  \
                                        ,'artist' :self.getMusicInfoTag().getArtist() \
                                        ,'album'  :self.getMusicInfoTag().getAlbum()  \
                                     }
                        )



        Notify('Playing next song after finishing saving ' + file_name)

        self.play_paused_time = None
        self.play_paused_count = None
        self.continue_after_download = True
        

    def onPlayBackResumed( self ):
        Log("onPlayBackResumed")
        self.speedChangedTime = None
        self.speedChangedCount = None
        

    def onPlayBackSpeedChanged(self, speed):
        Log("onPlayBackSpeedChanged")
        
        max_speedchange_count = 2
        max_speedchange_window = 5  

        if not self.speedChangedTime:
            self.speedChangedTime = time.time()
            return

        #Log(repr(time.time() - self.speedChangedTime))
        if (time.time() - self.speedChangedTime) > max_speedchange_window:
            self.speedChangedTime = None
            self.speedChangedCount = 0
            return

        if self.speedChangedCount:
            self.speedChangedCount = self.speedChangedCount + 1
        else:
            self.speedChangedCount = 1

        if self.speedChangedCount == max_speedchange_count:
            self.song_skipped = True
            Log("seeking to end of song")
            if self.fmproxyhelper:
                self.fmproxyhelper.seekToEnd()
            else:
                self.seekTime(self.getTotalTime()-1 )
        else: 
            self.speedChangedTime = time.time()


    def onPlayBackSeek( self, seek_time, seek_offset ):
        Log("onPlayBackSeek:: getTotalTime()={} seek_time={} seek_offset={} speedChangedCount={}  speedChangedTime={}".format(self.getTotalTime(), seek_time, seek_offset,repr(self.speedChangedCount), repr(self.speedChangedTime) ) )


    def onPlayBackStarted( self ):
        self.is_active = True  #important call to detect if http 404 error occured
        self.song_skipped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.continue_after_download = False
        try:
            Log("onPlayBackStarted :: " + self.getPlayingFile())
        except:
            pass


    def onPlayBackEnded(self):
        Log("onPlayBackEnded")
        self.is_active = True
        self.was_stopped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.continue_after_download = False


    def onPlayBackStopped(self):
        Log("onPlayBackStopped")
        self.was_stopped = True

        
    def onQueueNextItem(self):
        Log("onQueueNextItem")
        self.is_active = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.continue_after_download = False
