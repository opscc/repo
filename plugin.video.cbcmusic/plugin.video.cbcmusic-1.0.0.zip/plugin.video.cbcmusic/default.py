'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
import utils

import re
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys,os

import uuid
    
import time
import datetime
import base64
import traceback
import json

from utils import this_addon as addon
from utils import Clear_Simplecache
from utils import addon_id
from utils import TimeStampFor
from utils import Log,LogR
from utils import Notify
from utils import Header2pipestring
from utils import DEFAULT_HTTP_HEADERS
from utils import DEFAULT_ICON_IMAGE
from utils import addon_handle
from utils import Sleep
from utils import DownloadVideo
from utils import GetHtml

from myplayer import MyPlayer

MODE_MAIN = 0
MODE_PAGE = 1
MODE_IPTV = 2
MODE_PLAY_GENRE = 3
MODE_PLAY_SINGLE = 9
MODE_SEARCH = 4
MODE_SETTINGS = 5
MODE_DOWNLOAD = 6
MODE_REFRESH = 7
MODE_RESET_PLAYCOUNT = 8
MODE_CONFIGURE_FMproxy= 9995


#load our configurable settings
root_url = (addon.getSetting("search_starting_point"))
root_url = "https://www.cbc.ca/listen/cbc-music-playlists"
root_playlist_url = (addon.getSetting("root_playlist_url"))
ROOT_SONG_URL_GENERATOR = (addon.getSetting("root_song_url_generator"))
root_lineups_url = (addon.getSetting("root_lineups_url"))


#################################
#################################
#################################
#################################

def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

#################################
#################################
#################################
#################################

def AddDir(name, url, mode, iconimage, folder=True):
    if url.startswith('plugin'):
        u = url
    else:
        u = (sys.argv[0] +
             "?url=" + C.quote_plus(url) +
             "&mode=" + str(mode) +
             "&name=" + C.quote_plus(name))
    liz = xbmcgui.ListItem(name)
    if C.PY2:
        liz.setInfo(
            type="music"
            , infoLabels={
                "playCount": "888888"
                }
            )
    if C.PY3:
        liz.getMusicInfoTag().setMediaType('music')
        liz.getMusicInfoTag().setPlayCount(888888)
        
    liz.setProperty("IsPlayable", "false")
##    liz.setProperty("IsPlayable", "true")
    liz.setArt(
        { 'thumb': iconimage #must include thumb to avoid error log messages
          }
        ) 
    xbmcplugin.addDirectoryItem(handle=addon_handle
                                , url=u
                                , listitem=liz
                                , isFolder=folder
                                )

#################################
#################################
# REFRESH
#################################
#################################

def REFRESH():
    #Clear_Simplecache()
    xbmc.executebuiltin('Container.Refresh')

#################################
#################################
# RESET_PLAYCOUNT
#################################
#################################

def RESET_PLAYCOUNT(name):
    addon.setSetting(C.quote_plus("play_count_{}".format(name)), str(0))

#################################
#################################
#################################
#################################

def MAIN(url):

    # i want the refresh item at top; the [color will force it to top in most sort modes, and hardcoding 88888 to playcount will take care of others
    AddDir('[COLOR  blue]Refresh[/COLOR]','',MODE_REFRESH,'',folder=False)

    #read basic page
##    html = global_cache.get(
##        addon_id
##        )
##    if not html: html = GetHtml(url)
##    global_cache.set(
##        endpoint = addon_id
##        ,data = html
##        ,expiration = datetime.timedelta(seconds=html_timeout)
##        )
    html = GetHtml(url, cache_id=addon_id)
    TimeStampFor('htmlget')
##    if debug:
##        net = (datetime.datetime.now()-t_start).total_seconds()
##        Log("milliseconds for htmlget={:.0f}ms".format(net*1000) )

    #uid of root_playlist_url is a form of security
    myUUID = str(uuid.uuid4())
   
    #show the front page streams
    html = html.replace('\\\"', '\\\'')

    #music info can be duplicated - filter out the correct region
    region_regex = ('musicStreamDetailData(.*)')
    links = re.compile(region_regex, re.DOTALL | re.IGNORECASE).findall(html)
    if links: html = links[0]
                    
    regex = ('{"id":"(\d+)"'
             '.+?"title":"(.+?)"'
             '.+?"summary":"(.+?)"'
             '.+?"imageURL":"(.+?)"'
             '.+?"webURL":"(.+?)"'
             '.+?"genreID":"(.+?)"'
             '.+?"genreName":"(.+?)"'
             )
    links = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    if not links:
        Log('links were not found via regex', C.LOGERROR)
    TimeStampFor('regex')
    
    for stream_id, stream_name, summary_text, image_url, weburl, genre_id, genre_name in links:
        url = root_playlist_url.format(stream_id, myUUID)
        image_url = image_url.replace("${width}","320").replace("${ratio}","1x1")
        AddPlayItem([MODE_PLAY_GENRE
                     , url
                     , C.unescape(stream_name)
                     , C.unescape(genre_name)
                     , image_url
                     , summary_text
                     , "artist"
                     , "album"
                     ]
                    )
    TimeStampFor('addplayitems')

    
    if addon_handle > 0:
        xbmcplugin.setContent( addon_handle, 'songs' )
        SetSortMethod()
        xbmcplugin.endOfDirectory( addon_handle
                                  , succeeded=True
                                  , updateListing  = False
                                  , cacheToDisc = True
                                  )
    else:
        Log("handle isnull - can't endirectory)")

#################################
#################################
#################################
#################################

def SetSortMethod():
    sort_type = (addon.getSetting("sort_type"))
    if sort_type == 'name':
        sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE
    elif sort_type == 'genre':
        sortMethod=xbmcplugin.SORT_METHOD_GENRE #=15
    elif sort_type == 'playcount':        
        sortMethod=xbmcplugin.SORT_METHOD_PLAYCOUNT #= 35
    else:
        sortMethod=xbmcplugin.SORT_METHOD_UNSORTED

    #xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=sortMethod )  
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE )
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_PLAYCOUNT )
    xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_GENRE )    

############################################
############################################
############################################
############################################

def Download(url, title):
    log("\n Download [{},{}]\n".format(url, title))
    try:
        url, stream_type = Probe_url(url, title)
        #url = 'http://filmes.listaccess.me:8080/series/russo/123456/10935.mp4?token=HkFcUEIJRFgSU1ZQXQ9TAFxSVVwAAgJQVVMLXFIFVAVdWwAGAllQU1QUGRFKTUdXWA5rUFBDC1NSXApQGEMURwARa1hVQ1xABQcAAQ0bGRBNCllcFlsAV1FUDVwMVFEASUFEWFVDXEAHBw0EGxUXV0EXUUtaAF09BgBPDFcEQw5HQRgTXg85BlVbVF1dGw8QCUEYG10SQUBYR20AXxIAQhMaFGJeDRMWWVlbQBlwW1EXQRgbVghFEAMRXEcOQ1AHV1QWHRMCCRdeQkdKGwMXcXhBGBtRGUUHDBZQClpDWxYIEwATHUMPEW9EUEBNS1BTVAZGGw5DAUBOR1QETD4CWwsNUVJFCAkMQxQPEQgbGRBUDFpQQA5DPRIMXUcODxRYCR4=|Accept-Encoding=gzip,deflate&User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
        import downloader
        downloader.downloadVideo(url, title, download_path=None)
        #DownloadVideo(url, title)
    except:
        traceback.print_exc()

############################################
############################################
############################################
############################################
    
def AddPlayItem(link_tuple, return_url_only=False):
    play_mode = link_tuple[0]
    playable_url  = link_tuple[1]
    friendly_name = link_tuple[2]
    playlist_genre = link_tuple[3]
    
    try:        playitem_art = link_tuple[4]
    except:     playitem_art = DEFAULT_ICON_IMAGE 
    try:        summary_text = link_tuple[5]
    except:     summary_text = ""
    try:        artist = link_tuple[6]
    except:     artist = ""
    try:        album = link_tuple[7]
    except:
        raise
        album = ""
        
    try:    play_count = int(addon.getSetting(C.quote_plus("play_count_{}".format(friendly_name))))
    except: play_count = 0

    if not '|' in playitem_art and not playitem_art == DEFAULT_ICON_IMAGE:
        playitem_art += Header2pipestring(DEFAULT_HTTP_HEADERS)

    if C.PY2:
        if isinstance(friendly_name, str):  friendly_name = unicode(friendly_name, "utf-8")

##    LogR(summary_text)
    if C.PY3: summary_text = summary_text.encode('utf-8')
    internally_redirected_url = "{}?url={}&mode={}&name={}&playlist_genre={}&play_count={}&summary_text={}&playitem_art={}&artist={}&album={}".format(
                sys.argv[0]
                ,C.quote_plus(playable_url.encode('utf-8'))
                ,play_mode #MODE_PLAY_GENRE
                ,C.quote_plus(friendly_name.encode('utf-8'))
                ,C.quote_plus(playlist_genre.encode('utf-8'))
                ,play_count
                ,C.quote_plus(summary_text)
                ,C.quote_plus(playitem_art.encode('utf-8'))
                ,C.quote_plus(artist.encode('utf-8'))
                ,C.quote_plus(album.encode('utf-8'))
                )

    if return_url_only:
        return internally_redirected_url
    
    liz = xbmcgui.ListItem(friendly_name)
##    liz.setProperty("IsPlayable","true")
    liz.setProperty("IsPlayable","false")
    
    if C.PY2:
        liz.setInfo(
            type="music"
            , infoLabels={  "title": friendly_name
                            , "genre": playlist_genre
                            , "playCount": play_count
                            , "mediatype":"music"
                            , "comment": summary_text
                            , "artist": artist
                            , "album": album
                            }
            )
    if C.PY3:
        videoInfoTag = liz.getMusicInfoTag()
        videoInfoTag.setTitle(friendly_name)
        videoInfoTag.setGenres((playlist_genre,))
        videoInfoTag.setPlayCount(play_count)
        videoInfoTag.setMediaType('music')
        videoInfoTag.setComment(summary_text)
        videoInfoTag.setArtist(artist)
        videoInfoTag.setAlbum(album)
        

        
    liz.setArt(
        {
            'thumb': playitem_art
            ,'icon': playitem_art
         }
    ) 
    #liz.addStreamInfo('music' , {'codec': 'h264'})
    
    #liz.setProperty("playCount", str(play_count))

    #Log("playable_url={}, friendly_name={}, playlist_genre={}, playitem_art={}".format(playable_url, friendly_name, playlist_genre, playitem_art))

##https://codedocs.xyz/AlwinEsch/kodi/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
##setinfo
##racknumber	integer (8)
##discnumber	integer (2)
##duration	integer (245) - duration in seconds
##year	integer (1998)
##genre	string (Rock)
##album	string (Pulse)
##artist	string (Muse)
##title	string (American Pie)
##rating	float - range is between 0 and 10
##userrating	integer - range is 1..10
##lyrics	string (On a dark desert highway...)
##playcount	integer (2) - number of times this item has been played
##lastplayed	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
##mediatype	string - "music", "song", "album", "artist"
##dbid	integer (23) - Only add this for items which are part of the local db. You also need to set the correct 'mediatype'!
##listeners	integer (25614)
##musicbrainztrackid	string (cd1de9af-0b71-4503-9f96-9f5efe27923c)
##musicbrainzartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
##musicbrainzalbumid	string (24944755-2f68-3778-974e-f572a9e30108)
##musicbrainzalbumartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
##comment	string (This is a great song)
        
    liz.setArt(
            {
            'thumb': playitem_art
            ,'icon': playitem_art
            }
        )
    
    contextMenuItems = []    
    if '.mp4' in playable_url:
        download_url = "{}?url={}&mode={}&name={}&playlist_genre={}&play_count={}&summary_text={}&playitem_art={}&artist={}&album={}".format(
                    sys.argv[0]
                    ,C.quote_plus(playable_url.encode('utf-8'))
                    ,MODE_DOWNLOAD
                    ,C.quote_plus(friendly_name.encode('utf-8'))
                    ,C.quote_plus(playlist_genre.encode('utf-8'))
                    ,play_count
                    ,C.quote_plus(summary_text)
                    ,C.quote_plus(playitem_art.encode('utf-8'))
                    ,C.quote_plus(artist.encode('utf-8'))
                    ,C.quote_plus(album.encode('utf-8'))
                    )
        contextMenuItems.append(('[COLOR hotpink]Download Video[/COLOR]'
                                 , 'RunPlugin('+download_url+')'))

    reset_playcount_url = "{}?url={}&mode={}&name={}&playlist_genre={}&play_count={}&summary_text={}&playitem_art={}&artist={}&album={}".format(
                sys.argv[0]
                ,C.quote_plus(playable_url.encode('utf-8'))
                ,MODE_RESET_PLAYCOUNT
                ,C.quote_plus(friendly_name.encode('utf-8'))
                ,C.quote_plus(playlist_genre.encode('utf-8'))
                ,play_count
                ,C.quote_plus(summary_text)
                ,C.quote_plus(playitem_art.encode('utf-8'))
                ,C.quote_plus(artist.encode('utf-8'))
                ,C.quote_plus(album.encode('utf-8'))
                )
    contextMenuItems.append(('[COLOR blue]Reset Playcount[/COLOR]'
                             , 'RunPlugin('+reset_playcount_url+')'))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        
##    if addon_handle > 0:
    xbmcplugin.addDirectoryItem(handle=addon_handle
                                , url=internally_redirected_url
                                , listitem=liz
                                , isFolder=False
                                )


############################################
############################################
# MyPlaylist
############################################
############################################

#class MyPlaylist(xbmc.PlayList):
class MyPlaylist():

    def __init__(self, *args, **kwargs):

        self._xbmcplaylist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        self._xbmcplaylist.clear()

        self.playlist = []
        self.playitem = 0
        self.last_resolved_play_file = None

        self.player = None

        #keep track of all the songs we have played
        self.wamIDlist = list() #make per channel?
        try:
            self.save_recent_wam_ID_list = addon.getSetting("save_recent_wam_ID_list")
        except:
            self.save_recent_wam_ID_list = True
        if self.save_recent_wam_ID_list: #if we are saving, then we are also restoring
            try:
                for s in addon.getSetting("recent_wam_ID_list").replace("&apos;", "").replace("[","").replace("]","").replace("'","").split(","):
                    self.wamIDlist.append(s.strip())
            except:
                pass
        #self.wamIDlist = ['217448', '69008', '54550', '193707', '68672', '191179', '54498', '68749', '202306', '217452', '166339', '217442', '68669', '54099', '54125', '211052', '218951', '166344', '68702', '54207', '54319', '215501', '54217', '202083', '210000', '173163', '54129', '206545', '724', '68777', '217444', '53973', '211048', '53882', '35326', '192908', '54040', '53890', '54190', '186970', '53851', '54202', '181058', '68680', '217445', '54634', '213383', '53834', '54095']

        try:
            self.max_wamIDlist_size = int(addon.getSetting("max_wamIDlist_size"))
        except:
            self.max_wamIDlist_size = 200


        #for testing #make parameter?
        self.i_max=20                
                
    def add (self, idMedia, playitem):
        self.playlist.append([idMedia, playitem])
        
    def _geturl(self):
        current_play_item = self.playlist[self.playitem]
        
        #get the link for the song
        url_generator = ROOT_SONG_URL_GENERATOR.format(current_play_item[0])
        html = GetHtml(url_generator)
        media = json.loads(html)
##        Log("_geturl:" + repr(media))
        url = media['url']
##        Log(url)
        url_split = url.split('/')
        #sometimes provider sends a url with curly brackets where they can't be ...
        url = url.replace( url_split[7],  url_split[7].replace('{', '%7B').replace('}', '%7D') )
##        Log(url)
        return "{}{}".format(url, Header2pipestring())        

    def getlistitem(self, position=None):
        if self.playitem >= len(self.playlist):
            return None 

        if not position:
            current_play_item = self.playlist[self.playitem]
        else:
            current_play_item = self.playlist[position]
        
        #todo add next and prev options in set info

        #listitem = xbmcgui.ListItem(name) #, iconImage='', thumbnailImage=''
        listitem = xbmcgui.ListItem(current_play_item[1]['title']) #, iconImage='', thumbnailImage=''
        LogR(current_play_item[1]['title'])
        
        Log("current_play_item[0],[1]{},{}".format(current_play_item[0], current_play_item[1]))

##        listitem.setInfo('music', current_play_item[1]) #current_play_item[1] contains {'title': trackTitle, 'comment': wamId, 'album': albumTitle , 'duration': duration , 'artist': performers  }   )
        if C.PY2:
            listitem.setInfo(
                type="music"
                , infoLabels={"title": current_play_item[1]['title'].title()
                              , "genre": playlist_genre
                              , "playCount": play_count
                              , "mediatype":"music"
                              , "comment": current_play_item[1]['comment']
                              , "artist": current_play_item[1]['artist'].title()
                              , "album": current_play_item[1]['album'].title()
                                }
                )
        if C.PY3:
            videoInfoTag = listitem.getMusicInfoTag()
            videoInfoTag.setTitle(current_play_item[1]['title'].title())
            videoInfoTag.setMediaType('music')
            videoInfoTag.setComment(current_play_item[1]['comment'])
            videoInfoTag.setDuration(int(current_play_item[1]['duration']))
            videoInfoTag.setAlbum(current_play_item[1]['album'].title())
            videoInfoTag.setArtist(current_play_item[1]['artist'].title())
            
##{'title': 'Happy Together (The Turtles) (Ft. Mark Ronson)'
## , 'comment': '231893'
## , 'album': 'Happy Together'
## , 'duration': 186.66
## , 'artist': 'King Princess, Mark Ronson'
## }

        listitem.setPath(self._geturl())
##        listitem.setProperty('IsPlayable', 'true')

        if not position:
            self.playitem += 1


        # assume that we will successfully play this track after it 'getlistitem'
        # add it to our list of played songs
        if self.save_recent_wam_ID_list:
            wamId = current_play_item[1]['comment']
            self.wamIDlist.append(wamId)
            if len(self.wamIDlist) > self.max_wamIDlist_size:
                Log("popping list")
                self.wamIDlist.pop(0) #trim first item if getting too big
            #Log("wamIDlist {}".format(repr(self.wamIDlist)))
            Log("saving wamIDlist")
            addon.setSetting("recent_wam_ID_list", repr(self.wamIDlist))
            
            
        return listitem

    def resolveNext(self):

        Log("self.resolveNext")

        current_resolved_play_file = self.last_resolved_play_file
        
        #get current playlist position
        curr_pos = int(self._xbmcplaylist.getposition())
        next_pos = curr_pos + 1
        #Log("curr_pos:{}".format(curr_pos))

        self._xbmcplaylist.remove(current_resolved_play_file)

        #fill in the correct path for the next item
        #Log("getlistitem start:{}".format(next_pos))
        listitem =  self.getlistitem(next_pos)
        self.last_resolved_play_file = listitem.getPath()
        self._xbmcplaylist.add(listitem.getPath(), listitem, next_pos)
        #Log("getlistitem end:{}".format(next_pos))


        Log("resolveNext.repr(self.playlist): " + repr(self.playlist))

    def fillPlayList(self, playlist_url):

        Log("self._xbmcplaylist.getPlayListId:{}".format(self._xbmcplaylist.getPlayListId()))

        self._xbmcplaylist.clear()
        
        item_was_added = 0
        fill_retry_count = 0
        fill_retry_count_max = 3
        while item_was_added == 0 and fill_retry_count < fill_retry_count_max:        

            # sometimes we will run out of items to add; e.g. all top40 songs played;
            fill_retry_count = fill_retry_count + 1

            #read playlist json info from url
            html = GetHtml(playlist_url)
            json_playlist = json.loads(html)['tracks']
            Log("fillPlayList.json_playlist:{}".format(repr(json_playlist)))

            i=0 #used during testing; limit number of items in queue to i_max
            for playItem in json_playlist:
                i=i+1
                if len(json_playlist) == i: break     #exit last item in json; it is a cbc dud

                wamId = str(48744) #
                wamId = str(playItem['wamId'])
                trackTitle = playItem['trackTitle'].title()
                albumTitle = playItem['albumTitle'].title()
                duration = int(playItem['duration'])/1000
                performers = playItem['performers'].title()
                #url_generator = ROOT_SONG_URL_GENERATOR.format(wamId)

                if wamId in self.wamIDlist:
                    Log("skip {} [title='{}' artist='{}'] as we have already played it".format(wamId, repr(trackTitle),repr(performers) ) )
                    continue  #skip this song if we have already played it
                else:
                    
                    Log("Adding to playlist title='{}' artist='{}' wamId='{}'".format(repr(trackTitle),repr(performers),repr(wamId)), C.LOGNOTICE)
                    self.add(wamId, {'title': trackTitle, 'comment': wamId, 'album': albumTitle , 'duration': duration , 'artist': performers }   )
                    item_was_added = item_was_added + 1
               
                if i > self.i_max: break #for testing

            # if we have parsed the cbc playlist _once_ without adding an item
            # then we can be fairly sure  that we need to reset the recently played list
            # and retry adding the items in the playlist
            if len(json_playlist) < 1:
                item_was_added = 1 #just incase this was null

            #item_was_added = 0 #for testing
            if item_was_added == 0 :
                if C.PY2: clear_count = (self.max_wamIDlist_size/20)
                if C.PY3: clear_count = (self.max_wamIDlist_size//20)
                if not (clear_count > 0): clear_count = 1
                Log("Clearing top {} items in list because nothing was added".format(clear_count), C.LOGERROR)
                del self.wamIDlist[0:clear_count]
        


                    
        Log("fillPlayList.repr(self.playlist): {}".format(repr(self.playlist)))



def PLAY_SINGLE(play_url, friendly_name, playlist_genre, summary_text, playitem_art, artist, album):

    LogR(locals())

    try:
        if not ('|' in play_url):
            play_url += Header2pipestring(DEFAULT_HTTP_HEADERS)
            
        list_item = xbmcgui.ListItem(label=friendly_name, path=play_url)

        if C.PY2:
            list_item.setInfo(
                type="music"
                , infoLabels={  "title": friendly_name
                              , "genre": playlist_genre
                              , "playCount": play_count
                              , "mediatype":"music"
                              , "comment": summary_text
                                , "artist": artist
                                , "album": album
                                }
                )
        if C.PY3:
            videoInfoTag = list_item.getMusicInfoTag()
            videoInfoTag.setTitle(friendly_name)
            videoInfoTag.setGenres((playlist_genre,))
            videoInfoTag.setPlayCount(int(play_count))
            videoInfoTag.setMediaType('music')
            videoInfoTag.setComment(summary_text)
            videoInfoTag.setArtist(artist)
            videoInfoTag.setAlbum(album)
            
        list_item.setArt(
            {
                'thumb': playitem_art
                ,'icon': playitem_art
             }
        ) 

##    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)


        player = MyPlayer()
        player.root_song_url_generator = ROOT_SONG_URL_GENERATOR
        player.set_is_active()
##    player.set_playlist_pointer(my_playlist)
##    LogR(my_playlist)



        ## todo: maybe this will work better with a PlayMedia call for individual entrires instead of playlist
        ##  kodi21, the 'normal' player will not process any of the custom MyPlayer commands, including download
        ##  until next song [including downoad, logging etc.]
        
##            Log( "Playing: {} -- {}".format(listitem.getMusicInfoTag().getTitle(),listitem.getMusicInfoTag().getArtist()),  C.LOGNOTICE)
##            player.is_active = False

        media_player = addon.getSetting("media_player").lower()
        LogR(media_player)
        if media_player == "fmproxy":


            xbmc.executebuiltin( "Dialog.Close(busydialog)" )
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    
            #stream_type = 'HLSRETRY' #with  kodi 18, need seek version to fast forward etc.
            stream_type = 'HLSRETRYSEEK'
            url = list_item.getPath()
            from F4mProxy import f4mProxyHelper

            if player.fmproxyhelper:
                player.fmproxyhelper = None
            f4mp=f4mProxyHelper()
            player.fmproxyhelper = f4mp
            player.stop_playing_event = player.fmproxyhelper.stop_event

            title_info={
                                 'title'  :list_item.getMusicInfoTag().getTitle()   \
                                ,'artist' :list_item.getMusicInfoTag().getArtist()  \
                                ,'album'  :list_item.getMusicInfoTag().getAlbum()   \
                                ,'comment':list_item.getMusicInfoTag().getComment() \
                                }
            LogR(title_info)
            f4mp.playF4mLink( url=url
                             ,name=list_item.getMusicInfoTag().getTitle()
                             ,streamtype = stream_type
                             ,maxbitrate = 500000 #bytes 
                             ,pre_cache_size_max = 500000 #bytes #lets us know total song length with kodi 18
                             ,iconImage=DEFAULT_ICON_IMAGE
                             ,title_info=title_info
                             )
            
        else:
            Log("player.play(default_playlist)")
##            default_playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
##            default_playlist.clear()
##            default_playlist.add(list_item.getPath(), list_item)            
##            player.play(default_playlist)
            player.play(list_item.getPath(),list_item)
            Log("player.play(default_playlist)")

    except:
        traceback.print_exc()
##        raise


    
    pass
    

def PLAY_GENRE(playlist_url, playlist_channel):

    Log("\n PLAY [{},{}]\n".format(playlist_url, playlist_channel))
    
    try:    play_count = int(addon.getSetting(C.quote_plus("play_count_{}".format(playlist_channel))))
    except: play_count = 0
    addon.setSetting(C.quote_plus("play_count_{}".format(playlist_channel)), str(play_count + 1))

    try:    playing_genre = addon.getSetting("playlist_channel")
    except: playing_genre = 0
    addon.setSetting("playlist_channel", playlist_channel)

    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    try:
        my_playlist = MyPlaylist()
        my_playlist.fillPlayList(playlist_url)

        default_playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        default_playlist.clear()

        player = MyPlayer()
        player.root_song_url_generator = ROOT_SONG_URL_GENERATOR
        player.set_is_active()
        player.set_playlist_pointer(my_playlist)
        LogR(my_playlist)
            
        #
        # we add one single song at a time to the [cleared] xbmc playlist because 
        # a playlist can't be edited in real-time
        # 
        # we can't add all the songs at once because the url's contents expire after
        # a few minutes
        #
        # this means no next/previous funtionality
        #

        
        monitor = xbmc.Monitor()
        while True:

            t_start = datetime.datetime.now()
            LogR(t_start)

            #player.is_active is used to help detect if the player object has crashed without
            # letting us know e.g. http 404 
    ##        if player.is_active == True or player.song_skipped == True:
            if True:
                listitem = my_playlist.getlistitem()
                if not listitem:
                    Log("play list exausted...reloading")
                    #my_playlist = None
                    #Sleep(500) #allow cleanup? memory issue?
                    my_playlist.fillPlayList(playlist_url)
                    #my_playlist = PlaylistFromJSON(playlist_url)
                    listitem = my_playlist.getlistitem()
            else:
                # - we have begun to play a song
                # - it did not end normally [playback-ended event did not occur ]
                # - and/or it was not deliberately skippped
                my_playlist._geturl() # force the time-dependent url to be recalculated

            if not listitem:
                Log("breaking play because unable to load play list information")
                break #exit if we still don't have information

            title = listitem.getMusicInfoTag().getTitle().title()
            artist = listitem.getMusicInfoTag().getArtist().title()
            url = listitem.getPath()
##            Log(title)
            iconImage = ''
            try:

                art_url = ('http://ws.audioscrobbler.com/2.0/'
                           '?artist={}&track={}'
                           '&method=track.getInfo'
                           '&api_key=d942dd5ca4c9ee5bd821df58cf8130d4'
                           '&format=json'
                           )
                a = artist.split(',')[0]
                t = title.lower().split('ft.')[0].split('feat.')[0].split('(')[0].strip()
                art_url = art_url.format(
                    C.quote_plus(a)
                    , C.quote_plus(title)
                    )
                art_info = GetHtml(art_url)
                json_art_info = json.loads(art_info)
                try:
                    iconImage = json_art_info['track']['album']['image'][2]['#text'] + Header2pipestring(DEFAULT_HTTP_HEADERS)
                except:
                    a = artist.split(',')[1]
                    art_url = art_url.format(
                        C.quote_plus(a)
                        , C.quote_plus(title)
                        )
                    art_info = GetHtml(art_url)
                    json_art_info = json.loads(art_info)
                    iconImage = json_art_info['track']['album']['image'][2]['#text'] + Header2pipestring(DEFAULT_HTTP_HEADERS)
                    
                Log(iconImage)
                listitem.setArt(
                    { 'thumb': iconImage #must include thumb to avoid error log messages
                     , 'fanart': iconImage #must include fanart for infowall view
                      }
                    ) 
                
            except:
                LogR(artist)
                LogR(title)                
                pass

         
##    ##        default_playlist.clear() #beause we are not acutally using playist
##    ##        default_playlist.add(listitem.getPath(), listitem)
##            try:
##                u = AddPlayItem(
##                        [MODE_PLAY_SINGLE
##                         , url
##                         , title
##                         , C.unescape(playing_genre)
##                         , '' #art
##                         , listitem.getMusicInfoTag().getComment()
##                         , artist
##                         , listitem.getMusicInfoTag().getAlbum()
##                         ]
##                    , return_url_only=True)
##                Log(u)
##                xbmc.executebuiltin("PlayMedia({}), True".format(u))
##    ##            xbmc.executebuiltin("PlayMedia({}), False".format(u))
##                Sleep(1000) #allow enough time for player.isPlaying() to work
##            except:
##                traceback.print_exc()
##                raise

        
            try:
                ## todo: maybe this will work better with a PlayMedia call for individual entrires instead of playlist
                ##  kodi21, the 'normal' player will not process any of the custom MyPlayer commands, including download
                ##  until next song [including downoad, logging etc.]
                
                Log( "Playing: {} -- {}".format(listitem.getMusicInfoTag().getTitle(),listitem.getMusicInfoTag().getArtist()),  C.LOGNOTICE)
                player.is_active = False

                media_player = addon.getSetting("media_player").lower()
                Log(media_player)
                if media_player == "fmproxy":

                    #stream_type = 'HLSRETRY' #with  kodi 18, need seek version to fast forward etc.
                    stream_type = 'HLSRETRYSEEK'
##                    stream_type = 'MP4'
                    url = listitem.getPath()
                    from F4mProxy import f4mProxyHelper


##                    url = "http://raid/music/Beat%20Service%20&%20Ana%20Criado%20-%20An%20Autumn%20Tale%20(Kaimo%20K%20Remix).mp4"
                    
                    if player.fmproxyhelper:
                        player.fmproxyhelper = None
                    f4mp=f4mProxyHelper()
                    player.fmproxyhelper = f4mp
                    player.stop_playing_event = player.fmproxyhelper.stop_event

                    title_info={
                         'title'  : title
                        ,'artist' : artist
                        ,'album'  :listitem.getMusicInfoTag().getAlbum()   \
                        ,'comment':listitem.getMusicInfoTag().getComment() \
                        }
                    LogR(title_info)
                    f4mp.playF4mLink( url=url
                                     ,name=listitem.getMusicInfoTag().getTitle()
                                     ,streamtype = stream_type
                                     ,maxbitrate = 500000 #bytes 
                                     ,pre_cache_size_max = 500000 #bytes #lets us know total song length with kodi 18
                                     ,iconImage=iconImage #DEFAULT_ICON_IMAGE
                                     ,title_info=title_info
                                     )
                    Log(media_player+'finish')
                    
                else:
                    #xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=False, listitem=listitem)
                    #if int(sys.argv[1]) > 0:
                    #    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
##                    player.play(default_playlist)

##                    listitem.setPath(url)
##                    LogR(listitem.getPath())
                    
                    player.play(url,listitem)
                    Log("player.play(default_playlist)")
##                    if monitor.waitForAbort(3):
##                        Log("ending thread {} due to abort".format(""), C.LOGWARNING)
##                        return


                    play_start_count = 0
                    play_start_count_max = 6
                    while not player.isPlaying():
                        if monitor.waitForAbort(1):
                            Log("ending thread {} due to abort".format(""), C.LOGWARNING)
                            return
                        Log('waiting for play to start {}'.format(
                                time.time()
                                )
                            )
                        play_start_count += 1
                        if play_start_count> play_start_count_max:
                            Log("play_start_count> play_start_count_max:")
                            break
                    Log("player.isPlaying():")

                    current_play_item =""
                    play_test_count = 0
                    play_test_count_max = 3
                    while player.isPlaying():
                        try:
                            current_play_item = player.getPlayingFile()
                        except:
                            pass
        ##                LogR((current_play_item, datetime.datetime.timestamp(datetime.datetime.now())))
                        if (url != current_play_item) \
                            and \
                            (title not in current_play_item):
                            play_test_count += 1
                            LogR(play_test_count)
                        else:
                            play_test_count = 0
                        if play_test_count> play_test_count_max:
                            Log("test max now[current_play_item={}]".format(current_play_item), C.LOGERROR)
                            break
                        if monitor.waitForAbort(0.1):
                            Log("ending thread {} due to abort".format(""), C.LOGWARNING)
                            return
                
            except:
                raise
                traceback.print_exc()





            try:    playing_genre = addon.getSetting("playlist_channel")
            except: playing_genre = 0
            if playing_genre != playlist_channel:
                Log("Channel changed from {} to {}. Ending thread".format(playlist_channel, playing_genre ))
                break
##            if monitor.waitForAbort(1):
##                Log("ending thread {} due to abort".format(""), C.LOGWARNING)
##                return

            #hack to try and get onPlayBackStopped to register
            for x in range(5):
                if monitor.waitForAbort(0.1):
                    Log("ending thread {} due to abort".format(""), C.LOGWARNING)
                    return
            
            LogR(player.was_stopped)
            LogR(player.continue_after_download)
            if player.was_stopped == True and player.continue_after_download == False:
                Log("exiting play infinite loop because was stopped")
                break

            net = (datetime.datetime.now()-t_start).total_seconds()
            LogR(net)
            Log("milliseconds since last loop={:.0f}ms".format(net*1000) )
            if net < 10:
                Log("#infinite loop {}".format(net), C.LOGERROR)
                break #infinite loop


        default_playlist.clear()
        
        if int(sys.argv[1]) > 0:
            xbmcplugin.endOfDirectory(int(sys.argv[1])
                                      , succeeded=False  #must be false or else triggers infinite
                                      , updateListing  = False
                                      , cacheToDisc = False
                                      )
        else:
##            Log('missing argv', C.LOGERROR)
            pass
            

    except:
        traceback.print_exc()
##        raise

    Log('exiting')
    return False

############################################
############################################
# Main entry point
############################################
############################################

utils.LogR(sys.argv, C.LOGWARNING)
mode = None
try:
    params = getParams()
except:
    traceback.print_exc()
##LogR(params)
    
try:     url = C.unquote_plus(params["url"])
except:  url = None
try:    name = C.unquote_plus(params["name"])
except: name = None
try:    mode = int(params["mode"])
except: mode = None

try:     playlist_genre = C.unquote_plus(params["playlist_genre"])
except:  playlist_genre = None
try:    play_count = C.unquote_plus(params["play_count"])
except: play_count = None
try:     summary_text = C.unquote_plus(params["summary_text"])
except:  summary_text = None
try:    playitem_art = C.unquote_plus(params["playitem_art"])
except: playitem_art = None
try:    artist = C.unquote_plus(params["artist"])
except: artist = None
try:    album = C.unquote_plus(params["album"])
except: album = None

LogR(mode)
if   mode          is None:
    MAIN(root_url)
elif mode ==     MODE_MAIN:
    MAIN(root_url)
elif mode ==     MODE_PLAY_GENRE:
    PLAY_GENRE(url, name)
elif mode ==     MODE_PLAY_SINGLE:
    PLAY_SINGLE(url, name, playlist_genre, summary_text, playitem_art, artist, album)
elif mode == MODE_DOWNLOAD:
    Download(url, name)
elif mode ==  MODE_REFRESH:
    REFRESH()
elif mode ==  MODE_RESET_PLAYCOUNT:
    RESET_PLAYCOUNT(name)
elif mode ==  MODE_CONFIGURE_FMproxy:
    xbmcaddon.Addon(id='script.video.F4mProxy').openSettings()



############################################
############################################
# End of file
############################################
############################################
