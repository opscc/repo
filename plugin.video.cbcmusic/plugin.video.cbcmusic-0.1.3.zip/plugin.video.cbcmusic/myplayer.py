import xbmc
import time
import os
import json
import threading

from utils import this_addon
from utils import addon_id
from utils import Log
from utils import Notify
from utils import DEFAULT_ICON_IMAGE
from utils import GetHtml
from utils import Header2pipestring

from F4mProxy import f4mProxyHelper

############################################
############################################
# MyPlayer
############################################
############################################
class MyPlayer(xbmc.Player):
#__________________________________________________________________
#
    def __init__( self, *args, **kwargs):
        xbmc.Player.__init__(self, *args)
        self.is_active = True
        self.was_stopped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.play_paused_count = None
        self.continue_after_download = False
        self.playlist_pointer = None
        self.fmproxyhelper = None
        self.root_song_url_generator = None
        self.song_skipped = False
        self.pause_event = threading.Event()
        self.speed_change_event = threading.Event()
        self.stop_playing_event = threading.Event()
#__________________________________________________________________
#
    def set_playlist_pointer( self, playlist ):
        self.playlist_pointer = playlist
#__________________________________________________________________
#
    def set_is_active( self ):
        self.is_active = True
#__________________________________________________________________
#
    def onPlayBackPaused( self ):
        Log("onPlayBackPaused")
        self.pause_event.set()
        try:
            self.speedChangedTime = None
            self.speedChangedCount = None

            max_play_paused_count = 1
            max_play_paused_window = 5
            
            if self.play_paused_time:
                #Log("play_paused_time_delta: " + repr(time.time() - self.play_paused_time))

                if (time.time() - self.play_paused_time) > max_play_paused_window:
                    self.play_paused_time = None
                    self.play_paused_count = None
                    #Log("values should be reset")
                    return
                
                if self.play_paused_count:
                    self.play_paused_count = self.play_paused_count + 1
                else:
                    self.play_paused_count = 1

                #Log("play_paused_count" + str(self.play_paused_count))

                #save media to disk when this happens
                if self.play_paused_count >= max_play_paused_count:
                    self.SaveSong()

            else:
                self.play_paused_time = time.time()
        finally:
            self.pause_event.clear()
#__________________________________________________________________
#
    def SaveSong( self ):

        Log("getMusicInfoTag - title:'{}'".format(self.getMusicInfoTag().getTitle()))
        Log("getMusicInfoTag - comment:'{}'".format(self.getMusicInfoTag().getComment() ) )

        if not self.getMusicInfoTag().getComment():
            Notify('Id is blank: skipping')
            return

        file_name = "{} - {}.ts".format(self.getMusicInfoTag().getArtist(), self.getMusicInfoTag().getTitle()).replace('/', '.')
        file_folder = this_addon.getSetting("download_path").lower()
        download_path = os.path.join(file_folder, file_name)
        Notify('Saving song to ' + download_path)

        url =  self.getPlayingFile()
        #Log("url:'{}'".format(url))

        #get new link for the song - the original may have expired
        #url_generator = root_song_url_generator.format('35823') #test data
        if self.root_song_url_generator:
            url_generator = self.root_song_url_generator.format(self.getMusicInfoTag().getComment())
            html = GetHtml(url_generator)
            media = json.loads(html)
            url = "{}{}".format(media['url'], Header2pipestring())        

        Log("url:'{}'".format(url))

        save_song_stop_event = threading.Event()
        seek_forward_event = threading.Event()
        try:
            import HLSDownloaderRetry #part of f4mproxy dependency
            Log("Background_HLSDownloader instance")
            downloader = HLSDownloaderRetry.HLSDownloaderRetry()
            downloader.init(
                  url = url
                , stop_playing_event = save_song_stop_event
                , seek_forward_event = seek_forward_event
                , download_path = download_path
                )
            Log("Background_HLSDownloader keep sending start")
            downloader.keep_sending_video(None)
        finally:
            Log("Background_HLSDownloader keep sending finish")
            downloader = None
            save_song_stop_event = None
            seek_forward_event = None

##        if self.fmproxyhelper:
##            #stop current proxy before starting next one
##            self.fmproxyhelper.seekToEnd()
##        stream_type = 'HLS'
##        if not self.fmproxyhelper:
##            self.fmproxyhelper = f4mProxyHelper()
##        self.fmproxyhelper.playF4mLink( \
##                        url=url \
##                        ,name= self.getMusicInfoTag().getTitle()
##                        ,proxy=None
##                        ,use_proxy_for_chunks=False
##                        ,maxbitrate=0
##                        ,simpleDownloader=False
##                        ,auth=None
##                        ,streamtype = stream_type
##                        ,setResolved=False
##                        ,swf=None
##                        ,callbackpath=""
##                        ,callbackparam=""
##                        ,iconImage=DEFAULT_ICON_IMAGE
##                        ,download_path=download_path
##                        ,title_info={   'title'  :self.getMusicInfoTag().getTitle()  \
##                                        ,'artist' :self.getMusicInfoTag().getArtist() \
##                                        ,'album'  :self.getMusicInfoTag().getAlbum()  \
##                                     }
##                        )
##        Notify('Playing next song after finishing saving ' + file_name)

        self.play_paused_time = None
        self.play_paused_count = None
        self.continue_after_download = True
        
#__________________________________________________________________
#
    def onPlayBackResumed( self ):
        Log("onPlayBackResumed")
        self.speedChangedTime = None
        self.speedChangedCount = None
#__________________________________________________________________
#
    def onPlayBackSpeedChanged(self, speed):
        self.speed_change_event.set()
        Log("onPlayBackSpeedChanged")

        try:                
            max_speedchange_count = 2
            max_speedchange_window = 5  

            if not self.speedChangedTime:
                self.speedChangedTime = time.time()
                return
            #Log(repr(time.time() - self.speedChangedTime))
            if (time.time() - self.speedChangedTime) > max_speedchange_window:
                self.speedChangedTime = None
                self.speedChangedCount = 0
                return

            if self.speedChangedCount:
                self.speedChangedCount = self.speedChangedCount + 1
            else:
                self.speedChangedCount = 1

            if self.speedChangedCount == max_speedchange_count:
                self.song_skipped = True
                Log("seeking to end of song -- {}".format(self.getMusicInfoTag().getTitle()), xbmc.LOGNOTICE)
                if self.fmproxyhelper:
                    #self.fmproxyhelper.seekToEnd()
                    self.stop_playing_event.set()
                else:
                    self.seekTime(self.getTotalTime()-1 )
            else: 
                self.speedChangedTime = time.time()
        finally:
            self.speed_change_event.clear()
#__________________________________________________________________
#
    def onPlayBackSeek( self, seek_time, seek_offset ):
        Log("onPlayBackSeek:: getTotalTime()={} seek_time={} seek_offset={} speedChangedCount={}  speedChangedTime={}".format(self.getTotalTime(), seek_time, seek_offset,repr(self.speedChangedCount), repr(self.speedChangedTime) ) )
#__________________________________________________________________
#
    def onPlayBackStarted( self ):
        self.is_active = True  #important call to detect if http 404 error occured
        self.song_skipped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.continue_after_download = False
        try:
            Log("onPlayBackStarted :: " + self.getPlayingFile())
        except:
            pass
#__________________________________________________________________
#
    def onPlayBackEnded(self):
        Log("onPlayBackEnded")
        self.is_active = True
        self.was_stopped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.continue_after_download = False
#__________________________________________________________________
#
    def onPlayBackStopped(self):
        Log("onPlayBackStopped")
        self.was_stopped = True
#__________________________________________________________________
#
    def onQueueNextItem(self):
        Log("onQueueNextItem")
        self.is_active = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.continue_after_download = False
#__________________________________________________________________
#
