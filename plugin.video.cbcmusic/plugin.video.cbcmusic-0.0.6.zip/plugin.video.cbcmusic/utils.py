import xbmc
import xbmcgui
import xbmcaddon
import threading

#libraries used in downloading
import xbmcvfs
import tempfile 
import os.path  
import time
import traceback
from urllib2 import Request  as Request
from urllib2 import urlopen  as urlopen
import urlparse

this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
addon_name = this_addon.getAddonInfo('name')

DEFAULT_HTTP_HEADERS = {
    'User-Agent': "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    ,'Accept-Encoding': 'gzip,deflate'
    }

def Log(msg="", loglevel=None):
    try:    debug = (this_addon.getSetting('debug').lower() == "true")
    except:
        raise
        debug = True
    msg = "{}: {}".format(addon_id, repr(msg).decode('utf8',errors='ignore').encode('ascii',errors='ignore'))
    if loglevel: xbmc.log(msg , loglevel)
    elif debug:  xbmc.log(msg , xbmc.LOGNONE)
    else:        xbmc.log(msg)

def Notify(msg, duration=5000, icon="", title=addon_name):
    debug = (this_addon.getSetting('debug').lower() == "true")
    if threading.current_thread().name == "MainThread":
        Log( msg, xbmc.LOGNOTICE)
        xbmcgui.Dialog().notification(title, msg, icon, duration, sound=False )
    elif debug:
        Log( msg, xbmc.LOGNOTICE)

def Header2pipestring(header=DEFAULT_HTTP_HEADERS):
    q = "|{}".format( repr(header) )
    q = q.replace( "{'", "")
    q = q.replace( "'}", "")
    q = q.replace( "': '", "=" )
    q = q.replace( "', '", "&" )
    return q

# Modified `sleep` command that honors a user exit request
def Sleep (time):
    while time > 0 and not xbmc.abortRequested:
        xbmc.sleep( min(1000, time) )
        time = time - 1000


def DownloadVideo(url, name):

    def _pbhook(downloaded, filesize, name=None,dp=None):
        try:
            percent = min((downloaded*100)/filesize, 100)
            currently_downloaded = float(downloaded) / (1024 * 1024)
            kbps_speed = int(downloaded / (time.clock() - start))

            if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
            else:               eta = 0

            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            mbs = name
            mbs += ' %.02f MB of %.02f MB ' % (currently_downloaded, total)
            e = 'Speed: %.02f Kb/s ' % kbps_speed
            e += 'ETA: %02d:%02d' % divmod(eta, 60)
            #dp.update(percent,'',mbs,e)
            dp.update(percent,'',mbs + e)

        except:
            traceback.print_exc()
            percent = 100
            dp.update(percent)
            dp.close()
            
        #if dp.iscanceled():
        #    dp.close()
        #    raise StopDownloading('Stopped Downloading')


    def getResponse(url, headers2, size):
        #Log("getResponse:{}".format(url))
        try:
            if size > 0:
                size = int(size)
                headers2['Range'] = 'bytes=%d-' % size
            req = Request(url, headers=headers2)
            #req.add_header('Range', 'bytes=0-100') #only get a few bytes to test for redirection
            resp = urlopen(req, timeout=30)
            #Log("getResponse:urlopen:{}".format(url))
            return resp
        except:
            traceback.print_exc()
            return None

    def doDownload(url, dest, dp, name):

        try:

            #url may have include headers to be passed during transaction
            try:
                headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
            except:
                traceback.print_exc()
                headers = dict('')


            url = url.split('|')[0]
            file = dest.rsplit(os.sep, 1)[-1]

            resp = getResponse(url, headers, 0)

            if not resp:
                Notify("Download failed: {}".format(url))
                #xbmcgui.Dialog().ok("Ultimate Whitecream", 'Download failed', 'No response from server')
                return False

            try:    content = int(resp.headers['Content-Length'])
            except: content = 0

            try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
            except: resumable = False
            if resumable: Log("Download is resumable: {}".format(url))

            if content < 1:
                Notify("Unknown filesize: {}".format(url))
                #xbmcgui.Dialog().ok("Ultimate Whitecream", 'Unknown filesize', 'Unable to download')
                #return False

            size = 8192
            mb   = content / (1024 * 1024)

            if content < size:
                size = content

            total   = 0
            errors  = 0
            count   = 0
            resume  = 0
            sleep   = 0

            Log('Download File Size : %dMB %s ' % (mb, dest))
            f = xbmcvfs.File(dest, 'w')

            chunk  = None
            chunks = []

            while True:

                # kill the download if kodi monitor tells us to
                monitor = xbmc.Monitor()
                if monitor.abortRequested():
                    if monitor.waitForAbort(1):
                        Log("shutting down '{}' download thread for '{}'".format(addon_id,url), xbmc.LOGNOTICE)
                        return
                
                downloaded = total
                for c in chunks:
                    downloaded += len(c)
                percent = min(100 * downloaded / content, 100)

                _pbhook(downloaded,content,name,dp)

                chunk = None
                error = False

                try:
                    chunk  = resp.read(size)
                    if not chunk:
                        if percent < 99:
                            error = True
                        else:
                            while len(chunks) > 0:
                                c = chunks.pop(0)
                                f.write(c)
                                del c

                            f.close()
                            Log( '%s download complete' % (dest) )
                            return True

                except Exception, e:
                    traceback.print_exc()
                    error = True
                    sleep = 10
                    errno = 0

                    if hasattr(e, 'errno'):
                        errno = e.errno

                    if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                        pass

                    if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                        errors = 10 #force resume
                        sleep  = 30

                    if errno == 11001: # 'getaddrinfo failed'
                        errors = 10 #force resume
                        sleep  = 30

                if chunk:
                    errors = 0
                    chunks.append(chunk)
                    if len(chunks) > 5:
                        c = chunks.pop(0)
                        f.write(c)
                        total += len(c)
                        del c

                if error:
                    errors += 1
                    count  += 1
                    #Log ('%d Error(s) whilst downloading %s' % (count, dest))
                    #xbmc.sleep(sleep*1000)
                    Sleep(sleep*1000)

                if (resumable and errors > 0) or errors >= 500:
                    if (not resumable and resume >= 500) or resume >= 500:
                        #Give up!
                        Log ('%s download canceled - too many error whilst downloading' % (dest))
                        f.close()
                        return False

                    resume += 1
                    errors  = 0
                    if resumable:
                        chunks  = []
                        #create new response
                        Log ('Download resumed (%d) %s' % (resume, dest) )
                        resp = getResponse(url, headers, total)
                    else:
                        #use existing response
                        pass

        except:
            traceback.print_exc()

    def clean_filename(s):
        if not s:
            return ''
        badchars = '\\/:*?\"<>|\''
        for c in badchars:
            s = s.replace(c, '')
        return s.strip();

    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = name.strip('\r')
    
    download_path = this_addon.getSetting('download_path')
    if download_path == '':
        try:
            download_path = xbmcgui.Dialog().browse(0, "Download Path", 'myprograms', '', False, False)
            this_addon.setSetting(id='download_path', value=download_path)
            if not os.path.exists(download_path): os.mkdir(download_path)
        except:
            raise #pass

    if download_path != '':
        dp = xbmcgui.DialogProgressBG()
        #dp = xbmcgui.DialogProgress()
        name = name.split("[")[0]
        dp.create(addon_name,name[:50])
        tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
        tmp_file = xbmc.makeLegalFilename(tmp_file)
        start = time.clock()
        try:
            downloaded = doDownload(url, tmp_file, dp, name)
            if downloaded:
                vidfile = xbmc.makeLegalFilename(download_path + clean_filename(name) + ".mp4")
                Log(vidfile)
                try:
                  os.rename(tmp_file, vidfile)
                  dp.close()
                  return vidfile
                except Exception, e:
                  traceback.print_exc()
                  Notify("'{}' name:{} tmp:{}".format(e,vidfile,tmp_file), 20000)
                  dp.close()
                  return tmp_file
            else:
                raise StopDownloading('Stopped Downloading')
        except:
            while os.path.exists(tmp_file):
                try:
                    os.remove(tmp_file)
                    dp.close()
                    break
                except:
                    traceback.print_exc()
                    break
                    pass
            dp.close()
