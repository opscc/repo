﻿'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib,urllib2,re,gzip,socket
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys,os

import StringIO
import time
import datetime
import base64
import traceback
import json
try:
  # Python 2.6-2.7 
  from HTMLParser import HTMLParser
except ImportError:
  # Python 3
  from html.parser import HTMLParser


from utils import this_addon as addon
from utils import addon_id
from utils import Log
from utils import Notify
from utils import Header2pipestring
from utils import DEFAULT_HTTP_HEADERS
from utils import Sleep
from utils import DownloadVideo

MODE_MAIN = 0
MODE_PAGE = 1
MODE_IPTV = 2
MODE_PLAY = 3
MODE_SEARCH = 4
MODE_SETTINGS = 5
MODE_DOWNLOAD = 6
MODE_REFRESH = 7

#load our configurable settings
url_timeout = int(addon.getSetting('url_timeout'))
socket.setdefaulttimeout(url_timeout)
root_url = (addon.getSetting("search_starting_point"))
root_playlist_url = (addon.getSetting("root_playlist_url"))
root_song_url_generator = (addon.getSetting("root_song_url_generator"))

#set global variables
addon_handle = int(sys.argv[1])
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';': rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
DEFAULT_ICON_IMAGE = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))


#################################
#################################
#################################
#################################

def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

#################################
#################################
#################################
#################################

def GetHtml(url, referer=None, hdr=None, data=None):
    if url=='':  return None
    Log("reading html for url '{}'".format(url))
    if not hdr:    req = urllib2.Request(url, data, DEFAULT_HTTP_HEADERS)
    else:          req = urllib2.Request(url, data, hdr)
    if referer:    req.add_header('Referer', referer)
    if data:       req.add_header('Content-Length', len(data))
    data = ''
    response = urllib2.urlopen(req, timeout=url_timeout)
    if response:
        if response.info().get('Content-Encoding') == 'gzip':
            buf = StringIO.StringIO( response.read())
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = response.read()
    if response:  response.close()
    return data

def AddDir(name, url, mode, iconimage, folder=True):
    if url.startswith('plugin'):
        u = url
    else:
        u = (sys.argv[0] +
             "?url=" + urllib.quote_plus(url) +
             "&mode=" + str(mode) +
             "&name=" + urllib.quote_plus(name))

    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)

    liz.setInfo( type = 'music', infoLabels={"playCount":"888888"})
   
    liz.setProperty("IsPlayable","false")

    if addon_handle > 0:
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=folder)



#################################
#################################
#################################
#################################

def REFRESH():
    xbmc.executebuiltin('Container.Refresh')

#################################
#################################
#################################
#################################

def MAIN(url):

    AddDir('[COLOR  blue]Refresh[/COLOR]','',MODE_REFRESH,'',folder=False)

    genrelist = list(()) #html page sometimes includes duplicates; 
    
    #read basic page
    html = GetHtml(url)
    
    #show the front page streams
    links = re.compile('data-playable-object-id="([^"]+)".+?data-playable-object-title="([^"]+)".+?data-genre="([^"]+)".+?data-component-name="GenreTags">.+?cbcrc-genretag-([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    for stream_id, stream_name, genre_name, genre_id in links:
        #Log ("{} {}".format(genrelist.count(genre_name), genre_name  ))
        if genrelist.count(stream_id) < 1: #html page sometimes includes duplicates; 
            genrelist.append(stream_id)
            url = root_playlist_url.format(stream_id)
            AddPlayItem([None, url, HTMLParser().unescape(stream_name), genre_name ])
            #Log ("{} '{}'".format(url, HTMLParser().unescape(stream_name)) )

    #expand subcatetories

    #todo


    if addon_handle > 0:

        xbmcplugin.setContent( addon_handle, 'songs' )
        xbmcplugin.addSortMethod( handle=addon_handle, sortMethod=GetSortMethod() )
        xbmcplugin.endOfDirectory( addon_handle )
        #xbmcplugin.setResolvedUrl(addon_handle, True, liz)
        
#################################
#################################
#################################
#################################
    
def GetSortMethod():
    sort_type = (addon.getSetting("sort_type"))
    if sort_type == 'name':
        sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE
    elif sort_type == 'genre':
        sortMethod=xbmcplugin.SORT_METHOD_GENRE #=15
    elif sort_type == 'playcount':        
        sortMethod=xbmcplugin.SORT_METHOD_PLAYCOUNT #= 35
    else:
        sortMethod=xbmcplugin.SORT_METHOD_NONE
    return sortMethod

############################################
############################################
############################################
############################################
    
def Download(url, title):
    log("\n Download [{},{}]\n".format(url, title))
    try:
        url, stream_type = Probe_url(url, title)
        #url = 'http://filmes.listaccess.me:8080/series/russo/123456/10935.mp4?token=HkFcUEIJRFgSU1ZQXQ9TAFxSVVwAAgJQVVMLXFIFVAVdWwAGAllQU1QUGRFKTUdXWA5rUFBDC1NSXApQGEMURwARa1hVQ1xABQcAAQ0bGRBNCllcFlsAV1FUDVwMVFEASUFEWFVDXEAHBw0EGxUXV0EXUUtaAF09BgBPDFcEQw5HQRgTXg85BlVbVF1dGw8QCUEYG10SQUBYR20AXxIAQhMaFGJeDRMWWVlbQBlwW1EXQRgbVghFEAMRXEcOQ1AHV1QWHRMCCRdeQkdKGwMXcXhBGBtRGUUHDBZQClpDWxYIEwATHUMPEW9EUEBNS1BTVAZGGw5DAUBOR1QETD4CWwsNUVJFCAkMQxQPEQgbGRBUDFpQQA5DPRIMXUcODxRYCR4=|Accept-Encoding=gzip,deflate&User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
        #url = 'http://raid.opscc.net/pics/Jamie%20Lynn/_Movies/127_02_mooningthesun1920x1080.mp4|Accept-Encoding=gzip,deflate&User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
        DownloadVideo(url, title)
    except:
        traceback.print_exc()
    
############################################
############################################
############################################
############################################
    
def AddPlayItem(link_tuple):
    playable_url  = link_tuple[1]
    friendly_name = link_tuple[2]
    playlist_genre = link_tuple[3]
    try:    play_count = int(addon.getSetting(urllib.quote_plus("play_count_{}".format(friendly_name))))
    except: play_count = 0
    
    liz = xbmcgui.ListItem(friendly_name)
    liz.setInfo(
        type="music"
        , infoLabels={"title": friendly_name
                      , "genre":playlist_genre
                      , "playCount":play_count
                      , "mediatype":"music"})
    #liz.setArt( {'thumb': DEFAULT_ICON_IMAGE
    #             ,'icon': DEFAULT_ICON_IMAGE} ) 
    #liz.addStreamInfo('music' , {'codec': 'h264'})
    #liz.setProperty("IsPlayable","true")
    #liz.setProperty("playCount", str(play_count))

##https://codedocs.xyz/AlwinEsch/kodi/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
##setinfo
##racknumber	integer (8)
##discnumber	integer (2)
##duration	integer (245) - duration in seconds
##year	integer (1998)
##genre	string (Rock)
##album	string (Pulse)
##artist	string (Muse)
##title	string (American Pie)
##rating	float - range is between 0 and 10
##userrating	integer - range is 1..10
##lyrics	string (On a dark desert highway...)
##playcount	integer (2) - number of times this item has been played
##lastplayed	string (Y-m-d h:m:s = 2009-04-05 23:16:04)
##mediatype	string - "music", "song", "album", "artist"
##dbid	integer (23) - Only add this for items which are part of the local db. You also need to set the correct 'mediatype'!
##listeners	integer (25614)
##musicbrainztrackid	string (cd1de9af-0b71-4503-9f96-9f5efe27923c)
##musicbrainzartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
##musicbrainzalbumid	string (24944755-2f68-3778-974e-f572a9e30108)
##musicbrainzalbumartistid	string (d87e52c5-bb8d-4da8-b941-9f4928627dc8)
##comment	string (This is a great song)
    
    if '.mp4' in playable_url:
        download_url = "{}?url={}&mode={}&name={}".format(
                    sys.argv[0]
                    ,urllib.quote_plus(playable_url.encode('utf-8'))
                    ,MODE_DOWNLOAD
                    ,urllib.quote_plus(friendly_name.encode('utf-8'))
                    )
        contextMenuItems = []
        contextMenuItems.append(('[COLOR hotpink]Download Video[/COLOR]', 'xbmc.RunPlugin('+download_url+')'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)

    if addon_handle > 0:
        if isinstance(friendly_name, str):  friendly_name = unicode(friendly_name, "utf-8")

        internally_redirected_url = "{}?url={}&mode={}&name={}".format(
                    sys.argv[0]
                    ,urllib.quote_plus(playable_url.encode('utf-8'))
                    ,MODE_PLAY
                    ,urllib.quote_plus(friendly_name.encode('utf-8'))
                    )

        xbmcplugin.addDirectoryItem(handle=addon_handle
                                    , url=internally_redirected_url
                                    , listitem=liz
                                    , isFolder=False)
        
    
############################################
############################################
# MyPlaylist
############################################
############################################

class MyPlaylist(xbmc.PlayList):

    def __init__(self, *args, **kwargs):

        self._xbmcplaylist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        self._xbmcplaylist.clear()

        self.playlist = []
        self.playitem = 0
        self.last_resolved_play_file = None
        self.FAKE_NEXT_PATH = "http://127.0.0.1/next/"
        self.FAKE_PREV_PATH = "http://127.0.0.1/prev/"
        self.player = None

    def add (self, idMedia, playitem):
        self.playlist.append([idMedia, playitem])
        
    def _geturl(self):
        current_play_item = self.playlist[self.playitem]
        
        #get the link for the song
        url_generator = root_song_url_generator.format(current_play_item[0])
        html = GetHtml(url_generator)
        media = json.loads(html)
        Log(media)
        return "{}{}".format(media['url'], Header2pipestring())        

    def getlistitem (self, position=None):
        if self.playitem >= len(self.playlist):
            return None 

        if not position:
            current_play_item = self.playlist[self.playitem]
        else:
            current_play_item = self.playlist[position]
        
        #todo add next and prev options in set info

        listitem = xbmcgui.ListItem(name, iconImage='', thumbnailImage='')
        listitem.setInfo('music', current_play_item[1])
        listitem.setPath(self._geturl())

        if not position:
            self.playitem += 1
            
        return listitem

    def resolveNext(self):

        Log("self.resolveNext")

        current_resolved_play_file = self.last_resolved_play_file
        
        #get current playlist position
        curr_pos = int(self._xbmcplaylist.getposition())
        next_pos = curr_pos+1

        Log("curr_pos:{}".format(curr_pos))

        self._xbmcplaylist.remove(current_resolved_play_file)
        
        #fill in the correct path for the next item
        self._xbmcplaylist.remove(self.FAKE_NEXT_PATH)

        Log("getlistitem start:{}".format(next_pos))
        listitem =  self.getlistitem(next_pos)
        self.last_resolved_play_file = listitem.getPath()
        self._xbmcplaylist.add(listitem.getPath(), listitem, next_pos)
        Log("getlistitem end:{}".format(next_pos))


##        Log("self._xbmcplaylist.remove(self.current_resolved_play_file):{}".format(next_pos))
##        self._xbmcplaylist.remove(current_resolved_play_file)
####        playItem = self.playlist[curr_pos] 
####        wamId = str(playItem['wamId'])
####        trackTitle = playItem['trackTitle']
####        albumTitle = playItem['albumTitle']
####        duration = int(playItem['duration'])/1000
####        performers = playItem['performers']
####        listitem.setInfo('music', {'title': trackTitle, 'comment': wamId,  'album': albumTitle , 'duration': duration , 'artist': performers  })
##        listitem = xbmcgui.ListItem(self.playlist[curr_pos][1]['title'], iconImage='', thumbnailImage='')
##        listitem.setInfo('music', self.playlist[curr_pos])
##        self._xbmcplaylist.add(self.FAKE_PREV_PATH, listitem, curr_pos)
##        self.player.playnext()
##        Log("self._xbmcplaylist.remove(self.current_rese):{}".format(next_pos))
        
        
##        # show what will be next
##        listitem =  self.getlistitem(next_pos+1)
##        if listitem:
##            self._xbmcplaylist.add(self.FAKE_NEXT_PATH, listitem)
##
        Log("resolveNext.repr(self.playlist): " + repr(self.playlist))
        

    def fillPlayList(self, playlist_url):

        Log("self._xbmcplaylist.getPlayListId:{}".format(self._xbmcplaylist.getPlayListId()))

        self._xbmcplaylist.clear()
        
        #read playlist json info from url
        html = GetHtml(playlist_url)
        json_playlist = json.loads(html)['tracks']
        Log("fillPlayList.json_playlist: " + repr(json_playlist))
        i=0

        for playItem in json_playlist:
            i=i+1
            if len(json_playlist) == i: break; #skip last item in json; it is a cbc dud
            wamId = str(playItem['wamId'])
            trackTitle = playItem['trackTitle']
            albumTitle = playItem['albumTitle']
            duration = int(playItem['duration'])/1000
            performers = playItem['performers']
            self.add(wamId, {'title': trackTitle, 'comment': wamId, 'album': albumTitle , 'duration': duration , 'artist': performers  }   )
            if i > 2: break #testing

        listitem =  self.getlistitem()
        self.last_resolved_play_file = listitem.getPath()
        self._xbmcplaylist.add(self.last_resolved_play_file, listitem)

        listitem =  self.getlistitem()
        self._xbmcplaylist.add(self.FAKE_NEXT_PATH, listitem)

        Log("fillPlayList.repr(self.playlist): " + repr(self.playlist))
        
############################################
############################################
# MyPlayer
############################################
############################################
class MyPlayer(xbmc.Player):
    def __init__( self, *args, **kwargs):
        xbmc.Player.__init__(self, *args)
        self.is_active = True
        self.was_stopped = False
    def set_playlist_pointer( self, playlist ):
        self.playlist_pointer = playlist

    def set_is_active( self ):
        self.is_active = True
    def onPlayBackPaused( self ):
        Log("onPlayBackPaused")
    def onPlayBackResumed( self ):
        Log("onPlayBackResumed")
    def onPlayBackStarted( self ):
        self.is_active = True
        Log("onPlayBackStarted :: " + self.getPlayingFile())
    def onPlayBackEnded(self):
        Log("onPlayBackEnded")
        self.is_active = False
        self.was_stopped = False
    def onPlayBackStopped(self):
        Log("onPlayBackStopped")
        self.is_active = False
        self.was_stopped = True
    def onPlayBackSeekChapter(self):
        Log("onPlayBackSeekChapter")
    def onQueueNextItem(self):
        Log("onQueueNextItem - start")
        self.playlist_pointer.resolveNext()
        Log("onQueueNextItem - end")
        #get current playlist position
        #add one to position and get listitem
        #insert at that position



def PlaylistFromJSON(playlist_url):

    #read playlist json info from url
    html = GetHtml(playlist_url)
    json_playlist = json.loads(html)['tracks']
    Log(json_playlist)

    i=0
    my_playlist = MyPlaylist()
    for playItem in json_playlist:
        i=i+1
        if len(json_playlist) == i: break; #skip last item in json
        idMedia = str(playItem['wamId'])
        trackTitle = playItem['trackTitle']
        albumTitle = playItem['albumTitle']
        duration = int(playItem['duration'])/1000
        performers = playItem['performers']
        my_playlist.add(idMedia, {'title': trackTitle, 'album': albumTitle , 'duration': duration , 'artist': performers  }   )
        if i > 0: break #testing
    return my_playlist
    
def PLAY(playlist_url, playlist_channel):
    Log("\n PLAY [{},{}]\n".format(playlist_url, playlist_channel))

    try:    play_count = int(addon.getSetting(urllib.quote_plus("play_count_{}".format(playlist_channel))))
    except: play_count = 0
    addon.setSetting(urllib.quote_plus("play_count_{}".format(playlist_channel)), str(play_count + 1))

    try:    playing_genre = addon.getSetting("playlist_channel")
    except: playing_genre = 0
    addon.setSetting("playlist_channel", playlist_channel)

    xbmc.executebuiltin('Container.Refresh') #for updating playcount
    xbmcplugin.endOfDirectory(handle=addon_handle)  #force fill wait to stop because are going to use an infinite while loop

    my_playlist = MyPlaylist(xbmc.PLAYLIST_MUSIC)
    my_playlist.fillPlayList(playlist_url)
    #my_playlist = PlaylistFromJSON(playlist_url)    
    player = MyPlayer()
    my_playlist.player = player
    
    #default_playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    #default_playlist.clear()
    
    while True:
##        listitem = my_playlist.getlistitem()
##        if not listitem:
##            Log("play list exausted...reloading")
##            my_playlist = PlaylistFromJSON(playlist_url)
##            listitem = my_playlist.getlistitem()
##        if not listitem:
##            Log("exiting play because unable to load play list information")
##            break #exit if we still don't have information

        Log("player.set_is_active()")        
        player.set_is_active()

##        default_playlist.clear() #beause we are not acutally using playist
##        default_playlist.add(listitem.getPath(), listitem)
##        player.play(default_playlist)

        player.set_playlist_pointer(my_playlist)
        Log("player.play(my_playlist)")
        player.play(my_playlist)

        while player.is_active:
            Sleep(100)
            #Log("default_playlist.size={}  default_playlist.getposition={}".format(default_playlist.size(),default_playlist.getposition()))
            #Log("player.getTime={}  player.getTotalTime={}  player.getPlayingFile={}".format(player.getTime(),player.getTotalTime(),player.getPlayingFile()))
##            try:
##                item_to_delete = None
##                if player.getTotalTime() - player.getTime() < 10:
##                    item_to_delete = player.getPlayingFile()
##            except:
##                pass
        #if item_to_delete:
        #    default_playlist.remove(item_to_delete)

        if player.was_stopped:
            Log("exiting play because was stopped")
            break

        if not (addon.getSetting("playlist_channel") == playlist_channel):
            Log("stopping this thread because channel has changed")
            break

        
        #else:
        #    Log("play list exausted...reloading")
        #    my_playlist = PlaylistFromJSON(playlist_url, playlist_genre)

            
############################################
############################################
############################################
############################################

try:
    mode = None
    params = getParams()
    try:     url = urllib.unquote_plus(params["url"])
    except:  url = None
    try:    name = urllib.unquote_plus(params["name"])
    except: name = None
    try:    mode = int(params["mode"])
    except: mode = None
    try:     img = urllib.unquote_plus(params["img"])
    except:  img = None

    if   mode          is None: MAIN(root_url)
    elif mode ==     MODE_MAIN: MAIN(root_url)
    elif mode ==     MODE_PLAY: PLAY(url, name)
    elif mode == MODE_DOWNLOAD: Download(url, name)
    elif mode ==  MODE_REFRESH: REFRESH()
    

except:
    traceback.print_exc()
    pass



