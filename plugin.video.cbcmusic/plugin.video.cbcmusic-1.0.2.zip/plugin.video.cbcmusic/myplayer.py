import xbmc
import xbmcgui
import xbmcaddon

import datetime
import time
import os
import json
import threading
import traceback

import constants as C

from utils import addon_id
from utils import Log,LogR
from utils import Notify
from utils import DEFAULT_ICON_IMAGE
from utils import GetHtml
from utils import Header2pipestring

from F4mProxy import f4mProxyHelper


monitor = xbmc.Monitor()

        
############################################
############################################
# MyPlayer
############################################
############################################
class MyPlayer(xbmc.Player):
#__________________________________________________________________
#
    def __init__( self, *args, **kwargs):
        LogR(locals())
##        super(Thread,self).__init__(target, *args)
##        if C.PY2: xbmc.Player.__init__(self,args=args, kwargs=kwargs)
##        if C.PY3: super(xbmc.Player,self).__init__(args,kwargs)
        self.is_active = True
        self.was_stopped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.play_paused_count = None
        self.continue_after_download = False
        self.playlist_pointer = None
        self.fmproxyhelper = None
        self.root_song_url_generator = None
        self.song_skipped = False
        self.pause_event = threading.Event()
        self.speed_change_event = threading.Event()
        self.stop_playing_event = threading.Event()
#__________________________________________________________________
#
    def set_playlist_pointer( self, playlist ):
        self.playlist_pointer = playlist
#__________________________________________________________________
#
    def set_is_active( self ):
        self.is_active = True
#__________________________________________________________________
#
    def onPlayBackPaused( self ):
        Log("onPlayBackPaused")
        try:

            self.onQueueNextItem()
            
            self.pause_event.set()
            
            self.speedChangedTime = None
            self.speedChangedCount = None

            max_play_paused_count = 1
            max_play_paused_window = 5
            
            if self.play_paused_time:
                Log("play_paused_time_delta: " + repr(time.time() - self.play_paused_time))

                if (time.time() - self.play_paused_time) > max_play_paused_window:
                    self.play_paused_time = None
                    self.play_paused_count = None
                    #Log("values should be reset")
                    return
                
                if self.play_paused_count:
                    self.play_paused_count = self.play_paused_count + 1
                else:
                    self.play_paused_count = 1

                Log("play_paused_count" + str(self.play_paused_count))

                #save media to disk when this happens
                if self.play_paused_count >= max_play_paused_count:
                    proxy_thread = None
                    proxy_thread = threading.Thread(
                                target=self.SaveSong
                                ,args=(
                                    self.getMusicInfoTag().getTitle()
                                    ,self.getMusicInfoTag().getArtist()
                                    ,self.getMusicInfoTag().getComment()
                                    )
                                )
                    proxy_thread.daemon = True
                    Log('Saving song ' + repr( self.getMusicInfoTag().getTitle()), C.LOGERROR)
                    Notify(msg = 'Saving song ' + repr( self.getMusicInfoTag().getTitle() ), duration=10*1000)
                    proxy_thread.start()
                    LogR(dir(self))
                    self.play()
##                    self.SaveSong(   self.getMusicInfoTag().getTitle()
##                                    ,self.getMusicInfoTag().getArtist()
##                                    ,self.getMusicInfoTag().getComment()
##                                    )

            else:
                self.play_paused_time = time.time()
        except:
            traceback.print_exc()
        finally:
            Log("self.pause_event.clear()")
            self.pause_event.clear()
#__________________________________________________________________
#
    def SaveSong( self
                  ,title
                  ,artist
                  ,comment
                  ):

        self.continue_after_download = False
        
##        LogR(locals())
        this_addon = xbmcaddon.Addon() #recreate this object to get latest value
        if not self.fmproxyhelper and not this_addon.getSetting("download_path").lower():
            #the dialog box from below will not appear
            Log("not saving because 'normal' player is enabled and download path has not been set", xbmc.LOGWARNING)
            return

##        Log("getMusicInfoTag - title:'{}'".format(self.getMusicInfoTag().getTitle()))
##        Log("getMusicInfoTag - comment:'{}'".format(self.getMusicInfoTag().getComment() ) )
        Log("getMusicInfoTag - title:'{}'".format(title))
        Log("getMusicInfoTag - comment:'{}'".format(comment ) )

        if not self.getMusicInfoTag().getComment():
            Notify('Id is blank: skipping')
            return

        file_name = "{} - {}".format(  artist
                                     , title
                                     ).replace('/', '.')

        download_folder = this_addon.getSetting("download_path").lower()
        if download_folder in ['','None',None]:
            try:
                download_folder = xbmcgui.Dialog().browse(0, "Specify a folder to save Downloads", 'myprograms', '', False, False)
                this_addon.setSetting(id='download_path', value=download_folder)
                if not os.path.exists(download_folder): os.mkdir(download_folder)
            except:
                raise

        file_extension = ".ts"
        if True:
            date_string = datetime.datetime.now().strftime(".%Y-%m-%d")
        else:
            date_string = ""
        probe_filespec = os.path.join(download_folder, file_name+file_extension)
        if not os.path.exists(probe_filespec):
            download_path = probe_filespec
        else:
            for append in range(ord('a'),ord('z')):
                append = chr(append)
                probe_filespec = download_folder + file_name + date_string + append + file_extension
                if not os.path.exists(probe_filespec):
                    download_path = probe_filespec
                    break
                
        url =  self.getPlayingFile()
        Log(url)
        Log(comment)
        #get new link for the song - the original may have expired
        #url_generator = root_song_url_generator.format('35823') #test data
        if self.root_song_url_generator:
            #url_generator = self.root_song_url_generator.format(self.getMusicInfoTag().getComment())
            url_generator = self.root_song_url_generator.format(comment)
            Log(url_generator)
            html = GetHtml(url_generator)
            media = json.loads(html)
            url = "{}{}".format(media['url'], Header2pipestring())        
        Log("url:'{}'".format(url))

        save_song_stop_event = threading.Event()
        seek_forward_event = threading.Event()
        try:
            import HLSDownloaderRetry #part of f4mproxy dependency
            Log("Background_HLSDownloader instance")
            downloader = HLSDownloaderRetry.HLSDownloaderRetry()
            downloader.init(
                  url = url
                , stop_playing_event = save_song_stop_event
                , seek_forward_event = seek_forward_event
                , download_path = download_path
                )
            Log("Background_HLSDownloader keep sending start")
            downloader.keep_sending_video(None)
           
        
        finally:
            Log("Background_HLSDownloader keep sending finish")
            downloader = None
            save_song_stop_event = None
            seek_forward_event = None

        self.play_paused_time = None
        self.play_paused_count = None

        
#__________________________________________________________________
#
    def onPlayBackResumed( self ):
        Log("onPlayBackResumed")
        self.speedChangedTime = None
        self.speedChangedCount = None
#__________________________________________________________________
#
    def onPlayBackSpeedChanged(self, speed):
        Log('onPlayBackSpeedChanged')
        monitor.waitForAbort(0.1)
        try:
            self.speed_change_event.set()

            LogR(speed)
            if int(speed) == 0:
                return
            
            max_speedchange_count = 2
            max_speedchange_window = 5  

            if not self.speedChangedTime:
                self.speedChangedTime = time.time()
                LogR(self.speedChangedTime)
                return
##                raise Exception('a')
            
            if (time.time() - self.speedChangedTime) > max_speedchange_window:
                self.speedChangedTime = None
                self.speedChangedCount = 0
                LogR(time.time() - self.speedChangedTime)
                return

            if self.speedChangedCount:
                self.speedChangedCount = self.speedChangedCount + 1
            else:
                self.speedChangedCount = 1

            if self.speedChangedCount == max_speedchange_count:
                LogR((self.speedChangedCount,max_speedchange_count))
                self.song_skipped = True
                Log("seeking to end of song -- {}".format(self.getMusicInfoTag().getTitle()), xbmc.LOGINFO)
                if self.fmproxyhelper:
                    #self.fmproxyhelper.seekToEnd()
                    self.stop_playing_event.set()
                else:
                    self.seekTime(self.getTotalTime()-1 )
            else: 
                self.speedChangedTime = time.time()
        except:
            traceback.print_exc()
        finally:
            Log('finally:')
            self.speed_change_event.clear()
##            for x in range(5):
##                monitor.waitForAbort(0.2)
##            Log('waitabort end')
#__________________________________________________________________
#
    def onPlayBackSeek( self, seek_time, seek_offset ):
        Log("onPlayBackSeek:: getTotalTime()={} seek_time={} seek_offset={} speedChangedCount={}  speedChangedTime={}".format(self.getTotalTime(), seek_time, seek_offset,repr(self.speedChangedCount), repr(self.speedChangedTime) ) )
##        for x in range(5):
##            monitor.waitForAbort(0.1)        
#__________________________________________________________________
#
    def onPlayBackStarted( self ):
        Log("onPlayBackStarted")
        self.is_active = True  #important call to detect if http 404 error occured
        self.song_skipped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.continue_after_download = False
        try:
            Log("onPlayBackStarted :: " + self.getPlayingFile())
        except:
            pass
#__________________________________________________________________
#
    def onPlayBackEnded(self):
        Log("onPlayBackEnded")
        self.is_active = True
        self.was_stopped = False
        self.speedChangedTime = None
        self.speedChangedCount = None
        self.play_paused_time = None
        self.continue_after_download = False
#__________________________________________________________________
#
    def onPlayBackStopped(self):
        Log("onPlayBackStopped")
        self.was_stopped = True
        for x in range(5):
            monitor.waitForAbort(0.1)
#__________________________________________________________________
#
    def onQueueNextItem(self):
        Log("onQueueNextItem")
        self.is_active = False
        self.speedChangedTime = None
        self.speedChangedCount = None
##        self.play_paused_time = None
        self.continue_after_download = False
##        for x in range(5):
##            monitor.waitForAbort(0.1)
#__________________________________________________________________
#
