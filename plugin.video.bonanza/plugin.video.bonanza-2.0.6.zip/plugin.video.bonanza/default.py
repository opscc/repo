﻿'''
    IPTV BONANZA
    Copyright (C) 2017 BONANZA
    Based on Ultimate IPTV by  Whitecream - All credits to him!
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

__scriptname__ = "IPTV"
__author__ = "BONANZA"
__scriptid__ = "plugin.video.bonanza"
__version__ = "1.0.0"

import urllib,urllib2,re,gzip,socket
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys,os

import StringIO
import time
import datetime
import requests
import base64
import traceback

import routing
import mysql

from probe import Probe_url as Probe_url

from utils import this_addon as addon
from utils import this_addon
from utils import addon_id
from utils import Log as log
from utils import Log
from utils import Notify as notify
from utils import Header2pipestring as header2pipestring
from utils import DEFAULT_HTTP_HEADERS as HEADERS
from utils import Sleep
from utils import DownloadVideo as DownloadVideo


Request = urllib2.Request
progress = xbmcgui.DialogProgress()

#load our configurable settings
url_timeout = int(addon.getSetting('url_timeout'))
max_iptvlink_count = int(addon.getSetting('max_iptvlink_count'))
max_iptvlink_search_time = int(addon.getSetting('max_iptvlink_search_time'))
sort_results = (addon.getSetting("sort_results") == "true")
link_is_online_checkcount = int(addon.getSetting('link_is_online_checkcount'))

socket.setdefaulttimeout(url_timeout)

rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';': rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
bonanzaicon = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))

DEFAULT_ICON_IMAGE = 'DefaultVideo.png'
MODE_MAIN = 0
MODE_PAGE = 1
MODE_IPTV = 2
MODE_PLAY = 3
MODE_SEARCH = 4
MODE_SETTINGS = 5
MODE_DOWNLOAD = 6
MODE_REFRESH = 7

#################################
#################################
#################################
#################################

def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

#################################
#################################
#################################
#################################


def getHtml(url, referer=None, hdr=None, data=None):
    if url=='':
        return None
    log("reading html for url '{}'".format(url))

    if not hdr:
        req = Request(url, data, HEADERS)
    else:
        req = Request(url, data, hdr)

    if referer: req.add_header('Referer', referer)
    if data:    req.add_header('Content-Length', len(data))

    data = ''
    response = urllib2.urlopen(req, timeout=url_timeout)

    if response:
        if response.info().get('Content-Encoding') == 'gzip':
            buf = StringIO.StringIO( response.read())
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = response.read()

    if response:
        response.close()

    return data

def addDir(name, url, mode, iconimage, Folder=True):

    Log("\n addDir [{},{},{},{},{}] \n".format(name, url, mode, iconimage, Folder))
    
    if url.startswith('plugin'):
        u = url
    else:
        u = (sys.argv[0] +
             "?url=" + urllib.quote_plus(url) +
             "&mode=" + str(mode) +
             "&name=" + urllib.quote_plus(name))

    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setProperty("IsPlayable","false")

    addon_handle = int(sys.argv[1])
    if addon_handle > 0: xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=Folder)

#################################
#################################
#################################
#################################

def GETFILTER():
    filterset = int(addon.getSetting('filterset')) + 1
    txtfilter = addon.getSetting('txtfilter' + str(filterset))
    return txtfilter


def OPENSETTINGS():
    addon.openSettings()
    xbmc.executebuiltin('Container.Refresh')


def INDEX():
    #MAIN(addon.getSetting("search_starting_point"))
    MAIN("")

#################################
#################################
#################################
#################################

def MAIN(url):
    txtfilter = GETFILTER()
    if not txtfilter: txtfilter = "none"

    addDir('[COLOR blue][B]Current filter:[/B] '+txtfilter+'[/COLOR]', '', MODE_SETTINGS, bonanzaicon, Folder=False)
    addDir('IPTV M3u Stream Hunters', addon.getSetting("search_starting_point") + '???{}'.format(base64.b64encode(GETFILTER())), MODE_PAGE, 'http://www.m3uliste.pw/files/.logo-lw-scaled.jpg.png')
    
    try:
        html = getHtml(url)
        blogpage = re.compile("content='([^']+)' itemprop='image_url'.*?href='([^']+)'>([^<]+)<", re.DOTALL | re.IGNORECASE).findall(html)
        for img, url, name in blogpage:
            addDir(name, url, MODE_PAGE, img)
            
        try:
            nextp = re.compile("'blog-pager-older-link' href='([^']+)'", re.DOTALL | re.IGNORECASE).findall(html)[0]
            nextp = nextp.replace('&amp;','&')
            addDir('Next Page', nextp, MODE_MAIN, bonanzaicon)
        except:
            pass
    except:
        pass

    addon_handle = int(sys.argv[1])
    if addon_handle > 0: xbmcplugin.endOfDirectory( addon_handle )

#################################
#################################
#################################
#################################
    
def PAGE(url, name):
    log("\n PAGE [{},{}] \n".format(url,name))

    html = getHtml(url)

    try:
        dict_iptvlinks_direct = {}
        i=1
        txtfilter = GETFILTER()
        if txtfilter: addDir("[COLOR blue]Search for:[/COLOR] {}".format(txtfilter), url, MODE_SEARCH, bonanzaicon)

        if ('m3uliste' in url):
            for link in msq.db_link_urls_from_source(url):
                dict_iptvlinks_direct[link]=None
                addPlayItem(link)
        else:
            html = re.compile('<div class="code">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(html)[0]

        #iptvlinks_direct = re.compile("#EXTINF:-1,(?P<name>[^<]+)<[\W\w]+?(?P<url>http[s]?:\/\/[^<]+)", re.DOTALL | re.IGNORECASE).finditer(html)
        iptvlinks_direct = re.compile("#EXTINF:-1,(?P<name>[^<]+)<[\W\w]+?>(?P<protocol>(http[s]?|rmtp)?[^:]+):\/\/(?P<url>[^<]+)<", re.DOTALL | re.IGNORECASE).finditer(html)
        for res in iptvlinks_direct:
            link = "{}://{}".format(res.group('protocol') , res.group('url') )
            link = link.replace('&amp;','&')
            name = res.group('name')
            dict_iptvlinks_direct[link]=None
            addPlayItem([None,link,name])
        
        iptvlinks_relative = re.compile(">(http[s]?:\/\/[^<]+)", re.DOTALL | re.IGNORECASE).findall(html)
        for link in iptvlinks_relative:
            link = link.replace('&amp;','&')
            #log("'{}','{}','{}'".format(link in iptvlinks_direct[1], link, repr(iptvlinks_direct[1])))
            if (link not in dict_iptvlinks_direct):
                dict_iptvlinks_direct[link]=None
                name = "Link {}: {}".format(i,link)
                addDir(name, link, MODE_IPTV, bonanzaicon)
                i = i + 1

        addon_handle = int(sys.argv[1])
        if addon_handle > 0:
            if sort_results: xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
            xbmcplugin.endOfDirectory( addon_handle )

    except Exception as err:
        log("\n PAGE [{},{}]\n{}".format(url,name,err), xbmc.LOGERROR)
        traceback.print_exc()


#################################
#################################
#################################
#################################

def read_inline_search_filter_from_url(url,search_filter):
    link = url
    try:
        search_filter = url.split('???')[1]
        search_filter = base64.b64decode(search_filter)
        link = url.split('???')[0]
    except:
        pass
    return search_filter, link

#################################
#################################
#################################
#################################

##sort_order = int(addon.getSetting('sortxt'))
##if sort_order == 1:
##    sort_order = xbmcplugin.SORT_METHOD_DURATION
##elif sort_order == 2:
##    sort_order = xbmcplugin.SORT_METHOD_DATE
##elif sort_order == 3:
##    sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
##elif sort_order == 4:
##    sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
##elif sort_order == 5:
##    sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
##else:
##    sort_order = xbmcplugin.SORT_METHOD_UNSORTED

    
def SEARCHLINKS(url, search_filter=GETFILTER(), search_timeout=max_iptvlink_search_time ):

    log("\n SEARCHLINKS [{},{},{}] \n".format(url,search_filter,search_timeout) )

    txtfilter = search_filter #todo refactor txtfilter
    txtfilter, url = read_inline_search_filter_from_url(url, search_filter)

    try:     addon_handle = int(sys.argv[1])
    except:  addon_handle = -1
        
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )

    start_time = datetime.datetime.now()   

    if addon_handle > 0:
        progress.create("Searching IPTV lists","Searching for:"+search_filter)

    html = getHtml(url)
    if ('m3uliste' in url):
        blogpage = re.compile('<div\s+class=\"zs-accordion\s+selected\"(.*?)EXTINF', re.DOTALL | re.IGNORECASE).findall(html)[0]
    else:
        blogpage = re.compile('<div class="code">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(html)[0]
    iptvlinks = re.compile("(http[^<]+)", re.DOTALL | re.IGNORECASE).findall(blogpage)
    iptvlinks2 = re.compile(">(http[s]?:\/\/[^<]+)", re.DOTALL | re.IGNORECASE).findall(html)
    iptvlinkcount = len(iptvlinks) + len(iptvlinks2)

    count= 0
    links=0
   
    monitor = xbmc.Monitor()

    for link in iptvlinks:
        #time.sleep(1) #testing

        #progress for user
        if addon_handle > 0:
            count = count + 1
            mypercent=int((count*100/iptvlinkcount))
            progress.update(mypercent, "{} lists checked for '{}'".format(count, txtfilter) )
            if (progress.iscanceled()):
                notify('Search cancelled.  Showing any items found up to now')
                break

        #non-gui exit conditions
        if count > max_iptvlink_count:
            notify("Stopping search because max iptv search limit reached {}".format(max_iptvlink_count) )
            break
        if (datetime.datetime.now() - start_time).seconds   > search_timeout:
            notify("Stopping search because limit reached [ {} seconds ]".format(search_timeout) , duration=10000 )
            break
        if ( monitor.abortRequested() ):
            notify('Search due to kodi abort.  Nothing will be shown')
            return

        link = link.replace('&amp;','&')
        try:
            list_fitered_urls = None
            if msq.db_source_indexed(link) == True:
                log("we have information cached in local database, search from there")
            else:
                log("no information in DB for link '{}'".format(link))
                m3u = None
                try: m3u = getHtml(link)
                except: pass
                if not m3u: msq.db_source_add(link, '') 
                else:       parsem3u(html = m3u, source_url=link)

        except Exception as err:
            log("\n SEARCHLINKS [{},{},{}] \n{}".format(url,search_filter,search_timeout,err), xbmc.LOGERROR)
            traceback.print_exc()

    for link in iptvlinks2:
        #time.sleep(1) #testing

        #progress for user
        if addon_handle > 0:
            count = count + 1
            mypercent=int((count*100/iptvlinkcount))
            #if count % 10 == 0:
            #    progress.update(mypercent, "{} lists checked for '{}' ... {} links found".format(count, txtfilter, links) )
            progress.update(mypercent, "{} lists checked for '{}'".format(count, txtfilter) )
            if (progress.iscanceled()):
                notify('Search cancelled.  Showing any items found up to now')
                break
        #non-gui exit conditions
        if count > max_iptvlink_count:
            notify("Stopping search because max iptv search limit reached {}".format(max_iptvlink_count) )
            break
        if (datetime.datetime.now() - start_time).seconds   > search_timeout:
            notify("Stopping search because limit reached [ {} seconds ]".format(search_timeout) , duration=10000 )
            break
        if ( monitor.abortRequested() ):
            notify('Search due to kodi abort.  Nothing will be shown')
            return
        
        link = link.replace('&amp;','&')
        try:
            list_fitered_urls = None
            if msq.db_source_indexed(link) == True:
                log("we have information cached in local database, search from there")
            else:
                log("no information in DB for link '{}'".format(link))
                m3u = None
                try: m3u = getHtml(link)
                except: pass
                if not m3u: msq.db_source_add(link, '') 
                else:       parsem3u(html = m3u, source_url=link)

        except Exception as err:
            log("\n SEARCHLINKS [{},{},{}] \n{}".format(url,search_filter,search_timeout,err), xbmc.LOGERROR)
            traceback.print_exc()

    list_fitered_urls = msq.db_link_getmatchingnames(txtfilter)
    links = links + len(list_fitered_urls)

    #always allow refresh
    addDir("[COLOR blue] Refresh[/COLOR]", '', MODE_REFRESH, bonanzaicon, Folder=True)

    if links == 0: addDir("Nothing found for [COLOR {}]{}[/COLOR]".format("blue", txtfilter), '', '', '', Folder=False)

    for link in list_fitered_urls:
         addPlayItem(link)
            

        
    if addon_handle > 0:
        if sort_results:
            xbmcplugin.addSortMethod(handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_LABEL)
            xbmcplugin.addSortMethod(handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
            xbmcplugin.addSortMethod(handle=addon_handle, sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
            xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
        try:
            #when  cacheToDisc=False it can be annoying to switch channels, but if  cacheToDisc=True favorite links will not refresh
            xbmcplugin.endOfDirectory( handle=addon_handle, updateListing=False, cacheToDisc=True)
        except Exception as err:
            traceback.print_exc()

        progress.close()
        
    return True


############################################
############################################
############################################
############################################

def Refresh():
    Log("\Refresh []\n")
    xbmc.executebuiltin('Container.Refresh')

############################################
############################################
############################################
############################################

def IPTV(url, name):
    log("\nIPTV [{},{}]\n".format(url,name))

    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
    
    try:
        links_for_url = msq.db_link_urls_from_source(url)
        if len(links_for_url) < 1:
            log("nothing was found for IPTV in database.  Downloading and refreshing contents")
            try:
                m3u = getHtml(url)
                parsem3u(html=m3u, sitechk=True, source_url=url)
            except:
                pass
            msq.db_source_add(url, name) #regardless if dead link or not, we have now indexed it an so we flag DB accordingly
            links_for_url = msq.db_link_urls_from_source(url)
        else:
            log("many IPTV items in database.  Not downloading HTML")
            
        for link in links_for_url:
            addPlayItem(link)

    except Exception as err:
        log("\nIPTV [{},{}]\n{}".format(url,name,err), xbmc.LOGERROR)
        traceback.print_exc()

    if len(links_for_url) < 1: addDir('Nothing found', '', '', '', Folder=False)

    if sort_results: xbmcplugin.addSortMethod(handle=int(sys.argv[1]),sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.endOfDirectory( int(sys.argv[1]) )


############################################
############################################
############################################
############################################
    
def Download(url, title):
    log("\n Download [{},{}]\n".format(url, title))
    try:
        url, stream_type, latency = Probe_url(url, title)
        #url = 'http://filmes.listaccess.me:8080/series/russo/123456/10935.mp4?token=HkFcUEIJRFgSU1ZQXQ9TAFxSVVwAAgJQVVMLXFIFVAVdWwAGAllQU1QUGRFKTUdXWA5rUFBDC1NSXApQGEMURwARa1hVQ1xABQcAAQ0bGRBNCllcFlsAV1FUDVwMVFEASUFEWFVDXEAHBw0EGxUXV0EXUUtaAF09BgBPDFcEQw5HQRgTXg85BlVbVF1dGw8QCUEYG10SQUBYR20AXxIAQhMaFGJeDRMWWVlbQBlwW1EXQRgbVghFEAMRXEcOQ1AHV1QWHRMCCRdeQkdKGwMXcXhBGBtRGUUHDBZQClpDWxYIEwATHUMPEW9EUEBNS1BTVAZGGw5DAUBOR1QETD4CWwsNUVJFCAkMQxQPEQgbGRBUDFpQQA5DPRIMXUcODxRYCR4=|Accept-Encoding=gzip,deflate&User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
        #url = 'http://raid.opscc.net/pics/Jamie%20Lynn/_Movies/127_02_mooningthesun1920x1080.mp4|Accept-Encoding=gzip,deflate&User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
        DownloadVideo(url, title)
    except:
        traceback.print_exc()
    
############################################
############################################
############################################
############################################
    
def addPlayItem(link_tuple):
    friendly_name = link_tuple[2].strip()
    playable_url  = link_tuple[1]
    liz = xbmcgui.ListItem(friendly_name)
    liz.setInfo(type="Video", infoLabels={"Title": friendly_name})
    liz.setArt({'thumb': DEFAULT_ICON_IMAGE, 'icon': DEFAULT_ICON_IMAGE})
    liz.addStreamInfo('video', {'codec': 'h264'})

    if '.mp4' in playable_url:
        download_url = "{}?url={}&mode={}&name={}".format(
                    sys.argv[0]
                    ,urllib.quote_plus(playable_url.encode('utf-8'))
                    ,MODE_DOWNLOAD
                    ,urllib.quote_plus(friendly_name.encode('utf-8'))
                    )
        contextMenuItems = []
        contextMenuItems.append(('[COLOR hotpink]Download Video[/COLOR]', 'xbmc.RunPlugin('+download_url+')'))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)

    try:    addon_handle = int(sys.argv[1])
    except: addon_handle = -1

    if addon_handle > 0:
        if isinstance(friendly_name, str):  friendly_name = unicode(friendly_name, "utf-8")

        internally_redirected_url = "{}?url={}&mode={}&name={}".format(
                    sys.argv[0]
                    ,urllib.quote_plus(playable_url.encode('utf-8'))
                    ,MODE_PLAY
                    ,urllib.quote_plus(friendly_name.encode('utf-8'))
                    )

        xbmcplugin.addDirectoryItem(handle=addon_handle, url=internally_redirected_url, listitem=liz, isFolder=False)
    
############################################
############################################
############################################
############################################
    
def parsem3u(html, sitechk=False, channel_filter=None, show_link_progress=True, source_url='', source_name=''):
    log("\n parsem3u [{},{},{},{},'{}'] \n".format(sitechk , channel_filter, show_link_progress, source_url, source_name ))
    
    match = re.compile('#.+,(.+?)\n(.+?)\n').findall(html)

    #use default filtering rule unless it has been overridden by caller
    if not channel_filter:
        txtfilter = txtfilter = GETFILTER()
        log("channel_filter not set; using default{}".format(txtfilter))
    else:
        txtfilter = channel_filter
        log("channel_filter set as: '{}'".format(txtfilter))
        
    txtfilter = txtfilter.split(',') if txtfilter else []
    txtfilter = [f.lower().strip() for f in txtfilter]

    i = 0
    count = 0

    try:
        addon_handle = int(sys.argv[1])
    except:
        addon_handle = -1
    if addon_handle > 0:
        progress.create(heading="Parsing and validating up to {} links ...".format(len(match) ) )

    log("matches found {}".format(len(match)))

    delete_non_stream_links = (addon.getSetting("delete_non_stream_links") == "true")
    log("delete_non_stream_links:'{}'".format(delete_non_stream_links))
    try:
        msq.db_link_add_bulk(match, source_url)
        if delete_non_stream_links:
            msq.delete_non_stream_links(source_url)
    except Exception as err:
        log("\n parsem3u [{},{},{},'{}','{}'] \n{}".format(sitechk , channel_filter, show_link_progress, source_url, source_name, repr(err) ), xbmc.LOGERROR)
        traceback.print_exc()

    try:
        if source_url:
            msq.db_source_add(source_url, source_name)
    except Exception as err:
        log("\n parsem3u [{},{},{},{},'{}'] \n{}".format(sitechk , channel_filter, show_link_progress, source_url, source_name, repr(err) ), xbmc.LOGERROR)
        traceback.print_exc()

    return count

############################################
############################################
############################################
############################################

def PLAY(url, title):
    log("\n PLAY [{},{}]\n".format(url, title))

    #log ("addon_handle saved:{} argv:{} ".format(addon_handle, sys.argv[1] ))

    original_url = url
    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    stream_type = None

    #test if url is responsive and return url's content type so that we know how to stream it
    try:
        url, stream_type, latency = Probe_url(url, title) 
    except Exception,e:
        log(repr(e))
        traceback.print_exc()
        return

    log ("url:{} title:{} ".format(url,title), xbmc.LOGNONE)
    if not url:
        return
    if url == "" :
        return

    try:
        if url:
            msq.db_link_update_date_checked(original_url)
    except:
        traceback.print_exc()
    
    #stype = 'TSDOWNLOADER'
    #stype = 'HLSREDIR'
    if stream_type:
        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        xbmcplugin.endOfDirectory( int(sys.argv[1]) ) #required or else can't access menues
        f4mp.playF4mLink( url
                         ,name
                         ,proxy=None
                         ,use_proxy_for_chunks=False
                         ,maxbitrate=0
                         ,simpleDownloader=False
                         ,auth=None
                         ,streamtype = stream_type
                         ,setResolved=False
                         ,swf=None
                         ,callbackpath=""
                         ,callbackparam=""
                         ,iconImage=DEFAULT_ICON_IMAGE
                         )
        return

    log("using regular player")
    listitem = xbmcgui.ListItem(name, iconImage=DEFAULT_ICON_IMAGE, thumbnailImage=DEFAULT_ICON_IMAGE)
    #if '.m3u' in url:
    #    listitem.setProperty('inputstreamaddon','inputstream.adaptive')
    #    listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
    
    listitem.setInfo('video', {'Title': name})
    listitem.setProperty("IsPlayable","true")
    if ( int(sys.argv[1]) > 0 ):
        listitem.setPath(url) 
        xbmcplugin.setResolvedUrl( int(sys.argv[1]), True, listitem)
    else:
        xbmc.Player().play(url, listitem)

############################################
############################################
############################################
############################################

def get_favourites_from_file():
    '''json method for favourites doesn't return all items (such as android apps) so retrieve them from file'''
    allfavourites = []
    import xbmcvfs
    try:
        from xml.dom.minidom import parse
        favourites_path = xbmc.translatePath('special://profile/favourites.xml').decode("utf-8")
        if xbmcvfs.exists(favourites_path):
            doc = parse(favourites_path)
            result = doc.documentElement.getElementsByTagName('favourite')
            for fav in result:
                action = fav.childNodes[0].nodeValue
                action = action.replace('"', '')
                label = fav.attributes['name'].nodeValue
                try:
                    thumb = fav.attributes['thumb'].nodeValue
                except Exception:
                    thumb = ""
                window = ""
                windowparameter = ""
                action_type = "unknown"
                if action.startswith("StartAndroidActivity"):
                    action_type = "androidapp"
                elif action.startswith("ActivateWindow"):
                    action_type = "window"
                    actionparts = action.replace("ActivateWindow(", "").replace(",return)", "").split(",")
                    window = actionparts[0]
                    if len(actionparts) > 1:
                        windowparameter = actionparts[1]
                elif action.startswith("PlayMedia"):
                    action_type = "media"
                    action = action.replace("PlayMedia(", "")[:-1]
                allfavourites.append({"label": label, "path": action, "thumbnail": thumb, "window": window,
                                      "windowparameter": windowparameter, "type": action_type})
    except Exception as err:
        log("get_favourites_from_file:'{}'".format(err), xbmc.LOGERROR)
    return allfavourites
    
############################################
############################################
############################################
############################################

def Get_filters_for_url_validation():
    all_filters=""
    for fav in get_favourites_from_file():
        fav_url = fav['windowparameter']
        if fav_url.startswith("plugin://{}/".format(addon_id)):
            fav_url = urllib.unquote_plus( fav_url.split("&name=")[1] )
            txtfilter, url = read_inline_search_filter_from_url(fav_url, "")        
            all_filters = all_filters + "," + txtfilter
    for i in range(1, 5):    
        txtfilter = addon.getSetting('txtfilter' + str(i))
        all_filters = all_filters + "," + txtfilter
    all_filters = all_filters.strip(',')    
    all_filters = all_filters.split(",")
    all_filters = list(set(all_filters))
    all_filters.sort()
    all_filters = ','.join(map(str, all_filters))
    return all_filters


############################################
############################################
############################################
############################################

msq = mysql.MySQL()


monitor = xbmc.Monitor()
    
##list_fitered_urls = msq.db_link_getmatchingnames( Get_filters_for_url_validation() )
##            
##for link in list_fitered_urls:
##    Log("date_added:'{}'".format(link[3]), xbmc.LOGNONE)
##    #Log("url:'{}'".format(link[1]), xbmc.LOGNONE)
##    if monitor.waitForAbort(1):
##        Log("ending thread {} due to abort signal while probing".format(threading.current_thread()))
##        break
##
##    try:
##        #Log("url:'{}'".format(type(link[1])), xbmc.LOGNONE)
##        #from unidecode import unidecode
##        
##        #from unicodedata import normalize
##        #link = normalize('NFKD', link[1])
##        #link = link[1].encode('ascii',errors='ignore')
##        #Log(" url:'{}'".format(repr(link[1])), xbmc.LOGNONE)
##        #Log("link:'{}'".format(repr(link[2])), xbmc.LOGNONE)
##        try:
##            url = link[1].encode('ascii',errors='ignore')
##            title = link[2].encode('ascii',errors='ignore')
##            url, stream_type, latency = Probe_url(url=url,title=title)
##            if url:
##                msq.db_link_update_date_checked(link[1])
##        except UnicodeEncodeError:
##            msq.db_link_update_date_checked(link[1])
##            pass
##        except:
##            #Log("url:'{}'".format(type(link[1])), xbmc.LOGNONE)
##            #Log("url:'{}', date_added:'{}'".format(link[1],link[3]), xbmc.LOGNONE)
##            traceback.print_exc()
##            raise
##    except UnicodeEncodeError:
##        raise
        

##try:
##    url, stream_type, latency = Probe_url("http://116.125.216.42:9981/stream/channelid/360867240?ticket=F3477584FFDB456E043E2AD43A8DF2254309C651&profile=pass", "GR:Βρ")
##except:
##    pass

try:
    mode = None
    params = getParams()
    try:    url = urllib.unquote_plus(params["url"])
    except: url = None
    try:    name = urllib.unquote_plus(params["name"])
    except: name = None
    try:    mode = int(params["mode"])
    except: mode = None
    try:    img = urllib.unquote_plus(params["img"])
    except: img = None

    if   mode is None: INDEX()
    elif mode == MODE_MAIN: MAIN(url)
    elif mode == MODE_PAGE: PAGE(url, name)
    elif mode == MODE_IPTV: IPTV(url, name)
    elif mode == MODE_PLAY: PLAY(url, name)
    elif mode == MODE_SEARCH: SEARCHLINKS(url)
    elif mode == MODE_SETTINGS: OPENSETTINGS()
    elif mode == MODE_DOWNLOAD: Download(url, name)
    elif mode == MODE_REFRESH: Refresh()
    
except:
    pass



