import threading
import xbmc
import xbmcaddon
import time
import traceback
import random

import utils
from utils import Log
from utils import this_addon as this_addon
from utils import Sleep as Sleep
from default import SEARCHLINKS as SEARCHLINKS
from default import Get_filters_for_url_validation
from default import Probe_url

import mysql


def link_crawler():
    monitor = xbmc.Monitor()

    ## sleep then ... 
    sleeptime = int(int(this_addon.getSetting("service_periodic_interval")) * random.random() )
    Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
    Sleep(int(sleeptime * 1000))
    if monitor.waitForAbort(1):
        Log("ending thread {} due to abort".format(threading.current_thread().name))
        return
    
    while not monitor.abortRequested():

        ## ... do some work
        try:
            max_iptvlink_search_time = int(this_addon.getSetting('max_iptvlink_search_time')) * 3
            SEARCHLINKS(this_addon.getSetting("search_starting_point"), "", max_iptvlink_search_time)
        except:
            traceback.print_exc()
            
        ## sleep then ... do some work
        sleeptime = int(this_addon.getSetting("service_periodic_interval"))
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        Sleep(sleeptime * 1000)
        if monitor.waitForAbort(1):
            Log("ending thread {} due to abort".format(threading.current_thread().name))
            break
        
def db_maintenance():

    monitor = xbmc.Monitor()
    ## sleep then ... 
    sleeptime = int(int(this_addon.getSetting("service_periodic_interval")) * random.random() )
    Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
    Sleep(int(sleeptime * 1000))
    if monitor.waitForAbort(1):
        Log("ending thread {} due to abort".format(threading.current_thread().name))
        return
    
    while not monitor.abortRequested():

        ## ... do some work
        try:
            msq = mysql.MySQL()
            days_to_keep_links = float(  this_addon.getSetting("days_to_keep_links") )
            last_date_cleaned = msq.db_get_last_clean_date()
            if (float(last_date_cleaned) + 60*60*24*days_to_keep_links - 1) < time.time():
                msq.db_clean_old(days_to_keep_links)
        except:
            traceback.print_exc()

        ## sleep then ... 
        sleeptime = int(this_addon.getSetting("service_periodic_interval")) * 10 
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        Sleep(sleeptime * 1000)
        if monitor.waitForAbort(1):
            Log("ending thread {} due to abort".format(threading.current_thread().name))
            break
        
        #log("last_date_cleaned:{}\nfloat(last_date_cleaned):{}\n60*60*24*days_to_keep_links:{}\ntruefalse:{}\n".format(last_date_cleaned,float(last_date_cleaned),60*60*24*days_to_keep_links,(float(last_date_cleaned) + 60*60*24*days_to_keep_links ) < time.time()))
        #exit(0)

def link_checker():

    monitor = xbmc.Monitor()
    
    ## sleep then ... 
    sleeptime = int(int(this_addon.getSetting("service_periodic_interval")) * 0 * random.random() )
    Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
    Sleep(int(sleeptime * 1000))
    if monitor.waitForAbort(1):
        Log("ending thread {} due to abort signal".format(threading.current_thread().name))
        return
        
    while not monitor.abortRequested():

        ## ... do some work
        list_fitered_urls = {}
        try:
            enable_link_checker = this_addon.getSetting("enable_link_checker") == "true"
            if enable_link_checker == True:
                msq = mysql.MySQL()
                list_fitered_urls = msq.db_link_getmatchingnames( Get_filters_for_url_validation() )
        except:
            traceback.print_exc()
            
        for link in list_fitered_urls:

            if monitor.waitForAbort(1):
                Log("ending thread {} due to abort signal while probing".format(threading.current_thread().name))
                break

            enable_link_checker = this_addon.getSetting("enable_link_checker") == "true"
            if enable_link_checker == False:
                Log("pausing link_checker due to setting.  We will check if we need to restart after {} seconds".format(sleeptime))
                break

            #Log("service about to probe:{}".format(repr(link))
            try:
                url, stream_type = Probe_url(url=link[1],title=link[2])
                if url:
                    msq.db_link_update_date_checked(link[1])
            except:
                traceback.print_exc()


        ## sleep then ... 
        sleeptime = int(this_addon.getSetting("service_periodic_interval")) / 10
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        Sleep(sleeptime * 1000)
        if monitor.waitForAbort(1):
            Log("ending thread {} due to abort signal".format(threading.current_thread().name))
            break
        

if __name__ == '__main__':

    # start thread for link_crawler service
    proxy_thread = threading.Thread(target=link_crawler,name=utils.addon_id+".link_crawler")
    proxy_thread.daemon = True
    proxy_thread.start()

    # start thread for db_maintenance service
    proxy_thread = threading.Thread(target=db_maintenance, name=utils.addon_id+".db_maintenance")
    proxy_thread.daemon = True
    proxy_thread.start()

    # start thread for link_checker service
    proxy_thread = threading.Thread(target=link_checker, name=utils.addon_id+".link_checker")
    proxy_thread.daemon = True
    proxy_thread.start()

    # add thread to delete dead links for items that are a favourite or in our filter list
    
    # kill the services if kodi monitor tells us to
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            Log("shutting down '{}' service".format(utils.addon_id), xbmc.LOGNOTICE)
            break


