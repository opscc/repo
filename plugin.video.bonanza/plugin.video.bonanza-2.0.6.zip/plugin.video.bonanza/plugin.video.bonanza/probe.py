import urllib,urllib2,re,gzip,socket
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys,os

import mysql
import traceback

from utils import this_addon as addon
from utils import this_addon
from utils import addon_id
from utils import Log as log
from utils import Notify as notify
from utils import Header2pipestring as header2pipestring
from utils import DEFAULT_HTTP_HEADERS as HEADERS
from utils import Sleep
from utils import DownloadVideo as DownloadVideo



delete_error_links = (addon.getSetting('delete_error_links') == "true")
url_timeout = int(addon.getSetting('url_timeout'))

############################################
############################################
############################################
############################################

class HeadRequest(urllib2.Request):
    '''A Request class that sends HEAD requests'''
    def get_method(self):
        return 'HEAD'
class OptionsRequest(urllib2.Request):
    '''A Request class that sends OPTIONS requests'''
    def get_method(self):
        return 'OPTIONS'

def Probe_url(url, title):

    DEFAULT_CONTENT_TYPE = ''
    
    stream_type = None
    url_request_result = None
    
    original_url = url #keep track of original value...we may be modifying it
    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    title = title.strip('\r')

    #deal with non-ascii charset issues    
    #title = 'R++ckkehr'
    if isinstance(url, str):   url=unicode(url,"utf-8","replace")
    if isinstance(title, str): title = unicode(title,"utf-8","replace")
    url = url.encode("utf-8")
    title = title.encode("utf-8")

  
    #test if we will be redirected by reading the first 100 bytes
    link_checker_probe_type = (this_addon.getSetting('link_checker_probe_type').lower())
    log("link_checker_probe_type option '{}'".format(link_checker_probe_type))
    if link_checker_probe_type == 'none':
        log("Returning defaults '{}','{}'".format(url, DEFAULT_CONTENT_TYPE))
        return url, DEFAULT_CONTENT_TYPE
    elif link_checker_probe_type == 'normal':
        req = urllib2.Request(url, headers=HEADERS )
        if ('.m3u' in url) or ('.mp4' in url):   req.add_header('Range', 'bytes=0-100') #only get a few bytes to test for redirection
        req.add_header('Accept-Encoding', '*')
    elif link_checker_probe_type == 'head':
        req = HeadRequest(url, headers=HEADERS) #only reading HEAD will give us content type, but it may not reflect the actual contents availability
    elif link_checker_probe_type == 'options':
        req = OptionsRequest(url, headers=HEADERS)

    log("Begin PLAY URL probe '{}', '{}' ".format(url,title))
    retry_count_max = 3
    retry_count = 0

    if url.startswith("rtmp:"):
       return url, DEFAULT_CONTENT_TYPE 
    
    while retry_count < retry_count_max : #try and get our information via loop so that we can re-use our exception code

        try:
            url_request_result = urllib2.urlopen(req, timeout=url_timeout)

            maybe_redicted_url = url_request_result.geturl()

            #link may be to a redirected file, and if so, I want to use the redirection
            if ('.m3u' in maybe_redicted_url) or ('.mp4' in maybe_redicted_url):
                url = maybe_redicted_url + header2pipestring()
            else:
                url = url + header2pipestring()

            retry_count = retry_count_max + 1

        except (socket.timeout) as e:
            log("Simple timeout error.  Retrying...")
            Sleep(1000)
            retry_count += 1            
            
        except urllib2.URLError, e:
            #xbmc.executebuiltin( "Container.Refresh" ) #experiment to refresh listing after deleting a link; should be OK because informatin is DB now
            #traceback.print_exc()
            if isinstance(e.reason, socket.timeout):
                log("socket.timeout error.  Retrying...")
                Sleep(1000)
                retry_count += 1                
            elif hasattr(e,'code'):
                log ("URLError [{}] {}".format(e.code, title ) )
                if e.code >= 400 and e.code < 500: #maybe delete 500 ? sometimes it will work after a retry
                    retry_count = retry_count_max
                    break
                else:
                    log("HTTP 520 error.  Retrying...")
                    Sleep(1000)
                    retry_count += 1
            else:
                log ("URLError [{}] {}".format(e, title ) )
                #if delete_error_links: msq.db_link_delete(original_url)   #delete bad URLs from future searchs
                #return None, None
                retry_count = retry_count_max
                break

        except Exception,e:
            traceback.print_exc()
            log ("Failed '{}' [{}]".format(title,e) )
            #if delete_error_links: msq.db_link_delete(original_url)   #delete bad URLs from future searchs
            #return None, None
            retry_count = retry_count_max
            break

    if retry_count == retry_count_max:
        notify ("Error opening '{}' [{}]".format(title,original_url) , duration=3000)
        url = None # we errored out and should return None so that url is not reopened
        if delete_error_links:
            msq = mysql.MySQL()
            msq.db_link_delete(original_url)   #delete bad URLs from future searchs

    if url_request_result:
        detected_content_type = url_request_result.info()['Content-Type']
        log("Content-type:{}".format(detected_content_type))
        if   detected_content_type == 'video/mp2t':                    stream_type = 'TSDOWNLOADER'
        elif detected_content_type == 'video/mpeg':                    stream_type = 'TSDOWNLOADER'
        elif detected_content_type == 'flv-application/octet-stream':  stream_type = 'HLS'
        elif detected_content_type == 'application/vnd.apple.mpegurl': stream_type = 'HLSREDIR'
        elif detected_content_type == 'video/mp4':                     stream_type = DEFAULT_CONTENT_TYPE
        else:                                                          stream_type = DEFAULT_CONTENT_TYPE
   
    log("Final PLAY URL probe '{}', '{}'".format(url, stream_type))
    return url, stream_type
