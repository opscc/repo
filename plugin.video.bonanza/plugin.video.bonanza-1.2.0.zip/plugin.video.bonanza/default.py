﻿'''
    IPTV BONANZA
    Copyright (C) 2017 BONANZA
    Based on Ultimate IPTV by  Whitecream - All credits to him!
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


__scriptname__ = "IPTV"
__author__ = "BONANZA"
__scriptid__ = "plugin.video.bonanza"
__version__ = "1.0.0"

import urllib, urllib2, re, gzip, socket
import xbmc,xbmcplugin,xbmcgui,xbmcaddon,sys, os

import StringIO
import time
import requests
import base64


dialog = xbmcgui.Dialog()
progress = xbmcgui.DialogProgress()
addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id=__scriptid__)
USER_AGENT = 'Mozilla/5.0'
headers = {
            'User-Agent': USER_AGENT
            ,'Connection': 'keep-alive'
            ,'Accept-Encoding': 'gzip,deflate'
            }

socket.setdefaulttimeout(4)

rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
bonanzaicon = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))
profileDir = addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')


if not os.path.exists(profileDir):
    os.makedirs(profileDir)

urlopen = urllib2.urlopen
Request = urllib2.Request

added_urls = [1,2]

def log(msg='', loglevel=xbmc.LOGDEBUG):
    debug = None
    try:
        debug = (addon.getSetting('debug').lower() == "true")
    except:
        debug = True

    if debug:
        xbmc.log(msg , xbmc.LOGNONE)
    else:
        xbmc.log(msg , loglevel)

def notify(header=None, msg='', duration=5000):
    if header is None: header = __scriptname__
    xbmcgui.Dialog().notification(header, msg, bonanzaicon, duration, sound=False )

def getHtml(url, referer=None, hdr=None, data=None):
    if url=='':
        return None
    #log("reading html for url '{}'".format(url))

    if not hdr:
        req = Request(url, data, headers)
    else:
        req = Request(url, data, hdr)

    if referer:
        req.add_header('Referer', referer)

    if data:
        req.add_header('Content-Length', len(data))

    try:
        response = urlopen(req, timeout=2)
    except Exception as err:
        log(str(err))

    if response.info().get('Content-Encoding') == 'gzip':
        buf = StringIO.StringIO( response.read())
        f = gzip.GzipFile(fileobj=buf)
        data = f.read()
        f.close()
    else:
        data = response.read()    
    response.close()
    return data


def addPlayLink(name, url, mode, iconimage, forceUvalue=None):

    try:
        u = (sys.argv[0] +
             "?url=" + urllib.quote_plus(url) +
             "&mode=" + str(mode) +
             "&name=" + urllib.quote_plus(name))

        if not forceUvalue:
            #log( "added_urls length is {}".format(   len(added_urls) )  )
            if u in added_urls:
                log("skipping item {} because it has been already added".format(u))
                return True  #item was already added
            #log("appending item {}".format(u))
            added_urls.append(u)
        else:
            name=forceUvalue.split('&')[2]
            u=forceUvalue
            log('added'+name+u)
        
        ok = True
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setArt({'thumb': iconimage, 'icon': iconimage})
        #liz.setProperty('IsPlayable', 'true')
        liz.setInfo(type="Video", infoLabels={"Title": name})
        video_streaminfo = {'codec': 'h264'}
        liz.addStreamInfo('video', video_streaminfo)
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)


        return ok
    except Exception as err:
        log(str(err))
        

def addDir(name, url, mode, iconimage, Folder=True):
    if url.startswith('plugin'):
        u = url
    else:
        u = (sys.argv[0] +
             "?url=" + urllib.quote_plus(url) +
             "&mode=" + str(mode) +
             "&name=" + urllib.quote_plus(name))

    ok = True

    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    fanart = os.path.join(rootDir, 'fanart.jpg')

    liz.setArt({'fanart': fanart})
    liz.setInfo(type="Video", infoLabels={"Title": name})

    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=Folder)
    return ok


def GETFILTER():
    filterset = int(addon.getSetting('filterset')) + 1
    txtfilter = addon.getSetting('txtfilter' + str(filterset))
    return txtfilter


def OPENSETTINGS():
    addon.openSettings()
    xbmc.executebuiltin('Container.Refresh')


def INDEX():
    MAIN('http://iptvsatlinks.blogspot.com/search?max-results=40')


def MAIN(url):
    txtfilter = GETFILTER()
    if not txtfilter:
        txtfilter = "none"
    addDir('[COLOR blue][B]Current filter:[/B] '+txtfilter+'[/COLOR]', '', 5, bonanzaicon, Folder=False)
    #addDir('IPTV M3u Stream Hunters', 'http://www.m3uliste.pw/', 1, 'http://www.m3uliste.pw/files/.logo-lw-scaled.jpg.png')
    addDir('IPTV M3u Stream Hunters', 'http://www.m3uliste.pw/'+ '???{}'.format(base64.b64encode(GETFILTER())), 1, 'http://www.m3uliste.pw/files/.logo-lw-scaled.jpg.png')
    
    html = getHtml(url)
    blogpage = re.compile("content='([^']+)' itemprop='image_url'.*?href='([^']+)'>([^<]+)<", re.DOTALL | re.IGNORECASE).findall(html)
    for img, url, name in blogpage:
        addDir(name, url, 1, img)
    try:
        nextp = re.compile("'blog-pager-older-link' href='([^']+)'", re.DOTALL | re.IGNORECASE).findall(html)[0]
        nextp = nextp.replace('&amp;','&')
        addDir('Next Page', nextp, 0, bonanzaicon)
    except:
        pass
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def PAGE(url):
    html = getHtml(url)

    blogpage = ''
    if html:
        if ('m3uliste' in url):
            blogpage = re.compile('<div\s+class=\"zs-accordion\s+selected\"(.*?)EXTINF', re.DOTALL | re.IGNORECASE).findall(html)[0]
        else:
            blogpage = re.compile('<div class="code">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(html)[0]

    if '#EXTINF' in blogpage:
        blogpage = blogpage.replace('<br />', '\n').replace('&nbsp;','').replace('&amp;','&')
        parsem3u(blogpage)
    else:
        txtfilter = GETFILTER()
        if txtfilter:
            addDir('[COLOR blue]Search all links for: '+txtfilter+'[/COLOR]', url, 4, bonanzaicon)
        iptvlinks = re.compile("(http[^<]+)", re.DOTALL | re.IGNORECASE).findall(blogpage)
        i = 1
        for link in iptvlinks:
            link = link.replace('&amp;','&')
            name = 'Link ' + str(i) + ': ' + link
            addDir(name, link, 2, bonanzaicon)
            i = i + 1
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def SEARCHLINKS(url):

    inline_filter = None
    try:
        log("SEARCHLINKS 1 {}".format(url) )
        inline_filter = url.split('???')[1]
        log("SEARCHLINKS 2 {}".format(inline_filter) )
        txtfilter = base64.b64decode(inline_filter)
        log("SEARCHLINKS 3 {}".format(txtfilter) )
        url = url.split('???')[0]
        log("SEARCHLINKS 4 {}".format(url) )
    except:
        pass
    
    if not inline_filter:
        txtfilter = GETFILTER()
   
    dp = xbmcgui.DialogProgress()
    dp.create("Searching IPTV lists","Searching for:"+txtfilter)

    html = getHtml(url)

    if ('m3uliste' in url):
        blogpage = re.compile('<div\s+class=\"zs-accordion\s+selected\"(.*?)EXTINF', re.DOTALL | re.IGNORECASE).findall(html)[0]
    else:
        blogpage = re.compile('<div class="code">(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(html)[0]

    iptvlinks = re.compile("(http[^<]+)", re.DOTALL | re.IGNORECASE).findall(blogpage)
    iptvlinkcount = len(iptvlinks)
    count= 0
    links=0

    del added_urls[:] #clear results of previous search
    #log("added_urls {}".format(added_urls)) #validate in log that list is empty
    
    try:
        max_iptvlink_count = 100
        max_iptvlink_search_time = 100
        max_iptvlink_count = int(addon.getSetting('max_iptvlink_count'))
        max_iptvlink_search_time = int(addon.getSetting('max_iptvlink_search_time'))
    except:
        pass
        
    for link in iptvlinks:
        count = count+1
        mypercent=int((count*100/iptvlinkcount))
        dp.update(mypercent, "IPTV lists checked for '{}': {}: found: {}".format(txtfilter, count, len(added_urls)) )
        #dp.update(mypercent, "percent{} count{} iptvlinkcount{} found links{}".format(mypercent, count, iptvlinkcount, links) )

        if count > max_iptvlink_count:
            log("Stopping search because max iptv search limit reached {}".format(max_iptvlink_count) )
            break
        #time.sleep(1)
        
        if (dp.iscanceled()):
            notify('Search cancelled')
            #show what we managed to get so far
            if added_urls:
                for x in added_urls:
                    addPlayLink('', '', '', '', forceUvalue=x)
            break
        
        link = link.replace('&amp;','&')
        try:
            m3u = getHtml(link)
            links = links + parsem3u(html = m3u, sitechk=True, channel_filter=txtfilter, show_link_progress=False)
            #if links > 0: addDir('---------------------', '', 1, bonanzaicon, Folder=False)
        except:
            pass

    if links == 0:
        addDir('Nothing found', '', '', '', Folder=False)

    #log("added_urls from search [{}]".format(added_urls)) #make sure list is set
        
    dp.close()

    xbmcplugin.addSortMethod(handle=int(sys.argv[1]),sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    #log('sortmethod has been added')
    
    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True)


def IPTV(url):
    #notify(url)

    #added_urls=[]
    #global added_urls
    del added_urls[:] #clear existing list contents
    
    links = 0
    try:
        m3u = getHtml(url)
        links = links + parsem3u(html=m3u,sitechk=True)
    except Exception as err:
        log(str(err))
        pass
    if links == 0:
        addDir('Nothing found', '', '', '', Folder=False)

    #added_urls.append('aa')
    #log("added_urls from IPTV {}".format(added_urls))

    xbmcplugin.addSortMethod(handle=int(sys.argv[1]),sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def parsem3u(html, sitechk=False, channel_filter=None, show_link_progress=True):

    match = re.compile('#.+,(.+?)\n(.+?)\n').findall(html)

    #use default filtering rule unless it has been overridden by caller
    if not channel_filter:
        txtfilter = txtfilter = GETFILTER()
        log("channel_filter not set; using default{}".format(txtfilter))
    else:
        txtfilter = channel_filter
        log("channel_filter set as{}".format(txtfilter))
        
    txtfilter = txtfilter.split(',') if txtfilter else []
    txtfilter = [f.lower().strip() for f in txtfilter]

    try:
        link_is_online_checkcount = 20
        link_is_online_checkcount = int(addon.getSetting('link_is_online_checkcount'))
    except:
        pass

    i = 0
    count = 0

    pDialog = None
    if sitechk and show_link_progress:
        pDialog = xbmcgui.DialogProgress()
        pDialog.create(heading='Validating links ...')

##    try:
##        if pDialog:
##            if pDialog.iscanceled():
##                return
##            pDialog.update(1,'Validating link {} ...'.format(i) )
##    except Exception as err:
##        log(('pdialog:%s' %  err ))
##    return
                        
    log("matches found {}".format(len(match)))
        
    for name, url in match:

        status = ""
        url = url.replace('\r','')
        if not txtfilter or any(f in name.lower() for f in txtfilter):

            if sitechk:

                #log("individual link check enabled")

                i += 1
                if i <= link_is_online_checkcount:

                    #log("maximum [{}] for individual link check not reached [{}]".format(link_is_online_checkcount,i))
                    if pDialog:
                        if pDialog.iscanceled():
                            break
                        pDialog.update(1,'Validating link {} for url {} ...'.format(i,url) )
                        
                    try:
                        #log('testing url {}'.format(url))
                        #I want to use use reguests.head or .options instead of downloading the entire packet, but sites will succeed with .options but not with .get  ... and we need to .get in order to play
                        prox = {'127.0.0.1':8888}
                        req = requests.get(url=url, timeout=1, proxies=prox) #, proxies=prox) #'OPTIONS'

                        if req.ok:
                            status = " [COLOR green]online[/COLOR]"
                            #log("on line:{}   :{}".format(name,url))
                        else:
                            status = " [COLOR red]offline[/COLOR]"
                            #log("offline:{}   :{}".format(name,url))
                        
                    except Exception as err:
                        log(str(err))
                        status = " [COLOR blue]maybe offline[/COLOR]"
                        log("maybeoff:{}   :{}".format(name,url))
                            
                    i += 1
                    
                #else:
                    #log("Stopping link check because limit reached {}of{} ".format(i,link_is_online_checkcount) )

            addPlayLink(name+status, url, 3, bonanzaicon)
            count += 1

    if pDialog: pDialog.close()

    #global added_urls
    #log("added_urls from parsem3u [{}]".format(added_urls))

    return count


def PLAY(url, title):
    playmode = int(addon.getSetting('playmode'))
    iconimage = xbmc.getInfoImage("ListItem.Thumb")

    if playmode == 0:
        stype = ''
        if '.ts' in url:
            stype = 'TSDOWNLOADER'
        elif '.m3u' in url:
            stype = 'HLSRETRY'
        if stype:
            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
            f4mp.playF4mLink(url,name,proxy=None,use_proxy_for_chunks=False, maxbitrate=0, simpleDownloader=False, auth=None, streamtype=stype,setResolved=False,swf=None , callbackpath="",callbackparam="", iconImage=iconimage)
            return
    
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name})
    listitem.setProperty("IsPlayable","true")
    xbmc.Player().play(url, listitem)


def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = getParams()
url = None
name = None
mode = None
img = None

try: url = urllib.unquote_plus(params["url"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: mode = int(params["mode"])
except: pass
try: img = urllib.unquote_plus(params["img"])
except: pass

if mode is None: INDEX()
elif mode == 0: MAIN(url)
elif mode == 1: PAGE(url)
elif mode == 2: IPTV(url)
elif mode == 3: PLAY(url, name)
elif mode == 4: SEARCHLINKS(url)
elif mode == 5: OPENSETTINGS()

