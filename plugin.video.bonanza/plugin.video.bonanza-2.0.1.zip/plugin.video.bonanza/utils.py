import xbmc
import xbmcgui
import xbmcaddon
import threading

this_addon = xbmcaddon.Addon()
addon_id = this_addon.getAddonInfo('id')
addon_name = this_addon.getAddonInfo('name')

DEFAULT_HTTP_HEADERS = {
    'User-Agent': "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
    ,'Accept-Encoding': 'gzip,deflate'
    }

def Log(msg='', loglevel=None):
    try: debug = (this_addon.getSetting('debug').lower() == "true")
    except: debug = True
    msg = addon_id + ": " + msg
    if loglevel: xbmc.log(msg , loglevel)
    elif debug:  xbmc.log(msg , xbmc.LOGNONE)
    else:        xbmc.log(msg)

def Notify(msg, duration=5000, icon="", title=addon_name):
    Log( str(msg), xbmc.LOGNOTICE)
    if threading.current_thread().name == "MainThread":
        xbmcgui.Dialog().notification(title, msg, icon, duration, sound=False )

def Header2pipestring(header=DEFAULT_HTTP_HEADERS):
    q = "|{}".format( repr(header) )
    q = q.replace( "{'", "")
    q = q.replace( "'}", "")
    q = q.replace( "': '", "=" )
    q = q.replace( "', '", "&" )
    return q

# Modified `sleep` command that honors a user exit request
def Sleep (time):
    while time > 0 and not xbmc.abortRequested:
        xbmc.sleep( min(1000, time) )
        time = time - 1000
