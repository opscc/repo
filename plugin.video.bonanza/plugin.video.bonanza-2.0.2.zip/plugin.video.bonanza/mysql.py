try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database
import xbmcvfs
import time
import xbmcaddon
import os
import xbmc

from utils import Log as log

class MySQL:

    def __init__(self):
        self.getConstants()
        self.db_create()
        
    def getConstants(self):
        self.dataPath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
        self.providercacheFile = os.path.join(self.dataPath, 'iptvlinks.13.db')
        
    def db_create(self):
        xbmcvfs.mkdir(self.dataPath)
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.cursor()
        db_cursor.execute("CREATE TABLE IF NOT EXISTS table_metadata (""info TEXT PRIMARY KEY, ""val TEXT);")
        db_cursor.execute("CREATE TABLE IF NOT EXISTS table_urls (""source_url TEXT, ""url TEXT, ""name TEXT, ""favourited BOOLEAN,  ""date_added TEXT,  ""link_status TEXT, ""date_checked TEXT);")
        db_cursor.execute("CREATE TABLE IF NOT EXISTS table_sources (""url TEXT PRIMARY KEY, ""name TEXT,  ""date_added TEXT );")
        db_connection.commit()
        
    def validate_data(self, data, required_type=None):
        #todo: clean out special characters/commands in data
        return data

    def db_clean_old(self, older_than_days=3  ):
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.cursor()
        delete_from_time =  str (time.time() - 60*60*24*older_than_days )
        #log(delete_from_time)
        db_cursor.execute("DELETE FROM table_sources WHERE date_added < {}".format(delete_from_time) )
        db_cursor.execute("DELETE FROM table_urls    WHERE date_added < {}".format(delete_from_time) )
        log ("db_clean_old deleted {} rows older than {} days".format(db_cursor.rowcount, older_than_days ), xbmc.LOGNOTICE)
        db_cursor.execute("REPLACE INTO table_metadata(info,val) VALUES ( 'last_clean_date', '{}' )".format(delete_from_time) )
        db_connection.commit()
        db_cursor.execute("vacuum")
        db_connection.commit()        
        
    def db_source_add(self, url, name, date_added=time.time()  ):

        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.cursor()

        url = unicode(url, 'utf-8', 'ignore')
        name = unicode(name, 'utf-8', 'ignore')
        
        db_cursor.execute("REPLACE INTO table_sources VALUES (?, ?, ?)", (url, name, date_added ) )
        db_connection.commit()
        
##        return
##        db_cursor.execute("SELECT * FROM table_sources WHERE url = '%s'" % (url) )
##        match = db_cursor.fetchone()
##        if match:
##            log("url will be deleted{}".format(match) )
##            db_cursor.execute("DELETE FROM table_sources WHERE url = '%s' " % (url) )
##
##        db_cursor.execute("INSERT INTO table_sources Values (?, ?, ?)", (url, name, date_added ) )
##
##        db_connection.commit()
##
##        if (addon.getSetting('debug').lower() == "true"):
##            db_cursor.execute("SELECT * FROM table_sources WHERE url = '%s' " % (url) )
##            match = db_cursor.fetchone()
##            if match:
##                log("url '{}' inserted".format(match) )

    
    def db_link_add(self, source_url, url, name, favorite=False, date_added=time.time(), link_status=None, date_checked=None):

        #log("url '{}' inserted".format(source_url) )

        db_connection = database.connect(self.providercacheFile)
        #db_connection.text_factory = lambda x: unicode(x, 'utf-8', 'ignore')
        name=unicode(name, 'utf-8', 'ignore')
        
        db_cursor = db_connection.cursor()

        #db_cursor.execute("SELECT * FROM table_urls WHERE source_url = '%s' AND url = '%s'" % (source_url, url) )
        #match = db_cursor.fetchone()
        #if match:
        #    #log("url will be deleted{}".format(match) )
        #    db_cursor.execute("DELETE FROM table_urls WHERE source_url = '%s' AND url = '%s' " % (source_url, url) )
       
        db_cursor.execute("INSERT INTO table_urls Values (?, ?, ?, ?, ?, ?, ?)", (source_url, url, name, favorite, date_added, link_status, date_checked) )

        db_connection.commit()

##        if (addon.getSetting('debug').lower() == "true"):
##            db_cursor.execute("SELECT * FROM table_urls WHERE source_url = '%s' AND url = '%s' " % (source_url, url) )
##            match = db_cursor.fetchone()
##            if match: log("url '{}' inserted".format(match) )

    def db_link_delete(self, url):
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.cursor()
        #log("url will be deleted:'{}'".format(url) )
        db_cursor.execute("DELETE FROM table_urls WHERE url = '{}' ".format(url) )
        log ("deleted {} rows".format(db_cursor.rowcount ))
        db_connection.commit()

    def db_link_update_date_checked(self, url):
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.cursor()
        #log("url will be db_link_update_date_checked:'{}'".format(url) )
        db_cursor.execute("UPDATE table_urls SET date_checked = '{}' WHERE url = '{}' ".format(time.time(), url)    )
        log ("updated {} rows".format(db_cursor.rowcount ))
        db_connection.commit()

    def db_link_getmatchingnames(self, name, source_url='%', only_date_unchecked=False):
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.cursor()
        names = name.split(',') if name else []
        search_string = ""
        for single_name in names:
            search_string = search_string + " OR name LIKE '%{}%' ".format(single_name)
        if only_date_unchecked == True:  only_unchecked_string = " AND date_checked IS NULL "
        else:                            only_unchecked_string = ""
        search_string2 = "SELECT DISTINCT '', url, name FROM table_urls WHERE (name LIKE '%{}%' {} ) and source_url LIKE '{}' {}".format(name, search_string, source_url, only_unchecked_string)
        log (search_string2)
        db_cursor.execute( search_string2 )
        return db_cursor.fetchall()
        
    def db_link_urls_from_source(self, source_url):
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.cursor()
        db_cursor.execute("SELECT * FROM table_urls WHERE source_url = '%s'" % (source_url) )
        return db_cursor.fetchall()

    def db_source_indexed(self, source_url):
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.cursor()
        db_cursor.execute("SELECT * FROM table_sources WHERE url = '%s'" % (source_url) )
        match = db_cursor.fetchone()
        if match: return True
        else:     return False

    def db_link_add_bulk(self, listarray, source_url):
        db_connection = database.connect(self.providercacheFile)
        db_connection.execute("DELETE FROM table_urls WHERE source_url = '{}' ".format(source_url) )

        source_url=unicode(source_url, 'utf-8', 'ignore')
        db_cursor = db_connection.executemany("INSERT INTO table_urls (name,url,source_url,date_added) Values (?, ?, ?, ?)", UrlListSanitizer(listarray, source_url, time.time() ) )
        db_connection.commit()
        log ("db_link_add_bulk inserted {} rows".format(db_cursor.rowcount ))

    def db_get_last_clean_date(self):
        #log('db_get_last_clean_date')
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.execute("SELECT val FROM table_metadata WHERE info = 'last_clean_date' " )
        match = db_cursor.fetchone()
        if match: return float(match[0])
        else:     return time.time()

    def delete_non_stream_links(self, source_url="%"):
        db_connection = database.connect(self.providercacheFile)
        db_cursor = db_connection.execute("DELETE FROM table_urls WHERE source_url LIKE '{}' AND (url LIKE '%.mp4_' OR url LIKE '%.mkv_' OR url LIKE '%.avi_' OR url LIKE '%.mp4' OR url LIKE '%.mkv' OR url LIKE '%.avi') ".format(source_url) )
        db_connection.commit()
        log ("delete_non_stream_links deleted {} rows".format(db_cursor.rowcount ))
        
class UrlListSanitizer:
    def __init__(self, thelist, source_url,date_added):
        self.count = 0
        self.thelist = thelist
        self.maxlength = len(thelist) - 1
        #log(" length  {}".format(self.maxlength))
        self.date_added = date_added
        self.source_url = source_url
    def __iter__(self):
        return self
    def next(self):
        if self.count > self.maxlength:
            raise StopIteration
        name = self.thelist[(self.count)][0]
        url = self.thelist[(self.count)][1]
        source_url = self.source_url
        date_added = self.date_added
        name = unicode(name, 'utf-8', 'ignore')
        url = unicode(url, 'utf-8', 'ignore')
        self.count += 1
        return ( name, url, source_url, date_added) 
    

#msq = MySQL()
#import random
#msq.db_source_add('url'+str(random.random()), 'name'+str(random.random()) )
#msq.db_clean_old(0)
#log( repr( msq.db_link_getmatchingnames('testurl%') ) )
#msq.db_link_add('url', 'testurlname')
#msq.db_link_add('url2', 'testurlname2', True)
#msq.db_link_add('url3', 'testurlname3', True, time.ctime(), 'online', time.ctime() )
