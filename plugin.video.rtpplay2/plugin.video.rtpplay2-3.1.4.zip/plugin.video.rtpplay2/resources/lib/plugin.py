# -*- coding: utf-8 -*-



import xbmc
import xbmcgui

import inputstreamhelper
import urllib

import urllib2

import routing
import logging
import requests
import re
import xbmcaddon
import json

from sys import exit, version_info
from resources.lib import kodiutils
from resources.lib import kodilogging
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl


ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))
kodilogging.config()
plugin = routing.Plugin()


PROTOCOL = 'mpd'
DRM = 'com.widevine.alpha'
#STREAM_URL = 'https://demo.unified-streaming.com/video/tears-of-steel/tears-of-steel-dash-widevine.ism/.mpd'
#LICENSE_URL = 'https://cwip-shaka-proxy.appspot.com/no_auth'


__headers__ = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"}
__base_url__ = "http://www.rtp.pt"
__session__ = requests.Session()

TVI_BASE = "http://tviplayer.iol.pt"

if version_info >= (3, 0):
	from html.parser import HTMLParser
else:
	from HTMLParser import HTMLParser
html_parser = HTMLParser()



        

def addTVIIcons(plugin):
        
        try:
		req = __session__.get(TVI_BASE+ "/direto").text
        except Exception, e:
                notify("getting TVI main page", str(e), 4000) 
        
        
        match=re.compile('class="direto-canal-box videoUpdate" data-canal="(.+?)"\W*<a href="(.+?)".+img src="(.+?)"[\w\W]*?link-programa">\s+(.+?)\W*<\/a>').findall(req)       
        if match:
                for channel,rel_url,img,prog in match:
                        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                        liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                        liz.setProperty('IsPlayable', 'true')
                        liz.setInfo("Video", infoLabels={"plot": prog})
                        finalurl=TVI_BASE+rel_url
                        addDirectoryItem(plugin.handle, plugin.url_for(play
                                                                       , rel_url=kodiutils.smart_str(finalurl)
                                                                       , channel=kodiutils.smart_str(channel)
                                                                       , img=kodiutils.smart_str(img)
                                                                       , prog=kodiutils.smart_str(prog) ), liz, False)


def addTVIIcon(plugin):
        try:
		req = __session__.get("http://tviplayer.iol.pt/direto/TVI").text
        except Exception, e:
                notify("getting TVI main page", str(e), 4000) 
        channel = "TVI"
        prog = "TVI"
        match=re.compile('videoUrl = "(.+?)"').findall(req)
       
        if match:
                i=0
                for rel_url in match:
                        i=i+1
                        #four urls are found, just use the last one
                        finalurl=rel_url

                liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(i)))
                img = "http://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/58ab3cae0cf2b10cb661350e"
                liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                liz.setProperty('IsPlayable', 'true')
                liz.setInfo("Video", infoLabels={"plot": i})
                addDirectoryItem(plugin.handle, plugin.url_for(play
                                                               , rel_url=kodiutils.smart_str(finalurl)
                                                               , channel=kodiutils.smart_str(prog)
                                                               , img=kodiutils.smart_str(img)
                                                               , prog=kodiutils.smart_str(prog) ), liz, False)
                        
                
def addTVI24Icon(plugin):
        try:
		req = __session__.get("http://tviplayer.iol.pt/direto/TVI24").text
        except Exception, e:
                notify("getting TVI main page", str(e), 4000) 
        channel = "TVI24"
        prog = "TVI24"
        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
        match=re.compile('videoUrl = "(.+?)"').findall(req)
        if match:
                for rel_url in match:
                        img = "http://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/58ab3cc20cf2b10cb6613516"
                        liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                        liz.setProperty('IsPlayable', 'true')
                        liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
                        addDirectoryItem(plugin.handle, plugin.url_for(play, rel_url=kodiutils.smart_str(rel_url), channel=kodiutils.smart_str(channel), img=kodiutils.smart_str(img), prog=kodiutils.smart_str(prog) ), liz, False)
                        break

        

def addFatimaIcon(plugin):
        try:
		req = __session__.get("http://www.fatima.pt/en/pages/online-transmissions").text
        except Exception, e:
                kodiutils.ok(str(e),"getting fatima page")
        channel = "Fatima"
        prog = "Fatima"
        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
        match=re.compile('<iframe allowfullscreen="" frameborder="0" scrolling="no" src="http:.+file=(.+)&amp;[\w\W]+youtube\.com\/embed\/(\w+)').findall(req)
        if match:
                for rel_url,img in match:
                        rel_url = rel_url + "?all=1"
                        img = "https://i.ytimg.com/vi/" + img + "/maxresdefault_live.jpg"
                        liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                        liz.setProperty('IsPlayable', 'true')
                        liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
                        addDirectoryItem(plugin.handle, plugin.url_for(play, rel_url=kodiutils.smart_str(rel_url), channel=kodiutils.smart_str(channel), img=kodiutils.smart_str(img), prog=kodiutils.smart_str(prog) ), liz, False)
        

@plugin.route('/')
def index():

        try:
		req = __session__.get("http://www.rtp.pt/play/", headers=__headers__).text
	except:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32001))
		exit(0)
		
	match=re.compile('<a title=".+?direto (.+?)" href="(.+?)".+?img.+?src="(.+?)" class="img-responsive">.+?<span class="small"><b>(.+?)</b>').findall(req)
	if match:
                i = 0
		for channel ,rel_url ,img ,prog in match:
                        if i == 3:
                                addFatimaIcon(plugin)
                                #addTVI24Icon(plugin)
                                #addTVIIcon(plugin)
                                addTVIIcons(plugin)
                        
			liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
			if img.startswith("/"):
				img = "http:{}".format(img)
			
			liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
			liz.setProperty('IsPlayable', 'true')
			liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
			
			addDirectoryItem(plugin.handle, plugin.url_for(play, rel_url=kodiutils.smart_str(rel_url), channel=kodiutils.smart_str(channel), img=kodiutils.smart_str(img), prog=kodiutils.smart_str(prog) ), liz, False)
                        i = i + 1
                        
	endOfDirectory(plugin.handle)


@plugin.route('/play')
def play():
	rel_url = plugin.args["rel_url"][0]
	channel = plugin.args["channel"][0]
	prog = plugin.args["prog"][0]
	icon = plugin.args["img"][0]


        #notify("TVI", prog, 1000)
        #notify("TVI", channel, 1000)
        if channel.startswith('TVI'):
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify("TVI", "parsing TVI page", 1000)
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify("TVI", rel_url, 1000)
                req = __session__.get(rel_url).text
                match=re.compile('videoUrl = "(.+?)"').findall(req)
                for rel_url in match:
                        #four urls are found, just use the last one
                        final_stream_url=rel_url

                #this is an m3u8 file, force the slowest stream
                req = __session__.get(final_stream_url, verify=False).text
                pattern = '#EXT-X-STREAM-INF:BANDWIDTH=(\d+?),.*\\n(.+?)\\n'
                streams = re.findall(pattern, req)
                if streams:
                    
                    if kodiutils.get_setting_as_bool("debug"):
                        notify("TVI", "streamsfound", 1000)
                    best = 9999999
                    best = 9
                    for bandwidth, stream_url in streams:
                        if kodiutils.get_setting_as_bool("debug"):
                                notify("bandwidth", str(bandwidth), 5000)
                        if int(bandwidth) > best:
                            best = int(bandwidth)
                            playurl = stream_url

                match=re.compile('(http[sS]?:[\/]{2}.*?)(\/.*)').findall(final_stream_url)
                for baseURL, relURL in match:
                        playurl = baseURL + "/" + playurl

                if kodiutils.get_setting_as_bool("debug"):
                        notify("TVI", playurl, 10000)
                xbmc.log(playurl)
                final_stream_url = playurl

                liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                liz.setArt({"thumb": icon, "icon": icon})
                #liz.setProperty('IsPlayable', 'true')
                #liz.setProperty('IsFolder', 'false')
                liz.setPath("{}|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url))


                #liz.setPath("{}|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url.split('?')[0]))
                #liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                #liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
                #liz.setProperty('inputstream.adaptive.license_key', '|' + final_stream_url.split('?')[1] + '||')
                
##                is_helper = inputstreamhelper.Helper('hls')
##                liz = ListItem()
##                liz.setPath("{}|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url))
##                liz.setArt({"thumb": icon, "icon": icon})
##                liz.setProperty('inputstreamaddon', is_helper.inputstream_addon)
##                liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
##                liz.setProperty('inputstream.adaptive.license_key', '||||')

                setResolvedUrl(plugin.handle, True, liz)
                exit(0)
                
        
        if prog == "Fatima":
                try:
                        #kodiutils.ok("Debug:" + rel_url, "Fatima")
                        match=re.compile('(http[sS]?:[\/]{2}.*?)(\/.*)').findall(rel_url)
                        if match:
                                #kodiutils.ok("Debug:" + repr(match[0]), "match[0]")
                                for baseURL, relURL in match:
                                        #req = __session__.get("{}{}".format(baseURL, relURL).text
                                        #kodiutils.ok("Debug:" + baseURL, "baseURL")
                                        #kodiutils.ok("Debug:" + relURL, "relURL")
                                        #req = __session__.get("{}{}".format("http://rd3.videos.sapo.pt", "/v6Lza88afnReWzVdAQap/mov/24?all=1")).text
                                        req = __session__.get("{}{}".format(baseURL, relURL)).text
                                        d = json.loads(req)
                                        #kodiutils.ok(d['hls'],"json hls string")
                                        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                                        liz.setArt({"thumb": icon, "icon": icon})
                                        liz.setPath("{}".format(d['hls']))

                                        liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                                        liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
                                        
                                        setResolvedUrl(plugin.handle, True, liz)
                                        exit(0)
                except Exception, e:
                        kodiutils.ok(str(e),"unknown error playing " + prog)
                        exit(1)

                exit(0)



        
        if prog == "TVI24":
                try:
                        if kodiutils.get_setting_as_bool("debug"):
                                notify("TVI24 play", "playing" + rel_url, 1000)
                        liz = ListItem(path=rel_url)
                        liz.setArt({"thumb": icon, "icon": icon})
                        setResolvedUrl(plugin.handle, True, liz)
                        exit(0)
                except Exception, e:
                        kodiutils.ok(str(e),"unknown error playing " + prog)
                        exit(1)
                exit(0)

        if prog == "TVI":
                try:
                        if kodiutils.get_setting_as_bool("debug"):
                                notify("TVI play", "playing" + rel_url, 1000)
                        liz = ListItem(path=rel_url)
                        liz.setArt({"thumb": icon, "icon": icon})
                        setResolvedUrl(plugin.handle, True, liz)
                        exit(0)
                except Exception, e:
                        kodiutils.ok(str(e),"unknown error playing " + prog)
                        exit(1)
                exit(0)
                


	try:
		req = __session__.get("{}{}".format(__base_url__, rel_url)).text
	except:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
		exit(0)

	is_pseudo_aes = bool(re.findall("var aes = true", req))
		
	streams = ''
	final_stream_url = ''
        #streams = re.compile('new RTPPlayer\([\w\W]*file\:.+?"(.+?)"', re.DOTALL).findall(req)
        #streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?file\:.+?"(.+?)"', re.DOTALL).findall(req)
        #regex working 2018-04-15 to 2018-05-03
        streams = re.compile('dash\:"(.+?)"', re.DOTALL).findall(req)
        #regex working 2018-05-07 to 2018-?
        streams = re.compile('k\: \'(.+?)\'[\w\W]*dash\:"(.+?)"', re.DOTALL).findall(req)
	if streams:
		final_stream_url = None
		for key,stream in streams:
                        final_stream_url = stream
                        encryptionkey = key
                        xbmc.log(encryptionkey,xbmc.LOGNONE)
                        #if kodiutils.get_setting_as_bool("debug"):
                                #kodiutils.ok("Debug:" + "final_stream_url", final_stream_url)
			if ".mpd" in stream.split('/')[-1]: 
                                if  final_stream_url.endswith('?DVR'):
                                        final_stream_url = final_stream_url[:-4]
				break
			else:
                                final_stream_url = None #not MPD
        #final_stream_url = None #debugging

        PROTOCOL = 'mpd'
        DRM = 'com.widevine.alpha'

        
        if final_stream_url:
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify('Progress....',final_stream_url, 5000)                
                PROTOCOL = 'mpd'
                DRM = 'com.widevine.alpha'
                is_helper = inputstreamhelper.Helper(PROTOCOL)
                
                if is_helper.check_inputstream():
                        #https://github.com/peak3d/inputstream.adaptive/wiki/Playing-multi-bitrate-stream-from-a-python-addon
                        liz = ListItem(path=final_stream_url)
                        #liz.setPath("{}|Connection=keep-alive&Origin=https://www.rtp.pt&User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; WOW64; Trident/4.0; SLCC1)&Accept=*/*&Referer=https://www.rtp.pt/play/direto/rtp1&Accept-Encoding=gzip, deflate, br".format(final_stream_url))

                        liz.setArt({"thumb": icon, "icon": icon})
                        # worked before 2018-05-04
                        liz.setProperty('inputstreamaddon', is_helper.inputstream_addon)
                        #liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                        liz.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                        #setResolvedUrl(plugin.handle, True, liz)
                        #exit(0)
                        # worked 2018-05-04 to 2018-05-04
                        liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                        liz.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                        liz.setProperty('inputstream.adaptive.license_type', DRM)
                        #liz.setContentLookup(False)
                        LICENSE_URL = ''
                        LICENSE_URL = 'http://widevine-proxy.drm.technology/proxy'
                        #LICENSE_URL = 'https://widevine-proxy.drm.technology/proxy'
                        #LICENSE_URL = '"B{SSM}"'
                        SPECIAL_HEADERS = '|' #none required
                        POST_DATA = '|' #none required
                        POST_RESPONSE = '|' #none required
                        #POST_RESPONSE = '|J[licensetoken]'

                        # worked 2018-05-?? to 2018-??
                        SPECIAL_HEADERS = '|Content-Type=application/json'
                        #SPECIAL_HEADERS = '|Content-Type=application/json&User-Agent=Mozilla/6.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36&Referer=https://www.rtp.pt/play/direto/rtp1&Connection=keep-alive&Origin=https://www.rtp.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en'
                        SPECIAL_HEADERS = '|Content-Type=application/json&User-Agent=Mozilla/6.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36&Referer=https://www.rtp.pt/play/direto/rtp1&Origin=https://www.rtp.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en'
                        my_json_string = json.dumps({"token": encryptionkey, "drm_info":[8,4], "kid":"E13506F7-439B-EAE7-DDF0-489FCDDF7481"})
                        POST_DATA = '|' + urllib.quote_plus(my_json_string)
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[D{SSM}],"kid":"{KID}"}' % my_json_string)
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[8,4],"kid":"{KID}"}' % my_json_string)
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[b{SSM}],"kid":"{KID}"}' % encryptionkey)
                        #POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[8,4],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % encryptionkey)
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[8,4],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % encryptionkey)
                        #POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[8,1,18,187,34,18,92,10,90,10,68,8,1,18,16,154,196,52,232,105,14,94,124,184,179,237,146,171,38,211,249,26,6,118,117,97,108,116,111,34,32,55,67,53,69,55,70,57,49,49,70,55,57,50,70,50,49,66,69,53,70,69,57,66,67,57,49,57,51,67,51,51,66,42,2,72,68,50,0,16,1,26,16,200,35,12,140,82,127,155,202,160,152,251,189,239,213,252,22,24,1,32,188,178,215,215,5,48,21,66,208,33,10,20,108,105,99,101,110,115,101,46,119,105,100,101,118,105,110,101,46,99,111,109,18,16,23,5,185,23,204,18,4,134,139,6,51,58,47,119,42,140,26,144,31,142,207,120,33,9,237,49,115,73,219,104,126,239,179,107,99,151,250,79,243,170,185,227,150,83,192,84,36,64,60,242,226,225,117,43,111,16,138,69,216,139,14,154,205,247,122,123,157,67,75,184,42,26,212,4,197,173,120,222,170,16,97,15,252,9,25,220,222,128,150,118,214,213,201,42,109,241,118,27,92,206,110,130,177,94,170,32,165,185,98,156,255,55,36,226,217,174,34,253,63,112,98,160,42,26,229,102,207,139,92,251,253,145,143,1,87,151,43,156,94,208,131,25,194,93,95,57,186,125,133,255,197,93,154,183,233,45,14,209,5,203,71,155,33,149,137,255,211,72,242,138,15,196,33,240,55,22,122,172,77,96,246,120,251,215,206,201,45,135,198,67,154,232,37,210,30,183,111,97,15,37,192,66,163,92,188,94,220,99,115,196,79,139,39,137,43,252,227,135,6,212,26,121,78,187,132,54,146,199,114,21,26,235,118,37,40,20,84,138,233,177,57,12,75,1,214,137,222,195,226,48,186,16,151,3,236,32,38,245,86,203,91,105,35,201,0,38,243,150,0,252,151,72,111,200,247,59,106,149,16,170,75,169,109,65,29,85,239,86,171,128,204,87,235,99,210,156,172,222,178,10,74,160,13,13,31,243,160,164,118,122,176,61,106,135,105,142,107,18,121,229,12,23,254,159,37,151,102,37,163,129,42,151,103,46,189,43,25,5,173,221,127,167,147,186,170,80,109,237,7,191,48,249,99,211,177,33,160,158,222,110,99,234,155,89,194,168,127,158,251,217,160,233,40,238,173,18,54,213,169,183,219,113,168,43,198,72,37,146,233,186,133,85,54,158,66,82,106,74,95,160,220,29,228,147,149,77,217,170,60,113,109,199,207,47,48,129,0,106,95,226,114,144,135,97,58,118,250,2,30,241,181,115,91,127,15,172,75,178,45,10,249,230,0,145,83,62,206,32,228,249,60,186,180,250,94,81,102,189,148,44,18,132,198,193,39,72,82,141,148,22,185,113,5,137,235,137,68,81,84,140,141,117,216,228,224,125,127,149,72,186,35,43,50,193,235,67,119,194,174,227,162,91,29,69,121,233,50,41,255,111,1,174,252,61,144,65,177,191,17,202,32,149,76,225,83,43,51,80,4,254,200,165,29,141,21,48,168,80,77,34,161,196,76,96,233,50,152,70,11,173,115,84,142,64,210,68,78,74,38,129,223,37,165,244,142,240,32,231,93,238,252,184,29,14,106,100,34,203,61,179,118,78,53,172,235,140,102,235,158,172,249,123,50,6,113,230,82,196,89,72,197,58,152,211,237,176,16,131,125,145,140,102,161,64,155,133,246,122,113,28,104,56,158,145,16,161,255,230,92,126,109,148,75,237,62,50,221,114,78,9,28,201,255,143,250,216,79,24,151,9,81,233,104,186,122,34,244,94,222,201,115,247,169,177,227,26,227,246,243,129,250,22,189,147,203,246,159,56,160,173,202,174,198,188,144,65,96,23,42,188,196,135,201,213,32,219,74,149,62,46,62,156,64,89,240,164,134,248,71,218,95,184,227,82,1,71,17,132,72,232,184,29,248,152,244,90,138,211,232,48,204,186,3,236,3,172,10,8,74,45,51,162,229,86,67,32,14,5,126,85,206,96,10,55,80,224,162,179,106,103,30,194,176,64,138,101,26,128,197,81,60,40,15,241,31,48,1,26,39,223,104,171,120,98,89,173,74,94,81,99,34,26,161,246,56,204,151,151,177,186,5,20,240,97,193,91,67,93,14,3,161,181,90,104,196,46,186,184,41,61,140,94,51,192,113,251,127,119,11,137,145,120,79,95,220,78,50,77,209,101,67,9,139,210,9,228,234,35,104,198,5,211,159,15,119,241,129,167,210,223,197,3,217,50,247,233,231,111,147,126,29,8,208,95,42,217,46,61,81,82,154,130,136,239,127,160,195,178,63,92,21,207,255,252,239,220,51,84,123,129,235,139,12,35,170,180,99,41,170,133,37,122,63,90,156,15,112,115,51,116,120,125,151,95,114,166,55,5,27,228,230,54,220,72,24,90,147,129,61,164,123,216,112,86,57,145,70,254,157,62,58,35,170,26,180,25,237,44,137,137,116,106,51,225,114,175,147,222,11,248,152,132,187,23,239,86,183,248,114,32,161,236,220,53,128,201,216,139,133,194,138,157,181,33,247,58,78,63,12,29,169,42,19,91,146,97,76,173,90,217,235,233,94,33,248,185,58,251,9,149,19,248,103,57,43,220,33,197,84,101,38,91,144,104,231,210,212,252,88,64,135,145,248,213,43,26,209,165,197,53,234,178,195,130,38,71,61,243,77,217,132,32,140,244,98,151,222,255,18,252,35,8,69,132,102,215,120,95,61,54,209,84,149,141,227,29,13,160,154,231,127,254,22,19,185,80,58,94,198,174,136,225,26,0,18,144,186,114,75,8,8,207,4,56,98,204,96,183,79,155,157,193,138,210,209,240,72,52,182,112,135,213,188,244,207,43,48,129,230,18,41,69,227,194,149,35,197,85,75,121,30,249,0,201,6,187,138,245,32,211,19,27,58,133,15,213,223,51,173,162,121,140,51,232,199,160,131,187,64,207,159,217,27,52,167,217,62,205,195,26,162,110,149,182,169,190,21,89,171,216,228,134,200,113,247,187,246,82,152,73,191,70,165,13,208,41,38,25,215,149,172,248,157,14,10,49,153,88,174,217,29,250,90,238,126,152,119,206,186,191,75,58,41,150,219,240,214,148,214,53,117,106,204,93,178,131,16,174,97,241,151,12,197,142,194,253,54,146,181,129,65,186,130,4,195,31,9,105,75,71,213,125,219,3,236,246,198,191,142,94,230,48,222,41,213,233,85,132,74,141,46,122,66,246,155,10,101,80,77,14,20,204,236,32,178,23,207,196,217,29,90,49,20,121,179,131,69,143,45,65,105,34,189,197,55,170,167,57,109,188,103,20,122,63,244,67,41,252,102,176,142,89,18,29,169,30,221,34,156,142,252,155,230,113,107,19,206,83,87,206,162,51,209,63,46,183,50,81,40,91,11,247,213,220,203,142,143,141,254,170,47,111,249,241,47,239,90,148,191,45,230,196,118,182,230,97,221,67,133,83,38,31,121,47,143,112,54,194,242,55,205,160,236,36,158,182,142,245,93,33,64,10,4,104,22,205,2,51,33,80,186,137,58,105,1,138,76,69,156,227,251,222,48,73,102,57,129,102,100,8,173,66,251,11,97,96,157,255,64,71,73,73,211,7,69,150,207,3,247,50,154,245,99,31,220,100,164,210,110,97,160,240,52,238,165,137,75,76,100,87,34,84,218,41,157,32,194,29,91,155,77,16,115,150,12,165,158,154,128,4,13,96,234,83,219,76,84,33,180,65,76,251,109,45,74,148,179,64,212,117,40,110,114,83,254,167,243,11,170,227,43,41,248,65,195,83,85,106,6,1,8,60,86,240,66,20,254,103,142,217,54,12,164,222,197,231,245,162,24,44,238,187,208,230,243,246,168,76,250,44,108,32,199,193,171,235,78,5,57,136,16,205,148,39,103,24,220,177,16,20,21,46,177,160,190,181,43,226,76,83,103,54,10,190,156,11,127,32,37,162,250,150,165,97,228,209,81,87,178,3,17,156,134,10,28,201,53,235,48,136,229,215,171,203,90,217,90,217,213,234,238,173,86,80,196,42,106,27,206,17,113,4,58,78,109,125,71,127,132,214,41,215,83,189,58,219,125,29,112,125,79,22,206,72,9,15,191,212,173,190,9,0,163,195,72,253,251,66,238,162,31,152,182,6,169,128,194,112,139,226,170,245,131,186,235,166,101,9,110,255,90,175,193,225,225,230,184,12,22,95,12,5,51,6,210,145,4,33,185,95,103,182,151,59,82,122,49,52,14,12,158,3,13,144,123,62,41,99,184,120,233,25,63,165,183,106,18,195,111,215,56,120,40,114,32,185,54,212,168,183,126,105,73,9,142,224,228,158,56,215,91,176,153,54,252,173,144,66,181,206,101,94,144,11,211,228,172,160,61,156,234,152,241,81,12,130,112,230,247,233,132,110,182,13,134,239,230,187,124,183,245,251,147,162,131,105,2,240,29,192,224,247,122,234,51,50,60,120,107,246,182,146,122,9,70,114,199,50,73,124,143,190,70,63,94,15,175,133,175,225,65,58,15,102,251,19,116,117,63,227,241,249,232,37,163,22,202,106,94,184,133,105,175,255,144,73,24,119,6,85,79,137,14,190,162,110,189,212,73,185,76,221,8,23,97,222,55,168,122,190,70,252,165,238,190,105,91,133,177,91,161,130,203,180,40,16,15,2,241,173,140,215,107,37,23,4,113,151,87,124,106,161,75,52,172,65,11,145,245,253,49,223,151,143,155,65,247,129,89,235,100,23,87,39,66,167,236,231,182,129,63,4,60,182,63,209,82,58,52,135,60,154,139,106,188,226,221,14,113,6,85,2,184,8,6,135,66,100,81,240,193,110,196,133,247,50,12,252,34,0,250,236,147,120,102,32,194,105,83,195,79,102,137,51,115,69,124,253,204,254,108,61,247,175,48,59,223,70,11,178,217,192,44,202,23,121,237,247,135,90,4,90,141,127,175,55,64,216,211,26,253,186,128,89,55,45,97,192,189,230,133,228,179,173,128,84,46,199,46,181,139,141,19,199,249,236,200,161,205,157,9,101,180,93,44,221,94,130,240,246,227,85,30,121,169,178,74,19,97,241,107,81,210,137,186,4,36,203,53,250,150,199,176,239,142,151,180,129,150,138,134,30,199,70,101,103,199,233,18,174,112,190,119,220,76,33,29,230,187,136,242,44,81,132,127,112,4,209,216,198,135,13,147,199,76,19,119,194,216,146,29,250,159,217,2,146,143,24,70,150,67,63,131,25,138,7,115,233,168,200,41,117,102,101,159,118,164,25,13,90,129,152,109,221,133,227,219,165,119,168,112,46,157,163,26,154,124,159,216,62,205,156,34,132,217,166,208,197,9,34,42,71,239,239,217,42,27,5,186,175,228,100,69,151,243,216,47,212,50,171,123,187,87,193,70,181,197,164,48,68,145,35,106,33,228,230,196,146,67,243,235,209,170,229,57,218,80,236,158,130,150,178,128,184,0,98,107,47,2,80,138,250,119,42,229,161,215,102,20,230,192,40,85,74,207,70,74,3,39,106,99,34,57,135,73,239,170,174,145,238,82,169,206,33,234,151,89,196,12,19,10,157,62,64,90,186,181,32,107,74,184,22,1,230,239,199,157,161,157,204,82,145,197,185,11,91,26,172,100,26,194,174,137,115,136,218,135,106,58,120,13,109,97,15,197,81,178,46,154,140,246,75,68,36,45,8,46,102,210,48,192,169,56,139,135,68,187,25,83,142,178,128,166,214,100,51,196,42,208,250,253,52,120,76,4,171,236,29,75,28,130,92,70,254,10,218,81,157,167,185,236,118,101,247,31,96,85,85,48,106,217,67,236,203,68,68,145,23,59,142,175,69,122,92,163,109,183,48,42,100,228,213,241,221,200,78,98,21,32,252,73,0,228,5,15,152,13,2,212,104,217,34,50,155,193,17,54,181,247,195,225,234,34,118,53,159,221,172,237,209,156,225,118,190,147,91,243,180,214,41,163,212,202,55,244,108,8,159,246,105,145,148,247,226,182,1,80,250,135,99,194,112,219,249,199,210,64,234,21,175,17,223,1,234,248,62,236,50,133,88,134,60,239,158,250,134,219,92,62,225,223,38,38,173,214,135,138,47,86,85,151,200,13,63,130,82,127,146,115,97,166,180,173,52,76,167,2,33,171,186,75,125,3,249,49,33,78,178,239,141,30,40,117,227,41,178,7,14,162,160,16,90,93,19,96,173,227,248,115,217,110,235,191,144,41,122,208,152,214,30,240,199,109,64,27,22,233,122,129,164,157,142,197,25,209,57,53,26,60,29,181,31,92,49,122,77,51,10,0,32,227,207,228,55,28,39,68,200,168,219,248,91,151,47,208,240,225,118,171,244,192,221,130,28,138,252,193,247,204,10,232,196,19,195,62,12,43,136,16,207,192,194,198,54,213,74,121,137,107,214,114,90,242,234,184,167,47,113,90,228,1,237,251,127,144,43,117,198,150,63,1,204,119,123,97,1,72,173,88,160,224,148,15,24,184,88,123,89,247,205,156,89,9,193,249,171,128,55,244,166,226,129,242,166,17,109,159,78,246,37,77,91,246,165,86,152,129,243,249,37,12,196,253,222,170,171,179,220,57,130,208,105,107,195,28,140,237,85,75,110,37,138,58,199,8,129,72,219,120,165,70,250,243,231,41,243,137,96,255,109,100,9,44,251,153,156,231,109,2,163,43,47,71,108,105,73,12,82,129,153,2,11,222,169,43,201,20,151,38,201,93,163,164,123,129,149,28,207,210,136,64,125,162,159,218,173,31,152,70,255,1,252,161,25,6,95,159,248,87,176,88,249,115,54,121,215,145,162,46,185,228,125,178,60,235,60,117,169,159,16,136,171,245,115,140,191,245,25,117,105,47,237,203,86,237,100,138,27,141,161,158,211,233,18,79,198,118,150,195,74,31,195,17,66,135,245,20,154,135,131,210,57,7,141,19,213,91,196,33,39,118,121,65,134,94,182,173,35,41,99,185,178,42,239,59,84,218,11,94,242,58,6,46,26,228,14,85,190,164,60,90,197,37,225,131,85,150,21,218,170,191,63,62,81,107,141,130,156,102,60,241,180,251,58,195,21,158,204,180,254,8,14,143,108,133,244,104,167,244,14,208,15,77,153,131,9,172,243,10,35,87,117,243,89,54,171,69,211,89,44,31,138,197,106,82,82,47,113,92,38,161,185,58,230,176,86,219,5,82,146,47,125,79,18,159,132,110,204,138,226,183,246,47,45,68,205,175,192,179,58,60,126,254,84,205,194,232,46,114,116,236,160,147,104,234,72,147,242,94,116,104,218,121,65,224,213,153,85,134,117,21,182,56,174,100,12,230,113,179,131,167,167,75,16,104,105,124,104,4,140,95,181,15,43,106,184,188,6,235,133,84,1,206,245,113,171,41,117,101,149,121,5,74,161,221,54,201,15,21,158,91,100,210,219,252,134,160,115,157,158,167,221,56,68,146,44,95,78,251,253,58,223,0,150,200,255,198,82,53,172,208,97,183,229,123,169,17,104,135,69,155,100,67,18,225,146,35,87,43,66,194,114,174,85,15,82,191,203,160,234,187,164,174,174,191,160,53,33,104,6,194,202,69,238,246,26,11,120,164,158,115,1,58,184,234,235,197,60,18,179,182,107,72,87,139,140,43,105,18,87,181,83,204,100,221,154,70,102,168,243,35,67,30,213,186,248,28,160,150,233,120,118,22,124,125,186,34,159,248,110,147,127,214,76,33,130,165,107,109,16,10,98,113,196,21,79,202,162,4,127,21,157,120,98,84,93,113,88,54,114,6,189,129,211,42,25,77,27,43,103,154,131,96,179,239,206,47,44,12,245,71,101,182,208,236,249,45,250,141,10,190,106,178,107,115,27,43,121,138,235,149,242,93,85,66,197,149,75,2,1,107,85,94,202,159,224,172,152,32,90,216,155,69,253,170,22,150,88,170,195,96,247,172,187,7,170,88,6,35,94,116,231,36,113,204,231,78,103,58,244,30,126,166,208,44,87,58,2,151,171,82,94,181,239,20,34,171,167,73,107,132,61,78,201,94,115,171,214,165,59,233,208,203,35,29,219,137,68,240,113,106,31,93,180,198,167,148,18,42,60,172,157,196,202,9,103,235,99,69,33,130,181,98,158,167,28,109,240,122,130,174,12,163,68,6,144,251,192,67,41,152,28,173,158,243,24,107,148,231,156,103,202,94,247,143,36,208,146,155,57,210,66,154,241,228,146,184,3,84,34,170,77,150,146,99,233,50,119,87,180,82,167,232,191,248,100,225,71,98,88,10,182,224,242,105,49,192,54,232,90,73,133,156,91,153,222,108,176,10,11,239,217,108,194,86,84,190,83,182,94,204,219,202,15,188,39,35,225,105,158,18,82,156,171,5,190,102,238,205,232,222,129,44,197,107,217,229,0,26,200,28,158,79,178,180,13,212,206,120,254,169,42,133,222,65,52,96,143,85,46,245,164,143,251,48,64,101,56,23,145,88,197,71,118,131,175,57,109,202,126,40,224,181,196,131,140,240,97,156,71,68,102,231,174,253,10,55,35,211,98,133,89,124,100,205,80,191,3,232,42,238,147,91,124,16,76,7,222,44,96,185,152,109,17,170,89,29,248,255,207,214,50,56,207,126,11,60,146,94,165,129,4,12,66,63,48,161,88,154,185,34,39,126,126,87,87,136,80,63,30,117,180,1,98,144,198,252,27,183,11,170,160,176,214,129,125,106,51,20,131,185,60,125,97,214,4,94,71,129,212,86,201,26,201,93,195,195,70,245,54,180,215,36,155,244,19,64,233,36,62,255,131,39,22,220,202,197,82,205,197,231,135,156,117,14,197,170,109,23,74,208,199,217,47,49,208,153,173,14,0,106,166,193,110,116,164,173,113,48,1,16,23,61,66,116,177,160,220,103,185,33,194,219,210,182,167,200,22,22,156,158,82,183,211,81,86,250,232,159,22,126,142,247,253,18,238,221,124,123,130,92,123,76,101,92,11,199,98,110,39,3,37,128,228,216,85,216,220,166,123,237,220,86,35,181,240,222,145,185,49,63,15,55,127,173,186,242,142,148,150,103,190,155,47,23,86,34,138,247,222,184,226,145,116,234,133,141,218,208,127,30,195,52,184,93,250,152,50,237,11,254,118,62,194,120,179,71,23,137,226,199,32,27,159,40,254,99,211,198,151,9,17,4,50,55,138,238,167,111,218,123,245,216,235,62,163,212,85,54,89,137,57,121,159,108,29,194,181,95,85,131,108,173,26,158,19,239,175,223,100,15,190,164,34,16,241,3,53,215,240,29,9,196,162,146,124,211,125,253,92,206,42,128,2,89,47,9,39,119,173,234,106,99,164,75,142,0,96,196,34,156,156,24,230,140,144,46,110,89,215,204,165,188,111,212,246,50,165,97,16,159,243,121,161,189,72,230,223,125,12,57,251,164,76,175,104,163,25,222,229,240,35,222,78,59,196,36,6,27,88,242,178,248,170,154,135,128,79,140,114,38,136,201,247,70,30,8,17,42,222,134,66,169,64,67,231,238,17,147,69,131,15,226,113,45,182,69,1,208,44,176,109,75,240,193,151,231,201,137,229,2,24,251,58,20,21,4,28,160,56,34,108,59,39,24,249,10,195,249,114,232,175,218,19,225,151,3,87,167,76,236,127,103,85,179,90,224,0,2,189,99,71,178,175,169,198,110,43,81,207,247,70,216,109,31,14,142,144,17,46,170,245,19,216,63,103,46,130,39,112,75,163,122,168,195,168,82,209,145,96,164,126,28,85,95,108,13,233,134,159,135,241,16,153,64,30,77,24,249,68,253,115,233,128,47,83,219,226,186,179,5,122,55,216,254,166,240,120,232,165,164,180,207,158,140,241,217,209,86,93,191,194,149,94,125,185,172,1,26,58,26,128,2,156,254,232,35,193,228,69,195,157,32,209,37,93,75,215,125,180,235,160,125,89,104,161,15,238,46,39,189,0,169,219,170,45,108,120,177,31,40,57,125,151,95,45,213,237,208,233,21,222,26,208,255,173,236,178,4,222,41,234,241,113,33,112,22,159,64,1,184,149,111,115,133,7,195,219,82,23,77,233,93,97,231,121,133,218,149,88,177,6,48,34,42,146,58,235,78,69,246,42,250,243,220,52,230,225,82,188,243,118,146,13,254,92,211,136,34,61,131,30,11,227,30,231,152,250,139,155,232,54,60,221,173,192,66,118,72,211,47,205,85,248,81,204,69,210,137,158,220,186,103,214,208,251,12,137,246,59,0,156,215,154,143,23,172,144,231,149,104,51,123,198,227,49,169,204,155,18,47,53,74,12,153,120,116,157,2,172,247,201,121,244,191,228,251,247,117,229,41,100,10,48,105,48,238,216,96,135,38,96,139,136,139,255,32,63,208,219,70,248,26,1,177,21,93,133,144,5,174,231,236,50,192,33,144,0,97,238,155,173,240,39,66,120,189,144,252,155,169,79,160,159,127,172,225,223,101],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % encryptionkey)
                        #POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[D{SSM}],"kid":"E13506F7-439B-EAE7-DDF0-489FCDDF7481"}' % encryptionkey)
                        #POST_DATA = '|' + my_json_string
                        drmresponse = LICENSE_URL + SPECIAL_HEADERS + POST_DATA + POST_RESPONSE
                        #POST_DATA = '|' + my_json_string
                        #drmresponse = LICENSE_URL + POST_DATA + POST_RESPONSE
                        xbmc.log(drmresponse,xbmc.LOGNONE)
                        liz.setMimeType('application/json')
                        liz.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                        #liz.setProperty('inputstream.adaptive.license_key', LICENSE_URL + '|||')
                        liz.setProperty('inputstream.adaptive.license_key', drmresponse)
                        #liz.setProperty('inputstream.adaptive.license_key', '')


                        try:
                                head = {"Connection": "keep-alive"
                                        ,"Access-Control-Request-Method": "POST"
                                        ,"Origin": "https://www.rtp.pt"
                                        ,"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
                                        ,"Access-Control-Request-Headers": "content-type"
                                        ,"Accept": "*/*"
                                        ,"Accept-Encoding": "gzip, deflate, br"
                                        ,"Accept-Language": "en-US,en;q=0.9"
                                        }
                                #conn = httplib.HTTPConnection('widevine-proxy.drm.technology')
                                #conn.request('OPTIONS', 'http://widevine-proxy.drm.technology/proxy')
                                #conn = httplib.HTTPConnection("localhost", 8888)
                                #conn.set_tunnel("widevine-proxy.drm.technology")
                                #conn.request("OPTIONS","/proxy")
                                #qq = conn.getresponse()
                                #opener = urllib.request.build_opener(urllib.HTTPHandler)
                                #request = urllib.request('http://widevine-proxy.drm.technology/proxy')
                                #request.get_method = lambda: 'OPTIONS'
                                #url = opener.open(request)
                                #opener = urllib2.build_opener(urllib2.HTTPHandler)
                                #request = urllib2.Request('http://widevine-proxy.drm.technology/proxy',None,head)
                                #request.add_header('Content-Type', 'your/contenttype')
                                #request.add_headers(head)
                                #request.get_method = lambda: 'OPTIONS'
                                #url = opener.open(request)

                                aa = requests.request('OPTIONS', LICENSE_URL,headers=head)

                                #aa = __session__.get(LICENSE_URL, headers=head).text
                        except Exception, e:
                                kodiutils.ok("getting fatima page",str(e))

                        #setResolvedUrl(plugin.handle, True, liz)
                        #exit(0)



        if kodiutils.get_setting_as_bool("debug"):
                notify('RTPPlay2','Couldn\'t find a DASH link. Using old method', 2000)
        #try old method below 
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?file\:.+?"(.+?)"', re.DOTALL).findall(req)
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(req)
        #streams = re.compile('file\:.+?"(.+?)"', re.DOTALL).findall(req)
        
	#print(req.encode('utf-8'))
	if streams:
		final_stream_url = None
		for stream in streams:
			if ".m3u8" in stream.split('/')[-1]: 
				final_stream_url = stream

	if "xxantena" in rel_url:
                kodiutils.ok('RTPPlay2',rel_url)
                streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?file\:.+?"(.+?)"', re.DOTALL).findall(req)
        	if streams:
                        final_stream_url = None
                        for stream in streams:
                                if ".m3u8" in stream.split('/')[-1]: 
                                        final_stream_url = stream


	if is_pseudo_aes:
		try:
			req = __session__.post("http://www.rtp.pt/services/playRequest.php", headers={"RTPPlayUrl":	final_stream_url})
			final_stream_url = req.headers["RTPPlayWW"]
		except:
			kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
			exit(0)		

	if final_stream_url:
		liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
		liz.setArt({"thumb": icon, "icon": icon})
		liz.setProperty('IsPlayable', 'true')

                if "antena" not in rel_url:
                        #kodiutils.ok('RTPPlay2','inputstreamaddon')
                        liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                        liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
                        #liz.setProperty('inputstream.adaptive.license_type', DRM)
		
		liz.setPath("{}|Referer=http://www.rtp.pt/play/&Range&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url))
                if kodiutils.get_setting_as_bool("debug"):
                        kodiutils.ok('RTPPlay2','about to run ' + final_stream_url)
                setResolvedUrl(plugin.handle, True, liz)        
		exit(0)
	else:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
		exit(0)

        

def notify(header=None, msg='', duration=5000):
    if header is None: header = 'RTP Play 2'
    builtin = "XBMC.Notification(%s,%s, %s)" % (header, msg, duration)
    xbmc.executebuiltin(builtin)


def run():
    plugin.run()
