#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

import urllib
import urllib2
import urllib3
import re
import resolveurl
import cookielib
import os.path
import sys
import time, datetime
import tempfile
import sqlite3
import urlparse
import base64
from StringIO import StringIO
import gzip
import traceback
import threading
import ssl
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import cloudflare
from jsunpack import unpack

#__________________________________________________________________________
#
def resolve_video(videosource, name, download=False, url=u'', description=u'', ask_which_file_hoster=False):

    assert isinstance(videosource, unicode)
    assert isinstance(name, unicode)
    assert isinstance(description, unicode)
    name = utils.cleantext(name)
    description = utils.cleantext(description)
    Log(u"{}".format(name))
    Log(u"{}".format(description))
    Log(
        u"resolver.resolve_video {},{},{},{},{}".format(
            "<bunchofhtml>"
            , name
            , download
            , url
            , description
            )
##            , xbmc.LOGNONE
        )

    Log('Searching videofile')

    hosts = []
    videourl = None

    if re.search('aparat\.cam/\w+/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('aparat.cam')
    if re.search('https?://wolfstream\.tv/\w+/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('wolfstream.tv')

        
    if re.search('https?://(?:www\.)?aparat\.com/(?:v/|video/video/embed/videohash/)(?P<id>[a-zA-Z0-9]+)', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('aparat.com')

    if re.search('\.ypncdn\.com/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('youporn')

    if re.search('watchxfree\.(?:eu|io|info|stream)?/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Watchxfree')

    if re.search(r'(?://|\.)(evoload\.io)/(?:e|f|v)/([0-9a-zA-Z]+)', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('evoload')

    if re.search('streamin\.to/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamin')

    if re.search('flashx\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('FlashX')

    if re.search('mega3x\.net/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Mega3X')

    if re.search('ksplayer\.com/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('ksplayer')

    if re.search('streamcloud\.eu/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('StreamCloud')

    if re.search('streamcloud\.eu/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('StreamCloud')

    if re.search('jetload\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Jetload')
    elif re.search('(https?://jetload\.net/p/\w+/\w+.mp4)', videosource, re.DOTALL | re.IGNORECASE):
#<a href="https://jetload.net/p/kMvD8XpbDjr5/m0sl13d2jzjw.mp4" 
        hosts.append('jetload.net')
        
    if re.search('videowood\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Videowood')
    if re.search('streamdefence.com/view\.php', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamdefence')
    if re.search('strdef.world', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamdefence')


    if re.search('dato\.?porn(?:\.co|)\/\S+', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Datoporn')
    elif re.search('dato\.porn/embed', videosource, re.DOTALL | re.IGNORECASE):
        #href="http://dato.porn/embed-mormjvwfymtn.html"
        hosts.append('Datoporn')


    regex = r'(?://|\.)(clipwatching\.com)/(?:embed-)?(\w+)'
    if re.search(regex, videosource, re.DOTALL | re.IGNORECASE):
##    if re.search('(https?://clipwatching\.com/\w+/\w+.mp4)', videosource, re.DOTALL | re.IGNORECASE):
#<a href="https://clipwatching.com/zgr8sgn3vl5m/d8wjqt9rnf88.mp4" rel="nofollow noopener noreferrer" target="_blank" class="external"><strong> Streaming From ClipWatching</strong></a> </br></p>
        Log('clipwatching')
        hosts.append('clipwatching')

##    if re.search('https?://gounlimited\.to/embed', videosource, re.DOTALL | re.IGNORECASE):
##        hosts.append('gounlimited')
##    elif re.search('https?://gounlimited\.to/.+?\.html', videosource, re.DOTALL | re.IGNORECASE):
##        hosts.append('gounlimited')
##    elif re.search('https?://gounlimited\.to/.+?"', videosource, re.DOTALL | re.IGNORECASE):
##        hosts.append('gounlimited')
        
    if re.search('zstream\.to/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('ZStream')


    if re.search(r'(?://|\.)(dood(?:stream)?\.(?:com|watch|to|la))/(?:d|e)/([0-9a-zA-Z]+)', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('doodstream')



    if re.search('rapidvideo\.com/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Rapidvideo')

    if re.search('vidlox\.(?:tv|me)/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Vidlox')

    if re.search('streamcherry\.com', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamcherry')

##    if re.search('streamango\.com\/embed\/', videosource, re.DOTALL | re.IGNORECASE):
##        hosts.append('Streamango')

    # src="https://mixdrop.to/e/7rk1d8r4ix9md4" width
    if re.search('https?://mixdrop\.(?:co|to|sx)/(?:e|f)/\w+', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('mixdrop')

    # src="https://mixdrop.to/e/7rk1d8r4ix9md4" width
    if re.search('https?://videobin\.(?:c|t)o/\w+/\w+', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('videobin')
        
    #https://streamtape.com/e/MxdKj4xYQximmW0
    #https://streamtape.com/v/vVamvAJ8brh4gxz/Susan_Ayn_2on1_Balls_Deep_Anal_DAP_Gapes_and_Creampie_Swallow_GIO1733_SD.mp4
    if re.search('https?://streamtape\.com/(?:e|v)/\w+', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('streamtape')

    if re.search('<source', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Direct Source')

    if not 'keeplinks' in url:
        if re.search('keeplinks\.eu/p', videosource, re.DOTALL | re.IGNORECASE):
            hosts.append('Keeplinks <--')

    if re.search('verystream.com/e/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('verystream')

    if re.search("\.vipporns\.com\/embed\/", videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('vipporns')

    #https://vidoza.net/embed-h3ntvh6xo4v4.html
    if re.search("((?:https:|http:)(?://|\.)vidoza\.net/(?:embed-|)[0-9a-zA-Z]+(?:\.html|))", videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('vidoza')

    if re.search('tubst\.net\/embed', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('tubst')

    Log("hosts='{}'".format(hosts))
    if len(hosts) == 0:
##        progress.close()
        utils.Notify('Oh oh','Couldn\'t find any video hoster')
        return
    elif len(hosts) > 1:
        #ask_which_file_hoster
        if ((C.addon.getSetting("ask_which_file_hoster") == "false")
            or ask_which_file_hoster==False):
            vidhost = hosts[0]
        else:
            vh = C.dialog.select('Videohost:', hosts)
            if vh == -1:
                return
            vidhost = hosts[vh]
    else:
        vidhost = hosts[0]


    if vidhost == 'jetload.net':
        Log("vidhost='{}'".format(vidhost), xbmc.LOGNONE)

        regex = '(https?://jetload\.net/p/\w+/\w+.mp4)'
        video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)[0]
        Log("video_url='{}'".format(video_url))

        video_source =utils.getHtml(video_url, referer=url)
        #Log("video_source='{}'".format(video_source))

        regex = "x_source = '([^']+)"
        video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_source)
        if video_url: video_url=video_url[0]
##        Log("video_url='{}'".format(video_url))

        return video_url

        videourl = video_url
        Log("videourl='{}'".format(videourl))

    elif vidhost == 'doodstream':
        dood_url = re.compile(r'((?://|\.)dood(?:stream)?\.(?:com|watch|to|la)/(?:d|e)/[0-9a-zA-Z]+)', re.DOTALL | re.IGNORECASE).findall(videosource)[0]
        Log("dood_url='{}'".format(repr(dood_url)))
        if dood_url.startswith('/'): dood_url = 'https:' + dood_url
        Log("dood_url='{}'".format(dood_url))
        dood_html =utils.getHtml(dood_url)
##        Log("dood_html='{}'".format(dood_html))
        dood_sources = re.search(r'''dsplayer\.hotkeys[^']+'([^']+).+?function\s*makePlay.+?return[^?]+([^"]+)''', dood_html, re.DOTALL)
        if not dood_sources:
            return
        
        token = dood_sources.group(2)
        Log("token='{}'".format(token))
        url2 = 'https://dood.to' + dood_sources.group(1)
        Log("url2='{}'".format(url2))
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = dood_url

        secondary_dood_html =utils.getHtml(url2, headers=headers)
##        Log("secondary_dood_html='{}'".format(secondary_dood_html))
        import string, random
        t = string.ascii_letters + string.digits
        third_dood_url = secondary_dood_html + ''.join([random.choice(t) for _ in range(10)])
        #Log("third_dood_url='{}'".format(third_dood_url))
        third_dood_url = third_dood_url + token + str(int(time.time() * 1000)) + utils.Header2pipestring(headers)
        #Log("third_dood_url='{}'".format(third_dood_url))
        
        videourl = third_dood_url
        
    elif vidhost == 'clipwatching':

#href="https://highstream.tv/embed-t30e0ckmj5q1.html"
        #regex = r'((?://|\.)clipwatching\.com/(?:embed-)?\w+)'
        regex = r'((?://|\.)(?:highstream\.tv|clipwatching\.com)/(?:embed-)?.+(?:.html))'
        clipwatching_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        Log(repr(clipwatching_url))
        if clipwatching_url:
            clipwatching_url = clipwatching_url[0]
            if clipwatching_url.startswith('/'): clipwatching_url = 'https:' + clipwatching_url
        else: clipwatching_url = ''
        Log(repr(clipwatching_url))

        video_url = resolveurl.resolve(clipwatching_url)

        return video_url 

##        clipwatching_url = re.compile('(https?://clipwatching\.com/\w+/\w+.mp4)', re.DOTALL | re.IGNORECASE).findall(videosource)[0]
##        if clipwatching_url.startswith('/'): clipwatching_url = 'https:' + clipwatching_url
##        Log("clipwatching_url='{}'".format(clipwatching_url))
##
##        clipwatching_source =utils.getHtml(clipwatching_url, referer=url)
##        Log("clipwatching_source='{}'".format(clipwatching_source))
##
##        clipwatching_url = re.compile('sources:\s+?\["([^\[]+)"\]', re.DOTALL | re.IGNORECASE).findall(clipwatching_source)[0]
##        Log("clipwatching_url='{}'".format(clipwatching_url))
##
##        videourl = clipwatching_url
##        Log("videourl='{}'".format(videourl))

    elif vidhost == 'videobin':


        regex = 'https?://videobin\.(?:c|t)o/\w+/\w+'
        new_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        if new_url:
            new_url = new_url[0]
        else:
            Log('new_url not found')
            return None
        new_source = utils.getHtml(new_url, referer=url)
##        Log("new_source='{}'".format(new_source))

        regex = 'sources:\s*(\[.+?\])'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(new_source)
        Log("sources_list='{}'".format(sources_list))
        if not sources_list:
            Log(regex)
            Log(videosource)
            return None
        else:
            sources_list = sources_list[0]
            

        regex = '(?:\["|,")(?P<url>[^"]+)"'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(sources_list)
        Log("sources_list='{}'".format(sources_list))
        if not sources_list:
            Log(regex)
            Log(sources_list)
            return None

##        list_key_value = {} ##[] #dict()
##        res = 240
##        for source_list in sources_list:
####            Log("dir(source_list={})".format(repr(dir(source_list))))
##            Log("source_list={}".format(repr( source_list.group()  )))
##            list_key_value[str(res)] = source_list.group('url')
##            res = res+120
##        Log("list_key_value={}".format(list_key_value))
##        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function

        list_key_value = list()
        res = 240
        for source_list in sources_list:
            Log("source_list={}".format(repr( source_list.group()  )))
            list_key_value.append(  (str(res), source_list.group('url')) )
            res = res+120
            #break

        Log("list_key_value={}".format(list_key_value))
        video_url = utils.SortVideos(sources=list_key_value,download=False,vid_res_column=0)

        #todo: sort by quality
        
        Log("video_url={}".format(video_url))
        
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = 'https://videobin.co/'
        video_url += utils.Header2pipestring(headers)
        Log("video_url={}".format(video_url))
        videourl = video_url
        
        
    elif vidhost == 'streamtape':
        try:
            video_url = None
            #https://streamtape.com/e/MxdKj4xYQximmW0 HTTP/1.1
            streamtape_url_f = re.compile("(https?://streamtape\.com\/(?:e|v)/\w+)", re.DOTALL | re.IGNORECASE).findall(videosource)[0]
            if streamtape_url_f.startswith('/'): streamtape_url_f = 'https:' + streamtape_url_f
            Log("streamtape_url_f='{}'".format(streamtape_url_f))

            streamtape_source = utils.getHtml(streamtape_url_f, referer=url)
            #Log("streamtape_source='{}'".format(mixdrop_source))

            regex = '<div id="videolink".+?>(.+?)&token=.+?(&token=.+?)\''
            video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(streamtape_source)
##            Log("video_url='{}'".format(repr(video_url)), xbmc.LOGNONE)
            video_url = video_url[0][0] + video_url[0][1] + "&stream=1"
            Log("video_url='{}'".format(video_url))

            if video_url.startswith('/'): video_url = 'https:' + video_url
            Log("video_url={}".format(video_url))

        except:
            Log("video_url='{}'".format(repr(video_url)), xbmc.LOGNONE)
            #traceback.print_exc()
            raise
##            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
            return

        #site wants this change as per testing/script inspection 2020-11-11
##        search_r = re.compile("(http:|https:)(^|\/\/)(.+?\/)")
##        replace_r = "https://streamtape.xyz/"
##        video_url = re.sub(search_r, replace_r, video_url)
##        Log("video_url={}".format(video_url))
##        streamtape_url_f = re.sub(search_r, replace_r, streamtape_url_f)
        Log("streamtape_url_f='{}'".format(streamtape_url_f))

##        streamtape_headers = { \
##                    "Accept-Encoding" : "identity;q=1, *;q=0" \
##                    , "Accept-Language" : "en-US,en;q=0.9" \
##                    , "User-Agent" : USER_AGENT \
##                    , "Connection" : "keep-alive" \
##                    , "Accept" : "*/*" \
##                    , "Referer" :  streamtape_url_f \
##                    , "Range" :  "bytes=0-" \
##                    }

        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = streamtape_url_f
        video_url += utils.Header2pipestring(headers)
        return video_url
    
##        video_url += utils.Header2pipestring(streamtape_headers)
##        Log("video_url={}".format(video_url))
##        return video_url
        
        
    elif vidhost == 'mixdrop':

        try: 
            mixdrop_url_f = re.compile("(https?://mixdrop\.(?:co|to|sx)/(?:e|f)/\w+)", re.DOTALL | re.IGNORECASE).findall(videosource)[0]
            if mixdrop_url_f.startswith('/'): mixdrop_url_f = 'https:' + mixdrop_url_f
            Log("mixdrop_url_f='{}'".format(mixdrop_url_f))

            mixdrop_source =utils.getHtml(mixdrop_url_f, referer=mixdrop_url_f)
            #Log("mixdrop_source='{}'".format(mixdrop_source))

            if "<h2>WE ARE SORRY</h2>" in mixdrop_source:
                utils.Notify(u"failed to find video url for {} via {}".format(name, vidhost))
                return

            try:
                #
                #maybe another intermediate source
                #
                #mixdrop_url_e = re.compile('src="(//mixdrop\.co/e/\w+)', re.DOTALL | re.IGNORECASE).findall(mixdrop_source)[0]
                #mixdrop_url_e = re.compile('src="(?:https?:|)//mixdrop\.(?:c|t)o/(?:e|f)/\w+', re.DOTALL | re.IGNORECASE).findall(mixdrop_source)[0]
                mixdrop_url_e = re.compile('src="((?:https?:|)//mixdrop\.(?:co|to|sx)/(?:e|f)/\w+)"', re.DOTALL | re.IGNORECASE).findall(mixdrop_source)[0]
                
                if mixdrop_url_e.startswith('/'): mixdrop_url_e = 'https:' + mixdrop_url_e
                Log("mixdrop_url_e='{}'".format(mixdrop_url_e))

                mixdrop_source = utils.getHtml(mixdrop_url_e, referer=mixdrop_url_f)
                #Log("mixdrop_source='{}'".format(mixdrop_source))

            except:
                mixdrop_url_e = mixdrop_url_f
                pass
                

            #mixdrop_js = re.compile("(<script.+?eval.+?</script>)", re.DOTALL | re.IGNORECASE).findall(mixdrop_source)[0]
            mixdrop_js_multiple = re.compile("(eval\(function\(p,a,c,k,e,d\).+?</script>)", re.DOTALL | re.IGNORECASE).findall(mixdrop_source)

            video_url = None
            for mixdrop_js in mixdrop_js_multiple:

                Log("mixdrop_js='{}'".format(mixdrop_js))

                mixdrop_unpacked_js = unpack(mixdrop_js)
                Log("mixdrop_unpacked_js='{}'".format(mixdrop_unpacked_js))

                regex = ';MDCore.wurl="([^"]+)"'
                try:
                    video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(mixdrop_unpacked_js)[0]
                except:
                    traceback.print_exc()
                    Log("mixdrop_source='{}'".format(mixdrop_source), xbmc.LOGNONE)
                    Log("mixdrop_unpacked_js='{}'".format(mixdrop_unpacked_js), xbmc.LOGNONE)
                    utils.Notify(u"failed to find video url for {} via {}".format(name, vidhost))
                    #return
                Log("video_url='{}'".format(video_url))
                if video_url:
                    break # don't look at more source
            

            if video_url.startswith('/'): video_url = 'https:' + video_url
            Log("video_url={}".format(video_url))

        except:
            traceback.print_exc()
            utils.Notify(u"failed to find video url for {} via {}".format(name, vidhost))
            return
                   
##        mixdrop_headers ={ "Accept-Encoding" : "identity;q=1, *;q=0" \
##                    , "User-Agent" : USER_AGENT \
##                    , "Accept" : "*/*" \
##                    , "Referer" :  mixdrop_url_e \
##                    }
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = mixdrop_url_e
        video_url += utils.Header2pipestring(headers)
        return video_url
##        Log("video_url={}".format(video_url))
##        videourl = video_url

        
    elif vidhost == 'youporn':
        youporn_url = re.compile("class='videoPlayer' src=\"([^\"]+)\" ", re.DOTALL | re.IGNORECASE).findall(videosource)
        #Log("youporn_url='{}'".format(youporn_url))
        youporn_url = html_parser.unescape(youporn_url[0])
        videourl = youporn_url + utils.Header2pipestring() #+ '&Referrer='+url
        #Log("videourl='{}'".format(videourl))
        
    if vidhost == 'HQQ':
#https://hqq.tv/player/embed_player.php?vid=bVdCa0VDMEtXS0hlT1ZKY2lsMmNUQT09&amp;autoplay=no
        hqq_url = re.compile('src=\"(https:\/\/hqq\.tv\/player\/embed\_player\.php[^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("hqq_url='{}'".format(hqq_url))
        hqq_url = hqq_url[0]
        #Log("hqq_url='{}'".format(hqq_url))


        #2019-05-29 ... HQQ denying access from porn-czech domain
        v_s = utils.getHtml(hqq_url,referer= url)

        deb = re.compile("license_code:(.+)preload:", re.DOTALL | re.IGNORECASE).findall(v_s)
        Log("deb='{}'".format(deb[0]))
        
        license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("license_code='{}'".format(license_code))

        vipporns_url = re.compile("video_url: 'function\/0\/([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("vipporns_url='{}'".format(vipporns_url))

        fappy_salt = FaapySalt(license_code, "")
        #Log("fappysalt='{}'".format(fappy_salt))

        old_fappy_code = vipporns_url.split('/')[5]
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        old_fappy_code = old_fappy_code[0:len(fappy_salt)]  #not sure if this applies to all sites
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        new_fappy_code = ConvertFaapyCode( old_fappy_code, fappy_salt)
        #Log("new_fappy_code='{}'".format(new_fappy_code))

        vipporns_url = vipporns_url.replace(old_fappy_code, new_fappy_code)
        vipporns_url = vipporns_url + "&rnd=" + str(time.time()*100)
        #Log("vipporns_url='{}'".format(vipporns_url))

        videourl = vipporns_url
        

    if vidhost == 'vipporns':
        #Log("url='{}'".format(url))
        vipporns_url = re.compile('src=\"(https:\/\/www\.vipporns\.com\/embed\/[^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videosource)
        #Log("vipporns_url='{}'".format(vipporns_url))
        vipporns_url = vipporns_url[0]
        #Log("vipporns_url='{}'".format(vipporns_url))
        v_s = utils.getHtml(vipporns_url)

        deb = re.compile("license_code:(.+)preload:", re.DOTALL | re.IGNORECASE).findall(v_s)
        Log("deb='{}'".format(deb[0]))
        
        license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("license_code='{}'".format(license_code))

        vipporns_url = re.compile("video_url: 'function\/0\/([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("vipporns_url='{}'".format(vipporns_url))

        fappy_salt = FaapySalt(license_code, "")
        #Log("fappysalt='{}'".format(fappy_salt))

        old_fappy_code = vipporns_url.split('/')[5]
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        old_fappy_code = old_fappy_code[0:len(fappy_salt)]  #not sure if this applies to all sites
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        new_fappy_code = ConvertFaapyCode( old_fappy_code, fappy_salt)
        #Log("new_fappy_code='{}'".format(new_fappy_code))

        vipporns_url = vipporns_url.replace(old_fappy_code, new_fappy_code)
        vipporns_url = vipporns_url + "&rnd=" + str(time.time()*100)
        #Log("vipporns_url='{}'".format(vipporns_url))

        return vipporns_url



##    if vidhost == 'verystream':
##        Log("verystream hosted url='{}'".format(url))
##        verystream_url = re.compile('class=\"video-container\".+?src=\"([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videosource)
##        if verystream_url:
##            verystream_url = verystream_url[0]
##            Log("verystream_url='{}'".format(verystream_url))
##            v_s = utils.getHtml(verystream_url)
##            playvideo(v_s, name=name, download=download, url=url)
##            return
##
##        verystream_url = re.compile('(?:href|src)=\"(https:\/\/verystream\.com\/e\/[^\/\"]+)(?:\/|\")', re.DOTALL | re.IGNORECASE).findall(videosource)
##        if verystream_url: #some sites have an extra hop
##            verystream_url = verystream_url[0]
##            Log("verystream_url='{}'".format(verystream_url))
##            v_s = utils.getHtml(verystream_url, referer=url)
##        else:
##            v_s = videosource
##
##        verystream_url = re.compile('id=\"videolink\">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(v_s)
##        Log("verystream_url='{}'".format(verystream_url))
##
##        if verystream_url:
##            verystream_url = "https://verystream.com/gettoken/{}?mime=true".format(verystream_url[0])
##            Log("verystream_url='{}'".format(verystream_url))
##            videourl = verystream_url
        



    if vidhost == 'Watchxfree':
        try:
            watchxfree_url = re.compile(r"//(?:www\.)?watchxfree\.(?:eu|io|tv|info|stream)?/(?:embed|f)/([0-9a-zA-Z-_]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
            video = resolveurl.resolve(watchxfree_url)
            if video:
                videourl = video
        except:
            utils.Notify('Oh oh','Couldn\'t find playable link')
            return None

    elif vidhost in ['aparat.cam','wolfstream.tv']:

        vidhost = 'wolfstream.tv'
        
##    if re.search('https?://wolfstream\.tv/\w+/', videosource, re.DOTALL | re.IGNORECASE):
##        hosts.append('wolfstream.tv')
        regex = r'((?://|\.)(?:aparat\.cam|wolfstream\.tv)/(?:embed-)?[0-9a-zA-Z]+(?:\.html)?)'
        aparat_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)[0]
        if aparat_url.startswith('/'): aparat_url = 'https:' + str(aparat_url)
        Log("aparat_url='{}'".format(repr(aparat_url)) )#, xbmc.LOGNONE)

    
        regex = r'(?://|\.)(aparat\.cam)/(?:embed-)?([0-9a-zA-Z]+)'
        regex = r'((?://|\.)aparat\.cam/(?:embed-)?[0-9a-zA-Z]+(?:\.html)?)'
        regex = r'((?://|\.)(?:aparat\.cam|wolfstream\.tv)/(?:embed-)?[0-9a-zA-Z]+(?:\.html)?)'        
        aparat_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)[0]
        if aparat_url.startswith('/'): aparat_url = 'https:' + str(aparat_url)
        Log("aparat_url='{}'".format(repr(aparat_url)), xbmc.LOGNONE)
        aparat_html = utils.getHtml(aparat_url,referer=url)
        regex = 'jsplayer.+?src:.+?"([^"]+)'
        aparat_sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(aparat_html)
        if not aparat_sources:
            regex = 'jwplayer\.key.+?file:"([^"]+)"'
            aparat_sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(aparat_html)
        if not aparat_sources: return None

        Log("aparat_sources='{}'".format(repr(aparat_sources)), xbmc.LOGNONE)
        videourl = aparat_sources[0]
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = "https://{}".format(vidhost)
        headers['Origin'] = "https://{}".format(vidhost)
        return videourl + utils.Header2pipestring(headers)

                
    elif vidhost == 'aparat.com':


        regex = r'https?://(?:www\.)?aparat\.com/(?:v/|video/video/embed/videohash/|)(?P<id>[a-zA-Z0-9]+)'        
        aparat_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)[0]
        #Log("aparat_url='{}'".format(aparat_url), xbmc.LOGNONE)
        try:
            video = resolveurl.resolve(aparat_url)
            if video:
                videourl = video
        except:
            raise
##            utils.Notify('Oh oh','Couldn\'t find playable link')
##            return


    elif vidhost == 'tubst':
        tubst_url = re.compile("https:\/\/www\.tubst\.net\/(?:embed)?\/(?:[0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        if tubst_url:
            tubst_url = tubst_url[0]
            Log("tubst_url='{}'".format(tubst_url))
            v_s = utils.getHtml(tubst_url, url)
            playvideo(v_s, name=name, download=download, url=url)
            return
            
    elif vidhost == '1fichier':
        progress.update( 40, "", "Loading {}".format(vidhost), "" )
        streaminurl = re.compile("https:\/\/1fichier\.com\/(?:embed-)?\?(?:[0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        kodilog("{}:{}".format(vidhost, repr(streaminurl)))
        streaminurl = chkmultivids(streaminurl)
        kodilog("{}:{}".format(vidhost, repr(streaminurl)))
        progress.update( 50, "", "Loading {}".format(vidhost), "Sending it to resolveurl")
        video = resolveurl.resolve(streaminurl)
        if video:
            progress.update( 80, "", "Loading {}".format(vidhost), "Found the video" )
            videourl = video

    elif vidhost == 'Streamin':
        progress.update( 40, "", "Loading Streamin", "" )
        streaminurl = re.compile(r"//(?:www\.)?streamin\.to/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        streaminurl = chkmultivids(streaminurl)
        streaminurl = 'http://streamin.to/embed-%s-670x400.html' % streaminurl
        progress.update( 50, "", "Loading Streamin", "Sending it to resolveurl")
        video = resolveurl.resolve(streaminurl)
        if video:
            progress.update( 80, "", "Loading Streamin", "Found the video" )
            videourl = video

    elif vidhost == 'FlashX':
        progress.update( 40, "", "Loading FlashX", "" )
        flashxurl = re.compile(r"//(?:www\.)?flashx\.tv/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        media_id = chkmultivids(flashxurl)
        flashxurl = 'http://www.flashx.tv/%s.html' % media_id
        progress.update( 50, "", "Loading FlashX", "Sending it to resolveurl" )
        video = resolveurl.resolve(flashxurl)
        if video:
            progress.update( 80, "", "Loading FlashX", "Found the video" )
            videourl = video

    elif vidhost == 'ksplayer':
#<iframe loading="lazy" width="100%" height="100%" src="about:blank" frameborder="0" allowfullscreen="true" data-rocket-lazyload="fitvidscompatible" data-lazy-src="https://stream.ksplayer.com/embed/GyaZyGCNCgcCoi6/"></iframe><noscript>
#<iframe width="100%" height="100%" src="https://stream.ksplayer.com/embed/GyaZyGCNCgcCoi6/" frameborder="0" allowfullscreen="true"></iframe>
        
        Log("ksplayer='{}'".format(url))
        regex = '"(https?://(?:stream\.)?ksplayer\.com/(?:embed/)[0-9a-zA-Z]+/)\"'
        ksplayer_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("ksplayer_url='{}'".format(ksplayer_url))
        if len(ksplayer_url):
            ksplayer_url=ksplayer_url[0]
        
        ksplayer_src = utils.getHtml(ksplayer_url)
        Log("ksplayer_src='{}'".format(ksplayer_src))
        regex = '<script type="text/javascript">JuicyCodes\.Run\((.*?)\);</script>'
        juicycodes_src = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(ksplayer_src)
        if juicycodes_src:
            juicycodes_src = juicycodes_src[0]
            Log("juicycodes_src='{}'".format(juicycodes_src))
            regex = '"([^"]+)"'
            juicycodes_split = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(juicycodes_src)
            juicycodes_src = ""
            for juicycode in juicycodes_split:
                juicycodes_src = juicycodes_src + juicycode
            juicycodes_src = base64.b64decode(juicycodes_src)
        else:
            Log("Can't find juicy in this vidhost")
        Log("juicycodes_src='{}'".format(juicycodes_src))

        ksplayer_js = unpack(juicycodes_src)
        Log("ksplayer_js='{}'".format(ksplayer_js))

        regex = 'sources:(\[.*\])'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(ksplayer_js)
        Log("sources_list='{}'".format(sources_list))
        
        import json
        json_sources = json.loads(sources_list[0])

        list_key_value = {} ##[] #dict()
        for i in range(len(json_sources)):
            dict_source = dict(json_sources[i])
            q = str(dict_source['label'])
            v = str(dict_source['file'])
            if not v == "":
                list_key_value[q] = v
        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
        video_url = SortVideos(list_key_value,0)
        Log("video_url={}".format(video_url))

        return video_url


    elif vidhost == 'Mega3X':
        progress.update( 40, "", "Loading Mega3X", "" )
        mega3xurl = re.compile(r"(https?://(?:www\.)?mega3x.net/(?:embed-)?(?:[0-9a-zA-Z]+).html)", re.DOTALL | re.IGNORECASE).findall(videosource)
        mega3xurl = chkmultivids(mega3xurl)
        mega3xsrc = utils.getHtml(mega3xurl,'')
        mega3xjs = re.compile("<script[^>]+>(eval[^<]+)</sc", re.DOTALL | re.IGNORECASE).findall(mega3xsrc)
        progress.update( 80, "", "Getting video file from Mega3X", "" )
        mega3xujs = unpack(mega3xjs[0])
        videourl = re.compile('file:\s?"([^"]+m3u8)"', re.DOTALL | re.IGNORECASE).findall(mega3xujs)
        videourl = videourl[0]



    elif vidhost == 'gounlimited':
        Log("gounlimited='{}'".format(url))
        #Log("videosource='{}'".format(videosource))
        
#        regex = '"?(https?://gounlimited\.to/(?:embed-[0-9a-zA-Z]+\.html|\w+/\S+\.mp4))"?'
        regex = '"?(https?://gounlimited\.to/(?:embed-[0-9a-zA-Z]+\.html|\w+/\S+\.mp4|\w+))"?' #works 2020-04-08
#https://gounlimited.to/xyqxtycqxnq6/PrincessCum.20.01.03.Dana.Wolf.720p.mp4
#https://gounlimited.to/embed-4yjfuoztjqkp.html
#https://gounlimited.to/ckoabbhrvdg6


        gounlimited_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("gounlimited_url='{}'".format(gounlimited_url))
        if not gounlimited_url:
            Log("unknown gounlimited structure", xbmc.LOGWARNING)
            return
        else:
            gounlimited_url = gounlimited_url[0]
        gounlimited_src = utils.getHtml(gounlimited_url, url, http_timeout=50)
        #Log("gounlimited_src='{}'".format(gounlimited_src))
        
        regex = "\(p,a,c,k,e,d\).+?}\('(.*?),(\d+),(\d+),'(.*?)'"
        packed_src = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(gounlimited_src)
        if not packed_src: return
        else: packed_src = packed_src[0]
        #Log("packed_src='{}'".format(packed_src))


        p = packed_src[0]
        a = packed_src[1]
        c = packed_src[2]
        k = packed_src[3].split("|")
        source_js = dePacked(p,a,c,k,None,None)
        Log("source_js='{}'".format(source_js))
        #regex = '{sources:\["([^"]+)"'
        regex = '{(?:sources:\[|src:)"([^"]+)"'  #works 2020-04-08
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_js)
        Log("sources='{}'".format(sources))
        video_url = sources[0]
        if video_url.startswith('/'): video_url = 'https:' + video_url

        gounlimited_headers = { "Accept-Encoding" : "identity;q=1, *;q=0" \
                    , "User-Agent" : C.USER_AGENT \
                    , "Accept" : "*/*" \
                    , "Referer" :  gounlimited_url \
                    }
        video_url += utils.Header2pipestring(gounlimited_headers)
        
        Log("video_url='{}'".format(video_url))
        return video_url


    elif vidhost == 'Datoporn':

        video_url = resolveurl.resolve(videosource)
        Log("video_url='{}'".format(video_url))
        return video_url
        
        #progress.update( 40, "", "Loading Datoporn", "" )
        #href="http://dato.porn/embed-mormjvwfymtn.html"
        #http://dato.porn/se4mssi34ina
        #http://dato.porn/embed-se4mssi34ina.html
        datourl = re.compile("\/\/(?:www\.)?dato\.?porn(?:\.com|\.co)?\/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("datourl='{}'".format(datourl))
        if datourl:
            Log("datourl found")
            
            datourl = chkmultivids(datourl)
            Log("datourl='{}'".format(datourl))
            datourl = "http://datoporn.co/embed-" + datourl + ".html"
            Log("datourl='{}'".format(datourl))
            datosrc = utils.getHtml(datourl,'')
            if datosrc == '':
                datourl = "http://datoporn.com/embed-" + datourl + ".html"
                Log("datourl='{}'".format(datourl))
                datosrc = utils.getHtml(datourl,'')

            if "File was deleted" in datosrc:
                utils.Notify('Oh oh','File is deleted from Datoporn')
                return

            datojs = re.compile("<script>.var player.+?(player.updateSrc[^<]+)</sc", re.DOTALL | re.IGNORECASE).findall(datosrc)
            try:
                #Log("datojs='{}'".format(datojs))
                datoujs = unpack(datojs[0])
            except:
                datoujs = ''
            #Log("datoujs='{}'".format(datoujs))

            #maybe a packed encoding
            regex1 = "\(p,a,c,k,e,d\).+?}\('(.*?);',"
            packed1 = re.compile(regex1, re.DOTALL).findall(datosrc)
            regex2 = "\(p,a,c,k,e,d\).+?;',(.+)\.split\(\'\|\'\)"
            packed2 = re.compile(regex2, re.DOTALL).findall(datosrc)
            #Log("packed1='{}'".format(packed1))
            #Log("packed2='{}'".format(packed2))
            if packed1 and packed2:
                p = packed1[0]
                #Log("p='{}'".format(p))
                packed_arr = packed2[0].split(',')
                a = packed_arr[0]
                c = packed_arr[1]
                k = packed_arr[2].split('|')
                #Log("a='{}'".format(a))
                #Log("c='{}'".format(c))
                #Log("k='{}'".format(k))
                datoujs = dePacked(p,a,c,k,None,None)
                Log("datoujs='{}'".format(datoujs))
            else:
                Log("not packed1 and packed2;reverint to raw html")
##                Log(datosrc)
                datoujs = datosrc
                
            regex = 'file:\"([^\"]+mp4)\"'
            regex = 'file:\"([^\"]+mp4)\",label:\"([^\"]+)p\"'
            #regex = 'file:"([^"]+(?:\.mp4|\.m3u8|\.mpd))"(?:,label:")*(\d+|})(?:"p)*'
            video_sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(datoujs)
            if not video_sources: #try another format
                video_sources = re.compile('{src: "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(datoujs)
            if len(video_sources) == 0:
                video_sources = None
                
            Log("video_sources='{}'".format(video_sources))
            if video_sources:
                video_url = SortVideos(video_sources, substitute_res='1080')
                #videourl = videourl[0]
                videourl = "{}{}&Referer={}".format(video_url, utils.Header2pipestring(), datourl)
            Log("='{}'".format(videourl))


    elif vidhost == 'StreamCloud':
        Log("Opening Streamcloud")
        streamcloudurl = re.compile(r"//(?:www\.)?streamcloud\.eu?/([0-9a-zA-Z-_/.]+html)", re.DOTALL | re.IGNORECASE).findall(videosource)
        streamcloudurl = chkmultivids(streamcloudurl)
        streamcloudurl = "http://streamcloud.eu/" + streamcloudurl
        Log("Getting Streamcloud page")
        schtml = postHtml(streamcloudurl)

        form_values = {}
        match = re.compile('<input.*?name="(.*?)".*?value="(.*?)">', re.DOTALL | re.IGNORECASE).findall(schtml)
        for name, value in match:
            form_values[name] = value.replace("download1","download2")

        Log("Grabbing video file")
        newscpage = postHtml(streamcloudurl, form_data=form_values)

        videourl = re.compile('file:\s*"(.+?)",', re.DOTALL | re.IGNORECASE).findall(newscpage)[0]
        streamcloud_headers = { "Accept-Encoding" : "identity;q=1, *;q=0" \
                    , "User-Agent" : USER_AGENT \
                    , "Accept" : "*/*" \
                    , "Referer" :  streamcloudurl \
                    }
        videourl = videourl + utils.Header2pipestring(streamcloud_headers)
        Log("videourl='{}'".format(videourl), xbmc.LOGNONE)
        
    elif vidhost == 'Jetload':
        progress.update( 40, "", "Loading Jetload", "" )
        jlurl = re.compile(r'jetload\.tv/([^"]+)', re.DOTALL | re.IGNORECASE).findall(videosource)
        jlurl = chkmultivids(jlurl)
        jlurl = "http://jetload.tv/" + jlurl
        progress.update( 50, "", "Loading Jetload", "" )
        jlsrc = utils.getHtml(jlurl, url)
        videourl = re.compile(r'file: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(jlsrc)
        if videourl:
            videourl = videourl[0]
        else:
            utils.Notify('Oh oh','File was deleted from: {}'.format(vidhost))
            return

    elif vidhost == 'Videowood':
        progress.update( 40, "", "Loading Videowood", "" )
        vwurl = re.compile(r"//(?:www\.)?videowood\.tv/(?:embed|video)/([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        vwurl = chkmultivids(vwurl)
        vwurl = 'http://www.videowood.tv/embed/' + vwurl
        progress.update( 50, "", "Loading Videowood", "Sending it to resolveurl" )
        video = resolveurl.resolve(vwurl)
        if video:
            progress.update( 80, "", "Loading Videowood", "Found the video" )
            videourl = video

    elif vidhost == 'Keeplinks <--':
        progress.update( 40, "", "Loading Keeplinks", "" )
        klurl = re.compile(r"//(?:www\.)?keeplinks\.eu/p([0-9a-zA-Z/]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        klurl = chkmultivids(klurl)
        klurl = 'http://www.keeplinks.eu/p' + klurl
        kllink = getVideoLink(klurl, '')
        kllinkid = kllink.split('/')[-1]
        klheader = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
           'Accept-Encoding': 'none',
           'Accept-Language': 'en-US,en;q=0.8',
           'Connection': 'keep-alive',
           'Cookie': 'flag['+kllinkid+'] = 1;'}
        klpage = utils.getHtml(kllink, klurl, klheader)
        playvideo(klpage, name, download, klurl)
        return


    elif vidhost == "evoload":

        regex = r'((?:https?://|\.)(evoload\.io)/(?:e|f|v)/([0-9a-zA-Z]+))'
        resolveurl_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("resolveurl_url='{}'".format(resolveurl_url), xbmc.LOGNONE)
        video_url = None
        for url in resolveurl_url:
            video_url = resolveurl.resolve(url[0])
##        video_url = resolveurl.resolve(videosource)
            if video_url: break
        return video_url
        

    
    elif vidhost == 'Streamdefence':

        video_url = resolveurl.resolve(videosource)

        return video_url
    
##
##
##
##        Log("Loading Streamdefence")
##        sdurl = re.compile(r'streamdefence\.com/view.php\?ref=([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videosource)
##        if sdurl:
##            sdurl = chkmultivids(sdurl)
##            sdurl = 'http://www.streamdefence.com/view.php?ref=' + sdurl
##        else:
##            sdurl = re.compile('\.strdef\.world/([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videosource)
##            if sdurl:
##                sdurl = 'https://www.strdef.world/' + sdurl[0]
##
##        Log("streamdefence url:'{}'".format(sdurl))
##        Log("referrer:'{}'".format(url))
##        sdsrc = utils.getHtml(sdurl, url)
##        Log("Getting video file from Streamdefence")
##        sdpage = streamdefence(sdsrc)
##
##        #Log("sdpage={}".format(sdpage))
##        playvideo(sdpage, name, download, sdurl)
##        return

    elif vidhost == 'Filecrypt':
        Log("Loading Filecrypt")
        fcurl = re.compile(r'filecrypt\.cc/Container/([^\.]+)\.html', re.DOTALL | re.IGNORECASE).findall(videosource)
        fcurl = chkmultivids(fcurl)
        fcurl = 'http://filecrypt.cc/Container/' + fcurl + ".html"
        fcsrc = utils.getHtml(fcurl, url)
        fcmatch = re.compile(r"onclick=\"openLink.?'([\w\-]*)',", re.DOTALL | re.IGNORECASE).findall(fcsrc)
        progress.update( 80, "", "Getting video file from Filecrypt", "" )
        fcurls = ""
        for fclink in fcmatch:
            fcpage = "http://filecrypt.cc/Link/" + fclink + ".html"
            fcpagesrc = utils.getHtml(fcpage, fcurl)
            fclink2 = re.search('<iframe .*? noresize src="(.*)"></iframe>', fcpagesrc)
            if fclink2:
                try:
                    fcurl2 = getVideoLink(fclink2.group(1), fcpage)
                    fcurls = fcurls + " " + fcurl2
                except:
                    pass
        playvideo(fcurls, name, download, fcurl)
        return


    elif vidhost == 'vidoza':
        try:
            vidoza_url = re.compile("((?:https:|http:)(?://|\.)vidoza\.net/(?:embed-|)[0-9a-zA-Z]+(?:\.html|))", re.DOTALL | re.IGNORECASE).findall(videosource)
            Log("vidoza_url={}".format(vidoza_url))
            media_id = re.compile("(?://|\.)vidoza\.net/(?:embed-|)([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
            Log("media_id={}".format(media_id))
            vidoza_url = 'http://vidoza.net/%s' % media_id[0]       
            Log("vidoza_url={}".format(vidoza_url))
            video_url = resolveurl.resolve(vidoza_url)
        except:
            traceback.print_exc()
            video_url = None
        return video_url
    
    elif vidhost == 'Vidlox':
        Log("loading Vidlox")

        #look for direc source inside html
        regex = '"(https?://.+?\.mp4)"'
        regex = '"(https?://[^"]+\.(?:mp4|m3u8))"'
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        if sources:
            Log("sources={}".format(sources))
            videourl = sources[0]
        else:
            vidlox_url = re.compile(r"(?://|\.)vidlox\.(?:tv|me)/(?:embed-|)([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
            Log("vidlox_url={}".format(vidlox_url))
            media_id = chkmultivids(vidlox_url)
            vidlox_url = 'https://vidlox.me/%s' % media_id
            Log("vidlox_url={}".format(vidlox_url))
            try:
                video_url = resolveurl.resolve(vidlox_url)
            except:
                raise
                traceback.print_exc()
                video_url = None
            return video_url
                
##            
##            if video:
##                progress.update( 80, "", "Loading Vidlox", "Found the video" )
##                videourl = video
                

    elif vidhost == 'ZStream':
        progress.update( 40, "", "Loading Zstream", "" )
        zstreamurl = re.compile(r"(?://|\.)zstream\.to/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        zstreamurl = chkmultivids(zstreamurl)
        zstreamurl = 'http://zstream.to/embed-%s.html' % zstreamurl
        progress.update( 50, "", "Loading ZStream", "Sending it to resolveurl")
        video = resolveurl.resolve(zstreamurl)
        if video:
            progress.update( 80, "", "Loading ZStream", "Found the video" )
            videourl = video

    elif vidhost == 'Streamcherry' or vidhost == 'Streamango':
        Log("streamcherry url={}".format(url))
        scstreamurl = re.compile(r"(?://|\.)(?:streamcherry|streamango)\.com/(?:embed|f)/(\w+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        scstreamurl = chkmultivids(scstreamurl)
        scstreamurl = 'https://streamcherry.com/embed/%s' % scstreamurl
        Log("scstreamurl='{}'".format(scstreamurl))
        video = resolveurl.resolve(scstreamurl)
        if video:
            progress.update( 80, "", "Loading Streamcherry", "Found the video" )
            videourl = video

    elif vidhost == 'Rapidvideo':
        try:
            rpvideourl = re.compile(r"(?://|\.)(?:rapidvideo|raptu)\.com/(?:embed/|[ev]/|\?v=)?([0-9A-Za-z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
            rpvideourl = chkmultivids(rpvideourl)
            rpvideourl = 'https://www.rapidvideo.com/embed/%s' % rpvideourl
            video_url = resolveurl.resolve(rpvideourl)
        except:
            traceback.print_exc()
            video_url = None
        return video_url

    elif vidhost == 'Direct Source':
        Log("vidhost='{}'".format(vidhost))
        #progress.update( 40, "", "Loading Direct source", "" )
        dsurl = re.compile("""<source.*?src=(?:"|')([^"']+)[^>]+>""", re.DOTALL | re.IGNORECASE).findall(videosource)
        dsurl = chkmultivids(dsurl)
        videourl = dsurl


    return videourl


#__________________________________________________________________________
#
def chkmultivids(videomatch):
    videolist = list(set(videomatch))
    if len(videolist) > 1:
        i = 1
        hashlist = []
        for x in videolist:
            hashlist.append('Video ' + str(i) + '  ' + x)
            i += 1
        mvideo = C.dialog.select('Multiple videos found', hashlist)
        if mvideo == -1:
            return
        return videolist[mvideo]
    else:
        return videomatch[0]


#__________________________________________________________________________
#
# videowood decode copied from: https://github.com/schleichdi2/OpenNfr_E2_Gui-5.3/blob/4e3b5e967344c3ddc015bc67833a5935fc869fd4/lib/python/Plugins/Extensions/MediaPortal/resources/hosters/videowood.py
def videowood(data):
    parse = re.search('(....ωﾟ.*?);</script>', data)
    if parse:
        todecode = parse.group(1).split(';')
        todecode = todecode[-1].replace(' ','')

        code = {
            "(ﾟДﾟ)[ﾟoﾟ]" : "o",
            "(ﾟДﾟ) [return]" : "\\",
            "(ﾟДﾟ) [ ﾟΘﾟ]" : "_",
            "(ﾟДﾟ) [ ﾟΘﾟﾉ]" : "b",
            "(ﾟДﾟ) [ﾟｰﾟﾉ]" : "d",
            "(ﾟДﾟ)[ﾟεﾟ]": "/",
            "(oﾟｰﾟo)": '(u)',
            "3ﾟｰﾟ3": "u",
            "(c^_^o)": "0",
            "(o^_^o)": "3",
            "ﾟεﾟ": "return",
            "ﾟωﾟﾉ": "undefined",
            "_": "3",
            "(ﾟДﾟ)['0']" : "c",
            "c": "0",
            "(ﾟΘﾟ)": "1",
            "o": "3",
            "(ﾟｰﾟ)": "4",
            }
        cryptnumbers = []
        for searchword,isword in code.iteritems():
            todecode = todecode.replace(searchword,isword)
        for i in range(len(todecode)):
            if todecode[i:i+2] == '/+':
                for j in range(i+2, len(todecode)):
                    if todecode[j:j+2] == '+/':
                        cryptnumbers.append(todecode[i+1:j])
                        i = j
                        break
                        break
        finalstring = ''
        for item in cryptnumbers:
            chrnumber = '\\'
            jcounter = 0
            while jcounter < len(item):
                clipcounter = 0
                if item[jcounter] == '(':
                    jcounter +=1
                    clipcounter += 1
                    for k in range(jcounter, len(item)):
                        if item[k] == '(':
                            clipcounter += 1
                        elif item[k] == ')':
                            clipcounter -= 1
                        if clipcounter == 0:
                            jcounter = 0
                            chrnumber = chrnumber + str(eval(item[:k+1]))
                            item = item[k+1:]
                            break
                else:
                    jcounter +=1
            finalstring = finalstring + chrnumber.decode('unicode-escape')
        stream_url = re.search('=\s*(\'|")(.*?)$', finalstring)
        if stream_url:
            return stream_url.group(2)
    else:
        return


#__________________________________________________________________________
#
def streamdefence(html):

    Log("streamdefence(html) detected")
    #Log("streamdefence(html)={}".format(html), xbmc.LOGNONE)

    if html == "":
        return html


    #iframe src="https://verystream.com/e/N3DnRCksHaR/younfn.mp4"
    verystream_url = re.compile('iframe src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    if verystream_url:
        verystream_url = verystream_url[0]
        Log("verystream_url={}".format(verystream_url))
        returnutils.getHtml(verystream_url)

    second_streamdefence_url = re.compile('strdef\.world/player([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    if second_streamdefence_url:
        second_streamdefence_url = 'https://www.strdef.world/player' + second_streamdefence_url[0]
        Log("second_streamdefence_url={}".format(second_streamdefence_url))
        #sdurl = "https://strdef.world/player.php?id=1ebd0d89-6813-40ed-a014-c0e2bec7252b"
        sdsrc =utils.getHtml(second_streamdefence_url)
        return streamdefence(sdsrc)
    
    dhYas638H_code = re.compile('\(dhYas638H\(\"([0-9a-zA-Z/-_\+\=]+)\"', re.DOTALL | re.IGNORECASE).findall(html)
    if dhYas638H_code:
        Log("second encoding")
        dhYas638H_code = dhYas638H_code[0]
        try:
            dhYas638H_code = 'base64decoded(dhYas638H("' + base64.b64decode(dhYas638H_code) + '"'
            Log("base 64 decode successful")
            return streamdefence(dhYas638H_code)
        except:
            pass
        
        #Log("dhYas638H_code={}".format(dhYas638H_code) )
        dhYas638H_decoded = dhYas638H(dhYas638H_code)

        html = html.replace('dhYas638H("'+dhYas638H_code+'")', '"' + dhYas638H_decoded + '"' )
        Log("html_after_replace={}".format(html) )
        return html

    else:
        Log("second encoding NOT found")

    dhYas638H_code = None
    dhYas638H_code = re.compile('= dhYas638H\(\"?([0-9a-zA-Z-/_\+\=]+)\"?\)', re.DOTALL | re.IGNORECASE).findall(html)
    if dhYas638H_code:
        dhYas638H_code = dhYas638H_code[0]
        #Log("dhYas638H_code={}".format(dhYas638H_code), xbmc.LOGNONE)
        third_redirect = None

        third_redirect = re.compile(dhYas638H_code+'=\"([0-9a-zA-Z/-_\+\=]+)\"'  , re.DOTALL | re.IGNORECASE).findall(html)
        if third_redirect:
            third_redirect = third_redirect[0]
            #Log("third_redirect={}".format(third_redirect), xbmc.LOGNONE)        
            dhYas638H_decoded = dhYas638H(third_redirect)
            return streamdefence(dhYas638H_decoded)
    else:
        Log("no third_redirect found")        
    html = re.compile('"(https?:\/\/[^\"]+)"', re.DOTALL | re.IGNORECASE).findall(html)[0]

    #Log("decoded={}".format(html), xbmc.LOGNONE)
    return html



##playerlib.alltubes.8.6.3.v1.425.js
##in:
##var EiCkh8i4='[{"video_url":"aHR0cH\u041c6Ly9tZW1iZXIudHViZX\u0412vcm5jbGFzc2ljLmNvbS9nZXRfZmlsZS8xLz\u04154Yj\u04102NG\u04153\u041cz\u04154Yj\u04101NWJkOWI5\u041cmRmNTQ1N2\u0415wYzU0\u041cTJjNDlmZDc5O\u04218x\u041cDYx\u041cD\u0410wLz\u0415wNj\u04155\u041cj\u0410v\u041cT\u04102\u041cTky\u041c\u04215tcDQvP2Q9\u041cTgxJmJyPT\u0415wO\u0421Z0aT0xNTYxND\u04104\u041cj\u041cwJmxpcD0y\u041cTY~","is_default":1}]';
##out:
##https://member.tubepornclassic.com/get_file/1/
##18b064a7318b055bd9b92df5457a0c5412c49fd798/1061000/1061920/
##1061920.mp4/?d=181&br=108&ti=1561408230&lip=216&f=video.m3u8
##
##
##window.Dpww3Dw64 = function(k) {
##    var c = ""
##      , f = 0;
##    /[^\u0410\u0412\u0421\u0415\u041cA-Za-z0-9\.,~]/g.exec(k) && console.log("error decoding url");
##    k = k.replace(/[^\u0410\u0412\u0421\u0415\u041cA-Za-z0-9\.,~]/g, "");
##    do {
##        var e = "\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~".indexOf(k.charAt(f++))
##          , n = "\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~".indexOf(k.charAt(f++))
##          , m = "\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~".indexOf(k.charAt(f++))
##          , r = "\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~".indexOf(k.charAt(f++));
##        e = e << 2 | n >> 4;
##        n = (n & 15) << 4 | m >> 2;
##        var v = (m & 3) << 6 | r;
##        c += String.fromCharCode(e);
##        64 != m && (c += String.fromCharCode(n));
##        64 != r && (c += String.fromCharCode(v))
##    } while (f < k.length);return unescape(c)
##}
##;
def alltubes_decode(input_string):
    #Log("input_string={}".format(input_string))
    #aHR0cH\u041c6Ly9tZW1iZXIudHViZX\u0412vcm5jb
    #\u041daHR0cH\u041c
    #     01234567
    #aHR0cH\u041c
    #01234567
    k = input_string
##    Log(k[4])
##    Log(k[5])
##    Log(k[6])
    if not isinstance(input_string, unicode):
##        Log("not")
        input_string = input_string.decode("raw_unicode_escape")
    #"MaHR0cH\u041c
    k = input_string
##    #Log(k[0])
##    #Log(k[1]) #a
##    #Log(k[2]) #H
##    Log(k[4]) #R
##    Log(k[5]) #0
##    Log(k[6]) #c
    k = re.sub(u'(?is)[^\u0410\u0412\u0421\u0415\u041cA-Za-z0-9\.,~]','',k)
##    Log("regex sub")
##    Log(k[4]) #c
##    Log(k[5]) #H
##    #Log(k[6]) #\u041c

    f = 0; c= "";
    base64 = u"\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~"
    while (f < len(k)):
        e = base64.index(k[f+0])
        n = base64.index(k[f+1])
        m = base64.index(k[f+2])
        r = base64.index(k[f+3])
        f = f + 4
        e = (e << 2) | (n >> 4)
        n = ((n & 15) << 4) | (m >> 2)
        v = ((m & 3) << 6) | r
        c = c + from_char_code(e)
        if (m != 64):
            c = c + from_char_code(n)
        if (r != 64):
            c = c + from_char_code(v)
        
        

    Log("alltubes_decode={}".format(c))
##    Log("end")
    return c

   
#__________________________________________________________________________
#
def from_char_code(*args):
    return ''.join(map(unichr, args))


#__________________________________________________________________________
#
def dhYas638H(input_string
              , base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
              , substitutions = "[^A-Za-z0-9+/=]"
              ):
    #base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    output = "";
    i = 0;
    #Log("base64={}".format(base64.decode('utf-16')), xbmc.LOGNONE)
    #Log("input_string={}".format(input_string), xbmc.LOGNONE)
    input_string = re.sub(substitutions, "", input_string, re.DOTALL)
    #Log("input_string={}".format(input_string), xbmc.LOGNONE)
    
    while i < len(input_string) :

        #Log("i+0={},input_stringi+0={}".format(i,input_string[i+0]), xbmc.LOGNONE)        
        enc1 = base64.index(  input_string[i+0]  )
        #Log("enc1={}".format(enc1), xbmc.LOGNONE)        
        enc2 = base64.index(  input_string[i+1]  )
        #Log("enc2={}".format(enc2), xbmc.LOGNONE)        
        enc3 = base64.index(  input_string[i+2]  )
        #Log("enc3={}".format(enc3), xbmc.LOGNONE)        
        enc4 = base64.index(  input_string[i+3]  )
        #Log("enc4={}".format(enc4), xbmc.LOGNONE)        
        i = i+4

        ch1 = (enc1 << 2) | (enc2 >> 4)
        #Log("ch1={}".format(ch1), xbmc.LOGNONE)        
        ch2 = ((enc2 & 15) << 4) | (enc3 >> 2)
        #Log("ch2={}".format(ch2), xbmc.LOGNONE)        
        ch3 = ((enc3 & 3) << 6) | enc4

        output = output + from_char_code(ch1)
        #Log(output, xbmc.LOGNONE)
        
        if (enc3 != 64):
##            Log(from_char_code(ch2), xbmc.LOGNONE)
            output = output + from_char_code(ch2)
            #Log("--" + output, xbmc.LOGNONE)
        if (enc4 != 64):
            output = output + from_char_code(ch3)
            #Log("-----" + output, xbmc.LOGNONE)

        ch1 = ""
        ch2 = ""
        ch3 = ""
        enc1 = ""
        enc2 = ""
        enc3 = ""
        enc4 = ""

    Log("dhYas638H_output={}".format(output), xbmc.LOGNONE)        
    return output

#__________________________________________________________________________
#


    

#__________________________________________________________________________
#
## based on /player/kt_player.swf?v=4.0.4
def FaapySalt(licencekey, video_url):
    #m is a salt used later
    #d=licencecode
    #k = first 8 numbs of licence key
    #l= last 8
    c = "16px"
    #$3790 8681 2506 737
    #3790868 12506737
    #c =  video_url: 'function/0/https://faapy.com/get_file/1/1209b8bc708dea4836ab494685daf627/10000/10267/10267.mp4/',
    d = licencekey

#    f = licencekey without dollar sign, but then get changed
#        g = 1; g < d.length; g++)
#        f += o(d[g]) ? o(d[g]) : 1;
    g = 1 # starts at 1 because of dollar sign
    f = ""
    while g < len(licencekey):
##        f += licencekey[g]
        if int(licencekey[g]) == 0:
            f += '1'
        else:
            f += licencekey[g]
##        Log("f='{}'".format(f))
            
        g += 1

    #return f #for debugging
    j = len(f)/2
##    Log("j='{}'".format(j))
    f = oo(f)

    k=''
##    for i in range(1,9):
##        k += licencekey[i]
    k = str(f)[0:j+1]    
    k = oo(k)
##    Log("k='{}'".format(k))

    L=''
    
##    for i in range(8,16):
##        L += licencekey[i]
##    Log("L='{}'".format(L))
    L = str(f)[j:]
    L = oo(L)
##    Log("L='{}'".format(L))
    #return L

    g = abs(L - k)
#    return g
##    g < 0 && (g = -g)
    f = g

    g = abs(k - L)
##    g < 0 && (g = -g)
##    Log("g='{}'".format(g))

    f += g
    f *= 2
    f = str(f)
##    Log("f='{}'".format(f))
#    return f
    i = oo(c) / 2 + 2
    #Log("i='{}'".format(i))
    m = ""
####    g = 0; g < j + 1; g++)
####        for (h = 1; h <= 4; h++)
####        n = o(d[g + h]) + o(f[g]),
####        n >= i && (n -= i),
####        m += n;
####    return m
    g = 0
    while g < (j+1) :
        h = 1
        while h <= 4:
            n = oo(d[g + h]) + oo(f[g])
            if n >= i:
                n -= i
            m = m + str(n)
##            Log("m='{}'".format(m))
            h += 1

        g += 1

    return m
####o =    return function(n, r) {
####            var o = String(n).trim()
####              , i = Number(r) || (t.test(o) ? 16 : 10);
####            return e(o, i)
####            }
##    return m


#__________________________________________________________________________
#
def oo(val):
    return int(filter(str.isdigit, str(val)))

def ConvertFaapyCode(code, salt):
# h = code
# i = salt
##for (var j = h, k = h.length - 1; k >= 0; k--) {
##    for (var l = k, m = k; m < i.length; m++)
##        l += parseInt(i[m]);
##    for (; l >= h.length; )
##        l -= h.length;
##    for (var n = "", o = 0; o < h.length; o++)
##        n += o == k ? h[l] : o == l ? h[k] : h[o];
##    h = n
##    }
## 1209b8bc708dea4836ab494685daf627
## 12345678901234567890123456789012
#fappysalt 48017908019764248681358958928927

    #xbmc.log("salt='{}', length={}".format(salt, len(salt)), xbmc.LOGNONE)
    #xbmc.log("code='{}', length={}".format(code, len(code)), xbmc.LOGNONE)
    j = salt
    h = code
    k = len(h)-1
    while k >= 0:

        L = k
        m = k
        while m < len(salt) :
            L = L + int(salt[m])
            m += 1

        while L >= len(h):
            L = L - len(h)

        n = ""
        o = 0
        while o < len(h):
            if o == k:
                n = n + h[L]
            else:
                if o == L:
                    n = n + h[k]
                else:
                    n = n + h[o]
                    
            o += 1

        h = n

##        Log(n)

        k -=1

    return n

##

#__________________________________________________________________________
#
def toString(a, b=10):
    #if a > 2000: return None #only tested to this number....algo may be wrong
    t = int(a)
    remainder = t % b
    val = t // b
    if val > 9:
        val = toString(val, b)
        s = str(val)
    elif val > 0:
        s = str(val)
    else:
        s = ""
    zero_offset = 48
    if remainder > 9:
        zero_offset +=7
    s += chr( zero_offset + remainder).lower()
    return s
        
#__________________________________________________________________________
#
def dePacked(p,a,c,k,e,d):
    c = int(c)
    a = int(a)
    while c > 0:
        c = c - 1
        if ( k[c] ): #skip the blanks
            p = re.sub('\\b' + toString(c, a) + '\\b', k[c], p, flags=re.DOTALL)
    return p

