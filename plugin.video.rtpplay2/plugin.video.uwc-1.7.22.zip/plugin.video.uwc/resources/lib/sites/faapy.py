'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]faapy[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://faapy.com"
SEARCH_URL = ROOT_URL + '/search/?q={}&from={}'
URL_CATEGORIES = ROOT_URL #+ '/video-categories'
URL_RECENT = ROOT_URL + '/latest-updates/{}/'

MAIN_MODE          = C.MAIN_MODE_faapy
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url)#, send_back_redirect=True)
    if "No results. Please broaden your search a" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('class="main"')[1].split('class="pagination"')[0]
        except:
            #utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    # parse out list items
    regex = 'class="item thumb.+?href="([^"]+)" title="([^"]+)".+?data-original="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb in info:
        hd = utils.Normalize_HD_String(label)
        if not videourl.startswith('http'): videourl = 'https:' + videourl
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , desc = '\n' + ROOT_URL
            , iconimage = thumb)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    # next page items
    try:
        next_page_html = listhtml.split('class="pagination"')[1]
    except:
        next_page_html = listhtml
    next_page_regex = 'class="next'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
##        Log("np_url={}".format(np_url))
        np_number = int(page) + 1
        np_url=url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)                    
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)
    regex = 'href="('+ ROOT_URL + '/category/[^"]+)" title="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label   in info:
        #Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl + 'most-popular/{}'
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=C.search_icon)

    utils.endOfDirectory(end_directory=end_directory)        
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL

    full_html = utils.getHtml(url, ROOT_URL) #, '', '', True)

    regex = "license_code: '(?P<lic>[^']+)'"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
    if not sources_list:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return 

##    regex_model = 'href=\"https://faapy\.com/model/(?P<model>[^/]+)'
##    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(videopage)
##    description = ''
##    desc_separator_char = '; '
##    if source_models:
##        for model in source_models:
##            description = description + desc_separator_char + model.group('model')
##    description = description.strip(desc_separator_char)
##    if description == '':  description=name + '\n' + ROOT_URL
##    else:           description=description + '\n' + ROOT_URL
####    Log("description={}".format(description))

    description = ''
    desc_separator_char = '; '
    regex_tags_region = '(.+)'
    regex_tags = 'href="https://faapy\.com/model/(?P<model>[^/]+)'
    region_html = re.compile(regex_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
    if region_html:
        source_tags = re.compile(regex_tags, re.DOTALL | re.IGNORECASE).findall(region_html[0])
        for tag in source_tags:
            if tag.lower() not in description.lower():
                description = "{}{}{}".format(description,utils.cleantext(tag),desc_separator_char)
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))
    

    license_code = sources_list.next().group('lic')
    list_key_value = {}
##    regex = "video(?:_alt|)_url.?: 'function\/0\/(?P<url>[^']+).+?(?:video(?:_alt|)_url\d?_text: '(?P<res>[^']+)p.*?')"
    regex = "video(?:_alt)?_url\d?:.+?'(?P<url>[^']+)'.+?video(?:_alt)?_url\d?_text:.+?'(?P<res>\d+)p.*?'"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
    for source_list in sources_list:
        if source_list.group('res'):
            list_key_value[source_list.group('res')] = source_list.group('url')
        else:
            list_key_value['240'] = source_list.group('url')
    Log("list_key_value={}".format(list_key_value))
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
##    encoded_url = utils.SortVideos(list_key_value,download=download,vid_res_column=0)
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )


    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return

    from resources.lib import resolver
    fappy_salt = resolver.FaapySalt(license_code, "")
    Log("fappysalt='{}'".format(fappy_salt))
    encoded_fappy_code =  video_url.split('/')[5][0:32] #32 is coincidentally(?) the length of the salt
    Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
##    new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
##    Log("new_fappy_code='{}'".format(new_fappy_code))
##    video_url = encoded_url.replace(encoded_fappy_code, new_fappy_code)

    import time
    video_url += "?rnd={}".format(int(time.time()*1000))

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url += utils.Header2pipestring(headers)

    Log("video_url='{}'".format(video_url))

##    return

    utils.playvid(video_url, name=name, download=download, description=description)
    return
    
##    license_code = '$379086812506737'
##    fappy_salt = C.FaapySalt(license_code, "")
##    Log("fappysalt='{}'".format(fappy_salt))
##
##    encoded_url = 'https://faapy.com/get_file/1/f46c1060b5c3520abac23776b87ce783b320ee5114/12000/12745/12745.mp4/'
##    #encoded_url = 'https://faapy.com/get_file/1/ccacb2356f56bc458b5e79262ddda58c117940a000/12000/12745/12745_360p.mp4/'
##    #encoded_url = 'https://faapy.com/get_file/1/742b473c1d4f042328acd9a306d06f019890850d6d/12000/12745/12745_240p.mp4/'
##
##    encoded_fappy_code =  encoded_url.split('/')[5]
##    Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
##
##    old_fappy_code = encoded_fappy_code[0:len(fappy_salt)]  #not sure if this applies to all sites
##
####    new_fappy_code = C.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
####    Log("new_fappy_code='{}'".format(new_fappy_code))
##
##    new_fappy_code_1 = C.ConvertFaapyCode(old_fappy_code,fappy_salt)
##    Log("new_fappy_code_1='{}'".format(new_fappy_code_1))
##
####    new_fappy_code_2 = C.ConvertFaapyCode(encoded_fappy_code[len(fappy_salt)+1:]  ,fappy_salt)
####    Log("new_fappy_code_2='{}'".format(new_fappy_code_2))
##
##    import time
##    video_url = encoded_url.replace(old_fappy_code, new_fappy_code_1)  + "?rnd={}".format(int(time.time()*1000))
##    Log("video_url={}".format(video_url))
##
##    description = ''
##
##    utils.playvid(video_url, name, download, description=description)
##
###                            '125a243bfb0b5e3a8c83770cc066776c'
###https://faapy.com/get_file/1/125a243bfb0b5e3a8c83770cc066776cb320ee5114/12000/12745/12745.mp4/?rnd=1594573389145
###https://faapy.com/get_file/1/125a243bfb0b5e3a8c83770cc066776cb320ee5114/12000/12745/12745.mp4/?rnd=159457583500
##
##    return
##
##    source_html1 = utils.getHtml(url, ROOT_URL)
###    source_html1 = "var flashvars = {video_id: '7416', license_code: '$379086812506737',lrc: '50803888',rnd: '1563261307',video_url: 'function/0/https://faapy.com/get_file/1/9473952ab83ad26e80e8910d6a3fcb49/7000/7416/7416.mp4/',video_url_hd: '1',postfix: '.mp4',video_url_text: '720p',video_alt_url: 'https://faapy.com/redirect_cs.php?id=50',video_alt_url_text: 'Pure 4K HD',video_alt_url_redirect: '1',timeline_screens_url: '//cdn.faapy.com/contents/videos_screenshots/7000/7416/timelines/hq_mp4/240x120/{time}.jpg',timeline_screens_interval: '3',preview_url: '//cdn.faapy.com/contents/videos_screenshots/7000/7416/preview.mp4.jpg" + "var flashvars = {video_id: '7416', license_code: '$379086812506737',lrc: '50803888',rnd: '1563261307',video_url: 'function/0/https://faapy.com/get_file/1/9473952ab83ad26e80e8910d6a3fcb49/7000/7416/7416.mp4/',video_url_hd: '1',postfix: '.mp4',video_url_text: '720p',video_alt_url: 'https://faapy.com/redirect_cs.php?id=50',video_alt_url_text: 'Pure 4K HD',video_alt_url_redirect: '1',timeline_screens_url: '//cdn.faapy.com/contents/videos_screenshots/7000/7416/timelines/hq_mp4/240x120/{time}.jpg',timeline_screens_interval: '3',preview_url: '//cdn.faapy.com/contents/videos_screenshots/7000/7416/preview.mp4.jpg"
##    regex = "license_code: '(?P<lic>[^']+)'.+?video_url: 'function\/0\/(?P<vid>[^']+)"
##    #regex = "license_code: '(?P<lic>[^']+)'.+?video_url: 'function\/0\/(?P<vid>[^']+).+?href=\"https://faapy.com/model/.+?title=\"\">(?P<model>[^<]+)<"
##		
##    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(source_html1)
##    for source_list in sources_list:
##        license_code = source_list.group('lic')
##        encoded_url = source_list.group('vid')
##        regex_model = "license_code.+?href=\"https://faapy.com/model/.+?title=\"\">(?P<model>[^<]+)<"
##        source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(source_html1)
##        description = ''
##        if source_models:
##            for model in source_models:
##                description = description + ' ' + model.group('model')
##
##    fappy_salt = C.FaapySalt(license_code, "")
####    Log("fappysalt='{}'".format(fappy_salt))
##    encoded_fappy_code =  encoded_url.split('/')[5]
####    Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
##    new_fappy_code = C.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
####    Log("new_fappy_code='{}'".format(new_fappy_code))
##    video_url = encoded_url.replace(encoded_fappy_code, new_fappy_code)
##                            
###    source_url_vars = source_url_vars[0]
###    Log("sources_list={}".format(sources_list))
###    video_url = utils.SortVideos(sources_list,0)
###    video_url = video_url.replace('\/','/') + utils.Header2pipestring() + '&Referer=' + url
##
####    json_sources = json.loads(source_url_vars)
####    Log("json_sources={}".format(json_sources))
####    Log("json_sources[quality_720p]={}".format(json_sources['quality_720p']))
##
####    if source_url_vars: #
####        2019 desktop version of page
####        #from: https://www.empflix.com/combine/tnaflix.desktop.js,flixplayer.desktop.js,lazyload.desktop.js,thumbplayer.desktop.js,tnaflix.desktop.channels.js,ws.js,suggest.js,dyn.js,textarea-caret-position.js,URL.js,tnaflix.desktop.notifications.js,perfect-scrollbar.js,sortable.js,flex-images.js,masonry.js,3be38.js,imagesloaded.js?1562849301
####        Log("source_url_vars={}".format(source_url_vars))
####        source_url_vars = source_url_vars[0]
####        source_url2 = "https://cdn-fck.empflix.com/empflix/"+source_url_vars[1] 
####        source_url2 += "-1.fid?key="+source_url_vars[3] 
####        source_url2 += "&VID="+source_url_vars[0]  
####        source_url2 += "&nomp4=1&catID=0&rollover=1&startThumb="+source_url_vars[2] 
####        source_url2 += "&embed=0&utm_source=0&multiview=0&premium=1&country=0user=0&vip=1&cd=0&ref=0&alpha"
####
####        Log("source_url2={}".format(source_url2))
####        source_html2 = utils.getHtml(source_url2, url)
####        regex = '<res>([^<]+).+?<videoLink><!\[CDATA\[([^\]]+)'
####        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
####        Log("sources_list={}".format(sources_list))
####        video_url = utils.SortVideos(sources_list,0)
####        video_url = C.html_parser.unescape(video_url)
####        Log("video_url={}".format(video_url))
####        video_url = "https:" + video_url + utils.Header2pipestring() + '&Referer=' + url
####        
####    else: #2018 mobile version  if you use an ipad header, but then you are limited in vid resolution
####        regex = '"contentUrl" content="([^"]+)"'
####        source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
####        source_url2 = source_url2[0]
####        video_url = source_url2 + utils.Header2pipestring() + '&Referer=' + url
####
####        regex = 'flashvars.config = escape."([^ ]+)&VID='
####        source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)[0]
####        source_url2 = source_url2 + utils.Header2pipestring() + '&Referer=' + url
####        #Log("source_url2={}".format(source_url2))
####        source_html2 = utils.getHtml(source_url2, url)
####        regex = '<videoLink>(.+?)</videoLink>'
####        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
####        #Log("sources_list={}".format(sources_list))
####        video_url = sources_list[0]
##
##    Log("video_url={}".format(video_url))
##        
##    utils.playvid(video_url, name, download, description=description)



#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
