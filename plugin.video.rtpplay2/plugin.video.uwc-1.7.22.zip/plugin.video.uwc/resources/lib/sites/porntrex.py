'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from random import randint
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]PornTrex[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_SCENES
FRONT_PAGE_CANDIDATE = True

ROOT_URL = "https://www.porntrex.com"
SEARCH_URL = ROOT_URL + "/search/{}/{}/?mode=async&function=get_block&block_id=list_videos_videos&q={}&category_ids=&sort_by=relevance&from_videos={}&from_albums={}"
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + "/latest-updates/{}/"
URL_CATEGORIES_PAGE= ROOT_URL + "/categories/{}/?mode=async&function=get_block&block_id=list_videos_common_videos_list_norm&sort_by=post_date&from4={}"

MAIN_MODE          = C.MAIN_MODE_porntrex
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1' #default first page

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    listhtml = utils.getHtml(list_url, referer=ROOT_URL, save_cookie=True)
    if "is no data in this list" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('class="porntrex-box"')[1].split('class="pagination"')[0]
        except:
            video_region = ""

    # main list items
    regex = '<img class=\"cover lazyload\" data-src=\"(?P<thumb>[^\"]+)\".+?class="quality">(?P<quality>[\d]+).+?clock-o\"><\/i>(?P<duration>[^<]+).+?href=\"(?P<url>[^\"]+)\" title=\"(?P<title>[^\"]+)\"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for thumb, hd, duration, videourl, label in info:
        #Log("hd={}".format(hd))
        hd = utils.Normalize_HD_String(hd)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        thumb = thumb.replace('1.jpg?v=3', str(randint(1,10)) + '.jpg' + utils.Header2pipestring() + '&Referer=' + ROOT_URL + '/' )
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc = '\n' + ROOT_URL
            , duration = duration)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    
    # next page items
    try:
        next_page_html = listhtml.split('class="pagination"')[1]
    except:
        next_page_html = listhtml
    next_page_regex = 'class="next"><a href="([^"]+)".+?from(?:_videos\+from_albums|4|):(\d+)'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url, np_number in np_info:
        #Log("np_url={}".format(np_url))
        if '/search/' in list_url:
            np_url = SEARCH_URL.format(keyword, np_number, keyword.replace('%20','+'), np_number, np_number )
        if '/categories/' in list_url:
            np_url = URL_CATEGORIES_PAGE.format(keyword, np_number )
        if not np_url.startswith('http'): np_url = ROOT_URL + np_url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url)
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace('+',' ').replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword, "1", keyword.replace('%20','+'), "1", "1" )
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))        
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, ROOT_URL)
    cathtml = re.compile('"list-categories"(.*)class="footer-margin', re.DOTALL).findall(html)[0]
    regex = 'href="([^"]+)" title="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label, thumb in info:
        thumb = "https:" + thumb + utils.Header2pipestring()+"&Referer=" + ROOT_URL + '/'
        keyword = videourl.split('/categories/')[1].split('/')[0]
        #Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,keyword=keyword
            )

    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

#Set-Cookie: PHPSESSID=907066da148fbe15f738349615955fe5; path=/; domain=.porntrex.com
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
##    headers['Cookie'] = 'kt_member=El3ment.javbangers.com;'
    full_html = utils.getHtml(url, headers=headers)
    
    license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(full_html)
    if license_code:
        license_code = license_code[0]
    else:
        Log("url='{}'".format(url), xbmc.LOGNONE)
        utils.Notify("No license_code found for {}".format(name))
        return

    #full_html = ''
    regex = "video(?:_alt|)_url\d?: '([^']+)',.+?video(?:_alt|)_url\d?_text: '(\d+)"
    sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    if not sources: sources =[] #fake data so that next code can look simpler
    video_url = utils.SortVideos(
        sources=sources
        ,download=download
        ,vid_res_column=1
        ,max_video_resolution=max_video_resolution
        )

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return
    
    video_url += "?_rnd=" + utils.RandomNumber()

    from resources.lib import resolver
    Log("license_code='{}'".format(license_code) )
    fappy_salt = resolver.FaapySalt(license_code, "")
    Log("fappysalt='{}'".format(fappy_salt))
    old_fappy_code =  video_url.split('/')[5]
    Log("old_fappy_code='{}'".format(old_fappy_code))
    new_fappy_code = resolver.ConvertFaapyCode( old_fappy_code, fappy_salt)
    Log("new_fappy_code='{}'".format(new_fappy_code))

    #videourl = videourl.replace(old_fappy_code, new_fappy_code)

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
##    hdr['Cookie'] = 'PHPSESSID=' + utils.addon.getSetting('session') + '; kt_member=' + utils.addon.getSetting('kt_member')
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return
    utils.playvid(video_url, name=name, download=download, description=description)
        
#__________________________________________________________________________
#

