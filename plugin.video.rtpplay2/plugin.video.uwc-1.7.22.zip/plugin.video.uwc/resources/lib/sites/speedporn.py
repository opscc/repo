'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]speedporn[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_MOVIES
    _FRONT_PAGE_CANDIDATE = False
    
    _ROOT_URL        = "https://speedporn.net"
    _URL_CATEGORIES  = _ROOT_URL + '/categories/'
    _URL_RECENT      = _ROOT_URL + '/page/{}/'
    _SEARCH_URL      = _ROOT_URL + '/page/{}/?s={}'

    _MAIN_MODE = C.MAIN_MODE_speedporn

    _FIRST_PAGE = '1'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        ]

    #where we can find videos on this page [exclude advertisement]
    
    #videos on this page
    _REGEX_video_region = 'class="video-loop"(.+?)class="hero"'
    _REGEX_list_items = (
        'class="thumb" href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?span class="title">(?P<label>[^<]+)</span'
        '(?P<hd>)'
        '(?P<duration>)'
        )

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'class="pagination(.+?)class="hero"'
    _REGEX_next_page_regex = '(class="next page-link")'

    #if we need to save html cookies
    _SAVE_COOKIES = False

    #where categories can be found
    _REGEX_categories_region = (
        'class="entry-content"(.+?)class="hero"'
        )
    _REGEX_categories = (
        'class="thumb" href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        )

    #where playable urls live
    _REGEX_play_region = (
        'id="pettabs"(.+?)class="video-title"'
        )
    _REGEX_playsearch_01 = (
        C.FLAG_USE_RESOLVER_ONLY
##        'data-hls-src(?P<res>\d+)'
##        '="(?P<url>[^"]+)"'
        )

    #description for the playable url
    _REGEX_tags_region = 'id="video-about"(.+?)id="video-tags"'
    _REGEX_tags = '/pornstars/.+?>([^<]+)<'

    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return url + '/page/{}/'

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format('{}', keyword)

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None, testmode=False):
    website.Playvid(url, name, download, playmode_string, testmode=testmode)
#__________________________________________________________________________
#
