'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import json
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]Tube8[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.tube8.com"
SEARCH_URL = ROOT_URL + '/search.php?keywords={}&page={}' #pre 2019-11-25
#https://www.tube8.com/searches.html?q=sisters&page=2
SEARCH_URL = ROOT_URL + '/searches.html?q={}&page={}'
URL_CATEGORIES = ROOT_URL + '/categories.html'
URL_RECENT = ROOT_URL + '/newest/page/{}/'
URL_TOPRATED = ROOT_URL + "/top-rated-porn-videos/page/{}/"
URL_MOSTVIEWED = ROOT_URL + "/most-viewed-porn-videos/page/{}/"

MAIN_MODE          = C.MAIN_MODE_tube8
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon
        )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    listhtml = utils.getHtml(list_url, ignore404=True)
    regex = "<br/>.+?<p>Sorry, we couldn't find any pages containing"
    if ("but no results were found" in listhtml) or (len(re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml))>0):
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            regex = 'id="(?:home|search|videos)_page_wrapper"(.+?)(?:_page_wrapper.?-->|id="pagination")'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            video_region = listhtml
        #Log("video_region={}".format(video_region))

    #
    # parse out list items
    #
    regex = 'data-video_url=\"([^\"]+)\"' \
            + '.+?data-thumb=\"([^\"]+)\"' \
            + '.+?title=\"([^\"]+)\"' \
            + '.+?class=\"video-attributes-features\">(.+?)</span>' \
            + '.+?video-duration\">([^<]+)<'
    #Log("regex={}".format(regex))
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, hd, duration in info:
        hd = utils.Normalize_HD_String(hd)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc = '\n' + ROOT_URL
            , duration = duration)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)


    # next page items
    next_page_regex = 'id=\"pagination\".+href=\"([^\"]+)\".id=\"pagination_next\"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
            np_url = url
            np_number = int(page) + 1
##            Log("np_number={}".format(np_number))
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=1):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url, ROOT_URL)

    cat_html = listhtml.split("most_categories")[1].split("</header>")[1]
 
    regex = 'a href="([^"]+)"' \
            + '.+?data-thumb="([^"]+)"' \
            + '.+?<h5>([^<]+)<' 
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cat_html)
    for videourl, thumb, label in info:
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl+'page/{}/'
            ,page=FIRST_PAGE
            ,mode=LIST_MODE 
            ,iconimage=thumb )
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    full_html = utils.getHtml(url, ROOT_URL)

    if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
        return
    
    regex = ',"mediaDefinition":(.+?)}]'
    video_source_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    if video_source_html: video_source_html=video_source_html[0]
    else: video_source_html = ''
    
    #regex = 'page_params.videoUrlJS = "([^"]+)'
    regex = '"quality":(\d+),"videoUrl":"([^"]+)"'
    video_sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_source_html)
    Log("video_sources='{}'".format(video_sources))
    video_url = utils.SortVideos(
        sources=video_sources
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )
    
    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return

    video_url = video_url.replace('\/', '/')

    regex_model = 'data-pornstar_id="\d+".*?>(?P<model>[^<]+)<(?:/a>|/span></div>)'
    regex_model = '(?:data-esp-node=\'pornstar\'>.+?|data-esp-node="category"|/porntags/\w+/")>(?P<model>[^<]+)<'
    regex_model = '(?:data-esp-node=\'pornstar\'>.+?|/porntags/\w+/")>(?P<model>[^<]+)<'
    regex_model = '(?:data-esp-node=\'pornstar\'>.+?)>(?P<model>[^<]+)<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).findall(full_html)
    description = ''
    desc_separator_char = '; '
    for model in source_models:
        if model.lower() not in description.lower():
            description = description + utils.cleantext(model) + desc_separator_char
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
