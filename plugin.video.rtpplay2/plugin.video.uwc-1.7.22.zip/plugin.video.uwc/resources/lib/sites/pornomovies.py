'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]pornomovies[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.pornomovies.com"
SEARCH_URL = ROOT_URL + '/search/{}/{}/'
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/latest-updates/{}/'

MAIN_MODE          = C.MAIN_MODE_pornomovies
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, ignore404=True) #, send_back_redirect=True)
    if "Sorry, no results were found" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            regex = '(?:<!-- title END -->|id="vidresults")(.+?)(?:class="numlist2"|id="pagination")'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            video_region = listhtml

    # parse out list items
    regex = 'class="item thumb".+?href="([^"]+)".+?title="([^"]+)".+?data-src="([^"]+)".+?class="time">([^<]+)' #2020-11-30
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, duration in info:
        hd = utils.Normalize_HD_String(label)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label={}".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    # next page items
    try:
        regex = 'class="pagination"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
    next_page_regex = "(>Next</a></li>)"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_url = url
        np_number = int(page) + 1
##            Log("np_url={}".format(np_url))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace('+',' ').replace(' ','-') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    
    source_html = utils.getHtml(url, ROOT_URL)
    regex = "flashvars.+?license_code:.+?'(?P<lic>[^']+)'"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(source_html)
    license_code = sources_list.next().group('lic')
##    Log("license_code={}".format(license_code))

    list_key_value = {}
    #regex = "(?:video_url|video_alt_url.?): '(?P<url>[^']+).+?(?:video_url|video_alt_url.?)_text: '(?P<res>\d+)p'"
    #site does not include video_url_text when only one source
    regex = "(?:video_url|video_alt_url.?): '(?P<url>[^']+).+?(?:postfix:|video_url_text:|video_alt_url.?_text:) '(?P<res>[^']+)'"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(source_html)
    for source_list in sources_list:
        res = source_list.group('res')
        if res:
            if res == '.mp4': res = '480'
            list_key_value[res] = source_list.group('url')
        else:
            list_key_value['240'] = source_list.group('url')
    Log("list_key_value={}".format(list_key_value))

    if len(list_key_value) < 1:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    
    if video_url.startswith("function/0/"):
        video_url = video_url.split("function/0/")[1]
        Log("video_url={}".format(video_url))

    from resources.lib import resolver


    fappy_salt = resolver.FaapySalt(license_code, "")
    Log("fappysalt='{}'".format(fappy_salt))
    encoded_fappy_code =  video_url.split('/')[5][0:32]
    Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
    new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
    Log("new_fappy_code='{}'".format(new_fappy_code))
    video_url = video_url.replace(encoded_fappy_code, new_fappy_code)
    video_url += '?rnd=' + utils.RandomNumber(length=13)

    if '|' not in video_url:
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#

