# -*- coding: utf-8 -*-

#import base libraries
import datetime
import json
import os
import re
import traceback
#import internal addon libraries
import utils
import player
#define frequenctly used aliases
import constants as C
from utils import Log,LogR,Notify


BASE = 'https://iptv-org.github.io/iptv/countries/{}.m3u'

try: cache_duration = int(utils.get_setting('html_cache_sportsdaddy'))
except: cache_duration = 300

DEFAULT_SORT_ORDER = 30.0

###__________________________________________________________________________
###
##def add_icons(plugin, play, subchannel='', subchannel_label='', sort_order=None):
####    Log(repr((subchannel,subchannel_label,sort_order)))

MAIN_MODE          = C.MAIN_MODE_iptvorg
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
LIST_ROW_MODE      = str(int(MAIN_MODE) + 6)

#__________________________________________________________________________
#
##def add_icons(plugin, play, subchannel='', subchannel_label='', sort_order=None):
####    Log(repr((subchannel,subchannel_label,sort_order)))
@C.url_dispatcher.register(LIST_MODE)
def add_icons(
                subchannel = u''
              , subchannel_label = u''
              , sort_order = DEFAULT_SORT_ORDER
              , cache_as_json = False  
              , testmode = False
              , end_directory = False):

    try:

        if not subchannel: return  #for this set, only allow specific channels

        #for this site subchannel is
        #    <Country_code>/<string that matches a channel in M3U8 file>
        #    e.g 'US/Grit Xtra'
        #    e.g 'CA/CityNews Toronto'
        
        channel = subchannel
        program_name = subchannel #ignore program name because we don't have a tvguide for this

        sort_order = float(sort_order)


        #https://zhangboheng.github.io/Easy-Web-TV-M3u8/routes/countries.html
        
        #only figure this out during actual playback because the regex search can be slow on old hardware
        playable_url = subchannel
        
        icon_label = u"[COLOR {}][B]{}[/B][/COLOR]".format(
            C.channel_text_color
             , subchannel_label
            )
        if subchannel:
            icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon
        else:
            icon = ""

        utils.Add_Listitem(
            mode = PLAY_MODE
            ,icon_label = icon_label
            ,url = playable_url
            ,program_name = program_name
            ,channel = subchannel
            ,icon = icon
            ,module_name = __name__.split('.')[-1]
            ,rating = sort_order
            ,playmode_string = u''
            ,play_profile = u''
            ,testmode = testmode
            ,cache_as_json = cache_as_json
            ,is_folder = False)

        return playable_url

    except:
        LogR(locals())
        raise

###__________________________________________________________________________
###
@C.url_dispatcher.register(PLAY_MODE, ['icon_label','url'], ['channel', 'program_name', 'icon', 'playmode_string', 'play_profile','download', 'testmode'])
def play( icon_label
         ,url
         ,channel=u''
         ,program_name=u''
         ,icon=None
         ,playmode_string=None
         ,play_profile=None
         ,download=None
         ,testmode=False):

    try:    

        download = bool(download)
        testmode = bool(testmode)
            
        #
        #various download options
        #
        download_filespec = None
        if download:
            dt = datetime.datetime.now().strftime('%Y-%m-%d')
            d_name = u"{}.{}.{}.ts".format(utils.Clean_Filename(icon_label), utils.Clean_Filename(icon_label).strip(' '), dt)
            download_filespec = utils.get_setting('download_path')
            if not download_filespec:
                download_filespec = None
            else:
                download_filespec = os.path.join(download_filespec, d_name)
        #
        #f4mproxy defaults
        #
        if not playmode_string:
            playmode_string = C.PLAYMODE_DIRECT
        if playmode_string not in C.PLAYMODE_F4MPROXY:
            play_profile = None
        else:
            if play_profile not in C.VALID_PLAYMODE_PROFILES:
                play_profile = C.PLAYMODE_PROFILE_01
            

        if program_name: program_name = " ({})".format(program_name)
        play_label = u"[COLOR {}][B]{}[/COLOR]{}".format(
            C.channel_text_color
            , icon_label
            , program_name)


        #
        #channel include country of origin and search string
        #
        country = channel.split('/')[0].lower()
        search_string = channel.split('/')[1].lower()
        m3u_src = utils.getHtml(BASE.format(country)  , cache_duration=cache_duration)

        search_string = C.urlparse.unquote(search_string)  #so that i can pass braces within searchstring

        m3u8_url = None
        agent = None
        possible_match_regex = [
             r'#EXTINF:-1 tvg-id="{}".*?\n#EXTVLCOPT:http-user-agent=(.*?)\n(http.+?)\n'.format(search_string)   #2025-02-114
            ,r'#EXTINF:.+?,{}.*?\n()(.+?)(?:\r|\n)'.format(search_string)   #2024-07-16
            ]

        for regex in possible_match_regex:
            m3u8_url_search = re.compile(regex, re.DOTALL|re.IGNORECASE).search(m3u_src)
            if m3u8_url_search:
                m3u8_url = m3u8_url_search.group(2)
                agent = m3u8_url_search.group(1)
                break
        if not m3u8_url: m3u8_url='not found'

        if agent:
            headers = {"User-Agent": agent }
        else:
            headers = {}
    ##    Log(repr(headers))        

        video_url = m3u8_url + utils.Header2pipestring(headers) 
        Log(repr(video_url))

        m3u8 = utils.getHtml(video_url, cache_duration=0) #sometimes it is better to get this before playing


        #
        #what to do if we are just testing
        #
    ##    testmode=True
    ##    testmode=False
        if testmode:
            Log(repr(( "warning TESTMODE:"
                        , video_url
                        , play_label
                        , playmode_string
                        , play_profile
                        , download
                        , download_filespec
    ##                    , m3u8_url
    ##                    , headers
                      )))
            utils.getHtml(m3u8_url,headers=headers)
            utils.endOfDirectory(end_directory=False)
            return


        #
        #what to do if we are serious
        #
        player.playvid(
            video_url
            , name=play_label
            , playmode_string=playmode_string
            , play_profile=play_profile
            , download = download
            , download_filespec=download_filespec
        )

    except:
##        LogR(locals())
        raise
    
###__________________________________________________________________________
### Unit tests
@C.url_dispatcher.register(TEST_MODE)
def TEST_MODE():
    test_label = ""
    module_name = __name__.split('.')[-1]
    try:
        
        test_label = u'{}€ download html and add all categories'.format(module_name)
        playable_url = add_icons(
            subchannel = u'{}'.format('PT/RTP3.pt') #case sensitive!
          , subchannel_label = u"€ RTP3.pt €"
          , testmode = True
          )
        Log(playable_url)

        test_label = u'pla PT/RTP3.pt  gory'.format(module_name)
        play(  icon_label = test_label
             , channel = 'PT/RTP3.pt'
             , url = playable_url
             , testmode=True
             )

        test_label = u'{}€ S/Grit X 3'.format("TVIPT"   )
        play(  icon_label = test_label
             , channel = 'US/Grit Xtra'     
             , url = playable_url
             , playmode_string = C.PLAYMODE_F4MPROXY
             , play_profile = C.PLAYMODE_PROFILE_03
             , testmode = True
             )

        test_label = u'{}€ S/Grit X 3'.format("TVIPT"   )
        play(  icon_label = test_label
             , channel = 'CA/CityNews Toronto'
             , url = playable_url
             , playmode_string = C.PLAYMODE_F4MPROXY
             , play_profile = C.PLAYMODE_PROFILE_03
             , testmode = True
             )


        test_label = u'€ PT/RTP3.pt imputstream'.format("SICPT")
        play(  icon_label = test_label
             , channel = 'PT/RTP3.pt' #'CA/CityNews Toronto'
             , url = playable_url
             , playmode_string = C.PLAYMODE_INPUTSTREAM 
             , testmode = True
             )
        
    
        test_label = u'{}€ download'.format(module_name)
        play(
             url =  playable_url
             , icon_label = test_label
             , channel =  u'{}'.format('PT/RTP3.pt')
             , download = True
             , testmode = False
             )

    except Exception as e:
        traceback.print_exc()
        raise Exception(test_label)

##    if test_label:
##        raise Exception(test_label)
    
#__________________________________________________________________________
#

