# -*- coding: utf-8 -*-

import traceback
import json
import threading
import os
        
import utils
import downloader as D
import constants as C
from constants import BaseHTTPServer
from constants import urlparse
from utils import Log,LogR,Notify

#__________________________________________________________________________
#
class downloaderHTTPRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    sys_version = ""
    
    def do_HEAD(self):
        self.send_response(200)
        self.send_header('Connection', 'close')
        self.end_headers()
        self.finish()
        Log("self.server.shutdown()", C.LOGNONE)
        self.server.shutdown()
        os._exit(0)

    def log_message(self, format, *args):
        return #"""Disables the BaseHTTPServer log."""

    def do_POST(self):
        Log(repr(vars(self))
##            , C.LOGNONE
            )

        try:

            #fail by default
            response = ""
            response_code = 400
            reponse_content_type = 'text/plain'

            #confirm this is the right type of content
            request_content_type = self.headers['Content-Type']
            if not request_content_type in ['application/json']:
                response = u"Unknown content type '{}'".format(request_content_type)
                raise Exception(response)

            #read data to json structure and do some basic validation
            data_string = self.rfile.read(int(self.headers['Content-Length']))
            if C.PY3: data_string = str(data_string,'utf8')
            Log(repr(data_string))
            data = json.loads(data_string)
            assert (data[D.ATTRIB_cmd] in D.WEB_COMMANDS)
            assert (data[D.ATTRIB_type] in D.DOWNLOAD_ATTRIBUTES)

            #perform actions
            proxy_thread = None
            if data[D.ATTRIB_cmd] == D.CMD_download:
                if data[D.ATTRIB_type] == C.TYPE_hls:

                    stop_event = threading.Event()
                    download_path = data[D.ATTRIB_path]
                    if download_path is None:
                        download_path = D.Make_download_path(data[D.ATTRIB_name], file_extension = '.ts')                    

                    proxy_thread = utils.ThreadWithStopEvent(
                        target=D.Background_HLSDownloader
                        ,stop_event=stop_event
                        ,args=(data[D.ATTRIB_url]
                               , download_path
                               , data[D.ATTRIB_name]
                               , stop_event
                               , data[D.ATTRIB_repeat]
                               , None)
                        )

                elif data[D.ATTRIB_type] == C.TYPE_mp4:

                    stop_event = threading.Event()
                    download_path = data[D.ATTRIB_path]
                    if download_path is None: download_path = D.Make_download_path(data[D.ATTRIB_name], file_extension = '.mp4')

                    proxy_thread = utils.ThreadWithStopEvent(
                        target=D.Background_MP4Downloader
                        ,stop_event=stop_event
                        ,args=(data[D.ATTRIB_url]
                               , data[D.ATTRIB_name]
                               , data[D.ATTRIB_mode]
                               , data[D.ATTRIB_url_factory]
                               , data[D.ATTRIB_icon_uri]
                               , download_path
                               , stop_event
                               , None)
                        )


                save_thread_info = None
                if proxy_thread:
                    save_thread_info = self.server.thread_cache.set(
                        endpoint = C.DOWNLOAD_INDICATOR+data[D.ATTRIB_name]
                        , data = (proxy_thread, str(data_string))
                        )

##                #devtesting
##                cache_data = self.server.thread_cache.show() #devtest
##                assert( C.DOWNLOAD_INDICATOR+data[D.ATTRIB_name] in cache_data)#devtest
                    
                if save_thread_info: 
                    if proxy_thread:
                        proxy_thread.daemon = True
                        proxy_thread.start()
                        response = u"Download begun for '{}'".format(repr(proxy_thread))
                    else:
                        response = u"Failed to begin download for [offline?] '{}'".format(repr(proxy_thread))
                        Log('often seen when download scheduled for offline model')
                else:
                    response = u"Not starting active '{}'".format(repr(proxy_thread))
                r = []
                r.append(response)
                response = json.dumps(r)
                
            elif data[D.ATTRIB_cmd] == D.CMD_list:
                cache_data = self.server.thread_cache.show()
                Log(repr(cache_data))
                if len(cache_data) > 0:
                    response = []
                    for item in cache_data:
                        response.append(cache_data[item][1])
                    Log(repr(response))
                    response = json.dumps(response)
                else:
                    response = u"[]"


            elif data[D.ATTRIB_cmd] == D.CMD_cancel:
                #r = []
                r = {}
                cancel_thread = self.server.thread_cache.get(C.DOWNLOAD_INDICATOR+data[D.ATTRIB_name])
                if cancel_thread:
                    cancel_thread = cancel_thread[0]
                    if cancel_thread:
                        cancel_thread._stop_event.set()
                    self.server.thread_cache.pop(C.DOWNLOAD_INDICATOR+data[D.ATTRIB_name])
                    response = u"Stop event set for '{}'".format(data[D.ATTRIB_name])
                    #r.append(response)
                    r[D.ATTRIB_return_code] = D.SUCCESS
                    r[D.ATTRIB_message] = response
                    response = json.dumps(r)
                else:
                    response = u"Name '{}' does not appear to exist".format(data[D.ATTRIB_name])
##                    r.append(response)
                    r[D.ATTRIB_return_code] = D.NOT_ACTIVE
                    r[D.ATTRIB_message] = response
                    response = json.dumps(r)
                

                
            else:
                response = u"Unknown {} type '{}'".format(D.ATTRIB_cmd, data[D.ATTRIB_cmd])
                raise Exception(response)
                

            #response = data_string.encode('utf8')
            reponse_content_type = 'application/json; charset=UTF-8'
            response_code = 200
        except Exception as ex:
##            Log(repr(dir(ex)))
            response = repr(ex)
            traceback.print_exc()
        finally:
            self.send_response(response_code)
            self.send_header('Connection', 'close')
            self.send_header('Content-Type', reponse_content_type)
            self.end_headers()
            Log(repr(response))
            if C.PY2:
                self.wfile.write(response)
                self.finish()
            else:
                self.wfile.write(bytearray(response, 'utf8'))

#__________________________________________________________________________
#

