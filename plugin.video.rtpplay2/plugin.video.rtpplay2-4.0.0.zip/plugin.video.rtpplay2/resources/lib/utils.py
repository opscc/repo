#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import datetime
import json
import os.path
import random
import re
import requests
import simplecache
import sqlite3
import socket
import sys
import time
import traceback
import threading
import unicodedata
import urllib

import importlib
import operator
import collections
    
import urllib3

from xml.dom import minidom
    
from constants import urllib2
from constants import cookielib
from constants import StringIO
    
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import constants as C

from constants import quote
from constants import quote_plus
from constants import urlparse
from constants import urlencode
from constants import HTMLParser
from constants import StringIO

my_http_session = requests.Session()
from urllib3 import ProxyManager, PoolManager
if C.certPath:
    pool_proxy = PoolManager(ca_certs=C.certPath)
else:
    pool_proxy = PoolManager()


### fake cache created to check memory usage
### ... appears to be zero cost.... memory collection?...
### ram seems to be related to number of thumbnails(size) / skin viewtyep / other things?
class FakeCache():
    empty = json.loads("[]")    
    def get(self,endpoint):
        return self.empty
    
    def set(self,endpoint,data,expiration):
        return
##global_cache = FakeCache()
global_cache = simplecache.SimpleCache()
global_mem_cache = simplecache.SimpleCache()
global_mem_cache.enable_mem_cache= False
global_mem_cache_lock = threading.Lock()
CACHE_STRING = "gmc"

monitor = xbmc.Monitor()

LINKS_DB_VERSION_1 = 1
DB_VERSION_CURRENT = LINKS_DB_VERSION_1
TABLE_NAME = 'links'
linksdb = C.linksdb


#__________________________________________________________________________
#
def Log(msg='', loglevel=None, stacklevel=2):
    if not msg: msg = u""
    if not isinstance(msg, C.text_type):
        if C.PY3: msg = str(msg,'utf8','ignore')
        if C.PY2: msg = msg.decode('ascii','ignore').encode('utf8')
        #msg = unicode(msg.decode('utf-8', 'ignore'))
    try: 
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
            ,traceback.extract_stack(limit=stacklevel)[0][1]
            ,msg
            )
    except:
        pass
    if C.PY3: msg = "{}: {}".format(C.addon_id, msg )
    if C.PY2: msg = "{}: {}".format(C.addon_id, msg.encode('utf-8',errors='ignore') )
    if  loglevel: xbmc.log(msg , loglevel)
    elif C.DEBUG:  xbmc.log(msg , xbmc.LOGNONE)
    else:    xbmc.log(msg)
#__________________________________________________________________________
#
def LogR(msg='', loglevel=None):
    Log(repr((type(msg), msg)), loglevel, stacklevel=3)
#__________________________________________________________________________
# routine for PY2/PY3 compatibility
def s_e(s):
    if C.PY2:
        #change unicode to str or bool,float,int to str
        if type(s) in [str]:
            return s
        elif type(s) in [bool,float,int]:
            return str(s)
        elif s is None:
            return s
        else:
            return s.encode('utf8')
    else:
        if type(s) in [bool,float,int]:
            return str(s)
        elif s is None:
            return s
        else:
            return s
def s_d(s):
    if C.PY2:
        #cast str to unicode
        if s and not isinstance(s, C.text_type):
            return s.decode('utf8')
        else:
            return s
    else:
        return s
    
#__________________________________________________________________________
#
def routing_url_for(mode
                    ,icon_label = u''
                    ,url = u''
                    ,program_name = u''
                    ,channel = u''
                    ,icon = u''
                    ,module_name = u''
                    ,rating = u''
                    ,filter_category = u''
                    ,playmode_string = u''
                    ,play_profile = u''
                    ,download = False
                    ,is_folder = False
                    ,testmode = False
                    ,end_directory = True
                    ,cache_as_json = False
                    ):

    
    try:
        u = sys.argv[0] 
        u = u + "?mode=" + str(mode) 
        u = u + "&icon_label=" + quote_plus(s_e(icon_label))
        u = u + "&url=" + quote_plus(str(url)) 
        u = u + "&program_name=" + quote_plus(s_e(program_name))
        u = u + "&channel=" + quote_plus(s_e(channel))
        u = u + "&icon=" + quote_plus(s_e(icon))
        u = u + "&module_name=" + quote_plus(s_e(module_name))
        u = u + "&rating=" + quote_plus(s_e(rating))
        u = u + "&playmode_string=" + quote_plus(s_e(playmode_string)) 
        u = u + "&play_profile=" + quote_plus(s_e(play_profile))
        u = u + "&filter_category=" + quote_plus(s_e(filter_category)) 
        u = u + "&download=" + s_e(download)
        u = u + "&testmode=" + s_e(testmode)              
        u = u + "&is_folder=" + s_e(is_folder)              
        u = u + "&end_directory=" + s_e(end_directory)

        if not cache_as_json:
            return u 
        else:
            # performance testing shows that, on a slow computer, each cache.set can take 200ms therefore I am tring to minimize them
    ##            t_start = datetime.datetime.now()
    ##            Log("t_start {}".format(threading.currentThread().ident))
            json_item = {}
            json_item['mode'] = mode
            json_item['icon_label'] = icon_label
            json_item['url'] = u
            json_item['program_name'] = program_name
            json_item['channel'] = channel
            json_item['icon'] = icon
            json_item['module_name'] = module_name
            json_item['rating'] = rating
            json_item['is_folder'] = is_folder
            json_item['filter_category'] = filter_category
    ##        json_item['main_url'] = main_url

            Add_To_Cache(json_item)
            return u

    ##        net = (datetime.datetime.now()-t_start).total_seconds()
    ##        if net > 1: Log(repr((net,json_item)))
    ##        Log("return_json_info={:.0f}ms".format( net*1000 ) )
            return None
    except:
        LogR(locals())
        raise

def Add_Listitem(    mode
                    ,icon_label = u''
                    ,url = u''
                    ,program_name = u''
                    ,channel = u''
                    ,icon = C.default_icon
                    ,module_name = u''
                    ,rating = u''
                    ,filter_category = u''
                    ,playmode_string = u''
                    ,play_profile = u''
                    ,download = False
                    ,testmode = False
                    ,cache_as_json = False
                    ,is_folder = False
                     ):

##    LogR(locals())
##    Log('Add_Listitem')
##    Log(repr(icon_label))
##    Log(repr(rating))
##    cache_as_json = cache_as_json and is_folder==False #when we accidentally set a folder to be cached


    default_url = routing_url_for(
        mode = mode
        , url = url
        , icon_label = icon_label
        , channel = channel
        , rating = rating
        , icon = icon
        , program_name = program_name
        , playmode_string = playmode_string
        , play_profile= play_profile
        , module_name = module_name
        , filter_category = filter_category
        , download = download
        , testmode = testmode
        , cache_as_json = cache_as_json
        , is_folder = is_folder
        )

    if cache_as_json:
        return default_url

    #context options for item
    contextMenuItems = []
    context_url = routing_url_for(mode
            , icon_label=icon_label                                  
            , url=url
            , channel=channel
            , icon=icon
            , program_name=program_name
            , playmode_string = C.PLAYMODE_DIRECT
            , module_name = module_name
            , filter_category = filter_category
            , testmode = testmode
            , cache_as_json = cache_as_json
            )
##    LogR(context_url)

    
    contextMenuItems.append(
        (
        "[COLOR {}]{}[/COLOR]".format(C.time_text_color, 'Play Direct')
        , "PlayMedia({})".format(context_url)
        )
    )
    context_url = routing_url_for(mode
            , icon_label=icon_label
            , url=url
            , channel=channel
            , icon=icon
            , program_name=program_name
            , playmode_string = C.PLAYMODE_INPUTSTREAM
            , module_name = module_name
            , filter_category = filter_category
            , testmode = testmode
            )
    contextMenuItems.append(
        (
        "[COLOR {}]{}[/COLOR]".format(C.time_text_color, 'Play Inputstream')
        , "PlayMedia({})".format(context_url)
        )
    )
    for n in range(1,4,1): #starting at zero would incude download
        context_url = routing_url_for(
            mode
            , url=url
            , icon_label=icon_label
            , channel=channel
            , icon=icon
            , program_name=program_name
            , playmode_string = C.PLAYMODE_F4MPROXY
            , play_profile="profile_0{}".format(n)
            , module_name = module_name
            , filter_category = filter_category
            , testmode = testmode
            )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_0{}_alias".format(n)), C.PLAYMODE_F4MPROXY)
            ,"PlayMedia({})".format(context_url)
            )
            )
    context_url = routing_url_for(mode
        , url=url
        , icon_label=icon_label
        , channel=channel
        , icon=icon
        , program_name=program_name
        , playmode_string = C.PLAYMODE_F4MPROXY
        , play_profile="profile_00"
        , module_name = module_name
        , filter_category = filter_category
        , download = True
        , testmode = testmode
        )
    contextMenuItems.append(
            (
            "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, 'Download')
            , "PlayMedia({})".format(context_url)
            )
        )


    #the main listitem
    list_item = xbmcgui.ListItem(icon_label)
    list_item.setArt({"thumb": icon}) #setting fanart will cause extra network traffic to get latest image
    list_item.setContentLookup(False)
    list_item.setProperty('IsPlayable', 'true')

    if C.PY2:
        list_item.setInfo(type="video", infoLabels={
                                                    "sorttitle": "a{:0>10}".format(int(rating))
                                                    ,"playcount":"0" #remove the filled in circle from our skin
                                                    } )        
    if C.PY3:
        list_item.getVideoInfoTag().setSortTitle("a{:0>10}".format(int(rating)))
        list_item.getVideoInfoTag().setPlaycount(0)
    if not is_folder:
        list_item.addContextMenuItems(
            contextMenuItems
            , replaceItems=False
            )

    #add the listitem
##    if sys.argv[1]:
    if sys and sys.argv and len(sys.argv)> 1 and sys.argv[1]:
        xbmcplugin.addDirectoryItem(
            int(sys.argv[1])
            , default_url
            , list_item
            , isFolder=is_folder
            )
    else:
        Log('h3')

    return default_url #always return default url
#__________________________________________________________________
#
def Add_To_Cache(data, cache_duration=None):
    if not cache_duration:
        cache_duration=get_setting("min_service_interval", int)

    global_mem_cache_lock.acquire()
    try:
        if get_setting("use_dbcache", bool):
            Insert_Table(data, db_connection=sqlite3.connect(C.linksdb)) #,check_same_thread = False))
        elif get_setting("use_memcache", bool):
            size = global_mem_cache.get(\
                endpoint = (CACHE_STRING+'_size')\
                )
            if size: size = int(size)
            else: size = 0
            size = size+1
            global_mem_cache.set(\
                 endpoint = (CACHE_STRING+"_icons+"+str(size))\
                 ,data = data\
                 ,expiration = datetime.timedelta(seconds=cache_duration)\
                 )
            global_mem_cache.set(\
                 endpoint = (CACHE_STRING+'_size')\
                 ,data = size\
                 ,expiration = datetime.timedelta(seconds=cache_duration)\
                 )
    except:
        traceback.print_exc()
    finally:
        global_mem_cache_lock.release()

#__________________________________________________________________
#
def TableCreateString(db_version):
    if db_version == LINKS_DB_VERSION_1:
        return (
            " id INTEGER PRIMARY KEY"
            " , json_info "
            " , update_date DATETIME DEFAULT CURRENT_TIMESTAMP "
            )
#__________________________________________________________________
#
def Create_Table(db_connection):
    sql_command = "BEGIN TRANSACTION; " + "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
    sql_command += TableCreateString(DB_VERSION_CURRENT)
    sql_command += (
        ");"
        "COMMIT;"
        "PRAGMA user_version = {};".format(DB_VERSION_CURRENT)
        )
##    Log("sql_command='{}'".format( sql_command ) )#,LOGNONE)
    db_connection.executescript( sql_command )
    db_connection.commit()
#__________________________________________________________________
#
def Clear_Table(interval_minutes=1, db_connection = sqlite3.connect(linksdb)):
    Log("Clear_Table({})".format(interval_minutes))
    db_connection.text_factory = str  #= sqlite3.Row #note: wild cards not work with sqlite3.Row factory
    Create_Table(db_connection)
    now = datetime.datetime.utcnow()
    prev = now - datetime.timedelta(minutes=interval_minutes)
    sql_command_1 = (
        "DELETE FROM "
        )
    sql_command_1 += (
        TABLE_NAME
        )
    sql_command_1 += (
        " WHERE update_date < ?"
        )
    params = (prev.isoformat(sep=' '),)
##    Log("sql_command_1='{}'  ".format(sql_command_1.replace('?', repr(prev.isoformat(sep=' ')))))
    db_cursor = db_connection.cursor()
    db_cursor.execute(
        sql_command_1
        , params
        )
    Log("db_cursor.rowcount)='{}'".format(db_cursor.rowcount))

##    Log("db_connection.rowcount)='{}'".format(db_connection.rowcount))
    db_connection.commit()

#__________________________________________________________________
#
 #= sqlite3.connect(linksdb) 
def Insert_Table(info, db_connection):
##    Log(repr(db_connection))
    sql_command_1 = (
        "INSERT INTO  "
        )
    sql_command_1 += (
         TABLE_NAME
         )
    sql_command_1 += (
         " (json_info) VALUES (?)"
        )
    params = (json.dumps(info),)
##    Log("sql_command_1='{}'  ".format(repr((sql_command_1,params))))
    db_cursor = db_connection.cursor()
    db_cursor.execute(
        sql_command_1
        , params
        )
##    Log("db_cursor.rowcount)='{}'".format(db_cursor.rowcount))
    db_connection.commit()
#__________________________________________________________________________
#
def get_setting(setting_name, auto_convert_to_type=bool):
    raw_setting = C.this_addon.getSetting(setting_name)
##    Log(repr(("get_setting", setting_name, raw_setting)))
    if auto_convert_to_type is bool:
        if raw_setting.lower() in ['true','false']:
            return (raw_setting.lower() == 'true')
        if raw_setting.lower() in ['none']:
            return None
        if raw_setting == '':
            return None
    if auto_convert_to_type is int:
        if not raw_setting: raw_setting = 0
        return int(raw_setting)
    if auto_convert_to_type is float:
        return float(raw_setting)
    if auto_convert_to_type is str:
        return str(raw_setting)
    if auto_convert_to_type is list:
        lis = str(raw_setting).split(',')
        if lis is None: lis = ()
##        Log(repr((type(lis),lis)))
        return lis
##    splitted = repr(auto_convert_to_type).split("','")[0].split("'")[1]
##    Log(repr(setting_name), xbmc.LOGNONE)
##    Log("raw:"+splitted, xbmc.LOGNONE)
    return raw_setting
#__________________________________________________________________________
#
def set_setting(setting_name, setting_value):
    #Log(repr(("set_setting", setting_name,setting_value)))
    C.this_addon.setSetting(id=setting_name, value=str(setting_value))

        

#__________________________________________________________________________
# wrapper to allow cookie extraction from urllib3 proxy/socks requests
class FakeRequest(object):
    def __init__(self, full_url, headers):
        self.full_url = full_url
        self._headers = headers.copy()
    @property
    def headers(self):
        return self._headers
    @property
    def url(self):
        return self.full_url
    def get_full_url(self):
        return self.full_url
    def is_unverifiable(self, *args, **kargs):
        return True
    def get_origin_req_host(self, *args, **kargs):
        return self.full_url   
#__________________________________________________________________________
#
def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=30
            , sucuri_solved=False
            , method="GET"
            , send_back_response=False
            , auto_encode_content=False
            , size=8192*1000
            , start_point=None
            , preload_content=True
            , cache_duration=C.default_GETHTML_cache_duration #seconds
            ):



    if not url:
        if send_back_redirect == True:
            return '', ''
        return ''


    cache_id = C.addon_id+'_gethtml_'+url
    if  (send_back_response == False) and \
        (cache_duration > 0):
        cached_value = global_cache.get(cache_id)
        if cached_value:
            if send_back_redirect:
                return cached_value, url
            return cached_value             


    if not Is_Online():
        if send_back_redirect == True:
            return '', ''
        return ''


    cj = cookielib.LWPCookieJar(C.cookiePath)
    try:
        cj.load(ignore_discard=True, ignore_expires=True)
        cj._now = int(time.time()) #module does not set this if I use internal functions
    except:
        cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
        cj._now = int(time.time())
        pass
    stream=False
    response = None
    redirected_url = None

    

##    ##cookiedump
####   #Log(C.cookiePath)
##    this_domain = urlparse.urlparse(url).netloc
####   #Log(this_domain)
####   #Log(repr(cj))
##    for cookie in cj:
####       #Log(cookie.domain)
####       #Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
##        if this_domain.endswith(cookie.domain):
##        #if cookie.domain.endswith(this_domain):
##           #Log("filtered cookie={}".format(repr(cookie)), xbmc.LOGNONE)
####    return
                        
    try:
                
        if '|' in url:
            headers = dict(urlparse.parse_qsl( str(url.split('|')[1])))
            url = str(url.split('|')[0])

        
            

        if headers is None:
##           #Log("copying default header dictionary")
            getHtml_headers = C.DEFAULT_HEADERS.copy()
            r_c_u_a = C.USER_AGENT #random.choice(C._USER_AGENTS)
    ##       #Log("r_c_u_a={}".format(r_c_u_a), xbmc.LOGNONE)
            getHtml_headers['User-Agent'] = r_c_u_a
    ##       #Log("rand choice getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
        else:
            getHtml_headers = headers #headers.copy()


##        Log("getHtml_headers={}".format(getHtml_headers)
##            , xbmc.LOGNONE
##            )
##        return
    
        if len(referer) > 1:
            getHtml_headers['Referer'] = referer

        if sent_data:
            getHtml_headers['Content-Length'] = str(len(sent_data))

        if start_point and int(start_point) > 0:
            getHtml_headers['Range'] = 'bytes={}-'.format(start_point)


        #
        # I don't know how to use cookieJar with SOCKS proxy
        #
        socks_cookies = ''
        if url:
            this_domain = urlparse.urlparse(url).netloc
        
        temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
        if cj and url:
            for cookie in cj:
                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                    socks_cookies += "{}={};".format(cookie.name,cookie.value)
                    temp_cookiejar.set_cookie(cookie)
##            for cookie in temp_cookiejar: #verification during development 
##               #Log("temp_cookiejar_cookie={}".format(repr(cookie)))
##                pass
            if 'Cookie' in getHtml_headers:
                socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
            if not socks_cookies == '':
                getHtml_headers['Cookie'] = (socks_cookies).strip(';')


    
##       #Log("final getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
##        return "" #getHtml_headers testing/dev

        
        bypass_proxy_list = get_setting('bypass_proxy_list')
        if not bypass_proxy_list: bypass_proxy_list=''
##        Log(repr(  (bypass_proxy_list)   ))
        should_bypass_proxy = urlparse.urlparse(url).netloc in (bypass_proxy_list.split(','))
##        Log(repr(  (url,should_bypass_proxy)   ))
        
        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) and should_bypass_proxy==False:

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            if C.certPath: 
                proxy = SOCKSProxyManager(proxy_url=socks_string, ca_certs=C.certPath)
            else:
                proxy = SOCKSProxyManager(proxy_url=socks_string)

##           #Log(repr(proxy) )
            
            socks_response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if preload_content:
                data = socks_response.data
            redirected_url = socks_response.geturl()
            if not url == redirected_url:
               #Log(repr((url,redirected_url)))
               #Log("redirected_url='{}'".format(redirected_url))
                pass
            else:
                redirected_url = None



        elif (socks_proxy_info['uhp'] <= -0) :
            
            if (socks_proxy_info['ps'] is not None) and should_bypass_proxy==False:
                proxy_string = "http://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                proxy = ProxyManager(proxy_url=proxy_string, ca_certs=C.certPath)
            else:
                proxy_string = ''
                #proxy = PoolManager()
                proxy = pool_proxy

##           #Log(repr(proxy) )

            response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
 
            #make urllib3.response more like requests.response by adding cookiejar and status
            temp_jar = cookielib.LWPCookieJar()
            fake_request = FakeRequest(url, response.getheaders() )
            requests.cookies.extract_cookies_to_jar(temp_jar, fake_request, response)
            response.cookies = temp_jar
            response.status_code = response.status

            if preload_content:
                data = response.data
##            Log(data[:500]) #dev trim the data to minimize logging

            redirected_url = response.geturl()
            if not (url == redirected_url):
                if redirected_url and not (redirected_url.startswith('http')):
                    if (response.retries is not None):
                        if len(response.retries.history):
                            redirect_location = response.retries.history[-1].redirect_location
                            redirect_url = response.retries.history[-1].url
                            if not (redirected_url.startswith('http')):
                                if not (redirect_url.startswith('http')):
                                    redir_domain = urlparse.urlparse(url).scheme + '://' + urlparse.urlparse(url).netloc
                                else:
                                    redir_domain = urlparse.urlparse(redirect_url).scheme + '://' + urlparse.urlparse(redirect_url).netloc
                            redirected_url = redir_domain + redirected_url
                if redirected_url and not (redirected_url.startswith('http')):
                    redir_domain = urlparse.urlparse(url).scheme + '://' + urlparse.urlparse(url).netloc
                    redirected_url = redir_domain + redirected_url
                if (url == redirected_url): redirected_url = None
                else: Log(u"processed redirected_url={}".format(repr(redirected_url)))
            else:
                redirected_url = None

##        Log(repr(response.status_code))
        if not(response.status_code in (200,301)):
            raise urllib2.HTTPError(url=url, code=response.status_code, msg="", hdrs=response.headers, fp=None)
        
        if auto_encode_content: 
            if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
                content_type = response.headers['Content-Type']
                if 'charset=' in content_type:
                    ct = content_type.split('charset=')[1]
                    data = data.decode(ct)
        elif not send_back_response:

            try:
                data = str(data, 'utf8')
            except:
                pass #leave it as binary; caller will have to deal with any string conversions
            
        if sucuri_solved == False:
            if 'Server' in response.headers:
                if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                   #Log(repr(response.status_code))
                    import sucuri
                    if sucuri.SCRIPT_HEADER in data:
                        cookie = sucuri.Set_Cookie(data)
                        cj.set_cookie(cookie)
                        cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
                        return getHtml(url, referer, headers
                                       , save_cookie, sent_data
                                       , ignore404, ignore403
                                       , send_back_redirect, http_timeout
                                       , sucuri_solved = True, method=method)


        if not (save_cookie == False) and (cj is not None) :
            r = response
            this_domain = urlparse.urlparse(url).netloc

            if r is not None:
                for cookie in r.cookies:
                   #Log("r.cookie={}".format(repr(cookie)))
                    if save_cookie == True: #save as this domain even if cookie is not marked so
                         cookie.domain = this_domain
                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                        cj.set_cookie(cookie)
                        
                cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

             

        if send_back_response == True:
            if send_back_redirect == True:
                return response, redirected_url
            else:
                return response


        if  (send_back_response == False) and \
            (cache_duration > 0):

            if 'Content-Type' in response.headers:
                ctype = response.headers['Content-Type'].lower()
                if ctype and ctype in [
                                                        'application/xml; charset=utf-8'
                                                        ,'application/xml;charset=utf-8'
                                                        ,'application/xml'
                                                        , 'application/json; charset=utf-8'
                                                        , 'application/json;charset=utf-8'
                                                        , 'application/json'
                                                        , 'text/html; charset=utf-8'
                                                        , 'text/html;charset=utf-8'
                                                        , 'text/html'
                                                        , 'application/javascript; charset=utf-8'
                                                        ]:
                    global_cache.set(
                        endpoint = cache_id
                        ,data = data
                        ,expiration = datetime.timedelta(seconds=cache_duration)
                        )
                else:
                   #Log("not caching ctype = {}".format(repr(ctype)))
                    pass

        if response: response.close()

        if send_back_redirect == True: return data, redirected_url
        return data


    except requests.HTTPError as e:
        Log(" requests.HTTPError  repr(e)='{}'".format(repr(e)))
        raise
        
    except urllib2.HTTPError as e:

        data = e.msg

        if e.code == 503 and 'cf-browser-verification' in data:
            import cloudflare
            data = cloudflare.solve(url, cj, USER_AGENT)
            
        elif e.code == 404 and ignore404 == True:
            Log("404_e='{}'".format(url)) #e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        elif e.code == 403 and ignore403 == True:
            Log("403_e='{}'".format(url)) #e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        else:
            #traceback.print_exc()
            raise

    except Exception as e:
        LogR(locals())
        raise
##        traceback.print_exc()

    if send_back_redirect == True:
        return None, None
    else:
        return None
    
#__________________________________________________________________________
#
def postHtml(post_url
             , sent_data=None
             , headers=None
             , compression=True
             , NoCookie=True
             , cache_duration=-1):
    data = getHtml(url=post_url
                   , headers=headers
                   , save_cookie=(not NoCookie)
                   , sent_data=sent_data
                   , method="POST"
                   , cache_duration=-1)
    return data

#__________________________________________________________________________
#
def headHtml(head_url
             , sent_data=None
             , headers=None
             , compression=True
             , NoCookie=True
             , send_back_redirect=False
             , cache_duration=-1):
    return getHtml(url=head_url
                   , send_back_redirect=send_back_redirect
                   , headers=headers
                   , save_cookie=(not NoCookie)
                   , method="HEAD"
                   , cache_duration=-1 )

#__________________________________________________________________________
#
def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q
#__________________________________________________________________________
#
cp1252 = {
    # from http://www.microsoft.com/typography/unicode/1252.htm
    u"\u20AC": u"\x80", # EURO SIGN
    u"\u201A": u"\x82", # SINGLE LOW-9 QUOTATION MARK
    u"\u0192": u"\x83", # LATIN SMALL LETTER F WITH HOOK
    u"\u201E": u"\x84", # DOUBLE LOW-9 QUOTATION MARK
    u"\u2026": u"\x85", # HORIZONTAL ELLIPSIS
    u"\u2020": u"\x86", # DAGGER
    u"\u2021": u"\x87", # DOUBLE DAGGER
    u"\u02C6": u"\x88", # MODIFIER LETTER CIRCUMFLEX ACCENT
    u"\u2030": u"\x89", # PER MILLE SIGN
    u"\u0160": u"\x8A", # LATIN CAPITAL LETTER S WITH CARON
    u"\u2039": u"\x8B", # SINGLE LEFT-POINTING ANGLE QUOTATION MARK
    u"\u0152": u"\x8C", # LATIN CAPITAL LIGATURE OE
    u"\u017D": u"\x8E", # LATIN CAPITAL LETTER Z WITH CARON
    u"\u2018": u"\x91", # LEFT SINGLE QUOTATION MARK
    u"\u2019": u"\x92", # RIGHT SINGLE QUOTATION MARK
##    u"\u2019": "\u2019".encode('utf8'), # RIGHT SINGLE QUOTATION MARK
    u"\u201C": u"\x93", # LEFT DOUBLE QUOTATION MARK
    u"\u201D": u"\x94", # RIGHT DOUBLE QUOTATION MARK
    u"\u2022": u"\x95", # BULLET
    u"\u2013": u"\x96", # EN DASH
    u"\u2014": u"\x97", # EM DASH
    u"\u02DC": u"\x98", # SMALL TILDE
    u"\u2122": u"\x99", # TRADE MARK SIGN
    u"\u0161": u"\x9A", # LATIN SMALL LETTER S WITH CARON
    u"\u203A": u"\x9B", # SINGLE RIGHT-POINTING ANGLE QUOTATION MARK
    u"\u0153": u"\x9C", # LATIN SMALL LIGATURE OE
    u"\u017E": u"\x9E", # LATIN SMALL LETTER Z WITH CARON
    u"\u0178": u"\x9F", # LATIN CAPITAL LETTER Y WITH DIAERESIS
}

if C.PY2: from htmlentitydefs import name2codepoint
if C.PY3: from html.entities import name2codepoint
def htmlentitydecode(s):
    if C.PY2: s = re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: unichr(name2codepoint[m.group(1)]), s)
    if C.PY3: s = re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: chr(name2codepoint[m.group(1)]), s)
    return s    

def try_decode(text, encoding="utf-8"):
    '''helper to decode a string to unicode'''
    try:
        return text.decode(encoding, "ignore")
    except Exception:
        return text
def cleantext(text):
    '''normalize string, strip all special chars'''
    text = text.replace('\t','')
    text = text.replace('\n','')
##    text = text.replace(":", "")
##    text = text.replace("/", "-")
##    text = text.replace("\\", "-")
##    text = text.replace("<", "")
##    text = text.replace(">", "")
##    text = text.replace("*", "")
##    text = text.replace("?", "")
##    text = text.replace('|', "")
##    text = text.replace('(', "")
##    text = text.replace(')', "")
##    text = text.replace("\"", "")
    text = text.strip()
    text = text.rstrip('.')
    text = unicodedata.normalize('NFKD', try_decode(text))

    text = C.html_parser.unescape(text)
    text = htmlentitydecode(text)
    for src, dest in cp1252.items():
        text = text.replace(dest, src )

    text = text.replace('\\u0026','&')
    text = text.replace('&colon;',':')
    text = text.replace('&comma;',',')
    text = text.replace('&lowbar;','_')
    text = text.replace('&period;','.')
    text = text.replace('&lbrace;','(')
    text = text.replace('&DiacriticalAcute;','`')
    text = text.replace('&lcub;','{')
    text = text.replace('&rcub;','}')
    text = text.replace('&sol;','/')
    text = text.replace('&lpar;','(')
    text = text.replace('&rpar;',')')
    text = text.replace('&quest;','?')
    text = text.replace('&apos;','\'')
    text = text.replace('&percnt;','%')
    text = text.replace('&num;','#')
    return text
##
##    #return a unicode string, replacing html special codes with unicode characters
##
##    text = text.replace('\t','')
##    text = text.replace('\n','')
##    text = text.strip()
##    
##    #Log(repr(text) + "   org(text)")
##    if not isinstance(text, unicode):
##        text = text.decode('utf8')
##
##    text = htmlentitydecode(text)
##    text = html_parser.unescape(text)
##
##    for src, dest in cp1252.items():
##        text = text.replace(dest, src )
##
##    #return text        
##    return unicodedata.normalize(
##             'NFKD', text
##             ).encode('utf8','ignore')
##
####    text = text.replace(u'\u200b','')
####    from unidecode import unidecode
####    return unidecode(text)
##    
####    text = text.decode('ascii', 'xmlcharrefreplace')
##
##
##    
##
##    text = htmlentitydecode(text)
##    #Log(repr(text) + "   entity(text)")
####    import unicodedata
####    text = unicodedata.normalize('NFKD',text)
##    text = html_parser.unescape(text)
##    #Log(repr(text) + "   html(text)")
##    
##    #to make things easier on future functions that only support
##    #   ascii strings, make sure that a cleaned string is encoded as
##    #   utf8. This strings should be decoded before being made visible
##    #   to user
####    for src, dest in cp1252.items():
####        text = text.replace(src, dest)
####    Log(repr(text) + "   cp1252(text)")
######    text = text.encode('latin1')
######    Log(repr(text) + "   latin(text)")
####    text = text.decode('unicode_escape')
####    Log(repr(text) + "   unicode(text)")
##    
####    text = text.decode('utf8')
####    Log(repr(text) + "   utf8(text)")
##
####    text = text.replace(u"\u2018", u"'").replace(u"\u2019", u"'")
####    Log(repr(text) + "   replace(text)")
##
##    #returned text should be pure unicode
##    #no futher encoding should be necessary
##    
##
####
####    text = text.replace('&excl;','!')
####    text = text.replace('&lpar;','[')
####    text = text.replace('&rpar;',']')
##
##    return text
##
##    #Log(text,xbmc.LOGNONE)
##    #text = html_parser.unescape(text.encode('ascii', 'ignore'))
##    text = htmlentitydecode(text)
##    text = text.replace('&#8211;','-')
##    text = text.replace('&ndash;','-')
##    
##    
##    
##    text = text.replace('&amp;','&')
##    text = text.replace('&#038;','&')
##    text = text.replace('&#8217;','\'')
##    text = text.replace('&#8216;','\'')
##    text = text.replace('&#8230;','...')
##    text = text.replace('&quot;','"')
##    text = text.replace('&excl;','!')
##    text = text.replace('&apos;','\'')
##    text = text.replace('&#039;','`')
##    text = text.replace(u'ñ','n')
##
##
##    #Log(text,xbmc.LOGNONE)
##    #xbmc.log(  u'ñ'.encode("utf-8").decode("utf-8") , xbmc.LOGNONE)
##    #text = text.encode("utf-8").replace('&ntilde;','\xf1').decode("utf-8")
##    text = text.replace('&rsquo;','\'')
##    text = text.encode('ascii', 'ignore').strip()
##
##
##    return text


#__________________________________________________________________________
#
def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext


#__________________________________________________________________________
#
def Set_ListItem_Duration(listitem, duration):
    duration=str(duration).lower().strip()
    duration_seconds = 0

    # test cases:
    # 
##    Log(duration, xbmc.LOGNONE)
    
    #somethimes will have a dot
    if '.' in duration:
        duration = duration.split('.')[1]
        
    #sometimes format will be hh:mm:ss: normalize it to what I want
    timearr= ['s','m','h']
    if ':' in duration:
        duration_arr = duration.split(':')
        duration = ""
        i = 0
        for duration_elem in reversed(duration_arr):
            duration = duration_elem + timearr[i] + duration
            i = i+1

    duration = duration.replace(' h', 'h ').replace('h', 'h ').replace('min', 'm ').replace(' m', 'm ').replace('m', 'm ').replace(' s', 's ').replace('s', 's ').strip()

    #sometimes format will be Xh Ym Zs
    try:
        duration_arr = duration.split(' ')
        for duration_elem in duration_arr:
            duration_elem = duration_elem.strip()
            if 'h' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('h',''))*3600
            elif 'm' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('m',''))*60
            elif 's' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('s',''))
            elif duration_elem:
                try:
                    duration_seconds = duration_seconds + int(duration_elem)
                except:
                    pass
    except:
       #Log(repr(duration_arr))
        raise

    listitem.getVideoInfoTag().setDuration(duration_seconds)
#__________________________________________________________________________
#
def addDownLink(name, url, mode
                , iconimage=''
                , desc=''
                , stream=None
                , fav='add'
                , noDownload=False
                , duration=None
                , date=None
                , views=None
                , likes=None
                , play_method=None
                , hq_stream=None
                , return_listitem=False
                , icon_url=''
                , action=''
                ):

    try:
        list_item = xbmcgui.ListItem(
            label=u'[B][COLOR {}]{}[/COLOR][/B]'.format(C.highlight_text_color,name)
##            ,iconImage=iconimage
##            ,thumbnailImage=iconimage
            )

        s_t = "a{:0>10}".format(int(C.CONFIGURE_INPUTSTREAM))
        if C.PY2: 
            list_item.setInfo(type="video", infoLabels={
                "sorttitle": s_t
                } )
        if C.PY3: list_item.getVideoInfoTag().setSortTitle(s_t)

        xbmcplugin.addDirectoryItem(
            handle=C.addon_handle
            , url = url
            , listitem=list_item
            , isFolder=False
        )
    except:
        LogR(locals())
        traceback.print_exc()
        Notify(msg="Error adding Configuration icon", duration=2000)
    
#__________________________________________________________________________
#
def ___add___Playlink(
##    plugin
    mode
    ,playlink_name
    ,final_url
    ,program_name
    ,channel
    ,icon
    ,play #the memory address/signature for the entry function that the routing module will call
    ,module_name #=''
    ,rating #= 9.9
    ,return_json_info #= True
    ,is_folder #= False
    ,filter_category #= ''
    ,cache_duration=get_setting("min_service_interval", int)
    ):

        #the main link is below
        main_url = routing_url_for(
                mode
                , rel_url = final_url.encode('unicode-escape')
                , channel = channel.encode('utf8') #channel.encode('unicode-escape')
                , img = kodiutils.smart_str(icon)
                , prog = program_name.encode('utf8')  #program_name.encode('unicode-escape')
                , module_name = module_name
                , filter_category = filter_category
                )
        Log(main_url)


        if return_json_info:
            
            # performance testing shows that, on a slow computer, each cache.set can take 200ms therefore I am tring to minimize them
            global_mem_cache_lock.acquire()
##            t_start = datetime.datetime.now()
##            Log("t_start {}".format(threading.currentThread().ident))
            
            json_item = {}
            json_item['name'] = playlink_name
            json_item['final_url'] = final_url
            json_item['program_name'] = program_name
            json_item['channel'] = channel
            json_item['icon'] = icon
            json_item['module_name'] = module_name
            json_item['rating'] = rating
            json_item['is_folder'] = is_folder
            json_item['filter_category'] = filter_category
            json_item['main_url'] = main_url

            try:
                if get_setting("use_dbcache", bool):
                    Insert_Table(json_item, db_connection=sqlite3.connect(C.linksdb)) #,check_same_thread = False))

                elif get_setting("use_memcache", bool):
                    size = global_mem_cache.get(\
                        endpoint = (CACHE_STRING+'_size')\
                        )
                    if size: size = int(size)
                    else: size = 0
                    size = size+1
                    global_mem_cache.set(\
                         endpoint = (CACHE_STRING+"_icons+"+str(size))\
                         ,data = json_item\
                         ,expiration = datetime.timedelta(seconds=cache_duration)\
                         )
                    global_mem_cache.set(\
                         endpoint = (CACHE_STRING+'_size')\
                         ,data = size\
                         ,expiration = datetime.timedelta(seconds=cache_duration)\
                         )
            except:
                traceback.print_exc()
            finally:
                global_mem_cache_lock.release()

##            net = (datetime.datetime.now()-t_start).total_seconds()
##            if net > 1: Log(repr((net,json_item)))
##            Log("return_json_info={:.0f}ms".format( net*1000 ) )
            return
        
        list_item = xbmcgui.ListItem(playlink_name)
        list_item.setArt({"thumb": icon}) #setting fanart will cause extra network traffic to get latest image
        list_item.setContentLookup(False)
        list_item.setProperty('IsPlayable', 'false')
        list_item.getVideoInfoTag().setSortTitle("a{:0>10}".format(int(rating)))
        list_item.getVideoInfoTag().setPlaycount(0)


        contextMenuItems = []
        try: #create custom menu items
            
            plugin_url = plugin.url_for(
                    play
                    , rel_url=final_url.encode('unicode-escape')
                    , channel=channel.encode('unicode-escape')
                    , img=icon#kodiutils.smart_str(icon)
                    , prog=program_name.encode('unicode-escape')
                    , playmode_string=C.PLAYMODE_DIRECT
                    , module_name = module_name
                    , filter_category = filter_category
                    )
            contextMenuItems.append(
                (
                "[COLOR {}]{}Direct[/COLOR]".format(C.time_text_color, 'Play')
                , "PlayMedia({})".format(plugin_url)
                )
            )
            plugin_url = plugin.url_for(
                    play
                    , rel_url=final_url.encode('unicode-escape')
                    , channel=channel.encode('unicode-escape')
                    , img=kodiutils.smart_str(icon)
                    , prog=program_name.encode('unicode-escape')
                    , playmode_string=C.PLAYMODE_INPUTSTREAM
                    , module_name = module_name
                    , filter_category = filter_category
                    )
##            Log(plugin_url)
            contextMenuItems.append(
                (
                "[COLOR {}]{} Inputstream[/COLOR]".format(C.time_text_color, 'Play')
                , "PlayMedia({})".format(plugin_url)
                )
            )
            
            for n in range(1,4,1): #starting at zero would incude download
                plugin_url = plugin.url_for(
                        play
                        , rel_url=final_url.encode('unicode-escape')
                        , channel=channel.encode('unicode-escape')
                        , img=kodiutils.smart_str(icon)
                        , prog=program_name.encode('unicode-escape')
                        , playmode_string=C.PLAYMODE_F4MPROXY
                        #, play_profile=C.addon.getSetting("profile_0{}_stream_type".format(n))
                        , play_profile="profile_0{}".format(n)
                        , module_name = module_name
                        , filter_category = filter_category
                        )
##                Log(plugin_url)
                contextMenuItems.append( 
                    ( 
                    "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_0{}_alias".format(n)), C.PLAYMODE_F4MPROXY)
                    ,"PlayMedia({})".format(plugin_url)
                    )
                )


            plugin_url = plugin.url_for(
                    play
                    , rel_url=final_url.encode('unicode-escape')
                    , channel=channel.encode('unicode-escape')
                    , img=kodiutils.smart_str(icon)
                    , prog=program_name.encode('unicode-escape')
                    , playmode_string=C.PLAYMODE_F4MPROXY
                    , play_profile="profile_00"
                    , module_name = module_name
                    , filter_category = filter_category
                    , download=1
                    )
            Log(plugin_url)
            contextMenuItems.append(
                (
                "[COLOR {}]Download[/COLOR]".format(C.highlight_text_color, '')
                , "PlayMedia({})".format(plugin_url)
                )
            )
            
        except:
            raise
##            pass
        list_item.addContextMenuItems(
            contextMenuItems
            , replaceItems=False)

        
        xbmcplugin.addDirectoryItem(
            plugin.handle
            , main_url
            , list_item
            , isFolder=is_folder
            )

#__________________________________________________________________________
#
def addDir(name, url, mode
           , iconimage=None
           , page=None
           , channel=None
           , section=None
           , keyword=''
           , Folder=True
           , duration=None
           , title=None
           , end_directory=True
           , contextMenu=None
           , contextMenuReplace=True
           , return_listitem=False
           , return_url=False):

    if page is None: page='1'
    u = (sys.argv[0] +
     "?url=" + quote_plus(str(url)) +
     "&1mode=" + str(mode) +
     "&mode=" + str(mode) +
     "&page=" + str(page) +
     "&channel=" + str(channel) +
     "&section=" + str(section) +
     "&keyword=" + quote_plus(str(keyword)) +
     "&end_directory=" + str(end_directory) +
     "&name=" + quote_plus(str(name.encode('utf8'))))
    if return_url:
        return u


    if not(iconimage) or (len(iconimage) < 1): iconimage = C.default_icon

    if not '|' in iconimage and 'http' in iconimage:
        iconimage = u"{}{}".format(iconimage, Header2pipestring())

    if C.xbmc_version[0] > 17 :
        liz = xbmcgui.ListItem(
            label = name
##            , iconImage=iconimage
##            , thumbnailImage=iconimage
            , offscreen=True #kodi 18+
            )
    else:
        liz = xbmcgui.ListItem(
            label = name
##            , iconImage=iconimage
##            , thumbnailImage=iconimage
##            , offscreen=True #kodi 18+
            )


    liz.setProperty('IsPlayable', 'false')

    liz.setArt(
        { 'thumb': iconimage
          , 'icon': iconimage
          , 'fanart': iconimage
          , 'poster': iconimage
          }) #must include thumb to avoid error messages

    if duration:
        Set_ListItem_Duration(liz, duration)

    #setting type = music instead of video means no icon to the right of the label
    if title:
        if C.PY2: liz.setInfo(type="Video", infoLabels={"Title": title})
        if C.PY3: liz.getVideoInfoTag().setTitle(title)

    contextMenuItems = []
    if len(keyword) >= 1 and not("next page" in name.lower()):
        keyw = (sys.argv[0] +
            "?mode=" + C.DELETE_KEYWORD +
            "&keyword=" + quote_plus(keyword))
        #if not contextMenuItems: contextMenuItems = []
        contextMenuItems.append(
                (
                    "[COLOR {}]Remove keyword[/COLOR]".format(C.time_text_color)
                    , "RunPlugin({})".format(keyw)
                )
            )

    if section and section == C.INBAND_RECURSE:
        #below will not work well because the 'back' button will return to root of addon, and not where I want     
        u2 = u.replace("&keyword=" + quote_plus(str(keyword)), "&keyword=" + C.INBAND_RECURSE)
        u2 = u2.replace("&page=" + str(page), "&page=" + str(int(page)-1)) #include the page we are on
        u2 = u2.replace("&page=" + str(page), "&page=1")  #include the page we are on
        contextMenuItems.append( (
            "[COLOR {}]Recurse to Page {}[/COLOR]".format(C.search_text_color, C.MAX_RECURSE_DEPTH)
            , "ActivateWindow(Videos,{})".format(u2)  )  )
        contextMenuReplace=False

    if contextMenu:
        contextMenuItems = contextMenu

    if contextMenuItems:
        liz.addContextMenuItems(contextMenuItems, replaceItems=contextMenuReplace)

    if return_url:
        return u
    elif return_listitem:
        return(u, liz, Folder)
    else:
        xbmcplugin.addDirectoryItem(
            handle=C.addon_handle
            , url=u
            , listitem=liz
            , isFolder=Folder
            )
#__________________________________________________________________________
#
#__________________________________________________________________________
#
def Get_Sites(filter_category=None,icon_function=None):
    
    
    libDir = os.path.join(C.resDir, 'lib')
    sitesDir = os.path.join(libDir, 'sites')
    files = []
#    for r, d, f in os.walk(sitesDir): # r=root, d=directories, f = files
##        for f1 in f:
##        if (f1.endswith('.py') or f1.endswith('.pyc')) and not f1.startswith('_') :
##            f2 = f1[:-(len(f1.split('.')[-1])+1)]
##            files.append(f2)

    for f1 in os.listdir(sitesDir):
        if (f1.endswith('.py') or f1.endswith('.pyc')) and not f1.startswith('_') :
            f2 = f1[:-(len(f1.split('.')[-1])+1)]
            files.append(f2)
            #break
    site_list = {}
    for f in files:
        if not f in site_list:
##            Log("added f='{}'".format(f))
            site_list[f] = ''

    sorted_site_list = sorted(site_list.items(), key=operator.itemgetter(0))

    sorted_dict = collections.OrderedDict(sorted_site_list)

   
    aa = None
    for sitename in sorted_dict:
        if aa is None:
            try:
                try:
                    try:
                        module = importlib.import_module('sites.'+sitename)
                    except SyntaxError:
                        raise
                    except:
                        traceback.print_exc()
                        raise
                        continue
##                    Log(repr(module))
                    if hasattr(module, "website"):
                        module = module.website
                    if filter_category:
##                        Log(  repr((filter_category,sitename)),  C.LOGNONE)
##                        Log(repr((module.LIST_AREA == filter_category)))
                        if module.LIST_AREA == filter_category:
                            yield (
                                module.FRIENDLY_NAME
                                ,module.ROOT_URL
                                ,module.MAIN_MODE
                                ,os.path.join(C.imgDir, sitename + '.png')
                                )
                    elif icon_function==True:
                        aa = (yield (module ,module.MAIN_MODE))
                        if aa is not None:
                            break
                    else:
                        aa = (yield (sitename, module))
                        if aa is not None:
                            break
                except StopIteration:
                    pass
                except GeneratorExit:
                    return
                    pass
                except:
                    Log('failed Get_Sites for {}'.format(sitename), xbmc.LOGWARNING)
##                    traceback.print_exc()
                    raise
            except:
                traceback.print_exc()

#__________________________________________________________________________
#
def Notify(header=None, msg='', duration=4000, sound=False, allow_all_thread_names=False):
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound, allow_all_thread_names=allow_all_thread_names)
def notify(header=None, msg='', duration=C.DEFAULT_NOTIFY_TIME, sound=False, allow_all_thread_names=False):
    debug = (C.this_addon.getSetting('debug').lower() == "true")
    if allow_all_thread_names or (threading.current_thread().name == "MainThread"):
        if header==None or header == '':
            if len(msg) > 30:
                header = msg[0:30]
                msg = msg[-30:]
            else:
                header=msg
        xbmcgui.Dialog().notification(header, msg, C.default_icon, duration, sound=False )
    elif debug:
        Log( msg, xbmc.LOGERROR)
#__________________________________________________________________________
#
def Header2pipestring(header = C.DEFAULT_HEADERS):
    if not header or len(header)<1: header = C.DEFAULT_HEADERS
    q = "|{}".format( urlencode(header)  )
    return q
#__________________________________________________________________________
#
def add_sort_method():
    if not C.addon_handle:
        return
    try:
        sort_order = int(C.addon.getSetting('video_sort_by'))
    except:
        sort_order = -1
    if sort_order == 2:
        sort_order = xbmcplugin.SORT_METHOD_DURATION
##    elif sort_order == :
##        sort_order = xbmcplugin.SORT_METHOD_DATE
    elif sort_order == 1:
        sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
    elif sort_order == 4:
        sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
    elif sort_order == 5:
        sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
    else:
        sort_order = xbmcplugin.SORT_METHOD_UNSORTED


    xbmcplugin.addSortMethod(C.addon_handle #use the hidden string I insert for sorting
                             ,xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE
                             )
    xbmcplugin.addSortMethod(C.addon_handle
                             ,sort_order #use preferred method first
##                             ,'% '
                             ) 
    #xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(C.addon_handle
                             ,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
                             )
    xbmcplugin.addSortMethod(C.addon_handle
                             ,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED
                             )
    xbmcplugin.addSortMethod(C.addon_handle
                             ,sortMethod=xbmcplugin.SORT_METHOD_DURATION
                             )
    xbmcplugin.addSortMethod(C.addon_handle
                             ,xbmcplugin.SORT_METHOD_SONG_RATING
                             #,labelMask="%T. %H"
##                             ,'%O,%O'
                             )

#__________________________________________________________________________
#
def endOfDirectory(  cacheToDisc=True
                   , end_directory=True
                   , allow_sorting=True
                   , inband_recurse=False
                   , updateListing=False):
##    if end_directory is True:  traceback.print_stack()

    if not ( (end_directory == True) or inband_recurse ):
        return
    if allow_sorting == True:
        add_sort_method()
    if sys and sys.argv and len(sys.argv)>1 and sys.argv[1]:
        C.addon_handle = int(sys.argv[1])
##        Log(repr(C.addon_handle))
        xbmcplugin.endOfDirectory(C.addon_handle, cacheToDisc=cacheToDisc, updateListing=updateListing)
##        traceback.print_stack()
#__________________________________________________________________________
#
def SortVideos(sources
               , download
               , vid_res_column=1
               , substitute_char='}'
               , substitute_res='720'
               , max_video_resolution = C.maximum_video_resolution
               ):

    Log(repr((__name__, locals()))
##        ,C.LOGNONE
        )
   
##    global maximum_video_resolution
    if max_video_resolution:
        maximum_video_resolution = max_video_resolution
    else:
        maximum_video_resolution = C.maximum_video_resolution
##    Log(str(maximum_video_resolution))

    try: 
        #sometimes we can't get accurate resolutions and end up with a characters instead...
        # e.g. "http://video.mp4","}"     instead of   "http://video.mp4","480p"

##        Log("sources='{}', download='{}'".format(sources,download))

        if (bool(download) == True):
            maximum_video_resolution = 99999 # allow max resolution on download
##        Log("maximum_video_resolution='{}'".format(maximum_video_resolution))

        s3840p_string = "3840p"
        s2160p_string = "2160p"
        s1440p_string = "1440p"
        s1080p_string = "1080p"
        s720p_string = "720p"
        s540p_string = "540p"
        s480p_string = "480p"
        s320p_string = "320p"

        #report on what was the maximum resolution available; just for fun
        try:
            videos = sorted(sources
                            , key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('p60','p') \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True)
##            LogR(videos)

            if len(videos) > 1:
                if vid_res_column == 1:
                    max_avail_res = videos[0][1]
                else:
                    max_avail_res = videos[0][0]
            else:
                max_avail_res = 'unknown'
        except:
            traceback.print_exc()
            max_avail_res = 'unknown'
            pass
        
##        Log("Best quality for this item is {}".format(max_avail_res))
##        Log("Worst quality for this item is {}".format(videos[-1][vid_res_column]  ))

        #change these subst strings so that they can't be matched when max resolution is less
        if maximum_video_resolution < 3840:
            s3840p_string = "40p" 
        if maximum_video_resolution < 2160:
            s2160p_string = "60p"
        if maximum_video_resolution < 1440:
            s1440p_string = "14p"
        if maximum_video_resolution < 1080:
            s1080p_string = "14p"
        if maximum_video_resolution < 720:
            s720p_string = "14p"
        if maximum_video_resolution < 540:
            s540p_string = "13p"
        if maximum_video_resolution < 480:
            s480p_string = "12p"

    ##     the list of videos is a bunch of urls such as xxx\360.mp4
    ##        i use a lambda(just for fun) to split out the numeric resolution and the reverse sort it;
    ##        the best resolution should end up on top
    ##        the 720 is replaced with 721 so that the number ending 20 does not match other possible strings the site may use to define ultra resolutions
    ##        the letter p is removed so that we can convert to integer and avoid the 720 is better 1080 situation if it were chars
    ##        the higher resolutions, when we have been told not to use them, are replaced with lower numbered strings 

        try:
            videos = sorted(sources, key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('p60','p') \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True)
        except:
            videos = None
            traceback.print_exc()

##        Log("videos='{}'".format(videos))
        if len(videos) < 1:
            return None
        if vid_res_column == 1:
            video_url = videos[0][0]
        else:
            video_url = videos[0][1]

##        LogR(video_url)
        video_url = s_e(video_url)
            
        return video_url
    except:
         traceback.print_exc()
         return None

#__________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=10):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval
#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None

    def Get_Setting_Val(setting):
        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"' +
                                  setting + '"},"id":1}')
        return json.loads(val)['result']['value']
    
    try:
        usehttpproxy = Get_Setting_Val('network.usehttpproxy')
        if usehttpproxy and str(usehttpproxy).lower()=='true':
            httpproxytype = Get_Setting_Val('network.httpproxytype') #= get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = Get_Setting_Val('network.httpproxyserver') #= get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = Get_Setting_Val('network.httpproxyport') #= get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = Get_Setting_Val('network.httpproxyusername') #= get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = Get_Setting_Val('network.httpproxypassword') #= get_gui_setting(guisettings_xml, 'httpproxypassword')

    except:
        traceback.print_exc()
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
        return proxy_info
#__________________________________________________________________
#
def RandomNumber(return_integer=True,length=18):
    import random
    nc_string = str(random.random())
    if return_integer:
        nc_string = nc_string.split('.')[1]
    while len(nc_string) < length:
        nc_string += str(random.randint(10,99))
    if len(nc_string) > length:
        nc_string = nc_string[0:length]
    return nc_string
#__________________________________________________________________
#
def Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode):
    #helper function to make code look smaller
    # check for a minimum length; raise error if necessary; add item if not enough
    if len(info) < 1:
        label = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "No items")
        if not keyword == '':
            label += " for [COLOR {}]{}[/COLOR]".format(C.refresh_text_color,keyword)
        label +=  " on '{}'".format(ROOT_URL)
        addDir(
            name=label
            ,url=C.DO_NOTHING_URL
            ,mode=MAIN_MODE
            ,iconimage=C.not_found_icon
            )
        if testmode:
            raise OSError    
#__________________________________________________________________
#
def Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page):
    #helper function to make code look smaller
    inband_recurse = (keyword==C.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = C.MAX_RECURSE_DEPTH
    else:
        max_search_depth = C.DEFAULT_RECURSE_DEPTH
    if end_directory == True and SEARCH_URL:
        addDir(
            name=C.STANDARD_MESSAGE_SEARCH
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon )
        addDir(
            name=C.STANDARD_MESSAGE_SEARCH_RECURSIVE
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon
            ,end_directory=False
            ,page=C.FLAG_RECURSE_NEXT_PAGES)
    if ('{}' in url) and page:
        list_url = url.format(page)
    else:
        list_url = url
   #Log("list_url='{}'".format(list_url))

    return inband_recurse, end_directory, max_search_depth, list_url
#__________________________________________________________________
#
def Normalize_HD_String(hd):
    hd = hd.lower()
    if   ('2160'           in hd
          or 'uhd'         in hd
          or '4k'          in hd
          or '2k'          in hd
          or '1440'        in hd): hd = C.STANDARD_MESSAGE_UHD
    elif ('class="fullhd"' in hd
          or 'fullhd'      in hd
          or 'full_hd'     in hd
          or    'fhd'      in hd
          or '1080'        in hd): hd = C.STANDARD_MESSAGE_FHD
    elif (   'class="hd"'  in hd
          or 'hd'          in hd
          or 'icon-hd'     in hd
          or '720'         in hd): hd = C.STANDARD_MESSAGE_HD
    else:                          hd = C.STANDARD_MESSAGE_NOHD

    return hd
#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True, delete_first_color=False):

    if not s: return ''
    s = s.strip('\r')

    if not isinstance(s, C.text_type):
##        Log('not unicode yet')
        Log(repr(s))
        s = s.decode('utf8')
        Log(repr(s))

##    Log(repr((type(s),s)))

    regex = r"(?:\[COLOR \w+\]|\[/?B\]|\[/COLOR\]|/)"
    s = re.sub(regex, "", s).strip(' ')
####    if delete_first_color:
####        s = (re.sub(u'(?i)\[cOLOR \w+?\].+?\[\/Color\]','',s))
####    s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
####    s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s))
####    s = (re.sub(u'(?i)\[\/Color\]','',s))

##    Log(repr((type(s),s)))

    #s = unicodedata.normalize('NFKD', s).encode("utf8", "ignore")
    s = unicodedata.normalize('NFKD', try_decode(s))
##    Log(repr((type(s),s)))

##    s = unicode(s.encode("utf8"), 'utf8')
##    Log(repr((type(s),s)))

##[\[\] ,\'\.\&\_\-]
## orignally only allow these     s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_\-]',' ',s))



    s = (re.sub(u'(?is)[\?]',u'Â¿',s)) #this symbol is closest I can think of to subsitute
    if include_square_braces: #permit_square_braces
        s = (re.sub(u'(?is)[    \\\/\:\*\"\<\>\|]',' ',s))
    else:
        s = (re.sub(u'(?is)[\[\]\\\/\:\*\"\<\>\|]',' ',s))

##    Log(repr((type(s),s)))
    
    while '  ' in s:
        s = s.replace('  ', ' ')
    s = s.strip()

##    Log(repr((type(s),s)))

    return s

    if include_square_braces:
        s = (re.sub("(?is)[^A-Z0-9.' &_\-\]\[]"," ",s))
    else:
        s = (re.sub("(?is)[^A-Z0-9.' &_\-    ]"," ",s))
        #s = (re.sub(u'(?is)[^A-Za-z0-9~     ,\'.&_\-]',' ',s))

    while '  ' in s:
        s = s.replace('  ', ' ')
    return s.strip()
#__________________________________________________________________________
#
class Progress_Dialog(object):
    import threading, xbmcgui
    def __init__(
        self
        , title
        , message
        ):
        if threading.current_thread().name != "MainThread":
            self.dialog_progress = None
        self.dialog_progress = xbmcgui.DialogProgress()
        self.dialog_progress.create(title, message)
        self.percent = 0.01
        
    def iscanceled(self):
        if self.dialog_progress:
            return self.dialog_progress.iscanceled()
        else:
            return True
    def close(self):
        if not self.dialog_progress: return
        self.dialog_progress.close()
        self.dialog_progress = None
    def increment_percent(self, val=0.07):
        self.percent += val
        self.percent = min(self.percent,100)
        self.dialog_progress.update(int(self.percent))
        if self.percent == 100:
            self.percent = 75
    def percent(self):
        return self.percent
    def update(self
               ,percent
               ,message=None
               ,line2=None
               ,line3=None
               ):
        if not self.dialog_progress: return

        percent = min(percent,100)
##        Log(repr(percent),xbmc.LOGNONE)
        if not message:
            self.dialog_progress.update(int(percent))
            self.percent = percent
            return
        if line2 is None:
            self.dialog_progress.update(int(percent), message)
            self.percent = percent
            return
        if line3 is None:
            self.dialog_progress.update(int(percent), message, line2)
            self.percent = percent
            return
        
        #self.dialog_progress.update(int(percent), message, line2, line3) #pre kodi 19
        self.dialog_progress.update(int(percent), message+'[CR]'+line2+'[CR]'+line3) #post kodi 18
        self.percent = percent

        if self.percent == 100:
            self.percent = 75
#__________________________________________________________________
#
def Add_Refresh_Item(mode, name=C.STANDARD_MESSAGE_REFRESH, iconimage=C.refresh_icon, progress_dialog=None, end_directory=False, duration=C.STANDARD_DURATION_REFRESH ):
##    Kodi 18 needs these options for container.refresh to work
##        ,duration=C.STANDARD_DURATION_REFRESH 
##        ,Folder=False 
    if progress_dialog:
        if progress_dialog.iscanceled():
            end_directory = False
            addDir(
                name='Refresh this Cancelled Listing'
                ,url=C.DO_NOTHING_URL
                ,mode=mode
                ,iconimage=C.warning_icon
                ,duration=duration
                ,Folder=False 
                )
    if end_directory:
        addDir(
            name=name
            ,url=C.DO_NOTHING_URL
            ,mode=mode
            ,iconimage=iconimage
            ,duration=duration
            ,Folder=False 
            )
#__________________________________________________________________________
#
class ThreadWithStopEvent(threading.Thread):
    _stop_event = None
    def __init__(self, group=None, target=None, name=None, args=(), kwargs=None, stop_event=None):
        super(ThreadWithStopEvent,self).__init__(group=group, target=target, name=name, args=args, kwargs=kwargs)
        self.args = args
        self.kwargs = kwargs
        self._stop_event = stop_event
#__________________________________________________________________
#
def Is_Online(server=C.DEFAULT_IS_ONLINE_SERVER_NAME, port=C.DEFAULT_IS_ONLINE_SERVER_PORT):

    #todo: maybe change this to be proxy aware i.e. do a http get to server
    
    #use simplecache to store last time we did a network check
    # ... works like a static var across all threads
    cache_id = C.addon_id+'.Is_Online.'+"last_online_check"
    last_online_check = global_cache.get(cache_id)
    if last_online_check:
##        Log("skip Is_Online() Error to be more obvious on logs") #dev
        return True

    
    ip = xbmc.getIPAddress() #in case we don't have IP
    if (not ip) or ip.startswith('169.254'): # or ip.startswith('172.'):
        return False

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(3)
    try:
        qq = s.connect_ex((server, int(port)))
        if not qq == 0:
            raise Exception(qq)
    except:
        if C.DEBUG: traceback.print_exc()
        try:
            Sleep(1000)
            qq = s.connect_ex((server, int(port)))
            if not qq == 0:
                raise Exception(qq)
        except:
            return False
            raise
    finally:
        s.close()

    last_online_check = datetime.datetime.now()
    global_cache.set(
        endpoint = cache_id
        ,data = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ,expiration = datetime.timedelta(seconds=C.default_ISONLINE_cache_duration)
        )
    
    return True
#__________________________________________________________________
#
def crawl(q, all_method_results):
   #Log(repr(q.empty()))
    while not q.empty():
        work = q.get(timeout=C.WEBCRAWLER_THREAD_TIMEOUT)
       #Log(repr(work))
        index_for_result = work[0]
        method_to_call = work[1]
        keyword_arguments_for_method_to_call = work[2]
        import time
        t_start = time.time()
        try:
            single_method_result = method_to_call(**keyword_arguments_for_method_to_call)
        except Exception as ex:
            single_method_result = repr(ex)
        all_method_results[index_for_result] = single_method_result
        t_end = time.time()
        q.task_done()
       #Log("The time spent in thread {} is {}".format(index_for_result, t_end - t_start), C.LOGNONE)
        
    return True
#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
##        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
#__________________________________________________________________
# helper function to select an unused port on the host machine
def select_unused_port():
    import socket
    port = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('127.0.0.1', 0))
        addr, port = sock.getsockname()
        #sock.shutdown()
        sock.close()
    except Exception as ex:
        traceback.print_exc()
        port = 8666
    return port
#__________________________________________________________________________
#
