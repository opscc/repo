# -*- coding: utf-8 -*-
#__________________________________________________________________
#
import AES_key_net
import base64
try:
    import BaseHTTPServer
except:
    import http.server as BaseHTTPServer
    
import re
try:
    import urlparse
except:
    from urllib import parse as urlparse
    
import xbmc
import xbmcaddon

from resources.lib.utils import Log as Log
from resources.lib.utils import get_setting as GetSetting

net = AES_key_net.Net()

#__________________________________________________________________
#
class AES_key_proxy(BaseHTTPServer.BaseHTTPRequestHandler):
#__________________________________________________________________
#
    def log_message(self, format, *args):
        return #"""Disables the BaseHTTPServer log."""
#__________________________________________________________________
#
    def do_GET(self):
        try:
            url = base64.b64decode(self.path[1:])
        except:
            url = self.path
            pass
        try:
            headers_string = '|'+url.split('|')[1]
            stream_headers = dict(urlparse.parse_qsl( headers_string  ))
##            Log(repr(stream_headers))
            for h in stream_headers:
##                Log(repr((h, stream_headers[h])))
                if h.startswith('|'):
                    stream_headers[h.strip('|')] = stream_headers[h]
                    stream_headers.pop(h)
##            Log(repr(stream_headers))
                    
        except:
            stream_headers = {}
            headers_string = ""
        try:
            url = url.split('|')[0]
        except:
            pass

         
        Log(repr((url,stream_headers )))
        self.path = url
        self.send_response(200)
        resp =  net.http_GET(url=url, headers=stream_headers)
        get_url = resp.get_url()



##        self.path = url
##        self.send_response(200)
##        self.wfile.write(resp.content)
##        return



        is_mpeg = False
        cl = len(resp.content)

##        mpeg_headers = (
##            "application/vnd.apple.mpegurl"
##        #,"text/html;charset=UTF-8"
##        #,"text/html; charset=UTF-8"
##        )
##        content_type = 'unknown'
##
##        for h in resp.get_headers():
##            h2 = h.split(":",1)
##            h = h2[0]
##            v = h2[1]
##            if h in 'Content-Type':
##                content_type = v.splitlines()[0].strip()
##                is_mpeg = (content_type in  mpeg_headers)
####            Log(repr((h,v,cl)))

        if cl < 5000:
            content = resp.content
            is_mpeg = '#EXTM3U' in content
        if is_mpeg:
            self.send_header('Content-Type', "application/x-mpegURL")


        self.end_headers()

        try:

                
            if is_mpeg and False:
                get_url = resp.get_url()
                get_url = get_url[0:get_url.rindex('/')+1]

                
                regex = '#EXT-X-STREAM-IN.+?\n(.+?)(\n|$)'
                r = re.search(regex, content, re.DOTALL)
                if r:
                    #go back to this proxy so that next packet can replace AES key path
                    Log('replacing stream')
                    redir = r.group(1)
                    if not('http' in redir): #sometimes a completely different server, sometimes relative
                        redir = get_url+r.group(1)
                    
                    Log(repr(redir))
                    Log(repr(headers_string))
                    video_url = 'http://127.0.0.1:{}/'.format(GetSetting('AES_key_service_port_current')) \
                                +base64.b64encode(redir+headers_string)
    ##                Log(video_url)
                    content = content.replace(r.group(1), video_url )
                    

                regex = 'xxxx(#EXT-X-KEY:METHOD=AES-128)'
                r = re.search(regex, content, re.DOTALL)
                if r:
                    Log('replacing #EXT-X-KEY url')
                    regex = GetSetting("key_search_regex")
                    replace_source = GetSetting("key_replace_source")
                    replace_target = GetSetting("key_replace_target")
                    Log(repr((regex,replace_source,replace_target)))
                    r = re.search(regex, content, re.DOTALL)
                    if r:
                        content = content.replace(r.group(1), r.group(1).replace(replace_source,replace_target)+headers_string)
                        Log('replaced #EXT-X-KEY url')

                    Log('replacing stream data')
                    regex = '(#EXTINF.+?\n)(.+?)(?:\n|$)'
                    search_results = re.findall(regex, content, re.DOTALL)
                    ff = ''
                    for q, r in search_results:
                        if not('http' in r):#sometimes a completely different server, sometimes relative
                            ff = get_url + r
                            content = content.replace(r,ff)
                            Log('replaced #EXTINF url')

                Log(repr(content))
                self.wfile.write(content)
                
            else:
                Log('writing content directly for '+get_url)
                self.wfile.write(resp.content)
        except Exception as e:
            Log(repr(e),xbmc.LOGERROR)
            url = self.path
            pass

#__________________________________________________________________
#
