# -*- coding: utf-8 -*-
import routing
import sys
import traceback
import utils
import xbmc
import xbmcaddon
import xbmcplugin
from xbmcplugin import endOfDirectory
plugin = routing.Plugin()
#__________________________________________________________________________
#
@plugin.route('/9999')
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________________
#
def run():
    if int(sys.argv[1]) > 0: xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available
    plugin.run()
#__________________________________________________________________________
#
@plugin.route('/')
def index():
    try:
        import tvi
        tvi.addTVIIcons(plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding TVI", duration=4000)
    try:
        import euronews
        euronews.addEuronewsIcon(plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Euronews", duration=4000)
    try:
        import fatima
        fatima.addFatimaIcon(plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Fatima", duration=4000)
    try:
        import rtp
        rtp.addRTPicons(plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding RTP icons", duration=4000)

    endOfDirectory(plugin.handle, cacheToDisc=True)
#__________________________________________________________________________
#
@plugin.route('/play')
def play():
    rel_url = plugin.args["rel_url"][0]
    channel = plugin.args["channel"][0]
    prog = plugin.args["prog"][0]
    icon = plugin.args["img"][0]

    if prog == "PT Euronews":
        import euronews
        euronews.play_euronews(prog,rel_url,channel,icon)
        return
    if channel.startswith('TVI'):
        import tvi
        tvi.play_tvi(prog,rel_url,channel,icon)
        return
    if prog == "Fatima":
        import fatima
        fatima.play_fatima(prog,rel_url,channel,icon)
        return
    if channel.startswith('RTP'):
        import rtp
        rtp.play_rtp(prog,rel_url,channel,icon)
        return
#__________________________________________________________________________
#
        
