# -*- coding: utf-8 -*-
import constants as C
import json
import re
import urllib
import utils
import traceback
import xbmc

from utils import Log
from utils import Log as log
from utils import Notify as notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

#__________________________________________________________________________
#
def addEuronewsIcon(plugin,play):
    channel = "PT Euronews"
    prog = "PT Euronews"

    liz = ListItem("[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
        C.channel_text_color
         , kodiutils.smart_str(channel)
         , C.program_text_color
         , kodiutils.smart_str(prog)
        )
    )

    img = "https://static.euronews.com/website/images/live.jpg"
    img = img + "|User-Agent=Mozilla/5.0 (MSIE 10.0; Windows NT 6.1; Trident/5.0)"
    liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
    finalurl=C.EURONEWS_BASE
    addDirectoryItem(plugin.handle
                     , plugin.url_for(
                         play
                           , rel_url=kodiutils.smart_str(finalurl)
                           , channel=kodiutils.smart_str(channel)
                           , img=kodiutils.smart_str(img)
                           , prog=kodiutils.smart_str(prog)
                         )
                     , liz
                     , False)
##    utils.Notify(msg="Error parsing EuronewsIcon main page", duration=4000)
#__________________________________________________________________________
#
def play_euronews(prog,rel_url,channel,icon):
    
    page_content = utils.getHtml("https://pt.euronews.com/api/watchlive.json")
    json_content = json.loads(page_content)
##    Log("page_content='{}'".format(page_content))

    youtube_embed_url = "https://www.youtube.com/embed/" + json_content["videoId"]
##    Log("youtube_embed_url='{}'".format(youtube_embed_url))

    full_html = utils.getHtml(youtube_embed_url)
##    Log("full_html='{}'".format(full_html))

    regex = (
        'ytcfg\.set\((.+?)\);</script>'
        )
    json_html = re.compile(regex).findall(full_html)
    if json_html: json_html = json_html[0]
    else: json_html = "{}"
   
    json_content = json.loads(json_html)
##    Log("json_content='{}'".format(repr(json_content)))

    youtube_embed_url = "https://www.youtube.com/youtubei/v1/player?key=" + json_content["INNERTUBE_API_KEY"]
##    Log("youtube_embed_url='{}'".format(youtube_embed_url))

    post_json = (
        '{"videoId":"'+json_content["VIDEO_ID"]+'"'
        ',"playbackContext":{},"captionParams":{}'
        ',"context":{'
        '         "client":'
        '                  {"clientName":"' + json_content["INNERTUBE_CLIENT_NAME"] +  '"'
        '                  ,"clientVersion":"'+json_content["INNERTUBE_CLIENT_VERSION"]+ '"}'
        '         ,"user":{}'
        '         ,"adSignalsInfo":{"params":[] }'
        ' } } '
    )
##    Log("post_json='{}'".format(repr(json.loads(post_json))))
    json_html = utils.postHtml(youtube_embed_url, sent_data=post_json)
##    Log("json_html='{}'".format(json_html))

    json_content = json.loads(json_html)
##    Log("json_content='{}'".format(repr(json_content)))

    m3u8_url = json_content['streamingData']['hlsManifestUrl']
    Log("m3u8_url='{}'".format(m3u8_url))
##    Log("m3u8_url='{}'".format(urllib.unquote_plus(m3u8_url)))

##    content_list_url = "https:" + json_content["url"]
##    Log("content_list_url='{}'".format(content_list_url))
##
##    page_content = utils.getHtml(content_list_url)
##    json_content = json.loads(page_content)
##    Log("page_content='{}'".format(page_content))
##
##    m3u8_url = json_content["primary"] #"primary" #"backup"
##   return
##    m3u8_url = 'https://manifest.googlevideo.com/api/manifest/hls_variant/expire/1615239417/ei/mURGYJ2yAZLzNpOaqJAE/ip   /76.10.152.152/id/VOw7bts_rGQ.2/source/yt_live_broadcast/requiressl/yes/tx/23722138/txs/23722138%2C23722139/hfr/1/playlist_duration/30/manifest_duration/30/maudio/1/gcr/ca/vprv/1/go/1/nvgoi/1/keepalive/yes/fexp/24007246/dover/11/itag/0/playlist_type/DVR/sparams/expire%2Cei%2Cip%2Cid%2Csource%2Crequiressl%2Ctx%2Ctxs%2Chfr%2Cplaylist_duration%2Cmanifest_duration%2Cmaudio%2Cgcr%2Cvprv%2Cgo%2Citag%2Cplaylist_type/sig/AOq0QJ8wRQIgPR9ENCB74KjYxmHho7GfqcyO69nUSFUuSrnqemtRczECIQC1ku65PmCFACzWII9IYZ4ywNSfTPwinfnPqL3EfMiczQ%3D%3D/file/index.m3u8'
##    Log("m3u8_url='{}'".format(m3u8_url))

    Log("prog='{}'".format(prog.encode('utf8')))
    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog)
    url = m3u8_url + utils.Header2pipestring() 
    utils.playvid(url, name=name, play_profile="profile_02")
                        
#__________________________________________________________________________
#
