# -*- coding: utf-8 -*-
from resources.lib import plugin
plugin.run()


