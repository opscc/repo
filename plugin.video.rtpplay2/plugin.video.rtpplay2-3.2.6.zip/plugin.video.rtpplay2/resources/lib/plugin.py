# -*- coding: utf-8 -*-



import xbmc
import xbmcgui

import inputstreamhelper
import urllib
import urllib2

import base64

import routing
import logging
import requests
import re
import xbmcaddon
import json

from sys import exit, version_info
from resources.lib import kodiutils
from resources.lib import kodilogging
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl


import sys

__scriptname__="RTPplay2"
ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))
kodilogging.config()
plugin = routing.Plugin()
addon_handle = sys.argv[1]

PROTOCOL = 'mpd'
DRM = 'com.widevine.alpha'
#STREAM_URL = 'https://demo.unified-streaming.com/video/tears-of-steel/tears-of-steel-dash-widevine.ism/.mpd'
#LICENSE_URL = 'https://cwip-shaka-proxy.appspot.com/no_auth'

__user_agent__ = "Mozilla/5.0 (MSIE 10.0; Windows NT 6.1; Trident/5.0)"

#__headers__ = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"}
__headers__ = {"Accept-Language":"en-US,en;q=0.9"
               ,"Accept-Encoding":"gzip, deflate"
                ,"User-Agent":"Mozilla/5.0 (MSIE 10.0; Windows NT 6.1; Trident/5.0)"
                }


def log(msg="", loglevel=None):
    debug = None
    try: debug = (xbmcaddon.Addon().getSetting('debug').lower() == "true")
    except: debug = True
    if   loglevel:  xbmc.log(msg , loglevel)
    elif    debug:  xbmc.log(msg , xbmc.LOGNONE)
    else:           xbmc.log(msg)

def notify(msg="", duration=5000, header=__scriptname__, icon="" ):
    log( str(msg), xbmc.LOGNOTICE)    
    xbmcgui.Dialog().notification(header, msg, icon, duration, sound=False )

def header2pipestring(header=__headers__):
    q = "|{}".format( repr(header) )
    q = q.replace( "{'", "")
    q = q.replace( "'}", "")
    q = q.replace( "': '", "=" )
    q = q.replace( "', '", "&" )
    return q

#log( 'logger'+xbmcaddon.Addon().getAddonInfo('id'), xbmc.LOGNONE)
                              
__base_url__ = "http://www.rtp.pt"
__session__ = requests.Session()

TVI_BASE = "http://tviplayer.iol.pt"

if version_info >= (3, 0):
	from html.parser import HTMLParser
else:
	from HTMLParser import HTMLParser
html_parser = HTMLParser()



def addTVIIcons(plugin):
        
        try:
		req = __session__.get(TVI_BASE+ "/direto").text
        except Exception, e:
                notify("getting TVI main page", str(e), 4000) 
        
        
        match=re.compile('class="direto-canal-box videoUpdate" data-canal="(.+?)"\W*<a href="(.+?)".+img src="(.+?)"[\w\W]*?link-programa">\s+(.+?)\W*<\/a>').findall(req)       
        if match:
                for channel,rel_url,img,prog in match:
                        img = img + "|User-Agent=Mozilla/12.0"
                        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                        liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                        #liz.setProperty('IsPlayable', 'true')
                        liz.setInfo("Video", infoLabels={"plot": prog})
                        finalurl=TVI_BASE+rel_url
                        addDirectoryItem(plugin.handle, plugin.url_for(play
                                                                       , rel_url=kodiutils.smart_str(finalurl)
                                                                       , channel=kodiutils.smart_str(channel)
                                                                       , img=kodiutils.smart_str(img)
                                                                       , prog=kodiutils.smart_str(prog) )
                                         , liz
                                         , False)


##def addTVIIcon(plugin):
##        try:
##		req = __session__.get("http://tviplayer.iol.pt/direto/TVI").text
##        except Exception, e:
##                notify("getting TVI main page", str(e), 4000) 
##        channel = "TVI"
##        prog = "TVI"
##        match=re.compile('videoUrl = "(.+?)"').findall(req)
##       
##        if match:
##                i=0
##                for rel_url in match:
##                        i=i+1
##                        #four urls are found, just use the last one
##                        finalurl=rel_url
##
##                liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(i)))
##                img = "http://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/58ab3cae0cf2b10cb661350e"
##                liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
##                liz.setProperty('IsPlayable', 'true')
##                liz.setInfo("Video", infoLabels={"plot": i})
##                addDirectoryItem(plugin.handle, plugin.url_for(play
##                                                               , rel_url=kodiutils.smart_str(finalurl)
##                                                               , channel=kodiutils.smart_str(prog)
##                                                               , img=kodiutils.smart_str(img)
##                                                               , prog=kodiutils.smart_str(prog) ), liz, False)
##                        
##                
##def addTVI24Icon(plugin):
##        try:
##		req = __session__.get("http://tviplayer.iol.pt/direto/TVI24").text
##        except Exception, e:
##                notify("getting TVI main page", str(e), 4000) 
##        channel = "TVI24"
##        prog = "TVI24"
##        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
##        match=re.compile('videoUrl = "(.+?)"').findall(req)
##        if match:
##                for rel_url in match:
##                        img = "http://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/58ab3cc20cf2b10cb6613516"
##                        liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
##                        liz.setProperty('IsPlayable', 'true')
##                        liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
##                        addDirectoryItem(plugin.handle, plugin.url_for(play, rel_url=kodiutils.smart_str(rel_url), channel=kodiutils.smart_str(channel), img=kodiutils.smart_str(img), prog=kodiutils.smart_str(prog) ), liz, False)
##                        break
##


##def getHtml(url, referer=None, hdr=None, data=None, url_timeout=3, verify=True):
##    if url=='': return None
##    log("reading html for url '{}'".format(url))
##
##    if not hdr:   req = urllib2.Request(url, data, __headers__)
##    else:         req = urllib2.Request(url, data, hdr)
##
##    if referer:   req.add_header('Referer', referer)
##
##    if data:      req.add_header('Content-Length', len(data))
##
##    try:          response = urllib2.urlopen(req, timeout=url_timeout)
##    except Exception as err:
##        log(str(err))
##        #traceback.print_exc(file=sys.stdout)
##
##    if response.info().get('Content-Encoding') == 'gzip':
##        buf = StringIO.StringIO( response.read())
##        f = gzip.GzipFile(fileobj=buf)
##        data = f.read()
##        f.close()
##    else:
##        data = response.read()
##        
##    response.close()
##    return data


def addFatimaIcon(plugin):
        channel = "Fatima"
        prog = "Fatima"

        try:
		req = __session__.get("https://www.fatima.pt/en/pages/online-transmissions", verify=False).text
                #req = getHtml("https://www.fatima.pt/en/pages/online-transmissions")
		req = req.encode('utf-8') 
                log("Fatima full web page %s " % req)

                
                liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                #match=re.compile('<iframe allowfullscreen="" frameborder="0" scrolling="no" src="http:.+file=(.+)&amp;[\w\W]+youtube\.com\/embed\/(\w+)').findall(req)
                match=re.compile('playhtml\?file=(.+)"[\W\w]+www.youtube.com\/embed\/(\w+)"').findall(req)
                
                if match:
                        for rel_url,img in match:
                                #rel_url = rel_url + "?all=1"
                                img = "https://i.ytimg.com/vi/" + img + "/maxresdefault_live.jpg"
                                img = img + "|User-Agent=Mozilla/5.0 (MSIE 10.0; Windows NT 6.1; Trident/5.0)"
                                liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                                #liz.setProperty('IsPlayable', 'true')
                                liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
                                addDirectoryItem(plugin.handle
                                                 , plugin.url_for(play
                                                                  , rel_url=kodiutils.smart_str(rel_url)
                                                                  , channel=kodiutils.smart_str(channel)
                                                                  , img=kodiutils.smart_str(img)
                                                                  , prog=kodiutils.smart_str(prog) )
                                                 , liz
                                                 , False)
                else:
                        log("no match for fatima url search")
        except Exception, e:
                log("getting fatima page {}".format(str(e)), xbmc.LOGERROR)


@plugin.route('/')
def index():

        req = ""
        try:
		req = __session__.get("http://www.rtp.pt/play/", headers=__headers__).text
	except:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32001))
		exit(0)
		
	match=re.compile('<a title=".+?direto (.+?)" href="(.+?)".+?img.+?src="(.+?)" class="img-responsive">.+?<span class="small"><b>(.+?)</b>').findall(req)
        #log("match\n\n\n", xbmc.LOGNONE)
	if match:
                i = 0
		for channel ,rel_url ,img ,prog in match:
                        if i == 3:
                                addFatimaIcon(plugin)
                                #addTVI24Icon(plugin)
                                #addTVIIcon(plugin)
                                addTVIIcons(plugin)
                        
			liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
			if img.startswith("/"): img = "http:{}".format(img)

			img = img + "|User-Agent=Mozilla/5.0 (MSIE 10.0; Windows NT 6.1; Trident/5.0)&Range=bytes=0-&Content-Type=image/jpeg&Accept=*/*"
			
			liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
			liz.setProperty('IsPlayable', 'true')  #this must be set to True if you are goint to use setResolvedUrl later on
			liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
			#liz.setInfo(type="Video", infoLabels={"Title": prog})
			
##			addDirectoryItem(plugin.handle
##                                        , ''
##                                        , liz
##                                        , False)
			url = plugin.url_for(
                                                        play
                                                        , rel_url=kodiutils.smart_str(rel_url)
                                                        , channel=kodiutils.smart_str(channel)
                                                        , img=kodiutils.smart_str(img)
                                                        , prog=kodiutils.smart_str(prog)
                                                        )
                        #log(url, xbmc.LOGNONE)
			addDirectoryItem(plugin.handle
                                        , url
                                        , liz
                                        , False)
			
                        i = i + 1
                        
	endOfDirectory(plugin.handle)

        #log("end\n\nmatch\n\n\n", xbmc.LOGNONE)
        #return 0

@plugin.route('/play')
def play():
        #log('/play', xbmc.LOGNONE)
        #return

	rel_url = plugin.args["rel_url"][0]
	channel = plugin.args["channel"][0]
	prog = plugin.args["prog"][0]
	icon = plugin.args["img"][0]

        if prog == "Fatima":
                try:
                        #kodiutils.ok("Debug:" + prog, rel_url)
                        log("rel_url:"+rel_url)
                        match=re.compile('(http[sS]?:[\/]{2}.*?)(\/.*)\&').findall(rel_url)
                        
                        if match:
                                for baseURL, relURL in match:
                                        log(   baseURL + relURL )
                                        try:
                                            req = __session__.get("{}{}?all=1".format(baseURL, relURL), headers=__headers__ ).text
                                        except:
                                            req = __session__.get("{}{}?all=1".format(baseURL, relURL), verify=False, headers=__headers__ ).text
                                            
                                        d = json.loads(req)
                                        log(   str(d) )
                                        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                                        liz.setArt({"thumb": icon, "icon": icon})
                                        #liz.setPath("{}".format(d['hls']))
                                        #liz.setPath("{}".format(d['rtmp']))
                                        #liz.setPath("{}".format(d['ss']))
                                        #liz.setPath("{}".format(d['rtsp']))

                                        
                                        
                                        fsu="{}{}".format(d['hls'],  header2pipestring()     )
                                        #liz.setPath("{}{}".format(d['hls'], "|User-Agent=Mozilla/12.0" ))
                                        liz.setPath(fsu)
                                        log(   liz.getPath()  )

                                        #liz.setProperty('IsPlayable', 'true')
                                        
                                        #liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                                        #liz.setProperty('inputstream.adaptive.manifest_type', 'hls')

                                        xbmc.Player().play(fsu, liz)                                        
                                        setResolvedUrl(plugin.handle, True, liz)
                                        return
                                    
                except Exception as e:
                        log("Error playing {}:'{}'".format(prog,e) )
                        exit(1)

                exit(0)

                

        #notify("TVI", prog, 1000)
        #notify("TVI", channel, 1000)
        if channel.startswith('TVI'):
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify("TVI", "parsing TVI page", 1000)
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify("TVI", rel_url, 1000)
                req = __session__.get(rel_url).text
                match=re.compile('videoUrl = "(.+?)"').findall(req)
                for rel_url in match:
                        #four urls are found, just use the last one
                        final_stream_url=rel_url

                log("finalstream for m38 is " + final_stream_url )
                #this is an m3u8 file, force the slowest stream
                #        |
                tviheaders = {"Origin":"http://tviplayer.iol.pt"
                              ,"Accept-Encoding":"gzip, deflate, br"
                              ,"Accept-Language":"en-US,en;q=0.9"
                              ,"Referer":"http://tviplayer.iol.pt/direto/TVI"
                              ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
                              }
                req = __session__.get(final_stream_url, verify=False, headers=tviheaders).text

                log("m3u8 file contens " + req )
                
                pattern = '#EXT-X-STREAM-INF:BANDWIDTH=(\d+?),.*\\n(.+?)\\n'
                streams = re.findall(pattern, req)
                if streams:
                    
                    if kodiutils.get_setting_as_bool("debug"):
                        notify("TVI", "streamsfound", 1000)
                    best = 0
                    if kodiutils.get_setting_as_bool("useLowestTVIquality"):
                            best = 9999999
                    for bandwidth, stream_url in streams:
                        if kodiutils.get_setting_as_bool("debug"):
                                notify("bandwidth", str(bandwidth), 5000)

                        if kodiutils.get_setting_as_bool("useLowestTVIquality") == True:
                                if int(bandwidth) < best:
                                    best = int(bandwidth)
                                    playurl = stream_url
                        else:
                                if int(bandwidth) > best:
                                    best = int(bandwidth)
                                    playurl = stream_url
                                

                match=re.compile('(http[sS]?:[\/]{2}.*?)(\/.*)').findall(final_stream_url)
                for baseURL, relURL in match:
                        playurl = baseURL + "/" + playurl

                if kodiutils.get_setting_as_bool("debug"):
                        notify("TVI", playurl, 10000)
                log("found playurl " + playurl )
                final_stream_url = playurl

                liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                liz.setArt({"thumb": icon, "icon": icon})
                #liz.setProperty('IsPlayable', 'true')
                #liz.setProperty('IsFolder', 'false')
                liz.setPath("{}|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url))


##                liz.setPath("{}|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url.split('?')[0]))
##                liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
##                liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
##                wv_proxy_base = 'http://localhost:' + str(ADDON.getSetting('wv_proxy_port'))
##                token=''
##                encryptionkey=''
##                wv_proxy_url = '{0}?mpd_url={1}'.format(wv_proxy_base, final_stream_url)
##                liz.setPath("{}|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(wv_proxy_base))
                                
                #liz.setProperty('inputstream.adaptive.license_key', '|' + final_stream_url.split('?')[1] + '||')
                
                #is_helper = inputstreamhelper.Helper('hls','')
                #liz.setPath("{}".format(final_stream_url.split('?')[0]))
                ##|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".

                liz.setPath("{}|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/13.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url))

#                liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
#                liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
#                liz.setProperty('inputstream.adaptive.license_key', '||||')

                xbmc.Player().play(liz.getPath() , liz) 
                #setResolvedUrl(plugin.handle, True, liz)
                exit(0)
                
        




        #if we get here, then it is a RTP stream

#req = __session__.get("http://www.rtp.pt/play/", headers=__headers__).text
        #read the web page for the channel                
	try:
		req = __session__.get("{}{}".format(__base_url__, rel_url) , headers=__headers__ ).text
	except:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
		exit(0)

	streams = ''
	final_stream_url = ''

        #regex working 2018-04-15 to 2018-05-03
	log("Dash req " + "{}{}".format(__base_url__, rel_url) )
        streams = re.compile('dash\:"(.+?)"', re.DOTALL).findall(req)
        #regex working 2018-05-07 to 2018-05-21
        streams = re.compile('k\: \'(.+?)\'[\w\W]*dash\:"(.+?)"', re.DOTALL).findall(req)
        #regex working 2018-05-22 to 2018-06-13
        streams = re.compile('k\:[\w\W]*k\: \'(.+?)\'[\w\W]*dash\:"(.+?)"').findall(req)
        #regex working 2018-06-14 to 2018-???
        streams = re.compile('k\:[\w\W]*k\: \"(.+?)\"[\w\W]*dash\:"(.+?)"').findall(req)

        #log("full web page %s " % req.encode('utf-8') )

    
	if streams:
            final_stream_url = None
            for key,stream in streams:
                    final_stream_url = stream
                    encryptionkey = key
                    xbmc.log(encryptionkey,xbmc.LOGNONE)
                    #if kodiutils.get_setting_as_bool("debug"):
                            #kodiutils.ok("Debug:" + "final_stream_url", final_stream_url)
                    if ".mpd" in stream.split('/')[-1]: 
                            if  final_stream_url.endswith('?DVR'):
                                    final_stream_url = final_stream_url[:-4]
                            break
                    else:
                            final_stream_url = None #not MPD
            log("Dash MPD stream found %s" % final_stream_url )
            log("Key found %s" % encryptionkey )
        else:
            log("regex did not produce a match")
            log("full web page %s " % req.encode('utf-8') )
            #return

        if kodiutils.get_setting_as_bool("skipDASH"):
                xbmc.log('skipping DASH because of flag', xbmc.LOGNONE)
                final_stream_url = None 

        kodi_version = xbmc.getInfoLabel('System.BuildVersion')
        if kodi_version < '17.6':
                final_stream_url = None 
                log("skipping DASH because of version %s " % kodi_version )
                if kodiutils.get_setting_as_bool("debug"):
                        notify('Progress....',"skipping DASH because of version %s " % kodi_version, 2000)

        PROTOCOL = 'mpd'
        DRM = 'com.widevine.alpha'
        
        if final_stream_url:
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify('Progress....',final_stream_url, 5000)                
                PROTOCOL = 'mpd'
                DRM = 'com.widevine.alpha'
                is_helper = inputstreamhelper.Helper(PROTOCOL, DRM)
                
                if is_helper.check_inputstream():
                        #https://github.com/peak3d/inputstream.adaptive/wiki/Playing-multi-bitrate-stream-from-a-python-addon
                        liz = ListItem(path=final_stream_url)
                        liz.setPath("{}|Connection=keep-alive&Origin=https://www.rtp.pt/play/&User-Agent=Mozilla/5.0 (MSIE 10.0; Windows NT 6.1; Trident/5.0)&Accept=*/*&Referer=https://www.rtp.pt/play/direto/rtp1&Accept-Encoding=gzip, deflate, br".format(final_stream_url))

                        liz.setArt({"thumb": icon, "icon": icon})
                        # worked before 2018-05-04
                        liz.setProperty('inputstreamaddon', is_helper.inputstream_addon)
                        #liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                        liz.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                        #setResolvedUrl(plugin.handle, True, liz)
                        #exit(0)
                        # worked 2018-05-04 to 2018-05-04
                        liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                        liz.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                        liz.setProperty('inputstream.adaptive.license_type', DRM)
                        #liz.setContentLookup(False)
                        LICENSE_URL = ''
                        LICENSE_URL = 'http://widevine-proxy.drm.technology/proxy'
                        LICENSE_URL = 'https://widevine-proxy.drm.technology/proxy'
                        #LICENSE_URL = '"B{SSM}"'
                        SPECIAL_HEADERS = '|' #none required
                        POST_DATA = '|' #none required
                        POST_RESPONSE = '|' #none required
                        POST_RESPONSE = '|J[licensetoken]'

                        # worked 2018-05-?? to 2018-??
                        SPECIAL_HEADERS = '|Content-Type=application/json'
                        #SPECIAL_HEADERS = '|Content-Type=application/json&User-Agent=Mozilla/6.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36&Referer=https://www.rtp.pt/play/direto/rtp1&Connection=keep-alive&Origin=https://www.rtp.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en'
                        SPECIAL_HEADERS = '|Content-Type=application/json&User-Agent=Mozilla/6.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36&Referer=https://www.rtp.pt/play/direto/rtp1&Origin=https://www.rtp.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en'
                        my_json_string = json.dumps({"token": encryptionkey, "drm_info":[8,4], "kid":"E13506F7-439B-EAE7-DDF0-489FCDDF7481"})
                        POST_DATA = '|' + urllib.quote_plus(my_json_string)
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[D{SSM}],"kid":"{KID}"}' % my_json_string)
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[8,4],"kid":"{KID}"}' % my_json_string)
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[b{SSM}],"kid":"{KID}"}' % encryptionkey)
                        #POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[8,4],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % encryptionkey)
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[8,4],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % encryptionkey)
                        #POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[8,1,18,187,34,18,92,10,90,10,68,8,1,18,16,154,196,52,232,105,14,94,124,184,179,237,146,171,38,211,249,26,6,118,117,97,108,116,111,34,32,55,67,53,69,55,70,57,49,49,70,55,57,50,70,50,49,66,69,53,70,69,57,66,67,57,49,57,51,67,51,51,66,42,2,72,68,50,0,16,1,26,16
                            #                                                            ,200,35,12,140,82,127,155,202,160,152,251,189,239,213,252,22,24,1,32,188,178,215,215,5,48,21,66,208,33,10,20,108,105,99,101,110,115,101,46,119,105,100,101,118,105,110,101,46,99,111,109,18,16,23,5,185,23,204,18,4,134,139,6,51,58,47,119,42,140,26,144,31,142,207,120,33,9,237,49,115,73,219,104,126,239,179,107,99,151,250,79,243,170,185,227,150,83,192,84,36,64,60,242,226,225,117,43,111,16,138,69,216,139,14,154,205,247,122,123,157,67,75,184,42,26,212,4,197,173,120,222,170,16,97,15,252,9,25,220,222,128,150,118,214,213,201,42,109,241,118,27,92,206,110,130,177,94,170,32,165,185,98,156,255,55,36,226,217,174,34,253,63,112,98,160,42,26,229,102,207,139,92,251,253,145,143,1,87,151,43,156,94,208,131,25,194,93,95,57,186,125,133,255,197,93,154,183,233,45,14,209,5,203,71,155,33,149,137,255,211,72,242,138,15,196,33,240,55,22,122,172,77,96,246,120,251,215,206,201,45,135,198,67,154,232,37,210,30,183,111,97,15,37,192,66,163,92,188,94,220,99,115,196,79,139,39,137,43,252,227,135,6,212,26,121,78,187,132,54,146,199,114,21,26,235,118,37,40,20,84,138,233,177,57,12,75,1,214,137,222,195,226,48,186,16,151,3,236,32,38,245,86,203,91,105,35,201,0,38,243,150,0,252,151,72,111,200,247,59,106,149,16,170,75,169,109,65,29,85,239,86,171,128,204,87,235,99,210,156,172,222,178,10,74,160,13,13,31,243,160,164,118,122,176,61,106,135,105,142,107,18,121,229,12,23,254,159,37,151,102,37,163,129,42,151,103,46,189,43,25,5,173,221,127,167,147,186,170,80,109,237,7,191,48,249,99,211,177,33,160,158,222,110,99,234,155,89,194,168,127,158,251,217,160,233,40,238,173,18,54,213,169,183,219,113,168,43,198,72,37,146,233,186,133,85,54,158,66,82,106,74,95,160,220,29,228,147,149,77,217,170,60,113,109,199,207,47,48,129,0,106,95,226,114,144,135,97,58,118,250,2,30,241,181,115,91,127,15,172,75,178,45,10,249,230,0,145,83,62,206,32,228,249,60,186,180,250,94,81,102,189,148,44,18,132,198,193,39,72,82,141,148,22,185,113,5,137,235,137,68,81,84,140,141,117,216,228,224,125,127,149,72,186,35,43,50,193,235,67,119,194,174,227,162,91,29,69,121,233,50,41,255,111,1,174,252,61,144,65,177,191,17,202,32,149,76,225,83,43,51,80,4,254,200,165,29,141,21,48,168,80,77,34,161,196,76,96,233,50,152,70,11,173,115,84,142,64,210,68,78,74,38,129,223,37,165,244,142,240,32,231,93,238,252,184,29,14,106,100,34,203,61,179,118,78,53,172,235,140,102,235,158,172,249,123,50,6,113,230,82,196,89,72,197,58,152,211,237,176,16,131,125,145,140,102,161,64,155,133,246,122,113,28,104,56,158,145,16,161,255,230,92,126,109,148,75,237,62,50,221,114,78,9,28,201,255,143,250,216,79,24,151,9,81,233,104,186,122,34,244,94,222,201,115,247,169,177,227,26,227,246,243,129,250,22,189,147,203,246,159,56,160,173,202,174,198,188,144,65,96,23,42,188,196,135,201,213,32,219,74,149,62,46,62,156,64,89,240,164,134,248,71,218,95,184,227,82,1,71,17,132,72,232,184,29,248,152,244,90,138,211,232,48,204,186,3,236,3,172,10,8,74,45,51,162,229,86,67,32,14,5,126,85,206,96,10,55,80,224,162,179,106,103,30,194,176,64,138,101,26,128,197,81,60,40,15,241,31,48,1,26,39,223,104,171,120,98,89,173,74,94,81,99,34,26,161,246,56,204,151,151,177,186,5,20,240,97,193,91,67,93,14,3,161,181,90,104,196,46,186,184,41,61,140,94,51,192,113,251,127,119,11,137,145,120,79,95,220,78,50,77,209,101,67,9,139,210,9,228,234,35,104,198,5,211,159,15,119,241,129,167,210,223,197,3,217,50,247,233,231,111,147,126,29,8,208,95,42,217,46,61,81,82,154,130,136,239,127,160,195,178,63,92,21,207,255,252,239,220,51,84,123,129,235,139,12,35,170,180,99,41,170,133,37,122,63,90,156,15,112,115,51,116,120,125,151,95,114,166,55,5,27,228,230,54,220,72,24,90,147,129,61,164,123,216,112,86,57,145,70,254,157,62,58,35,170,26,180,25,237,44,137,137,116,106,51,225,114,175,147,222,11,248,152,132,187,23,239,86,183,248,114,32,161,236,220,53,128,201,216,139,133,194,138,157,181,33,247,58,78,63,12,29,169,42,19,91,146,97,76,173,90,217,235,233,94,33,248,185,58,251,9,149,19,248,103,57,43,220,33,197,84,101,38,91,144,104,231,210,212,252,88,64,135,145,248,213,43,26,209,165,197,53,234,178,195,130,38,71,61,243,77,217,132,32,140,244,98,151,222,255,18,252,35,8,69,132,102,215,120,95,61,54,209,84,149,141,227,29,13,160,154,231,127,254,22,19,185,80,58,94,198,174,136,225,26,0,18,144,186,114,75,8,8,207,4,56,98,204,96,183,79,155,157,193,138,210,209,240,72,52,182,112,135,213,188,244,207,43,48,129,230,18,41,69,227,194,149,35,197,85,75,121,30,249,0,201,6,187,138,245,32,211,19,27,58,133,15,213,223,51,173,162,121,140,51,232,199,160,131,187,64,207,159,217,27,52,167,217,62,205,195,26,162,110,149,182,169,190,21,89,171,216,228,134,200,113,247,187,246,82,152,73,191,70,165,13,208,41,38,25,215,149,172,248,157,14,10,49,153,88,174,217,29,250,90,238,126,152,119,206,186,191,75,58,41,150,219,240,214,148,214,53,117,106,204,93,178,131,16,174,97,241,151,12,197,142,194,253,54,146,181,129,65,186,130,4,195,31,9,105,75,71,213,125,219,3,236,246,198,191,142,94,230,48,222,41,213,233,85,132,74,141,46,122,66,246,155,10,101,80,77,14,20,204,236,32,178,23,207,196,217,29,90,49,20,121,179,131,69,143,45,65,105,34,189,197,55,170,167,57,109,188,103,20,122,63,244,67,41,252,102,176,142,89,18,29,169,30,221,34,156,142,252,155,230,113,107,19,206,83,87,206,162,51,209,63,46,183,50,81,40,91,11,247,213,220,203,142,143,141,254,170,47,111,249,241,47,239,90,148,191,45,230,196,118,182,230,97,221,67,133,83,38,31,121,47,143,112,54,194,242,55,205,160,236,36,158,182,142,245,93,33,64,10,4,104,22,205,2,51,33,80,186,137,58,105,1,138,76,69,156,227,251,222,48,73,102,57,129,102,100,8,173,66,251,11,97,96,157,255,64,71,73,73,211,7,69,150,207,3,247,50,154,245,99,31,220,100,164,210,110,97,160,240,52,238,165,137,75,76,100,87,34,84,218,41,157,32,194,29,91,155,77,16,115,150,12,165,158,154,128,4,13,96,234,83,219,76,84,33,180,65,76,251,109,45,74,148,179,64,212,117,40,110,114,83,254,167,243,11,170,227,43,41,248,65,195,83,85,106,6,1,8,60,86,240,66,20,254,103,142,217,54,12,164,222,197,231,245,162,24,44,238,187,208,230,243,246,168,76,250,44,108,32,199,193,171,235,78,5,57,136,16,205,148,39,103,24,220,177,16,20,21,46,177,160,190,181,43,226,76,83,103,54,10,190,156,11,127,32,37,162,250,150,165,97,228,209,81,87,178,3,17,156,134,10,28,201,53,235,48,136,229,215,171,203,90,217,90,217,213,234,238,173,86,80,196,42,106,27,206,17,113,4,58,78,109,125,71,127,132,214,41,215,83,189,58,219,125,29,112,125,79,22,206,72,9,15,191,212,173,190,9,0,163,195,72,253,251,66,238,162,31,152,182,6,169,128,194,112,139,226,170,245,131,186,235,166,101,9,110,255,90,175,193,225,225,230,184,12,22,95,12,5,51,6,210,145,4,33,185,95,103,182,151,59,82,122,49,52,14,12,158,3,13,144,123,62,41,99,184,120,233,25,63,165,183,106,18,195,111,215,56,120,40,114,32,185,54,212,168,183,126,105,73,9,142,224,228,158,56,215,91,176,153,54,252,173,144,66,181,206,101,94,144,11,211,228,172,160,61,156,234,152,241,81,12,130,112,230,247,233,132,110,182,13,134,239,230,187,124,183,245,251,147,162,131,105,2,240,29,192,224,247,122,234,51,50,60,120,107,246,182,146,122,9,70,114,199,50,73,124,143,190,70,63,94,15,175,133,175,225,65,58,15,102,251,19,116,117,63,227,241,249,232,37,163,22,202,106,94,184,133,105,175,255,144,73,24,119,6,85,79,137,14,190,162,110,189,212,73,185,76,221,8,23,97,222,55,168,122,190,70,252,165,238,190,105,91,133,177,91,161,130,203,180,40,16,15,2,241,173,140,215,107,37,23,4,113,151,87,124,106,161,75,52,172,65,11,145,245,253,49,223,151,143,155,65,247,129,89,235,100,23,87,39,66,167,236,231,182,129,63,4,60,182,63,209,82,58,52,135,60,154,139,106,188,226,221,14,113,6,85,2,184,8,6,135,66,100,81,240,193,110,196,133,247,50,12,252,34,0,250,236,147,120,102,32,194,105,83,195,79,102,137,51,115,69,124,253,204,254,108,61,247,175,48,59,223,70,11,178,217,192,44,202,23,121,237,247,135,90,4,90,141,127,175,55,64,216,211,26,253,186,128,89,55,45,97,192,189,230,133,228,179,173,128,84,46,199,46,181,139,141,19,199,249,236,200,161,205,157,9,101,180,93,44,221,94,130,240,246,227,85,30,121,169,178,74,19,97,241,107,81,210,137,186,4,36,203,53,250,150,199,176,239,142,151,180,129,150,138,134,30,199,70,101,103,199,233,18,174,112,190,119,220,76,33,29,230,187,136,242,44,81,132,127,112,4,209,216,198,135,13,147,199,76,19,119,194,216,146,29,250,159,217,2,146,143,24,70,150,67,63,131,25,138,7,115,233,168,200,41,117,102,101,159,118,164,25,13,90,129,152,109,221,133,227,219,165,119,168,112,46,157,163,26,154,124,159,216,62,205,156,34,132,217,166,208,197,9,34,42,71,239,239,217,42,27,5,186,175,228,100,69,151,243,216,47,212,50,171,123,187,87,193,70,181,197,164,48,68,145,35,106,33,228,230,196,146,67,243,235,209,170,229,57,218,80,236,158,130,150,178,128,184,0,98,107,47,2,80,138,250,119,42,229,161,215,102,20,230,192,40,85,74,207,70,74,3,39,106,99,34,57,135,73,239,170,174,145,238,82,169,206,33,234,151,89,196,12,19,10,157,62,64,90,186,181,32,107,74,184,22,1,230,239,199,157,161,157,204,82,145,197,185,11,91,26,172,100,26,194,174,137,115,136,218,135,106,58,120,13,109,97,15,197,81,178,46,154,140,246,75,68,36,45,8,46,102,210,48,192,169,56,139,135,68,187,25,83,142,178,128,166,214,100,51,196,42,208,250,253,52,120,76,4,171,236,29,75,28,130,92,70,254,10,218,81,157,167,185,236,118,101,247,31,96,85,85,48,106,217,67,236,203,68,68,145,23,59,142,175,69,122,92,163,109,183,48,42,100,228,213,241,221,200,78,98,21,32,252,73,0,228,5,15,152,13,2,212,104,217,34,50,155,193,17,54,181,247,195,225,234,34,118,53,159,221,172,237,209,156,225,118,190,147,91,243,180,214,41,163,212,202,55,244,108,8,159,246,105,145,148,247,226,182,1,80,250,135,99,194,112,219,249,199,210,64,234,21,175,17,223,1,234,248,62,236,50,133,88,134,60,239,158,250,134,219,92,62,225,223,38,38,173,214,135,138,47,86,85,151,200,13,63,130,82,127,146,115,97,166,180,173,52,76,167,2,33,171,186,75,125,3,249,49,33,78,178,239,141,30,40,117,227,41,178,7,14,162,160,16,90,93,19,96,173,227,248,115,217,110,235,191,144,41,122,208,152,214,30,240,199,109,64,27,22,233,122,129,164,157,142,197,25,209,57,53,26,60,29,181,31,92,49,122,77,51,10,0,32,227,207,228,55,28,39,68,200,168,219,248,91,151,47,208,240,225,118,171,244,192,221,130,28,138,252,193,247,204,10,232,196,19,195,62,12,43,136,16,207,192,194,198,54,213,74,121,137,107,214,114,90,242,234,184,167,47,113,90,228,1,237,251,127,144,43,117,198,150,63,1,204,119,123,97,1,72,173,88,160,224,148,15,24,184,88,123,89,247,205,156,89,9,193,249,171,128,55,244,166,226,129,242,166,17,109,159,78,246,37,77,91,246,165,86,152,129,243,249,37,12,196,253,222,170,171,179,220,57,130,208,105,107,195,28,140,237,85,75,110,37,138,58,199,8,129,72,219,120,165,70,250,243,231,41,243,137,96,255,109,100,9,44,251,153,156,231,109,2,163,43,47,71,108,105,73,12,82,129,153,2,11,222,169,43,201,20,151,38,201,93,163,164,123,129,149,28,207,210,136,64,125,162,159,218,173,31,152,70,255,1,252,161,25,6,95,159,248,87,176,88,249,115,54,121,215,145,162,46,185,228,125,178,60,235,60,117,169,159,16,136,171,245,115,140,191,245,25,117,105,47,237,203,86,237,100,138,27,141,161,158,211,233,18,79,198,118,150,195,74,31,195,17,66,135,245,20,154,135,131,210,57,7,141,19,213,91,196,33,39,118,121,65,134,94,182,173,35,41,99,185,178,42,239,59,84,218,11,94,242,58,6,46,26,228,14,85,190,164,60,90,197,37,225,131,85,150,21,218,170,191,63,62,81,107,141,130,156,102,60,241,180,251,58,195,21,158,204,180,254,8,14,143,108,133,244,104,167,244,14,208,15,77,153,131,9,172,243,10,35,87,117,243,89,54,171,69,211,89,44,31,138,197,106,82,82,47,113,92,38,161,185,58,230,176,86,219,5,82,146,47,125,79,18,159,132,110,204,138,226,183,246,47,45,68,205,175,192,179,58,60,126,254,84,205,194,232,46,114,116,236,160,147,104,234,72,147,242,94,116,104,218,121,65,224,213,153,85,134,117,21,182,56,174,100,12,230,113,179,131,167,167,75,16,104,105,124,104,4,140,95,181,15,43,106,184,188,6,235,133,84,1,206,245,113,171,41,117,101,149,121,5,74,161,221,54,201,15,21,158,91,100,210,219,252,134,160,115,157,158,167,221,56,68,146,44,95,78,251,253,58,223,0,150,200,255,198,82,53,172,208,97,183,229,123,169,17,104,135,69,155,100,67,18,225,146,35,87,43,66,194,114,174,85,15,82,191,203,160,234,187,164,174,174,191,160,53,33,104,6,194,202,69,238,246,26,11,120,164,158,115,1,58,184,234,235,197,60,18,179,182,107,72,87,139,140,43,105,18,87,181,83,204,100,221,154,70,102,168,243,35,67,30,213,186,248,28,160,150,233,120,118,22,124,125,186,34,159,248,110,147,127,214,76,33,130,165,107,109,16,10,98,113,196,21,79,202,162,4,127,21,157,120,98,84,93,113,88,54,114,6,189,129,211,42,25,77,27,43,103,154,131,96,179,239,206,47,44,12,245,71,101,182,208,236,249,45,250,141,10,190,106,178,107,115,27,43,121,138,235,149,242,93,85,66,197,149,75,2,1,107,85,94,202,159,224,172,152,32,90,216,155,69,253,170,22,150,88,170,195,96,247,172,187,7,170,88,6,35,94,116,231,36,113,204,231,78,103,58,244,30,126,166,208,44,87,58,2,151,171,82,94,181,239,20,34,171,167,73,107,132,61,78,201,94,115,171,214,165,59,233,208,203,35,29,219,137,68,240,113,106,31,93,180,198,167,148,18,42,60,172,157,196,202,9,103,235,99,69,33,130,181,98,158,167,28,109,240,122,130,174,12,163,68,6,144,251,192,67,41,152,28,173,158,243,24,107,148,231,156,103,202,94,247,143,36,208,146,155,57,210,66,154,241,228,146,184,3,84,34,170,77,150,146,99,233,50,119,87,180,82,167,232,191,248,100,225,71,98,88,10,182,224,242,105,49,192,54,232,90,73,133,156,91,153,222,108,176,10,11,239,217,108,194,86,84,190,83,182,94,204,219,202,15,188,39,35,225,105,158,18,82,156,171,5,190,102,238,205,232,222,129,44,197,107,217,229,0,26,200,28,158,79,178,180,13,212,206,120,254,169,42,133,222,65,52,96,143,85,46,245,164,143,251,48,64,101,56,23,145,88,197,71,118,131,175,57,109,202,126,40,224,181,196,131,140,240,97,156,71,68,102,231,174,253,10,55,35,211,98,133,89,124,100,205,80,191,3,232,42,238,147,91,124,16,76,7,222,44,96,185,152,109,17,170,89,29,248,255,207,214,50,56,207,126,11,60,146,94,165,129,4,12,66,63,48,161,88,154,185,34,39,126,126,87,87,136,80,63,30,117,180,1,98,144,198,252,27,183,11,170,160,176,214,129,125,106,51,20,131,185,60,125,97,214,4,94,71,129,212,86,201,26,201,93,195,195,70,245,54,180,215,36,155,244,19,64,233,36,62,255,131,39,22,220,202,197,82,205,197,231,135,156,117,14,197,170,109,23,74,208,199,217,47,49,208,153,173,14,0,106,166,193,110,116,164,173,113,48,1,16,23,61,66,116,177,160,220,103,185,33,194,219,210,182,167,200,22,22,156,158,82,183,211,81,86,250,232,159,22,126,142,247,253,18,238,221,124,123,130,92,123,76,101,92,11,199,98,110,39,3,37,128,228,216,85,216,220,166,123,237,220,86,35,181,240,222,145,185,49,63,15,55,127,173,186,242,142,148,150,103,190,155,47,23,86,34,138,247,222,184,226,145,116,234,133,141,218,208,127,30,195,52,184,93,250,152,50,237,11,254,118,62,194,120,179,71,23,137,226,199,32,27,159,40,254,99,211,198,151,9,17,4,50,55,138,238,167,111,218,123,245,216,235,62,163,212,85,54,89,137,57,121,159,108,29,194,181,95,85,131,108,173,26,158,19,239,175,223,100,15,190,164,34,16,241,3,53,215,240,29,9,196,162,146,124,211,125,253,92,206,42,128,2,89,47,9,39,119,173,234,106,99,164,75,142,0,96,196,34,156,156,24,230,140,144,46,110,89,215,204,165,188,111,212,246,50,165,97,16,159,243,121,161,189,72,230,223,125,12,57,251,164,76,175,104,163,25,222,229,240,35,222,78,59,196,36,6,27,88,242,178,248,170,154,135,128,79,140,114,38,136,201,247,70,30,8,17,42,222,134,66,169,64,67,231,238,17,147,69,131,15,226,113,45,182,69,1,208,44,176,109,75,240,193,151,231,201,137,229,2,24,251,58,20,21,4,28,160,56,34,108,59,39,24,249,10,195,249,114,232,175,218,19,225,151,3,87,167,76,236,127,103,85,179,90,224,0,2,189,99,71,178,175,169,198,110,43,81,207,247,70,216,109,31,14,142,144,17,46,170,245,19,216,63,103,46,130,39,112,75,163,122,168,195,168,82,209,145,96,164,126,28,85,95,108,13,233,134,159,135,241,16,153,64,30,77,24,249,68,253,115,233,128,47,83,219,226,186,179,5,122,55,216,254,166,240,120,232,165,164,180,207,158,140,241,217,209,86,93,191,194,149,94,125,185,172,1,26,58,26,128,2,156,254,232,35,193,228,69,195,157,32,209,37,93,75,215,125,180,235,160,125,89,104,161,15,238,46,39,189,0,169,219,170,45,108,120,177,31,40,57,125,151,95,45,213,237,208,233,21,222,26,208,255,173,236,178,4,222,41,234,241,113,33,112,22,159,64,1,184,149,111,115,133,7,195,219,82,23,77,233,93,97,231,121,133,218,149,88,177,6,48,34,42,146,58,235,78,69,246,42,250,243,220,52,230,225,82,188,243,118,146,13,254,92,211,136,34,61,131,30,11,227,30,231,152,250,139,155,232,54,60,221,173,192,66,118,72,211,47,205,85,248,81,204,69,210,137,158,220,186,103,214,208,251,12,137,246,59,0,156,215,154,143,23,172,144,231,149,104,51,123,198,227,49,169,204,155,18,47,53,74,12,153,120,116,157,2,172,247,201,121,244,191,228,251,247,117,229,41,100,10,48,105,48,238,216,96,135,38,96,139,136,139,255,32,63,208,219,70,248,26,1,177,21,93,133,144,5,174,231,236,50,192,33,144,0,97,238,155,173,240,39,66,120,189,144,252,155,169,79,160,159,127,172,225,223,101],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % encryptionkey)
                            #                                                           [8,1,18,187,34,18,92,10,90,10,68,8,1,18,16,154,196,52,232,105,14,94,124,184,179,237,146,171,38,211,249,26,6,118,117,97,108,116,111,34,32,55,67,53,69,55,70,57,49,49,70,55,57,50,70,50,49,66,69,53,70,69,57,66,67,57,49,57,51,67,51,51,66,42,2,72,68,50,0,16,1,26,16
                            #                                                            ,12,244,83,229,42,123,152,110,136,175,54,221,155,10,194,166,24,1,32,195,138,220,215,5,48,21,66,208,33,10,20,108,105,99,101,110,115,101,46,119,105,100,101,118,105,110,101,46,99,111,109,18,16,23,5,185,23,204,18,4,134,139,6,51,58,47,119,42,140,26,144,31,208,25,232,127,32,219,15,118,204,63,89,167,145,246,205,19,130,120,156,96,9,6,217,19,35,76,240,221,1,202,171,245,66,146,22,246,50,42,113,58,196,146,229,25,225,219,93,210,135,81,204,219,104,229,184,182,185,137,116,167,110,11,245,182,3,140,26,202,65,32,220,112,177,217,100,76,246,198,98,72,128,49,234,172,51,100,26,227,177,112,114,228,138,21,177,170,147,29,5,54,166,16,66,86,20,190,101,80,22,11,180,11,37,137,233,252,95,217,79,92,188,90,125,146,252,159,100,212,22,164,160,29,158,105,227,250,28,19,166,126,58,138,101,238,146,55,216,64,117,46,28,94,62,219,1,31,26,115,232,30,3,121,146,151,25,199,219,94,249,220,135,173,247,193,223,229,129,82,241,243,168,64,209,9,223,40,236,80,232,32,232,122,122,111,232,206,129,85,155,56,25,140,134,69,122,232,159,237,122,137,215,213,252,40,84,107,64,144,38,188,10,189,149,187,54,230,92,151,76,129,163,167,211,84,162,197,223,13,165,205,175,73,198,31,134,220,83,97,92,39,82,203,240,148,35,135,44,178,76,112,32,203,226,154,59,135,115,36,127,106,85,186,164,99,152,121,159,163,212,236,253,100,146,182,214,135,59,195,102,129,100,72,207,121,151,202,220,84,162,167,64,130,175,198,37,142,251,211,251,40,228,18,136,111,17,154,108,194,215,0,1,128,86,3,245,37,128,171,187,231,214,56,183,24,70,123,133,237,20,180,51,162,136,14,81,77,169,41,232,44,211,141,107,116,222,8,16,174,12,111,132,6,219,166,226,142,72,234,62,26,11,58,191,93,141,60,53,136,106,96,58,145,252,44,192,90,217,200,131,24,20,194,204,61,162,210,94,183,90,37,236,204,167,147,248,254,176,99,121,62,192,149,251,163,188,161,146,32,47,159,118,165,139,27,239,227,146,71,192,231,99,233,210,115,68,246,198,168,46,133,67,87,100,188,83,237,76,71,185,208,91,197,242,225,218,210,140,35,227,132,96,176,167,73,238,147,96,186,218,72,151,205,44,206,170,244,70,16,250,250,58,163,141,234,236,190,200,2,170,73,247,100,62,192,235,138,174,194,217,249,58,40,128,17,30,141,47,167,11,214,38,22,60,89,1,128,36,201,59,36,127,126,52,48,69,223,184,213,132,41,114,125,242,29,81,61,250,207,97,11,112,46,38,114,154,52,70,100,23,29,212,6,244,58,63,27,174,37,56,163,251,63,245,106,95,15,198,76,163,197,140,157,1,106,154,68,80,237,180,74,23,173,231,77,79,3,219,109,63,17,116,156,215,64,7,145,207,120,226,13,220,101,103,11,1,255,3,97,234,188,69,144,236,119,94,57,200,101,228,19,56,253,139,32,193,217,73,169,79,249,138,24,185,97,43,160,163,143,99,119,117,198,245,75,101,94,113,169,15,184,224,184,172,205,111,150,228,247,116,85,224,178,215,109,239,39,240,62,51,89,17,74,120,74,124,54,104,218,117,155,206,190,240,106,166,103,24,172,255,65,12,119,89,76,223,251,67,178,200,227,151,126,185,234,80,137,40,49,122,143,255,144,158,230,30,182,76,16,29,203,134,94,227,122,102,195,48,225,168,105,49,101,118,236,129,27,245,143,204,68,180,167,20,87,193,36,103,21,242,100,25,98,31,71,89,51,186,103,188,230,150,112,70,170,191,110,140,50,34,168,249,90,101,2,10,88,46,105,236,163,28,59,233,162,78,32,110,59,169,191,251,169,93,139,58,89,127,22,254,225,171,219,48,59,145,131,221,139,152,157,51,67,111,71,42,228,62,5,151,170,168,141,132,197,106,72,217,107,237,104,161,14,68,38,154,151,65,133,207,105,103,11,49,244,118,79,2,153,67,186,25,36,225,240,213,233,35,76,59,10,196,167,71,147,224,39,187,232,163,15,199,13,72,17,254,160,115,178,25,24,129,82,235,33,123,208,125,88,196,164,24,246,249,65,19,88,201,86,71,196,65,136,74,200,102,61,149,241,242,57,86,253,16,121,8,203,105,195,23,52,176,133,254,158,16,94,241,195,219,4,227,175,1,113,237,202,163,146,196,209,131,83,124,96,29,91,234,30,7,33,7,2,184,144,18,221,231,85,196,136,179,47,123,140,101,178,94,143,196,195,39,31,74,132,130,204,243,162,87,202,120,236,219,234,37,200,63,151,32,130,140,83,192,151,129,204,137,153,111,119,217,128,66,70,98,42,44,186,69,95,206,43,124,155,116,53,227,205,157,126,43,219,164,54,4,42,239,111,38,83,230,91,89,55,187,175,123,109,128,169,46,83,140,248,128,246,234,142,158,99,252,33,220,176,135,216,165,206,60,215,244,64,205,137,231,9,240,218,252,33,88,26,64,104,112,95,68,8,32,22,53,85,200,69,110,27,102,1,151,101,67,207,166,221,84,145,229,158,198,74,49,241,140,55,206,77,29,80,12,36,248,158,151,197,92,141,219,79,200,168,100,248,168,245,231,187,137,56,217,78,126,50,181,71,158,183,98,237,140,121,36,89,13,16,226,180,139,181,54,142,143,149,249,23,57,82,70,25,67,50,69,152,174,109,51,191,214,17,64,118,98,203,12,92,125,175,208,232,21,130,20,27,29,165,57,234,110,190,52,13,108,215,248,46,2,173,22,0,250,108,240,217,204,12,47,245,159,15,119,194,208,142,117,78,157,139,89,28,73,109,112,147,154,216,118,229,214,159,199,7,5,12,191,253,49,67,67,202,114,119,223,103,166,107,21,83,58,204,97,73,250,95,143,248,254,153,41,190,38,244,47,95,241,216,177,1,34,61,127,167,38,200,55,249,197,8,158,143,150,167,85,90,110,227,116,141,153,218,214,175,126,225,74,81,33,39,159,235,46,72,182,138,230,105,179,21,146,174,17,205,115,227,204,241,182,105,12,192,66,185,112,85,252,30,249,229,242,86,146,167,22,152,34,213,96,33,100,104,30,158,95,240,233,208,34,112,128,187,81,252,125,87,7,98,239,80,244,200,68,18,150,13,39,192,180,186,141,93,223,203,90,120,9,189,253,99,210,179,248,5,123,17,54,165,6,36,211,190,203,54,184,125,18,97,211,44,165,84,244,171,196,130,216,21,216,24,56,97,138,184,169,227,99,167,103,114,174,171,199,5,103,16,192,157,28,126,183,224,35,6,246,22,58,88,69,70,105,29,23,210,213,80,131,77,10,87,248,120,224,191,96,183,246,234,204,166,135,224,122,129,254,15,183,157,164,165,82,59,79,68,39,105,226,69,38,99,214,128,126,41,68,91,136,172,9,85,146,67,60,44,144,226,95,65,192,61,163,102,60,188,133,245,228,152,164,34,153,160,86,49,56,177,98,221,114,150,194,93,241,121,184,44,171,128,64,152,147,212,215,87,249,34,238,175,117,48,178,145,222,255,48,173,18,29,88,224,173,33,120,193,169,172,224,125,138,98,115,214,236,82,148,233,84,87,203,212,251,195,103,146,124,132,50,220,196,194,12,229,23,132,223,247,95,15,167,217,17,192,51,139,223,193,93,150,78,111,104,234,144,98,226,12,252,31,39,24,69,248,10,182,17,131,62,53,70,36,82,89,147,221,81,143,91,47,194,35,188,49,75,222,253,57,213,192,144,31,251,47,76,79,226,180,90,232,246,5,213,41,224,143,101,43,152,113,189,147,207,202,50,42,237,126,71,121,205,126,206,159,160,83,102,115,250,65,183,58,81,184,241,252,34,246,204,184,37,17,51,26,144,139,202,42,24,123,46,141,132,133,194,88,133,2,117,106,109,10,42,101,182,251,162,189,35,156,242,146,13,169,172,53,226,234,9,109,164,30,174,181,154,214,228,1,100,137,87,206,182,141,128,228,157,43,222,214,153,92,54,2,137,179,245,189,24,103,60,243,94,174,40,156,170,119,156,190,236,254,116,239,173,0,76,43,57,17,159,46,56,115,170,176,94,43,162,251,114,91,72,230,191,53,218,229,251,137,138,137,8,14,118,180,160,54,110,112,130,126,217,68,30,56,82,81,233,6,99,103,227,106,161,181,61,54,130,17,234,201,1,240,217,69,158,163,208,133,37,35,169,251,31,136,44,226,74,216,194,206,251,234,61,176,97,233,48,130,81,77,115,62,189,52,108,252,84,232,180,89,36,200,183,223,188,174,38,68,189,49,5,223,193,136,240,29,71,176,63,70,23,27,97,15,240,15,161,39,224,165,171,57,36,125,160,28,217,36,63,125,16,3,228,13,61,211,94,56,225,70,162,79,17,220,168,79,134,156,243,31,236,87,75,51,202,201,98,80,237,7,40,247,121,15,255,117,158,135,49,11,63,130,29,238,169,73,225,181,114,241,37,37,108,187,129,140,23,199,65,195,180,80,168,62,0,130,47,245,7,42,212,64,12,188,149,137,1,54,72,27,202,198,242,207,234,120,151,230,9,243,250,112,239,223,159,191,248,215,142,10,88,6,73,229,58,60,42,239,18,221,146,92,13,130,198,17,7,58,215,141,45,31,95,147,77,122,184,154,68,147,237,133,85,239,97,60,71,174,170,170,217,230,179,156,216,97,110,126,192,65,44,74,137,195,110,74,255,153,227,50,243,13,51,206,19,200,72,7,66,215,102,150,159,209,152,170,197,235,211,226,132,11,52,87,162,71,169,37,247,126,79,237,126,156,158,106,216,148,115,5,80,237,72,5,188,189,86,139,104,107,248,33,12,210,226,103,168,106,112,29,133,254,70,146,200,202,105,221,54,221,250,188,244,236,18,116,152,95,150,178,230,147,227,58,184,48,115,217,210,72,254,55,97,190,60,190,56,228,72,3,105,243,57,118,185,236,47,67,47,240,172,176,120,193,165,176,142,96,140,101,59,97,247,245,222,38,253,121,119,187,141,158,158,191,101,69,113,92,177,112,178,215,11,91,180,58,190,26,73,179,69,212,228,94,54,83,17,100,163,170,187,30,42,163,251,119,97,170,37,252,28,212,217,220,38,112,198,166,223,44,53,132,32,135,228,40,36,7,47,82,252,3,250,108,164,231,69,158,219,17,128,253,30,75,14,2,159,13,46,109,235,117,23,23,46,80,2,28,208,249,128,33,118,26,8,148,164,195,234,94,25,254,236,35,189,96,172,59,52,47,100,115,239,135,45,214,24,242,86,180,18,82,249,53,77,83,3,64,60,102,232,133,243,180,123,192,37,46,182,190,121,97,237,154,222,77,90,255,181,85,85,178,25,8,249,245,244,143,142,20,14,207,25,150,197,202,237,71,239,92,79,189,9,126,93,92,222,222,27,60,233,219,149,221,60,247,233,18,203,95,103,23,88,50,187,157,135,215,147,169,203,3,95,153,255,29,144,146,200,219,88,61,245,186,31,103,124,95,219,37,96,193,130,159,18,210,207,203,226,72,92,137,206,80,211,144,189,18,166,195,101,119,93,61,162,53,163,113,171,88,104,15,146,92,116,197,167,113,18,84,55,20,31,185,183,198,145,236,98,40,49,86,117,237,90,82,233,165,116,122,196,201,160,45,179,200,244,68,176,128,253,209,68,99,76,6,163,170,85,55,23,78,53,101,247,128,116,20,220,134,254,32,87,191,213,154,193,246,196,49,243,147,3,78,244,87,72,161,8,107,37,198,125,254,189,25,45,165,179,11,136,73,216,252,193,244,86,103,234,90,227,24,6,80,208,166,189,123,68,168,105,229,38,123,210,240,174,106,206,188,103,89,163,238,128,227,168,7,137,2,47,27,78,160,107,42,54,241,115,189,113,245,59,210,114,224,54,251,70,36,152,94,207,30,215,206,172,129,109,137,183,138,137,143,145,78,32,39,214,41,252,144,2,207,215,36,239,102,128,125,234,130,147,150,197,23,220,172,153,55,255,182,213,3,57,191,229,14,126,166,58,201,221,90,191,33,2,37,139,24,244,191,82,229,60,123,75,31,106,212,95,161,54,183,155,18,239,125,193,113,239,143,67,253,172,200,77,250,94,219,207,91,147,194,48,196,225,20,127,180,161,146,78,216,73,117,252,17,207,197,201,218,155,9,101,69,131,253,46,53,8,101,75,242,229,194,9,113,33,218,166,139,53,230,106,158,104,166,72,14,70,174,33,56,99,61,218,188,29,125,192,127,72,20,9,110,16,131,82,196,73,184,148,190,124,144,186,17,34,25,181,67,15,78,76,96,204,145,129,121,46,234,178,180,214,48,99,241,240,170,199,182,94,146,7,4,131,96,250,113,175,135,233,110,106,102,130,74,49,240,73,122,76,87,57,25,204,96,32,39,101,94,25,138,12,124,4,203,214,84,19,238,251,202,82,34,30,108,46,176,245,103,221,45,138,29,176,95,247,114,145,45,16,82,30,238,114,229,131,40,117,182,52,69,37,114,251,28,43,11,27,166,6,99,129,129,100,126,227,167,71,152,77,210,252,31,51,85,134,170,23,54,40,234,52,223,122,194,41,222,7,121,249,170,113,47,227,227,46,69,216,203,52,121,153,239,239,92,175,243,112,247,164,166,89,5,151,111,58,92,251,100,67,121,86,30,229,222,166,133,252,11,6,80,6,173,196,46,187,211,249,35,166,214,128,229,252,107,120,248,110,49,128,107,94,254,151,127,254,57,51,82,2,139,130,186,121,54,189,124,134,177,92,133,197,88,192,6,108,120,74,253,69,202,171,69,213,36,101,34,45,186,17,33,13,56,210,94,12,86,126,214,13,147,7,110,23,38,19,247,237,114,101,162,54,59,195,115,41,53,219,48,108,177,117,59,61,182,202,48,140,61,218,239,18,183,82,40,17,55,22,155,251,190,104,130,121,17,190,76,187,144,249,130,164,169,5,92,86,222,78,57,43,68,24,8,146,231,120,137,144,106,49,185,97,29,197,239,102,238,80,81,11,129,35,191,242,90,253,198,105,148,30,168,41,78,226,99,226,43,108,205,170,210,16,172,76,142,233,15,146,86,14,63,88,203,10,197,65,87,224,98,113,142,10,75,188,179,187,70,218,232,144,158,157,246,94,222,114,133,116,110,30,237,43,204,64,97,44,42,93,230,26,98,114,160,179,224,145,57,204,71,165,76,23,84,81,20,206,251,55,160,103,183,146,184,162,34,162,132,238,203,242,33,222,107,121,63,196,143,163,16,175,69,207,202,165,121,226,25,183,66,27,61,133,61,88,117,144,195,42,54,96,133,51,224,68,115,77,7,200,10,181,231,153,191,154,45,16,110,134,89,62,86,128,72,88,237,149,72,20,6,114,15,200,108,212,123,109,161,117,27,16,14,48,10,110,22,210,62,76,232,133,32,178,60,11,146,227,194,167,122,82,236,40,121,220,1,49,178,159,137,150,237,201,133,132,26,31,103,40,69,247,111,209,57,197,86,194,33,4,193,229,204,155,114,152,15,170,23,214,56,5,60,48,109,180,52,51,212,61,186,251,38,187,54,204,158,80,154,96,74,216,14,144,188,68,54,196,83,94,74,59,174,101,38,247,67,100,180,99,150,199,136,68,242,78,151,221,83,215,25,220,253,118,204,148,34,39,224,204,106,108,106,146,87,69,189,25,143,190,49,62,24,46,39,91,113,76,40,100,246,20,241,47,27,48,138,50,242,243,8,12,156,76,114,5,64,29,238,21,243,213,214,43,66,233,63,129,64,139,91,7,143,246,231,140,39,223,209,163,235,192,71,230,49,5,127,160,84,106,247,122,1,55,55,222,84,158,171,241,58,63,74,188,45,241,108,196,79,171,229,112,132,126,153,132,145,149,156,216,29,222,84,152,246,29,112,102,109,134,223,200,126,80,213,240,206,49,218,151,210,122,22,16,2,58,135,0,118,63,106,143,204,29,152,129,78,170,251,173,180,235,122,191,37,105,223,7,67,61,57,20,95,11,235,200,5,17,202,133,150,246,86,94,7,65,7,57,22,161,171,231,29,208,125,2,20,55,11,205,200,147,76,37,214,67,193,80,25,160,7,99,200,172,114,111,94,15,208,118,228,26,254,0,206,78,6,151,121,183,92,97,1,252,41,224,143,113,205,255,39,126,122,146,12,6,251,102,9,158,115,22,172,4,107,155,113,102,147,219,195,105,130,183,166,50,25,176,109,31,116,52,166,190,30,43,129,198,75,178,10,203,206,207,77,202,135,246,145,42,219,44,92,161,180,158,88,61,176,155,66,40,12,178,36,90,250,223,52,158,100,97,30,165,104,94,202,167,139,48,51,198,149,185,18,15,225,200,174,61,6,191,130,89,160,206,162,48,153,232,15,49,37,55,60,30,3,121,240,230,42,147,225,88,187,142,4,209,88,78,179,105,201,145,6,79,9,193,181,197,147,211,209,240,131,16,190,8,48,118,74,231,179,75,208,244,24,237,137,231,78,186,99,49,15,31,35,15,67,76,72,155,164,68,105,92,105,159,81,64,127,170,247,11,112,200,108,225,245,110,187,255,15,158,44,204,211,7,59,125,29,243,211,71,201,104,187,16,60,32,103,249,55,50,87,67,40,39,222,3,229,225,104,195,35,31,117,253,69,211,206,19,51,243,57,137,216,0,214,191,65,143,35,214,75,123,139,129,82,93,138,207,63,106,189,137,42,228,246,113,66,211,121,226,141,198,71,107,89,149,145,42,228,170,23,141,6,70,211,130,23,243,182,21,168,134,171,106,138,140,90,142,215,20,167,88,128,29,68,237,73,9,96,78,51,138,113,70,109,124,0,184,92,5,15,101,208,224,251,174,168,200,192,220,3,189,76,179,20,167,186,200,125,72,15,200,60,130,202,58,150,195,192,123,10,47,156,62,189,180,0,251,20,236,53,160,144,184,124,196,205,63,213,101,75,173,31,177,57,211,4,107,162,185,109,73,119,180,54,131,156,51,192,136,111,63,212,136,254,242,64,183,124,143,228,71,63,34,16,203,26,74,68,177,52,253,38,251,23,91,243,1,24,70,17,42,128,2,10,53,7,255,201,67,79,54,142,108,29,238,32,78,26,146,118,188,175,226,30,146,25,54,79,223,168,102,244,136,60,1,69,139,244,31,240,43,124,179,142,134,166,168,45,95,56,18,93,154,196,122,28,193,48,5,68,216,79,89,241,40,74,175,62,27,115,60,239,162,184,106,135,217,32,102,87,117,208,215,46,10,97,247,213,170,150,15,171,32,150,113,4,232,202,24,21,228,211,20,215,65,209,110,134,251,200,225,84,104,89,25,121,250,153,39,74,149,133,133,82,60,36,47,33,101,169,184,112,178,131,201,243,146,194,138,50,212,2,16,11,226,240,146,104,59,50,211,38,71,77,227,155,101,115,170,82,200,108,81,163,32,4,140,20,20,19,29,19,239,255,184,206,8,240,130,53,152,8,215,67,153,150,12,53,171,136,46,248,98,161,235,36,84,196,90,102,170,58,11,27,112,109,66,0,117,170,168,178,243,26,169,83,181,206,99,61,57,145,191,12,152,189,23,147,60,211,173,206,49,235,153,244,158,59,22,135,180,131,248,251,127,109,74,87,129,162,74,153,74,82,152,188,26,193,252,26,128,2,57,115,168,167,7,122,93,153,158,211,230,223,51,118,103,86,19,104,82,216,78,189,184,130,93,25,8,193,242,235,167,85,204,216,247,134,122,206,100,200,80,28,88,24,68,200,60,152,185,223,89,114,170,26,119,51,65,198,193,151,148,52,151,110,4,213,156,173,93,14,216,171,68,73,120,138,61,72,224,236,235,70,164,220,77,184,109,30,201,220,238,233,146,119,212,175,203,243,124,33,18,100,65,179,171,233,50,101,247,250,25,78,237,4,209,179,40,206,16,52,202,77,205,217,175,178,57,14,69,253,74,207,139,139,67,46,186,52,144,31,170,6,116,237,39,184,58,226,175,231,78,66,150,131,195,195,30,107,246,92,254,161,137,87,122,0,125,210,153,214,252,233,59,126,133,101,20,154,3,240,32,160,131,175,229,229,151,231,253,68,146,197,228,112,18,118,169,173,163,164,104,60,128,182,207,100,194,162,40,115,16,202,129,1,125,27,109,44,155,37,208,233,138,145,215,238,0,52,241,233,199,201,32,248,67,119,213,223,168,197,184,190,178,37,170,150,112,66,41,91,87,159,119,35,65,198]
                                                                           #"drm_info":[8,1,18,187,34,18,92,10,90,10,68,8,1,18,16,154,196,52,232,105,14,94,124,184,179,237,146,171,38,211,249,26,6,118,117,97,108,116,111,34,32,55,67,53,69,55,70,57,49,49,70,55,57,50,70,50,49,66,69,53,70,69,57,66,67,57,49,57,51,67,51,51,66,42,2,72,68,50,0,16,1,26,16
                            #                                                           ,2,134,220,37,54,220,224,15,23,192,64,44,95,81,247,248,24,1,32,207,164,220,215,5,48,21,66,208,33,10,20,108,105,99,101,110,115,101,46,119,105,100,101,118,105,110,101,46,99,111,109,18,16,23,5,185,23,204,18,4,134,139,6,51,58,47,119,42,140,26,144,31,116,243,63,37,158,240,181,213,255,201,1,49,108,150,214,78,207,248,222,138,227,8,19,11,28,34,68,17,225,108,174,55,205,195,29,173,247,126,226,163,117,87,152,113,61,25,183,195,137,174,73,81,253,37,106,162,129,246,163,132,74,2,118,15,114,233,210,223,148,90,89,249,5,75,226,16,55,160,60,141,98,231,149,76,136,36,64,14,61,236,23,162,196,254,17,188,144,53,160,229,164,95,97,113,208,178,203,41,200,217,254,30,75,238,222,78,59,32,216,114,180,187,29,59,249,234,69,88,221,164,201,186,87,209,173,194,8,78,247,204,233,68,120,31,78,48,73,122,183,199,252,212,222,131,129,36,44,167,96,209,130,61,76,119,94,22,18,197,134,172,126,233,19,177,187,187,89,170,163,105,49,93,28,80,50,218,227,235,181,221,43,204,182,44,196,127,69,72,161,220,167,136,229,158,143,37,144,32,17,169,228,73,197,11,175,250,233,44,217,130,137,197,178,252,224,103,39,105,224,123,13,116,159,166,133,137,17,170,199,196,76,159,247,44,4,168,19,189,190,187,195,27,9,3,243,220,80,206,197,42,207,98,203,202,60,161,48,127,247,219,141,59,201,145,174,133,122,206,81,251,236,116,243,46,117,11,175,219,194,119,190,148,152,9,31,83,155,125,32,132,4,55,51,12,5,231,33,225,92,55,128,89,144,189,32,187,105,90,140,176,17,124,75,77,167,145,21,87,161,92,35,78,188,113,129,141,5,196,233,7,193,80,3,47,32,220,194,134,215,151,196,172,214,64,75,241,151,68,199,145,89,212,106,0,124,62,104,89,210,185,255,227,28,212,184,29,108,170,4,241,139,184,240,226,128,69,253,89,142,33,170,75,211,47,161,27,101,213,206,82,161,145,26,12,159,249,105,147,32,67,130,190,249,177,63,126,27,255,213,237,238,74,210,167,32,19,185,109,59,133,176,192,218,92,245,145,70,109,30,174,123,88,213,226,172,4,163,80,209,14,225,255,74,175,236,8,148,85,122,37,80,135,160,180,177,102,63,35,71,186,217,225,21,103,141,222,131,39,214,108,153,73,216,161,198,97,23,62,163,75,98,65,22,111,27,233,9,20,162,123,14,13,57,146,166,9,208,118,174,146,222,220,83,90,127,213,251,185,104,110,237,202,31,16,214,157,161,255,35,245,103,82,186,142,80,122,87,107,180,151,103,248,178,253,23,171,0,9,161,76,48,58,120,219,24,45,175,39,160,252,42,139,46,41,95,2,229,154,23,68,230,35,106,195,230,207,244,242,31,244,117,157,5,173,109,122,8,236,5,112,71,190,138,169,213,85,184,247,240,149,143,63,74,233,62,81,182,237,200,24,177,17,156,231,244,34,157,128,0,41,246,217,113,90,17,104,41,88,205,43,122,5,236,68,243,127,0,123,191,200,114,130,164,124,139,238,17,120,33,36,2,215,251,228,252,28,49,189,237,223,23,148,234,233,30,116,59,153,150,162,124,63,35,107,223,2,2,70,137,255,183,176,134,63,240,37,12,254,86,123,166,240,10,248,235,240,228,48,71,126,69,250,24,87,206,227,27,191,236,56,59,26,104,15,108,32,39,127,73,254,62,134,200,79,80,240,89,74,209,8,207,25,165,234,183,108,86,99,233,126,48,33,220,198,149,227,0,116,187,99,81,244,123,218,137,105,101,116,1,143,121,183,189,137,21,145,110,190,189,148,188,216,178,109,10,185,89,184,16,189,237,250,46,161,10,108,88,15,170,38,213,226,192,13,55,213,108,33,52,98,82,238,168,221,144,231,93,204,219,166,234,24,175,45,235,187,47,218,151,102,81,124,206,113,94,93,56,189,217,109,122,76,201,240,194,154,236,207,236,56,54,35,121,17,117,45,200,224,164,213,83,237,7,71,89,173,247,218,210,65,207,101,232,241,142,162,75,185,99,221,182,246,19,168,182,241,248,109,89,145,126,22,245,106,243,80,38,252,12,66,232,238,93,125,11,71,206,174,183,215,59,105,102,34,201,46,47,40,231,229,156,122,79,70,4,122,122,76,18,33,114,64,120,174,81,156,35,121,203,118,21,69,12,78,63,173,251,103,222,106,208,24,82,189,241,3,95,1,229,119,27,40,158,127,144,145,149,10,216,39,194,32,37,234,253,19,224,174,198,51,72,119,230,56,255,115,85,85,195,219,143,239,177,93,212,36,17,144,242,199,172,201,155,101,107,1,140,201,195,223,169,236,182,183,138,38,67,235,100,174,96,181,23,81,195,114,34,70,95,145,30,102,247,28,89,241,254,253,90,185,172,83,50,108,47,133,138,213,194,236,241,51,4,23,119,228,118,42,150,102,88,239,112,250,189,78,82,35,216,185,76,217,84,2,89,130,28,156,3,243,73,68,236,56,234,224,85,105,47,204,179,121,136,130,90,14,10,103,213,142,155,155,119,13,17,35,83,237,213,116,64,101,164,25,176,241,27,10,75,169,119,3,131,247,47,6,81,171,129,147,73,224,219,20,4,172,6,35,1,151,102,31,204,252,44,168,178,115,209,34,132,36,173,35,129,109,245,93,154,14,150,193,124,222,83,140,158,3,85,239,100,80,87,200,19,170,240,168,235,62,185,246,54,222,115,113,18,91,2,147,37,47,177,236,203,169,41,71,174,225,234,109,173,165,158,183,92,161,10,107,186,218,193,221,3,249,48,249,13,61,164,172,166,132,147,82,83,110,216,240,39,4,244,73,182,131,215,186,1,24,188,129,181,253,220,175,70,96,155,170,126,81,57,161,231,116,184,174,228,93,58,122,72,201,174,41,164,202,3,125,20,91,206,42,136,5,104,61,1,130,177,122,96,144,35,169,255,163,127,66,89,37,249,76,171,57,131,218,50,160,135,207,115,95,75,102,235,226,142,15,82,242,19,120,37,143,21,212,79,164,140,245,17,206,137,193,197,120,49,235,118,255,211,250,33,123,110,205,212,228,172,255,62,167,226,106,253,146,75,231,109,255,235,105,197,35,251,108,106,116,252,241,170,228,182,60,251,86,71,178,163,242,80,201,73,234,159,81,187,241,188,159,0,165,241,159,20,205,127,246,246,185,23,218,151,106,201,58,114,236,200,168,255,238,92,46,49,37,9,17,132,81,240,42,110,126,69,1,128,116,21,73,170,226,204,197,125,105,131,213,201,149,246,63,252,239,208,244,251,63,223,12,100,214,177,0,139,109,207,84,127,143,156,234,35,238,65,100,139,203,86,140,194,96,156,132,251,212,203,139,166,27,52,188,133,129,250,246,72,240,93,76,1,112,63,137,75,247,186,202,208,153,113,85,54,19,234,48,190,45,22,196,84,69,56,172,135,208,160,242,12,30,97,115,35,214,246,139,237,187,255,108,203,153,170,56,3,214,58,108,241,64,19,26,25,53,161,84,38,97,98,35,219,145,64,59,35,240,230,216,55,30,218,21,76,150,28,186,213,68,221,37,157,203,172,211,47,231,169,202,8,121,255,102,194,253,150,100,66,44,104,129,39,155,207,117,155,213,154,211,62,157,107,204,24,148,74,83,62,15,74,176,218,178,61,45,181,158,47,195,31,148,87,9,30,120,74,245,219,87,139,27,216,173,85,159,206,128,251,103,33,232,79,189,38,185,185,201,214,91,227,203,239,115,7,182,76,85,187,106,255,161,211,176,92,205,110,5,31,151,31,170,133,79,72,22,24,29,246,156,147,246,17,78,11,80,170,138,21,139,186,175,131,191,59,102,167,27,104,142,7,226,167,231,72,180,20,117,208,225,175,205,130,235,136,130,95,135,140,101,32,153,237,24,36,226,189,166,26,202,212,219,250,175,44,225,157,246,234,165,114,163,89,55,166,53,91,105,9,153,3,62,47,89,158,233,51,255,212,251,5,15,88,194,54,221,106,95,10,212,174,43,63,186,231,55,150,34,176,171,67,47,4,126,245,58,0,100,33,21,4,158,196,85,22,139,160,99,249,20,186,3,33,9,247,255,26,54,244,38,11,92,237,231,49,175,207,173,123,13,22,158,68,202,139,65,13,118,63,47,194,14,167,173,12,28,173,244,44,128,190,154,220,191,121,148,74,88,121,5,133,208,46,101,229,227,65,18,133,243,110,138,10,229,162,187,57,55,153,18,227,203,61,213,117,59,222,191,150,128,122,130,142,85,225,242,42,231,92,39,57,19,221,241,125,106,141,13,43,219,95,15,116,33,122,109,27,131,95,186,220,116,46,66,246,23,177,202,105,58,70,12,132,61,102,227,177,182,53,178,137,200,155,32,220,25,232,62,103,3,44,1,168,1,203,87,216,95,140,211,149,48,122,202,137,208,76,95,155,251,138,248,67,45,212,235,153,79,77,254,214,161,11,168,32,231,79,245,217,164,56,247,203,182,205,250,11,36,171,111,110,98,132,162,215,190,196,68,188,90,54,77,123,254,77,156,52,48,55,100,160,76,33,89,63,37,120,207,122,63,117,99,47,220,233,70,24,182,191,47,39,121,38,203,15,229,173,236,32,232,131,17,160,180,4,162,179,221,6,52,253,24,61,103,164,118,48,229,53,95,19,107,188,214,78,247,139,198,167,156,179,106,0,121,190,35,236,176,92,170,78,230,48,117,242,97,225,44,120,175,173,5,75,21,106,119,7,212,197,114,250,116,209,197,183,111,71,42,30,183,244,202,35,81,114,195,117,213,66,201,85,75,136,67,111,180,32,248,125,18,145,72,196,33,236,184,126,36,47,202,241,246,136,122,235,74,233,36,188,211,174,14,28,60,6,127,20,93,167,119,72,47,171,101,246,175,192,151,34,7,210,163,164,74,246,2,235,194,102,73,249,89,222,106,173,154,214,171,43,96,86,125,167,223,244,109,133,254,17,159,29,109,212,168,123,164,185,5,126,140,148,130,132,205,191,122,100,251,23,179,5,188,72,98,69,90,67,132,104,176,34,44,79,40,15,110,24,155,37,195,182,158,67,225,10,99,0,167,65,187,90,83,126,81,50,20,228,26,131,176,33,112,7,86,246,227,99,16,67,18,39,180,109,231,82,23,11,176,179,71,214,207,138,186,74,165,194,218,158,108,70,168,114,37,68,237,130,210,207,209,235,218,216,56,112,172,144,229,249,0,201,16,69,191,214,235,51,14,192,63,81,194,195,189,86,242,76,134,161,142,66,102,219,115,207,235,97,59,173,32,6,185,196,221,235,127,244,73,180,184,112,75,223,233,154,54,45,53,40,128,253,51,106,143,114,41,18,90,114,81,132,49,122,238,114,154,204,150,173,255,80,60,58,3,250,165,172,98,11,45,150,98,218,132,35,198,201,58,80,110,175,213,146,239,104,240,27,115,82,173,108,120,126,193,221,218,235,27,241,85,187,229,248,189,152,89,187,248,140,231,252,72,179,0,254,153,166,184,114,250,172,229,9,115,15,205,63,168,23,231,138,124,33,64,4,35,14,68,116,223,254,41,0,108,124,78,181,186,40,168,101,201,166,194,19,172,32,101,189,46,168,70,23,14,232,6,219,238,178,91,174,29,252,137,80,71,174,97,226,141,83,100,213,156,64,84,230,124,187,189,239,6,105,170,212,19,30,65,62,169,147,218,36,189,215,54,153,252,169,235,136,110,186,242,113,212,84,20,61,55,217,14,136,139,122,199,36,138,185,27,182,40,41,51,16,141,136,214,225,50,15,235,106,196,138,56,155,0,62,56,106,23,98,75,230,99,255,2,20,28,44,70,26,234,141,152,82,234,173,250,160,201,31,49,147,0,206,247,6,87,46,154,2,208,175,133,56,70,125,11,146,1,145,223,178,236,75,96,59,25,85,79,48,150,86,7,75,140,172,98,64,158,168,156,146,126,144,116,204,126,195,157,83,5,168,12,74,245,202,252,194,129,123,3,200,83,115,235,25,208,151,154,215,177,12,120,151,138,96,34,109,48,32,253,176,215,130,48,55,133,247,216,49,96,133,79,4,54,253,150,135,144,38,115,165,72,109,115,45,212,236,120,221,39,95,58,60,14,201,62,50,104,193,160,14,47,142,9,111,98,153,9,61,170,145,181,192,122,196,1,141,252,23,1,204,10,111,51,250,14,91,214,197,6,252,141,69,163,251,80,208,223,167,236,5,62,52,112,41,231,133,55,65,192,11,153,208,208,20,198,186,86,230,250,185,75,78,110,7,6,11,254,96,236,247,37,156,26,139,132,183,142,123,190,78,182,168,40,222,241,214,61,204,172,109,238,173,154,28,51,64,206,170,233,9,254,125,219,63,109,116,40,22,207,254,95,95,96,147,41,25,127,101,35,17,34,138,47,29,236,24,201,111,176,35,123,62,93,77,205,163,8,173,197,12,241,16,34,249,83,55,146,245,242,196,38,78,72,52,32,150,60,41,21,169,198,145,73,51,168,184,247,234,29,12,70,252,171,124,43,169,91,32,165,110,230,89,250,8,209,239,107,248,74,53,193,56,251,228,109,117,210,132,47,246,56,215,112,103,87,139,119,54,116,112,121,68,217,116,21,228,195,52,223,16,96,46,139,168,40,107,8,139,162,126,192,46,64,227,52,34,44,189,6,130,213,217,33,96,206,135,109,151,191,62,102,24,132,117,22,208,239,234,225,11,203,27,78,240,125,40,4,180,88,204,57,60,242,38,138,28,191,20,30,40,152,67,68,208,167,206,239,207,109,86,53,162,78,159,160,169,206,126,238,239,133,44,236,58,226,47,125,170,112,116,79,43,98,198,170,116,14,128,135,100,127,79,105,98,141,18,10,206,60,242,118,150,189,244,78,188,123,3,214,161,158,138,161,206,32,165,151,80,76,142,112,184,221,81,251,112,100,144,77,106,67,34,213,24,200,191,60,150,121,3,106,31,238,199,213,210,206,1,179,115,168,213,202,46,99,155,68,171,189,233,127,100,255,181,124,64,242,63,27,174,195,136,196,39,91,213,139,179,244,37,254,5,3,219,44,198,193,132,207,250,231,176,92,11,161,100,61,246,66,28,204,135,179,180,77,34,171,7,24,136,72,156,66,253,17,195,140,144,162,99,198,80,224,68,19,10,17,195,128,92,240,103,70,125,221,186,67,234,41,99,2,2,2,162,71,216,70,144,187,159,235,162,170,227,4,59,77,249,139,43,159,110,213,187,144,135,246,175,222,87,126,174,110,26,11,132,166,77,250,123,113,238,27,42,54,144,86,61,87,235,175,217,5,196,236,157,197,22,118,107,3,115,236,187,163,32,24,120,25,233,189,205,93,96,100,111,118,192,85,22,109,133,7,46,58,255,231,182,244,121,62,124,78,158,57,2,61,200,73,153,113,55,10,196,73,171,236,41,252,220,51,154,11,185,246,51,220,94,221,164,155,46,8,206,104,178,93,85,74,34,238,204,155,151,214,136,24,151,253,165,111,148,87,170,121,23,59,76,229,112,93,159,101,186,194,184,181,3,108,158,214,66,164,114,50,212,135,74,239,253,38,240,243,127,89,68,205,3,238,121,195,2,131,14,201,143,159,159,212,106,90,196,233,129,123,35,84,153,145,20,175,24,11,175,121,40,253,141,199,232,239,235,247,146,131,151,252,192,151,137,125,158,50,214,93,164,23,133,184,114,197,228,25,202,177,208,40,92,7,12,201,11,64,76,69,23,28,27,79,177,35,104,80,24,33,123,170,160,159,25,194,28,134,179,123,185,227,195,216,161,93,216,180,45,203,223,46,174,152,175,155,208,81,71,157,178,32,216,181,8,117,66,248,244,104,20,12,14,161,218,253,140,121,10,7,115,48,170,62,137,223,155,83,127,197,251,247,26,232,52,42,66,245,196,59,28,81,153,152,60,92,239,46,219,31,19,135,176,56,172,169,6,78,65,69,71,115,36,172,27,59,161,26,140,50,126,157,1,82,227,112,26,2,15,65,63,59,62,24,69,161,233,109,207,125,69,126,181,34,249,215,114,98,229,103,0,26,167,53,123,107,97,215,51,93,148,88,237,142,198,243,254,100,32,242,79,12,197,36,162,193,221,217,64,110,75,208,230,182,5,20,167,5,233,72,197,152,3,152,167,34,135,153,93,215,195,43,49,163,14,242,187,228,69,247,2,130,162,5,68,158,6,221,174,146,90,187,85,50,120,161,205,150,245,231,11,136,201,192,134,70,170,33,66,90,174,23,221,221,58,83,164,185,109,84,63,40,20,156,38,216,154,132,127,34,212,11,59,119,230,148,130,248,205,118,176,23,129,173,248,217,236,175,0,9,158,27,121,240,29,232,166,124,189,168,114,145,11,21,19,113,51,59,171,139,136,251,243,228,23,222,67,170,19,110,102,151,168,1,175,114,244,152,105,96,74,35,71,45,153,90,186,141,221,39,114,63,117,166,198,9,132,35,111,201,62,253,215,215,21,236,52,75,78,155,230,3,166,223,237,228,81,98,39,199,104,254,249,241,182,198,79,251,135,234,37,51,255,42,7,15,17,193,254,145,110,138,38,115,115,117,176,149,71,17,2,236,21,177,137,27,245,115,197,218,96,213,180,92,54,63,184,81,6,92,244,240,46,15,148,99,132,213,33,151,135,82,134,145,239,188,53,117,204,60,57,105,78,3,141,167,150,255,90,218,97,122,57,70,217,246,161,83,227,47,74,20,124,37,64,48,31,226,225,82,211,30,87,240,151,49,248,5,206,38,241,226,201,10,87,47,179,115,53,18,215,147,111,106,162,111,254,125,26,216,92,216,49,141,35,100,46,236,0,186,221,125,168,206,141,170,67,19,59,214,64,26,234,36,32,105,53,153,143,213,245,85,61,152,150,74,120,51,154,49,163,35,193,248,47,235,98,221,221,7,254,125,136,44,204,29,230,112,139,49,208,113,162,124,210,57,3,140,10,158,229,94,131,18,96,165,8,243,24,67,119,49,21,28,125,196,243,240,230,76,57,244,197,91,34,16,175,15,50,64,87,11,13,180,119,210,4,46,209,109,98,148,42,128,2,32,147,179,62,236,197,32,237,221,39,81,217,38,33,140,0,110,183,209,29,206,198,39,111,194,2,198,42,163,143,129,109,79,204,253,252,134,91,68,202,173,162,154,203,188,125,71,51,228,255,194,186,39,229,153,43,15,87,5,36,70,57,215,18,85,162,186,108,84,110,2,88,34,21,223,54,34,120,198,41,208,245,151,105,83,81,177,218,78,234,93,200,63,181,36,235,10,197,148,79,242,48,165,43,73,67,202,230,32,90,165,80,92,138,94,107,184,204,87,59,193,241,238,58,65,194,247,15,47,37,124,83,215,38,228,44,78,202,135,1,180,255,56,122,205,69,92,144,160,23,85,160,122,40,178,95,84,1,129,183,53,230,149,225,165,5,142,128,135,71,99,182,206,173,209,25,205,78,156,47,73,98,105,154,157,2,103,156,209,88,30,127,22,34,23,173,36,49,200,181,137,38,80,222,183,156,20,222,40,203,41,108,159,86,215,191,110,110,153,196,205,104,20,127,56,241,84,26,202,52,238,89,221,152,220,160,44,252,85,98,23,209,90,16,113,60,80,189,32,142,34,207,190,78,19,86,26,128,2,168,145,227,66,27,81,42,16,199,86,30,176,228,167,150,105,25,80,11,14,219,16,248,74,84,183,168,140,167,180,31,97,93,85,28,213,70,12,7,165,68,157,94,151,149,114,107,45,121,0,65,100,124,140,4,103,143,115,240,114,8,82,178,32,176,228,119,112,164,243,0,186,45,36,21,122,173,24,241,164,154,237,62,176,129,146,33,203,33,169,31,118,68,195,222,213,141,81,106,169,19,82,237,11,24,161,39,154,47,170,47,48,108,72,50,45,76,176,33,87,70,95,40,77,34,125,129,175,74,53,213,226,129,227,44,39,72,88,191,207,163,229,186,76,144,195,171,233,240,194,231,226,161,13,211,89,246,212,55,186,253,190,19,224,112,223,31,78,160,124,122,44,95,194,201,115,95,69,76,49,221,97,72,71,88,229,94,6,230,157,19,70,156,244,42,157,129,162,240,20,126,120,139,30,250,58,174,102,5,210,80,118,62,96,220,57,186,207,74,230,114,72,63,96,115,245,157,200,68,33,181,165,48,225,166,183,165,181,62,144,223,248,253,174,223,139,184,26,208,41,4,163,85,47,126,20],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}                                                                                       
                        POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[D{SSM}],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % encryptionkey)
                        #POST_DATA = '|' + my_json_string
                        drmresponse = LICENSE_URL + SPECIAL_HEADERS + POST_DATA + POST_RESPONSE
                        #POST_DATA = '|' + my_json_string
                        #drmresponse = LICENSE_URL + POST_DATA + POST_RESPONSE
                        log(drmresponse )
                        liz.setMimeType('application/json')
                        liz.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                        #liz.setProperty('inputstream.adaptive.license_key', LICENSE_URL + '|||')
                        liz.setProperty('inputstream.adaptive.license_key', drmresponse)
                        liz.setProperty('inputstream.adaptive.license_key', '|||')
                        #setResolvedUrl(plugin.handle, True, liz)
                        #exit(0)

                        can_open_mpd = True
                        try:
                                head = {"Connection": "keep-alive"
                                        ,"Access-Control-Request-Method": "POST"
                                        ,"Origin": "https://www.rtp.pt"
                                        ,"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
                                        ,"Access-Control-Request-Headers": "content-type"
                                        ,"Accept": "*/*"
                                        ,"Accept-Encoding": "gzip, deflate, br"
                                        ,"Accept-Language": "en-US,en;q=0.9"
                                        ,"Referer": "http://www.rtp.pt/play/"
                                        }

##GET https://streaming-live.rtp.pt/liverepeater/rtp1HD.smil/manifest.mpd HTTP/1.1
##Host: streaming-live.rtp.pt
##Connection: keep-alive
##Origin: https://www.rtp.pt
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
##Accept: */*
##DNT: 1
##Referer: https://www.rtp.pt/play/direto/rtp1
##Accept-Encoding: gzip, deflate, br
##Accept-Language: en-US,en;q=0.9


                                #conn = httplib.HTTPConnection('widevine-proxy.drm.technology')
                                #conn.request('OPTIONS', 'http://widevine-proxy.drm.technology/proxy')
                                #conn = httplib.HTTPConnection("localhost", 8888)
                                #conn.set_tunnel("widevine-proxy.drm.technology")
                                #conn.request("OPTIONS","/proxy")
                                #qq = conn.getresponse()
                                #opener = urllib.request.build_opener(urllib.HTTPHandler)
                                #request = urllib.request('http://widevine-proxy.drm.technology/proxy')
                                #request.get_method = lambda: 'OPTIONS'
                                #url = opener.open(request)
                                #opener = urllib2.build_opener(urllib2.HTTPHandler)
                                #request = urllib2.Request('http://widevine-proxy.drm.technology/proxy',None,head)
                                #request.add_header('Content-Type', 'your/contenttype')
                                #request.add_headers(head)
                                #request.get_method = lambda: 'OPTIONS'
                                #url = opener.open(request)

                                #aa = requests.request('OPTIONS', LICENSE_URL,headers=head)
                                
                                #aa = requests.request('GET', final_stream_url,headers=head)
                                #aa = requests.request('OPTIONS', LICENSE_URL,headers=head)
                                
                                log("confirming we can read MPD file %s using headers" % final_stream_url )
                                aa = __session__.get(final_stream_url, verify=False, headers=head)
                                if aa.ok == False:
                                        can_open_mpd = False
                                        xbmc.log("unable to open MPD file...trying alternate method",xbmc.LOGNONE)
                                        
                        except Exception, e:
                                kodiutils.ok("getting MPD file",str(e))

                        #wv_proxytest
                        # worked 2018-05-14 to 2018-??
                        if can_open_mpd == True:
                                liz.setMimeType('application/json')

                                #final_stream_url =  final_stream_url.replace('.smil','HD.smil')


                                #final_stream_url = final_stream_url + "|User-Agent=Mozilla/19.0"
                                wv_proxy_base = 'http://localhost:' + str(ADDON.getSetting('wv_proxy_port'))
                                token=''
                                xbmc.log("LMM" + json.dumps(__headers__),xbmc.LOGNONE)
                                xbmc.log("LMM finalsteamurl '%s'" % final_stream_url,xbmc.LOGNONE)
                                
                                #wv_proxy_url = '{0}?mpd_url={1}&token={2}&headers={3}'.format(wv_proxy_base, base64.b64encode(final_stream_url), base64.b64encode(encryptionkey), base64.b64encode(json.dumps(__headers__)))
                                wv_proxy_url = '{0}?mpd_url={1}&token={2}&headers={3}'.format(wv_proxy_base, final_stream_url, base64.b64encode(encryptionkey), base64.b64encode(json.dumps(__headers__)))
                                license_key = wv_proxy_url + '||R{SSM}|'
                                #license_key = wv_proxy_url + '|User-Agent=Mozilla/16.0|R{SSM}|'

                                #__user_agent__
                                #liz.setProperty('User-Agent', 'Mozilla/19.0')
                                
                                liz.setProperty('inputstream.adaptive.license_key', license_key)
                                liz.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+__user_agent__)

                                xbmc.log("Opening " + wv_proxy_url,xbmc.LOGNONE)
                                
                                if kodiutils.get_setting_as_bool("debug"):
                                        xbmc.log(license_key,xbmc.LOGNONE)
                                        notify('using MPD', duration=2000)


                                #xbmc.Player().play('xx' , liz)                                         
                                setResolvedUrl(plugin.handle, True, liz)
                                exit(0)


        #try old method below 
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?file\:.+?"(.+?)"', re.DOTALL).findall(req)
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(req)
        #streams = re.compile('fps:"(.+?)"', re.DOTALL).findall(req)
        
        #streams = re.compile('file\:.+?"(.+?)"', re.DOTALL).findall(req)
        #streams = re.compile('file:\W+"(.+?)"', re.DOTALL).findall(req)
	#print(req.encode('utf-8'))
	if streams:
		final_stream_url = None
		for stream in streams:
			if ".m3u8" in stream.split('/')[-1]: 
				final_stream_url = stream
				log("first found" + final_stream_url)
        else:
                streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(req)
        	if streams:
                        final_stream_url = None
                        for stream in streams:
                                if ".m3u8" in stream.split('/')[-1]: 
                                        final_stream_url = stream
                                        log("second found" + final_stream_url)
                else:
                        streams = re.compile('file:\W+"(.+?)"', re.DOTALL).findall(req)
                        if streams:
                                final_stream_url = None
                                for stream in streams:
                                        if ".m3u8" in stream.split('/')[-1]: 
                                                final_stream_url = stream
                                                log("third found" + final_stream_url)


        #final_stream_url = 'https://streaming-live.rtp.pt/liverepeater/smil:rtp1.smil/playlist.m3u8'
        final_stream_url =  final_stream_url.replace('HD.smil', '.smil')

##	if is_pseudo_aes:
##		try:
##			req = __session__.post("http://www.rtp.pt/services/playRequest.php", headers={"RTPPlayUrl":	final_stream_url})
##			final_stream_url = req.headers["RTPPlayWW"]
##		except:
##			kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
##			exit(0)		

	if final_stream_url:

                log("about to run {}:{}".format(plugin.handle, final_stream_url), xbmc.LOGNOTICE)
                
		liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
		liz.setArt({"thumb": icon, "icon": icon})
		#liz.setProperty('IsPlayable', 'false')

                #if "antena" not in rel_url:
                        #kodiutils.ok('RTPPlay2','inputstreamaddon')
                #liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                #liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
                #liz.setProperty('inputstream.adaptive.license_type', DRM)
		#liz.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+__user_agent__)
		
		liz.setPath("{}|Referer=http://www.rtp.pt/play/&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url))
                fsu=("{}|Referer=http://www.rtp.pt/play/&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url))
                #xbmc.Player().play(fsu, liz)
                
                setResolvedUrl(handle=plugin.handle, succeeded=True, listitem=liz)        
                #return
		#exit(0)
		
	else:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
		#exit(0)

        
def run():
        #log("running", xbmc.LOGNONE)
        plugin.run()
