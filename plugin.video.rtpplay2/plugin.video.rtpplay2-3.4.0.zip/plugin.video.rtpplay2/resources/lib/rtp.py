# -*- coding: utf-8 -*-
import constants as C
import json
import re
import utils
import traceback
import xbmc

from utils import Log
from utils import Log as log
from utils import Notify as notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

RTP_BASE = "https://www.rtp.pt"

#__________________________________________________________________________
#
def addRTPicons(plugin, play):

##    Log(u"{}".format("Trio d´Ataque 2021".decode('utf8')))
##    xx = u"{}".format("T2rio d´Ataque 2021".decode('utf8').encode('unicode-escape'))
##    Log(xx)
##    return

    full_html = utils.getHtml(RTP_BASE + "/play/")

    regex = (
        '(?s)<a\W+title=\"Emiss&atilde;o em direto ([^\"]+)\"'
        ' href=\"([^\"]+)\"'
        '.+?alt=\"Emiss&atilde;o em direto ([^\"]+)\"'
        '.+?src.*?=\"([^\"]+)\"'
        )
    match = re.compile(regex).findall(full_html)
    if not match:
        raise Exception("Error finding code on main RTP page")
        
    for prog, rel_url, channel, img in match:   #works 2018-12-19

        if img.startswith("/"): img = "http:{}".format(img)
        img = img + utils.Header2pipestring()

        list_item = ListItem("[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
            C.channel_text_color
            , channel.decode('unicode-escape').encode('utf8')
            , C.program_text_color
            , prog.decode('unicode-escape').encode('utf8')
            )
        )
                
        list_item.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})

        if not channel.startswith('RTP'):
            channel = 'RTP ' + channel #lets me filter things later
            
        addDirectoryItem(
            plugin.handle
            , plugin.url_for(
                play
                , rel_url=kodiutils.smart_str(rel_url)
                #, channel=channel.decode('unicode-escape').encode('utf8')
                , channel=channel
                , img=kodiutils.smart_str(img)
##                , prog=prog.decode('unicode-escape').encode('utf8')
                #, prog=prog.decode('unicode-escape')
                , prog=prog
                )
            , list_item
            , False
            )
#__________________________________________________________________________
#
def play_rtp(prog,rel_url,channel,icon):
    Log(u"prog='{}',rel_url='{}',channel='{}',icon='{}'".format(prog,rel_url,channel,icon))

    rights_url= "https://www.rtp.pt/services/rtpplay/?v=5&ch_k=" + rel_url.split('/')[-1]
    string_rtp_rights = utils.getHtml(url=rights_url, save_cookie=True)
    json_rtp_rights = json.loads(string_rtp_rights)

    if json_rtp_rights["rights"] != 1:
        utils.Notify("No rights to see this from your country", duration=7000)
        return
    else:
        Log('we have rights')

    full_html = utils.getHtml("{}{}".format(RTP_BASE, rel_url), save_cookie=True)

    final_stream_url = None
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                Log("first regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                Log("second regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('file:\W+"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                Log("third regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?fps:"([^"]+)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                Log("fourth regex found final_stream_url='{}'".format(final_stream_url))

    Log("final_stream_url='{}'".format(final_stream_url))

    playmode_string = C.DEFAULT_PLAYMODE_RTP
    if 'liveradio' in final_stream_url  and playmode_string == C.PLAYMODE_INPUTSTREAM:
        playmode_string = C.PLAYMODE_DIRECT #PLAYMODE_INPUTSTREAM can't play this

    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(C.channel_text_color, channel, prog)
    url = final_stream_url + utils.Header2pipestring()+ "&Referer=https://www.rtp.pt/play/"
    utils.playvid(url, name=name, playmode_string=playmode_string, play_profile="profile_03")
##    utils.playvid(url, name=name, playmode_string=C.PLAYMODE_INPUTSTREAM, play_profile="profile_03")

#__________________________________________________________________________
#
