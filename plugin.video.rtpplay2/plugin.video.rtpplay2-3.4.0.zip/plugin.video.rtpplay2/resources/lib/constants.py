#-*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

__scriptname__ = "Ultimate Whitecream"
__author__ = "Whitecream"
__credits__ = "Whitecream, Fr33m1nd, anton40, NothingGnome"
__version__ = "1.1.55"

import sys
import os.path
import xbmc
import xbmcaddon
import xbmcgui

##import urllib
##import urllib2
##import urllib3
##import re
##import cookielib
##import time, datetime
##import tempfile
##import sqlite3
##import urlparse
##import base64
##from StringIO import StringIO
##import gzip
##import traceback
##import threading
##import ssl

##import xbmcplugin
##import xbmcgui

##import xbmcvfs
##import cloudflare
##from jsunpack import unpack

from url_dispatcher import URL_Dispatcher
url_dispatcher = URL_Dispatcher()
from HTMLParser import HTMLParser
html_parser = HTMLParser()


USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'

DEFAULT_HEADERS = { 
    'User-Agent': USER_AGENT  
    , 'Accept': '*/*'
    , 'Accept-Encoding': 'gzip'
    , 'Accept-Language': 'en-US,en;q=0.9'
    , 'verifypeer': 'false'
    
    }
    # , 'Connection': 'close'

addon_handle = int(sys.argv[1])
this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
#xbmc.log("addon_id={}".format(addon_id), xbmc.LOGNONE)
addon_name = this_addon.getAddonInfo('name')
addon = this_addon
progress = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
resDir = os.path.join(rootDir, 'resources')
imgDir = os.path.join(resDir, 'images')

uwcicon = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))
uwcchange = xbmc.translatePath(os.path.join(rootDir, 'uwcchange.txt'))

profileDir = addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')

refresh_text_color = addon.getSetting('refresh_text_color').lower()
search_text_color = addon.getSetting('search_text_color').lower()
time_text_color = addon.getSetting('time_text_color').lower()
highlight_text_color = addon.getSetting('highlight_text_color').lower()
program_text_color = addon.getSetting('program_text_color').lower()
icon_set = addon.getSetting('icon_set').lower()

maximum_video_resolution = int(addon.getSetting("maximum_video_resolution"))#do this early so that it can be overriden later if necessary

DEFAULT_PLAYMODE_RTP = addon.getSetting('default_playmode_rtp').lower()  #allow playmode to be forced by input command, or use default from addon settings
DEFAULT_PLAYMODE = addon.getSetting('default_playmode').lower()  #allow playmode to be forced by input command, or use default from addon settings
PLAYMODE_F4MPROXY = 'f4mproxy'
PLAYMODE_INPUTSTREAM = 'inputstream'
PLAYMODE_DIRECT = 'direct'
PLAYMODE_NO_OPTIONS = "NO_OPTIONS"
PLAYMODE_VARIABLE = 'VARIABLE_MAXRES'

PLAYMODE_PROFILE_00 = 'profile_00' #the download profile
PLAYMODE_PROFILE_01 = 'profile_01'
PLAYMODE_PROFILE_02 = 'profile_02'
PLAYMODE_PROFILE_03 = 'profile_03'
VALID_PLAYMODE_PROFILES = [PLAYMODE_PROFILE_00,PLAYMODE_PROFILE_01,PLAYMODE_PROFILE_02,PLAYMODE_PROFILE_03]

LIST_AREA_HENTAI = 'HENTAI'
LIST_AREA_CAMS = 'CAMS'
LIST_AREA_TUBES = 'TUBES'
LIST_AREA_MOVIES = 'movies'
LIST_AREA_SCENES = 'SCENES'

MAX_RECURSE_DEPTH = 10 #some sites will bann IP if too many requests

##DEFAULT_RECURSE_DEPTH = min(MAX_RECURSE_DEPTH, int(addon.getSetting('recursive_search_depth')))
INBAND_RECURSE = 'inband_recurse'

refresh_icon   = os.path.join(imgDir, "library_update_{}.png".format(icon_set) )
search_icon    = os.path.join(imgDir, "search_{}.png".format(icon_set) )
not_found_icon = os.path.join(imgDir, "search_{}.png".format(icon_set) )
next_icon      = os.path.join(imgDir, "next_{}.png".format(icon_set) )
category_icon  = os.path.join(imgDir, "category_{}.png".format(icon_set) )

if not os.path.exists(profileDir):
    os.makedirs(profileDir)

favoritesdb = os.path.join(profileDir, 'favorites.db')

REFRESH_IMAGES_MODE = '898'
REFRESH_CONTAINER_MODE = '899'
FAVORITES_MODE = '900'
ROOT_INDEX_FAVORITES = '901'
QWIK_SEARCH = '905'
ROOT_FRONT_PAGE = '906'
DELETE_KEYWORD = '904'
ADD_KEYWORD = '902'
CLEAR_SEARCH = '903'
CONFIGURE_INPUTSTREAM = '9999'

ROOT_MANAGE_DOWNLOADS = '911'
ROOT_STOP_DOWNLOAD = '912'
ROOT_SEARCH_ALL = '8'
ROOT_TEST_ALL = '5'
ROOT_INDEX_MOVIES = '2'
ROOT_INDEX_TUBES = '6'
ROOT_INDEX_CAMS = '7'
ROOT_INDEX_HENTAI = '3'
ROOT_INDEX_DOWNLOAD_FOLDER = '4'
NO_ACTION_MODE = '0'
ROOT_INDEX_INDEX = '0'
ROOT_INDEX_SCENES = '1'
FLAG_RECURSE_NEXT_PAGES = '-1'

DEFAULT_NOTIFY_TIME = 2000

SPACING_FOR_TOPMOST = chr(4)
SPACING_FOR_NAMES =  '' #chr(17)
SPACING_FOR_NEXT = chr(127)

DEFAULT_PROFILE_NAME = 'profile_01'

DO_NOTHING_URL = 'DO_NOTHING_URL' #url is required in the adddir function, but there are moments when I don't want to set it

GC_SEARCHLOOP_ITERATIONS = 500
GC_SEARCHLOOP_PAUSE = 5


#label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
STANDARD_MESSAGE_CATEGORY_LABEL = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color, '{}')
STANDARD_MESSAGE_NO_VIDEO_FILE = "No video file found for '{}'"

STANDARD_MESSAGE_NO_COUNTRY = "Page {} is not available in your country"


STANDARD_MESSAGE_NEXT_PAGE = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, search_text_color, '{}')
STANDARD_MESSAGE_NP_INFO = "np_info not found in url='{}'"
STANDARD_MESSAGE_CATEGORIES = "{}[COLOR {}]Categories[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_SEARCH = "{}[COLOR {}]Search[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_SEARCH_RECURSIVE = "{}[COLOR {}]Search Recursive[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)

STANDARD_MESSAGE_UHD  = " [COLOR {}]uhd[/COLOR]".format(search_text_color)
STANDARD_MESSAGE_FHD  = " [COLOR {}]fhd[/COLOR]".format(refresh_text_color)
STANDARD_MESSAGE_HD   = " [COLOR {}]hd[/COLOR]".format(time_text_color)
STANDARD_MESSAGE_NOHD = ""

VIDEO_NOT_AVAILABLE_WARNINGS = [
    "This video has been flagged for verification"
    ,"This page is not available in your country."
    ,"Video has been removed at the request of "
    ,"Video has been flagged"
    ,"this video is no longer available"
    ,"This Video Is Private"
    ,"this video is private."
    ]



channel_text_color = this_addon.getSetting('channel_text_color')
program_text_color = this_addon.getSetting('program_text_color')

EURONEWS_BASE="https://AApt.euronews.com/api/watchlive.json"
