# -*- coding: utf-8 -*-

#import base libraries
import datetime
import json
import os
import re
import traceback
#import internal addon libraries
import utils
import player
#define frequenctly used aliases
import constants as C
from utils import Log,LogR,Notify



MAIN_MODE          = C.MAIN_MODE_tvi
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
LIST_ROW_MODE      = str(int(MAIN_MODE) + 6)

TVI_BASE = "https://tviplayer.iol.pt"

DEFAULT_SORT_ORDER = 5.0

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE)
##def add_icons(plugin, play, subchannel='', subchannel_label='', sort_order=None):
def add_icons(
               subchannel = u''
              , subchannel_label = u''
              , sort_order = DEFAULT_SORT_ORDER
              , cache_as_json = False 
              , testmode = False
              , end_directory = False):

##    if subchannel == 'TVI_INTERNACIONAL':
##        subchannel = 'tviinternacional'
##        subchannel_label = 'TVI International'
        
    LogR((subchannel,subchannel_label,sort_order))
    
    if not subchannel: return  #for this set, only allow specific channels
    sub_url = "/direto/"

    if not sort_order: sort_order = DEFAULT_SORT_ORDER
    else: sort_order = float(sort_order)
    playable_url = ""

    #use cached HTML to create icons
    try:

        json_info = utils.global_cache.get(C.addon_id + TVI_BASE + sub_url + subchannel)

        json_items = None #testing
        if json_info and (len(json_info) > 0)  :
            Log("using global_cache tvi")
        else:
            with utils.global_mem_cache_lock:
                html_src = utils.getHtml(TVI_BASE + sub_url + subchannel)

                #regex = r"jsonData = (.+?});"
                regex_v1 = r"video: (\[.+?}}\])" #2025-12-08 transitional?
                regex = r"jsonData = (.+?});"  #2025-12-08

                html_text = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html_src)
                if not html_text:
                    html_text = re.compile(regex_v1, re.DOTALL | re.IGNORECASE).findall(html_src)
                if html_text: html_text = html_text[0]

                LogR(html_text,C.LOGWARNING)

                try:
                    json_info = json.loads(html_text)
                except:
                    return ""

                try:
                    json_info = json_info[0]['videoObj'] #2025-12-08
                except:
                    pass
                    
                #json_info = json_info[0]['videoObj']
##                LogR(json_info
#2025-12-08
##{"liveType":"DIRETO"
## ,"videoType":"Live"
## ,"categoria":"Informação"
## ,"channel":"TVI_INTERNACIONAL"
## ,"description":""
## ,"program":{
##     "name":"Jornal Nacional"
##     ,"season":"676ef283d34e94b829091666"
##     ,"id":"63e6588b0cf2665294d4f012"
##     ,"ep":"Sem Episódio"
##},"title":"Jornal Nacional"
## ,"duration":"-1"
## ,"cover":"https://img.iol.pt/image/id/63f3d1530cf2c84d7fc8ebc0/"
## ,"videoUrl":"https://video-auth5.iol.pt/live_tvi_internacional/live_tvi_internacional/playlist.m3u8"
## ,"liveEnd":1833004,"genero":"NA"
## ,"id":"554bb20f0cf28547ba511c7d","affiliate":"CMS"
## ,"brand":"TVI","providerName":"MCD"};
                
                utils.global_cache.set(
                    endpoint = (C.addon_id + TVI_BASE + sub_url + subchannel)
                    ,data = json_info
                    ,expiration = datetime.timedelta(seconds=C.default_GETHTML_cache_duration)
                    )
            


        LogR(json_info,C.LOGWARNING)
        json_video_info = json_info["videoUrl"]
        playable_url = json_video_info            
        program_name = json_info["program"]["name"]
        try:
            episode_name = json_info["title"]
        except:
            episode_name = program_name
            
        icon = json_info["cover"]

        icon_label = u"[COLOR {}][B]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
            C.channel_text_color
            , subchannel_label 
            , C.program_text_color
            , program_name 
            )

        playable_url = utils.Add_Listitem(
            mode = PLAY_MODE
            ,icon_label = icon_label
            ,url = playable_url
            ,program_name = episode_name
            ,channel = subchannel
            ,icon = icon
            ,module_name = __name__.split('.')[-1]
            ,rating = sort_order
            ,playmode_string = u''
            ,play_profile = u''
            ,testmode = testmode
            ,cache_as_json = cache_as_json
            ,is_folder = False
            )

    except:
        raise
        pass

    return playable_url
    
###__________________________________________________________________________
###
@C.url_dispatcher.register(PLAY_MODE, ['icon_label','url'], ['channel', 'program_name', 'icon', 'playmode_string', 'play_profile','download', 'testmode'])
def play( icon_label
         ,url
         ,channel=None
         ,program_name=u''
         ,icon=None
         ,playmode_string=None
         ,play_profile=None
         ,download=None
         ,testmode=False):


    if C.PY2:
        if not isinstance(icon_label, C.text_type):
            icon_label = icon_label.decode('utf8')
        if not isinstance(program_name, C.text_type):            
            program_name = program_name.decode('utf8')
        
    Log(u"icon_label='{}',playmode_string='{}',play_profile='{}',url='{}',channel='{}',icon_URI='{}', download='{}'".format(
        icon_label,playmode_string,play_profile,url,channel,icon,download)
        ,C.LOGNONE
        )
    
    download = bool(download)
    testmode = bool(testmode)
    qq = C.urlparse.parse_qs(url)
    if 'url' in qq:
        rel_url = qq['url'][0]
    else:
        rel_url = url
        
    #
    #various download options
    #
    download_filespec = None
    if download:
        dt = datetime.datetime.now().strftime('%Y-%m-%d')
        d_name = u"{}.{}.{}.ts".format(
            utils.Clean_Filename(icon_label)
            , utils.Clean_Filename(channel).strip(' ')
            , dt
            )
        download_filespec = utils.get_setting('download_path')
        if not download_filespec:
            download_filespec = None
        else:
            download_filespec = os.path.join(download_filespec, d_name)

    #
    #f4mproxy defaults
    #
    if not playmode_string:
        playmode_string = C.DEFAULT_PLAYMODE
    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    
    tviheaders = {"Origin":"http://tviplayer.iol.pt"
                  ,"Referer":"http://tviplayer.iol.pt/direto"
                  ,"Accept-Encoding":"gzip"
                  ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0"
                  }

##    Log(url)
##    return
    page_content = rel_url
    
    #2019-03-30 - ...and a second call to get a user id is required
    matrix_userId = utils.getHtml("https://services.iol.pt/matrix?userId="
                                  , headers=tviheaders
                                  , cache_duration=300
                                  )
    m3u8_url = page_content+"?wmsAuthSign="+matrix_userId
    video_url = m3u8_url + utils.Header2pipestring(tviheaders)

##    if download:
##        prog = re.sub("(?:\[COLOR \w+\]\d+:\d+\[/COLOR\]|\[COLOR \w+\]|\[/COLOR\])", "", name).strip(' ')
##        dt = datetime.datetime.now().strftime('%Y-%m-%d')
##        name = u"{}.{}.{}".format(prog, dt, name)

    if program_name: program_name = u" ({})".format(program_name)
    play_label = u"[B][COLOR {}]{}[/COLOR]{}".format(
        C.channel_text_color
        , icon_label
        , program_name)

    #
    #what to do if we are just testing
    #
##    testmode=True
##    testmode=False    
    if testmode:
        Log(repr(( "warning TESTMODE:"
                    , video_url
                    , play_label
                    , playmode_string
                    , play_profile
                    , download
                    , download_filespec
                  )))
        utils.getHtml(m3u8_url,headers=tviheaders)
        utils.endOfDirectory(end_directory=False)
        return

    player.playvid(
        video_url
        , name=play_label
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
        , download = download
        , download_filespec=download_filespec
    )

#__________________________________________________________________________
# Unit tests
@C.url_dispatcher.register(TEST_MODE)
def TEST_MODE():
    test_label = ""
    module_name = __name__.split('.')[-1]
    try:
        test_label = u'download html and add all categories'.format(module_name)
        playable_url = add_icons(
               subchannel = u'CNN'
              , subchannel_label = u''
              , sort_order = None
              , testmode = True
              )
        Log(playable_url)
        play(  icon_label = u'CNN'
             , url = playable_url
             , testmode = True
             )
             
        add_icons(
            subchannel = u'TVI'
              , subchannel_label = u''
              , sort_order = None
              , testmode = True
              )
        add_icons(
            subchannel = u'TVI_INTERNACIONAL'
          , subchannel_label = u''
          , sort_order = None
          , testmode = True
          )

        test_label = u'{}€ download'.format(module_name)
        play(
             url =  playable_url
             , icon_label = test_label
             , channel =  u'{}'.format('PT/RTP3.pt')
             , download = True
             , testmode = False
             )
        
    except Exception as e:
        traceback.print_exc()
        raise Exception(test_label)
#__________________________________________________________________________
#
