# -*- coding: utf-8 -*-
import xbmc
def Log(msg):
    return
    xbmc.log(repr(msg),xbmc.LOGNONE)
##Log(sys.argv)
argv2 = repr(sys.argv[2])
Log(argv2)


#performance testing
from timeit import default_timer as timer
#performance testing
start = timer()

reload_check = None
try:
    import re
    regex = "(\?reload=\d+)"
    reload_check = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(argv2)
    if reload_check:
        reload_check = reload_check[0]
    else:
#Log("reload is not present")
        pass
except:
    import traceback
    traceback.print_exc()

from resources.lib import plugin
if reload_check:
#Log(reload_check)
    pass
# Log("indexing only because reload present")
else:
    import xbmcplugin
    if int(sys.argv[1]) > 0:
        xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available
plugin.routing_plugin.run()

#performance testing
Log(repr(timer() - start))
