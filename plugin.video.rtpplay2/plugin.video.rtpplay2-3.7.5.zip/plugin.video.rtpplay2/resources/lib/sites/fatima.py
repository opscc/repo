# -*- coding: utf-8 -*-


#import base libraries
import json
import re
import traceback
import urllib
import xbmc
#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

#__________________________________________________________________________
#
def add_icons(plugin, play):
    channel = "Fatima"
    prog = "Fatima"

    sorting_delta = 0.0
    sorting_base = 2.0


    full_html = utils.getHtml("https://www.fatima.pt/en/pages/online-transmissions")

    playlink_name = "[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
        C.channel_text_color
        , channel.encode('utf8')
        , C.program_text_color
        , prog.encode('utf8')
        )

    match=re.compile('(?s)playhtml\?file=(.+?)\".+?embed\/+([^\"]+)\"').findall(full_html) #pre 2019-05-12 [double / added by site]
    for rel_url, img in match:
        utils.addPlaylink(
            plugin = plugin
            ,playlink_name = playlink_name
            ,final_url =kodiutils.smart_str(rel_url)
            ,program_name = kodiutils.smart_str(prog)
            ,channel =kodiutils.smart_str(channel)
            ,icon="https://i.ytimg.com/vi/" + img + "/maxresdefault_live.jpg"
            ,play=play
            ,module_name=__name__.split('.')[-1]
            ,rating=sorting_base+sorting_delta  #lower value is on top in sort ascending
            ,return_json_info = True
            ,is_folder = False
            ,filter_category = ''

            )
            
#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile):

    #Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(prog,playmode_string,play_profile,rel_url,channel,icon))

    match=re.compile('(http[sS]?:[\/]{2}.*?)(\/.*)\&').findall(rel_url)

    for baseURL, relURL in match:
        
        full_html = utils.getHtml("{}{}?all=1".format(baseURL, relURL))
        json_urls = json.loads(full_html)
        #Log(   str(json_urls) )
       
        #url = json_urls['rtsp'] + utils.Header2pipestring()
        url = json_urls['hls'] + utils.Header2pipestring()
        name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
            C.channel_text_color, channel, prog)

        if not playmode_string:
            playmode_string = C.DEFAULT_PLAYMODE

        if playmode_string not in C.PLAYMODE_F4MPROXY:
            play_profile = None
        else:
            if play_profile not in C.VALID_PLAYMODE_PROFILES:
                play_profile = C.PLAYMODE_PROFILE_02

        utils.playvid(
            url
            , name=name
            , playmode_string=playmode_string
            , play_profile=play_profile
            )

#__________________________________________________________________________
#
