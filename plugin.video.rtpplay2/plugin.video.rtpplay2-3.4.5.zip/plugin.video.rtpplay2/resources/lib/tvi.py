# -*- coding: utf-8 -*-
import constants as C
import json
import re
import utils
import traceback
import xbmc

from utils import Log
from utils import Log as log
from utils import Notify as notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

TVI_BASE = "https://tviplayer.iol.pt"

#__________________________________________________________________________
#
def addTVIIcons(plugin, play):

    #channel_list = {"TVI24",  "TVI_DIRECT", "TVI_FICCAO", "TVI_INTERNACIONAL"}
    channel_list = { "TVI24" , "TVI", "TVI_INTERNACIONAL"} #, "TVI_DIRECT"}
    sub_url = "/ajax/emissao/"
    sub_url = "/direto/"

    for channel in channel_list:

##            html_src = __session__.get(TVI_BASE + sub_url + channel, verify=False)
        html_src = utils.getHtml(TVI_BASE + sub_url + channel)
##            Log("html_src.apparent_encoding='{}'".format(html_src.apparent_encoding))
##        Log("html_src='{}'".format(html_src))
        regex = "\$\('#player_live'\).iolplayer\({\s+?video:\s+?\[([^\]]+)\]"
        regex = "var liveToJson = (.+?});"
        regex = "jsonData = (.+?});"
##        html_text = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html_src.text.encode("ascii", "ignore"))
        html_text = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html_src) #.text.encode("ascii", "ignore"))
        Log("html_text='{}'".format(html_text))
        Log("html_text[0]='{}'".format(html_text[0]))
        
        json_info = json.loads(html_text[0])
        json_video_info = json_info["videoUrl"]
        
        Log("json_info='{}'".format(json_info))
        program_name = json_info["program"]["name"]
        list_item = ListItem("[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
            C.channel_text_color
            #, kodiutils.smart_str(channel)
            #, channel.encode('unicode-escape')
            , channel.encode('utf8')
            , C.program_text_color
##            , kodiutils.smart_str(program_name)
##            , program_name.encode('unicode-escape')
##            , program_name
            , program_name.encode('utf8')
            )
        )

        icon = json_info["cover"]
        list_item.setArt({"thumb": icon, "icon": icon})
        final_url = json_video_info            
        Log("final_url='{}'".format(final_url))

        addDirectoryItem(
            plugin.handle
            , plugin.url_for(
                play
                , rel_url=kodiutils.smart_str(final_url)
##                , channel=kodiutils.smart_str(channel)
                , channel=channel.encode('unicode-escape')
                , img=kodiutils.smart_str(icon)
                #, prog=kodiutils.smart_str(program_name)
                , prog=program_name.encode('unicode-escape')
                )
            , list_item
            , False
            )

#__________________________________________________________________________
#
def play_tvi(prog,rel_url,channel,icon):
    Log("prog='{}',rel_url='{}',channel='{}',icon='{}'".format(prog,rel_url,channel,icon))

    tviheaders = {"Origin":"http://tviplayer.iol.pt"
                  ,"Referer":"http://tviplayer.iol.pt/direto"
                  ,"Accept-Encoding":"gzip"
                  ,"User-Agent":"Mozilla/13.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
                  }
    page_content = rel_url
    #2019-03-30 - ...and a second call to get a user id is required
    matrix_userId = utils.getHtml("https://services.iol.pt/matrix?userId=",headers=tviheaders)

    m3u8_url = page_content+"?wmsAuthSign="+matrix_userId
    Log("m3u8_url='{}'".format(m3u8_url))

    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog.decode('unicode-escape'))
    url = m3u8_url + utils.Header2pipestring(tviheaders)
    utils.playvid(url, name=name, play_profile="profile_01")
#__________________________________________________________________________
#
