# -*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import xbmc
import traceback
import sys

import constants
import constants as C
from constants import urlparse

#these libraries are imported individually in order to capture extreme exceptions

import utils
import plugin
import player

import service #devtesting; load here to capture errors more conveniently

##xbmc.log(repr(C.url_dispatcher.func_registry2()), xbmc.LOGNONE)
#these libraries are imported bulk because the exceptions can be caught later
##from resources.lib.sites import sportsdaddy
from sites import *


#__________________________________________________________________________
#
#__________________________________________________________________________
#
def parse_query(query):
    #convert these values to integers for the convenience of later callers
    toint = ['page', 'download', 'favmode', 'channel', 'section'] 
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = str(queries[key][0])
        else: #.decode('utf8')
            q[key] = str(queries[key])
    return q

def main(argv=None):

    if sys.argv: argv = sys.argv
    queries = parse_query(sys.argv[2])
    mode = 0
    try:
        mode = queries.get('mode', None)
        mode_via_url = sys.argv[0].split('/')[3]
        if mode_via_url: mode = str(int(mode_via_url))
    except ValueError as ex:
        pass
    C.url_dispatcher.dispatch(mode, queries)

if __name__ == '__main__':
    utils.LogR(sys.argv, C.LOGWARNING)
    sys.exit(main())
#__________________________________________________________________________
#
#__________________________________________________________________________
#
