# -*- coding: utf-8 -*-

import json
import xml.etree.ElementTree as ET
import net
import xbmc,xbmcaddon

net = net.Net(user_agent="Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36")
this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
addon_name = this_addon.getAddonInfo('name')
def log(msg="", loglevel=None):
    debug = None
    try: debug = (xbmcaddon.Addon().getSetting('debug').lower() == "true")
    except: debug = True
    msg = "{}: {}".format(addon_id, msg).encode('utf-8')
    if   loglevel:  xbmc.log(msg , loglevel)
    elif    debug:  xbmc.log(msg , xbmc.LOGNONE)
    else:           xbmc.log(msg)

class Widevine(object):
    license_url = 'http://widevine-proxy.drm.technology/proxy'

    def get_kid(self, mpd_url, dict_KID_header):
        if dict_KID_header is None:
            dict_KID_header = {'Accept': '*/*'} #later code will not work with blank
        mpd_data = net.http_GET(mpd_url, dict_KID_header).content
        mpd_root = ET.fromstring(mpd_data)
        for i in mpd_root.iter('{urn:mpeg:dash:schema:mpd:2011}ContentProtection'):
            if '{urn:mpeg:cenc:2013}default_KID' in i.attrib:
                log("returning KID : %s" % i.attrib['{urn:mpeg:cenc:2013}default_KID'])
                return i.attrib['{urn:mpeg:cenc:2013}default_KID']

    def get_license(self, mpd_url, wv_challenge, token, dict_KID_header, dict_POST_header={}  ):
        """Acquire the Widevine license from the license server and return it."""
        #log(" len(wv_challenge)                          '{}'".format(  len(wv_challenge)   ))
        #log(" len([x for x in bytearray(wv_challenge)])  '{}'".format(  len([x for x in bytearray(wv_challenge)])   ))
        post_data = {
            'token': token,
            'drm_info': [x for x in bytearray(wv_challenge)],  # convert challenge to a list of bytes
            'kid': self.get_kid(mpd_url, dict_KID_header)
        }
##        post_data = {
##            'token': token,
##            'drm_info': [8,4],  # convert challenge to a list of bytes
##            'kid': self.get_kid(mpd_url, dict_KID_header)
##        }
        log("-GET LICENSE POST DATA: '{}'".format(repr(post_data)))
        
        if not dict_POST_header: dict_POST_header= {'Content-Type': 'application/json'}
        log("dict_POST_header %s" % dict_POST_header)

        # wv_license = helper.c.make_request(self.license_url, 'post', payload=json.dumps(post_data))
        wv_license = net.http_POST(self.license_url, json.dumps(post_data), dict_POST_header ).content
        log("wv_license aquired: '{}'".format(repr(wv_license)))

        return wv_license
