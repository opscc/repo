# -*- coding: utf-8 -*-
import xbmc
xbmc.log(repr(sys.argv),xbmc.LOGNONE)
##
argv2 = repr(sys.argv[2])
xbmc.log(argv2,xbmc.LOGNONE)
##
reload_check = None
try:
    import re
    regex = "(\?reload=)"
    reload_check = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(argv2)
    if reload_check:
##        xbmc.log("b4 arraytrim "+repr(reload_check),xbmc.LOGNONE)
        reload_check = reload_check[0]
##        xbmc.log("after arraytrim "+repr(reload_check),xbmc.LOGNONE)
    else:
        xbmc.log("reload is not present ", xbmc.LOGNONE)
except:
    import traceback
    traceback.print_exc()

from resources.lib import plugin
if reload_check:
    xbmc.log("only indexing because reload present ", xbmc.LOGNONE)
    plugin.index()
else:
    import xbmcplugin
    if int(sys.argv[1]) > 0: xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available
    plugin.routing_plugin.run()

#from xbmcplugin import endOfDirectory
#endOfDirectory(int(sys.argv[1]), cacheToDisc=True)


##utils.endOfDirectory(cacheToDisc=True)


##import threading
##thread = threading.Thread(
##        name='plugin.run'
##        ,target=plugin.run
##        ,args=()
##    )
##thread.daemon = True
##thread.start()

