# -*- coding: utf-8 -*-
import routing
import sys
import traceback
import utils
import xbmc
import xbmcaddon
import xbmcplugin
from resources.lib import constants as C
routing_plugin = routing.Plugin()


###with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
##xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_INPUTSTREAM)
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()

###__________________________________________________________________________
###
##def run():
##    utils.Log(repr(sys.argv))
####    if int(sys.argv[1]) > 0: xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available
##    plugin.run()
####    utils.endOfDirectory(cacheToDisc=True)
####    index()
##    utils.endOfDirectory(cacheToDisc=True)
##
#__________________________________________________________________________
#
@routing_plugin.route('/')
def index():

    try:
        if utils.get_setting('list_tvi'):
            import tvi
            tvi.addTVIIcons(routing_plugin, play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding TVI", duration=4000)
    try:
        if utils.get_setting('list_euronews'):
            import euronews
            euronews.addEuronewsIcon(routing_plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Euronews", duration=4000)
    try:
        if utils.get_setting('list_fatima'):
            import fatima
            fatima.addFatimaIcon(routing_plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Fatima", duration=4000)
    try:
        if utils.get_setting('list_rtp'):
            import rtp
            rtp.addRTPicons(routing_plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding RTP icons", duration=4000)
    try:
        import xbmcgui
        liz = xbmcgui.ListItem(
            label='[B][COLOR {}]Settings[/COLOR][/B]'.format(C.highlight_text_color)
            ,iconImage=C.uwcicon
            ,thumbnailImage=C.uwcicon 
            )
        xbmcplugin.addDirectoryItem(
            handle=routing_plugin.handle
            , url=routing_plugin.url_for(
                configure_THIS_addon
            )
            , listitem=liz
            , isFolder=False
        )
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Configuration icon", duration=2000)

    utils.endOfDirectory()

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_THIS_ADDON)
def configure_THIS_addon():
    xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    import xbmcaddon
    xbmcaddon.Addon(id=C.addon_id).openSettings()
    #utils.endOfDirectory()
    return True
#__________________________________________________________________________
#
@routing_plugin.route('/play')
def play():

    utils.Log(repr(sys.argv))
    utils.Log(repr(routing_plugin.args))

    rel_url = routing_plugin.args["rel_url"][0]
    channel = routing_plugin.args["channel"][0]
    prog = routing_plugin.args["prog"][0]
    icon = routing_plugin.args["img"][0]
    if "playmode_string" in routing_plugin.args:      playmode_string = routing_plugin.args["playmode_string"][0]
    else:          playmode_string = None
    if "play_profile" in routing_plugin.args:         play_profile = routing_plugin.args["play_profile"][0]
    else:         play_profile = None

    #utils.Log(prog)
    if '\\x' in prog:
        #utils.Log(prog.decode('unicode-escape').encode('utf8'))
        prog = prog.decode('unicode-escape').encode('utf8')
    if '\\x' in channel:
        #utils.Log(prog.decode('unicode-escape').encode('utf8'))
        channel = channel.decode('unicode-escape').encode('utf8')
    
    #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen

    import tvi
    for sub_channel in tvi.CHANNEL_LIST:
        utils.Log(repr(sub_channel))
        if channel.startswith(sub_channel):
            tvi.play_tvi(prog,rel_url,channel,icon,playmode_string,play_profile)
            utils.endOfDirectory()
    if prog == "PT Euronews":
        import euronews
        euronews.play_euronews(prog,rel_url,channel,icon,playmode_string,play_profile)
    elif prog == "Fatima":
        import fatima
        fatima.play_fatima(prog,rel_url,channel,icon,playmode_string,play_profile)
    elif channel.startswith('RTP'):
        import rtp
        rtp.play_rtp(prog,rel_url,channel,icon,playmode_string,play_profile)

##    utils.endOfDirectory()
    return True
    
#__________________________________________________________________________
#
        
