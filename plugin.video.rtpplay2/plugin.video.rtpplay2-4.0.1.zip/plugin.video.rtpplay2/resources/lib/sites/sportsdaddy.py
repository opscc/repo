# -*- coding: utf-8 -*-

#import base libraries
import datetime
import json
import os
import re
import time
import traceback
#import internal addon libraries
import utils
import player
#define frequenctly used aliases
import constants as C
from utils import Log,LogR,Notify

MAIN_MODE          = C.MAIN_MODE_sportsdaddy
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
LIST_ROW_MODE      = str(int(MAIN_MODE) + 6)

BASE = "https://daddylivehd.sx/"
BASE = "https://daddylive.sx/"
BASE = "https://dlhd.sx/"
BASE = "https://dlhd.so/"
BASE = "https://thedaddy.to/"
BASE = "https://daddylive.dad/"

CATEGORY_REGEX = (
    '<h2 style="background-color:cyan">'
    '(?P<category>.+?)(?:</?h2>|<div id="sidebar">)'
    '(?P<category_info>.+?)(?=<h2 |<div id="sidebar">|\\Z)'
    )

CHANNEL_INFO_REGEX = (
    '<hr>(?:<strong>|)(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)(?:</strong>|)\s*<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|<hr|<h2|<div id="sidebar">)'
    )
CHANNEL_INFO_REGEX = (
    '<hr>(?:<strong>|)(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)(?:</strong>|)\s*<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|</span>\s|<hr|<h2|<div id="sidebar">)'
    )

LINK_INFO_REGEX = (
    'href="(?P<link>.+?)"'
    '.+?rel="noopener">(?P<broadcaster>.+?)</a>'
    )

try: cache_duration = int(utils.get_setting('html_cache_sportsdaddy'))
except: cache_duration = 300

DEFAULT_SORT_ORDER = 1000.0

##DEFAULT_PLAYMODE = C.PLAYMODE_INPUTSTREAM #2025-03 inputstream works again after proxy tweaks
DEFAULT_PLAYMODE = C.PLAYMODE_DIRECT #2024-10 ...but direct now works! ;/
##DEFAULT_PLAYMODE = C.PLAYMODE_F4MPROXY #2025-03 works, but fiddler stream mode will cause drops
DEFAULT_PLAY_PROFILE = C.PLAYMODE_PROFILE_01


STREAM_REGION_01 = '<div class="box">(.+)</span>Backup Streams Of Soccer &amp; Other Events</h1>'
STREAM_REGION_01 = '<div class="box">(.+)<div id="sidebar">'

SCHEDULE_JSON = BASE + 'schedule/schedule-generated.json'
SCHEDULE_JSON = BASE + 'schedule/schedule-generated.php'
SCHEDULE_HEADERS = {
                   "Referer" : 'https://daddylive.mp/'
                  ,"Accept-Encoding":"gzip"
                    ,"User-Agent": C.USER_AGENT#'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
                  }


#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE)
def add_icons(
                subchannel = u''
              , subchannel_label = u''
              , sort_order = DEFAULT_SORT_ORDER
              , cache_as_json = False  
              , testmode = False
              , end_directory = False):
    Log(repr((
                subchannel
              , subchannel_label
              , sort_order
              , cache_as_json
              , testmode
              , end_directory
               )))

    try:

        if not sort_order: sort_order = DEFAULT_SORT_ORDER
        else: sort_order = float(sort_order)
        
        #if not subchannel: return  #for this set, only allow specific channels
        program_name = subchannel #ignore program name because we don't have a tvguide for this


        icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon


        if subchannel.isdigit(): #don't worry about categories when we need to tune to a specific number
            Log('subchannel.isdigit()')
            playable_url = subchannel
            icon_label = u'[B][COLOR {}]{}[/COLOR][/B]'.format(
                        C.channel_text_color
                        ,subchannel_label)
            
            utils.Add_Listitem(
                mode = PLAY_MODE
                ,icon_label = icon_label
                ,url = playable_url
                ,program_name = program_name
                ,channel = subchannel
                ,icon = icon
                ,module_name = __name__.split('.')[-1]
                ,rating = sort_order
                ,playmode_string = u''
                ,play_profile = u''
                ,testmode = testmode
                ,cache_as_json = cache_as_json
                ,is_folder = False)

            return playable_url


        #
        # Load createable icons from cache or from html 
        #
        with utils.global_mem_cache_lock: #lock permits a cached GET when this section is launched within multiple threads
        ##    return json.loads("[]")  #testing
            json_info = utils.global_cache.get(C.addon_id+BASE)
##            json_info = None #testing
            if json_info and (len(json_info) > 0)  :
                Log("using global_cache " + BASE)
            else:
                json_src = utils.getHtml(SCHEDULE_JSON, headers=SCHEDULE_HEADERS  , cache_duration=cache_duration)
    ##            utils.Sleep(20000) ##performance testing
                json_info = json.loads(json_src)
##                utils.global_cache.set(
##                    endpoint = (C.addon_id+BASE)
##                    ,data = json_info
##                    ,expiration = datetime.timedelta(seconds=C.default_GETHTML_cache_duration)
##                    )


        #convert start time from GMT+1 to EST
        time_range = int(utils.get_setting('time_range_sportsdaddy'))
        today = datetime.datetime.utcnow()
        schedule_time = today.utcnow() + datetime.timedelta(hours=-6) 

        for k in json_info.keys(): #first item is a date which we can skip
            for category in json_info[k].keys(): 

                #skip non specified categories 
                if subchannel_label and not (subchannel in category): continue

                #skip categories with no entries
                if len(json_info[k][category]) < 1: continue

                #add a sub menu for the category with entries
                category_name = u"[COLOR {}][B]{}[/B][/COLOR]".format(
                    C.refresh_text_color
                    , category.split('</')[0] #fix bug on site, but only for displayed info
                    )

                sorting_delta = 0.1
                sort_order += sorting_delta

                if subchannel_label:
                    icon = os.path.join(C.imgDir, u''.join(subchannel_label.split('</')[0].split(u' '))+u'.png') #strip any spaces in the lable to find icon
                else:                
                    icon = os.path.join(C.imgDir, u''.join(category.split('</')[0].split(u' '))+u'.png') #strip any spaces in the lable to find icon
                if not os.path.isfile(icon):
                    icon = os.path.join(C.imgDir, u'other.png')

                playable_url = subchannel
                
                utils.Add_Listitem(
                    mode = LIST_ROW_MODE
                    ,icon_label = category_name
                    ,url = playable_url
                    ,program_name = category
                    ,channel = category
                    ,icon = icon
                    ,filter_category = category
                    ,module_name = __name__.split('.')[-1]
                    ,rating = sort_order
                    ,playmode_string = u''
                    ,play_profile = u''
                    ,testmode = testmode
                    ,cache_as_json = cache_as_json
                    ,is_folder = True)

    except:
        traceback.print_exc()

    return playable_url
        
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_ROW_MODE, ['filter_category','testmode'])
def Add_Icons_Rows(filter_category, testmode, end_directory=True):
    Log(repr((filter_category,testmode,end_directory)))

    json_urls = [
        SCHEDULE_JSON
##        ,BASE + 'schedule/schedule-generated.json'
        ]
    try:
        for json_url in json_urls:

            json_src = utils.getHtml(json_url, headers=SCHEDULE_HEADERS, cache_duration=cache_duration)
            json_info = json.loads(json_src)

            sorting_delta = 0
            sorting_base = 3
        
            for k in json_info.keys(): #first item is a date which we can skip
                for category in json_info[k].keys():


                    if filter_category and (category != filter_category):
##                        #split occurs due to site-side error in data on 2025-03
##                        Log(repr((category,filter_category)))
                        continue
                
                    for event in json_info[k][category]: #json_info[json_info.keys()[0]][category]:
                        
                        try:
                            t_time = '12 12 2023 ' + event['time']
                        except:
                            t_time = '00:00'
                        try:
                            gmt_time = datetime.datetime.strptime( json_info.keys()[0].split(' - Schedule Time')[0] + event['time'], '%A %dth %B %Y%H:%M')
                        except:
                            try: 
                                gmt_time = datetime.datetime.strptime(t_time, '%d %m %Y %H:%M')
                            except TypeError:
                                gmt_time = datetime.datetime(*(time.strptime(t_time, '%d %m %Y %H:%M')[0:6]))
                            
                        schedule_time = gmt_time + datetime.timedelta(hours=-5) #convert from GMT+1
        
                        time_and_teams_name = u" [COLOR {}]{}[/COLOR] [COLOR {}]{}[/COLOR]".format(
                             C.time_text_color
                            , schedule_time.strftime('%H:%M') #event['time']
                            , C.highlight_text_color
                            , utils.cleantext(event['event'])
                            )

                        sorting_delta = sorting_delta + 1

                        icon = os.path.join(C.imgDir, category.split('</')[0]+'.png')
                        
                        utils.Add_Listitem(
                            mode = PLAY_MODE
                            ,icon_label = time_and_teams_name
                            ,url = C.DO_NOTHING_URL
                            ,program_name = category
                            ,channel = category
                            ,filter_category = category
                            ,icon = icon
                            ,module_name = __name__.split('.')[-1]
                            ,rating = sorting_base+sorting_delta
                            ,playmode_string = u''
                            ,play_profile = u''
                            ,testmode = testmode
                            ,cache_as_json = False
                            ,is_folder = False)
                    

                        for link in event['channels']:
##                            Log(repr(event['channels']))

                            channel_name = channel_id = None

                            #sometimes data is a list, other times a numbered array
                            if type(link) is dict:
                                if not (u'channel_id' in link):
                                    continue #sometimes there is a blank entry
                                channel_name = link[u'channel_name']
                                channel_id = link[u'channel_id']
                            else:
                                #note: the json parser in py2 may reorder the array differently
                                #  ie.  source data is (0, 1, ... 11, 12) but parsed as (11, 12 ... 1, 0, 2)
                                link3 = event[u'channels'][link]
                                if not (u'channel_id' in link3):
                                    continue #sometimes there is a blank entry
                                channel_name = link3[u'channel_name']
                                channel_id = link3[u'channel_id']
                                                            
                            if channel_name and channel_id:

                                channel_name = utils.cleantext(channel_name)
                                
                                name = u"      [COLOR {}]{}[/COLOR]".format(
                                    C.program_text_color
                                    ,channel_name + ' channel ' + channel_id
                                    )


                                utils.Add_Listitem(
                                    mode = PLAY_MODE
                                    ,icon_label = name
                                    ,url = C.DO_NOTHING_URL
                                    ,program_name = time_and_teams_name
                                    ,channel = channel_id
                                    ,filter_category = category
                                    ,icon = os.path.join(C.imgDir, category+'.png')
                                    ,module_name = __name__.split('.')[-1]
                                    ,rating = sorting_base+sorting_delta
                                    ,playmode_string = u''
                                    ,play_profile = u''
                                    ,testmode = testmode
                                    ,cache_as_json = False
                                    ,is_folder = False)
                                


    
    except:
        traceback.print_exc()
        raise

    if end_directory: 
        utils.endOfDirectory(cacheToDisc=False)
    
###__________________________________________________________________________
###
@C.url_dispatcher.register(PLAY_MODE, ['icon_label','url'], ['channel', 'program_name', 'icon', 'playmode_string', 'play_profile','download', 'testmode'])
def play( icon_label
         ,url
         ,channel=u''
         ,program_name=u''
         ,icon=None
         ,playmode_string=None
         ,play_profile=None
         ,download=None
         ,testmode=False):
    Log(u"icon_label='{}',playmode_string='{}',play_profile='{}',url='{}',channel='{}',icon_URI='{}', download='{}'".format(
        icon_label,playmode_string,play_profile,url,channel,icon,download)
        #,C.LOGNONE
        )


    download = bool(download)
    testmode = bool(testmode)

    try:
        #
        #various download options
        #
        download_filespec = None
        if download:
            dt = datetime.datetime.now().strftime('%Y-%m-%d')
            d_name = u"{}.{}.{}.ts".format(utils.Clean_Filename(icon_label), utils.Clean_Filename(icon_label).strip(' '), dt)
            download_filespec = utils.get_setting('download_path')
            if not download_filespec:
                download_filespec = None
            else:
                download_filespec = os.path.join(download_filespec, d_name)
        #
        #f4mproxy defaults
        #
        if not playmode_string: playmode_string = DEFAULT_PLAYMODE
        if playmode_string not in C.PLAYMODE_F4MPROXY: play_profile = None
        if play_profile not in C.VALID_PLAYMODE_PROFILES: play_profile = DEFAULT_PLAY_PROFILE


##        channel = '919'   #testing this channel
##        channel = '766'   #testing this channel
##        channel = '300'   #testing this channel
        
        headers = {
                   "Referer" : BASE
                  ,"Accept-Encoding":"gzip, deflate"
                    ,"User-Agent":C.USER_AGENT#'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
                  }
        post_link = '{}stream/stream-{}.php'.format(
            BASE
            ,channel
            )                                                                                  

        Log(post_link)
        hint_0_src = utils.getHtml(post_link, headers=headers)

        m3u8_url= None


        resolve_method_name = "2025-05-30 method"
        if not m3u8_url: 
            C.DEBUG = True
            try:
                
                try:
                    regex = '<iframe.+?src="(.+?)"'
##                    regex = '<iframe.+?src="(https://(?:vidembed.re|veplay.top)/stream/(.+?))"'
                    next_link = re.findall(regex, hint_0_src)[0]
                    LogR(next_link)
                    next_uuid = next_link.split('/')[-1]
                    hint_1_src = utils.getHtml(next_link, headers=headers)
                except:
                    traceback.print_exc()
                    hint_1_src = hint_0_src
                        


                regex = 'src="(https://(?:vidembed.re|veplay.top)/stream/(.+?))"'
                next_link = re.findall(regex, hint_1_src)
                if next_link:
                    next_link=next_link[0]
                    next_uuid = next_link[1]
                    next_link = next_link[0]
                    post_json_url = next_link
                    LogR(next_link)
                    LogR(next_uuid)
                    hint_2_src = utils.getHtml(next_link, headers=headers)                
                    regex = 'event-ve="(a30dc10ede003d85fa1b54cc7f4ccf7b)"'
                    event_ve = re.findall(regex, hint_2_src)
                else:
                    LogR(("unabled to find 'next_link' with re ", regex))
                    Log('look for information in current file')
                    regex = r'event-ve="(.+?)"'
                    event_ve = re.findall(regex, hint_1_src)
                    LogR(event_ve)
                    post_json_url = "https://veplay.top/stream/{}".format(next_uuid)

                Log(next_uuid)

                
                post_link = 'https://www.vidembed.re/api/source/{}?type=live'.format(next_uuid)
                post_json = (
                    '{'
                    '"r":"https://daddylive.dad/"'
                    ',"d":"www.vidembed.re"'
                    '}'
                    )
                headers = {
                    'Connection': 'keep-alive'
                    ,'sec-ch-ua-platform': '"Windows"'
                    ,'sec-ch-ua': '"Chromium";v="136", "Microsoft Edge";v="136", "Not.A/Brand";v="99"'
                    ,'sec-ch-ua-mobile': '?0'
                    ,'X-Requested-With': 'XMLHttpRequest'
                    ,'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0'
                    ,'Accept': 'application/json, text/javascript, */*; q=0.01'
                    ,'DNT': '1'
                    ,'Content-Type': 'application/json'
                    ,'Origin': 'https://www.vidembed.re'
                    ,'Sec-Fetch-Site': 'same-origin'
                    ,'Sec-Fetch-Mode': 'cors'
                    ,'Sec-Fetch-Dest': 'empty'
                    ,'Sec-Fetch-Storage-Access': 'active'
                    ,'Referer': 'https://www.vidembed.re/stream/' + next_uuid
                    ,'Accept-Encoding': 'gzip, deflate'
                    ,'Accept-Language': 'en-US,en;q=0.9'
                    }
                hint_2_src = utils.postHtml(post_link, sent_data=post_json, headers=headers)
                
                source_file = json.loads(hint_2_src)['player']['source_file']
                Log(source_file)
                
                post_link_2 = 'https://p.vidembed.re/api/event'
                headers = {
                    'Connection': 'keep-alive'
                    ,'sec-ch-ua-platform': '"Windows"'
                    ,'sec-ch-ua': '"Chromium";v="136", "Microsoft Edge";v="136", "Not.A/Brand";v="99"'
                    ,'sec-ch-ua-mobile': '?0'
                    ,'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0'
                    ,'Accept': '*/*'
                    ,'DNT': '1'
                    ,'Content-Type': 'text/plain'
                    ,'Origin': 'https://www.vidembed.re'
                    ,'Sec-Fetch-Site': 'same-site'
                    ,'Sec-Fetch-Mode': 'cors'
                    ,'Sec-Fetch-Dest': 'empty'
                    ,'Referer': 'https://www.vidembed.re/'
                    ,'Accept-Encoding': 'gzip, deflate'
                    ,'Accept-Language': 'en-US,en;q=0.9'
                    }
                post_json = { 
                     "p":{
                         "ve": event_ve
                           }
                     ,"r":"https://daddylive.dad/"
                     ,"d":"vidembed.re"
                     ,"u": post_json_url
                     ,"n":"pageview"
                     }
                post_info = json.dumps(post_json)
                Log(post_info)
                api_src = utils.postHtml(post_link_2, sent_data=post_info, headers=headers)

                headers = {
                    'Connection':'keep-alive'
                    ,'sec-ch-ua-platform':'"Windows"'
                    ,'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0'
                    ,'sec-ch-ua':'"Chromium";v="136", "Microsoft Edge";v="136", "Not.A/Brand";v="99"'
                    ,'DNT':'1'
                    ,'sec-ch-ua-mobile':'?0'
                    ,'Accept':'*/*'
                    ,'Origin':'https://www.vidembed.re'
                    ,'Sec-Fetch-Site':'cross-site'
                    ,'Sec-Fetch-Mode':'cors'
                    ,'Sec-Fetch-Dest':'empty'
                    ,'Referer':'https://www.vidembed.re/'
                    ,'Accept-Encoding':'gzip, deflate'
                    ,'Accept-Language':'en-US,en;q=0.9'
                          }
                m3u8_url = source_file
                
            except:
                Log("failed " + resolve_method_name)
                traceback.print_exc()
##                raise

        resolve_method_name = "2025-06-01 method"
        if not m3u8_url:  #2025-06-01 method
            try:  
                current_referer = re.findall('iframe.+?src="([^"]*)', hint_0_src)
                if current_referer: current_referer=current_referer[0]
                LogR(current_referer)
                current_referer_urlparse = C.urlparse.urlparse(current_referer)
                LogR(current_referer_urlparse)
                self_referer = current_referer_urlparse.scheme+'://'+current_referer_urlparse.netloc
                LogR(self_referer)
                post_link_2 = current_referer
                Log(post_link_2)
                hint_2_src = utils.getHtml(post_link_2, headers=headers)
                
                channel_key = re.findall('var channelKey = "([^"]*)',hint_2_src)[0]
                Log(channel_key)
                stream_id = '/server_lookup.php?channel_id='
                post_link_3 = self_referer + stream_id + channel_key
                LogR(post_link_3)
                hint_3_src = utils.getHtml(post_link_3, headers=headers)
                try:
                    server_key = ''
                    
                    server_key = re.findall(':"([^"]*)',hint_3_src)[0]
                except:
                    LogR(hint_3_src)
                LogR(server_key)
                m3u8_name = '/mono.m3u8'#re.findall('(\/mono\.m3u8)'',hint_2_src)
                server_name = re.findall('var m3u8.+?\+ sk \+ "(.+?)"', hint_2_src, re.DOTALL | re.IGNORECASE )[0]
                LogR(server_name)

                authTs  = re.findall('var authTs  \s+= "(.+?)"',hint_2_src)[0]
                authRnd = re.findall('var authRnd \s+= "(.+?)"',hint_2_src)[0]
                authSig = re.findall('var authSig \s+= "(.+?)"',hint_2_src)[0]
                enable_key_url = "https://top2new.newkso.ru/auth.php?channel_id={}&ts={}&rnd={}&sig={}".format(
                    channel_key
                    ,authTs
                    ,authRnd
                    ,authSig
                    )
                Log(enable_key_url)
                headers={
                    'Accept':'*/*'
                    ,'Accept-Language':'en-US,en;q=0.5'
                    ,'Accept-Encoding':'gzip, deflate'
                    ,'Origin': self_referer.strip("/")
                    ,'DNT':'1'
                    ,'Sec-GPC': '1'
                    ,'Connection':'keep-alive'
                    ,'Referer':self_referer
                    ,'Sec-Fetch-Dest':'empty'
                    ,'Sec-Fetch-Mode':'cors'
                    ,'Sec-Fetch-Site':'cross-site'
                    ,'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0'
                    }
                misc = utils.getHtml(enable_key_url, headers=headers)
                LogR(misc)
##var player;
##var channelKey = "premium766";
##var authTs     = "1748633445";
##var authRnd    = "862facdb";
##var authSig    = "1106c5f81a85b3288a42dd5d4445ebf650ad10b5ebb76da6b5c5f404cd81bc1d";
##https://top2new.newkso.ru/auth.php?channel_id=premium766
##                &ts=1748633445&rnd=862facdb
##                &sig=1106c5f81a85b3288a42dd5d4445ebf650ad10b5ebb76da6b5c5f404cd81bc1d
##fetchWithRetry(
##  'https://top2new.newkso.ru/auth.php?channel_id='+channelKey+
##  '&ts=' + authTs +
##  '&rnd=' + authRnd +
##  '&sig=' + encodeURIComponent(authSig),
##  3, 1000
##).then(function(){
##  return fetchWithRetry(
##    '/s php?channel_id=' + encodeURIComponent(channelKey),
##    3, 1000
    
                m3u8_url= 'https://{server_key}{server_name}{server_key}/{channel_key}{m3u8_name}'.format(
                    server_key=server_key
                    ,server_name=server_name
                    ,channel_key=channel_key
                    ,m3u8_name=m3u8_name
                    )

            except:
                Log("failed " + resolve_method_name)
##                traceback.print_exc()
                raise
            

        if not m3u8_url:  #2025-02 method
            try:  
                current_referer = re.findall('iframe src="([^"]*)', hint_1_src)
                if current_referer: current_referer=current_referer[0]
                current_referer_urlparse = C.urlparse.urlparse(current_referer)
                LogR(current_referer)
                self_referer = current_referer_urlparse.scheme+'://'+current_referer_urlparse.netloc

                post_link_2 = current_referer
                Log(post_link_2)
                hint_2_src = utils.getHtml(post_link_2, headers=headers)

                channel_key = re.findall('var channelKey = "([^"]*)',hint_2_src)[0]
                stream_id = '/server_lookup.php?channel_id='
                post_link_3 = self_referer + stream_id + channel_key
                LogR(post_link_3)
                hint_3_src = utils.getHtml(post_link_3, headers=headers)
                server_key = re.findall(':"([^"]*)',hint_3_src)[0]
                LogR(server_key) #'ddy6')
                m3u8_name = '/mono.m3u8'#re.findall('(\/mono\.m3u8)'',hint_2_src)
                #server_name = re.findall('var m3u8Url.+? \+ serverKey \+ "(.+?)"', hint_2_src, re.DOTALL | re.IGNORECASE )
                server_name = re.findall('var m3u8.+?\+ sk \+ "(.+?)"', hint_2_src, re.DOTALL | re.IGNORECASE )[0]
                LogR(server_name)
                m3u8_url= 'https://{server_key}{server_name}{server_key}/{channel_key}{m3u8_name}'.format(
                    server_key=server_key
                    ,server_name=server_name
                    ,channel_key=channel_key
                    ,m3u8_name=m3u8_name
                    )
            except:
                traceback.print_exc()
                raise


##        test_poke = utils.getHtml(m3u8_url, headers=headers)
        video_url = m3u8_url + utils.Header2pipestring(headers)

        LogR(m3u8_url)
        
        play_label = "Channel {}".format(
             channel
             )
        #
        #what to do if we are just testing
        #
        testmode=True
        testmode=False
        if testmode:
            Log(repr(( "warning TESTMODE:"
                        ,video_url
                        , play_label
                        , playmode_string
                        , play_profile
                        , download
                        , download_filespec
                      )))
            utils.endOfDirectory(end_directory=True)
            raise Exception('logflush')
            return
        


        
        player.playvid(
            video_url
            , name=play_label
            , playmode_string=playmode_string
            , play_profile=play_profile
            , mimetype = 'application/vnd.apple.mpegurl'
            , download=download
            , download_filespec=download_filespec
            , skip_head = True
        )

    except:
        traceback.print_exc()
        

#__________________________________________________________________________
# Unit tests
@C.url_dispatcher.register(TEST_MODE)
def TEST_MODE():
    test_label = ""
    module_name = __name__.split('.')[-1]
    try:


        test_label='list only rows in Soccer'
        Add_Icons_Rows(filter_category = u'Soccer</span>'
                       , testmode = False
                       , end_directory = False
                       )
##        raise Exception('logflush')
    
        test_label='add channel 22 and call it TVO ü'
        playable_url = add_icons(
                   subchannel = u'767'
                  , subchannel_label = u'chanel 767 strangecahr ü'
                  , sort_order = None
                  , testmode = False
                  )
##        raise Exception('logflush')

        test_label='download html and add only the category folder soccer; label will not matter because this is a folder'
        add_icons(
                   subchannel = u'Soccer'
                  , subchannel_label = u'SoccerüSoccerü'
                  , sort_order = None
                  , testmode = True
                  )
        test_label='download html and add all categories'
        add_icons(
                   subchannel = u''
                  , subchannel_label = u''
                  , sort_order = None
                  , testmode = True
                  )

##        raise Exception('logflush')

        test_label='list only rows in Baseball'
        Add_Icons_Rows(filter_category = u'Baseball'
                       , testmode = False
                       , end_directory = False
                       )

        test_label='list only rows in Hockey'
        Add_Icons_Rows(filter_category = u'Hockey'
                       , testmode = False
                       , end_directory=False
                       )

        test_label='download ch 720'
        play(
             url =  playable_url
             , icon_label = test_label
             , channel =  u'{}'.format('720')
             , download = True
             , testmode = False
             )

    except:
        traceback.print_exc()
        raise Exception(test_label)
                                
#__________________________________________________________________________
#

