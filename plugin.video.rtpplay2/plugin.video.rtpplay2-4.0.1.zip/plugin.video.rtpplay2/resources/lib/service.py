from utils import Log
from utils import LogR

import json
import os
import os.path
import random
import sys
import threading
import traceback
import xbmc

##import importlib
##from importlib import reload as reload

import constants as C
from constants import SocketServer
from constants import reload
import plugin
import utils
from utils import Sleep as Sleep
from utils import get_setting as GetSetting
from utils import set_setting as SetSetting
from utils import select_unused_port as select_unused_port

# server defaults

##import AES_key_proxy


monitor = xbmc.Monitor()

#__________________________________________________________________________
#
class EndingException(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)
###__________________________________________________________________
###
##def recording_service(stop_event):
##    try:
##        while not monitor.abortRequested():
##            sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
##            if sleeptime < 1: sleeptime = 1
##            Log("{} monitor sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
##            if monitor.waitForAbort(sleeptime):
##                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
##            if stop_event.isSet():
##                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
##            if GetSetting("enable_recording_service", bool):
##                downloader.scan_and_start_db()
##    except EndingException as ex:
####        traceback.print_exc()
##        Log(ex.value)
##    except:
##        traceback.print_exc()

#__________________________________________________________________
#
def download_service(stop_event):

    import downloadServer
    try:
        download_proxy = None
        while not monitor.abortRequested():
            if stop_event.isSet():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_download_service", bool):
                if not download_proxy:
                    Log("starting download_proxy", C.LOGNONE)
                    reload(downloadServer) #reload during development so that I dont have to restart program
                    download_proxy = downloadServer.StartListening()
                else:
                    if download_proxy._BaseServer__shutdown_request:
                        Log('internal download_proxy forcestop')
                        download_proxy.server_close()
                        Log('internal download_proxy server_close')
                        download_proxy.socket.close()
                        Log('internal download_proxy close')
                        download_proxy = None
                    if GetSetting("keepalive_download_service", bool):
                        active_threads = utils.postHtml("http://localhost:{}/".format(GetSetting("download_server_port_current", int))
                                   ,sent_data= json.dumps({
                                      downloader.ATTRIB_cmd: downloader.CMD_list
                                       })
                                   ,headers={
                                       'Content-Type': 'application/json'
                                       }
                                   )
                        Log(repr(active_threads))
                        
                    pass
            else:
                if download_proxy or download_proxy._BaseServer__shutdown_request:
                    download_proxy.shutdown()
                    download_proxy.server_close()
                    download_proxy.socket.close()
                    Log('download_proxy stopped')
                    download_proxy = None
            sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
            if sleeptime < 1: sleeptime = 1
            Log("{} monitor sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
    except EndingException as ex:
##        traceback.print_exc()
        Log(ex.value)
    except:
        traceback.print_exc()
    finally:
        try:
            if download_proxy:
                download_proxy.shutdown()
                download_proxy.server_close()
                download_proxy.socket.close()
                Log('Finally download_proxy stopped')
                download_proxy = None
        except:
            traceback.print_exc()

###__________________________________________________________________
###
##def network_is_online(stop_event):
##    sleeptime = C.SERVICE_FIRST_SLEEPTIME
##    if monitor.waitForAbort(int(sleeptime)):
##        Log("{} ending due to abort".format(threading.current_thread().name))
##        return
##
##    try:
##        while not monitor.abortRequested():
##            if stop_event.isSet():
##                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
##            if GetSetting("reboot_required_detection", bool):
##                if C.DEBUG: reload(reboot_detection) #during dev, convenient to force a recompile
##                reboot_detection.reboot_required_detection()
##            sleeptime1 = random.randint(GetSetting("min_service_interval", int), GetSetting("min_service_interval", int)*5) #sleep betwen X and 5X seconds
##            sleeptime = max(sleeptime1, GetSetting("min_service_interval", int) )
####            sleeptime = C.SERVICE_FIRST_SLEEPTIME; Log("Warning: simulating result during a dev test")
##            if sleeptime < 1: sleeptime = 1
##            Log("{} sleeping {} seconds before next action [not {}]".format(repr(threading.current_thread().name), sleeptime, sleeptime1) ) #heartbeat logging
##            if monitor.waitForAbort(sleeptime):
##                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
##    except EndingException as ex:
##        Log(ex.value)
##    except:
##        traceback.print_exc()


###__________________________________________________________________
###
##def AES_key_service(stop_event):
##
##    import SocketServer
##    import AES_key_proxy
##
##    try:
##        proxy_AES_key_service = None
##        while not monitor.abortRequested():
##            if stop_event.isSet():
##                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
##            if GetSetting("enable_download_service", bool):
##                if not proxy_AES_key_service:
##                    Log("starting proxy_AES_key_service", utils.LOGNONE)
##                    reload(AES_key_proxy) #reload during development so that I dont have to restart program
##                    proxy_AES_key_service = downloadServer.StartListening()
##                else:
##                    if proxy_AES_key_service._BaseServer__shutdown_request:
##                        Log('internal download_proxy forcestop')
##                        proxy_AES_key_service.server_close()
##                        Log('internal download_proxy server_close')
##                        proxy_AES_key_service.socket.close()
##                        Log('internal download_proxy close')
##                        proxy_AES_key_service = None
##                     pass
##            else:
##                if proxy_AES_key_service or proxy_AES_key_service._BaseServer__shutdown_request:
##                    proxy_AES_key_service.shutdown()
##                    proxy_AES_key_service.server_close()
##                    proxy_AES_key_service.socket.close()
##                    Log('proxy_AES_key_service stopped')
##                    proxy_AES_key_service = None
##            sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
##            if sleeptime < 1: sleeptime = 1
##            Log("{} monitor sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
##            if monitor.waitForAbort(sleeptime):
##                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
##    except EndingException as ex:
####        traceback.print_exc()
##        Log(ex.value)
##    except:
##        traceback.print_exc()
##    finally:
##        try:
##            if proxy_AES_key_service:
##                proxy_AES_key_service.shutdown()
##                proxy_AES_key_service.server_close()
##                proxy_AES_key_service.socket.close()
##                Log('Finally download_proxy stopped')
##                proxy_AES_key_service = None
##        except:
##            traceback.print_exc()
    
#__________________________________________________________________
#
def link_crawler(stop_event):
    sleeptime = int(GetSetting("min_service_interval", int))
    if monitor.waitForAbort(int(sleeptime)):
        Log("{} ending due to abort".format(threading.current_thread().name))
        return
    
    try:
        while not monitor.abortRequested():
            if stop_event.isSet():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_link_crawler", bool):
                plugin.index(create_icons=False)
            sleeptime1 = int(GetSetting("service_periodic_interval", int) * (random.random()))
            sleeptime = max(sleeptime1, GetSetting("min_service_interval", int) )
            if sleeptime < 1: sleeptime = 1
            Log("{} sleeping {} seconds before next action [not{}]".format(threading.current_thread().name, sleeptime, sleeptime1) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
    except EndingException as ex:
        Log(ex.value)
    except:
        traceback.print_exc()
#__________________________________________________________________
#
if __name__ == '__main__':


    C.DEBUG = GetSetting('debug')
    threading.current_thread().name = C.addon_id+".service"

##    proxy_thread_recording_service = None
##    recording_service_stop_event = None

    proxy_thread_download_service = None    
    download_service_stop_event = None

    proxy_AES_key_service = None    
    AES_key_stop_event = None

    proxy_thread_crawler = None
    crawler_stop_event = None

##    proxy_reboot_required_detection = None
##    reboot_required_detection_stop_event = None

    while not monitor.abortRequested():

        try:
            # start thread for link_crawler service
            if GetSetting("enable_link_crawler", bool):
                try:        
                    if (not proxy_thread_crawler) or (not proxy_thread_crawler.is_alive()) : 
                        crawler_stop_event = threading.Event()
                        proxy_thread_crawler = threading.Thread(
                            target=link_crawler
                            ,args=(crawler_stop_event,)
                            ,name=C.addon_id+".link_crawler"
                            )
                        proxy_thread_crawler.daemon = True
                        proxy_thread_crawler.start()
                    else:
                        pass
                except:
                    traceback.print_exc()
            else:
                if proxy_thread_crawler:
                    if crawler_stop_event: crawler_stop_event.set()
                    proxy_thread_crawler = None


##            # start thread for AES_key_service
##            if False and GetSetting("AES_key_service", bool):
##                try:
##
##                    SocketServer.TCPServer.allow_reuse_address = True
##
##                    if (not proxy_AES_key_service) or (not proxy_AES_key_service.is_alive()) : # start thread
##
##                        # pick & store a port for the proxy service
##                        AES_key_service_port = GetSetting("AES_key_service_port", int)
##                        if not AES_key_service_port > 8000:
##                            AES_key_service_port = select_unused_port()
##                            Log("AES_key_service_port service port selected as '{0}'".format(str(AES_key_service_port)))
##                        else:
##                            Log("Static AES_key_service_port selected as '{0}'".format(str(AES_key_service_port)))
##                        SetSetting("AES_key_service_port_current", AES_key_service_port)
##
##                        reload(AES_key_proxy) #reload during development so that I dont have to restart program
##
##                        # configure the proxy server
##                        wv_proxy = SocketServer.TCPServer(
##                            ('127.0.0.1', AES_key_service_port)
##                            , AES_key_proxy.AES_key_proxy
##                            )
##                        wv_proxy.server_activate()
##                        wv_proxy.timeout = 1
##
##                        AES_key_stop_event = threading.Event()
##                        proxy_AES_key_service = threading.Thread(
##                            target=wv_proxy.serve_forever
##                            ,name=C.addon_id+".AES_key_service"
##                            )
##                        proxy_AES_key_service.daemon = True
##                        proxy_AES_key_service.start()
##                    else:
##                        reload(AES_key_proxy) #reload during development so that I dont have to restart program
##                except:
##                    traceback.print_exc()
##            else:
##                if proxy_AES_key_service:
##                    if AES_key_stop_event: AES_key_stop_event.set()
##                    proxy_AES_key_service = None
##                    wv_proxy.shutdown()

            # start thread for enable_download_service service
            if GetSetting("enable_download_service", bool):
                try:
                    if (not proxy_thread_download_service) or (not proxy_thread_download_service.is_alive()) : # start thread
                        download_service_stop_event = threading.Event()
                        proxy_thread_download_service = threading.Thread(
                            target=download_service
                            ,args=(download_service_stop_event,)
                            ,name=C.addon_id+".download_service"
                            )
                        proxy_thread_download_service.daemon = True
                        proxy_thread_download_service.start()
                    else:
                        pass
                except:
                    traceback.print_exc()
            else:
                if proxy_thread_download_service:
                    if download_service_stop_event: download_service_stop_event.set()
                    proxy_thread_download_service = None

        except:
            traceback.print_exc()

        ## sleep then ... do some work
        sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
        if sleeptime < 1: sleeptime = 1
        if monitor.waitForAbort(sleeptime):
            Log("{} ending due to abort".format(threading.current_thread().name))
            break

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = GetSetting('debug')

    if proxy_thread_crawler:
        if crawler_stop_event: crawler_stop_event.set()
##    if proxy_AES_key_service:
##        if AES_key_stop_event: AES_key_stop_event.set()
##        if wv_proxy: wv_proxy.shutdown()
        
##    if proxy_thread_recording_service:
##        if recording_service_stop_event: recording_service_stop_event.set()
    if proxy_thread_download_service:
        if download_service_stop_event: download_service_stop_event.set()
##    if proxy_reboot_required_detection:
##        if reboot_required_detection_stop_event: reboot_required_detection_stop_event.set()
        
#__________________________________________________________________
#
