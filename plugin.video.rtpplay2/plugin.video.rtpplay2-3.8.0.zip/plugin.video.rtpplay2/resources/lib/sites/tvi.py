# -*- coding: utf-8 -*-

#import base libraries
import json
import re
import threading 
import traceback
import xbmc
#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

TVI_BASE = "https://tviplayer.iol.pt"
CHANNEL_LIST = { "CNN" , "TVI", "TVI_INTERNACIONAL"} #, "TVI_DIRECT"}

#__________________________________________________________________________
#
def add_icons(plugin, play):

    sub_url = "/direto/"
    sorting_delta = 0.0
    sorting_base = 1.0

    #pre-cache the html data using threads
    worker_threads = []
    try:
        for channel in CHANNEL_LIST:
            worker = threading.Thread(name=channel
                                          ,target=utils.getHtml
                                          ,args=(TVI_BASE + sub_url + channel
                                                 ,
                                                )
                                  )
            worker.daemon = True
            worker_threads.append(worker)
            worker.start()

        max_cycles = 100 #multiply by cycle_sleep/1000 for seconds_to_wait_for_search
        cycle_sleep = 100 #milliseconds
        cur_time = 0
        still_working = True
        while still_working and (cur_time < max_cycles) :
            cur_time += 1
            utils.Sleep(cycle_sleep)
            still_working = False
            for worker in worker_threads:
                if worker.is_alive():
                    still_working = True
                    break #keep waiting for active task
        if (cur_time >= max_cycles):
            Log('lookup threads timeout')
    except:
        traceback.print_exc()
        

    #use cached HTML to create icons
    for channel in CHANNEL_LIST:

        html_src = utils.getHtml(TVI_BASE + sub_url + channel)
        regex = "jsonData = (.+?});"
        html_text = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html_src) #.text.encode("ascii", "ignore"))
        if not html_text: html_text = 'not found...error'
        
        json_info = json.loads(html_text[0])

        json_video_info = json_info["videoUrl"]
        final_url = json_video_info            
        program_name = json_info["program"]["name"]

        playlink_name = "[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
            C.channel_text_color
            , channel.encode('utf8')
            , C.program_text_color
            , program_name.encode('utf8')
            )

        sorting_delta = sorting_delta+0.1
        utils.addPlaylink(
            plugin
            ,playlink_name
            ,final_url
            ,program_name
            ,channel
            ,icon=json_info["cover"]
            ,play=play
            ,module_name=__name__.split('.')[-1]
            ,rating=sorting_base+sorting_delta #lower value is on top in sort ascending
            ,return_json_info = True
            ,is_folder = False
            ,filter_category = ''
##            ,db_connection = db_connection
            )

#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile):
#Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(prog,playmode_string,play_profile,rel_url,channel,icon))

    tviheaders = {"Origin":"http://tviplayer.iol.pt"
                  ,"Referer":"http://tviplayer.iol.pt/direto"
                  ,"Accept-Encoding":"gzip"
                  ,"User-Agent":"Mozilla/13.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
                  }
    page_content = rel_url
    
    #2019-03-30 - ...and a second call to get a user id is required
    matrix_userId = utils.getHtml("https://services.iol.pt/matrix?userId=",headers=tviheaders)

    m3u8_url = page_content+"?wmsAuthSign="+matrix_userId

    name = "[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog)
    url = m3u8_url + utils.Header2pipestring(tviheaders)

    if not playmode_string:
        playmode_string = C.DEFAULT_PLAYMODE

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
    )

    return True
#__________________________________________________________________________
#
