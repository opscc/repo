# -*- coding: utf-8 -*-

#import base libraries
import json
import os
import re
import traceback
import urllib
import xbmc
#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

#__________________________________________________________________________
#
def add_icons(plugin,play):
    channel = "CMTV"
    prog = "CMTV"

    sorting_delta = 0.0
    sorting_base = 4.0

    playlink_name = "[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
        C.channel_text_color
         , kodiutils.smart_str(channel)
         , C.program_text_color
         , kodiutils.smart_str(prog)
        )

    
    utils.addPlaylink(
        plugin = plugin
        ,playlink_name = playlink_name
        ,final_url = C.EURONEWS_BASE
        ,program_name = prog
        ,channel = channel
        ,icon=os.path.join(C.imgDir, 'cmtv.png')
        ,play=play
        ,module_name=__name__.split('.')[-1]
        ,rating=sorting_base+sorting_delta #lower value is on top in sort ascending
        ,return_json_info = True
        ,is_folder = False
        ,filter_category = ''
        )
    

#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile):

    Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(
        prog,playmode_string,play_profile,rel_url,channel,icon))

    headers = {
               "Referer" : 'https://www.freeshot.live/' #2024-06-30
              }
    
    #find out what the current ID is for youtube-hosted content
    full_html = utils.getHtml("https://popcdn.day/play.php?stream=CMTVPT")

    regex = 'src="https://securednode.xyz/CMTVPT/embed.html(\?token=.+?)&'
    embed_token=re.compile(regex).findall(full_html)[0]
    m3u8_url = "https://securednode.xyz/CMTVPT/index.fmp4.m3u8" + embed_token
    Log(repr(m3u8_url))

    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog)
    url = m3u8_url + utils.Header2pipestring() 

    if not playmode_string:
        playmode_string = C.PLAYMODE_DIRECT

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
        #, skip_head = True
    )

    return True
#__________________________________________________________________________
#
