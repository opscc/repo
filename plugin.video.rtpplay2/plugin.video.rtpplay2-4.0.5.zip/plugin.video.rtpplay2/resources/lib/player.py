# -*- coding: utf-8 -*-

#import base libraries
import socket
import sys
import threading
import traceback
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
#import internal addon libraries
import utils
#define frequenctly used aliases
import constants as C
from constants import urlparse
from utils import Log,LogR
from utils import Notify

#__________________________________________________________________________
#
def playvid(
    video_url
    , name
    , download = None
    , description = u''
    , playmode_string = None
    , play_profile = None
    , download_filespec = None
    , mode = None #30
    , url_factory = None#''
    , icon_URI = None
    , repeat_when_available = False
    , sub_title_url = None
    , mimetype = None #"video/mp2t"
    , skip_head = False #should not request HEAD for some sites
    ):



    LogR(locals())
    try:

        xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen

##        socket.setdefaulttimeout(30.0)

        try:
            xx = (u"unicode crash tester name={}".format(name))
            xx = (u"unicode crash tester description={}".format(description))
        except UnicodeDecodeError:
            name =  name.decode('utf-8')
            description =  description.decode('utf-8')

        if video_url is None:
            raise Exception('null video_url')
        
        if len(video_url) > 2000:
            raise Exception("playvid not playing broken videourl".format(video_url[0:100]))
            return

        if download:
            import downloader
            downloader.downloadVideo(
                video_url
                , name
                , mode = mode
                , url_factory = url_factory
                , download_path = download_filespec
                , icon_URI = icon_URI
                , repeat_when_available = repeat_when_available
                )
            return

        
        #
        # play url as needed
        #
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        if C.xbmc_version[0] > 17 :
            listitem = xbmcgui.ListItem(
                label = name
                , path=video_url
                , offscreen=True #kodi 18+
                )
        else:
            listitem = xbmcgui.ListItem(
                label = name
                , path=video_url
    ##            , offscreen=True #kodi 18+
                )
        listitem.setArt( #setart because other method deprecated
                {
                    "icon" : "DefaultVideo.png"
                    , "thumb": iconimage
                }
            )

        if C.PY2:
            listitem.setInfo(
                'video'
                , infoLabels={
                    'title': name
                    ,"plot": description
                    ,"plotoutline": description
                    }
                )
        if C.PY3:
            infotag = listitem.getVideoInfoTag()
            infotag.setTitle(name)
            infotag.setPlot(description)
        
        if sub_title_url: listitem.setSubtitles([sub_title_url]) #todo, sub_title_url might already be a dict
        listitem.setContentLookup(False)
        if mimetype:
            listitem.setMimeType(mimetype)
        listitem.setProperty('IsPlayable', 'false') # true required if you want to track playcount
    #    listitem.setProperty('IsPlayable', 'true')
        

    
##        video_url = str(video_url.split('|')[0])
        
        d_type = None
        c_type = None
        try:
            if '|' in video_url:
                h = dict(urlparse.parse_qsl( str(video_url.split('|')[1])))
                u = str(video_url.split('|')[0])
            else:
                u=h=''
            LogR((h,video_url),C.LOGNONE)
            if not skip_head:
                resp = utils.getHtml(url=u, headers=h, send_back_response=True, method="HEAD")
                if resp:
                    if 'Content-Type' in resp.headers:
                        c_type = resp.headers['Content-Type'].lower()
                        if c_type in ['video/mp4'
                                      , 'application/octet-stream'
                                      , 'video/mp4, application/octet-stream'
                                      ]:
                            d_type = C.TYPE_mp4
                            listitem.setMimeType(c_type)
                        elif c_type in ['application/vnd.apple.mpegurl'
                                        ,'application/x-mpegurl'
                                        ,'text/plain; charset=utf-8'
                                        ]:
                            d_type = C.TYPE_hls
                            listitem.setMimeType(c_type)
                        else:
                            Log("Unknown content type '{}'".format(c_type), xbmc.LOGWARNING)
            else:
                c_type = mimetype
                if c_type in ['video/mp4'
                              , 'application/octet-stream'
                              , 'video/mp4, application/octet-stream'
                              ]:
                    d_type = C.TYPE_mp4
                    listitem.setMimeType(c_type)
                elif c_type in ['application/vnd.apple.mpegurl'
                                ,'application/x-mpegurl'
                                ]:
                    d_type = C.TYPE_hls
                    listitem.setMimeType(c_type)                
        except:
            traceback.print_exc()

        LogR((c_type,d_type))
        if not video_url == '' and not '|' in video_url:
            video_url = video_url + utils.Header2pipestring()
            pass
        Log("video_url='{}'".format(video_url) )


        if not(playmode_string == C.PLAYMODE_DIRECT) and (str(playmode_string) in ['None',''] or str(playmode_string).isdigit()):
            if d_type and d_type == C.TYPE_hls:
                playmode_string = C.DEFAULT_PLAYMODE
            elif d_type and d_type == C.TYPE_mp4:
                playmode_string = C.PLAYMODE_DIRECT
            elif (".m3u8" in str(video_url)):
                playmode_string = C.DEFAULT_PLAYMODE
            elif ("/hls/" in video_url) or ("hlsA/" in video_url):
                playmode_string = C.DEFAULT_PLAYMODE
            else:
                playmode_string = C.PLAYMODE_DIRECT
                
        if playmode_string == C.PLAYMODE_INPUTSTREAM:
            if not(d_type == C.TYPE_hls):
                Log('warning: override of INPUTSTREAM to DIRECT because header says not HLS')
                playmode_string = C.PLAYMODE_DIRECT

##        try:
##            xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
##            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
##        except:
##            traceback.print_exc()

        if playmode_string == C.PLAYMODE_DIRECT:
            pass

        elif playmode_string == C.PLAYMODE_F4MPROXY:

           #Log("play_profile='{}'".format(play_profile)  )

            if play_profile not in C.VALID_PLAYMODE_PROFILES:
                play_profile = C.DEFAULT_PROFILE_NAME

            initial_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "initial"))* 1000 * 1000)
            maximum_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "maximum"))* 1000 * 1000)
            allow_upscale = C.addon.getSetting(play_profile + "_" + "allow_upscale")
            allow_downscale = C.addon.getSetting(play_profile + "_" + "allow_downscale")
            always_refresh_m3u8 = C.addon.getSetting(play_profile + "_" + "always_refresh_m3u8")
            downscale_threshhold = C.addon.getSetting(play_profile + "_" + "downscale_threshhold")
            upscale_threshhold = C.addon.getSetting(play_profile + "_" + "upscale_threshhold")
            upscale_penalty = C.addon.getSetting(play_profile + "_" + "upscale_penalty")
            pre_cache_size_max = int(float(C.addon.getSetting(play_profile + "_" + "pre_cache_size_max"))* 1000 * 1000)
            stream_type = C.addon.getSetting(play_profile + "_" + "stream_type").upper()

            from F4mProxy import f4mProxyHelper
            
            f4mp=f4mProxyHelper()
            if not stream_type:
                stream_type = 'HLSRETRY'
            Log("stream_type='{}'".format(stream_type), C.LOGNONE  )



            #run in separate thread so that plugin can finish
            proxy_thread = threading.Thread(
                name="playF4mLink."#+Clean_Filename(video_url)
                ,target=f4mp.playF4mLink
                ,args=(
                        video_url
                        , name
                        , None #proxy = None
                        , False #use_proxy_for_chunks = False
                        , maximum_bitrate #maxbitrate = maximum_bitrate
                        , False #simpleDownloader = False
                        , None #auth = None
                        , stream_type #streamtype = stream_type
                        , False #setResolved = False
                        , None #swf = None
                        , "" #callbackpath = ""
                        , "" #callbackparam = ""
                        , iconimage #iconImage = iconimage
                        , None #title_info
                        , download_filespec
                        , initial_bitrate #initial_bitrate = initial_bitrate
                        , allow_upscale #allow_upscale = allow_upscale
                        , allow_downscale #allow_downscale = allow_downscale
                        , always_refresh_m3u8 #always_refresh_m3u8 = always_refresh_m3u8
                        , downscale_threshhold #downscale_threshhold = downscale_threshhold
                        , upscale_threshhold #upscale_threshhold = upscale_threshhold
                        , upscale_penalty #upscale_penalty = upscale_penalty
                        , pre_cache_size_max #pre_cache_size_max = pre_cache_size_max
                        , description #description = description
                    )
                )
            proxy_thread.daemon = True
            proxy_thread.start()

            if C.addon_handle > 0:
                listitem.setProperty('IsPlayable', 'false')
                # setResolvedUrl set to help out skin helper service
                # False returned because playvid is using an alt player and kodi should
                # not use the url within listitem to play the vid
                # Race conditions can create an error log message...but best I can do for now
                xbmcplugin.setResolvedUrl(C.addon_handle, False, listitem) 
##                Log("ee WARNING setresolvedurl {}".format(repr(video_url)),C.LOGNONE)
            else:
##                Log("ERROR NO HANDLE for setresolvedurl {}".format(repr(video_url)),C.LOGNONE)
                pass

            Log('returning after starting fmproxy thread')
            return
        
        elif playmode_string == C.PLAYMODE_INPUTSTREAM :
            
            video_url = video_url.replace('&Accept=%2A%2F%2A', '')
            video_url = video_url.replace('&Accept-Encoding=gzip', '')

            try:
                test = xbmcaddon.Addon(id='inputstream.adaptive')
            except:
                traceback.print_exc()
                Notify('make sure inputstream is Enabled')

            try:
                stream_headers = video_url.split('|')[1]
                #delete create so that I can get sorted headers
                if C.PY3: video_url = video_url.split('|')[0]  #inputstream v21.5.10 requires this
##                if C.PY2: video_url = video_url + "|" + s_h    #inputstream v2.4.8   requires this
            except:
                traceback.print_exc()
                stream_headers = ''

            LogR(stream_headers)
            s_h = C.urlparse.parse_qsl(stream_headers)
            LogR(s_h)
            s_h = C.urlencode(s_h)
            LogR(s_h)

            #2025-03-12 - after much trial an error; found that I have to recreate listitem
                # for inputstream to pass headers to license key server [and not setPath]
            Log(video_url)
            listitem = xbmcgui.ListItem(
                label = name
                , path=video_url
                )

            if C.PY2:
                listitem.setInfo(
                    'video'
                    , infoLabels={
                        'title': name
                        ,"plot": description
                        ,"plotoutline": description
                        }
                    )
            if C.PY3:
                infotag = listitem.getVideoInfoTag()
                infotag.setTitle(name)
                infotag.setPlot(description)
            
            
            if sub_title_url: listitem.setSubtitles([sub_title_url]) #todo, sub_title_url might already be a dict
            listitem.setContentLookup(False)
            LogR(mimetype)
            if mimetype:
                listitem.setMimeType(mimetype)
            else:
                listitem.setMimeType('application/x-mpegURL')
                
            
            if C.PY2: listitem.setProperty('inputstreamaddon', 'inputstream.adaptive') #inputstream v2.4.8   requires this
            listitem.setProperty('KODIPROP:inputstream=inputstream.adaptive', 'inputstream.adaptive')
            listitem.setProperty('inputstream', 'inputstream.adaptive')


##            #2024-12  using this proxy because if m3u8 file has an AES key url,
              #   inputstream will not include all the stream headers in the AES key request.
              #   May not be necessary in a future inputstream version
##            video_url = u'http://127.0.0.1:{}/'.format(get_setting("AES_key_service_port_current"))  + str(base64.b64encode(bytearray(video_url,'utf8')))
            if C.PY2: listitem.setProperty('inputstream.adaptive.manifest_type', 'hls') #inputstream v2.4.8   requires this
##            if C.PY3: listitem.setProperty('inputstream.adaptive.manifest_type', 'hls') #inputstream v2.4.8   requires this
            listitem.setProperty('inputstream.adaptive.stream_headers', stream_headers)
            listitem.setProperty('inputstream.adaptive.common_headers', stream_headers)            
            listitem.setProperty('inputstream.adaptive.manifest_headers', stream_headers)            

            #https://github.com/xbmc/inputstream.adaptive/wiki/Integration-DRM
##            listitem.setProperty('inputstream.adaptive.drm_legacy', 'none||'+s_h)
            
            Log("using inputstream")

        else:
            Log('Unknown playmode for link. Using direct')
            pass


#????with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
##        utils.LogFlush()
        if C.addon_handle > 0: #removed for now ith kodi 21
            Log('warning using setResolvedUrl',C.LOGNONE)
##            listitem.setProperty('IsPlayable', 'true')
##            listitem.setProperty('IsPlayable', 'false')
            #xbmcplugin.setResolvedUrl(C.addon_handle, True, listitem)
            xbmcplugin.setResolvedUrl(
                C.addon_handle
                , succeeded = True
                , listitem=listitem
                )
##            xbmcplugin.endOfDirectory(
##                C.addon_handle
##                , succeeded = True
##                , updateListing= False
##                )
        else:
            Log('warning using playlist',C.LOGNONE)
##            listitem.setProperty('IsPlayable', 'true')
            xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

            myPlayList.add( video_url, listitem)
            xbmc.Player().play(myPlayList)
##        utils.LogFlush()
    except:
##        traceback.print_exc()
        raise
    finally:
##        Log('error exiting',C.LOGNONE)
        pass
