# -*- coding: utf-8 -*-


#import base libraries
import base64
import datetime
import json
import os
import re
import time
import traceback
import urllib
import xbmc
import xbmcgui
import xbmcplugin

#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils




BASE = "https://daddylivehd.sx/"
BASE = "https://daddylive.sx/"
BASE = "https://dlhd.sx/"


CATEGORY_REGEX = (
    '<h2 style="background-color:cyan">'
    '(?P<category>.+?)(?:</?h2>|<div id="sidebar">)'
    '(?P<category_info>.+?)(?=<h2 |<div id="sidebar">|\\Z)'
    )

CHANNEL_INFO_REGEX = (
    '<hr>(?:<strong>|)(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)(?:</strong>|)\s*<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|<hr|<h2|<div id="sidebar">)'
    )
CHANNEL_INFO_REGEX = (
    '<hr>(?:<strong>|)(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)(?:</strong>|)\s*<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|</span>\s|<hr|<h2|<div id="sidebar">)'
    )

LINK_INFO_REGEX = (
    'href="(?P<link>.+?)"'
    '.+?rel="noopener">(?P<broadcaster>.+?)</a>'
    )

try: cache_duration = int(utils.get_setting('html_cache_sportsdaddy'))
except: cache_duration = 300

STREAM_REGION_01 = '<div class="box">(.+)</span>Backup Streams Of Soccer &amp; Other Events</h1>'
STREAM_REGION_01 = '<div class="box">(.+)<div id="sidebar">'


#__________________________________________________________________________
#
def add_icons(plugin, play, soccer_only=False):

    sorting_delta = 1.0
    sorting_base = 1000

    try:
##        https://dlhd.sx/schedule/schedule-generated.json
        
        json_src = utils.getHtml(BASE + 'schedule/schedule-generated.json'  , cache_duration=cache_duration)

        json_info = json.loads(json_src)
        time_range = int(utils.get_setting('time_range_sportsdaddy'))

        today = datetime.datetime.utcnow()
        schedule_time = today.utcnow() + datetime.timedelta(hours=-6) #convert from GMT+1 to EST

        for category in json_info[json_info.keys()[0]]: #first item is a date which we can skip

            #skip categories with no entries
            if len(json_info[json_info.keys()[0]][category]) < 1:
                pass
            else:
                #add a sub menu for the item
                category_name = u"[B][COLOR {}]{}[/B][/COLOR]{}".format(
                    C.refresh_text_color
                    , category 
                    , '' 
                    )
                
                sorting_base += sorting_delta
                rating = sorting_base

                plugin_url = plugin.url_for(
                        play
                        , filter_category=category
                        , rel_url = category
                        , channel = category
                        , prog = category
                        , img = ''
                        , module_name = __name__.split('.')[-1]
                        )

                utils.addPlaylink(
                    plugin
                    ,playlink_name = category_name
                    ,final_url = plugin_url
                    ,program_name = category
                    ,channel = category
                    ,icon = os.path.join(C.imgDir, category+'.png')
                    ,play = play
                    ,module_name = __name__.split('.')[-1]
                    ,rating = rating
                    ,return_json_info = True
                    ,is_folder = True
                    ,filter_category = category
                    )

    except:
        traceback.print_exc()


#__________________________________________________________________________
#
def Add_Icons_Rows(plugin, play, filter_category):

    Log(repr(filter_category))

    json_urls = [
        BASE + 'schedule/schedule-generated.json'
        , BASE + 'schedule/schedule-extra-generated.json'
        ]
    try:
        for json_url in json_urls:

            json_src = utils.getHtml(json_url, cache_duration=cache_duration)
            json_info = json.loads(json_src)

            sorting_delta = 0
            sorting_base = 3
        
            for category in json_info[json_info.keys()[0]]: #first item is a date which we can skip

                if category != filter_category:
                    continue
                
                for event in json_info[json_info.keys()[0]][category]:

#>>> gg = u'Friday 29th December 2023'
#>>> time.strptime(gg + ' 03:30 GMT', '%A %d %B %Y %H:%M %Z')

                    try:
                        gmt_time = datetime.datetime.strptime( json_info.keys()[0].split(' - Schedule Time')[0] + event['time'], '%A %dth %B %Y%H:%M')
                    except:
                        gmt_time = datetime.datetime.strptime(  '12 12 2023'+ event['time'], '%d %m %Y%H:%M')
                        
                    schedule_time = gmt_time + datetime.timedelta(hours=-5) #convert from GMT+1
    
                    time_and_teams_name = u"  [COLOR {}]{}[/COLOR] [COLOR {}]{}[/COLOR]".format(
                         C.time_text_color
                        , schedule_time.strftime('%H:%M') #event['time']
                        , C.highlight_text_color
                        , event['event']
                        )

                    sorting_delta = sorting_delta + 1

                    list_item = xbmcgui.ListItem(
                        label=time_and_teams_name
                        )
                    rating = sorting_base+sorting_delta
                    list_item.setArt({"thumb":    os.path.join(C.imgDir, category+'.png')  })
                    list_item.setInfo(type="video"
                                      , infoLabels={
                                            "sorttitle": "a{:0>10}".format(int(rating))
                                            ,"playcount":"0" #remove the filled in circle from our skin
                                                   }
                                      )
                    xbmcplugin.addDirectoryItem(
                        handle=plugin.handle
                        , url=''
                        , listitem=list_item
                        , isFolder=True
                    )

                    for link in event[u'channels']:

                        if not link[u'channel_id']:
                            continue #sometimes there is a blank entry
                        
                        playlink_name = u"      [COLOR {}]{}[/COLOR]".format(
                            C.program_text_color
                            ,link[u'channel_name'] + ' channel ' + link[u'channel_id']
                            )
                        utils.addPlaylink(
                            plugin
                            ,playlink_name
                            ,link[u'channel_id']
                            ,time_and_teams_name #the program_name
                            ,channel='sportsdaddy'
                            ,icon= os.path.join(C.imgDir, category+'.png')
                            ,play=play
                            ,module_name=__name__.split('.')[-1]
                            ,rating=str(sorting_base+sorting_delta) #lower value is on top in sort ascending
                            ,return_json_info = False
                            ,is_folder = False
                            ,filter_category = ''
                            )
    
    except:
        traceback.print_exc()


    return

    html_src = utils.getHtml(BASE, cache_duration=cache_duration )

##    #for some reason site has duplicates; second seems better; my crappy way of filtering
##    html_src = html_src.split('<h2 style="background-color:cyan">Volleyball</h2>')[1]

    html_src = re.compile(STREAM_REGION_01, re.DOTALL | re.IGNORECASE).findall(html_src)[0]
    channels = re.compile(CATEGORY_REGEX, re.DOTALL | re.IGNORECASE).findall(html_src)
        
    time_range = int(utils.get_setting('time_range_sportsdaddy'))
    today = datetime.datetime.utcnow()
    schedule_time = today.utcnow() + datetime.timedelta(hours=-5) #convert from GMT+1

    sorting_delta = 0
    sorting_base = 3
    
    for category, channel_info in channels:

        channel_data = re.compile(CHANNEL_INFO_REGEX, re.DOTALL | re.IGNORECASE).findall(channel_info)

        if category.decode('ascii','ignore') != filter_category.decode('ascii','ignore'):
##            Log(repr((category,filter_category)))
            continue

        for hour, minute, team, links in channel_data:

##            Log(repr(channel_data))
        
            team = utils.cleantext(team)
            if '\\x' in team:
                team = team.decode('unicode-escape').encode('utf8')

            #adjust hour according to local TZ
            event_time = datetime.datetime(
                schedule_time.year
                ,schedule_time.month
                ,schedule_time.day
                ,hour=int(hour)
                ,minute=int(minute)
                )
            event_time_gmt = event_time + datetime.timedelta(hours=-1) #convert from GMT+1
            offset = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone
            tz_offset = offset / 60 / 60 * -1
            event_time_local = event_time_gmt + datetime.timedelta(hours=tz_offset)
            epoc_gmt = (event_time_gmt - datetime.datetime(1970, 1, 1)).total_seconds()
            epoc_local = (event_time_local - datetime.datetime(1970, 1, 1)).total_seconds()
            if (time_range < 0):
                Log(repr((epoc_local - epoc_gmt)/3600))
                Log(repr((epoc_gmt - epoc_local)/3600))
                if ((epoc_local - epoc_gmt ) < 0) : # in the future
                    
                    Log(u' keeping  {}:{} {}'.format(hour,minute,team))
                    pass
                else:

                    Log(u'skipping  {}:{} {}'.format(event_time.hour+tz_offset,event_time.minute,team))
                    continue


            link_data = re.compile(LINK_INFO_REGEX, re.DOTALL | re.IGNORECASE).findall(links)

            time_and_teams_name = u"  [COLOR {}]{:02}:{:02}[/COLOR] [COLOR {}]{}[/COLOR]".format(
                 C.time_text_color
                , event_time_local.hour #hour
                , event_time_local.minute #minute
                , C.highlight_text_color
                , team
                )

            
            if len(link_data) > 0:

                sorting_delta = sorting_delta + 1
                
                list_item = xbmcgui.ListItem(
                    label=time_and_teams_name
                    )
                rating = sorting_base+sorting_delta
                list_item.setArt({"thumb":    os.path.join(C.imgDir, category+'.png')  })
                list_item.setInfo(type="video", infoLabels={
                                                        "sorttitle": "a{:0>10}".format(int(rating))
                                                        ,"playcount":"0" #remove the filled in circle from our skin
                                                        })
        
                xbmcplugin.addDirectoryItem(
                    handle=plugin.handle
                    , url=''
                    , listitem=list_item
                    , isFolder=True
                )

                for link, broadcaster in link_data:

                    sorting_delta = sorting_delta + 1
                    
                    broadcaster = utils.cleantext(broadcaster)
                    if '\\x' in broadcaster:
                        broadcaster = broadcaster.decode('unicode-escape').encode('utf8')

                    playlink_name = u"      [COLOR {}]{}[/COLOR]".format(
                        C.program_text_color
                        ,broadcaster
                        )
                    utils.addPlaylink(
                        plugin
                        ,playlink_name
                        ,u"{}{}".format(time_and_teams_name, link)
                        ,time_and_teams_name #the program_name
                        ,channel='sportsdaddy'
                        ,icon= os.path.join(C.imgDir, category+'.png')
                        ,play=play
                        ,module_name=__name__.split('.')[-1]
                        ,rating=str(sorting_base+sorting_delta) #lower value is on top in sort ascending
                        ,return_json_info = False
                        ,is_folder = False
                        ,filter_category = ''
                        )

            

#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile):
    Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(
        prog,playmode_string,play_profile,rel_url,channel,icon))

##    Log(repr(rel_url))
    
    headers = {
              #"Referer":'https://bhqwplay.xyz/premiumtv/'
              "Referer":'https://weblivehdplay.ru/'  #2023-11-12
              ,'Accept': '*/*'
              ,"Accept-Encoding":"gzip,deflate"
              ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188"
              }

##    rel_url = '/stream-'+'722'+'.php'
    
##    if rel_url.startswith('/'): rel_url = rel_url.strip('/')
##    rel_url = rel_url.split("/stream-")[1].split('.php')[0]

##    import random
##    rel_url = random.randint(1,899)
                
    m3u8_url = "https://webudit.cdndac.lol/lb/premium{}/index.m3u8".format(rel_url) #pre 2023-09
    m3u8_url = "https://webudit.cdnbos.lol/lb/premium{}/index.m3u8".format(rel_url) #2023-09-04
    m3u8_url = "https://webudit.webdicdn.lol/lb/premium{}/index.m3u8".format(rel_url) #2023-09-09
    m3u8_url = "https://webudit.vipboxtv.stream/lb/premium{}/index.m3u8".format(rel_url) #2023-10-04
    m3u8_url = "https://webudit.hlsjs.ru/lb/premium{}/index.m3u8".format(rel_url) #2023-11-12
    m3u8_url = "https://webudit.webhd.ru/lb/premium{}/index.m3u8".format(rel_url) #2023-12-29
                
    name = "Channel {}".format(
         rel_url
         )


    url = m3u8_url + utils.Header2pipestring(headers)
    

    if not playmode_string:
        playmode_string = C.PLAYMODE_DIRECT

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
        #, skip_head = True
    )

    return True
#__________________________________________________________________________
#
