#-*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import urllib
import urllib2
import urllib3
import re
import cookielib
import os.path
import sys
import time, datetime
import sqlite3
import urlparse
from StringIO import StringIO
import gzip
import traceback
import threading
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import cloudflare

import constants as C

if sys.version_info >= (3, 0): from html.parser import HTMLParser
else: from HTMLParser import HTMLParser
html_parser = HTMLParser()

import requests
my_http_session = requests.Session()

#__________________________________________________________________________
#
def playvid(
    video_url
    , name
    , download = None
    , description = u''
    , playmode_string = None
    , play_profile = None
    , download_filespec = None
    ):

##    assert isinstance(name, unicode)
##    assert isinstance(description, unicode)
##    Log(u"name={}".format(name.decode('utf-8')))
    try:
        xx = (u"unicode crash tester name={}".format(name))
        xx = (u"unicode crash tester description={}".format(description))
    except UnicodeDecodeError:
        Log('UnicodeDecodeError')
        name =  name.decode('utf-8')
        description =  description.decode('utf-8')
    Log(u"playvid video_url='{}', name='{}', download='{}', description='{}', playmode_string='{}', play_profile='{}'".format(
            video_url
            , repr(name)
            , download
            , repr(description)
            , playmode_string
            , play_profile
            )
        )

##    return
    if video_url is None:
        return
    
    if len(video_url) > 2000:
        Log("playvid not playing broken videourl".format(video_url[0:100]) )
        return

    if download == 1:
        import downloader
        downloader.downloadVideo(video_url, name, download_path=download_filespec)
        return

    #
    # play url as needed
    #
    
    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(
        name
        , iconImage="DefaultVideo.png"
        , thumbnailImage=iconimage
        )
    listitem.setInfo(
        'video'
        , infoLabels={
            'title': name
            ,"plot": description
            ,"plotoutline": description
            }
        )
    listitem.setContentLookup(False)
    listitem.setMimeType('video/mp4')
    listitem.setProperty('IsPlayable', 'false')
    
##    Log("video_url='{}'".format(video_url))
    if not video_url == '' and not '|' in video_url:
        video_url = video_url + Header2pipestring()
        Log("video_url='{}'".format(video_url) )

##    Log("playmode_string='{}'".format(repr(playmode_string))  )
##    Log("play_profile='{}'".format(play_profile)  )

    if str(playmode_string) in ['None',''] or str(playmode_string).isdigit():
##        Log('here')
##        Log(repr(video_url))
##        Log(repr(".m3u8" in str(video_url)))
        if (".m3u8" in str(video_url)):
##            Log('m3u8')
            playmode_string = C.DEFAULT_PLAYMODE
        elif ("/hls/" in video_url):
##            Log('/hls/')
            playmode_string = C.DEFAULT_PLAYMODE
        else:
            Log('direct')
            playmode_string = C.PLAYMODE_DIRECT
            
    Log("playmode_string='{}'".format(playmode_string)  )

    if playmode_string == C.PLAYMODE_DIRECT:
        Log("direct video_url")
        pass

    elif playmode_string == C.PLAYMODE_F4MPROXY:

        Log("play_profile='{}'".format(play_profile)  )
##        if play_profile is None or play_profile == '' or str(play_profile).isdigit()::
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.DEFAULT_PROFILE_NAME

    
        Log("play_profile='{}'".format(play_profile)  )
        Log(C.addon.getSetting(play_profile + "_" + "initial"))

        initial_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "initial"))* 1000 * 1000)
        maximum_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "maximum"))* 1000 * 1000)
        allow_upscale = C.addon.getSetting(play_profile + "_" + "allow_upscale")
        allow_downscale = C.addon.getSetting(play_profile + "_" + "allow_downscale")
        always_refresh_m3u8 = C.addon.getSetting(play_profile + "_" + "always_refresh_m3u8")
        downscale_threshhold = C.addon.getSetting(play_profile + "_" + "downscale_threshhold")
        upscale_threshhold = C.addon.getSetting(play_profile + "_" + "upscale_threshhold")
        upscale_penalty = C.addon.getSetting(play_profile + "_" + "upscale_penalty")
        pre_cache_size_max = int(float(C.addon.getSetting(play_profile + "_" + "pre_cache_size_max"))* 1000 * 1000)

        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        streamtype = 'HLSRETRY'
##        streamtype = 'HLSREDIR'
        f4mp.playF4mLink(
            video_url
            , name
            , proxy = None
            , use_proxy_for_chunks = False
            , maxbitrate = maximum_bitrate
            , simpleDownloader = False
            , auth = None
            , streamtype = streamtype
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , iconImage = iconimage
            , initial_bitrate = initial_bitrate
            , allow_upscale = allow_upscale
            , allow_downscale = allow_downscale
            , always_refresh_m3u8 = always_refresh_m3u8
            , downscale_threshhold = downscale_threshhold
            , upscale_threshhold = upscale_threshhold
            , upscale_penalty = upscale_penalty
            , pre_cache_size_max = pre_cache_size_max
            , description = description
            )
        return
    
    elif playmode_string == C.PLAYMODE_INPUTSTREAM :
        listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        stream_headers = urllib.unquote_plus( video_url.split('|')[1])
        Log("stream_headers='{}'".format(stream_headers)  )
        listitem.setProperty('inputstream.adaptive.stream_headers', stream_headers)
        Log("using inputstream")
    else:
        Log('Unknown playmode for link. Using direct')

    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( video_url, listitem)
    xbmc.Player().play(myPlayList)

    return
#__________________________________________________________________________
#
######class Fake_Info(object):
######    def __init__(self, header_dict):
######        self.header_dict = header_dict
######    def getheaders(self, header_name):
######        if not(header_name in self.header_dict): return ['']
######        return [self.header_dict[header_name]]
######class FakeResponse(object):
######    def __init__(self,header_dict):
######        self.fake_info =  Fake_Info(header_dict)
######        Log("init header_dict='{}'".format(header_dict))
######    def info(self):
######        return self.fake_info
######class FakeRequest(object):
######    def __init__(self, full_url):
######        self.full_url = full_url
######    def get_full_url(self):
######        return self.full_url
#__________________________________________________________________________
#
def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=20
            , sucuri_solved=False
            , method="GET"):

    cj = cookielib.LWPCookieJar(C.cookiePath)
    try:
        cj.load(ignore_discard=True, ignore_expires=True)
        cj._now = int(time.time()) #module does not set this if I use internal functions
    except:
        cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
        cj._now = int(time.time())
        pass
    stream=False
    response = None
    redirected_url = None

    Log("getHtml method='{}', url='{}', referer='{}', headers='{}', sent_data='{}', save_cookie='{}', sucuri_solved='{}'".format(
        method
        ,url
        ,referer
        ,headers
        ,sent_data
        ,save_cookie
        ,sucuri_solved
        )
        )

##    ##cookiedump
####    Log(C.cookiePath)
##    this_domain = urlparse.urlparse(url).netloc
####    Log(this_domain)
####    Log(repr(cj))
##    for cookie in cj:
####        Log(cookie.domain)
####        Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
##        if this_domain.endswith(cookie.domain):
##        #if cookie.domain.endswith(this_domain):
##            Log("filtered cookie={}".format(repr(cookie)), xbmc.LOGNONE)
####    return
                        
    try:
                
        if headers is None:
            getHtml_headers = C.DEFAULT_HEADERS.copy()
        else:
            getHtml_headers = headers.copy()

        if len(referer) > 1:
            getHtml_headers['Referer'] = referer

        if sent_data:
            getHtml_headers['Content-Length'] = str(len(sent_data))
##        Log("getHtml_headers='{}'".format(getHtml_headers))


        #
        # I don't know how to use cookieJar with SOCKS proxy
        #
        socks_cookies = ''
        this_domain = urlparse.urlparse(url).netloc
##        Log(this_domain)
        temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
##        Log("type temp_cookiejar='{}'".format(type(temp_cookiejar)))
##        Log("type cj='{}'".format(type(cj)))
        if cj:
            for cookie in cj:
##                Log("pre-request cookie='{}'".format(cookie))
                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                    socks_cookies += "{}={};".format(cookie.name,cookie.value)
                    temp_cookiejar.set_cookie(cookie)
    ##                    Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)
##            Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)
            for cookie in temp_cookiejar:
##                Log("temp_cookiejar_cookie={}".format(repr(cookie)))
                pass

            if 'Cookie' in getHtml_headers:
    ##            Log("getHtml_headers['Cookie']={}".format(getHtml_headers['Cookie']), xbmc.LOGNONE)
                socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
            if not socks_cookies == '':
                getHtml_headers['Cookie'] = (socks_cookies).strip(';')

##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)

        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            Log(socks_string )
            proxy = SOCKSProxyManager(proxy_url=socks_string)
            socks_response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            data = socks_response.data
            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None
                
        elif (socks_proxy_info['uhp'] <= 0) :

            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
            else: proxies = {}

            #either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
            if C.DEBUG:
                verify=False
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            else:
                verify = C.certPath
            #https://requests.readthedocs.io/en/master/api/#requests.Request
            response = my_http_session.request(
                method
                , url=url
                , headers=getHtml_headers
                , data = sent_data
                , stream=stream
                , allow_redirects=True
                , proxies=proxies
                , cookies=temp_cookiejar
                , verify=verify      
                )
##            Log(repr(response.headers))

            if response.status_code == 429:
                response.raise_for_status()
            data = response.content
##            if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
##                content_type = response.headers['Content-Type']
##                if 'charset=' in content_type:
####                    assert isinstance(data, unicode)
##                    data = response.content.decode(content_type.split('charset=')[1])
####                    Log('decoded to {}'.format(content_type.split('charset=')[1]))
##                else:
##                    data = response.content
##            else:
##                data = response.content
##            Log(data[:1000])
            
            redirected_url = response.url 
            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
            else: redirected_url = None
            
##            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
##            else: proxies = {}  
##            #Log("proxies='{}'".format( proxies ) )
##            from requests import Request, Session
##            s = Session() #note: posts to https:// don't work in kodi 17; use http instead
##            req = Request(method, url=url, data=sent_data, headers=getHtml_headers, cookies=cj) #https://requests.readthedocs.io/en/master/api/
##            prepped = s.prepare_request(req)
##            response = s.send(prepped, verify=False, proxies=proxies)
##            data = response.content
##            redirected_url = response.url 
##            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
##            else: redirected_url = None
            
##        else:
##            Log("no proxy=''".format(socks_proxy_info['uhp']))
##            from requests import Request, Session
##            s = Session()
##            Log("getHtml_headers={}".format(getHtml_headers))
##            req = Request('GET', url=url, data=sent_data, headers=getHtml_headers)
##            prepped = s.prepare_request(req)
##            #https://requests.readthedocs.io/en/master/api/
##            response = s.send(prepped, verify=False)
##            data = response.content
##            redirected_url = response.url 
##            if not url == redirected_url:
##                Log("redirected_url='{}'".format(redirected_url))
##            else:
##                redirected_url = None


##        #https://requests.readthedocs.io/en/master/api/
####        from requests import Request, Session
####        s = Session()
####        req = Request('GET', url=url, data=sent_data, headers=getHtml_headers)
####        prepped = s.prepare_request(req)
####        r = s.send(prepped, verify=False)
##        req = urllib2.Request(url, headers=getHtml_headers, unverifiable=True)
##        r = urllib2.urlopen(req)
##        Log(repr(r.info()  ))
##        Log(repr(r.info().getheaders("Set-Cookie2")  ))
##        Log(repr(r.info().getheaders("Set-Cookie")  ))        
####        Log(repr(r.headers))
##        for cookie in cj.make_cookies(r, req):
##            Log("real cookie={}".format(repr(cookie)))
##        Log('done')

            
        if sucuri_solved == False:
            if response:
                #Log("response='{}'".format(repr(response.info())), xbmc.LOGNONE)
                if 'Server' in response.headers:
                    if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                        import sucuri
                        if sucuri.SCRIPT_HEADER in data:
                            cookie = sucuri.Set_Cookie(data)
                            cj.set_cookie(cookie)
                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
##                            raise
                            return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)
            elif socks_response:
                if 'Server' in socks_response.headers:
                    if socks_response.status in (200,301)  and socks_response.headers[ 'Server' ] == "Sucuri/Cloudproxy":
                        import sucuri
                        if sucuri.SCRIPT_HEADER in data:
                            cookie = sucuri.Set_Cookie(data)
                            cj.set_cookie(cookie)
                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
##                            raise
                            return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)

##        Log("data='{}'".format(data))


        if not (save_cookie == False) and (cj is not None) :
            r = None
            this_domain = urlparse.urlparse(url).netloc
            if isinstance(response, urllib3.response.HTTPResponse):
                r = socks_response
                raise Exception('cookie processing tbd once I have a socks proxy to test with')
            else:
                r = response
            if r is not None:
                for cookie in r.cookies:
                    if not cookie.discard:
                        if save_cookie == True: #save as this domain even if cookie is not marked so
                             cookie.domain = this_domain
                        if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                            cj.set_cookie(cookie)
                cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

##                    ### it turns out that using r.headers[ 'Set-Cookie' ] will join
##                    ###     multiple set-cookie headers using a comma, instead of ','
##                    ###   which means we loose information if I try and use some other libraries
##                    ### For now, just skip this - once I have a socks proxy to test with I can
##                    ###    try something else....
##                        
####                Log(repr(r.cookies))
####                Log(repr(r.headers))
####                for a in r.headers[ 'Set-Cookie' ]:
####                    Log(a)
##                if 'Set-Cookie' in r.headers:
##                    fake_response = FakeResponse(r.headers)
####                    Log("1fake_response={}".format(repr(fake_response)))
####                    Log("2fake_response={}".format(repr(fake_response.info())))
####                    Log("3fake_response={}".format(repr(fake_response.info().getheaders("Set-Cookie2") )))
##                    Log("4fake_response={}".format(repr(fake_response.info().getheaders("Set-Cookie") )))
##                    fake_request = FakeRequest(url)
####                    Log("1fake_request={}".format(repr(fake_request.get_full_url())))
##                    for cookie in cj.make_cookies(fake_response, fake_request):
##                        Log("fake cookie={}".format(repr(cookie)))
##                    Log('done')
##
##                    sc = [r.headers[ 'Set-Cookie' ]]
##                    Log("sc={}".format(sc))
##                    
##                    n_c_t = cj._normalized_cookie_tuples(cookielib.parse_ns_headers(sc))
##                    for tup in n_c_t:
##                        Log("tup={}".format(repr(tup)))
##                        #because i am passing request=None later; I need to makes sure that domain is part of the tupple
####                        Log("tup[2]={}".format(repr(tup[2])))
##                        if 'domain' not in tup[2]: tup[2]['domain']=this_domain
####                        Log("tup[2]={}".format(repr(tup[2])))
##                        cookie = cj._cookie_from_cookie_tuple(tup, None)
####                        Log("cookie={}".format(repr(cookie)))
##                        try:
##                            if not cookie.discard:
##                                if save_cookie == True: #save as this domain event if cookie is not marked so
##                                     cookie.domain = this_domain
##                                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
##                                    cj.set_cookie(cookie)
##                        except:
##                            traceback.print_exc()
####                            Log("sc={}".format(repr(sc)))
####                            Log("tup={}".format(repr(tup)))
####                            Log("tup[2]={}".format(repr(tup[2])))
####                            Log("cookie={}".format(repr(cookie)))
##                            raise
##                            
####                    #todo: use cookielib.make_cookies - with fake request/response if necessary
####                    for cookie in SetCookie_To_Array_Of_Cookie(r.headers[ 'Set-Cookie' ]) :
####                        Log("cookie={}".format(repr(cookie)))
####                        if not cookie.discard:
####                            if save_cookie == True: #save as this domain event if cookie is not marked so
####                                 cookie.domain = this_domain
####                            if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
####                                cj.set_cookie(cookie)
##
##                    cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
####                    Log("saving cookiejar")
####            for cookie in cj:
######                if cookie.domain.endswith(this_domain):
####                Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
####            Log("reloading cookiejar")
####            cj = None
####            cj = cookielib.LWPCookieJar(C.cookiePath)
####            cj.load(ignore_discard=True, ignore_expires=True)
####            for cookie in cj:
######                if cookie.domain.endswith(this_domain):
####                Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)                


    except requests.HTTPError as e:
        
##        Log("dir(e)='{}'".format(dir(e)))
##        Log("repr(e)='{}'".format(repr(e)))
##        Log("dir(e.response)='{}'".format(dir(e.response)))
##        Log("e.errno='{}'".format(e.errno))
##        Log("e.response.content='{}'".format(e.response.content))
##        Log("repr(e.response)='{}'".format(repr(e.response)))
        if e.response.status_code == 429 and 'ccapimg' in e.response.content:
            keyname = re.search('key=([^"]+)"', e.response.content).group(1)
            from urlresolver.plugins.lib import captcha_lib
            img_url = referer + '/ccapimg?key=' + keyname
##            Log("img_url='{}'".format(img_url))
            img = captcha_lib.write_img(img_url)
            solution = captcha_lib.get_response(img, y=225)
            form_data = {'secimgkey': (None, keyname), 'secimginp': (None, solution)}
            hdr = getHtml_headers
            if 'Referer' in hdr:
                del hdr['Referer']
            hdr['referer'] = url
            try:
                resp = requests.post(url, files=form_data, headers=hdr)
                resp.encoding = 'ISO-8859-1'
                result = resp.text
            finally:
                if resp: resp.close()
            return result

        raise
    except urllib2.HTTPError as e:
        if e.info().get('Content-Encoding') == 'gzip':
            import StringIO
            buf = StringIO.StringIO( e.read())
            import gzip
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = e.read()
        #Log(data)  #errors='ignore'
        #notify('Oh oh',data)
        if e.code == 503 and 'cf-browser-verification' in data:
            import cloudflare
            data = cloudflare.solve(url, cj, USER_AGENT)
            
        elif e.code == 404 and ignore404 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        elif e.code == 403 and ignore403 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data
            
        else:
            traceback.print_exc()
            raise urllib2.HTTPError()

    except Exception as e:
        traceback.print_exc()
        if 'SSL23_GET_SERVER_HELLO' in str(e):
            notify('Oh oh','Python version too old - update to Krypton or FTMC')
            raise urllib2.HTTPError()
        else:
            Notify(msg="It looks like '{}' is down.".format(url), duration=200)
            raise
        return None

    if send_back_redirect == True:
        return data, redirected_url
    else:
        return data

    if response:
        response.close()

#__________________________________________________________________________
#
def postHtml(post_url, sent_data=None, headers=None, compression=True, NoCookie=True):
    #form_data = urllib.urlencode(form_data)
    return getHtml(url=post_url, headers=headers, save_cookie=(not NoCookie), sent_data=sent_data, method="POST" )
###__________________________________________________________________________
###
##def getHtml2(url):
##    req = Request(url)
##    response = urllib2.urlopen(req, timeout=60)
##    data = response.read()
##    response.close()
##    return data
###__________________________________________________________________________
###
##def getVideoLink(url, referer, hdr=None, data=None):
##    if not hdr:
##        req2 = Request(url, data, DEFAULT_HEADERS)
##    else:
##        req2 = Request(url, data, hdr)
##    if len(referer) > 1:
##        req2.add_header('Referer', referer)
##    url2 = urllib2.urlopen(req2).geturl()
##    return url2


#__________________________________________________________________________
#
def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q

#__________________________________________________________________________
#
from htmlentitydefs import name2codepoint
def htmlentitydecode(s):
    return re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: unichr(name2codepoint[m.group(1)]), s)

#__________________________________________________________________________
#
def cleantext(text):

    text = text.replace('\t','')
    text = text.replace('\n','')
    
    if not isinstance(text, unicode):
        text = unicode(text.decode('utf8', 'ignore'))    

##    text = text.replace(u'\u200b','')
##    from unidecode import unidecode
##    return unidecode(text)
    text = text.strip()

##    text = text.decode('ascii', 'xmlcharrefreplace')

    text = htmlentitydecode(text)
##    import unicodedata
##    text = unicodedata.normalize('NFKD',text)
    text = html_parser.unescape(text)
    text = text.encode('utf-8')

    #returned text should be pure unicode
    #no futher encoding should be necessary
    

##
##    text = text.replace('&excl;','!')
##    text = text.replace('&comma;',',')
##    text = text.replace('&lowbar;','_')
##    text = text.replace('&period;','.')
##    text = text.replace('&lpar;','[')
##    text = text.replace('&rpar;',']')

    return text

    #Log(text,xbmc.LOGNONE)
    #text = html_parser.unescape(text.encode('ascii', 'ignore'))
    text = htmlentitydecode(text)
    text = text.replace('&#8211;','-')
    text = text.replace('&ndash;','-')
    
    
    
    text = text.replace('&amp;','&')
    text = text.replace('&#038;','&')
    text = text.replace('&#8217;','\'')
    text = text.replace('&#8216;','\'')
    text = text.replace('&#8230;','...')
    text = text.replace('&quot;','"')
    text = text.replace('&excl;','!')
    text = text.replace('&apos;','\'')
    text = text.replace('&#039;','`')
    text = text.replace(u'ñ','n')


    #Log(text,xbmc.LOGNONE)
    #xbmc.log(  u'ñ'.encode("utf-8").decode("utf-8") , xbmc.LOGNONE)
    #text = text.encode("utf-8").replace('&ntilde;','\xf1').decode("utf-8")
    text = text.replace('&rsquo;','\'')
    text = text.encode('ascii', 'ignore').strip()


    return text


#__________________________________________________________________________
#
def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext

#__________________________________________________________________________
#
def Set_ListItem_Duration(listitem, duration):
    duration=str(duration).strip()
    duration_seconds = 0
    #Log("'{}'".format(duration), xbmc.LOGNONE)

    #somethimes will have a dot
    if '.' in duration:
        duration = duration.split('.')[1]
        
    #somethimes format will be hh:mm:ss: normalize it to what I want
    timearr= ['s ','m ','h ']
    if ':' in duration:
        duration_arr = duration.split(':')
        duration = ""
        #Log("len '{}'".format(len(duration_arr)), xbmc.LOGNONE)
        i = 0
        for duration_elem in reversed(duration_arr):
            #Log("'{}'".format(duration_elem), xbmc.LOGNONE)
            duration = duration_elem + timearr[i] + duration
            i = i+1

    duration=duration.strip()
    duration = duration.replace(' h', 'h').replace(' min', 'm').replace(' sec', 's')
    #Log("'{}'".format(duration), xbmc.LOGNONE)

    #assume format will be Xh Ym Zs
    duration_arr = duration.split(' ')
    for duration_elem in duration_arr:
        #Log(duration_elem)
        if 'h' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('h',''))*3600
        elif 'm' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('m',''))*60
        elif 's' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('s',''))
        else:
            duration_seconds = duration_seconds + int(duration_elem)
    #Log(duration_seconds)
    listitem.setInfo(type="Video", infoLabels={"duration": duration_seconds} )

#__________________________________________________________________________
#
def addDownLink(name, url, mode
                , iconimage=u''
                , desc=u''
                , stream=None
                , fav='add'
                , noDownload=False
                , duration=None
                , date=None
                , views=None
                , likes=None
                , play_method=None
                , hq_stream=None ):

    if fav == 'add': favtext = "Add to"
    elif fav == 'del': favtext = "Remove from"
    if not date: date = 0
    if not hq_stream: hq_stream = ''
    else:  hq_stream = str(hq_stream)

##    assert isinstance(name, unicode)
##    Log(u"&name={}".format(name)) 
##    Log(u"&name={}".format(urllib.quote_plus(name.encode('utf8'))))
##    Log(u"&hq_stream={}".format(urllib.quote_plus(hq_stream)) )
##    Log(u"&img={}".format(urllib.quote_plus(iconimage.encode('utf8')) ))
##    Log(u"&desc={}".format(urllib.quote_plus(desc.encode('utf8'))) )
##    Log(u"&desc={}".format(desc))
##    Log(u"&desc={}".format(urllib.quote_plus(desc)))
##    Log(u"&playmode_string={}".format(play_method))
    
    u = (
        u"{}".format(sys.argv[0])
        + u"?url={}".format(urllib.quote_plus(url)) 
        + u"&mode={}".format(mode) 
        + u"&img={}".format(urllib.quote_plus(iconimage) ) 
        + u"&name={}".format(urllib.quote_plus(name)) 
        + u"&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + u"&desc={}".format(urllib.quote_plus(desc)) 
        + u"&playmode_string={}".format(play_method)
        )
    dwnld = (
        u"{}".format(sys.argv[0]) 
        + u"?url={}".format(urllib.quote_plus(url)) 
        + u"&mode={}".format(mode) 
        + u"&img={}".format(urllib.quote_plus(iconimage) ) 
        + u"&name={}".format(urllib.quote_plus(name)) 
        + u"&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + u"&playmode_string={}".format(play_method) 
        + u"&download=1"
        )
    favorite = (
        u"{}".format(sys.argv[0]) 
        + u"?url={}".format(urllib.quote_plus(url)) 
        + u"&mode={}".format(C.FAVORITES_MODE) 
        + u"&img={}".format(urllib.quote_plus(iconimage) ) 
        + u"&name={}".format(urllib.quote_plus(name)) 
        + u"&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + u"&fav={}".format(fav) 
        + u"&favmode={}".format(mode) 
        )
    play_with_method = (
        u"{}".format(sys.argv[0])
        + u"?url={}".format(urllib.quote_plus(url))
        + u"&mode={}".format(mode)
        + u"&img={}".format(urllib.quote_plus(iconimage) )
        + u"&name={}".format(urllib.quote_plus(name))
        + u"&hq_stream={}".format(urllib.quote_plus(hq_stream))
        + u"&playmode_string={}"
        + u"&play_profile={}"
        )

##    Log("u={}".format(u))
##    Log("favorite={}".format(favorite))
    #Log("play_with_method={}".format(play_with_method))
    
    ok = True

    if len(iconimage) < 1:
        iconimage = C.uwcicon
    #Log("iconimage={}".format(iconimage))
    if not '|' in iconimage and 'http' in iconimage:
        iconimage = "{}{}".format(iconimage, Header2pipestring())
    #Log("iconimage={}".format(iconimage))

    liz = xbmcgui.ListItem(name) #, thumbnailImage=iconimage, iconImage="DefaultVideo.png")
    liz.setArt({ 'thumb': iconimage, 'icon': iconimage, 'fanart': iconimage }) #must include thumb to avoid error messages
    #liz.setArt({'thumb': iconimage, 'icon': iconimage, 'fanart': iconimage })
##    fanart = os.path.join(rootDir, 'fanart.jpg')
##    if C.addon.getSetting('posterfanart') == 'true':
##        fanart = iconimage
##        liz.setArt({'poster': iconimage})
##    liz.setArt({'fanart': fanart})

    if duration:  
        Set_ListItem_Duration(liz, duration) #2021-01 k17.6 setting duration seems to cause page to be reloaded after play stops 

    liz.setMimeType('video/mp4')
    liz.setContentLookup(False)
    liz.setProperty('IsPlayable', 'false')
    
    if stream:
        #Log("iconimageasdasdf={}".format(iconimage))
        liz.setProperty('IsPlayable', 'true') #can't set this and use playlists at same time

    if len(desc) < 1:  desc = ''
    liz.setInfo(
        type="Video"
        , infoLabels={
            "title": name
            ,"plot": desc
            ,"plotoutline": desc
            }
        )

    liz.addStreamInfo('video', {'codec': 'h264'})

    contextMenuItems = []

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        
        contextMenuItems.append(
            (
            "[COLOR {}]{} favorites[/COLOR]".format(C.time_text_color, favtext)
            , "xbmc.RunPlugin({})".format(favorite)
            )
        )
        if fav == 'del':
            favorite = (
                u"{}".format(sys.argv[0]) 
                + u"?url={}".format(urllib.quote_plus(url)) 
                + u"&mode={}".format(C.FAVORITES_MODE) 
                + u"&img={}".format(urllib.quote_plus(iconimage) ) 
                + u"&name={}".format(urllib.quote_plus(name)) 
                + u"&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
                + u"&fav={}".format('refresh') 
                + u"&favmode={}".format(mode) 
                )
            contextMenuItems.append(
                (
                "[COLOR {}]{} favorite icon[/COLOR]".format(C.time_text_color, 'Refresh')
                , "xbmc.RunPlugin({})".format(favorite)
                )
            )

##    hq_bonus = int(C.addon.getSetting("hq_bonus").lower())

    #Log("play_method={}".format(play_method))
    if play_method in {C.PLAYMODE_VARIABLE, None} :
        contextMenuItems.append(
            (
            "[COLOR {}]{} 480[/COLOR]".format(C.time_text_color, 'Play Max')
            , "xbmc.RunPlugin({})".format(play_with_method.format('480', 0))
            )
        )
        contextMenuItems.append(
            (
            "[COLOR {}]{} 720[/COLOR]".format(C.time_text_color, 'Play Max')
            , "xbmc.RunPlugin({})".format(play_with_method.format('720', 0))
            )
        )
        contextMenuItems.append(
            (
            "[COLOR {}]{} 1080[/COLOR]".format(C.time_text_color, 'Play Max')
            , "xbmc.RunPlugin({})".format(play_with_method.format('1080', 0))
            )
        )
        
    if play_method in {C.PLAYMODE_INPUTSTREAM, C.PLAYMODE_F4MPROXY, C.PLAYMODE_DIRECT, ''} :

        contextMenuItems.append(
            (
            "[COLOR {}]{} Direct[/COLOR]".format(C.time_text_color, 'Play')
            , "xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_DIRECT, 0))
            )
        )
        contextMenuItems.append(
            (
            "[COLOR {}]{} Inputstream[/COLOR]".format(C.time_text_color, 'Play')
            , "xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_INPUTSTREAM, 0))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_01_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_01"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_02_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_02"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_03_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_03"))
            )
        )
        
    if noDownload == False:
        contextMenuItems.append(
            (
                "[COLOR {}]Download[/COLOR]".format(C.time_text_color)
                ,"xbmc.RunPlugin({})".format(dwnld)
            )
        )

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)

    #Log("u='{}'".format(u))
    ok = xbmcplugin.addDirectoryItem(handle=C.addon_handle, url=u, listitem=liz, isFolder=False)
    return 


#__________________________________________________________________________
#
def addDir(name, url, mode, iconimage=None, page=None, channel=None, section=None
           , keyword='', Folder=True, duration=None, title=None, end_directory=True
           , contextMenu=None, contextMenuReplace=True):
    #return
    u = (sys.argv[0] +
     "?url=" + urllib.quote_plus(str(url)) +
     "&mode=" + str(mode) +
     "&page=" + str(page) +
     "&channel=" + str(channel) +
     "&section=" + str(section) +
     "&keyword=" + urllib.quote_plus(str(keyword)) +
     "&end_directory=" + str(end_directory) +
     "&name=" + urllib.quote_plus(str(name)))

    ok = True

    #Log("u={}".format(u))

    if not(iconimage) or (len(iconimage) < 1): iconimage = C.uwcicon

    if not '|' in iconimage and 'http' in iconimage:
        iconimage = "{}{}".format(iconimage, Header2pipestring())

    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)

    liz.setProperty('IsPlayable', 'false')

    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    fanart = os.path.join(C.rootDir, 'fanart.jpg')

    if C.addon.getSetting('posterfanart') == 'true':
        fanart = iconimage
        liz.setArt({'poster': iconimage})

    liz.setArt({'fanart': fanart})

    if duration:
        Set_ListItem_Duration(liz, duration)

    #setting type = music instead of video means no icon to the right of the label
    #liz.setInfo(type="music", infoLabels={"Title": name})

    if title:
        liz.setInfo(type="Video", infoLabels={"Title": title})

    contextMenuItems = []
    if len(keyword) >= 1 and not("next page" in name.lower()):
        keyw = (sys.argv[0] +
            "?mode=" + C.DELETE_KEYWORD +
            "&keyword=" + urllib.quote_plus(keyword))
        #if not contextMenuItems: contextMenuItems = []
        contextMenuItems.append( (
            "[COLOR {}]Remove keyword[/COLOR]".format(C.time_text_color)
            , "xbmc.RunPlugin({})".format(keyw) )  )

    if section and section == C.INBAND_RECURSE:
        #below will not work well because the 'back' button will return to root of addon, and not where I want     
        u2 = u.replace("&keyword=" + urllib.quote_plus(str(keyword)), "&keyword=" + C.INBAND_RECURSE)
        u2 = u2.replace("&page=" + str(page), "&page=" + str(int(page)-1)) #include the page we are on
        u2 = u2.replace("&page=" + str(page), "&page=1")  #include the page we are on
        contextMenuItems.append( (
            "[COLOR {}]Recurse to Page {}[/COLOR]".format(C.search_text_color, C.MAX_RECURSE_DEPTH)
            , "xbmc.ActivateWindow(Videos,{})".format(u2)  )  )
        contextMenuReplace=False

#####below does not work well because the 'back' button will return to root of addon, and not where I want
##    if add_recursive_search_submenu == True:
##        u2 = (sys.argv[0] +
##         "?url=" +
##         "&mode=" + str(mode) +
##         "&page=-1"
##         "&keyword=" + urllib.quote_plus(str(keyword)) +
##         "&end_directory=False" )
##        #Log("u2={}".format(u2))
##        if not contextMenuItems: contextMenuItems = []
####        contextMenuItems.append( (
####            "[COLOR {}]Recursive Search[/COLOR]".format(search_text_color)
####            , "xbmc.RunPlugin({})".format(u2)  )  )
##        contextMenuItems.append( (
##            "[COLOR {}]Recursive Search[/COLOR]".format(search_text_color)
##            , "ReplaceWindow(Videos," + u2 + ")"  )  )
##            #'XBMC.RunPlugin('+ Pluginurl+')') 
##            #"ActivateWindow(Videos," + u2 + ")"
##            #ReplaceWindow

    if contextMenu:
        contextMenuItems = contextMenu
        
    if contextMenuItems:
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)

    ok = xbmcplugin.addDirectoryItem(handle=C.addon_handle, url=u, listitem=liz, isFolder=Folder)
    return liz

#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""


#__________________________________________________________________________
#
def searchDir(url, mode, page='1', end_directory=True):

    label = "{}[COLOR {}]Quick Search[/COLOR]".format(
        C.SPACING_FOR_TOPMOST
        ,C.search_text_color
        ) 
    addDir(
        name=label
        ,url=url 
        ,mode=C.QWIK_SEARCH 
        ,iconimage=C.search_icon 
        ,page=page
        ,channel=mode
        ,end_directory=end_directory)

    addDir(
        "{}[COLOR {}]Add Keyword[/COLOR]".format(C.SPACING_FOR_NEXT,C.search_text_color)
        , url=''
        , mode=C.ADD_KEYWORD
        , iconimage=C.search_icon
        , channel=mode)

    addDir(
        "{}[COLOR {}]Clear list[/COLOR]".format(C.SPACING_FOR_NEXT,C.search_text_color)
        , url=''
        , mode=C.CLEAR_SEARCH
        , iconimage=C.search_icon)

    conn = sqlite3.connect(C.favoritesdb)
    db_cursor = conn.cursor()
    try:
        db_cursor.execute("SELECT * FROM keywords")
        for (keyword,) in db_cursor.fetchall():
            label = "{}[COLOR {}]{}[/COLOR]".format(
                C.SPACING_FOR_NAMES
                , C.time_text_color
                , urllib.unquote_plus(keyword)
                )
            addDir(
                name=label
                , url=url 
                , mode=mode
                , iconimage=C.search_icon 
                , page=page
                , keyword=keyword
                , end_directory=end_directory
                )
    except:
        traceback.print_exc()
        pass

    endOfDirectory()

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ADD_KEYWORD, ['channel'])
def NewSearchKeyword(channel):
    Log("NewSearchKeyword channel='{}'".format( channel))
    vq = _get_keyboard(heading="Searching for...")
    if (not vq):
        return False, 0
    keyword = urllib.quote_plus(vq)
    AddKeyword(keyword)
    Quick_Search(url='', channel=channel, end_directory=True, page='1', keyword=keyword)
    #xbmc.executebuiltin('Container.Refresh')
    endOfDirectory()

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CLEAR_SEARCH)
def clearSearch():
    delallKeyword()
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
def AddKeyword(keyword):
    Log("AddKeyword keyword='{}'".format(keyword))
    conn = sqlite3.connect(C.favoritesdb)
    db_cursor = conn.cursor()
    db_cursor.execute("INSERT INTO keywords VALUES (?)", (keyword,))
    conn.commit()
    conn.close()

#__________________________________________________________________________
#
def delallKeyword():
    yes = dialog.yesno('Warning','This will clear all the keywords', 'Continue?', nolabel='No', yeslabel='Yes')
    if yes:
        conn = sqlite3.connect(C.favoritesdb)
        db_cursor = conn.cursor()
        db_cursor.execute("DELETE FROM keywords;")
        conn.commit()
        conn.close()

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.DELETE_KEYWORD, ['keyword'])
def delKeyword(keyword):
    Log('keyword: ' + keyword)
    conn = sqlite3.connect(C.favoritesdb)
    db_cursor = conn.cursor()
    db_cursor.execute("DELETE FROM keywords WHERE keyword = '%s'" % keyword)
    conn.commit()
    conn.close()
    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________________
#
def Get_Sites(filter_category=None):
    import importlib
    libDir = os.path.join(C.resDir, 'lib')
    sitesDir = os.path.join(libDir, 'sites')
    files = []
    for r, d, f in os.walk(sitesDir): # r=root, d=directories, f = files
        for file in f:
            if file.endswith('.py') and not file.startswith('_') :
                f2 = file[:-len('.py')]
                files.append(f2)
    site_list = {}
    for f in files:
        if not f in site_list:
##            Log("added f='{}'".format(f))
            site_list[f] = ''

    import operator
    sorted_site_list = sorted(site_list.items(), key=operator.itemgetter(0))
    import collections
    sorted_dict = collections.OrderedDict(sorted_site_list)

    aa = None
    for sitename in sorted_dict:
        if aa is None:
            try:
                module = importlib.import_module('resources.lib.sites.'+sitename)
                if hasattr(module, "website"):
                    module = module.website
##                    Log("detected subclass of 'website'")
##                    Log("module.LIST_AREA='{}'".format(module.LIST_AREA))
##                    Log("dir(module.LIST_AREA)='{}'".format(dir(module.LIST_AREA)))
##                    Log("repr(module.LIST_AREA)='{}'".format(repr(module.LIST_AREA)))
                if filter_category:
                    if module.LIST_AREA == filter_category:
                        yield (
                            module.FRIENDLY_NAME
                            ,module.ROOT_URL
                            ,module.MAIN_MODE
                            ,os.path.join(C.imgDir, sitename + '.png')
                            )
                else:
##                    Log("sitename='{}'".format(sitename))
                    aa = (yield (sitename, module))
                    if aa is not None:
                        break
            except:
                Log('failed Get_Sites for {}'.format(sitename), xbmc.LOGWARNING)
                traceback.print_exc()
#__________________________________________________________________
#
import Queue
import threading
def crawl(q, all_method_results):
##            Log("repr(q)='{}'".format(repr(q)))
    while not q.empty():
        work = q.get(timeout=C.WEBCRAWLER_THREAD_TIMEOUT)
##        Log("repr(work)='{}'".format(repr(work)))
        index_for_result = work[0]
        method_to_call = work[1]
        keyword_arguments_for_method_to_call = work[2]
        try:
            single_method_result = method_to_call(**keyword_arguments_for_method_to_call)
        except Exception as ex:
            single_method_result = ex
        all_method_results[index_for_result] = single_method_result
        q.task_done()
    return True

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.QWIK_SEARCH, ['url', 'channel'], ['end_directory','page','keyword'])
def Quick_Search(url, channel, end_directory=True, page='1', keyword=None):
    Log("Quick_Search url='{}', channel='{}', end_directory='{}', page='{}', keyword='{}'".format( url, channel, end_directory, page, keyword))


    if not keyword:
        ##get the search string from user; remember it; pre-populate remembered
        prev_search_string = C.this_addon.getSetting(id='quick_search_string')
        quick_search_string = _get_keyboard(
            heading="Search query"
            ,default=prev_search_string
            )
##        Log("quick_search_string='{}'".format(quick_search_string))
        if  quick_search_string == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.this_addon.setSetting(id='quick_search_string', value=quick_search_string)
##        Log("quick_search_string='{}'".format(quick_search_string))
    else:
        quick_search_string = keyword

    if C.ROOT_SEARCH_ALL == str(channel):
        end_directory = False #this sub will set the directory

    get_sites = Get_Sites()
    q = Queue.Queue()
    i = 0
    all_method_results = {}
    try: 
        for sitename, module in get_sites:
            if module.SEARCH_MODE == str(channel) or C.ROOT_SEARCH_ALL == str(channel):
##                i = i + 1 #testing
                all_method_results[sitename] = None
                method_to_call = getattr(module, 'Search')
                kwargs = {
                    "searchUrl": module.SEARCH_URL
                    ,"keyword": keyword
                    ,"end_directory": end_directory
                    ,"page": page}
                q.put( (sitename,method_to_call,kwargs) )
##            if i > 2: break #testing
        for k in range(C.MAX_WEBCRAWLER_THREADS):
            worker = threading.Thread(target=crawl, args=(q,all_method_results))
            worker.daemon = False
            worker.start()
        q.join()
        get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
    except StopIteration:
        pass
    except:
        traceback.print_exc()
        
    for result in all_method_results:
        if not(all_method_results[result] in [None, True]):
            addDownLink(
                name=C.STANDARD_MESSAGE_FAILED_SEARCH.format(result, all_method_results[result].message)
                ,url=C.DO_NOTHING_URL
                ,mode=C.ROOT_INDEX_INDEX
                )

    Log("Quick_Search ended")
    endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_SEARCH_ALL, ['page'], ['keyword']  )
def Search_All(page=1, keyword=None):

    if not keyword:
        searchDir(url=C.DO_NOTHING_URL, mode=C.ROOT_SEARCH_ALL)
        return
    
    #temporarilty force only  X   recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 1
    C.MAX_RECURSE_DEPTH = 1

    Quick_Search(url=C.DO_NOTHING_URL,channel=C.ROOT_SEARCH_ALL,keyword=keyword)

##single thread version
##    for sitename, module in utils.Get_Sites():
##        method_to_call = getattr(module, 'Search')
##        try:
##            result = method_to_call(module.SEARCH_URL, keyword=keyword, end_directory=False)
##            Log('passed search for {}'.format(sitename))
##        except:
##            Log('failed search for {}'.format(sitename), xbmc.LOGWARNING)
##            traceback.print_exc()
##            utils.addDownLink(
##                name="[COLOR {}]{}[/COLOR]".format(
##                    C.highlight_text_color
##                    , 'failed search on {}'.format(sitename)
##                    )
##                ,url=C.DO_NOTHING_URL
##                ,mode=ROOT_INDEX_INDEX
##                )
##    get_sites = Get_Sites()
##    q = Queue.Queue()  #store information in Q that will be used by threads
##    all_method_results = {} #storage for return codes
##    try:
##        i = 0 #don't do all sites during development
##        for sitename, module in get_sites:
####            i = i+1 #don't do all sites during development
##            all_method_results[sitename] = None #prepare this storage for return codes
##            method_to_call = getattr(module, 'Search')
##            kwargs = {
##                "searchUrl": module.SEARCH_URL
##                ,"keyword": keyword
##                ,"end_directory": False # _this_ function is responsible for end_directoriy
##                ,"page": page}
##            q.put( (sitename,method_to_call,kwargs) )
##            if i > 2: break      #don't do all sites during development       
##        for k in range(C.MAX_WEBCRAWLER_THREADS):
##            worker = threading.Thread(target=crawl, args=(q,all_method_results))
##            worker.daemon = False
##            worker.start()
##        q.join()
##        if i > 2: get_sites.send(False) #cancel yeild operations; will raise StopIteration inside get_sites
##    except StopIteration:
##        pass
##    except:
##        traceback.print_exc()
##
##    for result in all_method_results:
##        if not(all_method_results[result] in [None, True]):
##            addDownLink(
##                name=C.STANDARD_MESSAGE_FAILED_SEARCH.format(result, all_method_results[result].message)
##                ,url=C.DO_NOTHING_URL
##                ,mode=C.ROOT_INDEX_INDEX
##                )

##    Log("Search_All ends")
    endOfDirectory()
#__________________________________________________________________________
#
def textBox(heading,announce):
    class TextBox():
        WINDOW=10147
        CONTROL_LABEL=1
        CONTROL_TEXTBOX=5
        def __init__(self,*args,**kwargs):
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win=xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()
        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            try: f=open(announce); text=f.read()
            except: text=announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return
    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        Sleep(500)

#__________________________________________________________________________
#

##def kodilog(msg, loglevel=None):
##    Log(msg,loglevel)
##def log(msg='', loglevel=None):
##    Log(msg, loglevel)
def Log(msg='', loglevel=None):

    assert isinstance(msg, unicode)

    if not isinstance(msg, unicode):
        msg = unicode(msg.decode('utf-8', 'ignore'))
    
##    import unicodedata
##    msg = unicodedata.normalize('NFC', unicode(msg))
##    xbmc.log(msg.decode('unicode-escape').encode('utf-8'),xbmc.LOGNONE)
##    xbmc.log(msg.decode('utf8',errors='ignore').encode('ascii',errors='ignore'),xbmc.LOGNONE)

    try: 
        msg = "{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=2)[0][0])
            ,traceback.extract_stack(limit=2)[0][1]
            ,msg
            )
    except:
        pass
    

        
##    try:    debug = (C.this_addon.getSetting('debug').lower() == "true")
##    except: debug = True
##    if re.compile("\\u\w\w\w\w").findall(msg):
####        xbmc.log(msg , xbmc.LOGNONE)
##        xbmc.log('unicode-escape', xbmc.LOGNONE)
##        msg = msg.decode('unicode-escape',errors='ignore').encode('utf-8',errors='ignore')
##    xbmc.log(msg.encode('utf-8') , xbmc.LOGNONE)
##    xbmc.log(msg , xbmc.LOGNONE)
    msg = "{}: {}".format(C.addon_id, msg.encode('utf-8',errors='ignore') )
    
##    xbmc.log(msg , xbmc.LOGNONE)
##    return

    if  loglevel: xbmc.log(msg , loglevel)
    elif C.DEBUG:  xbmc.log(msg , xbmc.LOGNONE)
    else:    xbmc.log(msg)

#__________________________________________________________________________
#
def Notify(header=None, msg='', duration=3000, sound=False):
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound)
def notify(header=None, msg='', duration=C.DEFAULT_NOTIFY_TIME, sound=False):
    debug = (C.this_addon.getSetting('debug').lower() == "true")
    if threading.current_thread().name == "MainThread":
        Log( msg, xbmc.LOGNOTICE)
        if header==None or header == '':
            if len(msg) > 30:
                header = msg[0:30]
                msg = msg[-30:]
            else:
                header=msg
        xbmcgui.Dialog().notification(header, msg, C.uwcicon, duration, sound=False )
    elif debug:
        Log( msg, xbmc.LOGNOTICE)

#__________________________________________________________________________
#
def Header2pipestring(header = C.DEFAULT_HEADERS):
    q = "|{}".format( urllib.urlencode(header)  )
    return q

#__________________________________________________________________________
#
def add_sort_method():
    sort_order = int(C.addon.getSetting('video_sort_by'))
    if sort_order == 1:
        sort_order = xbmcplugin.SORT_METHOD_DURATION
    elif sort_order == 2:
        sort_order = xbmcplugin.SORT_METHOD_DATE
    elif sort_order == 3:
        sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
    elif sort_order == 4:
        sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
    elif sort_order == 5:
        sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
    else:
        sort_order = xbmcplugin.SORT_METHOD_UNSORTED
    
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=sort_order) #use preferred method first
    #xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
#    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_DURATION)
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CONFIGURE_INPUTSTREAM)
def configure_addon():
    import xbmcaddon
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________________
#
def endOfDirectory(cacheToDisc=True, end_directory=True, allow_sorting=True, inband_recurse=False):
    if not ( (end_directory == True) or inband_recurse ):
        return
    if allow_sorting == True:
        add_sort_method()
    if int(sys.argv[1]) > 0:
        C.addon_handle = int(sys.argv[1])
        xbmcplugin.endOfDirectory(C.addon_handle, cacheToDisc=cacheToDisc)
#__________________________________________________________________________
#
def SortVideos(sources
               , download
               , vid_res_column=1
               , substitute_char='}'
               , substitute_res='720'
               , max_video_resolution = C.maximum_video_resolution
               ):

    Log("SortVideos sources='{}', download='{}', vid_res_column='{}', max_video_resolution='{}'".format(repr(sources), download, vid_res_column, max_video_resolution))
##    global maximum_video_resolution
    if max_video_resolution:
        maximum_video_resolution = max_video_resolution
    else:
        maximum_video_resolution = C.maximum_video_resolution
##    Log(str(maximum_video_resolution))

    try: 
        #sometimes we can't get accurate resolutions and end up with a characters instead...
        # e.g. "http://video.mp4","}"     instead of   "http://video.mp4","480p"

##        Log("sources='{}', download='{}'".format(sources,download))

        if (bool(download) == True):
            maximum_video_resolution = 99999 # allow max resolution on download
##        Log("maximum_video_resolution='{}'".format(maximum_video_resolution))

        s3840p_string = "3840p"
        s2160p_string = "2160p"
        s1440p_string = "1440p"
        s1080p_string = "1080p"
        s720p_string = "720p"
        s540p_string = "540p"
        s480p_string = "480p"
        s320p_string = "320p"

        #report on what was the maximum resolution available; just for fun
        try:
            videos = sorted(sources
                            , key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True)
##            Log(repr(videos))

            if len(videos) > 1:
                if vid_res_column == 1:
                    max_avail_res = videos[0][1]
                else:
                    max_avail_res = videos[0][0]
            else:
                max_avail_res = 'unknown'
        except:
            traceback.print_exc()
            max_avail_res = 'unknown'
            pass
        Log("Best quality for this item is {}".format(max_avail_res))
##        Log("Worst quality for this item is {}".format(videos[-1][vid_res_column]  ))

        #change these subst strings so that they can't be matched when max resolution is less
        if maximum_video_resolution < 3840:
            s3840p_string = "40p" 
        if maximum_video_resolution < 2160:
            s2160p_string = "60p"
        if maximum_video_resolution < 1440:
            s1440p_string = "14p"
        if maximum_video_resolution < 1080:
            s1080p_string = "14p"
        if maximum_video_resolution < 720:
            s720p_string = "14p"
        if maximum_video_resolution < 540:
            s540p_string = "13p"
        if maximum_video_resolution < 480:
            s480p_string = "12p"

    ##     the list of videos is a bunch of urls such as xxx\360.mp4
    ##        i use a lambda(just for fun) to split out the numeric resolution and the reverse sort it;
    ##        the best resolution should end up on top
    ##        the 720 is replaced with 721 so that the number ending 20 does not match other possible strings the site may use to define ultra resolutions
    ##        the letter p is removed so that we can convert to integer and avoid the 720 is better 1080 situation if it were chars
    ##        the higher resolutions, when we have been told not to use them, are replaced with lower numbered strings 

        try:
            videos = sorted(sources, key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True)
        except:
            videos = None
            traceback.print_exc()

        Log("videos='{}'".format(videos))
        if len(videos) < 1:
            return None
        if vid_res_column == 1:
            video_url = videos[0][0]
        else:
            video_url = videos[0][1]
        Log("video_url='{}'".format(video_url))
        return video_url
    except:
         traceback.print_exc()
         return None

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_TEST_ALL)
def TEST_ALL(quick_search_string=None):

    #one of the tests is searching via keyword...get a keyword
##    quick_search_string = 'sex'
    if not quick_search_string:
        prev_search_string = C.addon.getSetting(id='quick_search_string')
        quick_search_string = _get_keyboard( heading="Search query", default=prev_search_string  )
        if  quick_search_string == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=quick_search_string)

    #generate list of potential test sites by listing dir
    get_sites = Get_Sites()
    #add sites to settings.xml [so that we can track which site has been tested today]
    test_list = C.addon.getSetting(id=C.TESTING_LIST_NAME)
##    test_list = "" #testing
    if test_list == "": test_list = json.loads("{}")
    else: test_list = json.loads(test_list)
    for sitename, module in get_sites:
##        Log("sitename='{}'".format(repr(sitename)))
        if not (sitename in test_list):
            test_list[sitename] = ''
    C.addon.setSetting(id=C.TESTING_LIST_NAME, value=json.dumps(test_list))

    
    #temporarilty force only  X   recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 1
    C.MAX_RECURSE_DEPTH = 2

    #perform tests [if not passed test today]
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    q = Queue.Queue()
    i = 0 #testing
    all_method_results = {}
    try:
        get_sites = Get_Sites() #refresh this variable
        for sitename, module in get_sites:
            all_method_results[sitename] = None #assume success
            last_success_date = test_list[sitename]
            if last_success_date < today: #we should test today
##                i = i + 1 #testing
                method_to_call = getattr(module, 'Test')
                kwargs = {"keyword": quick_search_string}
                q.put( (sitename,method_to_call,kwargs) )
            else:
                Log("'{}' passed '{}'".format(sitename, last_success_date))
            if i > 4: break #testing
                 
        for k in range(C.MAX_WEBCRAWLER_THREADS):
            worker = threading.Thread(target=crawl, args=(q,all_method_results))
            worker.daemon = False
            worker.start()
        q.join()

        get_sites.send(False) #testing #cancel yield operations; will raise StopIteration inside get_sites

    except StopIteration:
        pass
    except:
        traceback.print_exc()

    #analyze test results and save them
    something_failed = False
    for sitename in all_method_results:
        if not(all_method_results[sitename] in [None, True]): #None or True are the success codes
            something_failed = True
            try:
                Log(repr(all_method_results[sitename]))
                n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(sitename, sitename)
                n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(sitename, all_method_results[sitename].message.decode("utf8", "ignore"))
            except:
                traceback.print_exc()
            addDownLink(
                name=n
                ,url=C.DO_NOTHING_URL
                ,mode=C.NO_ACTION_MODE
                )
        else:
            test_list[sitename] = today
    C.addon.setSetting(id=C.TESTING_LIST_NAME, value=json.dumps(test_list))
##    Log("test_list='{}'".format(repr(test_list)))
    
    #visual indicator of success
    if not something_failed:
        addDownLink(
                name="[COLOR {}]all tests passed on {}[/COLOR]".format(C.test_passed_text_color,today)
                ,url=C.DO_NOTHING_URL
                ,mode=C.NO_ACTION_MODE
                )

    endOfDirectory()

#__________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=10):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval

#__________________________________________________________________
#
def get_set(genset,n):
    nd=genset.getElementsByTagName(n)[0]
    #Log("get_set='{}'".format(nd))
    if nd.lastChild is None:
        #Log("  {}='{}'".format(n,nd.lastChild))
        return nd.lastChild
    else:
        #Log("  {}='{}'".format(n,nd.lastChild.data))
        return nd.lastChild.data

#__________________________________________________________________
#
def Socks_Proxy_Active():
    
    from xml.dom import minidom
    gen_set=minidom.parse(xbmc.translatePath('special://home/userdata/guisettings.xml'))
    try: 
        uhp = get_set(gen_set,"usehttpproxy")
        uhp = uhp.lower()=='true'
        if uhp:
    ##        Log("a proxy is enabled='{} with value='{}''".format(uhp, int(get_set(gen_set,"httpproxytype")) ))
            #return {'uhp': int(get_set(gen_set,"httpproxytype"))==4  or int(get_set(gen_set,"httpproxytype"))==5  or int(get_set(gen_set,"httpproxytype"))==0
            return {'uhp': int(get_set(gen_set,"httpproxytype"))
                    , 'ps': get_set(gen_set,"httpproxyserver")
                    , 'pp': int(get_set(gen_set,"httpproxyport"))
                    , 'un': get_set(gen_set,"httpproxyusername")
                    , 'up': get_set(gen_set,"httpproxypassword")
                    }
    except:
        pass

    return {'uhp':-1, 'ps':None, 'pp':None, 'un':None, 'up':None}
#__________________________________________________________________
#
def RandomNumber(return_integer=True,length=18):
    import random
    nc_string = str(random.random())
    if return_integer:
        nc_string = nc_string.split('.')[1]
    while len(nc_string) < length:
        nc_string += str(random.randint(10,99))    
    return nc_string

#########__________________________________________________________________
#########
########def SetCookie_To_Array_Of_Cookie(set_cookie_string):
##########    Log("set_cookie_string='{}'".format(set_cookie_string))
########    cookies_array = []
########    #regex = "(?is)(\s?expires=\w\w\w,\s\d\d-\w\w\w-\d{2,4}\s\d{1,2}:\d\d:\d\d(?:\s?\w{3})?;?)"
########    regex = "(\s?expires=(.{27,29})(?:;|,)?)"
########    regex = "(\s?expires=([^;]+)(?:;|$)?)"
########    
########    set_cookie_string_no_expires = re.sub(regex,'',set_cookie_string, flags=re.IGNORECASE)
##########    Log("set_cookie_string_no_expires='{}'".format(set_cookie_string_no_expires))
##########    return cookies_array
########    #https://docs.python.org/2/library/cookielib.html#cookielib.Cookie.is_expired
########    for cook in set_cookie_string_no_expires.split(', '):
########        if cook == '': break #in case blank cookie
##########        Log("cook='{}'".format(repr(cook)))
########        morsels = None
########        name=None
########        value=None
########        port=None
########        port_specified=False
########        domain=''
########        domain_specified=False
########        domain_initial_dot=False
########        path=''
########        path_specified=False
########        max_age=None
########        expire_date=None
########        comment=None
########        comment_url=None
########        discard=False #True if this is a session cookie
########        secure=True #True if cookie should only be returned over a secure connection
########        for morsel in cook.split('; '):
##########            morsel=morsel.rstrip(';') #in case a cookie has only name/value
##########            Log("morsel='{}'".format(repr(morsel)))
########
########            if not '=' in morsel:
########                ##single word value
########                pass ##I am ignoring these ones
########            
########            else:
########                #morsels = morsel.split("=")
########                morsels=[morsel[0: morsel.find("=")] , morsel[morsel.find("=")+len("="): (max(morsel.find(";"), len(morsel)))      ] ]
##########                Log(str(morsel.find("=")+len("=")))
##########                Log(str(morsel.find(";")))
##########                Log(str(max(morsel.find(";"), len(morsel))))
########                #Log("morsels='{}'".format(repr(morsels)))
########                if morsels[0].lower() == 'path':
########                    path=morsels[1]
########                    path_specified=True
########                elif morsels[0].lower() == 'max-age':
########                    max_age=morsels[1] #essentially same info as expires; written as seconds(from now, presumably)which means cookie is only good for current session
##########                    Log("morsel='{}'".format(repr(morsel)))
##########                    Log("morsels[1]='{}'".format(morsels[1]))
##########                    Log("max_age='{}'".format(max_age))
########                    max_age=int(max_age)
########                elif morsels[0].lower() == 'domain':
########                    domain=morsels[1]
########                    domain_specified=True
########                    if domain[0]=='.': domain_initial_dot = True
########                elif morsels[0].lower() == 'port':
########                    port=morsels[1]
########                    port_specified=True
########                elif morsels[0].lower() == 'comment':
########                    comment=morsels[1]
########                elif morsels[0].lower() == 'samesite':
########                    pass
########                elif morsels[0].lower() == 'comment_url':
########                    comment_url=morsels[1]
########                else:
########                    name=morsels[0]
########                    value=morsels[1]
########                    regex = "{}={};?.*?expires=([^;]+)".format(re.escape(name),re.escape(value))
##########                    Log(regex) 
########                    try:
########                        expire_date_arr= re.compile(regex, re.DOTALL | re.IGNORECASE).findall(set_cookie_string)
########                        if len(expire_date_arr)<1:
########                            #discard=True
########                            Log("Cant find exipre date for regex='{}'".format(regex))
########                            Log("morsel='{}'".format(morsel))
########                            Log("name='{}'".format(name))
########                            Log("value='{}'".format(value))
########                            Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
########                            Log("cook='{}'".format(cook))
########                            Log("set_cookie_string='{}'".format(set_cookie_string))
########                            Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
########
########                        else:
########                            expire_date = expire_date_arr[0]
########                            expire_date = expire_date.split(',')[1]
##########                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##########                            Log("(type(datetime.datetime.now())='{}'".format(type(datetime.datetime.now())))
##########                            Log("{}".format(datetime.datetime(1970,1,1).strftime("%a, %d %b %Y %H:%M:%S %Z")))
##########                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##########                            Log("expire_date='{}'".format(expire_date))
########
##########                            expire_formats = {"%a, %d-%b-%Y %H:%M:%S %Z"
##########                                              , "%a, %d-%b-%y %H:%M:%S %Z"
##########                                              , "%a, %d %b %Y %H:%M:%S %Z"
##########                                              , "%a, %d %b %y %H:%M:%S %Z" }
########                            expire_formats = { " %d-%b-%Y %H:%M:%S %Z"
########                                              ," %d-%b-%y %H:%M:%S %Z"
########                                              ," %d %b %Y %H:%M:%S %Z"
########                                              ," %d %b %y %H:%M:%S %Z" }
########
########                            for expire_format in expire_formats:
########                                try:
########                                    expire_date = datetime.datetime.strptime(expire_date, expire_format)
##########                                    Log("morsel='{}'".format(morsel))
##########                                    Log("Match on {}".format(expire_format)) 
########                                    expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
##########                                    Log("expire_date='{}' type={}".format(expire_date,type(expire_date)))  
########                                    break
########                                except TypeError:
##########                                    Log("TypeError") 
########                                    try:
########                                        expire_date = datetime.datetime(*(time.strptime(expire_date, expire_format)[0:6]))
##########                                      Log("Match on {} with bugfix ".format(expire_format)) 
########                                        expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
########                                        break
########                                    except:
##########                                        traceback.print_exc()
########                                        pass
########                                    
########                                except:
##########                                    traceback.print_exc()
########                                    pass
########                                
##########                                Log("(type(expire_date)='{}'".format(type(expire_date)))
##########                                if type(expire_date) == "<type 'datetime.datetime'>":
########
##########                            Log("final (type(expire_date)='{}'".format(type(expire_date)))
##########                            Log("final expire_date='{}'".format(expire_date))
########                            if not (type(expire_date) == type(0)):
########                                Log("Failed to convert expire_date='{}' using format '{}'".format(expire_date,expire_format))  
##########                                Log("expire_date='{}'".format(expire_date))  
##########                                Log("morsel='{}'".format(repr(morsel)))
##########                                Log("name='{}'".format(repr(name)))
##########                                Log("value='{}'".format(repr(value)))
##########                                Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##########                                Log("cook='{}'".format(cook))
##########                                Log("set_cookie_string='{}'".format(set_cookie_string))
##########                                Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
########                                expire_date = 0
########                                
########
########                    except:
########                        traceback.print_exc()
########                        Log("Error parsing expire value for cookie")
########                        Log("name='{}'".format(repr(name)))
########                        Log("value='{}'".format(repr(value)))
########                        Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
########                        Log("cook='{}'".format(cook))
########                        Log("set_cookie_string='{}'".format(set_cookie_string))
########                        Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
########                        if expire_date: #might have been set by maxage
########                            expire_date = 0
########                        pass
########                    
########        if max_age:
########            expire_date = max_age
########            
##########        discard=(isinstance(expire_date, int))
########        
########        ck = cookielib.Cookie(version=0,
########                      name=name,
########                      value=value,
########                      port=port,
########                      port_specified=port_specified,
########                      domain=domain,
########                      domain_specified=domain_specified,
########                      domain_initial_dot=domain_initial_dot,
########                      path=path,
########                      path_specified=path_specified,
########                      secure=secure,
########                      expires=expire_date,
########                      discard=discard,
########                      comment=comment,
########                      comment_url=comment_url,
########                      rest={},
########                      rfc2109=False)
##########        Log("cook='{}'".format(repr(cook)))
##########        Log("ck='{}'".format(repr(ck)))
########        cookies_array.append(ck)
########
########    #Log("cookies_array='{}'".format(cookies_array))
########                
########    return cookies_array

#__________________________________________________________________
#
def Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode):
    #helper function to make code look smaller
    # check for a minimum length; raise error if necessary; add item if not enough
    if len(info) < 1:
        label = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "No items")
        if not keyword == '':
            label += " for [COLOR {}]{}[/COLOR]".format(C.refresh_text_color,keyword)
        label +=  " on '{}'".format(ROOT_URL)
        addDir(
            name=label
            ,url=C.DO_NOTHING_URL
            ,mode=MAIN_MODE
            ,iconimage=C.not_found_icon
            )
        if testmode:
            raise OSError    
#__________________________________________________________________
#
def Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page):
    #helper function to make code look smaller
    inband_recurse = (keyword==C.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = C.MAX_RECURSE_DEPTH
    else:
        max_search_depth = C.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        addDir(
            name=C.STANDARD_MESSAGE_SEARCH
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon )
        addDir(
            name=C.STANDARD_MESSAGE_SEARCH_RECURSIVE
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon
            ,end_directory=False
            ,page=C.FLAG_RECURSE_NEXT_PAGES)


    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    Log("list_url={}".format(list_url))    

    return inband_recurse, end_directory, max_search_depth, list_url
#__________________________________________________________________
#
def Normalize_HD_String(hd):
    hd = hd.lower()
    if   ('2160'           in hd
          or 'uhd'         in hd
          or '4k'          in hd
          or '1440'        in hd): hd = C.STANDARD_MESSAGE_UHD
    elif ('class="fullhd"' in hd
          or 'fullhd'      in hd
          or 'full_hd'     in hd
          or    'fhd'      in hd
          or '1080'        in hd): hd = C.STANDARD_MESSAGE_FHD
    elif (   'class="hd"'  in hd
          or 'hd'          in hd
          or 'icon-hd'     in hd
          or '720'         in hd): hd = C.STANDARD_MESSAGE_HD
    else:                          hd = C.STANDARD_MESSAGE_NOHD

    return hd
#__________________________________________________________________
#

