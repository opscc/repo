# -*- coding: utf-8 -*-
import constants as C
import json
import utils
import traceback
import xbmc

from utils import Log
from utils import Log as log
from utils import Notify as notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

#__________________________________________________________________________
#
def addEuronewsIcon(plugin,play):
    channel = "PT Euronews"
    prog = "PT Euronews"

    liz = ListItem("[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
        C.channel_text_color
         , kodiutils.smart_str(channel)
         , C.program_text_color
         , kodiutils.smart_str(prog)
        )
    )

    img = "https://static.euronews.com/website/images/live.jpg"
    img = img + "|User-Agent=Mozilla/5.0 (MSIE 10.0; Windows NT 6.1; Trident/5.0)"
    liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
    finalurl=C.EURONEWS_BASE
    addDirectoryItem(plugin.handle
                     , plugin.url_for(
                         play
                           , rel_url=kodiutils.smart_str(finalurl)
                           , channel=kodiutils.smart_str(channel)
                           , img=kodiutils.smart_str(img)
                           , prog=kodiutils.smart_str(prog)
                         )
                     , liz
                     , False)
##    utils.Notify(msg="Error parsing EuronewsIcon main page", duration=4000)
#__________________________________________________________________________
#
def play_euronews(prog,rel_url,channel,icon):
    
    page_content = utils.getHtml("https://pt.euronews.com/api/watchlive.json")
    json_content = json.loads(page_content)
    Log("page_content='{}'".format(page_content))

    content_list_url = "https:" + json_content["url"]
    Log("content_list_url='{}'".format(content_list_url))

    page_content = utils.getHtml(content_list_url)
    json_content = json.loads(page_content)
    Log("page_content='{}'".format(page_content))

    m3u8_url = json_content["primary"] #"primary" #"backup"
    Log("m3u8_url='{}'".format(m3u8_url))

    Log("prog='{}'".format(prog.encode('utf8')))
    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog)
    url = m3u8_url + utils.Header2pipestring() 
    utils.playvid(url, name=name, play_profile="profile_02")
                        
#__________________________________________________________________________
#
