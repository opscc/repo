# -*- coding: utf-8 -*-

#import base libraries
import base64
import datetime
import json
import os
import re
import time
import traceback
import urllib
import xbmc
import xbmcgui
import xbmcplugin

#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

MODULE_NAME = __name__.split('.')[-1]#'methstreams'

BASE = "https://methstreams.com/"

CATEGORY_REGEX = (
    "<div class='clearfix'"
    ".+?<h2>(?P<category>.+?)</h2>"
    ".+?href='(?P<category_info>.+?)'"
    )
CHANNEL_REGION_REGEX = (
    "<hr>(.+?)<h2>Welcome to <b>"
    )
CHANNEL_INFO_REGEX = (
    "href='(?P<link>.+?)'"
    ".+?img src='(?P<icon>.+?)'"
    ".+?class='media-heading'>(?P<team>.+?)<"
    ".+?<p>(?P<dateinfo>.+?)<"
    )
LINK_INFO_REGEX = (
    'href="(?P<link>.+?)"'
    '.+?rel="noopener">(?P<broadcaster>.+?)</a>'
    )
STREAM_REGION_01 = '<div class="box">(.+)<div id="sidebar">'

try: cache_duration = int(utils.get_setting('html_cache_methstreams'))
except: cache_duration = 300



#__________________________________________________________________________
#
def add_icons(routing_plugin, play, subchannel='', subchannel_label='', sort_order=None, soccer_only=False):
    Log(repr((subchannel, subchannel_label, sort_order)))

    if not sort_order: sort_order = 1010.0
    else: sort_order = float(sort_order)
    
    #if not subchannel: return  #for this set, only allow specific channels
    
    try:
        
        icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon

##        with utils.global_mem_cache_lock: #lock permits a cached GET when this section is launched within multiple threads
##            json_info = utils.global_cache.get(C.addon_id+BASE)
##            if json_info and (len(json_info) > 0)  :
##                Log("using global_cache " + BASE)
##            else:
##                json_src = utils.getHtml(BASE + 'schedule/schedule-generated.json'  , cache_duration=cache_duration)
##                json_info = json.loads(json_src)


        full_html = utils.getHtml(BASE, cache_duration=cache_duration)

        match = re.compile(CATEGORY_REGEX,re.DOTALL).findall(full_html)
        Log(repr(match))

##        return
##        json_info = json.loads(json_src)


##        for category in json_info[json_info.keys()[0]]: #first item is a date which we can skip
        for category, url in match:
    
            if subchannel_label and (category != subchannel):
                continue
##            Log(url)
            if not url.startswith('http'):
                url = BASE+url
##            Log(repr((category,url)))
            
            #add a sub menu for the category with entries
            category_name = u"[COLOR {}][B]{}[/B][/COLOR]".format(
                C.refresh_text_color
                , category 
                )

            sorting_delta = 0.1
            sort_order += sorting_delta

            plugin_url = routing_plugin.url_for(
                    play
                    , filter_category=category
                    , rel_url = url
                    , channel = category
                    , prog = category
                    , img = ''
                    , module_name = __name__.split('.')[-1]
                    )

##                if subchannel_label:
##                    icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon
##                else:                
            icon = os.path.join(C.imgDir, ''.join(category.split(' '))+'.png') #strip any spaces in the lable to find icon
            if not os.path.isfile(icon):
                icon = os.path.join(C.imgDir, 'other.png')
                    
            utils.addPlaylink(
                routing_plugin
                ,playlink_name = category_name
                ,final_url = plugin_url
                ,program_name = category
                ,channel = category
                ,icon = icon 
                ,play = play
                ,module_name = __name__.split('.')[-1]
                ,rating = sort_order
                ,return_json_info = True
                ,is_folder = True
                ,filter_category = category
                )

    except:
        traceback.print_exc()


#__________________________________________________________________________
#
def Add_Icons_Rows(plugin, play, filter_category):
    Log(repr((play, filter_category)))

    try:

        full_html = utils.getHtml(filter_category, cache_duration=cache_duration)

        region_html = re.compile(CHANNEL_REGION_REGEX,re.DOTALL).findall(full_html)
        if region_html: region_html = region_html[0]
        else: region_html = ''
        match = re.compile(CHANNEL_INFO_REGEX,re.DOTALL).findall(region_html)
        Log(repr(match))

        for url, icon, teams, dateinfo in match:

            sorting_delta = 0
            sorting_base = 3

##            Log(dateinfo)
            try:
                di = datetime.datetime.strptime(dateinfo,'%I:%M %p ET - %m/%d/%Y' )
                dateinfo = datetime.datetime.strftime(di, '%Y-%m-%d %H:%M')
                dateinfo = datetime.datetime.strftime(di, '%H:%M')
            except:
                try:
                    di = datetime.datetime.strptime(dateinfo,'%I:%M %p ET' )
                    dateinfo = datetime.datetime.strftime(di, '%H:%M')
                except:
##                    traceback.print_exc()
                    #datetime.datetime(*(time.strptime(t_time, '%d %m %Y %H:%M')[0:6]))
                    pass
                    
            time_and_teams_name = u"  [COLOR {}]{}[/COLOR] [COLOR {}]{}[/COLOR]".format(
                 C.time_text_color
                , dateinfo
                , C.highlight_text_color
                , teams
                )

            sorting_delta = sorting_delta + 1

            list_item = xbmcgui.ListItem(
                label=time_and_teams_name
                )
            rating = sorting_base+sorting_delta
            #list_item.setArt({"thumb":    os.path.join(C.imgDir, category+'.png')  })
            if icon:
                icon = filter_category + icon#.strip('/')
                list_item.setArt({"thumb":    icon  })
##                Log(icon)
            list_item.setInfo(type="video"
                              , infoLabels={
                                    "sorttitle": "a{:0>10}".format(int(rating))
                                    ,"playcount":"0" #remove the filled in circle from our skin
                                           }
                              )
            xbmcplugin.addDirectoryItem(
                handle=plugin.handle
                , url=''
                , listitem=list_item
                , isFolder=True
            )

####                    Log(repr(event))
##            for link in ['channel1','channel2']:
##
##                channel_name = channel_id = None
##
##                #sometimes data is a list, other times a numbered array
##                if type(link) is dict:
##                    if not (u'channel_id' in link):
##                        continue #sometimes there is a blank entry
##                    channel_name = link[u'channel_name']
##                    channel_id = link[u'channel_id']
##                else:
##                    #note: the json parser in py2 may reorder the array differently
##                    #  ie.  source data is (0, 1, ... 11, 12) but parsed as (11, 12 ... 1, 0, 2)
##                    link3 = event[u'channels'][link]
##                    if not (u'channel_id' in link3):
##                        continue #sometimes there is a blank entry
##                    channel_name = link3[u'channel_name']
##                    channel_id = link3[u'channel_id']
##                                                
##                if channel_name and channel_id:
##            playlink_name = u"      [COLOR {}]{}[/COLOR]".format(
##                C.program_text_color
##                ,channel_name + ' channel ' + channel_id
##                )
##
##            plugin_url = plugin.url_for(
##                    play
##                    , filter_category=filter_category
##                    , rel_url = url
##                    , channel = filter_category
##                    , prog = filter_category
##                    , img = icon
##                    , module_name = MODULE_NAME
##                    )
##            Log(url)
            utils.addPlaylink(
                plugin
                ,playlink_name = teams
                ,final_url = url
                ,program_name = time_and_teams_name
                ,channel=MODULE_NAME
                ,icon= icon
                ,play=play
                ,module_name=MODULE_NAME
                ,rating=str(sorting_base+sorting_delta) #lower value is on top in sort ascending
                ,return_json_info = False
                ,is_folder = False
                ,filter_category = ''
                )

    except:
        traceback.print_exc()

#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile,download=None):
    Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}', download='{}'".format(
        prog,playmode_string,play_profile,rel_url,channel,icon,download)
        ,C.LOGNONE
        )

    if download:
        download_filespec = utils.get_setting('download_folder')
        if not download_filespec: download_filespec = None
    else:
        download_filespec = None
##    Log(repr(download_filespec))
        
    headers = {
                'Accept'  : '*/*'
                ,"Connection": "keep-alive"
                ,"Accept-Encoding":"gzip"
                ,"User-Agent":'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
              }
    
                
    m3u8_url = rel_url #2024-10-07

    name = "{}".format(
         prog
         )


    full_html = utils.getHtml(rel_url, headers=headers)
    IFRAME_REGEX = (
        '<iframe width="100%" height="100%" src="(.+?)"'
        )
    match = re.compile(IFRAME_REGEX,re.DOTALL).findall(full_html)
    Log(repr(match))
    if not match: return
    match = match[0]

    ref = "{}://{}".format(utils.urlparse.urlparse(match).scheme, utils.urlparse.urlparse(match).netloc)

##    Log(ref)
##    return
    headers = {
               "Referer" : ref
               , "Origin" : ref
                ,'Accept'  : '*/*'
                ,"Connection": "keep-alive"
                ,"Accept-Encoding":"gzip"
                ,"User-Agent":'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
              }
    


    full_html = utils.getHtml(match, headers = headers, cache_duration=cache_duration)
    M3U8_REGEX = (
        '<source src="(.+?)"'
        )
    match = re.compile(M3U8_REGEX,re.DOTALL).findall(full_html)
    Log(repr(match))
    if not match: return

    url = match[0] + utils.Header2pipestring(headers)

    if not playmode_string:
        #playmode_string = C.PLAYMODE_INPUTSTREAM
        playmode_string = C.PLAYMODE_DIRECT #2024-10 ...but direct now works! ;/
    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    if download:
        prog = re.sub("(?:\[COLOR \w+\]\d+:\d+\[/COLOR\]|\[COLOR \w+\]|\[/COLOR\])", "", prog).strip(' ')
        dt = datetime.datetime.now().strftime('%Y-%m-%d')
        name = u"{}.{}.{}".format(prog, dt, name)

    Log(url)
    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download=download
        , download_filespec=download_filespec
    )

    return True
#__________________________________________________________________________
#
