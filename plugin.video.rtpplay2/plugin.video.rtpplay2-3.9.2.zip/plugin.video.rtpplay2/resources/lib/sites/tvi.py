# -*- coding: utf-8 -*-

#import base libraries
import datetime
import json
import re
import threading 
import traceback
import xbmc
#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

TVI_BASE = "https://tviplayer.iol.pt"

#__________________________________________________________________________
#
def add_icons(plugin, play, subchannel='', subchannel_label='', sort_order=None):
##    Log(repr((subchannel,subchannel_label,sort_order)))

    if not subchannel: return  #for this set, only allow specific channels
    sub_url = "/direto/"

    if not sort_order: sort_order = 5.0
    else: sort_order = float(sort_order)
        

    #use cached HTML to create icons
#    for channel in CHANNEL_LIST:
    try:

    ##    return json.loads("[]")  #testing
        json_info = utils.global_cache.get(C.addon_id + TVI_BASE + sub_url + subchannel)
    ##    json_items = None #testing
        if json_info and (len(json_info) > 0)  :
            Log("using global_cache tvi")
            #return json_info
        else:
            html_src = utils.getHtml(TVI_BASE + sub_url + subchannel)
            regex = "jsonData = (.+?});"
            html_text = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html_src)
            if not html_text: html_text = 'not found...error'
            json_info = json.loads(html_text[0])

            utils.global_cache.set(
                endpoint = (C.addon_id + TVI_BASE + sub_url + subchannel)
                ,data = json_info
                ,expiration = datetime.timedelta(seconds=C.default_GETHTML_cache_duration)
                )
            


        json_video_info = json_info["videoUrl"]
        final_url = json_video_info            
        program_name = json_info["program"]["name"]

        playlink_name = "[COLOR {}][B]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
            C.channel_text_color
            , subchannel.encode('utf8')
            , C.program_text_color
            , program_name.encode('utf8')
            )

        utils.addPlaylink(
            plugin
            ,playlink_name
            ,final_url
            ,program_name
            #,channel
            ,subchannel
            ,icon=json_info["cover"]
            ,play=play
            ,module_name=__name__.split('.')[-1]
            ,rating=sort_order #lower value is on top in sort ascending
            ,return_json_info = True
            ,is_folder = False
            ,filter_category = ''
##            ,db_connection = db_connection
            )

    except:
        traceback.print_exc()
        
#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile):
#Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(prog,playmode_string,play_profile,rel_url,channel,icon))

    tviheaders = {"Origin":"http://tviplayer.iol.pt"
                  ,"Referer":"http://tviplayer.iol.pt/direto"
                  ,"Accept-Encoding":"gzip"
                  ,"User-Agent":"Mozilla/13.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
                  }
    page_content = rel_url
    
    #2019-03-30 - ...and a second call to get a user id is required
    matrix_userId = utils.getHtml("https://services.iol.pt/matrix?userId=",headers=tviheaders)

    m3u8_url = page_content+"?wmsAuthSign="+matrix_userId

    name = "[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog)
    url = m3u8_url + utils.Header2pipestring(tviheaders)

    if not playmode_string:
        playmode_string = C.DEFAULT_PLAYMODE

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
    )

    return True
#__________________________________________________________________________
#
