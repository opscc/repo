# -*- coding: utf-8 -*-

#import base libraries
import base64
import datetime
import os
import re
import traceback
#import internal addon libraries
import utils
import player
#define frequenctly used aliases
import constants as C
from utils import Log,LogR,Notify



MODULE_NAME = __name__.split('.')[-1]#'methstreams'

##BASE = "https://methstreams.com/"
BASE = "https://methstreams.cx/"

CATEGORY_REGEX = (
    "<div class='clearfix'"
    ".+?<h2>(?P<category>.+?)</h2>"
    ".+?href='(?P<category_info>.+?)'"
    )
CHANNEL_REGION_REGEX = (
    "<hr>(.+?)<h2>Welcome to <b>"
    )
CHANNEL_INFO_REGEX = (
    "href='(?P<link>.+?)'"
    ".+?img src='(?P<icon>.+?)'"
    ".+?class='media-heading'>(?P<team>.+?)<"
    ".+?<p>(?P<dateinfo>.+?)<"
    )
LINK_INFO_REGEX = (
    'href="(?P<link>.+?)"'
    '.+?rel="noopener">(?P<broadcaster>.+?)</a>'
    )
STREAM_REGION_01 = '<div class="box">(.+)<div id="sidebar">'

IFRAME_REGEX = (
    '(?:<iframe width="100%" height="100%"|<video id="player_one").+?src="(.+?)"'
    )
    
try: cache_duration = int(utils.get_setting('html_cache_methstreams'))
except: cache_duration = 300

MAIN_MODE          = C.MAIN_MODE_methstreams
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
LIST_ROW_MODE      = str(int(MAIN_MODE) + 6)

DEFAULT_SORT_ORDER = 1010.0

#__________________________________________________________________________
#
##def add_icons(routing_plugin
##              , play
##              , subchannel=''
##              , subchannel_label=''
##              , sort_order=DEFAULT_SORT_ORDER
##              , soccer_only=False
##              ):
@C.url_dispatcher.register(LIST_MODE)
def add_icons(
                subchannel = u''
              , subchannel_label = u''
              , sort_order = DEFAULT_SORT_ORDER
              , cache_as_json = False
              , testmode = False
              , end_directory = False):
    Log(repr(locals()))

    if not sort_order: sort_order = DEFAULT_SORT_ORDER
    else: sort_order = float(sort_order)
    
    #if not subchannel: return  #for this set, only allow specific channels
    
    try:
        
        icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon


        with utils.global_mem_cache_lock:
            full_html = utils.getHtml(BASE, cache_duration=cache_duration)

        match = re.compile(CATEGORY_REGEX,re.DOTALL).findall(full_html)
        Log(repr(match))

        for category, url in match:
    
            if subchannel_label and (category != subchannel):
                continue
            if not url.startswith('http'):
                url = BASE+url
            
            #add a sub menu for the category with entries
            category_name = u"[COLOR {}][B]{}[/B][/COLOR]".format(
                C.refresh_text_color
                , category 
                )

            sorting_delta = 0.1
            sort_order += sorting_delta

            plugin_url = routing_plugin.url_for(
                    play
                    , filter_category=category
                    , rel_url = url
                    , channel = category
                    , prog = category
                    , img = ''
                    , module_name = __name__.split('.')[-1]
                    )

##                if subchannel_label:
##                    icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon
##                else:                
            icon = os.path.join(C.imgDir, ''.join(category.split(' '))+'.png') #strip any spaces in the lable to find icon
            if not os.path.isfile(icon):
                icon = os.path.join(C.imgDir, 'other.png')
                    
            utils.addPlaylink(
                routing_plugin
                ,playlink_name = category_name
                ,final_url = plugin_url
                ,program_name = category
                ,channel = category
                ,icon = icon 
                ,play = play
                ,module_name = __name__.split('.')[-1]
                ,rating = sort_order
                ,return_json_info = True
                ,is_folder = True
                ,filter_category = category
                )

    except:
        traceback.print_exc()

#
#
@C.url_dispatcher.register(PLAY_MODE, ['icon_label','url'], ['channel', 'program_name', 'icon', 'playmode_string', 'play_profile','download', 'testmode'])
def play( icon_label
         ,url
         ,channel=None
         ,program_name=u''
         ,icon=None
         ,playmode_string=None
         ,play_profile=None
         ,download=None
         ,testmode=False):
    Log(u"icon_label='{}',playmode_string='{}',play_profile='{}',url='{}',channel='{}',icon_URI='{}', download='{}'".format(
        icon_label,playmode_string,play_profile,url,channel,icon,download)
        ,C.LOGNONE
        )
    
    download = bool(download)
    testmode = bool(testmode)
    
    download_filespec = None
    if download:
        dt = datetime.datetime.now().strftime('%Y-%m-%d')
        d_name = u"{}.{}.{}.ts".format(utils.Clean_Filename(icon_label), utils.Clean_Filename(icon_label).strip(' '), dt)
        download_filespec = utils.get_setting('download_path')
        if not download_filespec:
            download_filespec = None
        else:
            download_filespec = os.path.join(download_filespec, d_name)
            
    #
    #f4mproxy defaults
    #
    if not playmode_string:
        playmode_string = C.DEFAULT_PLAYMODE
    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_02

            
    name = "{}".format(
         prog
         )

    headers = {
                'Accept'  : '*/*'
                ,"Connection": "keep-alive"
                ,"Accept-Encoding":"gzip"
                ,"User-Agent":'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
              }
    
    m3u8_url = rel_url #2024-10-07
    
    full_html = utils.getHtml(rel_url, headers=headers)
    match = re.compile(IFRAME_REGEX,re.DOTALL).findall(full_html)
    Log(repr(match))
    if match: match = match[0]
    else: return

    ref = "{}://{}".format(utils.urlparse.urlparse(match).scheme, utils.urlparse.urlparse(match).netloc)
    headers = {
               "Referer" : ref
               , "Origin" : ref
                ,'Accept'  : '*/*'
                ,"Connection": "keep-alive"
                ,"Accept-Encoding":"gzip"
                ,"User-Agent":'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
              }
    
    full_html = utils.getHtml(match, headers = headers, cache_duration=cache_duration)
    M3U8_REGEX_1 = (
        '<source src="(.+?)"'
        )
    match = re.compile(M3U8_REGEX_1,re.DOTALL).findall(full_html)
##    Log(repr(match))
    if match: link1_url = match[0]
    else: link1_url = None

    if not link1_url:
        M3U8_REGEX_2 = (
            'source: window.atob\("(.+?)"'
            )
        match = re.compile(M3U8_REGEX_2,re.DOTALL).findall(full_html)
##        Log(repr(match))
        if match:
            link1_url = match[0]
            try:
                link1_url = base64.b64decode(link1_url)
            except:
                pass
        else: return
    

    hosts = []
    hosts.append(link1_url)


    LINK2_REGEX = (
        '<b>Link #1</b>'
        '.+?href="(?P<link>.+?)"><b>'
        )
    link2_url = re.compile(LINK2_REGEX,re.DOTALL).findall(full_html)
    Log(repr(link2_url))
    if link2_url:
        full_html = utils.getHtml(link2_url[0], headers = headers, cache_duration=cache_duration)
        match = re.compile(M3U8_REGEX_1,re.DOTALL).findall(full_html)
        Log(repr(match))
        if match:
            hosts.append(match[0])

    Log(repr(hosts))

    if len(hosts) > 1:
        vh = C.xbmcgui.Dialog().select('Videohost:', hosts)
        if vh == -1: return
    else:
        vh = 0
    url = hosts[vh]
    url = url + utils.Header2pipestring(headers)

    Log(url)
##    return

    if not playmode_string:
        #playmode_string = C.PLAYMODE_INPUTSTREAM
        playmode_string = C.PLAYMODE_F4MPROXY
    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    if download:
        prog = re.sub("(?:\[COLOR \w+\]\d+:\d+\[/COLOR\]|\[COLOR \w+\]|\[/COLOR\])", "", prog).strip(' ')
        dt = datetime.datetime.now().strftime('%Y-%m-%d')
        name = u"{}.{}.{}".format(prog, dt, name)

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download=download
        , download_filespec=download_filespec
    )

    return True
###__________________________________________________________________________
### Unit tests
@C.url_dispatcher.register(TEST_MODE)
def TEST_MODE():
    test_label = ""
    module_name = __name__.split('.')[-1]
    try:
        #todo: figure out some tests
        pass
    except Exception as e:
        traceback.print_exc()
        raise Exception(test_label)
#__________________________________________________________________________
#
