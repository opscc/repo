# -*- coding: utf-8 -*-

#import base libraries
import datetime
import json
import os
import re
import traceback
#import internal addon libraries
import utils
import player
#define frequenctly used aliases
import constants as C
from utils import Log,LogR,Notify

MAIN_MODE          = C.MAIN_MODE_fatima
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
LIST_ROW_MODE      = str(int(MAIN_MODE) + 6)

DEFAULT_SORT_ORDER = 70.0

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE)
def add_icons(
                subchannel = u''
              , subchannel_label = u''
              , sort_order = DEFAULT_SORT_ORDER
              , cache_as_json = False
              , testmode = False
              , end_directory = False):
    LogR(
        locals()
        ,C.LOGWARNING
        )
    
##    channel = u"Fatima"
##    program_name = u"Fatima"
    if C.PY2:
        if not isinstance(subchannel_label, C.text_type):
            subchannel_label = subchannel_label.decode('utf8')
##    subchannel = subchannel.replace('Ymu8JZMWqD0', 'sN837AyNVcU')

    subchannel = subchannel.replace('GENH9mWlvb4', '8Rzq8IlqaGE') #caplellinha 2026-10
    subchannel = subchannel.replace('Ymu8JZMWqD0', 'HN8vhpcFKqg') #Santuário 2026-10


    
    if not sort_order: sort_order = DEFAULT_SORT_ORDER
    else: sort_order = float(sort_order)

    icon_label = u"[COLOR {}][B]{}[/B][/COLOR]".format(
        C.channel_text_color
         , subchannel_label
        )
    icon="https://i.ytimg.com/vi/WkhCfPPgqWc/maxresdefault_live.jpg"
    #sometimes this value is decteced from some sort of home page; but for this site we only create a stub icon
    playable_url =  C.DO_NOTHING_URL

    utils.Add_Listitem(
        mode = PLAY_MODE
        ,icon_label = icon_label
        ,url = playable_url
        ,program_name = subchannel_label
        ,channel = subchannel
        ,icon = icon
        ,module_name = __name__.split('.')[-1]
        ,rating = sort_order
        ,playmode_string = u''
        ,play_profile = u''
        ,testmode = testmode
        ,cache_as_json = cache_as_json
        ,is_folder = False
        )

    return playable_url

###__________________________________________________________________________
###
@C.url_dispatcher.register(
    PLAY_MODE
    , ['icon_label','url']
    , ['channel', 'program_name'
       , 'icon', 'playmode_string'
       , 'play_profile','download'
       , 'testmode']
    )
def play( icon_label
         ,url
         ,channel=None
         ,program_name=u''
         ,icon=None
         ,playmode_string=None
         ,play_profile=None
         ,download=None
         ,testmode=False):

    LogR(  locals()
           ,C.LOGWARNING
         )
    
##    Log(u"icon_label='{}',playmode_string='{}',play_profile='{}',url='{}',channel='{}',icon_URI='{}', download='{}'".format(
##        icon_label,playmode_string,play_profile,url,channel,icon,download)
##        ,C.LOGNONE
##        )
    
    download = bool(download)
    testmode = bool(testmode)


##    LogR(program_name,C.LOGERROR)
    if C.PY2:
        if not isinstance(program_name, C.text_type):
            program_name = program_name.decode('utf8')
        if not isinstance(icon_label, C.text_type):
            icon_label = icon_label.decode('utf8')
            

##    LogR(program_name,C.LOGERROR)
##    return
    download_filespec = None
    if download:
        dt = datetime.datetime.now().strftime('%Y-%m-%d')
        d_name = u"{}.{}.{}.ts".format(utils.Clean_Filename(icon_label), utils.Clean_Filename(icon_label).strip(' '), dt)
        download_filespec = utils.get_setting('download_path')
        if not download_filespec:
            download_filespec = None
        else:
            download_filespec = os.path.join(download_filespec, d_name)
            
    #
    #f4mproxy defaults
    #
    if not playmode_string:
        playmode_string = C.DEFAULT_PLAYMODE
    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_02

    if program_name: program_name = u" ({})".format(program_name)
    name = u"[COLOR {}][B]{}[/COLOR]{}".format(
        C.channel_text_color
        , icon_label
        , program_name
        )
    

####    #find out what the current ID is for youtube-hosted content
####    full_html = utils.getHtml("https://www.fatima.pt/en/pages/online-transmissions")
####    #src="https://www.youtube.com/embed/WkhCfPPgqWc"   #2024-06-30
####    regex = 'src="(https://www.youtube.com/embed/.+?)"'
####    youtube_embed_url=re.compile(regex).findall(full_html)[0]
####    full_html = utils.getHtml(youtube_embed_url)
####    regex = (
####        r'ytcfg\.set\((.+?)\);window.ytcfg.obfuscatedData_'
####        ) #2021-11
####    json_html = re.compile(regex).findall(full_html)
####    if json_html: json_html = json_html[0]
####    else: json_html = "{}"
####    
####    json_content = json.loads(json_html)
####    youtube_embed_url = "https://www.youtube.com/youtubei/v1/player?key=" + json_content["INNERTUBE_API_KEY"]
####
####    headers = {
####    'User-Agent':'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36'
####    ,'Accept':'text/html,application/xhtml+xml,application/xml,image/jpeg,*.*;q=0.9'
####    ,'Accept-Encoding':'gzip, deflate'
####    ,'Accept-Language':'en-US,en;q=0.9'
####    }
####
####    hls_header = 'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36'
####    hls_header = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.36 Safari/537.36'
####    post_json = (
####        '{"videoId":"'+json_content["VIDEO_ID"]+'"'
####        ',"playbackContext":{},"captionParams":{}'
####        ',"context":{'
####        '         "client":'
######        '                  {"clientName":"' + json_content["INNERTUBE_CLIENT_NAME"] +  '"'
####        '                  {"clientName":"' + 'WEB' +  '"'
####
####        '                  ,"clientVersion":"'+json_content["INNERTUBE_CLIENT_VERSION"]+ '"}'
####        '         ,"user":{}'
####        '         ,"adSignalsInfo":{"params":[] }'
####        ' } } '
####    )
####    json_html = utils.postHtml(youtube_embed_url, sent_data=post_json,headers=headers)
####    json_content = json.loads(json_html)
####    m3u8_url = json_content['streamingData']['hlsManifestUrl']


    m3u8_url = utils.Get_Youtube_Url(channel)
    
    video_url = m3u8_url + utils.Header2pipestring()

    #
    #f4mproxy defaults
    #
    if not playmode_string:
        #2026-07 youtube now needs to be fmproxy or inputstream
        playmode_string = C.DEFAULT_PLAYMODE 
        #playmode_string = C.PLAYMODE_INPUTSTREAM
    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_02
   #
    #what to do if we are just testing
    #
    if testmode:
        Log(repr(( "warning TESTMODE:"
                    , video_url
                    , icon_label
                    , playmode_string
                    , play_profile
                    , download
                    , download_filespec
                  )))
        utils.getHtml(m3u8_url)
        utils.endOfDirectory(end_directory=False)
        return

    #
    #what to do if we are serious
    #
    player.playvid(
        video_url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download = download
        , download_filespec=download_filespec
    )


#__________________________________________________________________________
# Unit tests
@C.url_dispatcher.register(TEST_MODE)
def TEST_MODE():
    test_label = ""
    module_name = __name__.split('.')[-1]
    try:
        test_label = u'{}€ download html and add all categories'.format(module_name)
        playable_url = add_icons(
            subchannel = u'fatima€'
          , subchannel_label = u''
          , testmode = True
          )
        Log(playable_url)

        test_label = u'play first {}€ category'.format(module_name)
        play(test_label
             , playable_url
             , testmode=True)

        test_label = u'{}€ proxy profile 3'.format(module_name)
        play(icon_label = test_label
             , url = playable_url
             , playmode_string = C.PLAYMODE_F4MPROXY
             , play_profile = C.PLAYMODE_PROFILE_03
             , testmode = True
             )

        test_label = u'{}€ imputstream'.format(module_name)
        play(  icon_label = test_label
             , url = playable_url
             , playmode_string = C.PLAYMODE_INPUTSTREAM
             , testmode = True
             )

        test_label = u'{}€ download'.format(module_name)
        play(
             url =  playable_url
             , icon_label = test_label
             , download = True
             , testmode = False
             )

    except Exception as e:
        traceback.print_exc()
        raise Exception(test_label)
        

    
#__________________________________________________________________________
#

