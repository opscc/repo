# -*- coding: utf-8 -*-
import os
import routing
import sys
import timeit
import traceback
import utils
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import constants as C
from utils import Log as log
from utils import Log

routing_plugin = routing.Plugin()

###with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
##xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_INPUTSTREAM)
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________
#
@routing_plugin.route('/'+C.REFRESH_CONTAINER_MODE)
def RefreshContainter():
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
@routing_plugin.route('/')
def index():

    try:
        if utils.get_setting('list_tvi'):
            import tvi
            tvi.addTVIIcons(routing_plugin, play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding TVI", duration=4000)

    try:
        if utils.get_setting('list_sportsdaddy'):
            import sportsdaddy
            sportsdaddy.Add_Icons_Category(routing_plugin, sportsrows, True)
##            Log(repr(timeit.timeit(
##                "sportsdaddy.Add_Icons_Category(routing_plugin, sportsrows, True)"
##                , number=1
##                )
##                     ))
                


            channel = 722
            plugin_url = 'plugin://plugin.video.rtpplay2/play?&channel=sportsdaddy&prog=SIC&img=%2F&rel_url=%2Fstream-'+str(channel)+'.php'
            list_item = xbmcgui.ListItem(
                label='[B][COLOR {}]SIC[/COLOR][/B]'.format(
                        C.channel_text_color
                    )
                )
            list_item.setArt({"thumb":    os.path.join(C.imgDir, 'sic.png')  }) 
            list_item.setProperty('IsPlayable', 'true')
            list_item.setInfo(type="Video", infoLabels={"country": "Portugal"
                                                        #,"duration":"99999"
                                                        ,"playcount":"0" #remove the filled in circle from our skin
                                                        })

            xbmcplugin.addDirectoryItem(
                handle=routing_plugin.handle
                , url = plugin_url
                , listitem=list_item
                , isFolder=False
            )
            
            channel = 719
            plugin_url = 'plugin://plugin.video.rtpplay2/play?&channel=sportsdaddy&prog=SIC&img=%2F&rel_url=%2Fstream-'+str(channel)+'.php'
            list_item = xbmcgui.ListItem(
                label='[B][COLOR {}]RTP 1[/COLOR][/B]'.format(
                        C.channel_text_color
                    )
                )
            list_item.setArt({"thumb":    os.path.join(C.imgDir, 'rtp1.png')  }) 
            list_item.setProperty('IsPlayable', 'true')
            list_item.setContentLookup(False)
            list_item.setInfo(type="Video", infoLabels={"country": "Portugal"
                                                        #,"duration":"99999"
                                                        ,"playcount":"0" #remove the filled in circle from our skin
                                                        })
            xbmcplugin.addDirectoryItem(
                handle=routing_plugin.handle
                , url = plugin_url
                , listitem=list_item
                , isFolder=False
            )
            
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding sportsdaddy", duration=4000)
        
    try:
        if utils.get_setting('list_euronews'):
            import euronews
            euronews.addEuronewsIcon(routing_plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Euronews", duration=4000)

    try:
        if utils.get_setting('list_fatima'):
            import fatima
            fatima.addFatimaIcon(routing_plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Fatima", duration=4000)
    try:
        if utils.get_setting('list_rtp'):
            import rtp
            rtp.addRTPicons(routing_plugin,play)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding RTP icons", duration=4000)

    try:
        if utils.get_setting('list_sportsdaddy'):
            import sportsdaddy
            sportsdaddy.Add_Icons_Category(routing_plugin, sportsrows, False)
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding sportsdaddy", duration=4000)
        
    try:
        list_item = xbmcgui.ListItem(
            label='[B][COLOR {}]Refresh[/COLOR][/B]'.format(C.time_text_color)
            )
        xbmcplugin.addDirectoryItem(
            handle=routing_plugin.handle
            , url=routing_plugin.url_for(
                RefreshContainter
            )
            , listitem=list_item
            , isFolder=False
        )
    except:
        traceback.print_exc()


    try:

        liz = xbmcgui.ListItem(
            label='[B][COLOR {}]Settings[/COLOR][/B]'.format(C.highlight_text_color)
            ,iconImage=C.default_icon
            ,thumbnailImage=C.default_icon 
            )
        xbmcplugin.addDirectoryItem(
            handle=routing_plugin.handle
            , url=routing_plugin.url_for(
                configure_THIS_addon
            )
            , listitem=liz
            , isFolder=False
        )
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Configuration icon", duration=2000)


    utils.endOfDirectory()

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_THIS_ADDON)
def configure_THIS_addon():
    xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    import xbmcaddon
    xbmcaddon.Addon(id=C.addon_id).openSettings()
    #utils.endOfDirectory()
    return True
#__________________________________________________________________________
#
@routing_plugin.route('/play')
def play():

    #Log(repr(sys.argv))
    #Log(repr(routing_plugin.args))

    rel_url = routing_plugin.args["rel_url"][0]
##    Log(rel_url)
##    Log(rel_url.encode('utf8').decode('utf8'))
    channel = routing_plugin.args["channel"][0]
    prog = routing_plugin.args["prog"][0]
    icon = routing_plugin.args["img"][0]
    if "playmode_string" in routing_plugin.args:      playmode_string = routing_plugin.args["playmode_string"][0]
    else:          playmode_string = None
    if "play_profile" in routing_plugin.args:         play_profile = routing_plugin.args["play_profile"][0]
    else:         play_profile = None

##    Log(prog)
##    Log(unicode(type(rel_url)))
##    Log(rel_url)
    if '\\x' in prog:
        #Log(prog.decode('unicode-escape').encode('utf8'))
        prog = prog.decode('unicode-escape').encode('utf8')
    if '\\x' in channel:
        #Log(prog.decode('unicode-escape').encode('utf8'))
        channel = channel.decode('unicode-escape').encode('utf8')
    if '\\x' in rel_url:
        rel_url = rel_url.decode('unicode-escape').encode('utf8')
        
    
    #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen

    import tvi
    for sub_channel in tvi.CHANNEL_LIST:
        #Log(repr(sub_channel))
        if channel.startswith(sub_channel):
            tvi.play_tvi(prog,rel_url,channel,icon,playmode_string,play_profile)
            return True
    if prog == "PT Euronews":
        import euronews
        euronews.play_euronews(prog,rel_url,channel,icon,playmode_string,play_profile)
    elif prog == "Fatima":
        import fatima
        fatima.play_fatima(prog,rel_url,channel,icon,playmode_string,play_profile)
    elif channel.startswith('RTP'):
        import rtp
        rtp.play_rtp(prog,rel_url,channel,icon,playmode_string,play_profile)
    elif channel.startswith('sportsdaddy'):
        import sportsdaddy
        sportsdaddy.play(prog,rel_url,channel,icon,playmode_string,play_profile)

    return True
#__________________________________________________________________________
#
        
@routing_plugin.route('/sportsrows')
def sportsrows():
    try:
        filter_category = routing_plugin.args["filter_category"][0]
        import sportsdaddy
        sportsdaddy.Add_Icons_Rows(routing_plugin, play, filter_category)
        utils.endOfDirectory()
    except:
        traceback.print_exc()
#__________________________________________________________________________
#
