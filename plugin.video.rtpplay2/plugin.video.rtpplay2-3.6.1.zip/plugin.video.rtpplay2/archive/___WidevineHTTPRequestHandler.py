# -*- coding: utf-8 -*-
import BaseHTTPServer
import urlparse
import base64
import traceback
import xbmc,xbmcaddon
import json
from Widevine import Widevine
wv = Widevine()
this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
addon_name = this_addon.getAddonInfo('name')
def log(msg="", loglevel=None):
    debug = None
    try: debug = (this_addon.getSetting('debug').lower() == "true")
    except: debug = True
    msg = "{}: {}".format(addon_id, msg).encode('utf-8')
    if   loglevel:  xbmc.log(msg , loglevel)
    elif    debug:  xbmc.log(msg , xbmc.LOGNONE)
    else:           xbmc.log(msg)

class WidevineHTTPRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200)
    def log_message(self, format, *args):
        return #"""Disables the BaseHTTPServer log."""

    def do_POST(self):
        length = int(self.headers['content-length'])
        wv_challenge = self.rfile.read(length)
        log("WidevineHTTPRequestHandler - wv_challenge - '{}'".format(repr(wv_challenge)))
        query = dict(urlparse.parse_qsl(urlparse.urlsplit(self.path).query, keep_blank_values=True))
        mpd_url = query['mpd_url']
        log("WidevineHTTPRequestHandler - mpd_url: %s" % mpd_url)
        token = base64.b64decode(query['token'])
        log("WidevineHTTPRequestHandler - token: %s" % token)
        if not query['headers'] == None:               mpdheaders = query['headers']
        if mpdheaders:                                 mpdheaders = base64.b64decode(query['headers'])
        log("WidevineHTTPRequestHandler - mpdheaders: %s" % mpdheaders)
        mpdheaders = json.loads(mpdheaders)
        try:
            wv_license = wv.get_license(mpd_url, wv_challenge, token, mpdheaders)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(wv_license)
            self.finish()
        except Exception as ex:
            log("WidevineHTTPRequestHandler - ERROR: %s" % ex)
            traceback.print_exc()
            self.send_response(400)
            self.wfile.write(ex.message)

