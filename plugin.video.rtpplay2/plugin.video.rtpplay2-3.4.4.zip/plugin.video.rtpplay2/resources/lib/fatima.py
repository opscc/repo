# -*- coding: utf-8 -*-
import constants as C
import json
import re
import utils
import traceback
import xbmc

from utils import Log
from utils import Log as log
from utils import Notify as notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

#__________________________________________________________________________
#
def addFatimaIcon(plugin, play):
    channel = "Fatima"
    prog = "Fatima"

    full_html = utils.getHtml("https://www.fatima.pt/en/pages/online-transmissions")
    
    list_item = ListItem("[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
        C.channel_text_color
        , channel.encode('utf8')
        , C.program_text_color
        , prog.encode('utf8')
        )
    )
    
    match=re.compile('(?s)playhtml\?file=(.+?)\".+?embed\/+([^\"]+)\"').findall(full_html) #pre 2019-05-12 [double / added by site]
    for rel_url, img in match:
        img = "https://i.ytimg.com/vi/" + img + "/maxresdefault_live.jpg"
        list_item.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
        addDirectoryItem(
            plugin.handle
            , plugin.url_for(
                play
                , rel_url=kodiutils.smart_str(rel_url)
                , channel=kodiutils.smart_str(channel)
                , img=kodiutils.smart_str(img)
                , prog=kodiutils.smart_str(prog)
                )
            , list_item
            , False
            )

#__________________________________________________________________________
#
def play_fatima(prog,rel_url,channel,icon):

    match=re.compile('(http[sS]?:[\/]{2}.*?)(\/.*)\&').findall(rel_url)

    for baseURL, relURL in match:
        
        full_html = utils.getHtml("{}{}?all=1".format(baseURL, relURL))
        json_urls = json.loads(full_html)
        Log(   str(json_urls) )
       
        url = json_urls['hls'] + utils.Header2pipestring()
        name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
            C.channel_text_color, channel, prog)
        utils.playvid(url, name=name, play_profile="profile_03")
        return                                     
                        
#__________________________________________________________________________
#
