# -*- coding: utf-8 -*-

#import base libraries
import datetime
import json
import os
import re
import time
import traceback
#import internal addon libraries
import utils
import player
#define frequenctly used aliases
import constants as C
from utils import Log,LogR,Notify

MAIN_MODE          = C.MAIN_MODE_sportsdaddy
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
LIST_ROW_MODE      = str(int(MAIN_MODE) + 6)

BASE = "https://daddylivehd.sx/"
BASE = "https://daddylive.sx/"
BASE = "https://dlhd.sx/"
BASE = "https://dlhd.so/"
BASE = "https://thedaddy.to/"
BASE = "https://daddylive.dad/"
BASE = "https://thedaddy.click/"
BASE = "https://dlhd.click/"
BASE = "https://thedaddy.top/"
BASE = "https://daddylivestream.com/"

CATEGORY_REGEX = (
    '<h2 style="background-color:cyan">'
    '(?P<category>.+?)(?:</?h2>|<div id="sidebar">)'
    '(?P<category_info>.+?)(?=<h2 |<div id="sidebar">|\\Z)'
    )

CHANNEL_INFO_REGEX = (
    '<hr>(?:<strong>|)(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)(?:</strong>|)\s*<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|<hr|<h2|<div id="sidebar">)'
    )
CHANNEL_INFO_REGEX = (
    '<hr>(?:<strong>|)(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)(?:</strong>|)\s*<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|</span>\s|<hr|<h2|<div id="sidebar">)'
    )

LINK_INFO_REGEX = (
    'href="(?P<link>.+?)"'
    '.+?rel="noopener">(?P<broadcaster>.+?)</a>'
    )

try: cache_duration = int(utils.get_setting('html_cache_sportsdaddy'))
except: cache_duration = 300

DEFAULT_SORT_ORDER = 1000.0

##DEFAULT_PLAYMODE = C.PLAYMODE_INPUTSTREAM #2025-03 inputstream works again after proxy tweaks
DEFAULT_PLAYMODE = C.PLAYMODE_DIRECT #2024-10 ...but direct now works! ;/
##DEFAULT_PLAYMODE = C.PLAYMODE_F4MPROXY #2025-03 works, but fiddler stream mode will cause drops
DEFAULT_PLAY_PROFILE = C.PLAYMODE_PROFILE_01


STREAM_REGION_01 = '<div class="box">(.+)</span>Backup Streams Of Soccer &amp; Other Events</h1>'
STREAM_REGION_01 = '<div class="box">(.+)<div id="sidebar">'

SCHEDULE_JSON = BASE + 'schedule/schedule-generated.json'
SCHEDULE_JSON = BASE + 'schedule/schedule-generated.php'
SCHEDULE_HEADERS = {
                   "Referer" : BASE #'https://daddylive.mp/'
                  ,"Accept-Encoding":"gzip"
                    ,"User-Agent": C.USER_AGENT#'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
                  }


##LogR(type(C.urlparse),C.LOGNONE)
##LogR(dir(C.urlparse),C.LOGNONE)
##if C.PY3: from C import urlparse
##if C.PY3: from constants import urlparse
            
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE)
def add_icons(
                subchannel = u''
              , subchannel_label = u''
              , sort_order = DEFAULT_SORT_ORDER
              , cache_as_json = False  
              , testmode = False
              , end_directory = False):
    Log(repr((
                subchannel
              , subchannel_label
              , sort_order
              , cache_as_json
              , testmode
              , end_directory
               )))


    try:

        playable_url = None
        
        if not sort_order: sort_order = DEFAULT_SORT_ORDER
        else: sort_order = float(sort_order)
        
        #if not subchannel: return  #for this set, only allow specific channels
        program_name = subchannel #ignore program name because we don't have a tvguide for this


        icon = os.path.join(C.imgDir, ''.join(subchannel_label.lower().split(' '))+'.png') #strip any spaces in the lable to find icon


        if subchannel.isdigit(): #don't worry about categories when we need to tune to a specific number
            Log('subchannel.isdigit()')
            playable_url = subchannel
            icon_label = u'[B][COLOR {}]{}[/COLOR][/B]'.format(
                        C.channel_text_color
                        ,subchannel_label)
            
            utils.Add_Listitem(
                mode = PLAY_MODE
                ,icon_label = icon_label
                ,url = playable_url
                ,program_name = program_name
                ,channel = subchannel
                ,icon = icon
                ,module_name = __name__.split('.')[-1]
                ,rating = sort_order
                ,playmode_string = u''
                ,play_profile = u''
                ,testmode = testmode
                ,cache_as_json = cache_as_json
                ,is_folder = False)

            return playable_url


        #
        # Load createable icons from cache or from html 
        #
        with utils.global_mem_cache_lock: #lock permits a cached GET when this section is launched within multiple treads
        ##    return json.loads("[]")  #testing
            json_info = utils.global_cache.get(C.addon_id+BASE)
##            json_info = None #testing
            if json_info and (len(json_info) > 0)  :
                Log("using global_cache " + BASE)
            else:
                json_src = utils.getHtml(SCHEDULE_JSON, headers=SCHEDULE_HEADERS  , cache_duration=cache_duration)
    ##            utils.Sleep(20000) ##performance testing
                json_info = json.loads(json_src)
##                utils.global_cache.set(
##                    endpoint = (C.addon_id+BASE)
##                    ,data = json_info
##                    ,expiration = datetime.timedelta(seconds=C.default_GETHTML_cache_duration)
##                    )


        #convert start time from GMT+1 to EST
        time_range = int(utils.get_setting('time_range_sportsdaddy'))
        today = datetime.datetime.utcnow()
        schedule_time = today.utcnow() + datetime.timedelta(hours=-6) 

        for k in json_info.keys(): #first item is a date which we can skip
            for category in json_info[k].keys(): 

                #skip non specified categories 
                if subchannel_label and not (subchannel in category): continue

                #skip categories with no entries
                if len(json_info[k][category]) < 1: continue

                #add a sub menu for the category with entries
                category_name = u"[COLOR {}][B]{}[/B][/COLOR]".format(
                    C.refresh_text_color
                    , category.split('</')[0] #fix bug on site, but only for displayed info
                    )

                sorting_delta = 0.1
                sort_order += sorting_delta

                if subchannel_label:
                    icon = os.path.join(C.imgDir, u''.join(subchannel_label.split('</')[0].split(u' '))+u'.png') #strip any spaces in the lable to find icon
                else:                
                    icon = os.path.join(C.imgDir, u''.join(category.split('</')[0].split(u' '))+u'.png') #strip any spaces in the lable to find icon
                if not os.path.isfile(icon):
                    icon = os.path.join(C.imgDir, u'other.png')

                playable_url = subchannel
                
                utils.Add_Listitem(
                    mode = LIST_ROW_MODE
                    ,icon_label = category_name
                    ,url = playable_url
                    ,program_name = category
                    ,channel = category
                    ,icon = icon
                    ,filter_category = category
                    ,module_name = __name__.split('.')[-1]
                    ,rating = sort_order
                    ,playmode_string = u''
                    ,play_profile = u''
                    ,testmode = testmode
                    ,cache_as_json = cache_as_json
                    ,is_folder = True)

    except:
        traceback.print_exc()

    return playable_url
        
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_ROW_MODE, ['filter_category','testmode'])
def Add_Icons_Rows(filter_category, testmode, end_directory=True):
    Log(repr((filter_category,testmode,end_directory)))

    json_urls = [
        SCHEDULE_JSON
##        ,BASE + 'schedule/schedule-generated.json'
        ]
    try:
        for json_url in json_urls:

            json_src = utils.getHtml(json_url, headers=SCHEDULE_HEADERS, cache_duration=cache_duration)
            json_info = json.loads(json_src)

            sorting_delta = 0
            sorting_base = 3
        
            for k in json_info.keys(): #first item is a date which we can skip
                for category in json_info[k].keys():


                    if filter_category and (category != filter_category):
##                        #split occurs due to site-side error in data on 2025-03
##                        Log(repr((category,filter_category)))
                        continue
                
                    for event in json_info[k][category]: #json_info[json_info.keys()[0]][category]:
                        
                        try:
                            t_time = '12 12 2023 ' + event['time']
                        except:
                            t_time = '00:00'
                        try:
                            gmt_time = datetime.datetime.strptime( json_info.keys()[0].split(' - Schedule Time')[0] + event['time'], '%A %dth %B %Y%H:%M')
                        except:
                            try: 
                                gmt_time = datetime.datetime.strptime(t_time, '%d %m %Y %H:%M')
                            except TypeError:
                                gmt_time = datetime.datetime(*(time.strptime(t_time, '%d %m %Y %H:%M')[0:6]))
                            
                        schedule_time = gmt_time + datetime.timedelta(hours=-5) #convert from GMT+1
        
                        time_and_teams_name = u" [COLOR {}]{}[/COLOR] [COLOR {}]{}[/COLOR]".format(
                             C.time_text_color
                            , schedule_time.strftime('%H:%M') #event['time']
                            , C.highlight_text_color
                            , utils.cleantext(event['event'])
                            )

                        sorting_delta = sorting_delta + 1

                        icon = os.path.join(C.imgDir, category.split('</')[0]+'.png')
                        
                        utils.Add_Listitem(
                            mode = PLAY_MODE
                            ,icon_label = time_and_teams_name
                            ,url = C.DO_NOTHING_URL
                            ,program_name = category
                            ,channel = category
                            ,filter_category = category
                            ,icon = icon
                            ,module_name = __name__.split('.')[-1]
                            ,rating = sorting_base+sorting_delta
                            ,playmode_string = u''
                            ,play_profile = u''
                            ,testmode = testmode
                            ,cache_as_json = False
                            ,is_folder = False)
                    

                        for link in event['channels']:
##                            Log(repr(event['channels']))

                            channel_name = channel_id = None

                            #sometimes data is a list, other times a numbered array
                            if type(link) is dict:
                                if not (u'channel_id' in link):
                                    continue #sometimes there is a blank entry
                                channel_name = link[u'channel_name']
                                channel_id = link[u'channel_id']
                            else:
                                #note: the json parser in py2 may reorder the array differently
                                #  ie.  source data is (0, 1, ... 11, 12) but parsed as (11, 12 ... 1, 0, 2)
                                link3 = event[u'channels'][link]
                                if not (u'channel_id' in link3):
                                    continue #sometimes there is a blank entry
                                channel_name = link3[u'channel_name']
                                channel_id = link3[u'channel_id']
                                                            
                            if channel_name and channel_id:

                                channel_name = utils.cleantext(channel_name)
                                
                                name = u"      [COLOR {}]{}[/COLOR]".format(
                                    C.program_text_color
                                    ,channel_name + ' channel ' + channel_id
                                    )


                                utils.Add_Listitem(
                                    mode = PLAY_MODE
                                    ,icon_label = name
                                    ,url = C.DO_NOTHING_URL
                                    ,program_name = time_and_teams_name
                                    ,channel = channel_id
                                    ,filter_category = category
                                    ,icon = os.path.join(C.imgDir, category+'.png')
                                    ,module_name = __name__.split('.')[-1]
                                    ,rating = sorting_base+sorting_delta
                                    ,playmode_string = u''
                                    ,play_profile = u''
                                    ,testmode = testmode
                                    ,cache_as_json = False
                                    ,is_folder = False)
                                


    
    except:
        traceback.print_exc()
        raise

    if end_directory: 
        utils.endOfDirectory(cacheToDisc=False)
    
###__________________________________________________________________________
###
@C.url_dispatcher.register(PLAY_MODE, ['icon_label','url'], ['channel', 'program_name', 'icon', 'playmode_string', 'play_profile','download', 'testmode'])
def play( icon_label
         ,url
         ,channel=u''
         ,program_name=u''
         ,icon=None
         ,playmode_string=None
         ,play_profile=None
         ,download=None
         ,testmode=False):
    Log(u"icon_label='{}',playmode_string='{}',play_profile='{}',url='{}',channel='{}',icon_URI='{}', download='{}'".format(
        icon_label,playmode_string,play_profile,url,channel,icon,download)
        #,C.LOGNONE
        )


    download = bool(download)
    testmode = bool(testmode)

    try:
        #
        #various download options
        #
        download_filespec = None
        if download:
            dt = datetime.datetime.now().strftime('%Y-%m-%d')
            d_name = u"{}.{}.{}.ts".format(utils.Clean_Filename(icon_label), utils.Clean_Filename(icon_label).strip(' '), dt)
            download_filespec = utils.get_setting('download_path')
            if not download_filespec:
                download_filespec = None
            else:
                download_filespec = os.path.join(download_filespec, d_name)
        #
        #f4mproxy defaults
        #
        if not playmode_string: playmode_string = DEFAULT_PLAYMODE
        if playmode_string not in C.PLAYMODE_F4MPROXY: play_profile = None
        if play_profile not in C.VALID_PLAYMODE_PROFILES: play_profile = DEFAULT_PLAY_PROFILE


##        channel = '919'   #testing this channel
##        channel = '766'   #testing this channel
##        channel = '300'   #testing this channel
        
        headers = {
                   "Referer" : BASE
                  ,"Accept-Encoding":"gzip, deflate"
                    ,"User-Agent":C.USER_AGENT#'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
                  }
        post_link = '{}stream/stream-{}.php'.format(
            BASE
            ,channel
            )                                                                                  

        post_link = '{}casting/stream-{}.php'.format(
            BASE
            ,channel
            )                                                                                  

##        post_link = '{}cast/stream-{}.php'.format(
##            BASE
##            ,channel
##            )                                                                                  

        Log(post_link)
        hint_0_src = utils.getHtml(post_link, headers=headers)

        m3u8_url= None


        C.DEBUG = True
##        Log(hint_0_src)

        if not m3u8_url:  
            try:
                method = "#2025-08-27 method"
                iframes = re.findall(r'<a[^>]*href="([^"]+)"[^>]*>\s*<button[^>]*>\s*Player\s*2\s*<\/button>', hint_0_src)
    ##            LogR(iframes)

                url2 = iframes[0]
                url2 = BASE + url2
                url2 = url2.replace('//cast','/cast')
                headers['Referer'] = headers['Origin'] = url2
                response = utils.getHtml(url2, headers=headers)
                iframes = re.findall(r'iframe src="([^"]*)', response)
                LogR(iframes)
                if not iframes:
                    log("No iframe src found")
                    return
                url2 = iframes[0]
                LogR(url2)
                response = utils.getHtml(url2, headers=headers)
    ##            LogR(response)


                import base64
    ##            channel_key = re.findall(r'(?s) channelKey = \"([^"]*)', response)[0]
                channel_key = re.findall(r'CHANNEL_KEY\s*=\s*"([^"]*)"', response)[0]
    ##            LogR(channel_key)
                try:
                    bundle = re.findall(r'const BUNDLE = "([^"]*)"', response)[0]
                except:
                    bundle = re.findall(r'const XJZ="([^"]*)"', response)[0]
                    
    ##            LogR(bundle)
                bundle = base64.b64decode(bundle).decode('utf-8')
    ##            LogR(bundle)
                bundle = json.loads(bundle)
                LogR(bundle)
    ##            host = re.findall('(?s)m3u8 =.*?:.*?:.*?".*?".*?"([^"]*)', response)[0]
    ##            auth_host = re.findall(r'(?s)a = atob\("([^"]*)', response)[0]; auth_host = base64.b64decode(auth_host).decode('utf-8')
                auth_host = base64.b64decode(bundle['b_host']).decode('utf-8')
                LogR(auth_host)

    ##            auth_php = re.findall(r'(?s)b = atob\("([^"]*)', response)[0]; auth_php = base64.b64decode(auth_php).decode('utf-8')
    ##            auth_php = base64.b64decode(bundle['b_script']).decode('utf-8')
    ##            LogR(auth_php)
                auth_codes = re.findall(r'Uint8Array\(\[(.+?)\]', response)[0]
                auth_codes = re.findall(r'(\d+)', auth_codes)
                LogR(auth_codes)
                auth_php=''
                for z in auth_codes:
                    auth_php+= (chr(int(z)^73))
                LogR(auth_php)
                    
    ##            auth_ts = re.findall(r'(?s)c = atob\("([^"]*)', response)[0]; auth_ts = base64.b64decode(auth_ts).decode('utf-8')
                auth_ts = base64.b64decode(bundle['b_ts']).decode('utf-8')
                LogR(auth_ts)
    ##            auth_rnd = re.findall(r'(?s)d = atob\("([^"]*)', response)[0]; auth_rnd = base64.b64decode(auth_rnd).decode('utf-8')
                auth_rnd = base64.b64decode(bundle['b_rnd']).decode('utf-8')
                LogR(auth_rnd)
    ##            auth_sig = re.findall(r'(?s)e = atob\("([^"]*)', response)[0]; auth_sig = base64.b64decode(auth_sig).decode('utf-8')
                auth_sig = base64.b64decode(bundle['b_sig']).decode('utf-8')
                LogR(auth_sig)
                auth_sig = C.quote_plus(auth_sig)
                
    ##            server_lookup = re.findall('n fetchWithRetry\(\s*\'([^\']*)', response)[0]
                server_lookup = 'https://' +  C.urlparse.urlparse(url2).netloc + '/'

                url2 = 'https://lefttoplay.xyz/'
                headers['Referer'] = url2
                headers['Origin'] = headers['Referer'].rstrip('/')
                
                LogR(headers)

                #auth_url = f'{auth_host}{auth_php}?channel_id={channel_key}&ts={auth_ts}&rnd={auth_rnd}&sig={auth_sig}'
                auth_url = '{}{}?channel_id={}&ts={}&rnd={}&sig={}'.format(
                    auth_host
                    ,auth_php
                    ,channel_key
                    ,auth_ts
                    ,auth_rnd
                    ,auth_sig
                    )
                LogR(auth_url)
            
    ##            auth = requests.get(auth_url, headers=headers, timeout=10).text
                auth = utils.getHtml(auth_url, headers=headers)
                LogR(auth)

    ##            return
            
    ##            from urllib.parse import urlparse
    ##            LogR(dir(urlparse))
    ##            LogR(dir(C.urlparse))



                if C.PY2: from urlparse import urlparse
    ##            LogR(dir(C),C.LOGNONE)
    ##            if C.PY3: import C.urlparse as urlparse


    ##        https://jxoxkplay.xyz/server_lookup.php?channel_id=premium110
    ##            server_lookup_url = f"https://{urlparse(url2).netloc}{server_lookup}{channel_key}"
    ##            server_lookup_url = "https://{}{}{}".format(
    ##                C.urlparse.urlparse(url2).netloc
    ##                ,server_lookup
    ##                ,channel_key
    ##                )
                server_lookup_url = '{}server_lookup.php?channel_id={}'.format(
                    server_lookup
                    ,channel_key
                    )

    ##            LogR((server_lookup_url,headers)); return;
                response =  utils.getHtml(server_lookup_url, headers=headers)
                response = json.loads(response)
                server_key = response['server_key']
    ##            LogR(server_key); utils.LogFlush(); return;

            
                #referer_raw = f'https://{urlparse(url2).netloc}'
                referer_raw = 'https://{}'.format(C.urlparse.urlparse(url2).netloc)
                referer = C.quote_plus(referer_raw)
                ua_encoded = C.quote_plus(C.USER_AGENT)


    ##  const m3u8=(sk==='top1/cdn')?`https://top1.newkso.ru/top1/cdn/${CHANNEL_KEY}/mono.m3u8`:`https://${sk}new.newkso.ru/${sk}/${CHANNEL_KEY}/mono.m3u8`;
    ##                f'https://{server_key}{host}{server_key}/{channel_key}/mono.m3u8'
    ##                f'|Referer={referer}/&Origin={referer}&Connection=Keep-Alive&User-Agent={ua_encoded}'

                if server_key == 'top1/cdn':
    ## `https://top1.newkso.ru/top1/cdn/${CHANNEL_KEY}/mono.m3u8`
                    m3u8_url = 'https://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(
                            channel_key
                            )

                else:
    ##:`https://${sk}new.newkso.ru/${sk}/${CHANNEL_KEY}/mono.m3u8`;
                    m3u8_url = 'https://{}{}/{}/{}/mono.m3u8'.format(
                            server_key
                            ,'new.newkso.ru'
                            ,server_key
                            ,channel_key
                            )
                
                m3u8_url += '|Referer={}/&Origin={}&Connection=Keep-Alive&User-Agent={}'.format(
                        referer
                        ,referer
                        ,ua_encoded
                        )

                LogR(m3u8_url); ##utils.LogFlush(); return;
            except:
##                traceback.print_exc()
##                raise
                pass
            if not m3u8_url: LogR((method,' failed'),C.LOGWARNING)
            


            
    ####        utils.LogFlush()
    ##        return            

        if not m3u8_url:  
            method = "#2025-06-20 method"
            try:
                regex = r'src="(https://soccermlbstream.top/.+?)"'
                next_link = re.findall(regex, hint_0_src)
                if next_link: next_link=next_link[0]
##                current_referer_urlparse = C.urlparse.urlparse(current_referer)
                LogR(next_link)
##                self_referer = current_referer_urlparse.scheme+'://'+current_referer_urlparse.netloc

                hint_1_src = utils.getHtml(next_link, headers=headers) 
                current_referer_urlparse = C.urlparse.urlparse(next_link)                    
                self_referer = current_referer_urlparse.scheme+'://'+current_referer_urlparse.netloc
                regex = r'fid="(.+?)".+src="(//.+?)"'
                next_link = re.findall(regex, hint_1_src)
                LogR(next_link)
                if next_link:
                    fid = next_link[0][0]
                    next_link='https:'+next_link[0][1]
                else:
                    raise Exception('regex not found')

                LogR(next_link)
                headers['Referer'] = self_referer
                hint_2_src = utils.getHtml(next_link, headers=headers) 
                regex = r'src="(.+?&live=)'
                next_link = re.findall(regex, hint_2_src)
                LogR(next_link)
                next_link = next_link[0].replace("'+ embedded +'", "desktop")
                next_link = next_link+fid

                current_referer_urlparse = C.urlparse.urlparse(next_link)                    
                self_referer = current_referer_urlparse.scheme+'://'+current_referer_urlparse.netloc

                LogR(next_link)
                hint_3_src = utils.getHtml(next_link, headers=headers) 
                regex = r'return\(\[(.+?)\]'
                next_link = re.findall(regex, hint_3_src)
##                LogR(next_link, include_type=True)
                next_link = next_link[0].split(",")
##                LogR(next_link, include_type=True)
                next_link = "".join(next_link).replace('\"','').replace("\/","/").replace("//","/")
                LogR(next_link, include_type=True)


                headers['Referer'] = self_referer + '/'
                headers['Origin'] = self_referer
                m3u8_url = next_link
##                raise Exception(repr(headers))
##                return
            except:
##                traceback.print_exc()
##                raise
                pass
            if not m3u8_url: LogR((method,' failed'),C.LOGWARNING)



        if not m3u8_url:
            method = "2025-06-19 method"
            try:  
                post_link = '{}embed/stream-{}.php'.format(
                    BASE
                    ,channel
                    )                                                                                  

                Log(post_link)
                hint_0_src = utils.getHtml(post_link, headers=headers)

                current_referer = re.findall('iframe\s+src="([^"]*)', hint_0_src)
                if current_referer: current_referer=current_referer[0]
                LogR(current_referer)
                current_referer_urlparse = C.urlparse.urlparse(current_referer)
                LogR(current_referer_urlparse)
                self_referer = current_referer_urlparse.scheme+'://'+current_referer_urlparse.netloc
                LogR(self_referer)
                post_link_2 = current_referer
                Log(post_link_2)
                hint_2_src = utils.getHtml(post_link_2, headers=headers)
                
                channel_key = re.findall('var channelKey = "([^"]*)',hint_2_src)[0]
                Log(channel_key)
                stream_id = '/server_lookup.php?channel_id='
                post_link_3 = self_referer + stream_id + channel_key
                LogR(post_link_3)
                hint_3_src = utils.getHtml(post_link_3, headers=headers)
                try:
                    server_key = ''
                    
                    server_key = re.findall(':"([^"]*)',hint_3_src)[0]
                except:
                    LogR(hint_3_src)
                LogR(server_key)
                m3u8_name = '/mono.m3u8'#re.findall('(\/mono\.m3u8)'',hint_2_src)
                server_name = re.findall('var m3u8.+?\+ sk \+ "(.+?)"', hint_2_src, re.DOTALL | re.IGNORECASE )[0]
                LogR(server_name)

                authTs  = re.findall('var authTs  \s+= "(.+?)"',hint_2_src)[0]
                authRnd = re.findall('var authRnd \s+= "(.+?)"',hint_2_src)[0]
                authSig = re.findall('var authSig \s+= "(.+?)"',hint_2_src)[0]
                enable_key_url = "https://top2new.newkso.ru/auth.php?channel_id={}&ts={}&rnd={}&sig={}".format(
                    channel_key
                    ,authTs
                    ,authRnd
                    ,authSig
                    )
                Log(enable_key_url)
                headers={
                    'Accept':'*/*'
                    ,'Accept-Language':'en-US,en;q=0.5'
                    ,'Accept-Encoding':'gzip, deflate'
                    ,'Origin': self_referer.strip("/")
                    ,'DNT':'1'
                    ,'Sec-GPC': '1'
                    ,'Connection':'keep-alive'
                    ,'Referer':self_referer
                    ,'Sec-Fetch-Dest':'empty'
                    ,'Sec-Fetch-Mode':'cors'
                    ,'Sec-Fetch-Site':'cross-site'
                    ,'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0'
                    }
                misc = utils.getHtml(enable_key_url, headers=headers)
                LogR(misc)
    
                m3u8_url= 'https://{server_key}{server_name}{server_key}/{channel_key}{m3u8_name}'.format(
                    server_key=server_key
                    ,server_name=server_name
                    ,channel_key=channel_key
                    ,m3u8_name=m3u8_name
                    )

            except:
                traceback.print_exc()
                pass
            if not m3u8_url: LogR((method,' failed'),C.LOGWARNING)



    
        if not m3u8_url: 
            method = "2025-05-30 method"
            try:
                
                try:
                    regex = '<iframe.+?src="(.+?)"'
##                    regex = '<iframe.+?src="(https://(?:vidembed.re|veplay.top)/stream/(.+?))"'
                    next_link = re.findall(regex, hint_0_src)[0]
                    LogR(next_link)
                    next_uuid = next_link.split('/')[-1]
                    hint_1_src = utils.getHtml(next_link, headers=headers)
                except:
                    traceback.print_exc()
                    hint_1_src = hint_0_src
                        


                regex = 'src="(https://(?:vidembed.re|veplay.top)/stream/(.+?))"'
                regex = 'src="(https://(?:www\.|)(?:vidembed.re|veplay.top)/stream/(.+?))"'
                next_link = re.findall(regex, hint_1_src)
                if next_link:
                    next_link=next_link[0]
                    next_uuid = next_link[1]
                    next_link = next_link[0]
                    post_json_url = next_link
                    LogR(next_link)
                    LogR(next_uuid)
                    hint_2_src = utils.getHtml(next_link, headers=headers)                
                    regex = 'event-ve="(a30dc10ede003d85fa1b54cc7f4ccf7b)"'
                    event_ve = re.findall(regex, hint_2_src)
                else:
                    LogR(("unabled to find 'next_link' with re ", regex))
                    Log('look for information in current file')
                    regex = r'event-ve="(.+?)"'
                    event_ve = re.findall(regex, hint_1_src)
                    LogR(event_ve)
                    post_json_url = "https://veplay.top/stream/{}".format(next_uuid)

                Log(next_uuid)

                
                post_link = 'https://www.vidembed.re/api/source/{}?type=live'.format(next_uuid)
                post_json = (
                    '{'
                    '"r":"https://daddylive.dad/"'
                    ',"d":"www.vidembed.re"'
                    '}'
                    )
                headers = {
                    'Connection': 'keep-alive'
                    ,'sec-ch-ua-platform': '"Windows"'
                    ,'sec-ch-ua': '"Chromium";v="136", "Microsoft Edge";v="136", "Not.A/Brand";v="99"'
                    ,'sec-ch-ua-mobile': '?0'
                    ,'X-Requested-With': 'XMLHttpRequest'
                    ,'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0'
                    ,'Accept': 'application/json, text/javascript, */*; q=0.01'
                    ,'DNT': '1'
                    ,'Content-Type': 'application/json'
                    ,'Origin': 'https://www.vidembed.re'
                    ,'Sec-Fetch-Site': 'same-origin'
                    ,'Sec-Fetch-Mode': 'cors'
                    ,'Sec-Fetch-Dest': 'empty'
                    ,'Sec-Fetch-Storage-Access': 'active'
                    ,'Referer': 'https://www.vidembed.re/stream/' + next_uuid
                    ,'Accept-Encoding': 'gzip, deflate'
                    ,'Accept-Language': 'en-US,en;q=0.9'
                    }
                hint_2_src = utils.postHtml(post_link, sent_data=post_json, headers=headers)

                #2025-06-20 'source_file' is now encoded
                source_file = json.loads(hint_2_src)['player']['source_file']
                Log(source_file)
                
                post_link_2 = 'https://p.vidembed.re/api/event'
                headers = {
                    'Connection': 'keep-alive'
                    ,'sec-ch-ua-platform': '"Windows"'
                    ,'sec-ch-ua': '"Chromium";v="136", "Microsoft Edge";v="136", "Not.A/Brand";v="99"'
                    ,'sec-ch-ua-mobile': '?0'
                    ,'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0'
                    ,'Accept': '*/*'
                    ,'DNT': '1'
                    ,'Content-Type': 'text/plain'
                    ,'Origin': 'https://www.vidembed.re'
                    ,'Sec-Fetch-Site': 'same-site'
                    ,'Sec-Fetch-Mode': 'cors'
                    ,'Sec-Fetch-Dest': 'empty'
                    ,'Referer': 'https://www.vidembed.re/'
                    ,'Accept-Encoding': 'gzip, deflate'
                    ,'Accept-Language': 'en-US,en;q=0.9'
                    }
                post_json = { 
                     "p":{
                         "ve": event_ve
                           }
                     ,"r":"https://daddylive.dad/"
                     ,"d":"vidembed.re"
                     ,"u": post_json_url
                     ,"n":"pageview"
                     }
                post_info = json.dumps(post_json)
                Log(post_info)
                api_src = utils.postHtml(post_link_2, sent_data=post_info, headers=headers)

                headers = {
                    'Connection':'keep-alive'
                    ,'sec-ch-ua-platform':'"Windows"'
                    ,'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36 Edg/136.0.0.0'
                    ,'sec-ch-ua':'"Chromium";v="136", "Microsoft Edge";v="136", "Not.A/Brand";v="99"'
                    ,'DNT':'1'
                    ,'sec-ch-ua-mobile':'?0'
                    ,'Accept':'*/*'
                    ,'Origin':'https://www.vidembed.re'
                    ,'Sec-Fetch-Site':'cross-site'
                    ,'Sec-Fetch-Mode':'cors'
                    ,'Sec-Fetch-Dest':'empty'
                    ,'Referer':'https://www.vidembed.re/'
                    ,'Accept-Encoding':'gzip, deflate'
                    ,'Accept-Language':'en-US,en;q=0.9'
                          }
                m3u8_url = source_file
                
            except:
                traceback.print_exc()
                pass
            if not m3u8_url: LogR((method,' failed'),C.LOGWARNING)

##        assert False
##        LogR(__debug__)



        if not m3u8_url:  
            method = "#2025-02 method"
            try:  
                current_referer = re.findall('iframe src="([^"]*)', hint_1_src)
                if current_referer: current_referer=current_referer[0]
                current_referer_urlparse = C.urlparse.urlparse(current_referer)
                LogR(current_referer)
                self_referer = current_referer_urlparse.scheme+'://'+current_referer_urlparse.netloc

                post_link_2 = current_referer
                Log(post_link_2)
                hint_2_src = utils.getHtml(post_link_2, headers=headers)

                channel_key = re.findall('var channelKey = "([^"]*)',hint_2_src)[0]
                stream_id = '/server_lookup.php?channel_id='
                post_link_3 = self_referer + stream_id + channel_key
                LogR(post_link_3)
                hint_3_src = utils.getHtml(post_link_3, headers=headers)
                server_key = re.findall(':"([^"]*)',hint_3_src)[0]
                LogR(server_key) #'ddy6')
                m3u8_name = '/mono.m3u8'#re.findall('(\/mono\.m3u8)'',hint_2_src)
                #server_name = re.findall('var m3u8Url.+? \+ serverKey \+ "(.+?)"', hint_2_src, re.DOTALL | re.IGNORECASE )
                server_name = re.findall('var m3u8.+?\+ sk \+ "(.+?)"', hint_2_src, re.DOTALL | re.IGNORECASE )[0]
                LogR(server_name)
                m3u8_url= 'https://{server_key}{server_name}{server_key}/{channel_key}{m3u8_name}'.format(
                    server_key=server_key
                    ,server_name=server_name
                    ,channel_key=channel_key
                    ,m3u8_name=m3u8_name
                    )
            except:
                traceback.print_exc()
##                raise
                pass
            if not m3u8_url: LogR((method,' failed'),C.LOGWARNING)




                
##        test_poke = utils.getHtml(m3u8_url, headers=headers)
        LogR(m3u8_url)
        if not m3u8_url: utils.Notify(u"can't find playable url for channel {}".format(channel))
        video_url = m3u8_url + utils.Header2pipestring(headers)
        LogR(m3u8_url)
        
        play_label = "Channel {}".format(
             channel
             )
        #
        #what to do if we are just testing
        #
        testmode=True
        testmode=False
        if testmode:
            Log(repr(( "warning TESTMODE:"
                        ,video_url
                        , play_label
                        , playmode_string
                        , play_profile
                        , download
                        , download_filespec
                      )))
            utils.endOfDirectory(end_directory=True)
            raise Exception('logflush')
            return
        


        
        player.playvid(
            video_url
            , name=play_label
            , playmode_string=playmode_string
            , play_profile=play_profile
            , mimetype = 'application/vnd.apple.mpegurl'
            , download=download
            , download_filespec=download_filespec
            , skip_head = True
        )

    except:
        traceback.print_exc()
        

#__________________________________________________________________________
# Unit tests
@C.url_dispatcher.register(TEST_MODE)
def TEST_MODE():
    test_label = ""
    module_name = __name__.split('.')[-1]
    try:


        test_label='list only rows in Soccer'
        Add_Icons_Rows(filter_category = u'Soccer</span>'
                       , testmode = False
                       , end_directory = False
                       )
##        raise Exception('logflush')
    
        test_label='add channel 22 and call it TVO ü'
        playable_url = add_icons(
                   subchannel = u'767'
                  , subchannel_label = u'chanel 767 strangecahr ü'
                  , sort_order = None
                  , testmode = False
                  )
##        raise Exception('logflush')

        test_label='download html and add only the category folder soccer; label will not matter because this is a folder'
        add_icons(
                   subchannel = u'Soccer'
                  , subchannel_label = u'SoccerüSoccerü'
                  , sort_order = None
                  , testmode = True
                  )
        test_label='download html and add all categories'
        add_icons(
                   subchannel = u''
                  , subchannel_label = u''
                  , sort_order = None
                  , testmode = True
                  )

##        raise Exception('logflush')

        test_label='list only rows in Baseball'
        Add_Icons_Rows(filter_category = u'Baseball'
                       , testmode = False
                       , end_directory = False
                       )

        test_label='list only rows in Hockey'
        Add_Icons_Rows(filter_category = u'Hockey'
                       , testmode = False
                       , end_directory=False
                       )

        test_label='download ch 720'
        play(
             url =  playable_url
             , icon_label = test_label
             , channel =  u'{}'.format('720')
             , download = True
             , testmode = False
             )

    except:
        traceback.print_exc()
        raise Exception(test_label)
                                
#__________________________________________________________________________
#

