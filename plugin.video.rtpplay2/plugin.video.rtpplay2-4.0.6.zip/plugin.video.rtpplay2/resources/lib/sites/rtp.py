# -*- coding: utf-8 -*-

#import base libraries
import datetime
import json
import os
import re
import traceback
#import internal addon libraries
import utils
import player
#define frequenctly used aliases
import constants as C
from utils import Log,LogR,Notify


RTP_BASE = "https://www.rtp.pt"

MAIN_MODE          = C.MAIN_MODE_rtp
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
LIST_ROW_MODE      = str(int(MAIN_MODE) + 6)

DEFAULT_SORT_ORDER = 50.0

###__________________________________________________________________________
###
@C.url_dispatcher.register(LIST_MODE)
def add_icons(
                subchannel = u''
              , subchannel_label = u''
              , sort_order = DEFAULT_SORT_ORDER
              , cache_as_json = False  
              , testmode = False
              , end_directory = False
              ):
    try:
    
        if not sort_order: sort_order = DEFAULT_SORT_ORDER
        else: sort_order = float(sort_order)

        with utils.global_mem_cache_lock: #lock permits a cached GET when this section is launched within multiple treads
            full_html = utils.getHtml(RTP_BASE + "/play/direto", auto_encode_content=True) #works 2023-03-12
        
        regex = (
            '(?s)<a\W+title=\"Emiss&atilde;o em direto ([^\"]+)\"'
            '.+?href=\"([^\"]+)\"'
            '.+?alt="Imagem de ([^"]+)"'
            '.+?src.*?=\"([^\"]+)\"'
            )
        match = re.compile(regex).findall(full_html)
        if not match:
            raise Exception("Error finding code on main RTP page")

        for program_name, playable_url, channel, icon in match:
            if subchannel and not("/play/direto/"+subchannel.lower()==playable_url.lower() ):
                #only add what is specified when we have been asked for a subchannel
                continue

            icon_label = u"[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
                C.channel_text_color
                , channel
                , C.program_text_color
                , program_name
                )
            if not channel.startswith('RTP'):
                channel = 'RTP ' + channel #lets me filter things later
                
            if icon.startswith("/"): icon = "http:{}".format(icon)
            icon = icon + utils.Header2pipestring()

            playable_url = utils.Add_Listitem(
                mode = PLAY_MODE
                ,icon_label = icon_label
                ,url = playable_url
                ,program_name = program_name
                ,channel = subchannel
                ,icon = icon
                ,module_name = __name__.split('.')[-1]
                ,rating = sort_order
                ,playmode_string = u''
                ,play_profile = u'profile_03'
                ,testmode = testmode
                ,cache_as_json = cache_as_json
                ,is_folder = False
                )
            if subchannel:
                return playable_url

        return playable_url

    except:
        LogR(locals())
        raise

###__________________________________________________________________________
###
@C.url_dispatcher.register(PLAY_MODE, ['icon_label','url'], ['channel', 'program_name', 'icon',  'playmode_string', 'play_profile','download', 'testmode'])
def play( icon_label
         ,url
         ,channel=None
         ,program_name=u''
         ,icon=None
         ,playmode_string=None
         ,play_profile=None
         ,download=None
         ,testmode=False):

    if C.PY2:
        if not isinstance(icon_label, C.text_type):
            icon_label = icon_label.decode('utf8')
        if not isinstance(program_name, C.text_type):            
            program_name = program_name.decode('utf8')

    Log(u"icon_label='{}',playmode_string='{}',play_profile='{}',url='{}',channel='{}',program_name='{}',icon_URI='{}', download='{}'".format(
        icon_label,playmode_string,play_profile,url,channel,program_name,icon,download)
        ,C.LOGNONE
        )
    download = bool(download)
    testmode = bool(testmode)


    qq = C.urlparse.parse_qs(url)
    if 'url' in qq:
        rel_url = qq['url'][0]
    else:
        rel_url = url
##    Log(rel_url)
##    return
        
    #
    #various download options
    #
    download_filespec = None
    if download:
        dt = datetime.datetime.now().strftime('%Y-%m-%d')
        d_name = u"{}.{}.{}.ts".format(utils.Clean_Filename(icon_label), utils.Clean_Filename(icon_label).strip(' '), dt)
        download_filespec = utils.get_setting('download_path')
        if not download_filespec:
            download_filespec = None
        else:
            download_filespec = os.path.join(download_filespec, d_name)

    #
    #f4mproxy defaults
    #
    if not playmode_string:
        playmode_string = C.DEFAULT_PLAYMODE_RTP
    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_03
            
    rights_url= "https://www.rtp.pt/services/rtpplay/?v=5&ch_k=" + rel_url.split('/')[-1]
    string_rtp_rights = utils.getHtml(url=rights_url, save_cookie=True)
    json_rtp_rights = json.loads(string_rtp_rights)

    if json_rtp_rights["rights"] != 1:
        header = "RTP blocking your country"
        header = "[B][COLOR {}]{}[/COLOR][/B]".format(C.highlight_text_color,header)
        msg = u"'{}'".format(program_name)
        utils.Notify(header=header, msg=msg, duration=15000)
        return
    else:
        #Log('we have rights')
        pass

    play_html_url = "{}{}".format(RTP_BASE, rel_url)
    full_html = utils.getHtml(play_html_url, save_cookie=True)

    final_stream_url = None
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                #Log("first regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                #Log("second regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('file:\W+"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                #Log("third regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        regex = (
            'file:\s+{\s+fps:""\s+,\s+hls:\s+decodeURIComponent\('
            '(.+?)'
            '\.join\(""\)\),\s+dash:""},'
            )
        streams = re.compile(regex, re.DOTALL).findall(full_html)
        for stream in streams:
            regex = '"(.+?)(?:",|"\])'
            stream = re.compile(regex, re.DOTALL).findall(stream)
            stream = "".join(stream)
            stream = unquote(stream)
            if ".m3u8" in stream.split('/')[-1]:
                final_stream_url = stream
                #Log("fifth regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        regex = (
            'file:\s+{\s+fps:"[^"]+"\s+,\s+hls:\s+decodeURIComponent\('
            '(.+?)'
            '\.join\(""\)\),\s+dash:"'
            )
        streams = re.compile(regex, re.DOTALL).findall(full_html)
        for stream in streams:
            regex = '"(.+?)(?:",|"\])'
            stream = re.compile(regex, re.DOTALL).findall(stream)
            stream = "".join(stream)
            stream = unquote(stream)
            if ".m3u8" in stream.split('/')[-1]:
                final_stream_url = stream
                #Log("sixth regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?fps:"([^"]+)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                #Log("fourth regex found final_stream_url='{}'".format(final_stream_url))

    if not final_stream_url:
        regex = (
            'file:\s+{\s+fps:""\s+,\s+hls:\s+'
            '(.+?)'
            ',\s+dash:""},'
            )
        streams = re.compile(regex, re.DOTALL).findall(full_html)
        for stream in streams:
            #Log("stream={}".format(repr(stream)))
            if ".m3u8" in stream.split('/')[-1]:
                final_stream_url = stream
                #Log("sixth regex found final_stream_url='{}'".format(final_stream_url))

    #Log("final_stream_url='{}'".format(final_stream_url))
    if final_stream_url is None:
        #Log(full_html)
        utils.Notify("Unexpected error: playable url was not found", duration=7000)
        return
    
    #playmode_string = C.DEFAULT_PLAYMODE_RTP
    mimetype = "video/mp2t"


    if program_name: program_name = u" ({})".format(program_name)
    play_label = u"[B][COLOR {}]{}[/COLOR]{}".format(
        C.channel_text_color
        , icon_label
        , program_name)

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = 'https://www.rtp.pt/play/'
    
    video_url = final_stream_url + utils.Header2pipestring(headers) #+ "&Referer=https://www.rtp.pt/play/"
    LogR(video_url)

    if 'liveradio' in final_stream_url:
        playmode_string = C.PLAYMODE_DIRECT #PLAYMODE_INPUTSTREAM can't play this


    #
    #what to do if we are just testing
    #
##    testmode=True
##    testmode=False
    if testmode:
        Log(repr(( "warning TESTMODE:"
                    , video_url
                    , play_label
                    , playmode_string
                    , play_profile
                    , download
                    , download_filespec
##                    , m3u8_url
##                    , headers
                  )))
        utils.getHtml(final_stream_url,headers=headers)
##        utils.endOfDirectory(end_directory=False)
        return

    #
    #what to do if we are serious
    #
    player.playvid(
        video_url
        , name=play_label
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download = download
        , download_filespec=download_filespec
    )
   

#__________________________________________________________________________
#

#__________________________________________________________________________
# Unit tests
@C.url_dispatcher.register(TEST_MODE)
def TEST_MODE():
    test_label = ""
    module_name = __name__.split('.')[-1]
    try:

        test_label = u'{}€ add Antena1 '.format(module_name)
        playable_url = add_icons(
            subchannel = 'Antena1' #case sensitive!
          , subchannel_label = ''
          , sort_order = None
          , testmode = True
          )
        
        test_label = u'{}€ play antenna1 - without program'.format(module_name)
        play(
               url =  playable_url
             , icon_label = test_label
             , playmode_string = C.PLAYMODE_DIRECT
             , download = False
             , testmode = True
             )
     

        test_label = u'{}€ add all categories'.format(module_name)
        playable_url = add_icons(
            subchannel = '' #case sensitive!
          , subchannel_label = ''
          , sort_order = None
          , testmode = True
          )


                
        test_label = u'{}€ download html and add single station'.format(module_name)
        playable_url = add_icons(
            subchannel = u'{}'.format('RTP3') #case sensitive!
          , subchannel_label = u"€ RTP3.pt €"
          , sort_order = None
          , testmode = True
          )
        Log(playable_url)
##        playable_url = C.urlparse.parse_qs(playable_url)['url'][0]
        test_label = u'RTP1 testmode play default'.format(module_name)
        play(icon_label = test_label
             , channel = 'RTP1'
             , url = playable_url
             , testmode= True
             )




        test_label = u'{}€ X 3'.format("RTP3"   )
        playable_url = add_icons(
            subchannel = u'{}'.format('RTP3') 
          , subchannel_label = u"€ RTP3.pt €"
          , sort_order = None
          , testmode = True
          )
        Log(playable_url)
##        playable_url = C.urlparse.parse_qs(playable_url)['url'][0]
        play(  icon_label = test_label
             , channel = 'US/Grit Xtra'     
             , url = playable_url
             , playmode_string = C.PLAYMODE_F4MPROXY
             , play_profile = C.PLAYMODE_PROFILE_03
             , testmode = True
             )




        test_label = u'{}€ S/Grit X 3'.format("TVIPT"   )
        play(  icon_label = test_label
             , channel = 'CA/CityNews Toronto'
             , url = playable_url
             , playmode_string = C.PLAYMODE_F4MPROXY
             , play_profile = C.PLAYMODE_PROFILE_03
             , testmode = True
             )


        test_label = u'€ PT/RTP3.pt imputstream'.format("SICPT")
        play(  icon_label = test_label
             , channel = 'PT/RTP3.pt' #'CA/CityNews Toronto'
             , url = playable_url
             , playmode_string = C.PLAYMODE_INPUTSTREAM 
             , testmode = True
             )
        
##        utils.Sleep(2000)
##        raise ValueError()
    
        test_label = u'{}€ RTP3 download - with program'.format(module_name)
        play(
             url =  playable_url
             , channel = 'PT/RTP3.pt'
             , program_name = 'hello tet world'
             , icon_label = test_label
             , download = True
             , testmode = False
             )

        test_label = u'{}€ RTP3 download - without program'.format(module_name)
        play(
             url =  playable_url
             , channel = 'PT/RTP3.pt'
             , icon_label = test_label
             , download = True
             , testmode = False
             )

##
##    except ValueError:
##        pass
    except Exception as e:
        traceback.print_exc()
        raise Exception(test_label)

##    if test_label:
##        raise Exception(test_label)
    
#__________________________________________________________________________
#


