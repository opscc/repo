# -*- coding: utf-8 -*-
import datetime
import os
import importlib
import json
import sqlite3
import sys
import threading
import traceback
import xbmc
import xbmcaddon

import constants
import constants as C
from constants import reload
from constants import urlparse
from constants import quote_plus

import downloader
    
import utils
from utils import Log
from utils import routing_url_for

#__________________________________________________________________________
#
@C.url_dispatcher.register(str(C.ROOT_TEST_ALL))
def test_all():
    
    for plugin_name, test_function, test_module in get_sites(function_name='TEST_MODE',plugin_filter=''):

        if not utils.get_setting('list_'+ plugin_name):
            utils.Add_Listitem(
                mode = C.NO_ACTION_MODE
                ,icon_label = "[COLOR orange] [B] {} skipping test for disabled module [/B] [/COLOR]\n\n".format(plugin_name)
                ,url = C.DO_NOTHING_URL
                ,rating = 0
                ,is_folder = False
                )
##            utils.Notify(' {}'.format(plugin_name))
            continue

        cache_duration = 12 #hours
        cache_id = 'test_'+ plugin_name
        cached_value = utils.global_cache.get(cache_id)
        if cached_value:
            Log('skipping test for passed module {}'.format(plugin_name), C.LOGNONE)
            utils.Add_Listitem(
                mode = C.NO_ACTION_MODE
                ,icon_label = "[COLOR yellow] [B] {} tests already passed[/B][/COLOR] within past {} hours".format(plugin_name, cache_duration)
                ,url = C.DO_NOTHING_URL
                ,rating = 0
                ,is_folder = False)
            continue
        else:
            Log('running test for {}'.format(plugin_name), C.LOGNONE)
                
        try:

            test_function()


            utils.global_cache.set(
                endpoint = cache_id
                ,data = datetime.datetime.now()
                ,expiration = datetime.timedelta(hours=cache_duration)
                )
            
            utils.Add_Listitem(
                mode = C.NO_ACTION_MODE
                ,icon_label = "[COLOR yellow] [B] {} tests passed [/B] [/COLOR]\n\n".format(plugin_name)
                ,url = C.DO_NOTHING_URL
                ,rating = 0
                ,is_folder = False)

        except Exception as ex:
            utils.Add_Listitem(
                mode = C.NO_ACTION_MODE
                ,icon_label = u"[COLOR red][B]failed {}[/B][/COLOR] '{}'".format(plugin_name, ex)
                ,url = C.DO_NOTHING_URL
                ,rating = 0
                ,is_folder = False)              
            Log(repr(ex))
            traceback.print_exc()

            
    utils.endOfDirectory()
    
###__________________________________________________________________________
###
@C.url_dispatcher.register(C.REFRESH_CONTAINER_MODE)
def RefreshContainter():
    reload(utils)
    if utils.get_setting("use_memcache", bool):
        try:
            utils.global_mem_cache_lock.acquire()
            Log('manually expiring info due to refresh click')
            utils.global_mem_cache.set(
                 endpoint = (utils.CACHE_STRING+'_size')
                ,data = 0
                )
        except:
            traceback.print_exc()
        finally:
            utils.global_mem_cache_lock.release()
            
    if utils.get_setting("use_dbcache", bool):
        try:        
            utils.Clear_Table(interval_minutes=0,db_connection=sqlite3.connect(C.linksdb,check_same_thread = False))
        except:
            traceback.print_exc()

    xbmc.executebuiltin('Container.Refresh')

###__________________________________________________________________________
###
def get_sites(function_name, plugin_filter=''):
    #todo: list files in folder
    sites = ['fatima','euronews','rtp','cmtv','iptvorg','methstreams','tvi', 'sportsdaddy'] 
    for plugin in sites:
        if plugin_filter and plugin_filter.lower() != plugin:
            continue
        try:
            module = importlib.import_module('sites.'+plugin)
            if hasattr(module, function_name):
                function = getattr(module, function_name)
                yield (plugin, function, module)
        except ModuleNotFoundError:
            pass #most likely testing
        except:
            traceback.print_exc()
            break
            pass

###__________________________________________________________________________
###
@C.url_dispatcher.register(C.ROOT_INDEX_INDEX)
def index(create_icons=True, testmode=False):

        
    progress_dialog = None
    if create_icons:
        pass
    t_start = datetime.datetime.now()
    index_lock = threading.Lock()

    try:
        index_lock.acquire()
        size = None
        
        # I want a particular default order for the items
        # I can't guarantee the order with listitems being added inside the threads,
        #   and so I store the data in a cache [using memory for now],
        #   and add the items when done
        if utils.get_setting("use_memcache", bool):
            Log('use_memcache')
            try:
                utils.global_mem_cache_lock.acquire()
                size = utils.global_mem_cache.get(
                         endpoint = (utils.CACHE_STRING+"_size")
                         )
                if size: size = int(size)
                else: size = None
                if not size:
                    Log('info has expired')
                    utils.global_mem_cache.set(
                         endpoint = (utils.CACHE_STRING+'_size')
                        ,data = 0
                         )
                else:
                    Log('cached info size ' + repr(size))
            finally:
                utils.global_mem_cache_lock.release()

        else:  ##utils.get_setting("use_dbcache", bool):
            Log('use_dbcache')
            db_connection=sqlite3.connect(C.linksdb) #,check_same_thread = False) 
            utils.Clear_Table( (utils.get_setting("service_periodic_interval", int)/60) +1, db_connection)
            size = db_connection.execute("select count(*) from links").fetchone()
            size = int(size[0])


    ##    net = datetime.datetime.now()-t_start
    ##    Log("ops = {:.0f}ms".format(net.microseconds/1000 + net.total_seconds()*1000) )



        worker_threads = []

        if not size:
            try:
                cycle_sleep = 1 #milliseconds

                for plugin_name, function, module in get_sites(function_name='add_icons',plugin_filter=''):
                    if utils.get_setting('list_'+ plugin_name):
                        Log('list_'+ plugin_name + '_subchannels')
                        for subchannel in utils.get_setting('list_'+ plugin_name + '_subchannels', list)  :
                            sort_order=module.DEFAULT_SORT_ORDER
                            if ';' in subchannel:
                                subchannel = subchannel.split(';')
                                subchannel_filter=subchannel[0]
                                subchannel_label=subchannel[1]
                                if len(subchannel) == 3:  sort_order=subchannel[2]
                            else:
                                subchannel_filter=subchannel
                                subchannel_label=subchannel
                            cache_as_json = True 
                            worker = threading.Thread(name=plugin_name
                                                      ,target=function
                                                      ,args=( subchannel_filter
                                                             ,subchannel_label
                                                             ,sort_order
                                                             ,cache_as_json
                                                            )
                                          )
                            worker.daemon = True
                            worker_threads.append(worker)

                            #sleep between thread start to ENCOURAGE the link ordering to come out close to the order described in list
                            utils.Sleep(cycle_sleep) #milliseconds

                            worker.start()
                            Log('started thread {}:{}'.format(worker.name,worker.ident))
                            

                max_cycles = 100 #multiply by cycle_sleep/1000 for seconds_to_wait_for_search
                cycle_sleep = 200 #milliseconds
                cur_time = 0
                still_working = True
                while still_working and (cur_time < max_cycles) :
                    if progress_dialog and progress_dialog.iscanceled(): break
                    if progress_dialog: progress_dialog.increment_percent()
                    cur_time += 1
                    utils.Sleep(cycle_sleep) #milliseconds
                    still_working = False
    ##                Log(repr(len(worker_threads)))
                    for worker in worker_threads:
                        if worker.is_alive():
    ##                        Log(worker.name)
                            still_working = True
                            break #keep waiting for active task
                if (cur_time >= max_cycles):
                    Log('lookup threads timeout {}'.format(cur_time))
            except:
                traceback.print_exc()

    ##    net = datetime.datetime.now()-t_start
    ##    Log("ops = {:.0f}ms".format(net.microseconds/1000 + net.total_seconds()*1000) )
        

        #threads done by now; use the info to add listitems in our preferred order
        json_items = {}
        
        if utils.get_setting("use_memcache", bool):
            try:
                utils.global_mem_cache_lock.acquire()
                size = utils.global_mem_cache.get(
                    endpoint = (utils.CACHE_STRING+'_size')
                    )
                if size: size = int(size)
                else: size = -1
                for i in range(1,size+1,1): #add all to a list
                    json_item = utils.global_mem_cache.get(
                             endpoint = (utils.CACHE_STRING+"_icons+"+str(i))
                             )

                    #check if the 'rating' index already exists;
                    while json_items.get(json_item['rating']):
                        #Log(repr(json_item['rating']))
                        #if is already exists, change the index value so that don't overwrite
                        json_item['rating'] = json_item['rating']+0.1

                    json_items[json_item['rating']] = json_item
            except:
                traceback.print_exc()
            finally:
                utils.global_mem_cache_lock.release()
                
        if utils.get_setting("use_dbcache", bool):
            try:
                db_connection = sqlite3.connect(C.linksdb)
                for info in db_connection.execute("select json_info from links"):
                    json_item = json.loads(info[0])

                    #check if the 'rating' index already exists;
                    while json_items.get(json_item['rating']):
                        #Log(repr(json_item['rating']))
                        #if is already exists, change the index value so that don't overwrite
                        json_item['rating'] = json_item['rating']+0.1
                    
                    json_items[json_item['rating']] = json_item
            except:
                traceback.print_exc()
                    

        Log("total items to list is " + repr(len(json_items.keys())))                

        if not create_icons:
            #if we are only backgrould refreshing, we can stop
            return
        
        #sort all of them and add listitems the sorted order
        for k in sorted(json_items.keys()):
            json_item = json_items[k]
##            Log(repr(json_item))
            utils.Add_Listitem(
                mode = json_item['mode']
                ,icon_label = json_item['icon_label']
                ,url = json_item['url']
                ,program_name = json_item['program_name']
                ,channel = json_item['channel']
                ,icon = json_item['icon']
                ,filter_category = json_item['filter_category']
                ,rating = json_item['rating']
                ,is_folder = json_item['is_folder']
                ,cache_as_json = False
                )
                

        if testmode:
            net = datetime.datetime.now()-t_start
            Log("ops = {:.0f}ms".format(net.microseconds/1000 + net.total_seconds()*1000) )

        try:
            utils.Add_Listitem(
                mode = C.MANAGE_DOWNLOADS
                ,icon_label = '[B][COLOR {}]Downloads[/COLOR][/B]'.format(C.time_text_color)
                ,url = routing_url_for(C.MANAGE_DOWNLOADS)
                ,icon = os.path.join(C.imgDir, 'library_update_5.png')
                ,rating = int(C.MANAGE_DOWNLOADS)
                ,is_folder = True
                )
        except:
            traceback.print_exc()
            
        try:
            utils.Add_Listitem(
                mode = C.REFRESH_CONTAINER_MODE
                ,icon_label = '[B][COLOR {}]Refresh[/COLOR][/B]'.format(C.highlight_text_color)
                ,url = routing_url_for(C.REFRESH_CONTAINER_MODE)
                ,icon = os.path.join(C.imgDir, 'library_update_5.png')
                ,rating = int(C.REFRESH_CONTAINER_MODE)
                ,cache_as_json = False
                ,is_folder = False
                )
        except:
            traceback.print_exc()

        try:
            utils.Add_Listitem(
                mode = C.CONFIGURE_THIS_ADDON
                ,icon_label = '[B][COLOR {}]Settings[/COLOR][/B]'.format(C.time_text_color)
                ,url = routing_url_for(C.CONFIGURE_THIS_ADDON)
                ,icon = os.path.join(C.imgDir, 'tools.png')
                ,rating = int(C.CONFIGURE_THIS_ADDON)
                ,is_folder = True)
        except:
            traceback.print_exc()
            
        try:
            if C.DEBUG:
                utils.Add_Listitem(
                    mode = C.ROOT_TEST_ALL
                    ,icon_label = '[B][COLOR {}]Test All[/COLOR][/B]'.format(C.test_text_color)
                    ,url = routing_url_for(C.ROOT_TEST_ALL)
                    ,icon = os.path.join(C.imgDir, 'tools.png')
                    ,rating = int(C.ROOT_TEST_ALL)
                    ,is_folder = True)

        except:
            traceback.print_exc()

##        if C.DEBUG: raise Exception('logflush')
    
    except:
        traceback.print_exc()
    finally:
        index_lock.release()
        utils.endOfDirectory(updateListing=True)
    ###end with threading.lock

    net = (datetime.datetime.now()-t_start).total_seconds()
    Log("milliseconds for all ops={:.0f}ms".format(net*1000) )



###__________________________________________________________________________
###
@C.url_dispatcher.register(C.CONFIGURE_THIS_ADDON)
def configure_THIS_addon():
    xbmc.executebuiltin("Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    xbmcaddon.Addon(id=C.addon_id).openSettings()
    return True
###__________________________________________________________________________
###
@C.url_dispatcher.register(C.MANAGE_DOWNLOADS)
def Manage_Downloads():
    Log(repr(("Manage_Downloads", sys.argv, C.addon_handle))
        ,C.LOGNONE
        )
    C.addon_handle = int(sys.argv[1])
    downloader.Manage_Downloads()
###__________________________________________________________________________
###
@C.url_dispatcher.register(C.STOP_DOWNLOAD, ['rel_url','name'])
def Stop_Download(rel_url,name):
    Log(repr(("Stop_Download", rel_url,name)) 
        ,C.LOGNONE
        )
    downloader.Stop_Download(rel_url,name)
###__________________________________________________________________________
###
@C.url_dispatcher.register(C.CONFIGURE_FMPROXY)
def configure_addon():
    xbmcaddon.Addon(id='script.video.F4mProxy').openSettings()
###__________________________________________________________________________
###
@C.url_dispatcher.register(C.CONFIGURE_INPUTSTREAM)
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
###__________________________________________________________________________
###
@C.url_dispatcher.register(C.LIST_DOWNLOADS, ['folder'])
def List_Downloads(folder=''):
    Log(repr(("List_Downloads", sys.argv, folder))
        ,C.LOGNONE
        )
    xbmc.executebuiltin("ActivateWindow(Videos, {})".format(folder))

###__________________________________________________________________
###
