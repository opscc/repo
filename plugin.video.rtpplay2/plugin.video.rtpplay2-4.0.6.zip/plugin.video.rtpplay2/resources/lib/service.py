import json
import os
import os.path
import random
import sys
import threading
import traceback
import xbmc

##import importlib
##from importlib import reload as reload

import constants as C
from constants import reload
import plugin
import utils
from utils import Log,LogR,Sleep
from utils import get_setting as GetSetting

# server defaults

##import AES_key_proxy

monitor = xbmc.Monitor()

#__________________________________________________________________
#
def Sleep_Start(sleep_time):
##    xbmc.log("Begin {}s sleep for {}:{}".format(
##            sleep_time
##            , threading.current_thread().name
##            , threading.current_thread().ident
##            )
##            ,xbmc.LOGINFO)
    Log("Begin {}s sleep for {}:{}".format(
            sleep_time
            , threading.current_thread().name
            , threading.current_thread().ident
            )
        ,stacklevel=3
        )
#__________________________________________________________________
#
def Sleep_End(sleep_time):
##    xbmc.log("End {}s sleep for {}:{}".format(
##            sleep_time
##            , threading.current_thread().name
##            , threading.current_thread().ident
##            )
##            ,xbmc.LOGINFO)
    Log("End {}s sleep for {}:{}".format(
            sleep_time
            , threading.current_thread().name
            , threading.current_thread().ident
            )
        ,stacklevel=3
        )
#__________________________________________________________________________
#
class EndingException(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)

#__________________________________________________________________
#
def download_service(stop_event):

    import downloadServer
    try:
        download_proxy = None
        while not monitor.abortRequested():

            if stop_event.is_set():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))

            if GetSetting("enable_download_service", bool):
                if not download_proxy:
                    Log("starting download_proxy", C.LOGNONE)
                    download_proxy = downloadServer.StartListening()
            else:
                Log('not enabled. download_proxy will be stopped')
                stop_event.set()
                download_proxy = None
                
            sleep_time = max(1,GetSetting("min_service_interval", int))
##            sleep_time = 13
            Sleep_Start(sleep_time)
##            Sleep(sleep_time*1000)
            monitor.waitForAbort(sleep_time) 
            Sleep_End(sleep_time)

        Log("abortrequested"+threading.current_thread().name)
    except EndingException as ex:
        Log(ex.value,C.LOGINFO)
    except SystemExit as ex:
        Log('SystemExit',C.LOGERROR)
        traceback.print_exc()
    except:
        traceback.print_exc()
    finally:
        stop_event.set()
        if download_proxy:
            Log('Finally download_proxy stoppING')
            download_proxy.shutdown()
            download_proxy.socket.close()
        Log('Finally download_proxy stopped')


#__________________________________________________________________
#
def link_crawler(stop_event):
    sleep_time = int(GetSetting("min_service_interval", int)) //2
    try:
        Sleep_Start(sleep_time)
##        Sleep(sleeptime*1000)
        monitor.waitForAbort(sleep_time) 
        Sleep_End(sleep_time)
        while not monitor.abortRequested():
            if stop_event.is_set():
                raise EndingException("{} ending due to stop_event".format(
                                        threading.current_thread().name
                                        )
                                      )
            if GetSetting("enable_link_crawler", bool):
                plugin.index(create_icons=False) #index sites now
            sleep_time = max(
                1
                , GetSetting("min_service_interval", int)
                , int(GetSetting("service_periodic_interval", int) * (random.random()))
                )

            Sleep_Start(sleep_time)
##            Sleep(sleeptime *1000)
            monitor.waitForAbort(sleep_time) 
            Sleep_End(sleep_time)

        Log("monitor.abortRequested()"+threading.current_thread().name)
    except SystemExit as ex:
        Log('SystemExit',C.LOGWARNING)
        traceback.print_exc()
    except EndingException as ex:
        Log(ex.value)
    except:
        traceback.print_exc()
#__________________________________________________________________
#
try:

##    Log(__name__)
    if __name__ != '__main__':
##        xbmc.log(repr(__name__),xbmc.LOGERROR)
##        import traceback
        traceback.print_stack()
        exit(0)

##    xbmc.log("a",xbmc.LOGERROR)    
    C.DEBUG = GetSetting('debug')
    threading.current_thread().name = C.addon_id+".service"
##    LogR(threading.current_thread().ident,xbmc.LOGERROR)
    LogR(threading.current_thread().ident)
##    xbmc.log("a",xbmc.LOGERROR)

    proxy_thread_download_service = None    
    download_service_stop_event = threading.Event()

    proxy_thread_crawler = None
    crawler_stop_event = threading.Event()    

    while not monitor.abortRequested():

        try:
            # start thread for link_crawler service
            if GetSetting("enable_link_crawler", bool):
                if not proxy_thread_crawler: 
                    crawler_stop_event.clear()
                    proxy_thread_crawler = threading.Thread(
                        target=link_crawler
                        ,args=(crawler_stop_event,)
                        ,name=C.addon_id+".link_crawler"
                        )
##                    proxy_thread_crawler.daemon = True
                    proxy_thread_crawler.start()
                    Log("enable_link_crawler starting id {}".format(
                                proxy_thread_crawler.ident
                            )
                        )
                else:
                    Log("enable_link_crawler is already alive")
                    pass
            else:
                Log("enable_link_crawler=false. Will turn off if active")
                crawler_stop_event.set()
                proxy_thread_crawler = None

           # start thread for enable_download_service service
            if GetSetting("enable_download_service", bool):
                if not proxy_thread_download_service: # start thread
                    download_service_stop_event.clear()
                    proxy_thread_download_service = threading.Thread(
                        target=download_service
                        ,args=(download_service_stop_event,)
                        ,name=C.addon_id+".download_service"
                        )
##                    proxy_thread_download_service.daemon = True
                    proxy_thread_download_service.start()
                    Log("proxy_thread_download_service starting id {}".format(
                                proxy_thread_download_service.ident)
                                 )
            else:
                Log("proxy_thread_download_service=false. Will turn off if active")
                download_service_stop_event.set()
                proxy_thread_download_service = None

        except:
            traceback.print_exc()

        ## sleep then ... do some work
        sleep_time = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
        sleep_time = max(1,sleep_time,300)
        Sleep_Start(sleep_time)
##        Sleep(sleep_time*1000)
        monitor.waitForAbort(sleep_time) 
        Sleep_End(sleep_time)

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = GetSetting('debug')

    utils.global_cache.close()
##    utils.global_mem_cache_lock.release()
    Log("abortrequested"+threading.current_thread().name)
##    exit(0)
except:
    traceback.print_exc()
finally:
    Log("service finally")
    if proxy_thread_crawler:
        crawler_stop_event.set()
        proxy_thread_crawler.join()
        Log('proxy_thread_crawler joined')
    if proxy_thread_download_service:
        Log("proxy_thread_download_service joining")
        download_service_stop_event.set()
        proxy_thread_download_service.join()
        Log('proxy_thread_download_service joined')
    Log("service should be stopped",C.LOGERROR)
    del monitor
    
        
#__________________________________________________________________
#
