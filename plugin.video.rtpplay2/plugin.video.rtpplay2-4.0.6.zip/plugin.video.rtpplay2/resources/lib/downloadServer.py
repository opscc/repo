import socket
import threading
import traceback
import xbmc
    
import constants as C
from constants import SocketServer
from constants import reload
import downloaderHTTPRequestHandler
import thread_cache
import utils
from utils import Log,LogR
from utils import get_setting as GetSetting
from utils import set_setting as SetSetting

def close(self):
    xbmc.log("downloadserver close")
        
#__________________________________________________________________________
#
# helper function to select an unused port on the host machine
def select_unused_port():
    port = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('localhost', 0))
        addr, port = sock.getsockname()
        sock.close()
    except Exception as ex:
        traceback.print_exc()
        port = 59893
##    return 59893 #dev testing hardcode
    return port
#__________________________________________________________________________
#
class ThreadCacheTCPServer(SocketServer.TCPServer):
#"C:\Python312\Lib\socketserver.py"
    thread_cache = thread_cache.uwcSimpleCache()
    thread_cache._identifier = '__tcpserver__'
    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        xbmc.log("ThreadCacheTCPServer __init__")
        super().__init__(server_address, RequestHandlerClass, bind_and_activate)
    def server_close(self):
        self.socket.close()
        xbmc.log("ThreadCacheTCPServer server_close")
    def close(self):
        xbmc.log("ThreadCacheTCPServer close")
        
#__________________________________________________________________________
#
def StartListening():
    download_proxy = None
    proxy_thread = None

    # pick & store a port for the proxy service
    downloader_proxy_port = GetSetting("download_server_port", int)
    if not downloader_proxy_port > 8000:
        downloader_proxy_port = select_unused_port()
        Log("Autodetect for proxy service port selected as '{0}'".format(str(downloader_proxy_port)))
    else:
        Log("Static proxy service port selected as '{0}'".format(str(downloader_proxy_port)))
    SetSetting("download_server_port_current", downloader_proxy_port)

##        reload(downloaderHTTPRequestHandler) #reload during development so that I dont have to restart program

    ##todo; relocate @C.url_dispatcher.register elements so that below is possible
    #reload(utils) #reload during development so that I dont have to restart program
    
    # configure the proxy server
    download_proxy = ThreadCacheTCPServer(
        ('localhost', downloader_proxy_port)
        , downloaderHTTPRequestHandler.downloaderHTTPRequestHandler
    )
##    download_proxy.server_activate()
    download_proxy.timeout = 1
##    xbmc.log(repr(dir(download_proxy)),C.LOGERROR)
##    xbmc.log(repr(("download_proxy",download_proxy)),C.LOGERROR)

    # start thread for proxy server
    proxy_thread = threading.Thread(
        target=download_proxy.serve_forever
        )
##    proxy_thread.daemon = True
    proxy_thread.start()

    xbmc.log(repr(("dowloadserver.StartListening proxy_thread",proxy_thread.ident)),C.LOGERROR)

    #caller is responsible for sending shut down commands
    return download_proxy
