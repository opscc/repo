'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import sqlite3
import urllib
import json
import xbmc

import utils
from utils import Log,LogR
import constants as C
import downloader
    
FRIENDLY_NAME = '[COLOR {}]Cam4[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.cam4.com"

RESULTS_PER_PAGE = 60

SEARCH_URL = 'stub - make all sites consistent'

URL_FEMALES = ROOT_URL + "/directoryCams?directoryJson=true&online=true&url=true&gender=female&broadcastType=female_group&broadcastType=solo&page={}&orderBy=VIDEO_QUALITY&resultsPerPage={}" # + str(RESULTS_PER_PAGE)
URL_COUPLES = ROOT_URL + "/directoryCams?directoryJson=true&online=true&url=true&broadcastType=female_group&broadcastType=male_female_group&page={}&orderBy=VIDEO_QUALITY&resultsPerPage={}" #+ str(RESULTS_PER_PAGE)

MAIN_MODE          = C.MAIN_MODE_cam4
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CLEANDATABASE_MODE = str(int(MAIN_MODE) + 3)
REFRESH_MODE       = str(int(MAIN_MODE) + 4)
SEARCH_MODE        = str(int(MAIN_MODE) + 5)
TEST_MODE          = str(int(MAIN_MODE) + 6)

FIRST_PAGE = 1

_MIN_VALID_IMAGE_SIZE = 8000

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name="{}[COLOR {}]Couples[/COLOR]".format(C.SPACING_FOR_TOPMOST,C.search_text_color) 
        ,url=URL_COUPLES
        ,page_start=FIRST_PAGE
        ,mode=LIST_MODE
        ,iconimage=C.category_icon )

    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)

    List(URL_FEMALES, page_start=FIRST_PAGE, page_end=None, end_directory=True, keyword='', progress_dialog=progress_dialog)
#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
##    utils.Sleep(3000)
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page_start=1, depth=1, notify=False, progress_dialog=None):
    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    if '{}' in url and page_start:
        list_url = url.format(page_start,RESULTS_PER_PAGE*int(depth))
    else: list_url = url

    Log("list_url='{}'".format(list_url))

    json_html = utils.getHtml(list_url, cache_duration=C.default_ISONLINE_cache_duration)
    if not json_html: return json.loads("[]")
    
    json_items = json.loads(json_html)['users']

    play_method = ''#str(C.addon.getSetting("default_playmode").lower())

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = ROOT_URL

    for json_item in json_items:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        camscore=int(json_item["viewers"])
        hd = json_item["resolution"]
        hd = str(hd.split(':')[0])
        if   '4k' in hd :
            camscore=camscore*1
            hd = "[COLOR {}]uhd[/COLOR]".format(C.refresh_text_color)
        elif '1920' in hd :
            camscore=camscore*1
            hd = "[COLOR {}]fhd[/COLOR]".format(C.refresh_text_color)
        elif '1280' in hd :
            camscore=camscore*1
            hd = "[COLOR {}]hd[/COLOR]".format(C.time_text_color)
        elif '1152' in hd :
            camscore=camscore*1
            hd = "[COLOR {}]hd[/COLOR]".format(C.time_text_color)
        else:
            hd = ""
        name = json_item["username"]
        #Log("name='{}'".format(name))
        icon_image = json_item["snapshotImageLink"]
        #videourl = json_item["hlsPreviewUrl"]
        video_url = ROOT_URL + '/' + name
        label = "{}{} {}".format(C.SPACING_FOR_NAMES, utils.cleantext(name), hd)

        icon_image = icon_image + utils.Header2pipestring(headers)
    
        json_item['icon_label'] = label
        json_item['icon_image'] = icon_image
        json_item['video_url'] = video_url
        json_item['camscore'] = camscore
        json_item['mode'] = PLAY_MODE
        json_item['description'] = '\n' + ROOT_URL
        json_item['play_method'] = play_method
            
    return json_items
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword=''
         ,progress_dialog=None, bulk_operation=False):
    LogR(locals())

    utils.Add_Refresh_Item(REFRESH_MODE,end_directory=end_directory)

    models = GetCamgirlList(url, page_start, progress_dialog=progress_dialog)
    
    for model in models:
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            )

    if HasNextPage(url, page_start):
        np_number = int(page_start) + 1
        np_url = url
        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(C.SPACING_FOR_NEXT, C.search_text_color, np_number)
        if end_directory == True:
            utils.addDir(
                name= np_label
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page_start=np_number
                ,keyword=keyword )
        

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
#__________________________________________________________________________
#
def HasNextPage(url, page):
    #POST to get json info
    #page number and item count don't seem to matter, but using them anyway
    cam4_headers = {
                    'User-Agent': C.USER_AGENT
                    ,'Accept': "application/json, text/plain, */*"
                    ,'Referer': "{}".format(ROOT_URL)
                    }

    if '{}' in url and page:
        url = url.format(page, RESULTS_PER_PAGE)
    
    url = url.replace("directoryCams", "directoryCounts")
#    url = url.replace("https", "http")

    json_html = utils.postHtml(url, headers=cam4_headers, compression=True)
    if not json_html: return json.loads("[]")
    json_items = json.loads(json_html)

    total_count = json_items["totalCount"]
    total_count = int(total_count)
    page_window = RESULTS_PER_PAGE * int(page)
    Log("total_count='{}'".format(total_count))
    Log("page_window='{}'".format(page_window))

    has_next_page = (total_count > page_window)
    Log("has_next_page='{}'".format(has_next_page))
    return has_next_page
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name', 'img'], ['playmode_string', 'download', 'play_profile'])
def Playvid(url, name, icon_URI, download=None, playmode_string=None, play_profile=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

##    testmode = True

    headers = C.DEFAULT_HEADERS.copy()
    headers['Accept'] = 'application/json, text/plain, */*'
    headers['Referer'] = ROOT_URL

    interim_url = "{}/rest/v1.0/profile/{}/streamInfo".format(ROOT_URL, url.split('/')[3])
    Log("interim_url='{}'".format(interim_url)  )
    
    listhtml = utils.getHtml(interim_url, headers=headers)
##    Log("listhtml='{}'".format(listhtml)  )

    json_sources = json.loads(listhtml)
    if 'cdnURL' in json_sources:
        video_url = json_sources['cdnURL']

    #we should have a url by now...
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(url, ROOT_URL))
        return

    #always set referrer so that 'kodi' does not appear on the target server
    if '|' not in video_url:
        headers = C.DEFAULT_HEADERS.copy()
        if url: headers['Referer'] = url
        video_url = video_url + utils.Header2pipestring(headers)

    Log("video_url='{}'".format(video_url))

    #calculate potential download name here because I want to include recording date
    download_filespec = downloader.Make_download_path(
        name = name
        , include_date = True
        , file_extension = '.ts'
        )

    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return   #during testmode, only ensure that a url can be generated

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI
        , repeat_when_available = True
        )
#__________________________________________________________________________
#
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=1
    , page_end=1
    , progress_dialog=None
    , bulk_operation=False
    ):
    return True
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True, page_start=1, page_end=1
                  , progress_dialog=None, bulk_operation=False):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
    return True
    List(URL_RECENT, page_start=FIRST_PAGE, page_end=None, end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page_start=0)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(CLEANDATABASE_MODE)
def clean_database(showdialog=True):
    conn = sqlite3.connect(C.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            texture_list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%{}';".format("www.cam4.com"))
            for row in texture_list:
                conn.execute("DELETE FROM sizes WHERE idtexture = '%s';".format(row[0]))
                
                try:
                    os.remove(C.translatePath("special://thumbnails/" + row[1]))
##                    Log(C.translatePath("special://thumbnails/" + row[1]), C.LOGNONE)
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".cam4s.com")
            if showdialog:
                utils.notify('Finished','Cam4 images cleared')
    except:
        raise
        pass
#__________________________________________________________________________
#

def Camgirl_Generic_Image(model_id, url=None, current_icon=None):
    Log("refreshing icon for {}".format(repr(model_id)), C.LOGNONE)
    generated = False

    #site has generic banner whose size is smaller than this
    generic_icon_size = _MIN_VALID_IMAGE_SIZE
    icon_image_url = current_icon

    response = utils.getHtml(
        current_icon
        , send_back_response=True
        )
    LogR(response) #we don't want the generic banner
    if response and (len(response.data) > generic_icon_size): 
        icon_image_url = current_icon
        generated = True
        Log("current_icon was found; image {} ".format(repr(icon_image_url)), C.LOGNONE)
##    else:
##        #try using the current streaming pic
##        icon_image_url = "site does not have one".format(model_id)
##        response = utils.getHtml(
##            icon_image_url
##             , send_back_response=True
##             )
##        if not generated and (len(response.data) > generic_icon_size):
##            generated = True
##            Log("a current online image was found  {} ".format(repr(icon_image_url)), C.LOGNONE)

    LogR(icon_image_url
        , C.LOGNONE
        )
    return icon_image_url
#__________________________________________________________________________
#
