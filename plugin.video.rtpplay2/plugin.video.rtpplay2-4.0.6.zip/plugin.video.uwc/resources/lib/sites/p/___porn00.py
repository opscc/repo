'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import json
import re
import xbmc
import xbmcgui

import resolver
import search
import utils
from utils import Log,LogR
import constants as C

FRIENDLY_NAME = '[COLOR {}]Porn00[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_SCENES
FRONT_PAGE_CANDIDATE = True

ROOT_URL = "https://www.porn00.org"
SEARCH_URL = ROOT_URL + "/q/{}/{}/"
SEARCH_URL = ROOT_URL + "/searching/?q={}&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&from_videos={}"
#https://www.porn00.org/searching/?q=penny+barber&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=penny+barber&category_ids=&sort_by=&from_videos=3&from_albums=3
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/porn-page/{}/'
URL_MOST_VIEWED = ROOT_URL + '/most-viewed/'

MAIN_MODE       = C.MAIN_MODE_porn00
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)
TEST_MODE       = str(int(MAIN_MODE) + 5)

FIRST_PAGE = 1

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page_start=FIRST_PAGE, page_end=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)


#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    LogR(locals())

    if not progress_dialog: progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    
    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page_start, page_end, FIRST_PAGE)  

    # read html
    listhtml = utils.getHtml(list_url)
    if "No porn & pornstar were found" in listhtml:
        video_region = ""
        listhtml = ""
    else: #distinguish between adverts and videos
        video_region = listhtml.split('class="list-videos')[1]#.split('id="pagination"')[0]
        
    regex = ('div class="item.+?' 
             'href="([^"]+)".+?'
             'title="([^"]+)".+?'
             'data-original="([^"]+)".+?'
             '((?:<span class="is-hd"></span>|class="title")).+?'
             'class="duration">([^<]+)<')
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, hd, duration in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        hd = utils.Normalize_HD_String(hd)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , duration = duration
            , desc = '\n' + ROOT_URL
            , iconimage = thumb)
##    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    if (progress_dialog is None) or (progress_dialog and not progress_dialog.iscanceled()):
        utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
        if (testmode == True) and (len(videourl) > 1):
            Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)


    # next page items
    try:    
        next_page_regex = "<li class='.+?pagination.+?'>([^<]+)</div>"
        next_page_html = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    except:
        next_page_html = listhtml
    next_page_regex = '<li class="next">.+?:(\d+)">Next'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_number in np_info:
        np_number = int(np_number)
        np_url = url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page_start=np_number 
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))
                List(url=np_url
                     , page_start=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)
        break # in case there are multiple pagination
    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)        
#__________________________________________________________________________
#
##@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
##def Playvid(url, name, download=None, playmode_string=None):
##    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))

    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    elif playmode_string == C.PLAYMODE_DIRECT:  max_video_resolution = 99999 #if 'direct' was chosen, use max available resolution
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    progress_dialog = None
    
    try:
        progress_dialog = xbmcgui.DialogProgressBG()
        progress_dialog.create(u"Playing "+name)

        full_html = utils.getHtml(url, ROOT_URL)

        SITE_NOT_AVAILABLE_WARNINGS = {
            'Sorry, the website is temporary unavailable.'
            }

        if any(x in full_html for x in SITE_NOT_AVAILABLE_WARNINGS):
            utils.Notify("Website is temporary unavailable {}".format(name))
            Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
            return
            pass
        if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
            Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
            return
            pass

        regex = "license_code: '(?P<lic>[^']+)'"
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if not sources_list:
            utils.Notify("No license code for {}".format(name))
            return
        license_code = sources_list[0]
        Log("license_code={}".format(license_code))

        list_key_value = {}
        regex = "video_(?:alt_|)url: 'function\/0\/(?P<url>[^']+).+?(?:video_(?:alt_|)url_text: '(?P<res>[^']+)p')"
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
        for source_list in sources_list:
            Log("source_list={}".format(source_list))
            if source_list.group('res'):
                list_key_value[source_list.group('res')] = source_list.group('url')
            else:
                list_key_value['240'] = source_list.group('url')
        Log("list_key_value={}".format(list_key_value))

        if len(list_key_value) < 1: #try this other method
            regex = "video_url:\s+'function\/0\/(?P<url>[^']+)"
            sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
            Log("sources_list={}".format(sources_list))
            for source_list in sources_list:
                list_key_value['240'] = source_list.group('url')
            Log("list_key_value={}".format(list_key_value))
            

        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
        encoded_url = utils.SortVideos(
            sources=list_key_value
            ,download=download
            ,vid_res_column=0
            ,max_video_resolution=max_video_resolution
            )

        if not encoded_url:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
            return
        

        fappy_salt = resolver.FaapySalt(license_code, "")
        Log("fappysalt='{}'".format(fappy_salt))
        encoded_fappy_code =  encoded_url.split('/')[5][0:32]
        Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
        new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
        Log("new_fappy_code='{}'".format(new_fappy_code))
        video_url = encoded_url.replace(encoded_fappy_code, new_fappy_code)

        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        video_url = video_url + utils.Header2pipestring(headers)
        Log("video_url='{}'".format(video_url))

        if testmode:
            Log("video_url not played due to test mode")
            return
        
        utils.playvid(
            video_url
            , name=name
            , download=download
            , description=description
            , playmode_string=playmode_string
            , play_profile=play_profile
    ##        , download_filespec=download_filespec
            , mode = PLAY_MODE
    ##        , url_factory = url
    ##        , icon_URI = icon_URI            
            )
##        utils.playvid(video_url, name=name, download=download, description=description)

    finally:
        if progress_dialog: progress_dialog.close()
        progress_dialog = None


#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=0, progress_dialog=None):
    LogR(locals())

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page_start=page_start, page_end=page_end, end_directory=end_directory)
        return
    keyword = keyword.replace('+','-').replace(' ','-')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page_start=FIRST_PAGE, page_end=page_end
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page_start)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    url = URL_CATEGORIES
    root_url = url.split('/')[0] + '//' + url.split('/')[2]
    html = utils.getHtml(url, '')
    #cathtml = html.split('id="categorias"')[1]
    regex = 'class="col-md-12"(.*)'
    regex = 'class="list-categories"(.*)'
    cathtml = re.compile(regex, re.DOTALL).findall(html)[0]

    regex = 'class="item" href="([^"]+)".+?title="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label, thumb  in info:
        if not videourl.startswith('http'): videourl = root_url + videourl
        videourl = videourl + '/?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date&from={}'
        #Log("videourl='{}'".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page_start=FIRST_PAGE
            ,iconimage= thumb
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True, page_start=FIRST_PAGE, page_end=FIRST_PAGE):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))

    if not keyword:
        prev_keyword = utils.get_setting('quick_search_string')
        if prev_keyword: keyword = prev_keyword
    if not keyword:
        keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
        if  keyword == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=keyword)

    List(URL_RECENT, page_start=FIRST_PAGE, page_end=None, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page_start=FIRST_PAGE, page_end=page_end)
    Categories(URL_CATEGORIES, False)

    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
