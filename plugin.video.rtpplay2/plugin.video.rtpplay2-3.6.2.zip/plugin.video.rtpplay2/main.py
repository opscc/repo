# -*- coding: utf-8 -*-
import xbmc
def Log(msg):
    xbmc.log(repr(msg),xbmc.LOGNONE)
Log(sys.argv)
argv2 = repr(sys.argv[2])
Log(argv2)

reload_check = None
try:
    import re
    regex = "(\?reload=\d+)"
    reload_check = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(argv2)
    if reload_check:
        reload_check = reload_check[0]
    else:
        Log("reload is not present")
except:
    import traceback
    traceback.print_exc()

from resources.lib import plugin
if reload_check:
    Log(reload_check)
    Log("indexing only because reload present")
##    plugin.index()
else:
    import xbmcplugin
    if int(sys.argv[1]) > 0:
        xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available
plugin.routing_plugin.run()
    

#from xbmcplugin import endOfDirectory
#endOfDirectory(int(sys.argv[1]), cacheToDisc=True)


##utils.endOfDirectory(cacheToDisc=True)


##import threading
##thread = threading.Thread(
##        name='plugin.run'
##        ,target=plugin.run
##        ,args=()
##    )
##thread.daemon = True
##thread.start()

