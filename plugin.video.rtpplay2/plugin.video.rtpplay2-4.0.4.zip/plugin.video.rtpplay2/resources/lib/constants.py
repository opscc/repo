#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import random
import sys
import os.path
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

PY3 = sys.version_info >= (3, 0)
PY2 = not PY3

##xbmc.log(repr(sys.path),xbmc.LOGNONE)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
##xbmc.log(repr(sys.path),xbmc.LOGNONE)

if   PY3: from xbmcvfs import translatePath
elif PY2: from xbmc    import translatePath

if   PY3: from xbmcvfs import makeLegalFilename
elif PY2: from xbmc    import makeLegalFilename

if PY3: text_type = str  
if PY2: text_type = unicode #this keyword will raise error in PY3

import importlib
if PY2: from imp import reload
if PY3: from importlib import reload

import io
if PY2: import StringIO
if PY3: StringIO = io.StringIO

if PY2: import Queue
if PY3: import queue as Queue

if PY2: import cookielib
if PY3:     import http.cookiejar as cookielib

if PY2: import BaseHTTPServer
if PY3: import http.server as BaseHTTPServer

if PY2: import SocketServer
if PY3: import socketserver as SocketServer

if PY2: from urllib2 import urlparse    
if PY3: from urllib import parse as urlparse
##if PY3: from urllib.parse import urlparse
##if PY3: from urllib.parse import parse_qs

if PY2: from urllib import urlencode
if PY3: from urllib.parse import urlencode

if PY2: from urllib2 import unquote
if PY3: from urllib.parse import unquote

if PY2: from urllib import unquote_plus
if PY3: from urllib.parse import unquote_plus

if PY2: from urllib2 import quote
if PY3: from urllib.parse import quote

if PY2: from urllib import quote_plus
if PY3: from urllib.parse import quote_plus

if PY2: import urllib2
if PY3: import urllib.error as urllib2

if PY2: import SocketServer
if PY3: import socketserver as SocketServer

if PY2: from HTMLParser import HTMLParser
if PY3: from html.parser import HTMLParser

html_parser = HTMLParser()

from url_dispatcher import URL_Dispatcher
url_dispatcher = URL_Dispatcher()

if PY2: from HTMLParser import HTMLParser
if PY3: from html.parser import HTMLParser
html_parser = HTMLParser()
this_addon = xbmcaddon.Addon()
DEBUG = (this_addon.getSetting('debug').lower() == "true")
LOGNONE = xbmc.LOGNONE
if PY2: LOGWARNING = xbmc.LOGWARNING
if PY3: LOGWARNING = xbmc.LOGWARNING
LOGNOTICE = 11
LOGERROR = xbmc.LOGERROR
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0"
DEFAULT_RECURSE_DEPTH = 1

DEFAULT_HEADERS = {
    'User-Agent': USER_AGENT  
    
    #, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    #, 'Accept': '*.*;text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7'
    , 'Accept': 'text/html,application/xhtml+xml,application/xml,image/jpeg,*.*;q=0.9'
##    , 'verifypeer': 'false'
    , 'Accept-Encoding': 'gzip, deflate'
    , 'Accept-Language': 'en-US,en;q=0.9'
    }
    # , 'Connection': 'close'

##if DEBUG:
##    DEFAULT_HEADERS['verifypeer'] = 'false'
##xbmc.log(repr(DEBUG),xbmc.LOGNONE)

##xbmc.log(repr(sys),xbmc.LOGNONE)
##xbmc.log(repr(sys.argv),xbmc.LOGNONE)
if len(sys.argv) > 1: addon_handle = int(sys.argv[1])
else: addon_handle = -1

addon_id = str(this_addon.getAddonInfo('id'))
addon_name = this_addon.getAddonInfo('name')
addon = this_addon
progress = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = translatePath(rootDir)
resDir = os.path.join(rootDir, u'resources')
imgDir = os.path.join(resDir, u'images')

default_icon = translatePath(os.path.join(rootDir, 'icon.png'))

profileDir = addon.getAddonInfo('profile')
profileDir = translatePath(profileDir) #.decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')

refresh_text_color = addon.getSetting('refresh_text_color').lower()
search_text_color = addon.getSetting('search_text_color').lower()
time_text_color = addon.getSetting('time_text_color').lower()
highlight_text_color = addon.getSetting('highlight_text_color').lower()
program_text_color = addon.getSetting('program_text_color').lower()
test_text_color = addon.getSetting('test_text_color').lower()

test_passed_text_color = highlight_text_color

#icon_set = addon.getSetting('icon_set').lower()
icon_set = '5'

maximum_video_resolution = int(addon.getSetting("maximum_video_resolution"))#do this early so that it can be overriden later if necessary

DEFAULT_PLAYMODE_RTP = addon.getSetting('default_playmode_rtp').lower()  #allow playmode to be forced by input command, or use default from addon settings
DEFAULT_PLAYMODE = addon.getSetting('default_playmode').lower()  #allow playmode to be forced by input command, or use default from addon settings
PLAYMODE_F4MPROXY = 'f4mproxy'
PLAYMODE_INPUTSTREAM = 'inputstream'
PLAYMODE_DIRECT = '88888888'#'direct'
PLAYMODE_NO_OPTIONS = "NO_OPTIONS"
PLAYMODE_VARIABLE = 'VARIABLE_MAXRES'

PLAYMODE_PROFILE_00 = 'profile_00' #the download profile
PLAYMODE_PROFILE_01 = 'profile_01'
PLAYMODE_PROFILE_02 = 'profile_02'
PLAYMODE_PROFILE_03 = 'profile_03'
PLAYMODE_PROFILE_04 = 'profile_04'
VALID_PLAYMODE_PROFILES = [PLAYMODE_PROFILE_00,PLAYMODE_PROFILE_01,PLAYMODE_PROFILE_02,PLAYMODE_PROFILE_03,PLAYMODE_PROFILE_04]


##MAX_RECURSE_DEPTH = 10 #some sites will bann IP if too many requests

##DEFAULT_RECURSE_DEPTH = min(MAX_RECURSE_DEPTH, int(addon.getSetting('recursive_search_depth')))
INBAND_RECURSE = 'inband_recurse'

refresh_icon   = os.path.join(imgDir, "library_update_{}.png".format(icon_set) )
search_icon    = os.path.join(imgDir, "search_{}.png".format(icon_set) )
not_found_icon = os.path.join(imgDir, "search_{}.png".format(icon_set) )
next_icon      = os.path.join(imgDir, "next_{}.png".format(icon_set) )
category_icon  = os.path.join(imgDir, "category_{}.png".format(icon_set) )
warning_icon   = os.path.join(imgDir, "warning_{}.png".format(icon_set) )
success_icon   = os.path.join(imgDir, "greeninch.png")

if not os.path.exists(profileDir):
    os.makedirs(profileDir)

favoritesdb = os.path.join(profileDir, 'favorites.db')
linksdb = os.path.join(profileDir, 'links.db') #":memory:" #
downloadsdb = os.path.join(profileDir, 'downloads.db')

REFRESH_IMAGES_MODE = '898'

FAVORITES_MODE = '900'
ROOT_INDEX_FAVORITES = '901'
QWIK_SEARCH = '905'
ROOT_FRONT_PAGE = '906'
DELETE_KEYWORD = '904'
ADD_KEYWORD = '902'
CLEAR_SEARCH = '903'
CONFIGURE_INPUTSTREAM = '9999'

STOP_DOWNLOAD = '9995'
LIST_DOWNLOADS = '9994'

REFRESH_CONTAINER_MODE = '19900'
CONFIGURE_THIS_ADDON = '19910'
MANAGE_DOWNLOADS = '19998'
TESTALL = '20000'

ROOT_MANAGE_DOWNLOADS = '911'
ROOT_STOP_DOWNLOAD = '912'
ROOT_SEARCH_ALL = '8'

ROOT_INDEX_INDEX = '0' #must be zero for very first indexer

NO_ACTION_MODE = '0'
ROOT_INDEX_SCENES = '1'
FLAG_RECURSE_NEXT_PAGES = '-1'
FLAG_USE_RESOLVER_ONLY = 'USE_RESOLVER_ONLY'


DEFAULT_NOTIFY_TIME = 2000

SPACING_FOR_TOPMOST = chr(4)
SPACING_FOR_NAMES =  '' #chr(17)
SPACING_FOR_NEXT = chr(127)

DEFAULT_PROFILE_NAME = 'profile_01'

DOWNLOAD_INDICATOR = addon_id+".downlading."


DO_NOTHING_URL = 'DO_NOTHING_URL' #url is required in the adddir function, but there are moments when I don't want to set it

GC_SEARCHLOOP_ITERATIONS = 2000
GC_SEARCHLOOP_PAUSE = 50


STANDARD_MESSAGE_CATEGORY_LABEL = u"{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color, '{}')
STANDARD_MESSAGE_NO_VIDEO_FILE = u"Not found or deleted '{}' {}"
STANDARD_MESSAGE_NO_COUNTRY = u"Page {} is not available in your country"
STANDARD_MESSAGE_FAILED_SEARCH=u"[COLOR {}]failed search[/COLOR] on {} [error: {}]".format(highlight_text_color, '{}', '{}')
STANDARD_MESSAGE_CANCELLED_SEARCH=u"[COLOR {}]Search was Cancelled. Listing may be incompete[/COLOR]".format(highlight_text_color, )
STANDARD_MESSAGE_NEXT_PAGE = u"{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, search_text_color, '{}')
STANDARD_MESSAGE_NP_INFO = u"np_info not found in url='{}'"
STANDARD_MESSAGE_CATEGORIES = u"{}[COLOR {}]Categories[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_SEARCH = u"{}[COLOR {}]Search[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_SEARCH_RECURSIVE = u"{}[COLOR {}]Search Recursive[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_REFRESH = u"{}[COLOR {}]Refresh[/COLOR]".format(SPACING_FOR_TOPMOST, refresh_text_color)
STANDARD_DURATION_REFRESH = 55*60*60+55*60+55  #a cool-looking size for this number

STANDARD_MESSAGE_UHD  = u" [COLOR {}]uhd[/COLOR]".format(search_text_color)
STANDARD_MESSAGE_FHD  = u" [COLOR {}]fhd[/COLOR]".format(refresh_text_color)
STANDARD_MESSAGE_HD   = u" [COLOR {}]hd[/COLOR]".format(time_text_color)
STANDARD_MESSAGE_NOHD = ""

VIDEO_NOT_AVAILABLE_WARNINGS = [
    "This video has been flagged for verification"
    ,"This page is not available in your country."
    ,"Video has been removed at the request of "
    ,"Video has been flagged"
    ,"this video is no longer available"
    ,"This Video Is Private"
    ,"this video is private."
    ,"This video does not exist."
    ,"File has been removed due to copyright owner request"
    ]

channel_text_color = this_addon.getSetting('channel_text_color')
program_text_color = this_addon.getSetting('program_text_color')


FAVORITE_LISTING_TIMEOUT = 30 #seconds #how long to wait to discover if webcam model is online

WEBCRAWLER_THREAD_TIMEOUT = 10
MAX_WEBCRAWLER_THREADS = 60


TYPE_hls = 'hls'
TYPE_mp4 = 'mp4'
DOWNLOAD_TYPES = (TYPE_hls, TYPE_mp4)
TESTING_LIST_NAME = 'test_list' #setting.xml key containing which sites we have 'tested' and when they 'tested' successfully
#either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
# https://wiki.mozilla.org/CA/Included_Certificates
##if C.DEBUG: urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
#certPath = os.path.join(os.path.join(os.path.dirname(__file__), "websocket"),"cacert.2020-10-14.pem")
import certifi
certPath = certifi.where()


xbmc_version = xbmc.getInfoLabel('System.BuildVersion').split(' ')[0].split('.')
xbmc_version = [int(x) for x in xbmc_version]

try: default_GETHTML_cache_duration = int(addon.getSetting("GETHTML_cache_duration"))
except: default_GETHTML_cache_duration = 300 #seconds
try: default_ISONLINE_cache_duration = int(addon.getSetting("ISONLINE_cache_duration"))
except: default_ISONLINE_cache_duration = 77 #seconds

DEFAULT_IS_ONLINE_SERVER_NAME = '1.1.1.1'
DEFAULT_IS_ONLINE_SERVER_PORT = '80'

SERVICE_FIRST_SLEEPTIME = 10 #seconds before service begins; long enough for other stuff to start

FILE_MANIPULATION_ATTEMPTS = 3
TIME_BEFORE_FILE_MANIPULATION = 1000 #milliseconds

ROOT_TEST_ALL = 33000
MAIN_MODE_cmtv= 44000
MAIN_MODE_euronews= 44010
MAIN_MODE_fatima= 44020
MAIN_MODE_iptvorg= 44030
MAIN_MODE_methstreams= 44040
MAIN_MODE_rtp= 44050
MAIN_MODE_sportsdaddy = 44100
MAIN_MODE_tvi = 44110
