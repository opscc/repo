# -*- coding: utf-8 -*-

#import base libraries
import datetime
import os
import re
import traceback
#import internal addon libraries
import utils
import player
#define frequenctly used aliases
import constants as C
from utils import Log,LogR,Notify


MAIN_MODE          = C.MAIN_MODE_cmtv
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
LIST_ROW_MODE      = str(int(MAIN_MODE) + 6)

DEFAULT_SORT_ORDER = 40.0

###__________________________________________________________________________
###
@C.url_dispatcher.register(LIST_MODE)
def add_icons(
                subchannel = u''
              , subchannel_label = u''
              , sort_order = DEFAULT_SORT_ORDER
              , cache_as_json = False  
              , testmode = False
              , end_directory = False):
    try:

        if not subchannel: return  #for this set, only allow specific channels

        channel = subchannel
        program_name = subchannel #ignore program name because we don't have a tvguide for this

        if not sort_order: sort_order = DEFAULT_SORT_ORDER
        else: sort_order = float(sort_order)

        icon_label = u"[COLOR {}][B]{}[/B][/COLOR]".format(
            C.channel_text_color
             , subchannel_label 
            )
        if subchannel:
            icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon
        else:
            icon = ""
        #sometimes this value is decteced from some sort of home page; but for this site we only create a stub icon
        playable_url =  C.DO_NOTHING_URL 

        utils.Add_Listitem(
            mode = PLAY_MODE
            ,icon_label = icon_label
            ,url = playable_url
            #,program_name = program_name
            ,channel = subchannel
            ,icon = icon
            ,module_name = __name__.split('.')[-1]
            ,rating = sort_order
            ,playmode_string = u''
            ,play_profile = u''
            ,testmode = testmode
            ,cache_as_json = cache_as_json
            ,is_folder = False)

        return playable_url
    except:
        LogR(locals())
        raise
###__________________________________________________________________________
###
@C.url_dispatcher.register(PLAY_MODE, ['icon_label','url'], ['channel', 'program_name', 'icon', 'playmode_string', 'play_profile','download', 'testmode'])
def play(icon_label
         ,url
         ,channel=None
         ,program_name=u''
         ,icon=None
         ,playmode_string=None
         ,play_profile=None
         ,download=None
         ,testmode=False):

    try:
        channel = utils.s_d(channel)
        channel = channel.rstrip('PT') #temporary hack
        program_name = utils.s_d(program_name)
        icon_label = utils.s_d(icon_label)
        
        if not channel: raise Exception("channel is required")  #for this site, only allow specific channels
        
        download = bool(download)
        testmode = bool(testmode)

        download_filespec = None
        if download:
            dt = datetime.datetime.now().strftime('%Y-%m-%d')
            d_name = u"{}.{}.{}.ts".format(utils.Clean_Filename(icon_label), utils.Clean_Filename(channel).strip(' '), dt)
            download_filespec = utils.get_setting('download_path')
            if not download_filespec:
                download_filespec = None
            else:
                download_filespec = os.path.join(download_filespec, d_name)
                
        #
        #f4mproxy defaults
        #
        if not playmode_string:
            #direct kinda works, but kodi player drops if too out of sync; same with VLC  #2025-01-27
            playmode_string = C.PLAYMODE_DIRECT
            #inputstream works best #2025-01-27
            playmode_string = C.PLAYMODE_INPUTSTREAM
            #fmproxy does not work because audio and video are separate streams and i don't demux
        if playmode_string not in C.PLAYMODE_F4MPROXY:
            play_profile = None
        else:
            if play_profile not in C.VALID_PLAYMODE_PROFILES:
                play_profile = C.PLAYMODE_PROFILE_01

            
        if program_name: program_name = " ({})".format(program_name)
        name = u"[B][COLOR {}]{}[/COLOR]{}".format(
            C.channel_text_color
            , icon_label
            , program_name)

        headers = {
                   "Referer" : 'https://www.freeshot.live/' #2024-06-30
                   ,"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
                  }
        #
        #find out what the current ID is
        #site may work with one or the other; must try each
        #
        #2025-08-10 'lyrashield' embeds cookie in html
        u = "https://freeshot.live/embed/{}.php?d=1".format(channel)
        embed_html_1 = utils.getHtml(u, headers=headers)
        cookie = re.findall(r'document.cookie="(.+?);',embed_html_1)[0]
        location = re.findall(r'location.href="(.+?)"',embed_html_1)[0]
        u2 = "https://freeshot.live/embed/{}.php?d=2".format(channel)
        headers["Referer"] = location
        headers["Cookie"] = cookie
        embed_html = utils.getHtml(u2, headers=headers)
        regex = '<iframe src="(.+?)"'
        embed_info = re.compile(regex).findall(embed_html)[0]
        LogR(embed_info)
        
        if "?stream=" in embed_info:
            full_html = utils.getHtml("https:"+embed_info, headers=headers)
            regex = '<iframe allowfullscreen width="100%" height="100%" scrolling="no" frameborder="0" src="(.+?)/embed.html(\?token=.+?)&'   #2024-07-07
            embed_info=re.compile(regex).findall(full_html)
            embed_url=embed_info[0][0] 
            embed_token=embed_info[0][1]
            m3u8_url = embed_url + "/index.fmp4.m3u8" + embed_token
        else:
            #https://popcdn.day/stream/TVIPT.php  #2025-01-27
            full_html = utils.getHtml("https:"+embed_info, headers=headers) #2025-04
            regex = 'source: "(.+?)"'   #2024-07-16
            m3u8_url=re.compile(regex).findall(full_html)[0]

        headers = {
                "Accept" : "*/*"
                ,"Accept-Language": "en_US"
                ,"Cache-Control": "no-cache"
                ,"Icy-MetaData" : "0"
                ,"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
                  }
        video_url = m3u8_url + utils.Header2pipestring(headers) 


        #
        #what to do if we are just testing
        #
        if testmode:
            Log(repr(( "warning TESTMODE:"
                        , video_url
                        , icon_label
                        , playmode_string
                        , play_profile
                        , download
                        , download_filespec
    ##                    , m3u8_url
    ##                    , headers
                      )))
            utils.getHtml(m3u8_url,headers=headers)
            utils.endOfDirectory(end_directory=False)
            return

        #
        #what to do if we are serious
        #
        player.playvid(
            video_url
            , name=icon_label
            , playmode_string=playmode_string
            , play_profile=play_profile
            , download = download
            , download_filespec=download_filespec
        )

        return True
    except:
        LogR(locals())
        raise

#__________________________________________________________________________
#

#__________________________________________________________________________
# Unit tests
@C.url_dispatcher.register(TEST_MODE)
def TEST_MODE():
    test_label = ""
    module_name = __name__.split('.')[-1]
    try:

        test_label = u'{}€ download html and add all categories'.format(module_name)
        playable_url = add_icons(
            subchannel = u'{}'.format('CMTVPT') #case sensitive!
          , subchannel_label = u"€ CMTVPT €"
          , sort_order = None
          , testmode = True
          )
        Log(playable_url)

        test_label = u'play first {}€ category'.format(module_name)
        play(icon_label = test_label
             , channel = "CMTVPT"
             , url = playable_url
             , testmode=True
             )
##        utils.Sleep(5000)

        test_label = u'{}€ proxy profile 3'.format("TVIPT"   )
        play(icon_label = test_label
             , channel = "TVIPT"    #case sensitive!        
             , url = playable_url
             , playmode_string = C.PLAYMODE_F4MPROXY
             , play_profile = C.PLAYMODE_PROFILE_03
             , testmode = True
             )
##        utils.Sleep(5000)
    
        test_label = u'{}€ imputstream'.format("SICPT")
        play(icon_label = test_label
             , channel = "SICPT"   #case sensitive!     
             , url = playable_url
             , playmode_string = C.PLAYMODE_INPUTSTREAM
             , testmode = True
             )
##        utils.Sleep(5000)

#2024-02 - downloads not possible with f4mproxy ; site uses m4s files
##        test_label = u'{}€ download'.format(module_name)
##        play(
##             url =  playable_url
##             , channel = "SICPT"
##             , icon_label = test_label
##             , download = True
##             , testmode = False
##             )

    except ValueError:
        pass
    except Exception as e:
        traceback.print_exc()
        raise Exception(test_label)


    
#__________________________________________________________________________
#

