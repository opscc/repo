# -*- coding: utf-8 -*-
#__________________________________________________________________
#
import AES_key_net
import base64
import BaseHTTPServer
import re
import urlparse
import xbmc
import xbmcaddon

from resources.lib.utils import Log as Log
from resources.lib.utils import get_setting as GetSetting

#net = AES_key_net.Net(proxy='127.0.0.1:1025')
net = AES_key_net.Net()

#__________________________________________________________________
#
class AES_key_proxy(BaseHTTPServer.BaseHTTPRequestHandler):
#__________________________________________________________________
#
    def log_message(self, format, *args):
        return #"""Disables the BaseHTTPServer log."""
#__________________________________________________________________
#
    def do_GET(self):
        try:
            url = base64.b64decode(self.path[1:])
        except:
            url = self.path
            pass
        try:
            headers_string = '|'+url.split('|')[1]
            stream_headers = dict(urlparse.parse_qsl( headers_string  ))
        except:
            stream_headers = {}
            headers_string = ""
        try:
            url = url.split('|')[0]
        except:
            pass
        self.path = url
        self.send_response(200)
        resp =  net.http_GET(url=url, headers=stream_headers)
        get_url = resp.get_url()

        is_mpeg = False
        for h in resp.get_headers():
            h2 = h.split(":",1)
            h = h2[0]
            v = h2[1]
            if h in 'Content-Type':
                v = v.splitlines()[0].strip()
##                self.send_header(h, v)
                is_mpeg = (v == "application/vnd.apple.mpegurl")
        self.end_headers()

        if is_mpeg:
            get_url = resp.get_url()
            get_url = get_url[0:get_url.rindex('/')+1]
            content = resp.content
            regex = '#EXT-X-STREAM-IN.+?\n(.+?)(\n|$)'

            r = re.search(regex, content, re.DOTALL)
            if r:
                #go back to this proxy so that next packet can replace AES key path
##                Log('replacing stream')
                video_url = 'http://127.0.0.1:{}/'.format(GetSetting('AES_key_service_port_current'))+base64.b64encode(get_url+r.group(1)+headers_string)
##                Log(video_url)
                content = content.replace(r.group(1), video_url )
                

            regex = '(#EXT-X-KEY:METHOD=AES-128)'
            r = re.search(regex, content, re.DOTALL)
            if r:
##                Log('replacing key url')

                regex = '(key\d.mizhls.ru.+?)"'
                r = re.search(regex, content, re.DOTALL)
                if r:
                    content = content.replace(r.group(1), r.group(1).replace("key2.mizhls.ru","key.mizhls.ru")+headers_string)

                regex = '#EXTINF.+?\n(.+?)(?:\n|$)'
                search_results = re.findall(regex, content, re.DOTALL)
                for r in search_results:
                    content = content.replace(r,get_url + r )

##            Log(content)
            self.wfile.write(content)
            
        else:
            Log('writing content directly for '+get_url)
            self.wfile.write(resp.content)
#__________________________________________________________________
#
