# -*- coding: utf-8 -*-
from resources.lib import plugin
plugin.run()
##import threading
##thread = threading.Thread(
##        name='plugin.run'
##        ,target=plugin.run
##        ,args=()
##    )
##thread.daemon = True
##thread.start()

