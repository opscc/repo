# -*- coding: utf-8 -*-
import base64
import constants as C
import json
import re
import urllib
import utils
import traceback
import xbmc

from utils import Log
from utils import html_parser
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

RTP_BASE = "https://www.rtp.pt"

#__________________________________________________________________________
#
def addRTPicons(plugin, play):

##    Log(u"{}".format("Trio d´Ataque 2021".decode('utf8')))
##    xx = u"{}".format("T2rio d´Ataque 2021".decode('utf8').encode('unicode-escape'))
##    Log(xx)
##    return

##    full_html = utils.getHtml(RTP_BASE + "/play") #works 2021-02-22
    full_html = utils.getHtml(RTP_BASE + "/play/direto") #works 2021-04-22

    regex = (
        '(?s)<a\W+title=\"Emiss&atilde;o em direto ([^\"]+)\"'
        ' href=\"([^\"]+)\"'
        '.+?alt=\"Emiss&atilde;o em direto ([^\"]+)\"'
        '.+?src.*?=\"([^\"]+)\"'
        )
    match = re.compile(regex).findall(full_html)
    if not match:
        raise Exception("Error finding code on main RTP page")
        
    for prog, rel_url, channel, img in match:   

        if img.startswith("/"): img = "http:{}".format(img)
        img = img + utils.Header2pipestring()

        list_item = ListItem("[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
            C.channel_text_color
            , channel.decode('unicode-escape').encode('utf8')
            , C.program_text_color
            , prog.decode('unicode-escape').encode('utf8')
            )
        )
                
        list_item.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})

        if not channel.startswith('RTP'):
            channel = 'RTP ' + channel #lets me filter things later
            
        addDirectoryItem(
            plugin.handle
            , plugin.url_for(
                play
                , rel_url=kodiutils.smart_str(rel_url)
                #, channel=channel.decode('unicode-escape').encode('utf8')
                , channel=channel
                , img=kodiutils.smart_str(img)
##                , prog=prog.decode('unicode-escape').encode('utf8')
                #, prog=prog.decode('unicode-escape')
                , prog=prog
                )
            , list_item
            , False
            )
#__________________________________________________________________________
#
def play_rtp(prog,rel_url,channel,icon):
    Log(u"prog='{}',rel_url='{}',channel='{}',icon='{}'".format(prog,rel_url,channel,icon))

    rights_url= "https://www.rtp.pt/services/rtpplay/?v=5&ch_k=" + rel_url.split('/')[-1]
    string_rtp_rights = utils.getHtml(url=rights_url, save_cookie=True)
    json_rtp_rights = json.loads(string_rtp_rights)

##    if json_rtp_rights["rights"] != 1:
##        utils.Notify("No rights to see this from your country", duration=7000)
##        return
##    else:
##        Log('we have rights')

    full_html = utils.getHtml("{}{}".format(RTP_BASE, rel_url), save_cookie=True)
##    Log(full_html)

    final_stream_url = None
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                Log("first regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?hls\:.+?"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                Log("second regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('file:\W+"(.+?)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                Log("third regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        regex = (
            'file:\s+{\s+fps:""\s+,\s+hls:\s+decodeURIComponent\('
            '(.+?)'
            '\.join\(""\)\),\s+dash:""},'
            )
        streams = re.compile(regex, re.DOTALL).findall(full_html)
        for stream in streams:
            regex = '"(.+?)(?:",|"\])'
            stream = re.compile(regex, re.DOTALL).findall(stream)
            stream = "".join(stream)
            stream = urllib.unquote(stream)
            if ".m3u8" in stream.split('/')[-1]:
                final_stream_url = stream
                Log("fifth regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        regex = (
            'file:\s+{\s+fps:"[^"]+"\s+,\s+hls:\s+decodeURIComponent\('
            '(.+?)'
            '\.join\(""\)\),\s+dash:"'
            )
        streams = re.compile(regex, re.DOTALL).findall(full_html)
        for stream in streams:
            regex = '"(.+?)(?:",|"\])'
            stream = re.compile(regex, re.DOTALL).findall(stream)
            stream = "".join(stream)
            stream = urllib.unquote(stream)
            if ".m3u8" in stream.split('/')[-1]:
                final_stream_url = stream
                Log("sixth regex found final_stream_url='{}'".format(final_stream_url))
    if not final_stream_url:
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?fps:"([^"]+)"', re.DOTALL).findall(full_html)
        for stream in streams:
            if ".m3u8" in stream.split('/')[-1]: 
                final_stream_url = stream
                Log("fourth regex found final_stream_url='{}'".format(final_stream_url))


    #experimental
    mpd_stream_url = None
    mpd_key = None
    if mpd_stream_url is None:
        LICENSE_URL = 'https://widevine-license.vudrm.tech/proxy'
        SPECIAL_HEADERS = '|Content-Type=application/json&User-Agent=Mozilla/6.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36&Referer=https://www.rtp.pt/play/direto/rtp1&Origin=https://www.rtp.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en'
        POST_RESPONSE = '|J[licensetoken]'
        regex = (
            'drm: true.+?k: "([^"]+?)"'
            '.+?dash:"([^"]+?)"}'
            )
        streams = re.compile(regex, re.DOTALL).findall(full_html)
        for key, stream in streams:
            if ".mpd" in stream.split('/')[-1]:
                #urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed
                POST_DATA = '|' + urllib.quote_plus('{"token":"%s","drm_info":[D{SSM}],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % key)
                POST_DATA = '|' + ('{"token":"%s","drm_info":[8,4],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}' % key)
                drmresponse = LICENSE_URL + SPECIAL_HEADERS + POST_DATA + POST_RESPONSE
                mpd_key = key
                mpd_stream_url = stream
                Log("mpd_stream_url={}".format(repr(mpd_stream_url)))
                Log("drmresponse={}".format(repr(drmresponse)))
                Log("mpd_key={}".format(repr(mpd_key)))
                POST_DATA = ('{"token":"%s","drm_info":[8,4],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}'%key)
                #             {"token":"rtp|2021-07-04T20:08:21Z|pB4uhre+Wbw2+lxMRvf3nvueZ+popha6UZ7Cmh3OvAT87Mwn7OTChMSOiJzWQ+eSOLHuYQG1ci7hDJDUMbVMHhODdVCCvmXEAcg9UPppUJIdToMd1vMu2H+v5jmXf0jkEdHYijCBh1U0GCMxUGplamKMprQj15Dpj5Hh52U2ZWg=|ddc65b1e18b73013843e7b0af7055eadf42953ff"
                #                          ,"drm_info":[8,4],"kid":"E13506F7439BEAE7DDF0489FCDDF7481"}
                Log("POST_DATA={}".format(repr(POST_DATA)))
                break
    mpd_stream_url = None #dev
    if mpd_stream_url:
        PROTOCOL = 'mpd'
        DRM = 'com.widevine.alpha'
        import xbmcgui
        listitem = xbmcgui.ListItem(
            prog
            , iconImage="DefaultVideo.png"
            )
        listitem.setContentLookup(False)
        listitem.setMimeType('video/mp4')
        listitem.setProperty('IsPlayable', 'false')

        wv_proxy_base = 'http://localhost:8000'
        wv_proxy_url = '{0}?mpd_url={1}&token={2}'.format(
            wv_proxy_base
            ,base64.b64encode(mpd_stream_url)
            ,base64.b64encode(mpd_key)
            )
        license_key = wv_proxy_url + '||R{SSM}|'
        
        video_url = wv_proxy_url #+ utils.Header2pipestring()+ "&Referer=https://www.rtp.pt/play/"
        
        listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        listitem.setProperty('inputstream.adaptive.license_type', DRM)
        listitem.setProperty('inputstream.adaptive.license_key', POST_DATA)
        xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
        myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        myPlayList.add( video_url, listitem)
        xbmc.Player().play(myPlayList)
        return

    if not final_stream_url:
        regex = (
            'file:\s+{\s+fps:""\s+,\s+hls:\s+'
            '(.+?)'
            ',\s+dash:""},'
            )
        streams = re.compile(regex, re.DOTALL).findall(full_html)
        for stream in streams:
            Log("stream={}".format(repr(stream)))
            if ".m3u8" in stream.split('/')[-1]:
                final_stream_url = stream
                Log("sixth regex found final_stream_url='{}'".format(final_stream_url))

    Log("final_stream_url='{}'".format(final_stream_url))
    if final_stream_url is None:
        Log(full_html)
        utils.Notify("Unexpected error: playable url was not found", duration=7000)
        return
    
    playmode_string = C.DEFAULT_PLAYMODE_RTP
    mimetype = "video/mp2t"
    if 'liveradio' in final_stream_url:
        mimetype = "mp2"
        if playmode_string == C.PLAYMODE_INPUTSTREAM:
            playmode_string = C.PLAYMODE_DIRECT #PLAYMODE_INPUTSTREAM can't play this
    

    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(C.channel_text_color, channel, prog)
    url = final_stream_url + utils.Header2pipestring()+ "&Referer=https://www.rtp.pt/play/"

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile="profile_03"
        , mimetype = mimetype
        )
#__________________________________________________________________________
#
