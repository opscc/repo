# -*- coding: utf-8 -*-
import os
import routing
import sys
import timeit
import threading
import traceback
import utils
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import constants as C
from utils import Log as log
from utils import Log

from resources.lib.sites import *

routing_plugin = routing.Plugin()

###with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
##xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_INPUTSTREAM)
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________
#
@routing_plugin.route('/'+C.REFRESH_CONTAINER_MODE)
def RefreshContainter():
    xbmc.executebuiltin('Container.Refresh')
##    list_item = xbmcgui.ListItem('fake')
##    xbmcplugin.setResolvedUrl(C.addon_handle, True, list_item)
##    utils.endOfDirectory()

#__________________________________________________________________________
#
def get_sites(function_name, plugin_filter=''):
    import importlib
    sites = ['fatima','sportsdaddy','euronews','rtp','tvi'] #
    for plugin in sites:
        if plugin_filter and plugin_filter.lower() != plugin:
            continue
        module = importlib.import_module('resources.lib.sites.'+plugin)
        if hasattr(module, function_name):
##            Log(repr(dir(module)))
            module = getattr(module, function_name)
            yield (plugin, module)
    return 
#__________________________________________________________________________
#
@routing_plugin.route('/')
def index():

    progress_dialog = None
##    progress_dialog = utils.Progress_Dialog(C.addon_name,"indexing {}".format('...'))

    # I want a particular default order for the items
    # I can't guarantee the order with listitems being added inside the threads,
    #   and so I store the data in a cache [using memory for now],
    #   and add the items when done
    with utils.global_mem_cache_lock:
        utils.global_mem_cache.set(
             endpoint = (utils.CACHE_STRING+'_size')
            ,data = 0
             )
                
    worker_threads = []
    try:
        for plugin_name, module in get_sites(function_name='add_icons',plugin_filter=''):
            if utils.get_setting('list_'+ plugin_name):
                worker = threading.Thread(name=plugin_name
                                          ,target=module
                                          ,args=(routing_plugin
                                                 ,play
                                                )
                                  )
                worker.daemon = True
                worker_threads.append(worker)
                worker.start()
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding TVI", duration=4000)


    try:
        max_time = 120 #divide by 4 to get seconds_to_wait_for_search
        cur_time = 0
        still_working = True
        while still_working and (cur_time < max_time) :
            if progress_dialog and progress_dialog.iscanceled(): break
            if progress_dialog: progress_dialog.increment_percent()
            cur_time += 1
            utils.Sleep(250)
            still_working = False
            for worker in worker_threads:
                if worker.is_alive():
                    still_working = True
                    break #keep waiting for active task
    except:
        traceback.print_exc()


    #I can't get this to work how I wan't with multithreaded modules;  maybe create a unique _module_ for this
    if utils.get_setting('list_sportsdaddy'):
        channel = 722
        utils.addPlaylink(
            routing_plugin
            ,playlink_name = '[B][COLOR {}]SIC[/COLOR][/B]'.format(
                    C.channel_text_color
                )
            ,final_url = 'plugin://plugin.video.rtpplay2/play?&channel=sportsdaddy&prog=SIC&img=%2F&rel_url=/stream-'+str(channel)+'.php'
            ,program_name = 'SIC'
            ,channel='SIC'
            ,icon= os.path.join(C.imgDir, 'sic.png')
            ,play=play
            ,module_name='sportsdaddy'
            ,rating=37
            ,return_json_info = True
            ,is_folder = False
            ,filter_category = ''
            )
        channel = 719
        utils.addPlaylink(
            routing_plugin
            ,playlink_name = '[B][COLOR {}]RTP 1[/COLOR][/B]'.format(
                    C.channel_text_color
                )
            ,final_url = 'plugin://plugin.video.rtpplay2/play?&channel=sportsdaddy&prog=rtp1&img=%2F&rel_url=/stream-'+str(channel)+'.php'
            ,program_name = 'RTP 1'
            ,channel='RTP 1'
            ,icon= os.path.join(C.imgDir, 'rtp1.png')
            ,play=play
            ,module_name='sportsdaddy'
            ,rating=39
            ,return_json_info = True
            ,is_folder = False
            ,filter_category = ''
            )
        utils.addPlaylink(
            routing_plugin
            ,playlink_name = '[B][COLOR {}]Soccer[/COLOR][/B]'.format(
                    C.channel_text_color
                )
            ,final_url = 'plugin://plugin.video.rtpplay2/sportsrows?&filter_category=Soccer'
            ,program_name = 'Soccer'
            ,channel='sportsdaddy'
            ,icon= os.path.join(C.imgDir, 'soccer.png')
            ,play=play
            ,module_name='sportsdaddy'
            ,rating=38
            ,return_json_info = True
            ,is_folder = True
            ,filter_category = 'Soccer'
            )


##    try:

##        utils.addPlaylink(
##            routing_plugin
##            ,playlink_name = '[B][COLOR {}]Refresh[/COLOR][/B]'.format(C.time_text_color)
##            ,final_url = 'plugin://plugin.video.rtpplay2/'+C.REFRESH_CONTAINER_MODE
##            ,program_name = str(C.REFRESH_CONTAINER_MODE)
##            ,channel= str(C.REFRESH_CONTAINER_MODE)
##            ,icon= ''
##            ,play=RefreshContainter
##            ,module_name='plugin'
##            ,rating=9997
##            ,return_json_info = True
##            ,is_folder = False
##            ,filter_category = ''
##            )

##        Log(repr(routing_plugin.url_for(
##                        RefreshContainter
##                    )))
##        list_item = xbmcgui.ListItem(
##            label='[B][COLOR {}]Refresh[/COLOR][/B]'.format(C.time_text_color)
##            )
##        list_item.setInfo(type="video", infoLabels={
##            "sorttitle": "a{:0>10}".format(int(9997))
##            ,"duration": 9997
##            ,"rating": 9.9} )
##        xbmcplugin.addDirectoryItem(
##            handle=routing_plugin.handle
##            , url=routing_plugin.url_for(
##                RefreshContainter
##            )
##            , listitem=list_item
##            , isFolder=False
##        )
##    except:
##        traceback.print_exc()



##    if utils.get_setting('list_sportsdaddy'):
##        pass
##
##        channel = 722
##        plugin_url = 'plugin://plugin.video.rtpplay2/sportsrows?&filter_category=Soccer'
##        list_item = xbmcgui.ListItem(
##            label='[B][COLOR {}]Soccer[/COLOR][/B]'.format(
##                    C.channel_text_color
##                )
##            )
##        list_item.setArt({"thumb":    os.path.join(C.imgDir, 'soccer.png')  })
##        list_item.setContentLookup(False)
##        list_item.setProperty('IsPlayable', 'false')        
##        list_item.setInfo(type="video"  #setting to video will create a circle...which is okay for me because sorting is more important
##                          , infoLabels={"sorttitle": "a{:0>10}".format(int(38))
##                                        ,"playcount":"0" #remove the filled in circle from our skin
##                                        }
##                          )
##        xbmcplugin.addDirectoryItem(
##            handle=routing_plugin.handle
##            , url = plugin_url
##            , listitem=list_item
##            , isFolder=True
##        )



##        plugin_url = 'plugin://plugin.video.rtpplay2/play?&channel=sportsdaddy&prog=SIC&img=%2F&rel_url=%2Fstream-'+str(channel)+'.php'
##        list_item = xbmcgui.ListItem(
##            label='[B][COLOR {}]SIC[/COLOR][/B]'.format(
##                    C.channel_text_color
##                )
##            )
##        list_item.setArt({"thumb":    os.path.join(C.imgDir, 'sic.png')  }) 
##        list_item.setProperty('IsPlayable', 'true')
##        list_item.setInfo(type="video", infoLabels={"country": "Portugal"
##                                                    ,"sorttitle": "a{:0>10}".format(int(39))
##                                                    ,"playcount":"0" #remove the filled in circle from our skin
##                                                    })
##        xbmcplugin.addDirectoryItem(
##            handle=routing_plugin.handle
##            , url = plugin_url
##            , listitem=list_item
##            , isFolder=False
##        )

        
##        plugin_url = 'plugin://plugin.video.rtpplay2/play?&channel=sportsdaddy&prog=rtp1&img=%2F&rel_url=%2Fstream-'+str(channel)+'.php'
##        list_item = xbmcgui.ListItem(
##            label='[B][COLOR {}]RTP 1[/COLOR][/B]'.format(
##                    C.channel_text_color
##                )
##            )
##        list_item.setArt({"thumb":    os.path.join(C.imgDir, 'rtp1.png')  }) 
##        list_item.setProperty('IsPlayable', 'true')
##        list_item.setContentLookup(False)
##        list_item.setInfo(type="video", infoLabels={"country": "Portugal"
##                                                    ,"sorttitle": "a{:0>10}".format(int(40))
##                                                    ,"playcount":"0" #remove the filled in circle from our skin
##                                                    })
##        xbmcplugin.addDirectoryItem(
##            handle=routing_plugin.handle
##            , url = plugin_url
##            , listitem=list_item
##            , isFolder=False
##        )



    #threads done by now; use the info to add listitems in our preferred order
    try:
        json_items = {}
        with utils.global_mem_cache_lock:
            size = utils.global_mem_cache.get(
                endpoint = (utils.CACHE_STRING+'_size')
                )
            for i in range(1,size+1,1): #add all to a list
                json_item = utils.global_mem_cache.get(
                         endpoint = (utils.CACHE_STRING+"_icons+"+str(i))
                         )
                json_items[json_item['rating']] = json_item
                
        #sort all of them and add listitems the sorted order
        for k in sorted(json_items.keys()):
            json_item = json_items[k]
            utils.addPlaylink(
                routing_plugin
                ,playlink_name = json_item['name']
                ,final_url = json_item['final_url']
                ,program_name = json_item['program_name']
                ,channel = json_item['channel']
                ,icon = json_item['icon']
                ,play = play #json_item['play']
                ,module_name = json_item['module_name']
                ,rating = json_item['rating']
                ,filter_category = json_item['filter_category']
                ,is_folder = json_item['is_folder']
                ,return_json_info = False
                )
    except:
        traceback.print_exc()



    try:
        list_item = xbmcgui.ListItem(
            label='[B][COLOR {}]Refresh[/COLOR][/B]'.format(C.time_text_color)
            )
        list_item.setInfo(type="video", infoLabels={
            "sorttitle": "a{:0>10}".format(int(9997))
            } )
        xbmcplugin.addDirectoryItem(
            handle=routing_plugin.handle
            , url=routing_plugin.url_for(
                RefreshContainter
            )
            , listitem=list_item
            , isFolder=False
        )
    except:
        traceback.print_exc()


    try:
        list_item = xbmcgui.ListItem(
            label='[B][COLOR {}]Settings[/COLOR][/B]'.format(C.highlight_text_color)
            ,iconImage=C.default_icon
            ,thumbnailImage=C.default_icon 
            )
        list_item.setInfo(type="video", infoLabels={
            "sorttitle": "a{:0>10}".format(int(9999))
            } )
        xbmcplugin.addDirectoryItem(
            handle=routing_plugin.handle
            , url=routing_plugin.url_for(
                configure_THIS_addon
            )
            , listitem=list_item
            , isFolder=False
        )
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Configuration icon", duration=2000)

    utils.endOfDirectory(updateListing=True)
    

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_THIS_ADDON)
def configure_THIS_addon():
    xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    import xbmcaddon
    xbmcaddon.Addon(id=C.addon_id).openSettings()
    return True
#__________________________________________________________________________
#
@routing_plugin.route('/play')
def play():

##    Log(repr(sys.argv))
##    Log(repr(routing_plugin.args))

    rel_url = routing_plugin.args["rel_url"][0]
    channel = routing_plugin.args["channel"][0]
    prog = routing_plugin.args["prog"][0]
    if "img" in routing_plugin.args:                  icon = routing_plugin.args["img"][0]
    else:         icon = None
    if "module_name" in routing_plugin.args:          module_name = routing_plugin.args["module_name"][0]
    else:         module_name = channel
    if "playmode_string" in routing_plugin.args:      playmode_string = routing_plugin.args["playmode_string"][0]
    else:          playmode_string = None
    if "play_profile" in routing_plugin.args:         play_profile = routing_plugin.args["play_profile"][0]
    else:         play_profile = None

    if '\\x' in prog:         prog = prog.decode('unicode-escape').encode('utf8')
    if '\\x' in channel:      channel = channel.decode('unicode-escape').encode('utf8')
    if '\\x' in rel_url:      rel_url = rel_url.decode('unicode-escape').encode('utf8')
    
    #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )

    if "filter_category" in routing_plugin.args and routing_plugin.args["filter_category"][0]:
##        Log('hwere')
        sportsrows()
        return True
    
##    if channel == C.REFRESH_CONTAINER_MODE and  module_name == 'plugin':
##        Log('h')
##        RefreshContainter()
##        utils.endOfDirectory()
##        return True

    for plugin_name, module in get_sites(function_name='play',plugin_filter=module_name):
        module(prog,rel_url,channel,icon,playmode_string,play_profile)
        return True

    #we should not get here
    Log("error can't find rout to " + repr((channel,prog,module_name)))
    return True

#__________________________________________________________________________
#
        
@routing_plugin.route('/sportsrows')
def sportsrows():
    try:
        filter_category = routing_plugin.args["filter_category"][0]
##        import sportsdaddy
        from resources.lib.sites import sportsdaddy
        sportsdaddy.Add_Icons_Rows(routing_plugin, play, filter_category)
        utils.endOfDirectory()
    except:
        traceback.print_exc()
#__________________________________________________________________________
#
