# -*- coding: utf-8 -*-



import xbmc
import xbmcgui


import inputstreamhelper
import urllib

import routing
import logging
import requests
import re
import xbmcaddon
import json

from sys import exit, version_info
from resources.lib import kodiutils
from resources.lib import kodilogging
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl


ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))
kodilogging.config()
plugin = routing.Plugin()


PROTOCOL = 'mpd'
DRM = 'com.widevine.alpha'
#STREAM_URL = 'https://demo.unified-streaming.com/video/tears-of-steel/tears-of-steel-dash-widevine.ism/.mpd'
#LICENSE_URL = 'https://cwip-shaka-proxy.appspot.com/no_auth'


__headers__ = {"User-Agent": "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"}
__base_url__ = "http://www.rtp.pt"
__session__ = requests.Session()

TVI_BASE = "http://tviplayer.iol.pt"

if version_info >= (3, 0):
	from html.parser import HTMLParser
else:
	from HTMLParser import HTMLParser
html_parser = HTMLParser()



        

def addTVIIcons(plugin):
        
        try:
		req = __session__.get(TVI_BASE+ "/direto").text
        except Exception, e:
                notify("getting TVI main page", str(e), 4000) 
        
        
        match=re.compile('class="direto-canal-box videoUpdate" data-canal="(.+?)"\W*<a href="(.+?)".+img src="(.+?)"[\w\W]*?link-programa">\s+(.+?)\W*<\/a>').findall(req)       
        if match:
                for channel,rel_url,img,prog in match:
                        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                        liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                        liz.setProperty('IsPlayable', 'true')
                        liz.setInfo("Video", infoLabels={"plot": prog})
                        finalurl=TVI_BASE+rel_url
                        addDirectoryItem(plugin.handle, plugin.url_for(play
                                                                       , rel_url=kodiutils.smart_str(finalurl)
                                                                       , channel=kodiutils.smart_str(channel)
                                                                       , img=kodiutils.smart_str(img)
                                                                       , prog=kodiutils.smart_str(prog) ), liz, False)


def addTVIIcon(plugin):
        try:
		req = __session__.get("http://tviplayer.iol.pt/direto/TVI").text
        except Exception, e:
                notify("getting TVI main page", str(e), 4000) 
        channel = "TVI"
        prog = "TVI"
        match=re.compile('videoUrl = "(.+?)"').findall(req)
       
        if match:
                i=0
                for rel_url in match:
                        i=i+1
                        #four urls are found, just use the last one
                        finalurl=rel_url

                liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(i)))
                img = "http://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/58ab3cae0cf2b10cb661350e"
                liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                liz.setProperty('IsPlayable', 'true')
                liz.setInfo("Video", infoLabels={"plot": i})
                addDirectoryItem(plugin.handle, plugin.url_for(play
                                                               , rel_url=kodiutils.smart_str(finalurl)
                                                               , channel=kodiutils.smart_str(prog)
                                                               , img=kodiutils.smart_str(img)
                                                               , prog=kodiutils.smart_str(prog) ), liz, False)
                        
                
def addTVI24Icon(plugin):
        try:
		req = __session__.get("http://tviplayer.iol.pt/direto/TVI24").text
        except Exception, e:
                notify("getting TVI main page", str(e), 4000) 
        channel = "TVI24"
        prog = "TVI24"
        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
        match=re.compile('videoUrl = "(.+?)"').findall(req)
        if match:
                for rel_url in match:
                        img = "http://www.iol.pt/multimedia/oratvi/multimedia/imagem/id/58ab3cc20cf2b10cb6613516"
                        liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                        liz.setProperty('IsPlayable', 'true')
                        liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
                        addDirectoryItem(plugin.handle, plugin.url_for(play, rel_url=kodiutils.smart_str(rel_url), channel=kodiutils.smart_str(channel), img=kodiutils.smart_str(img), prog=kodiutils.smart_str(prog) ), liz, False)
                        break

        

def addFatimaIcon(plugin):
        try:
		req = __session__.get("http://www.fatima.pt/en/pages/online-transmissions").text
        except Exception, e:
                kodiutils.ok(str(e),"getting fatima page")
        channel = "Fatima"
        prog = "Fatima"
        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
        match=re.compile('<iframe allowfullscreen="" frameborder="0" scrolling="no" src="http:.+file=(.+)&amp;[\w\W]+youtube\.com\/embed\/(\w+)').findall(req)
        if match:
                for rel_url,img in match:
                        rel_url = rel_url + "?all=1"
                        img = "https://i.ytimg.com/vi/" + img + "/maxresdefault_live.jpg"
                        liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
                        liz.setProperty('IsPlayable', 'true')
                        liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
                        addDirectoryItem(plugin.handle, plugin.url_for(play, rel_url=kodiutils.smart_str(rel_url), channel=kodiutils.smart_str(channel), img=kodiutils.smart_str(img), prog=kodiutils.smart_str(prog) ), liz, False)
        

@plugin.route('/')
def index():

        try:
		req = __session__.get("http://www.rtp.pt/play/", headers=__headers__).text
	except:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32001))
		exit(0)
		
	match=re.compile('<a title=".+?direto (.+?)" href="(.+?)".+?img.+?src="(.+?)" class="img-responsive">.+?<span class="small"><b>(.+?)</b>').findall(req)
	if match:
                i = 0
		for channel ,rel_url ,img ,prog in match:
                        if i == 3:
                                addFatimaIcon(plugin)
                                #addTVI24Icon(plugin)
                                #addTVIIcon(plugin)
                                addTVIIcons(plugin)
                        
			liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
			if img.startswith("/"):
				img = "http:{}".format(img)
			
			liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
			liz.setProperty('IsPlayable', 'true')
			liz.setInfo("Video", infoLabels={"plot": html_parser.unescape(kodiutils.smart_str(prog))})
			
			addDirectoryItem(plugin.handle, plugin.url_for(play, rel_url=kodiutils.smart_str(rel_url), channel=kodiutils.smart_str(channel), img=kodiutils.smart_str(img), prog=kodiutils.smart_str(prog) ), liz, False)
                        i = i + 1
                        
	endOfDirectory(plugin.handle)


@plugin.route('/play')
def play():
	rel_url = plugin.args["rel_url"][0]
	channel = plugin.args["channel"][0]
	prog = plugin.args["prog"][0]
	icon = plugin.args["img"][0]


        #notify("TVI", prog, 1000)
        #notify("TVI", channel, 1000)
        if channel.startswith('TVI'):
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify("TVI", "parsing TVI page", 1000)
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify("TVI", rel_url, 1000)
                req = __session__.get(rel_url).text
                match=re.compile('videoUrl = "(.+?)"').findall(req)
                for rel_url in match:
                        #four urls are found, just use the last one
                        final_stream_url=rel_url

                #this is an m3u8 file, force the slowest stream
                req = __session__.get(final_stream_url, verify=False).text
                pattern = '#EXT-X-STREAM-INF:BANDWIDTH=(\d+?),.*\\n(.+?)\\n'
                streams = re.findall(pattern, req)
                if streams:
                    if kodiutils.get_setting_as_bool("debug"):
                        notify("TVI", "streamsfound", 1000)
                    best = 9999999
                    for bandwidth, stream_url in streams:
                        if kodiutils.get_setting_as_bool("debug"):
                                notify("bandwidth", str(bandwidth), 5000)
                        if int(bandwidth) < best:
                            best = int(bandwidth)
                            playurl = stream_url

                match=re.compile('(http[sS]?:[\/]{2}.*?)(\/.*)').findall(final_stream_url)
                for baseURL, relURL in match:
                        playurl = baseURL + "/" + playurl
                #playurl = playurl.replace("https://","http://")

                if kodiutils.get_setting_as_bool("debug"):
                        notify("TVI", playurl, 10000)
                xbmc.log(playurl)
                final_stream_url = playurl
                
                liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                liz.setArt({"thumb": icon, "icon": icon})
                liz.setProperty('IsPlayable', 'true')
                liz.setProperty('IsFolder', 'false')

                
                liz.setPath("{}|Origin=http://tviplayer.iol.pt&Accept-Encoding=gzip, deflate, br&Accept-Language=en-US,en;q=0.9&Referer=http://tviplayer.iol.pt/direto/TVI&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36".format(final_stream_url))
                setResolvedUrl(plugin.handle, True, liz)
                exit(0)
                
        
        if prog == "Fatima":
                try:
                        #kodiutils.ok("Debug:" + rel_url, "Fatima")
                        match=re.compile('(http[sS]?:[\/]{2}.*?)(\/.*)').findall(rel_url)
                        if match:
                                #kodiutils.ok("Debug:" + repr(match[0]), "match[0]")
                                for baseURL, relURL in match:
                                        #req = __session__.get("{}{}".format(baseURL, relURL).text
                                        #kodiutils.ok("Debug:" + baseURL, "baseURL")
                                        #kodiutils.ok("Debug:" + relURL, "relURL")
                                        #req = __session__.get("{}{}".format("http://rd3.videos.sapo.pt", "/v6Lza88afnReWzVdAQap/mov/24?all=1")).text
                                        req = __session__.get("{}{}".format(baseURL, relURL)).text
                                        d = json.loads(req)
                                        #kodiutils.ok(d['hls'],"json hls string")
                                        liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
                                        liz.setArt({"thumb": icon, "icon": icon})
                                        liz.setPath("{}".format(d['hls']))
                                        setResolvedUrl(plugin.handle, True, liz)
                                        exit(0)
                except Exception, e:
                        kodiutils.ok(str(e),"unknown error playing " + prog)
                        exit(1)

                exit(0)



        
        if prog == "TVI24":
                try:
                        if kodiutils.get_setting_as_bool("debug"):
                                notify("TVI24 play", "playing" + rel_url, 1000)
                        liz = ListItem(path=rel_url)
                        liz.setArt({"thumb": icon, "icon": icon})
                        setResolvedUrl(plugin.handle, True, liz)
                        exit(0)
                except Exception, e:
                        kodiutils.ok(str(e),"unknown error playing " + prog)
                        exit(1)
                exit(0)

        if prog == "TVI":
                try:
                        if kodiutils.get_setting_as_bool("debug"):
                                notify("TVI play", "playing" + rel_url, 1000)
                        liz = ListItem(path=rel_url)
                        liz.setArt({"thumb": icon, "icon": icon})
                        setResolvedUrl(plugin.handle, True, liz)
                        exit(0)
                except Exception, e:
                        kodiutils.ok(str(e),"unknown error playing " + prog)
                        exit(1)
                exit(0)
                


	try:
		req = __session__.get("{}{}".format(__base_url__, rel_url)).text
	except:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
		exit(0)

	is_pseudo_aes = bool(re.findall("var aes = true", req))
		
	streams = ''
	final_stream_url = ''
        #streams = re.compile('new RTPPlayer\([\w\W]*file\:.+?"(.+?)"', re.DOTALL).findall(req)
        #streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?file\:.+?"(.+?)"', re.DOTALL).findall(req)
        #regex working 2018-04-15 to 2018-05-03
        streams = re.compile('dash\:"(.+?)"', re.DOTALL).findall(req)
        #regex working 2018-05-07 to 2018-?
        streams = re.compile('k\: \'(.+?)\'[\w\W]*dash\:"(.+?)"', re.DOTALL).findall(req)
	if streams:
		final_stream_url = None
		for key,stream in streams:
                        final_stream_url = stream
                        encryptionkey = key
                        #if kodiutils.get_setting_as_bool("debug"):
                                #kodiutils.ok("Debug:" + "final_stream_url", final_stream_url)
			if ".mpd" in stream.split('/')[-1]: 
                                if  final_stream_url.endswith('?DVR'):
                                        final_stream_url = final_stream_url[:-4]
				break
			else:
                                final_stream_url = None #not MPD
        #final_stream_url = None #debugging
        if final_stream_url:
                #if kodiutils.get_setting_as_bool("debug"):
                        #notify('Progress....',final_stream_url, 5000)                
                
                is_helper = inputstreamhelper.Helper(PROTOCOL)
                
                if is_helper.check_inputstream():
                        #https://github.com/peak3d/inputstream.adaptive/wiki/Playing-multi-bitrate-stream-from-a-python-addon
                        liz = ListItem(path=final_stream_url)
                        liz.setArt({"thumb": icon, "icon": icon})
                        # worked before 2018-05-04
                        liz.setProperty('inputstreamaddon', is_helper.inputstream_addon)
                        liz.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                        #setResolvedUrl(plugin.handle, True, liz)
                        #exit(0)
                        # worked 2018-05-04 to 2018-05-04
                        liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
                        liz.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                        liz.setProperty('inputstream.adaptive.license_type', DRM)
                        LICENSE_URL = ''
                        LICENSE_URL = 'https://widevine-proxy.drm.technology/proxy'
                        SPECIAL_HEADERS = '|' #none required
                        POST_DATA = '|' #none required
                        POST_RESPONSE = '|' #none required

                        # worked 2018-05-?? to 2018-??
                        #SPECIAL_HEADERS = '|Content-Type=application/json'
                        # 2018-05-07 waiting for new version of library that can allow pipe symbol
                        #my_json_string = json.dumps({'token': encryptionkey, "drm_info":[8,4], 'kid':"E13506F7-439B-EAE7-DDF0-489FCDDF7481"})
                        #POST_DATA = '|%' + urllib.urlencode({'token': encryptionkey, "drm_info":[8,4], 'kid':"E13506F7-439B-EAE7-DDF0-489FCDDF7481"})
                        drmresponse = LICENSE_URL + SPECIAL_HEADERS + POST_DATA + POST_RESPONSE
                        #xbmc.log(drmresponse,xbmc.LOGNONE)
                        liz.setMimeType('application/json')
                        #liz.setProperty('inputstream.adaptive.license_key', LICENSE_URL + '||||')
                        liz.setProperty('inputstream.adaptive.license_key', drmresponse)
                        #setResolvedUrl(plugin.handle, True, liz)
                        #exit(0)



        if kodiutils.get_setting_as_bool("debug"):
                notify('RTPPlay2','Couldn\'t find a DASH link. Using old method', 2000)
        #try old method below 
        streams = re.compile('<script>[\w\W]*?}\);[\w\W]*?file\:.+?"(.+?)"', re.DOTALL).findall(req)
        #streams = re.compile('file\:.+?"(.+?)"', re.DOTALL).findall(req)
        
	#print(req.encode('utf-8'))
	if streams:
		final_stream_url = None
		for stream in streams:
			if ".m3u8" in stream.split('/')[-1]: 
				final_stream_url = stream
			
	if is_pseudo_aes:
		try:
			req = __session__.post("http://www.rtp.pt/services/playRequest.php", headers={"RTPPlayUrl":	final_stream_url})
			final_stream_url = req.headers["RTPPlayWW"]
		except:
			kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
			exit(0)		

	if final_stream_url:
		liz = ListItem("[B][COLOR blue]{}[/B][/COLOR] ({})".format(kodiutils.smart_str(channel), kodiutils.smart_str(prog)))
		liz.setArt({"thumb": icon, "icon": icon})
		liz.setProperty('IsPlayable', 'true')
		liz.setPath("{}|Referer=http://www.rtp.pt/play/&Range".format(final_stream_url))
                if kodiutils.get_setting_as_bool("debug"):
                        kodiutils.ok('RTPPlay2','about to run ' + final_stream_url)
                setResolvedUrl(plugin.handle, True, liz)        
		exit(0)
	else:
		kodiutils.ok(kodiutils.get_string(32000),kodiutils.get_string(32002))
		exit(0)

        

def notify(header=None, msg='', duration=5000):
    if header is None: header = 'RTP Play 2'
    builtin = "XBMC.Notification(%s,%s, %s)" % (header, msg, duration)
    xbmc.executebuiltin(builtin)


def run():
    plugin.run()
