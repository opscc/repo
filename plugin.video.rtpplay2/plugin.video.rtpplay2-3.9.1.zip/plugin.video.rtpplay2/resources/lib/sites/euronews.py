# -*- coding: utf-8 -*-

#import base libraries
import json
import os
import re
import traceback
import urllib
import xbmc
#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

#__________________________________________________________________________
#
def add_icons(plugin,play, subchannel='', subchannel_label='', sort_order=None):
##    Log(repr((subchannel,subchannel_label,sort_order)))
    
    channel = "PT Euronews"
    prog = "PT Euronews"

    if not sort_order: sort_order = 71.0
    else: sort_order = float(sort_order)


    playlink_name = "[COLOR {}][B]{}[/B][/COLOR]".format(
        C.channel_text_color
         , kodiutils.smart_str(channel)
        )

    utils.addPlaylink(
        plugin = plugin
        ,playlink_name = playlink_name
        ,final_url = C.DO_NOTHING_URL
        ,program_name = prog
        ,channel = channel
        ,icon=os.path.join(C.imgDir, 'euronews.jpg')
        ,play=play
        ,module_name=__name__.split('.')[-1]
        ,rating=sort_order#sorting_base+sorting_delta #lower value is on top in sort ascending
        ,return_json_info = True
        ,is_folder = False
        ,filter_category = ''
##        ,db_connection = db_connection
        )
    
#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile):
    ##Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(prog,playmode_string,play_profile,rel_url,channel,icon))

    #return

    #find out what the current ID is for youtube-hosted content
    #page_content = utils.getHtml("https://pt.euronews.com/api/geoblocking_live.json?countrycode=PT&locale=pt") #2022-03-13
    page_content = utils.getHtml("https://pt.euronews.com/api/live/data?locale=pt") #2023-03-14
    json_content = json.loads(page_content)

    youtube_embed_url = "https://www.youtube.com/embed/" + json_content["videoId"]
    full_html = utils.getHtml(youtube_embed_url)
    regex = (
        'ytcfg\.set\((.+?)\);window.ytcfg.obfuscatedData_'
        ) #2021-11
    json_html = re.compile(regex).findall(full_html)
    if json_html: json_html = json_html[0]
    else: json_html = "{}"
    ##Log(repr(json_html))

##    #google does some non-jason standard replacements... aka GSON
##    json_html = json_html.replace("\\u003d","=").replace("\\u003c","<").replace("\\u003e",">").replace("\\u0026","&")
    #Log(repr(json_html))
    
    json_content = json.loads(json_html)

    youtube_embed_url = "https://www.youtube.com/youtubei/v1/player?key=" + json_content["INNERTUBE_API_KEY"]

    post_json = (
        '{"videoId":"'+json_content["VIDEO_ID"]+'"'
        ',"playbackContext":{},"captionParams":{}'
        ',"context":{'
        '         "client":'
        '                  {"clientName":"' + json_content["INNERTUBE_CLIENT_NAME"] +  '"'
        '                  ,"clientVersion":"'+json_content["INNERTUBE_CLIENT_VERSION"]+ '"}'
        '         ,"user":{}'
        '         ,"adSignalsInfo":{"params":[] }'
        ' } } '
    )
    json_html = utils.postHtml(youtube_embed_url, sent_data=post_json)

    json_content = json.loads(json_html)

    m3u8_url = json_content['streamingData']['hlsManifestUrl']
    #Log("m3u8_url='{}'".format(m3u8_url))

#Log("prog='{}'".format(prog.encode('utf8')))
    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog)
    url = m3u8_url + utils.Header2pipestring() 

    if not playmode_string:
        playmode_string = C.DEFAULT_PLAYMODE

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_02

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        )

    return True
#__________________________________________________________________________
#
