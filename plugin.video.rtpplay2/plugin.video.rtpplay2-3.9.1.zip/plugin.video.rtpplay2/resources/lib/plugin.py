# -*- coding: utf-8 -*-
import datetime
import os
import json
import routing
import sqlite3
import sys
import timeit
import threading
import traceback
import utils
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import constants as C
from utils import Log as log
from utils import Log

from resources.lib.sites import *

routing_plugin = routing.Plugin()

###with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
##xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_INPUTSTREAM)
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________________
#
@routing_plugin.route('/'+C.MANAGE_DOWNLOADS)
def Manage_Downloads():
    Log(repr(("Manage_Downloads", sys.argv, routing_plugin.args, C.addon_handle))
        ,C.LOGNONE
        )
    C.addon_handle = int(sys.argv[1])
    import downloader
    downloader.Manage_Downloads()
#__________________________________________________________________________
#
@routing_plugin.route('/'+C.STOP_DOWNLOAD)
def Stop_Download():
    Log(repr(("Stop_Download", sys.argv, routing_plugin.args))
        ,C.LOGNONE
        )
    if routing_plugin.args.get("rel_url"): rel_url = routing_plugin.args["rel_url"][0]
    else: rel_url=''
    if routing_plugin.args.get("name"): name = routing_plugin.args["name"][0]
    else: name=''
        
    import downloader
    #Stop_Download(url,name,refresh_container=True,rowid=None,desc=None,hq_stream=None):
    downloader.Stop_Download(rel_url,name)

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.LIST_DOWNLOADS)
def List_Downloads():
    Log(repr(("List_Downloads", sys.argv, routing_plugin.args))
        ,C.LOGNONE
        )
    if routing_plugin.args.get("folder"): folder = routing_plugin.args["folder"][0]
    else: folder=''
    xbmc.executebuiltin("ActivateWindow(Videos, {})".format(folder))

#__________________________________________________________________
#
@routing_plugin.route('/'+C.REFRESH_CONTAINER_MODE)
def RefreshContainter():

    if utils.get_setting("use_memcache", bool):
        try:
            utils.global_mem_cache_lock.acquire()
            Log('manually expiring info due to refresh click')
            utils.global_mem_cache.set(
                 endpoint = (utils.CACHE_STRING+'_size')
                ,data = 0
                )
        except:
            traceback.print_exc()
        finally:
            utils.global_mem_cache_lock.release()
            
    if utils.get_setting("use_dbcache", bool):
        try:        
            utils.Clear_Table(interval_minutes=0,db_connection=sqlite3.connect(C.linksdb,check_same_thread = False))
        except:
            traceback.print_exc()

    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________________
#
def get_sites(function_name, plugin_filter=''):
    import importlib
    sites = ['fatima','sportsdaddy','euronews','rtp','tvi','cmtv','iptvorg'] 
    for plugin in sites:
        if plugin_filter and plugin_filter.lower() != plugin:
            continue
        module = importlib.import_module('resources.lib.sites.'+plugin)
        if hasattr(module, function_name):
            module = getattr(module, function_name)
            yield (plugin, module)
    return 
#__________________________________________________________________________
#
@routing_plugin.route('/')
def index(create_icons=True):

    progress_dialog = None
    if create_icons:
        pass
    ##    progress_dialog = utils.Progress_Dialog(C.addon_name,"indexing {}".format('...'))
    t_start = datetime.datetime.now()


    with threading.Lock():

        # I want a particular default order for the items
        # I can't guarantee the order with listitems being added inside the threads,
        #   and so I store the data in a cache [using memory for now],
        #   and add the items when done
        if utils.get_setting("use_memcache", bool):
            Log('use_memcache')
            try:
                utils.global_mem_cache_lock.acquire()
                size = utils.global_mem_cache.get(
                         endpoint = (utils.CACHE_STRING+"_size")
                         )
                if size: size = int(size)
                else: size = None
                if not size:
                    Log('info has expired')
                    utils.global_mem_cache.set(
                         endpoint = (utils.CACHE_STRING+'_size')
                        ,data = 0
                         )
                else:
                    Log('cached info size ' + repr(size))
            finally:
                utils.global_mem_cache_lock.release()

        if utils.get_setting("use_dbcache", bool):
            Log('use_dbcache')
            db_connection=sqlite3.connect(C.linksdb) #,check_same_thread = False) 
            utils.Clear_Table( (utils.get_setting("service_periodic_interval", int)/60) +1, db_connection)
            size = db_connection.execute("select count(*) from links").fetchone()
            size = int(size[0])


    ##    net = datetime.datetime.now()-t_start
    ##    Log("ops = {:.0f}ms".format(net.microseconds/1000 + net.total_seconds()*1000) )



        worker_threads = []

        if not size:
            try:
                cycle_sleep = 1 #milliseconds

                for plugin_name, module in get_sites(function_name='add_icons',plugin_filter=''):
                    if utils.get_setting('list_'+ plugin_name):
                        for subchannel in utils.get_setting('list_'+ plugin_name + '_subchannels', list)  :
    ##                        Log(repr((plugin_name,subchannel_filter)))
                            sort_order=None
                            if ';' in subchannel:
                                subchannel = subchannel.split(';')
                                subchannel_filter=subchannel[0]
                                subchannel_label=subchannel[1]
                                if len(subchannel) == 3:  sort_order=subchannel[2]
                            else:
                                subchannel_filter=subchannel
                                subchannel_label=subchannel
                            worker = threading.Thread(name=plugin_name
                                                      ,target=module
                                                      ,args=(routing_plugin
                                                             ,play
                                                             ,subchannel_filter
                                                             ,subchannel_label
                                                             ,sort_order
                                                            )
                                          )
                            worker.daemon = True
                            worker_threads.append(worker)

                            #sleep between thread start to ENCOURAGE the link ordering to come out close to the order described in list
                            utils.Sleep(cycle_sleep) #milliseconds

                            worker.start()

                max_cycles = 100 #multiply by cycle_sleep/1000 for seconds_to_wait_for_search
                cycle_sleep = 200 #milliseconds
                cur_time = 0
                still_working = True
                while still_working and (cur_time < max_cycles) :
                    if progress_dialog and progress_dialog.iscanceled(): break
                    if progress_dialog: progress_dialog.increment_percent()
                    cur_time += 1
                    utils.Sleep(cycle_sleep) #milliseconds
                    still_working = False
    ##                Log(repr(len(worker_threads)))
                    for worker in worker_threads:
                        if worker.is_alive():
    ##                        Log(worker.name)
                            still_working = True
                            break #keep waiting for active task
                if (cur_time >= max_cycles):
                    Log('lookup threads timeout {}'.format(cur_time))
            except:
                traceback.print_exc()

    ##    net = datetime.datetime.now()-t_start
    ##    Log("ops = {:.0f}ms".format(net.microseconds/1000 + net.total_seconds()*1000) )
        

        #threads done by now; use the info to add listitems in our preferred order
        json_items = {}
        if utils.get_setting("use_memcache", bool):
            try:
                utils.global_mem_cache_lock.acquire()
                size = utils.global_mem_cache.get(
                    endpoint = (utils.CACHE_STRING+'_size')
                    )
                if size: size = int(size)
                else: size = -1
                for i in range(1,size+1,1): #add all to a list
                    json_item = utils.global_mem_cache.get(
                             endpoint = (utils.CACHE_STRING+"_icons+"+str(i))
                             )

                    #check if the 'rating' index already exists;
                    while json_items.get(json_item['rating']):
                        #Log(repr(json_item['rating']))
                        #if is already exists, change the index value so that don't overwrite
                        json_item['rating'] = json_item['rating']+0.1

                    json_items[json_item['rating']] = json_item
            except:
                traceback.print_exc()
            finally:
                utils.global_mem_cache_lock.release()
        if utils.get_setting("use_dbcache", bool):
            try:
                db_connection = sqlite3.connect(C.linksdb)
                for info in db_connection.execute("select json_info from links"):
                    json_item = json.loads(info[0])

                    #check if the 'rating' index already exists;
                    while json_items.get(json_item['rating']):
                        #Log(repr(json_item['rating']))
                        #if is already exists, change the index value so that don't overwrite
                        json_item['rating'] = json_item['rating']+0.1
                    
                    json_items[json_item['rating']] = json_item
            except:
                traceback.print_exc()
                    

        Log("total items to list is " + repr(len(json_items.keys())))                

        if not create_icons:
            #if we are only backgrould refreshing, we can stop
            return
        
        #sort all of them and add listitems the sorted order
        for k in sorted(json_items.keys()):
            json_item = json_items[k]
            utils.addPlaylink(
                routing_plugin
                ,playlink_name = json_item['name']
                ,final_url = json_item['final_url']
                ,program_name = json_item['program_name']
                ,channel = json_item['channel']
                ,icon = json_item['icon']
                ,play = play #json_item['play']
                ,module_name = json_item['module_name']
                ,rating = json_item['rating']
                ,filter_category = json_item['filter_category']
                ,is_folder = json_item['is_folder']
                ,return_json_info = False
    ##            ,db_connection = None
                )


    ##    net = datetime.datetime.now()-t_start
    ##    Log("ops = {:.0f}ms".format(net.microseconds/1000 + net.total_seconds()*1000) )


        try:
            list_item = xbmcgui.ListItem(
                label='[B][COLOR {}]Downloads[/COLOR][/B]'.format(C.time_text_color)
                ,iconImage=os.path.join(C.imgDir, 'library_update_5.png')
                ,thumbnailImage=os.path.join(C.imgDir, 'library_update_5.png')
                )
            
            list_item.setInfo(type="video", infoLabels={
                "sorttitle": "a{:0>10}".format(int(C.MANAGE_DOWNLOADS))
                } )
            Log(repr(routing_plugin.url_for(Manage_Downloads)),C.LOGNONE)
            xbmcplugin.addDirectoryItem(
                handle=routing_plugin.handle
                , url=routing_plugin.url_for(
                    Manage_Downloads
                )
                , listitem=list_item
                , isFolder=True
            )
        except:
            traceback.print_exc()


        try:
            list_item = xbmcgui.ListItem(
                label='[B][COLOR {}]Refresh[/COLOR][/B]'.format(C.highlight_text_color)
                ,iconImage=os.path.join(C.imgDir, 'library_update_5.png')
                ,thumbnailImage=os.path.join(C.imgDir, 'library_update_5.png')
                )
            
            list_item.setInfo(type="video", infoLabels={
                "sorttitle": "a{:0>10}".format(int(C.CONFIGURE_REFRESH))
                } )
            xbmcplugin.addDirectoryItem(
                handle=routing_plugin.handle
                , url=routing_plugin.url_for(
                    RefreshContainter
                )
                , listitem=list_item
                , isFolder=False
            )
        except:
            traceback.print_exc()


        try:
            list_item = xbmcgui.ListItem(
                label='[B][COLOR {}]Settings[/COLOR][/B]'.format(C.highlight_text_color)
                ,iconImage=os.path.join(C.imgDir, 'tools.png')
                ,thumbnailImage=os.path.join(C.imgDir, 'tools.png')
                )
            list_item.setInfo(type="video", infoLabels={
                "sorttitle": "a{:0>10}".format(int(C.CONFIGURE_INPUTSTREAM))
                } )
            xbmcplugin.addDirectoryItem(
                handle=routing_plugin.handle
                , url=routing_plugin.url_for(
                    configure_THIS_addon
                )
                , listitem=list_item
                , isFolder=False
            )
        except:
            traceback.print_exc()
            utils.Notify(msg="Error adding Configuration icon", duration=2000)

        utils.endOfDirectory(updateListing=True)

    net = (datetime.datetime.now()-t_start).total_seconds()
    Log("milliseconds for all ops={:.0f}ms".format(net*1000) )

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_THIS_ADDON)
def configure_THIS_addon():
    xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    xbmcaddon.Addon(id=C.addon_id).openSettings()
    return True
#__________________________________________________________________________
#
@routing_plugin.route('/play')
def play():
    Log(repr((sys.argv, routing_plugin.args))
        ,C.LOGNONE
        )
        
    try:

        #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )

        if "filter_category" in routing_plugin.args and routing_plugin.args["filter_category"][0]:
            sportsrows()
            return True
        
        if routing_plugin.args.get("rel_url"): rel_url = routing_plugin.args["rel_url"][0]
        else: rel_url=''
        if '\\x' in rel_url:      rel_url = rel_url.decode('unicode-escape').encode('utf8')
        
        if routing_plugin.args.get("channel"): channel = routing_plugin.args["channel"][0]
        else: channel=''
        if '\\x' in channel:      channel = channel.decode('unicode-escape').encode('utf8')
        
        if routing_plugin.args.get("prog"): prog = routing_plugin.args["prog"][0]
        else: prog=''
        if '\\x' in prog:         prog = prog.decode('unicode-escape').encode('utf8')
        
        if "img" in routing_plugin.args:                  icon = routing_plugin.args["img"][0]
        else:         icon = None

        if "module_name" in routing_plugin.args:          module_name = routing_plugin.args["module_name"][0]
        else:         module_name = channel

        if "playmode_string" in routing_plugin.args:      playmode_string = routing_plugin.args["playmode_string"][0]
        else:          playmode_string = None

        if "play_profile" in routing_plugin.args:         play_profile = routing_plugin.args["play_profile"][0]
        else:         play_profile = None

        if "download" in routing_plugin.args:         download = routing_plugin.args["download"][0]
        else:         download = None

        if prog:
            for plugin_name, module in get_sites(function_name='play',plugin_filter=module_name):
                Log(repr(module_name))
                if not download:
                    module(prog,rel_url,channel,icon,playmode_string,play_profile)
                else:
                    module(prog,rel_url,channel,icon,playmode_string,play_profile,download)
        else: #we should not get here
            Log("no program, probably .. pressed after a subfolder was opened using skinhelper")
            #will generate an error log if we get here without playing
    
    except:
        traceback.print_exc()
        Log(repr((sys.argv, routing_plugin.args)),C.LOGNONE)

#__________________________________________________________________________
#
        
@routing_plugin.route('/sportsrows')
def sportsrows():
    try:
        filter_category = routing_plugin.args["filter_category"][0]
        from resources.lib.sites import sportsdaddy
        sportsdaddy.Add_Icons_Rows(routing_plugin, play, filter_category)
        utils.endOfDirectory()
    except:
        traceback.print_exc()
#__________________________________________________________________________
#
