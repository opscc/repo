# -*- coding: utf-8 -*-
import BaseHTTPServer
import urlparse
import base64
import traceback
import xbmc
import xbmcaddon
import json
from Widevine import Widevine
wv = Widevine()
import utils
from utils import Log
#__________________________________________________________________________
#
class WidevineHTTPRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200)
    def log_message(self, format, *args):
        return #"""Disables the BaseHTTPServer log."""
    def do_POST(self):
        length = int(self.headers['content-length'])
        wv_challenge = self.rfile.read(length)
        Log("wv_challenge={}".format(repr(wv_challenge)))
        
        query = dict(urlparse.parse_qsl(urlparse.urlsplit(self.path).query, keep_blank_values=True))
        mpd_url = base64.b64decode(query['mpd_url'])
        token = base64.b64decode(query['token'])
        mpdheaders = None
        if query['headers']:
            mpdheaders = base64.b64decode(query['headers'])
            mpdheaders = json.loads(mpdheaders)

        try:
            Log("mpd_url={}".format(repr(mpd_url)))
            Log("token={}".format(repr(token)))
            Log("mpdheaders={}".format(repr(mpdheaders)))
            
            wv_license = wv.get_license(mpd_url, wv_challenge, token, mpdheaders)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(wv_license)
            self.finish()
        except:
            traceback.print_exc()
            self.send_response(400)
            self.wfile.write(ex.message)
#__________________________________________________________________________
#

