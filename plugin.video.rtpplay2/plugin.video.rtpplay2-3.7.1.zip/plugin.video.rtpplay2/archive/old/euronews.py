# -*- coding: utf-8 -*-
import constants as C
import json
import re
import urllib
import utils
import traceback
import xbmc

from utils import Log
from utils import Log as log
from utils import Notify as notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

#__________________________________________________________________________
#
def addEuronewsIcon(plugin,play):
    channel = "PT Euronews"
    prog = "PT Euronews"

    playlink_name = "[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
        C.channel_text_color
         , kodiutils.smart_str(channel)
         , C.program_text_color
         , kodiutils.smart_str(prog)
        )

    utils.addPlaylink(
        plugin = plugin
        ,playlink_name = playlink_name
        ,final_url = C.EURONEWS_BASE
        ,program_name = prog
        ,channel = channel
        ,icon="https://static.euronews.com/website/images/live.jpg"
        ,play=play
        )
    

##    liz = ListItem("[B][COLOR {}]{}[/B][/COLOR] [COLOR {}]({})[/COLOR]".format(
##        C.channel_text_color
##         , kodiutils.smart_str(channel)
##         , C.program_text_color
##         , kodiutils.smart_str(prog)
##        )
##    )
##    img = "https://static.euronews.com/website/images/live.jpg"
##    img = img + "|User-Agent=Mozilla/5.0 (MSIE 10.0; Windows NT 6.1; Trident/5.0)"
##    liz.setArt({"thumb": img, "icon": img, "fanart": kodiutils.FANART})
##    finalurl=C.EURONEWS_BASE
##    addDirectoryItem(plugin.handle
##                     , plugin.url_for(
##                         play
##                           , rel_url=kodiutils.smart_str(finalurl)
##                           , channel=kodiutils.smart_str(channel)
##                           , img=kodiutils.smart_str(img)
##                           , prog=kodiutils.smart_str(prog)
##                         )
##                     , liz
##                     , False)

#__________________________________________________________________________
#
def play_euronews(prog,rel_url,channel,icon,playmode_string,play_profile):

    ##Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(prog,playmode_string,play_profile,rel_url,channel,icon))

    #return

    #find out what the current ID is for youtube-hosted content
    #page_content = utils.getHtml("https://pt.euronews.com/api/geoblocking_live.json?countrycode=PT&locale=pt") #2022-03-13
    page_content = utils.getHtml("https://pt.euronews.com/api/live/data?locale=pt") #2023-03-14
    json_content = json.loads(page_content)

    youtube_embed_url = "https://www.youtube.com/embed/" + json_content["videoId"]
    full_html = utils.getHtml(youtube_embed_url)
    regex = (
        'ytcfg\.set\((.+?)\);window.ytcfg.obfuscatedData_'
        ) #2021-11
    json_html = re.compile(regex).findall(full_html)
    if json_html: json_html = json_html[0]
    else: json_html = "{}"
    ##Log(repr(json_html))

##    #google does some non-jason standard replacements... aka GSON
##    json_html = json_html.replace("\\u003d","=").replace("\\u003c","<").replace("\\u003e",">").replace("\\u0026","&")
    #Log(repr(json_html))
    
    json_content = json.loads(json_html)

    youtube_embed_url = "https://www.youtube.com/youtubei/v1/player?key=" + json_content["INNERTUBE_API_KEY"]

    post_json = (
        '{"videoId":"'+json_content["VIDEO_ID"]+'"'
        ',"playbackContext":{},"captionParams":{}'
        ',"context":{'
        '         "client":'
        '                  {"clientName":"' + json_content["INNERTUBE_CLIENT_NAME"] +  '"'
        '                  ,"clientVersion":"'+json_content["INNERTUBE_CLIENT_VERSION"]+ '"}'
        '         ,"user":{}'
        '         ,"adSignalsInfo":{"params":[] }'
        ' } } '
    )
    json_html = utils.postHtml(youtube_embed_url, sent_data=post_json)

    json_content = json.loads(json_html)

    m3u8_url = json_content['streamingData']['hlsManifestUrl']
    #Log("m3u8_url='{}'".format(m3u8_url))

#Log("prog='{}'".format(prog.encode('utf8')))
    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog)
    url = m3u8_url + utils.Header2pipestring() 

    if not playmode_string:
        playmode_string = C.DEFAULT_PLAYMODE

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_02

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        )


#__________________________________________________________________________
#
