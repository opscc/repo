# -*- coding: utf-8 -*-
import os
import json
import routing
import sqlite3
import sys
import timeit
import threading
import traceback
import utils
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import constants as C
from utils import Log as log
from utils import Log

from resources.lib.sites import *

routing_plugin = routing.Plugin()

###with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
##xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_INPUTSTREAM)
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________
#
@routing_plugin.route('/'+C.REFRESH_CONTAINER_MODE)
def RefreshContainter():

    if utils.get_setting("use_memcache", bool):
        try:
            utils.global_mem_cache_lock.acquire()
            Log('manually expiring info due to refresh click')
            utils.global_mem_cache.set(
                 endpoint = (utils.CACHE_STRING+'_size')
                ,data = 0
                )

        except:
            traceback.print_exc()
        finally:
            utils.global_mem_cache_lock.release()
    if utils.get_setting("use_dbcache", bool):
        try:        
            utils.Clear_Table(interval_minutes=0,db_connection=sqlite3.connect(C.linksdb,check_same_thread = False))
        except:
            traceback.print_exc()

    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________________
#
def get_sites(function_name, plugin_filter=''):
    import importlib
    sites = ['fatima','sportsdaddy','euronews','rtp','tvi','cmtv'] 
    for plugin in sites:
        if plugin_filter and plugin_filter.lower() != plugin:
            continue
        module = importlib.import_module('resources.lib.sites.'+plugin)
        if hasattr(module, function_name):
            module = getattr(module, function_name)
            yield (plugin, module)
    return 
#__________________________________________________________________________
#
@routing_plugin.route('/')
def index(create_icons=True):

    progress_dialog = None
##    progress_dialog = utils.Progress_Dialog(C.addon_name,"indexing {}".format('...'))

    # I want a particular default order for the items
    # I can't guarantee the order with listitems being added inside the threads,
    #   and so I store the data in a cache [using memory for now],
    #   and add the items when done
    if utils.get_setting("use_memcache", bool):
        try:
            utils.global_mem_cache_lock.acquire()
            size = utils.global_mem_cache.get(
                     endpoint = (utils.CACHE_STRING+"_size")
                     )
            if size: size = int(size)
            else: size = None
            if not size:
                Log('info has expired')
                utils.global_mem_cache.set(
                     endpoint = (utils.CACHE_STRING+'_size')
                    ,data = 0
                     )
            else:
                Log('cached info size ' + repr(size))
        finally:
            utils.global_mem_cache_lock.release()

    if utils.get_setting("use_dbcache", bool):
        db_connection=sqlite3.connect(C.linksdb,check_same_thread = False) 
        utils.Clear_Table(utils.get_setting("service_periodic_interval", int)/60, db_connection)
        size = db_connection.execute("select count(*) from links").fetchone()
##        Log(repr(size[0]))
        size = int(size[0])

    worker_threads = []

    if not size:
        try:
            for plugin_name, module in get_sites(function_name='add_icons',plugin_filter=''):
                if utils.get_setting('list_'+ plugin_name):
                    worker = threading.Thread(name=plugin_name
                                              ,target=module
                                              ,args=(routing_plugin
                                                     ,play
                                                    )
                                      )
                    worker.daemon = True
                    worker_threads.append(worker)
                    worker.start()

            max_cycles = 100 #multiply by cycle_sleep/1000 for seconds_to_wait_for_search
            cycle_sleep = 200 #milliseconds
            cur_time = 0
            still_working = True
            while still_working and (cur_time < max_cycles) :
                if progress_dialog and progress_dialog.iscanceled(): break
                if progress_dialog: progress_dialog.increment_percent()
                cur_time += 1
                utils.Sleep(cycle_sleep) #milliseconds
                still_working = False
                for worker in worker_threads:
                    if worker.is_alive():
##                        Log(worker.name)
                        still_working = True
                        break #keep waiting for active task
            if (cur_time >= max_cycles):
                Log('lookup threads timeout {}'.format(cur_time))
        except:
            traceback.print_exc()

    #I can't get this to work how I wan't with multithreaded modules;  maybe create a unique _module_ for this
    if not size:
        if utils.get_setting('list_sportsdaddy'):
            
            channel = 722
            utils.addPlaylink(
                routing_plugin
                ,playlink_name = '[B][COLOR {}]SIC[/COLOR][/B]'.format(
                        C.channel_text_color
                    )
    ##            ,final_url = 'plugin://plugin.video.rtpplay2/play?&channel=sportsdaddy&prog=SIC&img=%2F&rel_url='+str(channel)
                ,final_url = str(channel)
                ,program_name = 'SIC'
                ,channel='SIC'
                ,icon= os.path.join(C.imgDir, 'sic.png')
                ,play=play
                ,module_name='sportsdaddy'
                ,rating=36
                ,return_json_info = True
                ,is_folder = False
                ,filter_category = ''
##                ,db_connection = sqlite3.connect(C.linksdb)
                )

##            channel = 330
##            utils.addPlaylink(
##                routing_plugin
##                ,playlink_name = '[B][COLOR {}]Channel {}[/COLOR][/B]'.format(
##                        C.channel_text_color
##                        ,channel
##                    )
##                ,final_url = str(channel)
##                ,program_name = 'Channel {}'.format(channel)
##                ,channel='Channel {}'.format(channel)
##                ,icon= ""#os.path.join(C.imgDir, 'sic.png')
##                ,play=play
##                ,module_name='sportsdaddy'
##                ,rating=36
##                ,return_json_info = True
##                ,is_folder = False
##                ,filter_category = ''
##                )

            
            channel = 719
            utils.addPlaylink(
                routing_plugin
                ,playlink_name = '[B][COLOR {}]RTP 1[/COLOR][/B]'.format(
                        C.channel_text_color
                    )
                ,final_url = str(channel)
                ,program_name = 'RTP 1'
                ,channel='RTP 1'
                ,icon= os.path.join(C.imgDir, 'rtp1.png')
                ,play=play
                ,module_name='sportsdaddy'
                ,rating=37
                ,return_json_info = True
                ,is_folder = False
                ,filter_category = ''
##                ,db_connection = sqlite3.connect(C.linksdb)
                )
            utils.addPlaylink(
                routing_plugin
                ,playlink_name = '[B][COLOR {}]Soccer[/COLOR][/B]'.format(
                        C.channel_text_color
                    )
                ,final_url = 'plugin://plugin.video.rtpplay2/sportsrows?&filter_category=Soccer'
                ,program_name = 'Soccer'
                ,channel='sportsdaddy'
                ,icon= os.path.join(C.imgDir, 'soccer.png')
                ,play=play
                ,module_name='sportsdaddy'
                ,rating=38
                ,return_json_info = True
                ,is_folder = True
                ,filter_category = 'Soccer'
##                ,db_connection = sqlite3.connect(C.linksdb)
                )

    if not create_icons: return

    #threads done by now; use the info to add listitems in our preferred order
    
    json_items = {}
    if utils.get_setting("use_memcache", bool):
        try:
            utils.global_mem_cache_lock.acquire()
            size = utils.global_mem_cache.get(
                endpoint = (utils.CACHE_STRING+'_size')
                )
            if size: size = int(size)
            else: size = -1
            for i in range(1,size+1,1): #add all to a list
                json_item = utils.global_mem_cache.get(
                         endpoint = (utils.CACHE_STRING+"_icons+"+str(i))
                         )
                json_items[json_item['rating']] = json_item
        except:
            traceback.print_exc()
        finally:
            utils.global_mem_cache_lock.release()
    if utils.get_setting("use_dbcache", bool):
        try:
            db_connection = sqlite3.connect(C.linksdb)
            for info in db_connection.execute("select json_info from links"):
##                Log(repr(info[0]))
##                Log(repr(dir(info)))
                json_item = json.loads(info[0])
                json_items[json_item['rating']] = json_item
        except:
            traceback.print_exc()
                

    Log("total items to list is " + repr(len(json_items.keys())))                
    #sort all of them and add listitems the sorted order
    for k in sorted(json_items.keys()):
        json_item = json_items[k]
        utils.addPlaylink(
            routing_plugin
            ,playlink_name = json_item['name']
            ,final_url = json_item['final_url']
            ,program_name = json_item['program_name']
            ,channel = json_item['channel']
            ,icon = json_item['icon']
            ,play = play #json_item['play']
            ,module_name = json_item['module_name']
            ,rating = json_item['rating']
            ,filter_category = json_item['filter_category']
            ,is_folder = json_item['is_folder']
            ,return_json_info = False
##            ,db_connection = None
            )




    try:
        list_item = xbmcgui.ListItem(
            label='[B][COLOR {}]Refresh[/COLOR][/B]'.format(C.time_text_color)
            ,iconImage=os.path.join(C.imgDir, 'library_update_5.png')
            ,thumbnailImage=os.path.join(C.imgDir, 'library_update_5.png')
            )
        
        list_item.setInfo(type="video", infoLabels={
            "sorttitle": "a{:0>10}".format(int(9997))
            } )
        xbmcplugin.addDirectoryItem(
            handle=routing_plugin.handle
            , url=routing_plugin.url_for(
                RefreshContainter
            )
            , listitem=list_item
            , isFolder=False
        )
    except:
        traceback.print_exc()


    try:
        list_item = xbmcgui.ListItem(
            label='[B][COLOR {}]Settings[/COLOR][/B]'.format(C.highlight_text_color)
            ,iconImage=os.path.join(C.imgDir, 'tools.png')
            ,thumbnailImage=os.path.join(C.imgDir, 'tools.png')
            )
        list_item.setInfo(type="video", infoLabels={
            "sorttitle": "a{:0>10}".format(int(9999))
            } )
        xbmcplugin.addDirectoryItem(
            handle=routing_plugin.handle
            , url=routing_plugin.url_for(
                configure_THIS_addon
            )
            , listitem=list_item
            , isFolder=False
        )
    except:
        traceback.print_exc()
        utils.Notify(msg="Error adding Configuration icon", duration=2000)

    utils.endOfDirectory(updateListing=True)
    

#__________________________________________________________________________
#
@routing_plugin.route('/'+C.CONFIGURE_THIS_ADDON)
def configure_THIS_addon():
    xbmc.executebuiltin( "Dialog.Close(busydialog)" ) #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    import xbmcaddon
    xbmcaddon.Addon(id=C.addon_id).openSettings()
    return True
#__________________________________________________________________________
#
@routing_plugin.route('/play')
def play():

##    Log(repr(sys.argv))
##    Log(repr(routing_plugin.args))

    rel_url = routing_plugin.args["rel_url"][0]
    channel = routing_plugin.args["channel"][0]
    prog = routing_plugin.args["prog"][0]
    if "img" in routing_plugin.args:                  icon = routing_plugin.args["img"][0]
    else:         icon = None
    if "module_name" in routing_plugin.args:          module_name = routing_plugin.args["module_name"][0]
    else:         module_name = channel
    if "playmode_string" in routing_plugin.args:      playmode_string = routing_plugin.args["playmode_string"][0]
    else:          playmode_string = None
    if "play_profile" in routing_plugin.args:         play_profile = routing_plugin.args["play_profile"][0]
    else:         play_profile = None

    if '\\x' in prog:         prog = prog.decode('unicode-escape').encode('utf8')
    if '\\x' in channel:      channel = channel.decode('unicode-escape').encode('utf8')
    if '\\x' in rel_url:      rel_url = rel_url.decode('unicode-escape').encode('utf8')
    
    #with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )

    if "filter_category" in routing_plugin.args and routing_plugin.args["filter_category"][0]:
##        Log('hwere')
        sportsrows()
        return True
    
##    if channel == C.REFRESH_CONTAINER_MODE and  module_name == 'plugin':
##        Log('h')
##        RefreshContainter()
##        utils.endOfDirectory()
##        return True

    for plugin_name, module in get_sites(function_name='play',plugin_filter=module_name):
        module(prog,rel_url,channel,icon,playmode_string,play_profile)
        return True

    #we should not get here
    Log("error can't find rout to " + repr((channel,prog,module_name)))
    return True

#__________________________________________________________________________
#
        
@routing_plugin.route('/sportsrows')
def sportsrows():
    try:
        filter_category = routing_plugin.args["filter_category"][0]
##        import sportsdaddy
        from resources.lib.sites import sportsdaddy
        sportsdaddy.Add_Icons_Rows(routing_plugin, play, filter_category)
        utils.endOfDirectory()
    except:
        traceback.print_exc()
#__________________________________________________________________________
#
