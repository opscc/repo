# -*- coding: utf-8 -*-
import constants as C
import datetime
import json
import os
import re
import utils
import time
import timeit
import traceback
import xbmc
import xbmcgui
import xbmcplugin

from utils import Log
from utils import Log as log
from utils import Notify as notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils


BASE = "https://d.daddylivehd.sx/"

CATEGORY_REGEX = (
    '<h2 style="background-color:cyan">'
    '(?P<category>.+?)(?:</h2>|<div id="sidebar">)'
    '(?P<category_info>.+?)(?=<h2 |<div id="sidebar">)'
    )

##CHANNEL_INFO_REGEX = (
##    '<hr>(?P<hour>\d\d):(?P<min>\d\d) '
##    '(?P<team>.+?)<span'
##    '.+?(?P<link>href=".+?)'
##    '(?=<hr|<h2|<div id="sidebar">)'
##    )
CHANNEL_INFO_REGEX = (
    '<hr>(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|<hr|<h2|<div id="sidebar">)'
    )

LINK_INFO_REGEX = (
    'href="(?P<link>.+?)"'
    '.+?rel="noopener">(?P<broadcaster>.+?)</a>'
    )

try: cache_duration = int(utils.get_setting('html_cache_sportsdaddy'))
except: cache_duration = 300

STREAM_REGION_01 = '<div class="box">(.+)</span>Backup Streams Of Soccer &amp; Other Events</h1>'

#__________________________________________________________________________
#
def Add_Icons_Category(plugin, play, soccer_only):

    try:
##        Log('01')
        html_src = utils.getHtml(BASE, cache_duration=cache_duration )
##        Log('02')
        
        html_src = re.compile(STREAM_REGION_01, re.DOTALL | re.IGNORECASE).findall(html_src)[0]

##        Log('1')
        channels = re.compile(CATEGORY_REGEX, re.DOTALL | re.IGNORECASE).findall(html_src)
##        Log('2')
        time_range = int(utils.get_setting('time_range_sportsdaddy'))

        today = datetime.datetime.utcnow()
        schedule_time = today.utcnow() + datetime.timedelta(hours=-5) #convert from GMT+1

        
        for category, channel_info in channels:
            channel = ''
            program = ''

##            Log('3')
            channel_data = re.compile(CHANNEL_INFO_REGEX, re.DOTALL | re.IGNORECASE).findall(channel_info)
##            Log('4')
            
            if len(channel_data) > 0: #skip categories with no entries
                category_name = "[B][COLOR {}]{}[/B][/COLOR]{}".format(
                    C.refresh_text_color
                    , category.encode('utf8')
                    , '' #str(datetime.datetime.today())
                    )
                
                list_item = xbmcgui.ListItem(
                    label=category_name
                    )
                list_item.setArt({"thumb":    os.path.join(C.imgDir, category+'.png')  })
##                Log(repr(os.path.join(C.imgDir, category+'.png')))
                
                if soccer_only:
                    if category == 'Soccer':
                        plugin_url = plugin.url_for(
                                play
                                , filter_category=category
                                )
                        xbmcplugin.addDirectoryItem(
                            handle=plugin.handle
                            , url = plugin_url
                            , listitem=list_item
                            , isFolder=True
                        )
                        return
                    else:
                        continue

                plugin_url = plugin.url_for(
                        play
                        , filter_category=category
                        )
                xbmcplugin.addDirectoryItem(
                    handle=plugin.handle
                    , url = plugin_url
                    , listitem=list_item
                    , isFolder=True
                )

##                Log(repr(plugin_url))
##                import random
##                channel = random.randint(1,799)



                
    except:
        traceback.print_exc()


#__________________________________________________________________________
#
def Add_Icons_Rows(plugin, play, filter_category):

    html_src = utils.getHtml(BASE, cache_duration=cache_duration )

##    #for some reason site has duplicates; second seems better; my crappy way of filtering
##    html_src = html_src.split('<h2 style="background-color:cyan">Volleyball</h2>')[1]

    html_src = re.compile(STREAM_REGION_01, re.DOTALL | re.IGNORECASE).findall(html_src)[0]
        
    channels = re.compile(CATEGORY_REGEX, re.DOTALL | re.IGNORECASE).findall(html_src)
        
    time_range = int(utils.get_setting('time_range_sportsdaddy'))

    today = datetime.datetime.utcnow()
##    today = (today - datetime.datetime(1970, 1, 1)).total_seconds()
    
    schedule_time = today.utcnow() + datetime.timedelta(hours=-5) #convert from GMT+1

    for category, channel_info in channels:

        channel_data = re.compile(CHANNEL_INFO_REGEX, re.DOTALL | re.IGNORECASE).findall(channel_info)

        if not (category == filter_category):
##            Log(repr((category,filter_category)))
            continue

        for hour, minute, team, links in channel_data:

##            Log(repr(channel_data))
        
            team = utils.cleantext(team)
            if '\\x' in team:
                team = team.decode('unicode-escape').encode('utf8')

            #adjust hour according to local TZ
            event_time = datetime.datetime(
                schedule_time.year
                ,schedule_time.month
                ,schedule_time.day
                ,hour=int(hour)
                ,minute=int(minute)
                )
            

            event_time_gmt = event_time + datetime.timedelta(hours=-1) #convert from GMT+1
            offset = time.timezone if (time.localtime().tm_isdst == 0) else time.altzone
            tz_offset = offset / 60 / 60 * -1
            event_time_local = event_time_gmt + datetime.timedelta(hours=tz_offset)

##            Log(repr(event_time_gmt))
##            Log(repr(event_time_local))
            epoc_gmt = (event_time_gmt - datetime.datetime(1970, 1, 1)).total_seconds()
            epoc_local = (event_time_local - datetime.datetime(1970, 1, 1)).total_seconds()
            
##            Log(repr(epoc_gmt))
##            Log(repr(epoc_local))
            
            if (time_range < 0):
##                if (((event_time - today).seconds/3600) < time_range) \
##                        or \
##                (((event_time - today  ).seconds/3600) > time_range/2)    :
                Log(repr((epoc_local - epoc_gmt)/3600))
                Log(repr((epoc_gmt - epoc_local)/3600))
                if ((epoc_local - epoc_gmt ) < 0) : # in the future
                    
                    Log(u' keeping  {}:{} {}'.format(hour,minute,team))
                    pass
                else:

                    Log(u'skipping  {}:{} {}'.format(event_time.hour+tz_offset,event_time.minute,team))
                    continue

            link_data = re.compile(LINK_INFO_REGEX, re.DOTALL | re.IGNORECASE).findall(links)

            time_and_teams_name = u"  [COLOR {}]{:02}:{:02}[/COLOR] [COLOR {}]{}[/COLOR]".format(
                 C.time_text_color
                , event_time_local.hour #hour
                , event_time_local.minute #minute
                , C.highlight_text_color
                , team
                )
            
            if len(link_data) > 0:

                list_item = xbmcgui.ListItem(
                    label=time_and_teams_name
                    )
                xbmcplugin.addDirectoryItem(
                    handle=plugin.handle
                    , url=''
                    , listitem=list_item
                    , isFolder=False
                )

                for link, broadcaster in link_data:


                    broadcaster = utils.cleantext(broadcaster)
                    if '\\x' in broadcaster:
                        broadcaster = broadcaster.decode('unicode-escape').encode('utf8')
                    
                    playlink_name = u"      [COLOR {}]{}[/COLOR]".format(
                        C.program_text_color
                        ,broadcaster
                        )
                    utils.addPlaylink(
                        plugin
                        ,playlink_name
                        ,u"{}{}".format(time_and_teams_name,link)
                        ,time_and_teams_name #the program_name
                        ,channel='sportsdaddy'
                        ,icon=C.default_icon
                        ,play=play
                        )

            

#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile):
    Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(
        prog,playmode_string,play_profile,rel_url,channel,icon))

    headers = {
              "Referer":'https://bhqwplay.xyz/premiumtv/'
              ,'Accept': '*/*'
              ,"Accept-Encoding":"gzip,deflate"
              ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188"
              }

##    rel_url = '/stream-'+'722'+'.php'
    
##    if rel_url.startswith('/'): rel_url = rel_url.strip('/')
    rel_url = rel_url.split("/stream-")[1].split('.php')[0]

##    import random
##    rel_url = random.randint(1,899)
                
    m3u8_url = "https://webudit.cdndac.lol/lb/premium{}/index.m3u8".format(rel_url) #pre 2023-09
    m3u8_url = "https://webudit.cdnbos.lol/lb/premium{}/index.m3u8".format(rel_url) #2023-09-04
##    m3u8_url = "https://webudit.cdndac.lol/lb/premium73/index.m3u8"
    Log((m3u8_url))
##    source_html = utils.getHtml(source_url,headers=headers)

##    return
##    m3u8_url = page_content+"?wmsAuthSign="+matrix_userId
#Log("m3u8_url='{}'".format(m3u8_url))

##    name = "[B][COLOR {}]{}[/B][/COLOR] ({})".format(
##        C.channel_text_color
##        , channel
##        , prog)
    name = "Channel {}".format(
         rel_url
         )

    url = m3u8_url + utils.Header2pipestring(headers)

    if not playmode_string:
        playmode_string = C.PLAYMODE_DIRECT

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
    )
#__________________________________________________________________________
#
