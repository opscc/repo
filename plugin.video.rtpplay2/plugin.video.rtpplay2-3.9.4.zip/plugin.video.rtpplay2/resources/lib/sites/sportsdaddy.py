# -*- coding: utf-8 -*-


#import base libraries
import base64
import datetime
import json
import os
import re
import time
import traceback
import urllib
import xbmc
import xbmcgui
import xbmcplugin

#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils




BASE = "https://daddylivehd.sx/"
BASE = "https://daddylive.sx/"
BASE = "https://dlhd.sx/"
BASE = "https://dlhd.so/"

CATEGORY_REGEX = (
    '<h2 style="background-color:cyan">'
    '(?P<category>.+?)(?:</?h2>|<div id="sidebar">)'
    '(?P<category_info>.+?)(?=<h2 |<div id="sidebar">|\\Z)'
    )

CHANNEL_INFO_REGEX = (
    '<hr>(?:<strong>|)(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)(?:</strong>|)\s*<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|<hr|<h2|<div id="sidebar">)'
    )
CHANNEL_INFO_REGEX = (
    '<hr>(?:<strong>|)(?P<hour>\d\d):(?P<min>\d\d) '
    '(?P<team>.+?)(?:</strong>|)\s*<span'
    '.+?(?P<link>href=".+?)'
    '(?=</span><br />|</span></p>|</span>\s|<hr|<h2|<div id="sidebar">)'
    )

LINK_INFO_REGEX = (
    'href="(?P<link>.+?)"'
    '.+?rel="noopener">(?P<broadcaster>.+?)</a>'
    )

try: cache_duration = int(utils.get_setting('html_cache_sportsdaddy'))
except: cache_duration = 300

STREAM_REGION_01 = '<div class="box">(.+)</span>Backup Streams Of Soccer &amp; Other Events</h1>'
STREAM_REGION_01 = '<div class="box">(.+)<div id="sidebar">'


#__________________________________________________________________________
#
def add_icons(routing_plugin, play, subchannel='', subchannel_label='', sort_order=None, soccer_only=False):
##    Log(repr((subchannel,subchannel_label,sort_order)))

    if not sort_order: sort_order = 1000.0
    else: sort_order = float(sort_order)
    
    #if not subchannel: return  #for this set, only allow specific channels
    
    try:
        
        icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon

        if subchannel.isdigit():  #don't worry about categaries when we need to tune to a specific number
            utils.addPlaylink(
                routing_plugin
                ,playlink_name = '[B][COLOR {}]{}[/COLOR][/B]'.format(
                        C.channel_text_color
                        ,subchannel_label
                    )
                ,final_url = subchannel
                ,program_name = subchannel_label
                ,channel= subchannel_label
                ,icon= icon
                ,play=play
                ,module_name='sportsdaddy'
                ,rating=sort_order
                ,return_json_info = True
                ,is_folder = False
                ,filter_category = ''
##                ,db_connection = sqlite3.connect(C.linksdb)
                )
            
            return


        
        with utils.global_mem_cache_lock: #lock permits a cached GET when this section is launched within multiple threads

        ##    return json.loads("[]")  #testing
            json_info = utils.global_cache.get(C.addon_id+BASE)
            json_info = None #testing
            if json_info and (len(json_info) > 0)  :
                Log("using global_cache " + BASE)
            else:
                json_src = utils.getHtml(BASE + 'schedule/schedule-generated.json'  , cache_duration=cache_duration)
    ##            utils.Sleep(20000) ##performance testing
                json_info = json.loads(json_src)
##                utils.global_cache.set(
##                    endpoint = (C.addon_id+BASE)
##                    ,data = json_info
##                    ,expiration = datetime.timedelta(seconds=C.default_GETHTML_cache_duration)
##                    )


        time_range = int(utils.get_setting('time_range_sportsdaddy'))
        today = datetime.datetime.utcnow()
        schedule_time = today.utcnow() + datetime.timedelta(hours=-6) #convert from GMT+1 to EST

        for category in json_info[json_info.keys()[0]]: #first item is a date which we can skip

            if subchannel_label and (category != subchannel):
##                Log(repr( (subchannel_label,category,subchannel)))
                continue

            #skip categories with no entries
            if len(json_info[json_info.keys()[0]][category]) < 1:
                pass
            else:
                #add a sub menu for the category with entries
                category_name = u"[COLOR {}][B]{}[/B][/COLOR]".format(
                    C.refresh_text_color
                    , category 
                    )

                sorting_delta = 0.1
                sort_order += sorting_delta

                plugin_url = routing_plugin.url_for(
                        play
                        , filter_category=category
                        , rel_url = category
                        , channel = category
                        , prog = category
                        , img = ''
                        , module_name = __name__.split('.')[-1]
                        )

                if subchannel_label:
                    icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon
                else:                
                    icon = os.path.join(C.imgDir, ''.join(category.split(' '))+'.png') #strip any spaces in the lable to find icon
                if not os.path.isfile(icon):
                    icon = os.path.join(C.imgDir, 'other.png')
                                        
##                Log(repr(icon))
                    
                utils.addPlaylink(
                    routing_plugin
                    ,playlink_name = category_name
                    ,final_url = plugin_url
                    ,program_name = category
                    ,channel = category
                    ,icon = icon #os.path.join(C.imgDir, category+'.png')
                    ,play = play
                    ,module_name = __name__.split('.')[-1]
                    ,rating = sort_order
                    ,return_json_info = True
                    ,is_folder = True
                    ,filter_category = category
##                    ,db_connection = db_connection
                    )

    except:
        traceback.print_exc()


#__________________________________________________________________________
#
def Add_Icons_Rows(plugin, play, filter_category):
##    Log(repr(filter_category))

    json_urls = [
        BASE + 'schedule/schedule-generated.json'
        ]
    try:
        for json_url in json_urls:

            json_src = utils.getHtml(json_url, cache_duration=cache_duration)
            json_info = json.loads(json_src)

            sorting_delta = 0
            sorting_base = 3
        
            for category in json_info[json_info.keys()[0]]: #first item is a date which we can skip

                if category != filter_category:
                    continue
                
                for event in json_info[json_info.keys()[0]][category]:

                    try:
                        t_time = '12 12 2023 ' + event['time']
                    except:
                        t_time = '00:00'
                    try:
                        gmt_time = datetime.datetime.strptime( json_info.keys()[0].split(' - Schedule Time')[0] + event['time'], '%A %dth %B %Y%H:%M')
                    except:
                        try: 
                            gmt_time = datetime.datetime.strptime(t_time, '%d %m %Y %H:%M')
                        except TypeError:
                            gmt_time = datetime.datetime(*(time.strptime(t_time, '%d %m %Y %H:%M')[0:6]))
                        
                    schedule_time = gmt_time + datetime.timedelta(hours=-5) #convert from GMT+1
    
                    time_and_teams_name = u"  [COLOR {}]{}[/COLOR] [COLOR {}]{}[/COLOR]".format(
                         C.time_text_color
                        , schedule_time.strftime('%H:%M') #event['time']
                        , C.highlight_text_color
                        , event['event']
                        )

                    sorting_delta = sorting_delta + 1

                    list_item = xbmcgui.ListItem(
                        label=time_and_teams_name
                        )
                    rating = sorting_base+sorting_delta
                    list_item.setArt({"thumb":    os.path.join(C.imgDir, category+'.png')  })
                    list_item.setInfo(type="video"
                                      , infoLabels={
                                            "sorttitle": "a{:0>10}".format(int(rating))
                                            ,"playcount":"0" #remove the filled in circle from our skin
                                                   }
                                      )
                    xbmcplugin.addDirectoryItem(
                        handle=plugin.handle
                        , url=''
                        , listitem=list_item
                        , isFolder=True
                    )

##                    Log(repr(event))
                    for link in event[u'channels']:

                        channel_name = channel_id = None

                        #sometimes data is a list, other times a numbered array
                        if type(link) is dict:
                            if not (u'channel_id' in link):
                                continue #sometimes there is a blank entry
                            channel_name = link[u'channel_name']
                            channel_id = link[u'channel_id']
                        else:
                            #note: the json parser in py2 may reorder the array differently
                            #  ie.  source data is (0, 1, ... 11, 12) but parsed as (11, 12 ... 1, 0, 2)
                            link3 = event[u'channels'][link]
                            if not (u'channel_id' in link3):
                                continue #sometimes there is a blank entry
                            channel_name = link3[u'channel_name']
                            channel_id = link3[u'channel_id']
                                                        
                        if channel_name and channel_id:
                            playlink_name = u"      [COLOR {}]{}[/COLOR]".format(
                                C.program_text_color
                                ,channel_name + ' channel ' + channel_id
                                )
                            utils.addPlaylink(
                                plugin
                                ,playlink_name
                                ,channel_id
                                ,time_and_teams_name #the program_name
                                ,channel='sportsdaddy'
                                ,icon= os.path.join(C.imgDir, category+'.png')
                                ,play=play
                                ,module_name=__name__.split('.')[-1]
                                ,rating=str(sorting_base+sorting_delta) #lower value is on top in sort ascending
                                ,return_json_info = False
                                ,is_folder = False
                                ,filter_category = ''
                                )
    
    except:
        traceback.print_exc()

#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile,download=None):
    Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}', download='{}'".format(
        prog,playmode_string,play_profile,rel_url,channel,icon,download)
        ,C.LOGNONE
        )

    if download:
        download_filespec = utils.get_setting('download_folder')
        if not download_filespec:
            download_filespec = None
        Log(repr(download_filespec))
            
    else:
        download_filespec = None
    
    headers = {
              #"Referer":'https://bhqwplay.xyz/premiumtv/'
              #"Referer":'https://weblivehdplay.ru/'  #2023-11-12
              #"Referer" : 'https://claplivehdplay.ru/'  #2024-03-01
##               "Referer" : 'https://lewblivehdplay.ru/' #2024-04-14
##              ,"Origin"  : "https://lewblivehdplay.ru" #2024-03-01
##               "Referer" : 'https://claplivehdplay.ru/' #2024-07-07
##              ,"Origin"  : "https://claplivehdplay.ru" #2024-07-07
##               "Referer" : 'https://1qwebplay.xyz/' #2024-08-19
##              ,"Origin"  : "https://1qwebplay.xyz" #2024-08-19
               "Referer" : 'https://quest4play.xyz/' #2024-09-23
              ,"Origin"  : "https://quest4play.xyz" #2024-09-23
               

              ,'Accept'  : '*/*'
            ,"Connection": "keep-alive"
##            ,"Icy-MetaData": "1"
              ,"Accept-Encoding":"gzip"
##              ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0"
              #,"User-Agent":"Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/127.0 Firefox/128.0"
##              ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0"
                ,"User-Agent":'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0'
              }

##    rel_url = '/stream-'+'722'+'.php'
    
##    if rel_url.startswith('/'): rel_url = rel_url.strip('/')
##    rel_url = rel_url.split("/stream-")[1].split('.php')[0]

##    import random
##    rel_url = random.randint(1,899)
                
    m3u8_url = "https://webudit.cdndac.lol/lb/premium{}/index.m3u8".format(rel_url) #pre 2023-09
    m3u8_url = "https://webudit.cdnbos.lol/lb/premium{}/index.m3u8".format(rel_url) #2023-09-04
    m3u8_url = "https://webudit.webdicdn.lol/lb/premium{}/index.m3u8".format(rel_url) #2023-09-09
    m3u8_url = "https://webudit.vipboxtv.stream/lb/premium{}/index.m3u8".format(rel_url) #2023-10-04
    m3u8_url = "https://webudit.hlsjs.ru/lb/premium{}/index.m3u8".format(rel_url) #2023-11-12
    m3u8_url = "https://webudit.webhd.ru/lb/premium{}/index.m3u8".format(rel_url) #2023-12-29
    m3u8_url = "https://webhdrus.webhd.ru/lb/premium{}/index.m3u8".format(rel_url) #2024-02-12
    m3u8_url = "https://webhdrus.onlinehdhls.ru/lb/premium{}/index.m3u8".format(rel_url) #2024-03-01
    m3u8_url = "https://webhdrus.onlinehdhls.ru/lb/premium{}/index.m3u8".format(rel_url) #2024-04-07
    m3u8_url = "https://webhdrunns.mizhls.ru/lb/premium{}/playlist.m3u8".format(rel_url) #2024-07-07

    name = "Channel {}".format(
         rel_url
         )

    url = m3u8_url + utils.Header2pipestring(headers)

    if not playmode_string:
        #playmode_string = C.PLAYMODE_INPUTSTREAM #2024-10 inputstream can't process the M3u8 content 
        playmode_string = C.PLAYMODE_DIRECT #2024-10 ...but direct now works! ;/
    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    if download:
        prog = re.sub("(?:\[COLOR \w+\]\d+:\d+\[/COLOR\]|\[COLOR \w+\]|\[/COLOR\])", "", prog).strip(' ')
        dt = datetime.datetime.now().strftime('%Y-%m-%d')
        name = u"{}.{}.{}".format(prog, dt, name)

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
##        , mimetype = 'video/mp4'
        , download=download
        , download_filespec=download_filespec
        #, skip_head = True
    )

    return True
#__________________________________________________________________________
#
