# -*- coding: utf-8 -*-

#import base libraries
import json
import os
import re
import traceback
import urllib
import xbmc



#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import urlparse
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

BASE = 'https://iptv-org.github.io/iptv/countries/{}.m3u'

try: cache_duration = int(utils.get_setting('html_cache_sportsdaddy'))
except: cache_duration = 300

#__________________________________________________________________________
#
def add_icons(plugin, play, subchannel='', subchannel_label='', sort_order=None):
##    Log(repr((subchannel,subchannel_label,sort_order)))
    
    if not subchannel: return  #for this set, only allow specific channels

    channel = subchannel
    prog = subchannel #ignore program name because we don't have a tvguide for this

    if not sort_order: sort_order = 30.0
    else: sort_order = float(sort_order)

    try:

        #https://zhangboheng.github.io/Easy-Web-TV-M3u8/routes/countries.html
        
        #only figure this out during actual playback because the regex search can be slow on old hardware
        m3u8_url = subchannel
        
        playlink_name = "[COLOR {}][B]{}[/B][/COLOR]".format(
            C.channel_text_color
             , kodiutils.smart_str(subchannel_label)
            )

        if subchannel:
            icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon
        else:
            icon = ""
        utils.addPlaylink(
            plugin = plugin
            ,playlink_name = playlink_name
            ,final_url = m3u8_url
            ,program_name = prog
            ,channel = channel
            ,icon=icon
            ,play=play
            ,module_name=__name__.split('.')[-1]
            ,rating=sort_order #lower value is on top in sort ascending
            ,return_json_info = True
            ,is_folder = False
            ,filter_category = ''
            )
    except:
        traceback.print_exc()

#__________________________________________________________________________
#
def play(prog,rel_url,channel,icon,playmode_string,play_profile):

    Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(
        prog,playmode_string,play_profile,rel_url,channel,icon))

    #rel_url include country of origin and search string 
    country = rel_url.split('/')[0].lower()
    search_string = rel_url.split('/')[1].lower()
    m3u_src = utils.getHtml(BASE.format(country)  , cache_duration=cache_duration)

    search_string = urlparse.unquote(search_string)  #so that i can pass braces within searchstring
    regex = r'#EXTINF:.+?,{}.*?\n(.+?)\n'.format(search_string)   #2024-07-16
    
##    import datetime
##    t_start = datetime.datetime.now()
##    m3u8_url=re.compile(regex, re.DOTALL|re.IGNORECASE).findall(m3u_src)[-1]
##    net = (datetime.datetime.now()-t_start).total_seconds()
##    Log("milliseconds for findall={:.0f}ms".format(net*1000) )
##    Log(m3u8_url)

##    t_start = datetime.datetime.now()
##    Log(repr(regex))
    m3u8_url=re.compile(regex, re.DOTALL|re.IGNORECASE).search(m3u_src)
    if not m3u8_url: m3u8_url='not found'
    else: m3u8_url = m3u8_url.group(1)
##    net = (datetime.datetime.now()-t_start).total_seconds()
##    Log("milliseconds for search={:.0f}ms".format(net*1000) )
##    Log(m3u8_url)
##        

    name = u"[COLOR {}][B]{}[/B][/COLOR] ".format(
        C.channel_text_color,   prog)

    url = m3u8_url

    m3u8 = utils.getHtml(m3u8_url, cache_duration=0) #sometimes it is better to get this before playing
    

    if not playmode_string:
        playmode_string = C.PLAYMODE_DIRECT  #default player

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
        #, skip_head = True
    )

    return True
#__________________________________________________________________________
#
