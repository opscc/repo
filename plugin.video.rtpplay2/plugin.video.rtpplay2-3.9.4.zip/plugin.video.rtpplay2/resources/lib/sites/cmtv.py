# -*- coding: utf-8 -*-

#import base libraries
import json
import os
import re
import traceback
import urllib
import xbmc
#import internal addon libraries
from resources.lib import utils
#define frequenctly used aliases
from resources.lib import constants as C
from resources.lib.utils import Log
from resources.lib.utils import Notify as Notify
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem
from resources.lib import kodiutils

#__________________________________________________________________________
#
def add_icons(plugin, play, subchannel='', subchannel_label='', sort_order=None):
##    Log(repr((subchannel,subchannel_label,sort_order)))
    
    if not subchannel: return  #for this set, only allow specific channels

    channel = subchannel
    prog = subchannel #ignore program name because we don't have a tvguide for this

    if not sort_order: sort_order = 40.0
    else: sort_order = float(sort_order)


    playlink_name = "[COLOR {}][B]{}[/B][/COLOR]".format(
        C.channel_text_color
         , kodiutils.smart_str(subchannel_label)
        )

    if subchannel:
        icon = os.path.join(C.imgDir, ''.join(subchannel_label.split(' '))+'.png') #strip any spaces in the lable to find icon
    else:
        icon = ""
    utils.addPlaylink(
        plugin = plugin
        ,playlink_name = playlink_name
        ,final_url = C.DO_NOTHING_URL
        ,program_name = prog
        ,channel = channel
        ,icon=icon
        ,play=play
        ,module_name=__name__.split('.')[-1]
        ,rating=sort_order #lower value is on top in sort ascending
        ,return_json_info = True
        ,is_folder = False
        ,filter_category = ''
        )

#__________________________________________________________________________
#
##def play(prog,rel_url,channel,icon,playmode_string,play_profile):
##    Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}'".format(
##        prog,playmode_string,play_profile,rel_url,channel,icon))
def play(prog,rel_url,channel,icon,playmode_string,play_profile,download=None):
    Log("prog='{}',playmode_string='{}',play_profile='{}',rel_url='{}',channel='{}',icon='{}', download='{}'".format(
        prog,playmode_string,play_profile,rel_url,channel,icon,download)
        ,C.LOGNONE
        )


    if download:
        download_filespec = utils.get_setting('download_folder')
        if not download_filespec:
            download_filespec = None
        Log(repr(download_filespec))
            
    else:
        download_filespec = None
        
    headers = {
               "Referer" : 'https://www.freeshot.live/' #2024-06-30
              }

    #find out what the current ID is
    try:
        full_html = utils.getHtml("https://popcdn.day/play.php?stream="+channel)
    #    regex = 'src="https://securednode.xyz/CMTVPT/embed.html(\?token=.+?)&'  #2024-06-30
        regex = '<iframe allowfullscreen width="100%" height="100%" scrolling="no" frameborder="0" src="(.+?)/embed.html(\?token=.+?)&'   #2024-07-07
        embed_info=re.compile(regex).findall(full_html)
        embed_url=embed_info[0][0] 
        embed_token=embed_info[0][1]
        m3u8_url = embed_url + "/index.fmp4.m3u8" + embed_token
    except:
        full_html = utils.getHtml("https://popcdn.day/stream/"+channel+".php")
        regex = 'source: "(.+?)"'   #2024-07-16
        m3u8_url=re.compile(regex).findall(full_html)[0]


    name = u"[B][COLOR {}]{}[/B][/COLOR] ({})".format(
        C.channel_text_color, channel, prog)

    headers = {
            "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0"
            ,"Connection" : "keep-alive"
            ,"Icy-MetaData" : "1"
            ,"Accept" : "*/*"
              }
    url = m3u8_url + utils.Header2pipestring(headers) 

    if not playmode_string:
        playmode_string = C.PLAYMODE_DIRECT

    if playmode_string not in C.PLAYMODE_F4MPROXY:
        play_profile = None
    else:
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.PLAYMODE_PROFILE_01

    if download:
        import datetime
        prog = re.sub("(?:\[COLOR \w+\]\d+:\d+\[/COLOR\]|\[COLOR \w+\]|\[/COLOR\])", "", prog).strip(' ')
        dt = datetime.datetime.now().strftime('%Y-%m-%d')
        name = u"{}.{}.{}".format(prog, dt, name)
        
    utils.playvid(
        url
        , name=name
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mimetype = 'application/vnd.apple.mpegurl'
        , download=download
        , download_filespec=download_filespec
        #, skip_head = True
    )
    
    return True
#__________________________________________________________________________
#
