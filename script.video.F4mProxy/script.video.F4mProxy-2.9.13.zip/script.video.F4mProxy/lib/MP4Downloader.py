"""
Simple HTTP Live Streaming client.

References:
    http://tools.ietf.org/html/draft-pantos-http-live-streaming-08

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

Last updated: July 22, 2012
MODIFIED BY shani to make it work with F4mProxy
"""

import struct
import sys
import io
import os
import xbmc
import xbmcvfs
import urllib
import traceback
import urlparse
import array
import random
import string
import requests
import threading

import time


import errno, socket

from f4mUtils import constants as c
from f4mUtils.general_tools import Bool
from f4mUtils.general_tools import Debugging
from f4mUtils.general_tools import Log
from f4mUtils.general_tools import Sleep
from f4mUtils.general_tools import Get_URL as getUrl
from f4mUtils.general_tools import parse_m3u_tag as Parse_M3U_Tag
from f4mUtils.general_tools import Choose_M3U8_Stream

from f4mUtils.general_tools import TempCacheFile
from f4mUtils.general_tools import DeleteCacheFile
from f4mUtils.general_tools import CleanCacheDir

#from Crypto.Cipher import AES
'''
from crypto.cipher.aes      import AES
from crypto.cipher.cbc      import CBC
from crypto.cipher.base     import padWithPadLen
from crypto.cipher.rijndael import Rijndael
from crypto.cipher.aes_cbc import AES_CBC
'''

gauth=None

callbackDRM=None
##from Cryptodome.Cipher import AES
try:
    from Crypto.Cipher import AES
    USEDec=1 ## 1==crypto 2==local, local pycrypto
except:
    Log('pycrypt not available using slow decryption') #, xbmc.LOGNONE)
    USEDec=3 ## 1==crypto 2==local, local pycrypto

if USEDec==1:
    #from Crypto.Cipher import AES
    print 'using pycrypto'
elif USEDec==2:
    from decrypter import AESDecrypter
    AES=AESDecrypter()
else:
    from f4mUtils import python_aes
#from decrypter import AESDecrypter

iv=None
key=None
value_unsafe = '%+&;#'
VALUE_SAFE = ''.join(chr(c) for c in range(33, 127)
    if chr(c) not in value_unsafe)
    
SUPPORTED_VERSION=3

g_clientHeader=None

class MP4Downloader(object):
    """
    A downloader for f4m manifests or AdobeHDS.
    """

    def __init__(self, name = threading.current_thread().name ):
        self.init_done = False
        self.name = name
        self.stop_playing_event = None
        self.download_path = None
        self.url = None
        self.thumbnail_url = None

    def init(self
            , url
            , stop_playing_event
            , seek_forward_event
            , maxbitrate = c.MAXIMUM_BITRATE
            , download_path = None
            , auth = ''
            , initial_bitrate = c.INITIAL_BITRATE
            , allow_upscale = c.ALLOW_UPSCALE
            , allow_downscale = c.ALLOW_DOWNSCALE
            , always_refresh_m3u8 = c.ALWAYS_REFRESH_M3U8
            , downscale_threshhold = c.DOWNSCALE_THRESHHOLD
            , upscale_threshhold = c.UPSCALE_THRESHHOLD
            , upscale_penalty = c.UPSCALE_PENALTY
            , pre_cache_size_max = c.DEFAULT_PRE_CACHE_SIZE_MAX
            , thumbnail_url = None
            ):
        
        global g_clientHeader
        global gauth

        try:
            self.init_done=False
            self.init_url=url
            g_clientHeader=None

            self.name = url
            self.url = url
            self.thumbnail_url = thumbnail_url
            
            self.auth=auth

            if self.auth ==None or self.auth =='None' or self.auth=='':
                self.auth=None

            if self.auth: gauth=self.auth
            
            stop_playing_event.clear()
            self.stop_playing_event = stop_playing_event

            if seek_forward_event: seek_forward_event.clear()
            self.seek_forward_event = seek_forward_event
            
            if '|' in url:
                sp = url.split('|')
                url = sp[0]
                g_clientHeader = sp[1]
                g_clientHeader= urlparse.parse_qsl(g_clientHeader)
                Log ("header recieved now url and headers are '{}'".format(url, g_clientHeader))
            self.url=url

            #store and normalize these values
            self.maxbitrate = abs(int(maxbitrate))
            self.initial_bitrate = abs(int(initial_bitrate))

            self.allow_upscale = Bool(allow_upscale)
            
            self.allow_downscale = Bool(allow_downscale)
            self.always_refresh_m3u8 = Bool(always_refresh_m3u8)
            self.downscale_threshhold = abs(int(downscale_threshhold))
            self.upscale_threshhold = abs(int(upscale_threshhold))
            self.upscale_penalty = -1*abs(int(upscale_penalty))
            self.pre_cache_size_max = abs(int(pre_cache_size_max))

            if self.maxbitrate < c.MINIMUM_BITRATE:
               self.maxbitrate = c.MAXIMUM_BITRATE
            if self.initial_bitrate > self.maxbitrate:
                Log("adjusting birtrate initial {:,} to become maximum {:,}".format(self.initial_bitrate, self.maxbitrate))
                self.initial_bitrate = self.maxbitrate

            self.dumpfile = None
            if download_path:
                if download_path <> 'None':
                    Log ("download_path='{}'".format(download_path))
                    self.dumpfile = open(download_path, "ab")
                    self.download_path = download_path
                    self.name = download_path.split(os.sep)[-1]
            
        except: 
            traceback.print_exc()
            return False

        return True
        
    def keep_sending_video(
        self
        , dest_stream
        , segmentToStart = None
        , totalSegmentToSend = 0
        ) :
        try:
            downloadInternal(
                url = self.url
                , external_stream = dest_stream
                , maximum_bitrate = self.maxbitrate
                , stop_event = self.stop_playing_event
                , seek_forward_event = self.seek_forward_event
                , dumpfile = self.dumpfile
                , initial_bitrate = self.initial_bitrate
                , allow_upscale = self.allow_upscale
                , allow_downscale = self.allow_downscale
                , always_refresh_m3u8 = self.always_refresh_m3u8
                , downscale_threshhold = self.downscale_threshhold
                , upscale_threshhold = self.upscale_threshhold
                , upscale_penalty = self.upscale_penalty
                , pre_cache_size_max = self.pre_cache_size_max
                )
        except:
            #if Debugging():
            traceback.print_exc()
            pass


###__________________________________________________________________
###
def Stop_And_Flush(stop_event, response=None, chunk=None, dumpfile=None):

    if stop_event: #make sure this exists
        if stop_event.isSet(): #if it says 'stop' then close everything
            if dumpfile:
                dumpfile.close()
                dumpfile = None
            if response:
                response.close()
        
    if dumpfile: # just save what needs to be saved
        if chunk:
##            Log( 'Stop_And_Flush' + repr(chunk[0:25]).encode('utf8') )
            dumpfile.write(chunk)
        dumpfile.flush()

###__________________________________________________________________
###
def send_back( data
               , external_stream
               , stop_event
               , dumpfile
               ):
    try:
        if external_stream:
            external_stream.write(data)
##        Log( 'send_back' + repr(data[0:25]).encode('utf8') )
        Stop_And_Flush(stop_event=stop_event, response=None, chunk=data, dumpfile=dumpfile)

    except socket.error as error:
        if error.errno == errno.WSAECONNRESET or error.errno == errno.WSAECONNABORTED:
            pass
        else:
            raise
        
###__________________________________________________________________
###
def download_chunks(URL, stop_event, chunk_size=4096, encrypted=None, decryptor=None, dumpfile=None ):
##    Log("download_chunks [URL='{}',chunk_size='{}', encrypted='{}',decryptor='{}',dumpfile='{}']".format(
##        URL
##        , chunk_size
##        , encrypted
##        , decryptor
##        , dumpfile
##        ))

    response = getUrl(
        URL
        , client_header = g_clientHeader
        , return_response = True
        , stream = True
        )
    if not response:
        return

    if encrypted and decryptor==3:
        chunk_size *= 5 #keep this _smaller_ when using python AES decode to avoid exponential memory copy penalty
##    else:
##        chunk_size *= 10
##    Log('chunk_size={:,}'.format(chunk_size))

    stop_yeilding_signal = None
    import urllib3   
    if isinstance(response, urllib3.response.HTTPResponse):  #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
        for chunk in response.stream(chunk_size, decode_content=True):
            Stop_And_Flush(
                stop_event=stop_event
                , response=response
                , chunk=None
                , dumpfile=dumpfile
                )
            stop_yeilding_signal = (yield chunk)
            if stop_yeilding_signal is not None: break
        response.release_conn()
    else:
        for chunk in response.iter_content(chunk_size=chunk_size):
            Stop_And_Flush(
                stop_event=stop_event
                , response=response
                , chunk=None
                , dumpfile=dumpfile
                )
            stop_yeilding_signal = (yield chunk)
            if stop_yeilding_signal is not None: break
        response.close()
#__________________________________________________________________________
#
#def doDownload(url, dest, progress_dialog, name, stop_event):
def downloadInternal(
                    url
                    , external_stream
                    , maximum_bitrate
                    , stop_event
                    , seek_forward_event
                    , dumpfile
                    , initial_bitrate
                    , allow_upscale
                    , allow_downscale
                    , always_refresh_m3u8
                    , downscale_threshhold
                    , upscale_threshhold
                    , upscale_penalty
                    , pre_cache_size_max
                    ):
    
    start = time.clock()

    try:
        
        #url may have include headers to be passed during transaction
        try:
            headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
        except:
##            traceback.print_exc()
            headers = g_clientHeader

        if '|' in url:
            url = url.split('|')[0]
##        file = dest.rsplit(os.sep, 1)[-1]

        Log("headers='{}'".format(repr(headers)))
        Log("url='{}'".format(repr(url)))
##        resp = getResponse(url, headers, 0)
        #utils.getHtml(url, headers=headers)
        resp = getUrl(
            url
            #, client_header = g_clientHeader
            , client_header = headers
            , return_response = True
            , stream = False
            , method = 'HEAD'
            )

        
        if not resp:
            Log("Download failed: {}".format(url))
            return False

        try:
            content = int(resp.headers['Content-Length'])
            Log("Expected file size {:,} bytes".format(content))
        except:
            content = 0
            traceback.print_exc()

        try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
        except: resumable = False
        if resumable: Log("Download is resumable: {}".format(url))

        if content < 1:
            Log("Unknown filesize: {}".format(url))
            content = 1024*1024*1024


        size = 8192
        mb   = content / (1024 * 1024)

        if content < size:
            size = content

        total   = 0
        errors  = 0
        count   = 0
        resume  = 0
        sleep   = 0
        downloaded = 0

        Log('Download File Size : %dMB ' % (mb))

        chunk  = None
        chunks = []

        loop_interruptor = 0
        monitor = xbmc.Monitor()
        

        chunk = None
        error = False

        down_chunks = download_chunks(
            url
            , stop_event=stop_event
            , dumpfile=dumpfile
            , chunk_size=1024*500
            )
        for chunk in down_chunks:

            # kill the download if kodi monitor tells us to
            if monitor.abortRequested():
                if monitor.waitForAbort(0.1):
                    Log("shutting down '{}' download thread for '{}'".format(C.addon_id,url), xbmc.LOGNOTICE)
                    break

            if stop_event.isSet() == True:
                Log("stop_event.isSet()")
                break

            chunk_length = len(chunk)
            Log('playing {:,} sized chunk of file {}'.format( chunk_length , url ))
            send_back(data=chunk, external_stream=external_stream, stop_event=stop_event, dumpfile=dumpfile)

    except:
        traceback.print_exc()
        raise
#__________________________________________________________________
#
