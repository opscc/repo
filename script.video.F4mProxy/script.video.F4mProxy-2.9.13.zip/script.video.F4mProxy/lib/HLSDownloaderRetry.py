"""
Simple HTTP Live Streaming client.

References:
    http://tools.ietf.org/html/draft-pantos-http-live-streaming-08

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

Last updated: July 22, 2012
MODIFIED BY shani to make it work with F4mProxy
"""

import struct
import sys
import io
import os
import xbmc
import xbmcvfs
import urllib
import traceback
import urlparse
import array
import random
import string
import requests
import threading

import errno, socket

from f4mUtils import constants as c
from f4mUtils.general_tools import Bool
from f4mUtils.general_tools import Debugging
from f4mUtils.general_tools import Log
from f4mUtils.general_tools import Sleep
from f4mUtils.general_tools import Get_URL as getUrl
from f4mUtils.general_tools import parse_m3u_tag as Parse_M3U_Tag
from f4mUtils.general_tools import Choose_M3U8_Stream

from f4mUtils.general_tools import TempCacheFile
from f4mUtils.general_tools import DeleteCacheFile
from f4mUtils.general_tools import CleanCacheDir

#from Crypto.Cipher import AES
'''
from crypto.cipher.aes      import AES
from crypto.cipher.cbc      import CBC
from crypto.cipher.base     import padWithPadLen
from crypto.cipher.rijndael import Rijndael
from crypto.cipher.aes_cbc import AES_CBC
'''

gauth=None

callbackDRM=None
##from Cryptodome.Cipher import AES
try:
    from Crypto.Cipher import AES
    USEDec=1 ## 1==crypto 2==local, local pycrypto
except:
    Log('pycrypt not available using slow decryption') #, xbmc.LOGNONE)
    USEDec=3 ## 1==crypto 2==local, local pycrypto

if USEDec==1:
    #from Crypto.Cipher import AES
    print 'using pycrypto'
elif USEDec==2:
    from decrypter import AESDecrypter
    AES=AESDecrypter()
else:
    from f4mUtils import python_aes
#from decrypter import AESDecrypter

iv=None
key=None
value_unsafe = '%+&;#'
VALUE_SAFE = ''.join(chr(c) for c in range(33, 127)
    if chr(c) not in value_unsafe)
    
SUPPORTED_VERSION=3

g_clientHeader=None

class HLSDownloaderRetry(object):
    """
    A downloader for f4m manifests or AdobeHDS.
    """

    def __init__(self, name = threading.current_thread().name ):
        self.init_done = False
        self.name = name
        self.stop_playing_event = None
        self.download_path = None
        self.url = None
        self.thumbnail_url = None

    def init(self
            , url
            , stop_playing_event
            , seek_forward_event
            , maxbitrate = c.MAXIMUM_BITRATE
            , download_path = None
            , auth = ''
            , initial_bitrate = c.INITIAL_BITRATE
            , allow_upscale = c.ALLOW_UPSCALE
            , allow_downscale = c.ALLOW_DOWNSCALE
            , always_refresh_m3u8 = c.ALWAYS_REFRESH_M3U8
            , downscale_threshhold = c.DOWNSCALE_THRESHHOLD
            , upscale_threshhold = c.UPSCALE_THRESHHOLD
            , upscale_penalty = c.UPSCALE_PENALTY
            , pre_cache_size_max = c.DEFAULT_PRE_CACHE_SIZE_MAX
            , thumbnail_url = None
            ):
        
        global g_clientHeader
        global gauth

        try:
            self.init_done=False
            self.init_url=url
            g_clientHeader=None

            self.name = url
            self.url = url
            self.thumbnail_url = thumbnail_url
            
            self.auth=auth

            if self.auth ==None or self.auth =='None' or self.auth=='':
                self.auth=None

            if self.auth: gauth=self.auth
            
            stop_playing_event.clear()
            self.stop_playing_event = stop_playing_event

            if seek_forward_event: seek_forward_event.clear()
            self.seek_forward_event = seek_forward_event
            
            if '|' in url:
                sp = url.split('|')
                url = sp[0]
                g_clientHeader = sp[1]
                g_clientHeader= urlparse.parse_qsl(g_clientHeader)
                Log ("header recieved now url and headers are '{}'".format(url, g_clientHeader))
            self.url=url

            #store and normalize these values
            self.maxbitrate = abs(int(maxbitrate))
            self.initial_bitrate = abs(int(initial_bitrate))

            self.allow_upscale = Bool(allow_upscale)
            
            self.allow_downscale = Bool(allow_downscale)
            self.always_refresh_m3u8 = Bool(always_refresh_m3u8)
            self.downscale_threshhold = abs(int(downscale_threshhold))
            self.upscale_threshhold = abs(int(upscale_threshhold))
            self.upscale_penalty = -1*abs(int(upscale_penalty))
            self.pre_cache_size_max = abs(int(pre_cache_size_max))

            if self.maxbitrate < c.MINIMUM_BITRATE:
               self.maxbitrate = c.MAXIMUM_BITRATE
            if self.initial_bitrate > self.maxbitrate:
                Log("adjusting birtrate initial {:,} to become maximum {:,}".format(self.initial_bitrate, self.maxbitrate))
                self.initial_bitrate = self.maxbitrate

            self.dumpfile = None
            if download_path:
                if download_path <> 'None':
                    Log ("download_path='{}'".format(download_path))
                    self.dumpfile = open(download_path, "ab")
                    self.download_path = download_path
                    self.name = download_path.split(os.sep)[-1]
            
        except: 
            traceback.print_exc()
            return False

        return True
        
    def keep_sending_video(
        self
        , dest_stream
        , segmentToStart = None
        , totalSegmentToSend = 0
        ) :
        try:
            downloadInternal(
                url = self.url
                , external_stream = dest_stream
                , maximum_bitrate = self.maxbitrate
                , stop_event = self.stop_playing_event
                , seek_forward_event = self.seek_forward_event
                , dumpfile = self.dumpfile
                , initial_bitrate = self.initial_bitrate
                , allow_upscale = self.allow_upscale
                , allow_downscale = self.allow_downscale
                , always_refresh_m3u8 = self.always_refresh_m3u8
                , downscale_threshhold = self.downscale_threshhold
                , upscale_threshhold = self.upscale_threshhold
                , upscale_penalty = self.upscale_penalty
                , pre_cache_size_max = self.pre_cache_size_max
                )
        except:
            #if Debugging():
            traceback.print_exc()
            pass


###__________________________________________________________________
###
def Stop_And_Flush(stop_event, response=None, chunk=None, dumpfile=None):

    if stop_event: #make sure this exists
        if stop_event.isSet(): #if it says 'stop' then close everything
            if dumpfile:
                dumpfile.close()
                dumpfile = None
            if response:
                response.close()
        
    if dumpfile: # just save what needs to be saved
        if chunk:
##            Log( 'Stop_And_Flush' + repr(chunk[0:25]).encode('utf8') )
            dumpfile.write(chunk)
        dumpfile.flush()

###__________________________________________________________________
###
def send_back( data
               , external_stream
               , stop_event
               , dumpfile
               ):
    try:
        if external_stream:
            external_stream.write(data)
##        Log( 'send_back' + repr(data[0:25]).encode('utf8') )
        Stop_And_Flush(stop_event=stop_event, response=None, chunk=data, dumpfile=dumpfile)

    except socket.error as error:
        if error.errno == errno.WSAECONNRESET or error.errno == errno.WSAECONNABORTED:
            pass
        else:
            raise
        
###__________________________________________________________________
###
def download_chunks(URL, stop_event, chunk_size=4096, encrypted=None, decryptor=None, dumpfile=None ):
##    Log("download_chunks [URL='{}',chunk_size='{}', encrypted='{}',decryptor='{}',dumpfile='{}']".format(
##        URL
##        , chunk_size
##        , encrypted
##        , decryptor
##        , dumpfile
##        ))

    response = getUrl(
        URL
        , client_header = g_clientHeader
        , return_response = True
        , stream = True
        )
##    Log(repr(response))
##    Log(repr(dir(response)))
##    Log(repr(response.data))

    if not response:
        return

    if encrypted and decryptor==3:
        chunk_size *= 50 #keep this _smaller_ when using python AES decode to avoid exponential memory copy penalty
    else:
        chunk_size *= 1000
##    Log('chunk_size={:,}'.format(chunk_size))

    stop_yeilding_signal = None
    import urllib3   
    if isinstance(response, urllib3.response.HTTPResponse):  #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
        for chunk in response.stream(chunk_size, decode_content=True):
            Stop_And_Flush(
                stop_event=stop_event
                , response=response
                , chunk=None
                , dumpfile=dumpfile
                )
            stop_yeilding_signal = (yield chunk)
            if stop_yeilding_signal is not None: break
        response.release_conn()
    else:
        for chunk in response.iter_content(chunk_size=chunk_size):
            Stop_And_Flush(
                stop_event=stop_event
                , response=response
                , chunk=None
                , dumpfile=dumpfile
                )
            stop_yeilding_signal = (yield chunk)
            if stop_yeilding_signal is not None: break
        response.close()
        
###__________________________________________________________________
###
def download_file(URL, stop_event):
    return ''.join(download_chunks(URL=URL, stop_event=stop_event))

###__________________________________________________________________
###
def gen_m3u(url, skip_comments=True):

    response, redirected_url = getUrl(
                                      url
                                      , client_header = g_clientHeader
                                      , send_back_redirect = True
                                      )
    if not response:
        yield ''
        raise Exception("No response at url='{}'".format(url))

    if redirected_url:
        text = 'f4mredirect:'+redirected_url
        Log(text)
        yield text

    #for line in response.iter_lines():
    for line in response.split('\n'):
        line = line.rstrip('\r\n') #.decode(file_encoding)
        if not line: # blank line
            continue
        elif line.startswith('#EXT'): # tag
            yield line
        elif line.startswith('#'):    # comment
            if skip_comments:
                continue
            else:
                yield line
        else: # media file
            yield line
            

###__________________________________________________________________
###
def parse_kv(attribs, known_keys=None):
    d = {}
    for item in attribs:
        k, v = item.split('=', 1)
        k=k.strip()
        v=v.strip().strip('"')
        if known_keys is not None and k not in known_keys:
            raise ValueError("unknown attribute %s"%k)
        d[k] = v
    return d

###__________________________________________________________________
###
def handle_basic_m3u(url):
    global iv
    global key
    global USEDec
    global gauth
    import urlparse
    global callbackDRM
    
    seq = 1
    enc = None
    duration = 5
    targetduration=5
    aesdone=False
    redirurl=url
    vod=False

##    expire_date_time = datetime.datetime.now() + datetime.timedelta(0,5)
##    Log("expire_date_time={}".format(repr(expire_date_time)))

    for line in gen_m3u(url):

##        Log("line_from_gen_m3u={}".format(repr(line)))

        if line.startswith('f4mredirect:'):
            redirurl=line.split('f4mredirect:')[1]
            continue
        if line.startswith('#EXT'):
            tag, attribs = Parse_M3U_Tag(line)

##            Log("EXT line_from_gen_m3u={}".format(repr(line)))
##            Log("tag='{}'".format(repr(tag)))
##            Log("attribs='{}'".format(repr(attribs)))

            if tag == '#EXTINF':
                duration = float(attribs[0])

            elif tag == '#EXT-X-TARGETDURATION':
##                duration = int ( line.split('#EXT-X-TARGETDURATION:')[1] )
##                Log("duration={}".format(repr(duration)))
                assert len(attribs) == 1, "too many attribs in EXT-X-TARGETDURATION"
                targetduration = int(attribs[0])
##                expire_date_time = datetime.datetime.now() + datetime.timedelta(0,targetduration)
##                Log("targetduration={}".format(repr(targetduration)))
##                Log("expire_date_time={}".format(repr(expire_date_time)))
                pass

            elif tag == '#EXT-X-MEDIA-SEQUENCE':
                assert len(attribs) == 1, "too many attribs in EXT-X-MEDIA-SEQUENCE"
                seq = int(attribs[0])

            elif tag == '#EXT-X-KEY':

                attribs = parse_kv(attribs, ('METHOD', 'URI', 'IV'))
                assert 'METHOD' in attribs, 'expected METHOD in EXT-X-KEY'
                if attribs['METHOD'] == 'NONE':
                    assert 'URI' not in attribs, 'EXT-X-KEY: METHOD=NONE, but URI found'
                    assert 'IV' not in attribs, 'EXT-X-KEY: METHOD=NONE, but IV found'
                    enc = None
                elif attribs['METHOD'] == 'AES-128':
                    if not aesdone:
                        #aesdone=False there can be multple aes per file
                        assert 'URI' in attribs, 'EXT-X-KEY: METHOD=AES-128, but no URI found'
                        #from Crypto.Cipher import AES
                        codeurl=attribs['URI'].strip('"')
                        
                        if gauth:
                            currentaesUrl=codeurl
                            codeurl=gauth
                            
                            if codeurl.startswith("LSHex$"):
                                codeurl=codeurl.split('LSHex$')[1].decode("hex")
                                print 'code is ',codeurl.encode("hex")
                            if codeurl.startswith("LSDRMCallBack$"):
                                codeurlpath=codeurl.split('LSDRMCallBack$')[1]
                                codeurl='LSDRMCallBack$'+currentaesUrl
                                
                                if codeurlpath and len(codeurlpath)>0 and callbackDRM==None:
                                    print 'callback',codeurlpath
                                    import importlib, os
                                    foldername=os.path.sep.join(codeurlpath.split(os.path.sep)[:-1])
                                    urlnew=''
                                    if foldername not in sys.path:
                                        sys.path.append(foldername)
                                    try:
                                        callbackfilename= codeurlpath.split(os.path.sep)[-1].split('.')[0]
                                        callbackDRM = importlib.import_module(callbackfilename)
                                        print 'LSDRMCallBack imported'
                                    except:
                                        traceback.print_exc()
                            
                        elif not codeurl.startswith('http'):
                            import urlparse
                            codeurl=urlparse.urljoin(url, codeurl)
                                
                        
                        #key = download_file(codeurl)
                        
                        elif not codeurl.startswith('http'):
                            import urlparse
                            codeurl=urlparse.urljoin(url, codeurl)
                            
                        #assert len(key) == 16, 'EXT-X-KEY: downloaded key file has bad length'
                        if 'IV' in attribs:
                            assert attribs['IV'].lower().startswith('0x'), 'EXT-X-KEY: IV attribute has bad format'
                            iv = attribs['IV'][2:].zfill(32).decode('hex')
                            assert len(iv) == 16, 'EXT-X-KEY: IV attribute has bad length'
                        else:
                            iv = '\0'*8 + struct.pack('>Q', seq)
                        enc=(codeurl,iv)
                        #if not USEDec==3:
                        #    enc = AES.new(key, AES.MODE_CBC, iv)
                        #else:
                        #    ivb=array.array('B',iv)
                        #    keyb= array.array('B',key)
                        #    enc=python_aes.new(keyb, 2, ivb)
                        #enc = AES_CBC(key)
                        #print key
                        #print iv
                        #enc=AESDecrypter.new(key, 2, iv)
                else:
                    assert False, 'EXT-X-KEY: METHOD=%s unknown'%attribs['METHOD']
            elif tag == '#EXT-X-PROGRAM-DATE-TIME':
                assert len(attribs) == 1, "too many attribs in EXT-X-PROGRAM-DATE-TIME"
                # TODO parse attribs[0] as ISO8601 date/time
                pass
            elif tag == '#EXT-X-ALLOW-CACHE':
                # XXX deliberately ignore
                pass
            elif tag == '#EXT-X-PLAYLIST-TYPE':
                vod = (attribs[0] == 'VOD')
                continue                
                #EXT-X-PLAYLIST-TYPE:VOD
            elif tag == '#EXT-X-ENDLIST':
                assert not attribs
                yield None
                return
            elif tag == '#EXT-X-STREAM-INF':
                raise ValueError("don't know how to handle EXT-X-STREAM-INF in basic playlist")
            elif tag == '#EXT-X-DISCONTINUITY':
                assert not attribs
                print "[warn] discontinuity in stream"
            elif tag == '#EXT-X-VERSION':
                assert len(attribs) == 1
                if int(attribs[0]) > SUPPORTED_VERSION:
                    print "[warn] file version %s exceeds supported version %d; some things might be broken"%(attribs[0], SUPPORTED_VERSION)
            #else:
            #    raise ValueError("tag %s not known"%tag)

        else:
            if not line.startswith('http'):
                line=urlparse.urljoin(redirurl, line)
            yield (seq, enc, duration, targetduration, line ,vod )
            seq += 1


###__________________________________________________________________
###
def downloadInternal(
                    url
                    , external_stream
                    , maximum_bitrate
                    , stop_event
                    , seek_forward_event
                    , dumpfile
                    , initial_bitrate
                    , allow_upscale
                    , allow_downscale
                    , always_refresh_m3u8
                    , downscale_threshhold
                    , upscale_threshhold
                    , upscale_penalty
                    , pre_cache_size_max
                    ):



    if external_stream is None and dumpfile is None:
        raise Exception("both external_stream and save_file are None")

    
    #url check if requires redirect
    redirected_url = url
    data_from_url, redirected_url = getUrl( url
                                            , client_header = g_clientHeader
                                            , send_back_redirect = True
                                            )
    if redirected_url:
        Log("redirected_url='{}'".format(redirected_url))
        url = redirected_url
##    Log("data_from_url='{}'".format(data_from_url))

##
##    data = "#EXTM3U\n#EXT-X-TARGETDURATION:19\n#EXT-X-ALLOW-CACHE:YES\n"
##    if external_stream:
##        external_stream.write(data_from_url)
##    Sleep(30*1000)
##        
##    return


    vod = ("EXT-X-PLAYLIST-TYPE:VOD" in data_from_url)

    #extract stream from  the expected application/vnd.apple.mpegurl file
    if not('EXT-X-STREAM-INF' in data_from_url or 'EXT-X-TARGETDURATION' in data_from_url):
        Log("data_from_url='{}'".format(data_from_url), xbmc.LOGNONE)
        raise Exception("EXT-X-STREAM-INF was not found in '{}'".format(url))

    #
    #used in adjusting bitrate [and playing in first place]
    #
    initial_bitrate = min(initial_bitrate, maximum_bitrate) #in case initial is somehow bigger than max
    (chunklist_url, chosen_bitrate, slightly_better, slightly_worse) = Choose_M3U8_Stream(
        url
        , data_from_url
        , initial_bitrate
        , dumpfile
        , vod)
    Log("found {:,} bitrate, with initial of {:,}".format(chosen_bitrate, initial_bitrate))
    first_chosen_bitrate = chosen_bitrate


    INITIALIZE_LAST_SEQ = -1
    fails = 0
    maxfails = 5 #value will be increased after first successful connection
    

    #
    #decrypting encrypted streams
    #
    lastKeyUrl=""
    lastkey=None
  

    #
    #pre-caching some amout of
    #
##    DEFAULT_PRE_CACHE_SIZE_FACTOR = 1
##    pre_cache_size_factor = DEFAULT_PRE_CACHE_SIZE_FACTOR
##    pre_cache_size_max = slightly_better*pre_cache_size_factor
    pre_cache_size_current = 0
    cache_file = None
    # make sure caching does not take too long; else player will give up
    # can test by combining a low bitrate stream with a large cache size
##    Log("pre_cache_size_max='{:,}'".format(pre_cache_size_max))
##    Log("pre_cache_size_max='{:,}'".format(first_chosen_bitrate * c.PRE_CACHE_SIZE_BITRATE_MAX_FACTOR))
    pre_cache_size_max = min(pre_cache_size_max, first_chosen_bitrate * c.PRE_CACHE_SIZE_BITRATE_MAX_FACTOR)
##    Log("final pre_cache_size_max='{:,}'".format(pre_cache_size_max))
    try:
        #cleanup cache dir in a thread in cases where hlsretryseek is used, which needs to pre-load X seconds of content. Delays in cleanp could prevent this loding
        worker = threading.Thread(target=CleanCacheDir)
        worker.daemon = True
        worker.start()
        #CleanCacheDir()
    except:
        traceback.print_exc()
        pass
    if pre_cache_size_max > 0:
        Log("caching up to {:,} before playing".format(pre_cache_size_max))

    start_new_seq = True
    

    #
    #wait some amount of time before asking for next m3u8 file
    #
    sleep_time = c.DEFAULT_SLEEP_TIME  # will be tuned as time goes on within 

    #
    #used in detecting if this thread needs to be deleted/stopped
    #
    stopevent_exception_count = 0
    original_playing_file = None
    if external_stream and xbmc.Player().isPlaying():
        original_playing_file = xbmc.Player().getPlayingFile()
    Log("original_playing_file='{}'".format(original_playing_file))
        
    monitor = xbmc.Monitor()
##    if monitor.abortRequested() or stop_event.isSet():
##        Log("ending thread because monitor.abortRequested() or stop_event.isSet()")
##        Stop_And_Flush(stop_event=stop_event, response=None, chunk=None, dumpfile=None)
##        return False


##    Log("downloadInternal stop_event='{}'".format(repr(stop_event)))
    while not stop_event.isSet() :

        Debugging() #recheck if debugging setting changed
        
        if start_new_seq:
            Log('start_new_seq')
            stream_was_changed = False
            good_chunks = 0
            missed_sequences = 0
            last_seq = INITIALIZE_LAST_SEQ
            start_new_seq = False

        if fails > maxfails:
            Log("fails '{}' > '{}' maxfails".format(fails, maxfails))
            stop_event.set()
            break

        if stop_event.isSet() == True:
            Log("stop_event.isSet()")
            break
            
        try:
            medialist = list(handle_basic_m3u(chunklist_url))
            if len(medialist) < 1:
                raise Exception('empty m3u8')
        except:
##            traceback.print_exc()
            fails+=1
            Sleep(sleep_time)
            continue
        
        #
        # keep track in case we happen to go through the entire media list without
        # finding a sequence number to play
        #
        found_playable_packet = False

        for media in medialist:

            if fails > maxfails:
                Log("fails '{}' > '{}' maxfails".format(fails, maxfails), xbmc.LOGNONE)
                stop_event.set()
                break

            if monitor.abortRequested():
                Log("ending thread because monitor.abortRequested()==True") 
                stop_event.set() 
                break
            
            if external_stream is not None:
                try:
                    current_playing_file = None
                    if xbmc.Player().isPlaying():
                        current_playing_file = xbmc.Player().getPlayingFile()
                    #if we are switching between media files
                    if not(original_playing_file == current_playing_file ): 
                        Log("ending thread because '{}'<>'{}'".format(original_playing_file,current_playing_file)) 
                        stop_event.set() 
                        break           
                    else: 
                        stopevent_exception_count = 0 
                    pass
                except:
                    stopevent_exception_count += 1
                    # we can exit or assume player will stop messing up next loop
                    if stopevent_exception_count > c.MAX_NOTHING_PLAYING_EXCEPTIONS:
                        Log("stopevent_exception_count > c.MAX_NOTHING_PLAYING_EXCEPTIONS:")
                        stop_event.set()  
                        break            
                    #traceback.print_exc()
                    pass

            if media is None:
                Log("media is None")
                stop_event.set()
                break

            if stop_event.isSet() == True:
                Log("stop_event.isSet()")
                break

            seq, encobj, duration, targetduration, media_url, vod = media
##            Log("media='{}'".format(repr(media)))

            if (seq <= last_seq) :
##                Log("already played seq={} file={}".format(repr(seq), repr(media_url)))
                Sleep(c.MIN_SLEEP_TIME/2)
                continue #look at the next media sequence
            else:
                found_playable_packet = True

            #
            # adjust sleep times according to what manually tuned values see to work
            #
            if last_seq == INITIALIZE_LAST_SEQ: last_seq = seq-1
            old_missed_sequences = missed_sequences
            if (seq > (last_seq + 1)) and not(last_seq == -1) :                   # ==-1 part is to prevent missinformation on first packet
                newly_missed = seq - (last_seq + 1)
                missed_sequences = missed_sequences + newly_missed               
##                Log("sleep_time='{:,}' duration='{:,}' ".format(sleep_time, duration))
                sleep_time = max( (sleep_time/1.5) , c.MIN_SLEEP_TIME)
            else:
                missed_sequences = max(0, missed_sequences - 0.5)        #slowly decrement this, making sure it is never negative
                sleep_time = min( (sleep_time*1.5), (targetduration*250) )
                sleep_time = max( c.MIN_SLEEP_TIME, sleep_time )         #correct for situation where a sites reports a negative value for duration...
##                Log("sleep_time='{:,}' duration='{:,}' ".format(sleep_time, duration))
            if not (old_missed_sequences == missed_sequences): #logging purposes
                Log("missed_sequences='{:,}'".format(missed_sequences))
                pass

            old_chunklist_url = chunklist_url # only do this if there was acutally a change; some only have one stream

            #
            # consequences for too many missed chunks...
            #
            if missed_sequences > downscale_threshhold: #2 seems to be good number on my device

##                Log("missed_sequences {:,} > {:,} downscale_threshhold".format(missed_sequences,downscale_threshhold))
                pre_cache_size_current = 0
                last_seq = seq
                missed_sequences = 0
                good_chunks = upscale_penalty #make it hard for stream to improve if it was downgraded
                sleep_time = c.DEFAULT_SLEEP_TIME

                if allow_downscale == True and vod == False:

                    Log("downscaling...")

                    old_chosen_bitrate = chosen_bitrate
                    
                    Log("looking for a slower bitrate than {:,} to a minimum of {:,} bps".format(chosen_bitrate,slightly_worse))
                    chunklist_url, chosen_bitrate, slightly_better, slightly_worse = Choose_M3U8_Stream(url, data_from_url, slightly_worse, dumpfile, vod)
                    Log("found {:,} bitrate, with maximum of {:,}".format(chosen_bitrate, slightly_worse))

                    stream_was_changed = not(old_chunklist_url == chunklist_url)

                    if stream_was_changed:
##                        start_new_seq = True #sometimes the seq number will be different for different resolutions                        
                        break #force a new m3u8 because seq number changed

                seek_forward_event.set()
                Log("seek_forward_event", xbmc.LOGNONE)
##                if not stream_was_changed:
####                    Log("seek_forward_event")
##                    seek_forward_event.set()
####                    break #force a new m3u8; seems to help with ?crashing?
##                else:
##                    Log("only_one_stream (slightly_better{:,}=={:,}slightly_worse)".format(slightly_better,slightly_worse))
##                    pass


            #
            # consequences for good chunks...
            #
            if missed_sequences <= 0:
                good_chunks += 1
            else:
                good_chunks = 0
                
            if good_chunks > upscale_threshhold: #good number of chunks before we will try and improve bitrates

                last_seq = seq
                missed_sequences = 0
                good_chunks = 0
                sleep_time = c.DEFAULT_SLEEP_TIME

                if allow_upscale == True and vod == False:

                    Log("upscaling...")

##                    if first_chosen_bitrate < c.KODI_CRASH:
##                        slightly_better = min(slightly_better,c.KODI_CRASH)

                    slightly_better = min(slightly_better, maximum_bitrate)

                    old_chosen_bitrate = chosen_bitrate
                    
                    Log("looking for a better bitrate than {:,} to a maximum of {:,} bps".format(chosen_bitrate, slightly_better))
                    chunklist_url, chosen_bitrate, slightly_better, slightly_worse = Choose_M3U8_Stream(url, data_from_url, slightly_better, dumpfile, vod)
                    Log("found {:,} bitrate, with maximum of {:,}".format(chosen_bitrate, slightly_better))

                    stream_was_changed = not(old_chunklist_url == chunklist_url)
                
                    #move forward to force a video player flush
                    if stream_was_changed : # only do this if there was actually a change; some only have one stream
##                        start_new_seq = True #sometimes the seq number will be different for different resolutions
                        break #force a new m3u8 because seq number changed
                    else:
                        Log("better bitrate not found")
                        pass


            #
            # download chunks and play them
            #            
            try:
                
                #
                # prepare encryption key; if any
                #
                enc=None
                if encobj:
                    codeurl, iv = encobj
                    if codeurl <> lastKeyUrl:
    ##                    Log("new codeurl='{}'    lastKeyUrl='{}' ".format(codeurl, lastKeyUrl))
                        if codeurl.startswith('http'):
                            key = download_file(codeurl, stop_event)
                        elif codeurl.startswith('LSDRMCallBack$'):
                            key = callbackDRM.DRMCallback(codeurl.split('LSDRMCallBack$')[1],url)
                        else:
                            key = codeurl
                        lastKeyUrl = codeurl
                    else:
                        key=lastkey
                    if not lastkey==key: Log("new key='{}'".format(repr(key)))
                    lastkey = key
                    if not USEDec==3:
                        Log("not USEDec==3")
                        enc = AES.new(key, AES.MODE_CBC, iv)
                    else:
                        ivb=array.array('B',iv)
                        keyb= array.array('B',key)
    ##                    Log("python_aes.new(keyb, 2, ivb)")
    ##                    Log("keyb='{}'".format(keyb))
    ##                    Log("ivb='{}'".format(ivb))
                        enc=python_aes.new(keyb, 2, ivb)
                    #enc=AESDecrypter.new(key, 2, iv)



                chunk = None
                chunk_length = 0
                try:
##                    Log('downloading from {}'.format(urlparse.urljoin(url, media_url)))
                    down_chunks = download_chunks(
                        media_url
                        , stop_event=stop_event
                        , dumpfile=dumpfile
                        , encrypted=enc
                        , decryptor=USEDec
                        ) 
                    for chunk in down_chunks:
                        if enc:
##                            Log("encrypted, usedec={}".format(USEDec))
                            if not USEDec==3:
                                chunk = enc.decrypt(chunk)
                            else:
##                                Log("array")
                                chunkB = array.array('B',chunk)
##                                Log("chunkB='{}'".format(chunkB))
##                                Log("decrypt")
                                chunk = enc.decrypt(chunkB)
##                                Log("join")
                                chunk = "".join(map(chr, chunk))
##                                Log('end decrypting chunk, USEDec={}'.format(USEDec))
##                                Log('afterdecrypting' + repr(chunk[0:25]).encode('utf8') )

                        chunk_length = len(chunk)

                        if pre_cache_size_current < pre_cache_size_max: #store chunk instead of playing it
                            Log('caching {:,} sized chunk of seq {}'.format( chunk_length , seq ))
                            if not cache_file:
                                cache_file = TempCacheFile()
                                cache_filespec = cache_file.name
                                Log("cache_filespec='{}'".format(cache_filespec))
                                
                            cache_file.write(chunk)
                            
                            pre_cache_size_current += chunk_length

                            if pre_cache_size_current >= pre_cache_size_max: #play what we cached
                                cache_file.close()
                                cache_file = open(cache_filespec, "r+b")
                                Log('uncaching {:,} sized chunk'.format( pre_cache_size_current ))
                                chunk = cache_file.read()  #todo? read 8192 bytes at a time
                                chunk_length = len(chunk)
                                cache_file.close()
                                DeleteCacheFile(cache_filespec)
                                cache_file = None
                                cache_filespec = None
                                
                        if cache_file is None:
                            Log('playing {:,} sized chunk of seq {} file {}'.format( chunk_length , seq, media_url ))
                            send_back(data=chunk, external_stream=external_stream, stop_event=stop_event, dumpfile=dumpfile)
                            #down_chunks.send(False) #Stop yeilding data. Generate exception StopIteration

                except StopIteration:
                    pass                      
                except Exception as inst:
                    Log('except Exception as inst:')
                    traceback.print_exc()
                    raise
                    if 'forcibly closed' in repr(inst): 
                        return False

                if chunk and chunk_length>0: 
                    last_seq = seq
                    fails=0
                    maxfails=20
                else:
                    fails+=1

                if always_refresh_m3u8 == True:
                    break #exit loop " for media in medialist:"   # force a fresh m3u8 file
                elif (missed_sequences > 1): 
                    Log("chunks missing; use current m3u8 as much as possible to give temporary issues time to catch up")
                    pass
                else:
##                    Log("using current m3u8 as much as possible")
                    pass


##                stop_event.set()
            
            except:
                traceback.print_exc()
                fails+=1
                pass

            monitor.waitForAbort(0.01) #need this to make abortRequested() call more accurate?
            
        else:
##            Log('end of loop " for media in medialist:"')
##            seek_forward_event.set()
##            stop_event.set()

            monitor.waitForAbort(0.01) #need this to make abortRequested() call more accurate?
            
            if found_playable_packet == False:
                # we went through the entire media list without finding a sequence number to play
                # sleep before looking for another m3u8
##                Log("Sleeping '{:,}' milliseconds because we did not find any new pieces to play".format(sleep_time))
                Sleep(sleep_time)
                
            
        


    else:
        Log("end of loop   'while not stop_event.isSet() :'   ")

    if cache_file is not None: #media is smaller than cache somehow. Dump it
        cache_file.close()
        cache_file = open(cache_filespec, "r+b")
        Log('uncaching {:,} sized chunk'.format( pre_cache_size_current ))
        chunk = cache_file.read()  #todo? read 8192 bytes at a time
        chunk_length = len(chunk)
        cache_file.close()
        DeleteCacheFile(cache_filespec)
        cache_file = None
        cache_filespec = None
        Log('playing {:,} sized chunk of seq {}'.format( chunk_length , seq ))
        send_back(data=chunk, external_stream=external_stream, stop_event=stop_event, dumpfile=dumpfile)

    monitor = None

#__________________________________________________________________
#
