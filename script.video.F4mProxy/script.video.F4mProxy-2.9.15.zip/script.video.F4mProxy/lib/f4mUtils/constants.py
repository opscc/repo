#-*- coding: utf-8 -*-
'''
Constants and stuff
'''

import xbmcaddon

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 55334

MAXIMUM_BITRATE_FOR_DOWNLOADS = 999999999

HTTP_TIMEOUT = 90


#HLS DOWNLOADER RETRY
INITIAL_BITRATE = 5000000
MAXIMUM_BITRATE = 5000000
ALLOW_UPSCALE = False
UPSCALE_THRESHHOLD = 30
UPSCALE_PENALTY = 30
ALWAYS_REFRESH_M3U8 = False
ALLOW_DOWNSCALE = False
DOWNSCALE_THRESHHOLD = 2
MINIMUM_BITRATE = 1000

DEFAULT_DESCRIPTION = ''
DEFAULT_PRE_CACHE_SIZE_MAX = 0 #no cache by default
#player will give up if caching is taking too long; avoid this by adjusting
#cache size relative to bitrate such that player only has to wait X seconds
PRE_CACHE_SIZE_BITRATE_MAX_FACTOR = 2

#HACKS: kodi crashes if I ALLOW_UPSCALE when more than this
KODI_CRASH = int(2.9*1000*1000)
MAX_NOTHING_PLAYING_EXCEPTIONS = 4 # often getPlayingFile will return a 'nothing is playing' exception instead of True/False

DEFAULT_SLEEP_TIME = 444 # milliseconds; how long to sleep before asking for a new M3u8 file                    
MIN_SLEEP_TIME     = 101 # milliseconds; minimum

    
DEFAULT_SLEEP_INTERVAL_STEP = 50

TEMP_CACHE_FILE_FOLDER = "cache"
TEMP_CACHE_FILE_EXT = ".tmp.ts"

TIME_BEFORE_TEMP_FILE_MANIPULATION = 1000 #milliseconds
TEMP_FILE_MANIPULATION_ATTEMPTS = 5

this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
##DEBUG = (this_addon.getSetting('debug').lower() == "true")
