#-*- coding: utf-8 -*-
#import Cookie
import cookielib
import datetime
import time
import json
import os, errno
import re
import requests
import traceback
import urllib3
import urlparse
import xbmc
import xbmcaddon

import constants as c

this_addon = xbmcaddon.Addon()
DEBUG = (this_addon.getSetting('debug').lower() == "true")
addon_id = str(this_addon.getAddonInfo('id'))
profileDir = this_addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')
cookieJar = cookielib.LWPCookieJar(xbmc.translatePath(cookiePath))
my_http_session = requests.Session()


###__________________________________________________________________
###
#either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
# https://wiki.mozilla.org/CA/Included_Certificates
##if C.DEBUG: urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
##certPath = os.path.join(os.path.dirname(__file__), "cacert.pem")  # located in same folder as this one
import certifi
certPath = certifi.where()

from urllib3 import PoolManager
proxy = PoolManager()
if certPath:
    pool_proxy = PoolManager(ca_certs=certPath)
else:
    pool_proxy = PoolManager()
    


###__________________________________________________________________
###
def Bool(data): #convert an object into True or False; can't trust python's
    return (str(data) in ['true', 'True'])

###__________________________________________________________________
###
def IsNotNone(data):
    return not(str(data) in ['None', 'none', ''])

###__________________________________________________________________
###
def IsNone(data):
    return (str(data) in ['None', 'none', ''])

###__________________________________________________________________
###
def Debugging():
##    return True
    global DEBUG
    try:
        this_addon = xbmcaddon.Addon()
        DEBUG = (this_addon.getSetting('debug').lower() == "true")
    except:
        traceback.print_exc()
        DEBUG = True
        
    return  DEBUG

###__________________________________________________________________
###
def Log(msg="", loglevel=None):
    if not isinstance(msg, unicode):
        msg = unicode(msg.decode('utf-8', 'ignore'))
    try: 
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=2)[0][0])
            ,traceback.extract_stack(limit=2)[0][1]
            ,msg
            )
    except:
        pass
    msg = "{}: {}".format(addon_id, msg.encode('utf-8',errors='ignore') )
    if              loglevel: xbmc.log(msg , loglevel)
    elif         Debugging():  xbmc.log(msg , xbmc.LOGNONE)
    else:                       xbmc.log(msg)
##    try: 
##        msg = "{}:{} {}".format(
##            os.path.basename(traceback.extract_stack(limit=2)[0][0])
##            ,traceback.extract_stack(limit=2)[0][1]
##            ,msg
##            )
##    except:
##        pass
##    
##    msg = "{}: {}".format(addon_id, msg)
##    if   loglevel is not None: xbmc.log(msg , loglevel)
##    elif          Debugging(): xbmc.log(msg , xbmc.LOGNONE)
##    else:                      xbmc.log(msg)

###__________________________________________________________________
###
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=c.DEFAULT_SLEEP_INTERVAL_STEP):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
##    Log("num='{}' sleep_interval='{}'".format(num,sleep_interval))
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval

###__________________________________________________________________
###
def GetCacheDirFileSpec():
    addon = xbmcaddon.Addon()
#    cache_dir = addon.getAddonInfo('profile')
#    cache_dir = xbmc.translatePath("special://home/cache/archive_cache")
    cache_dir = xbmc.translatePath("special://home/cache")
    if not os.path.exists(cache_dir): os.mkdir(cache_dir)
    cache_dir = os.path.join(cache_dir, "archive_cache")
    if not os.path.exists(cache_dir): os.mkdir(cache_dir)
    cache_dir = os.path.join(cache_dir, c.TEMP_CACHE_FILE_FOLDER)
    if not os.path.exists(cache_dir): os.mkdir(cache_dir)
##    temp_path = os.path.join(cache_dir, c.TEMP_CACHE_FILE_FOLDER)
##    try:
##        os.mkdir(temp_path)
##    except OSError as e:
##        if e.errno == errno.EEXIST:
##            pass
##        else:
##            raise
    return cache_dir

###__________________________________________________________________
###
def CleanCacheDir():
    temp_path = GetCacheDirFileSpec()
    for root, dirs, files in os.walk(temp_path):
        for name in files:
            filename = os.path.join(root, name)
            mtime = os.path.getmtime(filename)
##            Log(repr(time.gmtime(mtime)))
            if (time.time() - mtime) > 120:  #file modified more than 120 seconds
                DeleteCacheFile(filename)
###__________________________________________________________________
###
def DeleteCacheFile(filespec):
#    traceback.print_stack()
    try:
        if filespec.endswith(c.TEMP_CACHE_FILE_EXT):
            Log("deleting filespec='{}'".format(filespec))
            delete_attempt = 0
            while os.path.exists(filespec) and delete_attempt <= c.TEMP_FILE_MANIPULATION_ATTEMPTS:
                delete_attempt += 1
                Sleep(c.TIME_BEFORE_TEMP_FILE_MANIPULATION)
                try:
                    os.remove(filespec)
                except:
                    if delete_attempt == c.TEMP_FILE_MANIPULATION_ATTEMPTS:
                        traceback.print_exc()
                    pass
            else:
                if not os.path.exists(filespec):
                    Log("{} deleted".format(repr(filespec).replace('\\\\', '\\')))
    except:
        traceback.print_exc()
        
###__________________________________________________________________
###
def TempCacheFile():
    #return writable file object
    import tempfile
    return tempfile.NamedTemporaryFile(
        mode = 'a+b'
        ,suffix = '.tmp.mp4'
        ,dir = GetCacheDirFileSpec()
        ,delete = False
        )
###__________________________________________________________________
###
def Get_URL(url
           ,client_header
           ,stream=False
           ,return_response=False
           ,save_cookie=False
           ,send_back_redirect=False
           ,method='GET'
           ,request_body=''):

    #must recalc this value if we want to dynamically change debugging verbosity without restart
    Debugging()
    
##    Log(repr((url
##           ,client_header
##           ,stream
##           ,return_response
##           ,save_cookie
##           ,send_back_redirect
##           ,method
##           ,request_body)))

    if not client_header: client_header = {}

    return getHtml(url
                   , headers=dict(client_header)
                   , send_back_response=return_response
                   , preload_content=not stream
                   , method=method
                   , save_cookie=save_cookie
                   , send_back_redirect=send_back_redirect
                   , sent_data=request_body
                   )
##def getHtml(url
##            , referer=''
##            , headers=None
##            , save_cookie=False
##            , sent_data=None
##            , ignore404=False
##            , ignore403=False
##            , send_back_redirect=False
##            , http_timeout=10
##            , sucuri_solved=False
##            , method="GET"
##            , send_back_response=False
##            , auto_encode_content=False
####            , cookie_domain=None
##            , size=8192*1000
##            , start_point=None
##            , preload_content=True
##            ):



    return
##    Log(("getUrl url='{}'"
##         ", send_back_redirect='{}'"
##         ", return_response='{}'"
##         ", save_cookie='{}'"
##         ", stream='{}'"
##         ).format(
##        url
##        ,send_back_redirect
##        ,return_response
##        ,save_cookie
##        ,stream))

    global cookieJar
    response = None
    redirected_url = None

##    Log("clientHeader='{}'".format(clientHeader))
    getHtml_headers={}
    if client_header:
        for n,v in client_header:
            getHtml_headers[n]=v

    try:

        # I don't know how to use cookieJar with SOCKS proxy; fake it using headers
        socks_cookies = ''
        for cookie in cookieJar:
            this_domain = urlparse.urlparse(url).netloc
            if cookie.domain.endswith(this_domain):
                socks_cookies += "{}={};".format(cookie.name,cookie.value)
        if 'Cookie' in getHtml_headers:
            socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
        if not socks_cookies == '':
            getHtml_headers['Cookie'] = (socks_cookies).strip(';')
##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)

        response = None
        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            #s_proxy = SOCKSProxyManager(proxy_url=socks_string)  #Bases: urllib3.poolmanager.PoolManager, urllib3.request.RequestMethods
            if certPath: 
                s_proxy = SOCKSProxyManager(proxy_url=socks_string, ca_certs=certPath)
            else:
                s_proxy = SOCKSProxyManager(proxy_url=socks_string)
                
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.request.html
            socks_response = s_proxy.request(
                method
                ,url = url
                ,headers = getHtml_headers
                ,preload_content = not(stream)
                )
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if stream:
                data = None #must not read data now...it will be streamed
            else:
                data = socks_response.data

            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None

        elif (socks_proxy_info['uhp'] == 0) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3 import ProxyManager
            proxy_string = "http://{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp'])
            p_proxy = ProxyManager(proxy_url=proxy_string, ca_certs=certPath)  #Bases: urllib3.poolmanager.PoolManager, urllib3.request.RequestMethods
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.request.html
            socks_response = p_proxy.request(
                method
                ,url = url
                ,headers = getHtml_headers
                ,preload_content = not(stream)
                ,timeout=urllib3.Timeout(c.HTTP_TIMEOUT)
                )
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if stream:   data = None #must not read data now...it will be streamed
            else:        data = socks_response.data

            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None

        elif (socks_proxy_info['uhp'] < 0) :

            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.request.html
            socks_response = proxy.request(
                method
                ,url = url
                ,headers = getHtml_headers
                ,preload_content = not(stream)
                ,timeout=urllib3.Timeout(c.HTTP_TIMEOUT)
                )
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if stream:   data = None #must not read data now...it will be streamed
            else:        data = socks_response.data

            redirected_url = socks_response.geturl()
            #if (redirected_url is not None) and (not (url == redirected_url)):
            if (not (url == redirected_url)):                
                Log("url='{}'".format(url))
                Log("redirected_url='{}'".format(redirected_url))
            else:
                redirected_url = None
            
            
##        elif (socks_proxy_info['uhp'] < 0) :
##            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
##            else: proxies = {}
####            if DEBUG:
####                verify=False
####                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
####            else:
####                verify = certPath
##            #https://requests.readthedocs.io/en/master/api/#requests.Request
##            response = my_http_session.request(
##                method
##                , url=url
##                , headers=getHtml_headers
##                , stream=stream
####                , verify=verify
##                , proxies=proxies) 
##            #prepped = my_http_session.prepare_request(my_request)
##            #https://requests.readthedocs.io/en/master/api/#requests.Response
##            #response = my_http_session.send(prepped, verify=False, proxies=proxies) # https://requests.readthedocs.io/en/master/api/#requests.Response
##            if stream:   data = None #must not read data now...it will be streamed
##            else:        data = response.content
##            redirected_url = response.url 
##            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
##            else: redirected_url = None
            
        if save_cookie == True:
            this_domain = urlparse.urlparse(url).netloc
            if cookieJar is not None and response is not None:
##                if 'Set-Cookie' in response.headers:
##                    for cookie in SetCookie_To_Array_Of_Cookie(response.headers[ 'Set-Cookie' ]) :
##                        if cookie.domain.endswith(this_domain) and not cookie.discard:
##                            cookieJar.set_cookie(cookie)
                for cookie in response.cookies:
                    if not cookie.discard:
                        if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                            cookieJar.set_cookie(cookie)
                cookieJar.save(cookiePath, ignore_expires=True, ignore_discard=True)


            if cookieJar is not None and socks_response is not None:
                if 'Set-Cookie' in socks_response.headers:
                    for cookie in SetCookie_To_Array_Of_Cookie(socks_response.headers[ 'Set-Cookie' ]) :
                        #Log(repr(cookie))
                        if cookie.domain.endswith(this_domain) and not cookie.discard:
                            #Log(repr(cookie))
                            cookieJar.set_cookie(cookie)
##            Log(cookiePath)
##            cookieJar.save(cookiePath, ignore_expires=True, ignore_discard=True)

    except requests.exceptions.RequestException as e:
        if DEBUG:
            traceback.print_exc()
            Log(repr(getHtml_headers))
            Log(("getUrl url='{}'"
                 ", send_back_redirect='{}'"
                 ", return_response='{}'"
                 ", save_cookie='{}'"
                 ", stream='{}'"
                 ).format(
                url
                ,send_back_redirect
                ,return_response
                ,save_cookie
                ,stream) , xbmc.LOGNONE)
            Log( repr(e) , xbmc.LOGERROR)
        return None
    except:
        Log("It looks like '{}' is down.".format(url), xbmc.LOGERROR)
        raise

    if send_back_redirect == True:
        return data, redirected_url
    
    if return_response:
        if response:
            return response
        else:
            return socks_response

    return data

#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data 
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting

import sqlite3
import sys
import time
import traceback
import threading
import urllib
import urllib2
import urllib3
import urlparse
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import constants as C
import simplecache

#from resolveurl.plugins.lib import captcha_lib

from xbmc import LOGNONE

if sys.version_info >= (3, 0): from html.parser import HTMLParser
else: from HTMLParser import HTMLParser
html_parser = HTMLParser()

import requests
my_http_session = requests.Session()
from urllib3 import ProxyManager, PoolManager
pool_proxy = PoolManager()

##proxy_proxy = ProxyManager()

global_cache = simplecache.SimpleCache()

monitor = xbmc.Monitor()


#__________________________________________________________________________
#
def get_setting(setting_name, auto_convert=bool):
    raw_setting = C.this_addon.getSetting(setting_name)
    if auto_convert is bool:
        if raw_setting.lower() in ['true','false']:
            return (raw_setting.lower() == 'true')
        if raw_setting.lower() in ['none']:
            return None
        if raw_setting == '':
            return None
    if auto_convert is int:
##        Log(repr(("get_setting", setting_name,raw_setting)))
        if raw_setting == '':
            return 0
        else:
            return int(raw_setting)
    if auto_convert is float:
        #Log("float:"+repr(auto_convert is float), xbmc.LOGNONE)
        return float(raw_setting)
    if auto_convert is str:
        return str(raw_setting)
    splitted = repr(auto_convert).split("','")[0].split("'")[1]
#    Log(repr(setting_name), xbmc.LOGNONE)
#    Log("raw:"+splitted, xbmc.LOGNONE)
    return raw_setting
#__________________________________________________________________________
#
def set_setting(setting_name, setting_value):
    Log(repr(("set_setting", setting_name,setting_value)))
    C.this_addon.setSetting(id=setting_name, value=str(setting_value))
    
#__________________________________________________________________________
#
def playvid(
    video_url
    , name
    , download = None
    , description = u''
    , playmode_string = None
    , play_profile = None
    , download_filespec = None
    , mode = None #30
    , url_factory = None#''
    , icon_URI = None
    , repeat_when_available = False
    ):

    import socket
##    Log(repr(socket.getdefaulttimeout()))
    socket.setdefaulttimeout(60.0)
##    Log(repr(socket.getdefaulttimeout()))
    
##    assert isinstance(name, unicode)
##    assert isinstance(description, unicode)
##    Log(u"name={}".format(name.decode('utf-8')))
    try:
        xx = (u"unicode crash tester name={}".format(name))
        xx = (u"unicode crash tester description={}".format(description))
    except UnicodeDecodeError:
##        Log("UnicodeDecodeError")
        name =  name.decode('utf-8')
        description =  description.decode('utf-8')
    Log(u"video_url='{}', name='{}', download='{}', description='{}', playmode_string='{}', play_profile='{}'".format(
            video_url
            , name
            , download
            , description
            , playmode_string
            , play_profile
            )
        )

##    return
    if video_url is None:
        return
    
    if len(video_url) > 2000:
        Log("playvid not playing broken videourl".format(video_url[0:100]) )
        return

    if download == 1:
        import downloader
        downloader.downloadVideo(
            video_url
            , name
            , mode = mode
            , url_factory = url_factory
            , download_path = download_filespec
            , icon_URI = icon_URI
            , repeat_when_available = repeat_when_available
            )
        return

    #
    # play url as needed
    #
    
    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(
        label = name
        , path=video_url
##        , offscreen=True #kodi 18+
        )
    listitem.setArt( #setart because other method deprecated
            {
                "icon" : "DefaultVideo.png"
                , "thumb": iconimage
            }
        )
            
    listitem.setInfo(
        'video'
        , infoLabels={
            'title': name
            ,"plot": description
            ,"plotoutline": description
            }
        )
    listitem.setContentLookup(False)
    listitem.setMimeType('video/mp4')
    listitem.setProperty('IsPlayable', 'false') # true required if you want to track playcount
#    listitem.setProperty('IsPlayable', 'true')
    
    Log("video_url='{}'".format(video_url) )
    d_type = None
    TYPE_hls = 'hls'
    TYPE_mp4 = 'mp4'
    try:
        h=dict(urlparse.parse_qsl( str(video_url.split('|')[1])))
        resp = getHtml(url=str(video_url.split('|')[0]), headers=h, send_back_response=True, method="HEAD")
        if resp:
            if 'Content-Type' in resp.headers:
                c_type = resp.headers['Content-Type']
                if c_type in ['video/mp4', 'application/octet-stream']:
                    d_type = TYPE_mp4
                elif c_type in ['application/vnd.apple.mpegurl','application/x-mpegURL']:
                    d_type = TYPE_hls
                else:
                    raise Exception("Unknown content type '{}'".format(c_type))
    except:
        traceback.print_exc()
    Log(repr(d_type))
    if not video_url == '' and not '|' in video_url:
        video_url = video_url + Header2pipestring()
        Log("video_url='{}'".format(video_url) )

##    Log("playmode_string='{}'".format(repr(playmode_string))  )
##    Log("play_profile='{}'".format(play_profile)  )

    if str(playmode_string) in ['None',''] or str(playmode_string).isdigit():
        if (".m3u8" in str(video_url)):
            playmode_string = C.DEFAULT_PLAYMODE
        elif ("/hls/" in video_url) or ("hlsA/" in video_url):
            playmode_string = C.DEFAULT_PLAYMODE
        else:
            Log('direct')
            playmode_string = C.PLAYMODE_DIRECT
            
    Log("playmode_string='{}'".format(playmode_string)  )

    if playmode_string == C.PLAYMODE_DIRECT:
        Log("direct video_url")
        pass

    elif playmode_string == C.PLAYMODE_F4MPROXY:

        Log("play_profile='{}'".format(play_profile)  )
##        if play_profile is None or play_profile == '' or str(play_profile).isdigit()::
        if play_profile not in C.VALID_PLAYMODE_PROFILES:
            play_profile = C.DEFAULT_PROFILE_NAME

    
        Log("play_profile='{}'".format(play_profile)  )

        initial_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "initial"))* 1000 * 1000)
        maximum_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "maximum"))* 1000 * 1000)
        allow_upscale = C.addon.getSetting(play_profile + "_" + "allow_upscale")
        allow_downscale = C.addon.getSetting(play_profile + "_" + "allow_downscale")
        always_refresh_m3u8 = C.addon.getSetting(play_profile + "_" + "always_refresh_m3u8")
        downscale_threshhold = C.addon.getSetting(play_profile + "_" + "downscale_threshhold")
        upscale_threshhold = C.addon.getSetting(play_profile + "_" + "upscale_threshhold")
        upscale_penalty = C.addon.getSetting(play_profile + "_" + "upscale_penalty")
        pre_cache_size_max = int(float(C.addon.getSetting(play_profile + "_" + "pre_cache_size_max"))* 1000 * 1000)
        stream_type = C.addon.getSetting(play_profile + "_" + "stream_type").upper()

##        Log("stream_type='{}'".format(stream_type)  )

        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        if not stream_type:
            stream_type = 'HLSRETRY'
    ##        stream_type = 'HLSREDIR'
        Log("stream_type='{}'".format(stream_type)  )
   
        f4mp.playF4mLink(
            video_url
            , name
            , proxy = None
            , use_proxy_for_chunks = False
            , maxbitrate = maximum_bitrate
            , simpleDownloader = False
            , auth = None
            , streamtype = stream_type
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , iconImage = iconimage
            , initial_bitrate = initial_bitrate
            , allow_upscale = allow_upscale
            , allow_downscale = allow_downscale
            , always_refresh_m3u8 = always_refresh_m3u8
            , downscale_threshhold = downscale_threshhold
            , upscale_threshhold = upscale_threshhold
            , upscale_penalty = upscale_penalty
            , pre_cache_size_max = pre_cache_size_max
            , description = description
            )
        return
    
    elif playmode_string == C.PLAYMODE_INPUTSTREAM :
        listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        stream_headers = urllib.unquote_plus( video_url.split('|')[1])
##        video_url = urllib.unquote_plus( video_url.split('|')[0])
        Log("stream_headers='{}'".format(stream_headers)  )
        listitem.setProperty('inputstream.adaptive.stream_headers', stream_headers)
        Log("using inputstream")
    else:
        Log('Unknown playmode for link. Using direct')

    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( video_url, listitem)
    xbmc.Player().play(myPlayList)

##    xbmcplugin.setResolvedUrl(C.addon_handle, True, listitem)

#__________________________________________________________________________
# wrapper to allow cookie extraction from urllib3 proxy/socks requests
class FakeRequest(object):
    def __init__(self, full_url, headers):
        self.full_url = full_url
        self._headers = headers.copy()
    @property
    def headers(self):
        return self._headers
    @property
    def url(self):
        return self.full_url
    def get_full_url(self):
        return self.full_url
    def is_unverifiable(self, *args, **kargs):
        return True
    def get_origin_req_host(self, *args, **kargs):
        return self.full_url   
#__________________________________________________________________________
#
def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=10
            , sucuri_solved=False
            , method="GET"
            , send_back_response=False
            , auto_encode_content=False
##            , cookie_domain=None
            , size=8192*1000
            , start_point=None
            , preload_content=True
            ):

##    Log(repr(dir(pool_proxy)), xbmc.LOGNONE)
    Log(repr(('getHtml',url
                , referer
                , headers
                , save_cookie
                , sent_data
                , ignore404
                , ignore403
                , send_back_redirect
                , http_timeout
                , sucuri_solved
                , method
                , send_back_response
                , auto_encode_content
                , size
                , start_point
                , preload_content
              )))
##    return

##    Log(repr(xbmc.getIPAddress()),xbmc.LOGNONE)
    ip = xbmc.getIPAddress() #in case we don't have IP
    if not ip or ip.startswith('169.254'): # or ip.startswith('172.'):
        if send_back_redirect == True:
            return '', ''
        return ''


    cj = cookielib.LWPCookieJar(cookiePath)
    try:
        cj.load(ignore_discard=True, ignore_expires=True)
        cj._now = int(time.time()) #module does not set this if I use internal functions
    except:
        cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
        cj._now = int(time.time())
        pass
    stream=False
    response = None
    redirected_url = None



##    ##cookiedump
####    Log(C.cookiePath)
##    this_domain = urlparse.urlparse(url).netloc
####    Log(this_domain)
####    Log(repr(cj))
##    for cookie in cj:
####        Log(cookie.domain)
####        Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
##        if this_domain.endswith(cookie.domain):
##        #if cookie.domain.endswith(this_domain):
##            Log("filtered cookie={}".format(repr(cookie)), xbmc.LOGNONE)
####    return
                        
    try:
                
        if headers is None:
##            Log("copying default header dictionary")
            getHtml_headers = C.DEFAULT_HEADERS.copy()
            r_c_u_a = C.USER_AGENT #random.choice(C._USER_AGENTS)
    ##        Log("r_c_u_a={}".format(r_c_u_a), xbmc.LOGNONE)
            getHtml_headers['User-Agent'] = r_c_u_a
    ##        Log("rand choice getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
        else:
            getHtml_headers = headers #headers.copy()
##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
            
        if len(referer) > 1:
            getHtml_headers['Referer'] = referer

        if sent_data:
            getHtml_headers['Content-Length'] = str(len(sent_data))

        if start_point and int(start_point) > 0:
            getHtml_headers['Range'] = 'bytes={}-'.format(start_point)


        #
        # I don't know how to use cookieJar with SOCKS proxy
        #
        socks_cookies = ''
        this_domain = urlparse.urlparse(url).netloc
##        Log(this_domain)
        temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
##        Log("type temp_cookiejar='{}'".format(type(temp_cookiejar)))
##        Log("type cj='{}'".format(type(cj)))
        if cj:
            for cookie in cj:
##                Log("pre-request cookie='{}'".format(cookie))
                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                    socks_cookies += "{}={};".format(cookie.name,cookie.value)
                    temp_cookiejar.set_cookie(cookie)
    ##                    Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)
##            Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)

##            for cookie in temp_cookiejar: #verification during development 
##                Log("temp_cookiejar_cookie={}".format(repr(cookie)))
##                pass

            if 'Cookie' in getHtml_headers:
    ##            Log("getHtml_headers['Cookie']={}".format(getHtml_headers['Cookie']), xbmc.LOGNONE)
                socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
            if not socks_cookies == '':
                getHtml_headers['Cookie'] = (socks_cookies).strip(';')


    
##        Log("final getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
##        return "" #getHtml_headers testing/dev

        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
##            Log(socks_string )
            proxy = SOCKSProxyManager(proxy_url=socks_string)

##            Log(repr(proxy) )
            
            socks_response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content 
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if preload_content:
                data = socks_response.data
            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None



        elif (socks_proxy_info['uhp'] <= -0) :
            
            if socks_proxy_info['ps'] is not None:
                proxy_string = "http://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                proxy = ProxyManager(proxy_url=proxy_string)
            else:
                proxy_string = ''
                #proxy = PoolManager()
                proxy = pool_proxy

##            Log(repr(proxy) )

            response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content 
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
 
            #make urllib3.response more like requests.response by adding cookiejar and status
            temp_jar = cookielib.LWPCookieJar()
            fake_request = FakeRequest(url, response.getheaders() )
            requests.cookies.extract_cookies_to_jar(temp_jar, fake_request, response)
            response.cookies = temp_jar
            response.status_code = response.status
            
            if preload_content:
                data = response.data

##            Log(data[:500])
##            Log(repr(response.getheaders()))
##            Log(repr(response.geturl()))
##            Log(repr(response.url()))
##            Log(repr(response))            
            redirected_url = response.geturl()
            if not (url == redirected_url):
                if not ('http' in redirected_url):
                    if response.retries is not None and len(response.retries.history):
                        redir_domain = response.retries.history[-1].url
                        Log(repr(redir_domain))
                        redirected_url = redir_domain #+ redirected_url
                Log("redirected_url={}".format(repr(redirected_url)))
            else:
                redirected_url = None

            
            
            
        elif (socks_proxy_info['uhp'] <= 0) :

            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
            else: proxies = {}
##            Log("proxies='{}'".format(repr(proxies)))

##            #either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
##            if C.DEBUG:
##                verify=False
##                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
##            else:
##                verify = C.certPath
            verify = C.certPath

            #https://requests.readthedocs.io/en/master/api/#requests.Request
            response = my_http_session.request(
                method
                , url=url
                , headers=getHtml_headers
                , data = sent_data
                , stream=stream
                , allow_redirects=True
                , proxies=proxies
                , cookies=temp_cookiejar
                , verify=verify      
                )

##            Log(repr(type(response)))
##            Log(repr(response.headers))
##            Log(repr(dir(response)))
##            Log(repr(response.headers['Set-Cookie']))
            
            if response.status_code == 429:
                response.raise_for_status()

##            if response.headers['Content-Encoding'] == 'gzip':
##                import gzip, StringIO
##                buf = StringIO.StringIO( e.read())
##                f = gzip.GzipFile(fileobj=buf)
##                data = f.read()
##                f.close()
##            else:
            data = response.content

##            Log(data[:1000])
            
            redirected_url = response.url 
            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
            else: redirected_url = None


        if auto_encode_content: 
            if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
                content_type = response.headers['Content-Type']
                if 'charset=' in content_type:
                    ct = content_type.split('charset=')[1]
##                    Log('decoding as {}'.format(repr(ct)))
                    data = data.decode(ct)
                    


            
        if sucuri_solved == False:
            if 'Server' in response.headers:
                if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                    Log(repr(response.status_code))
                    import sucuri
                    if sucuri.SCRIPT_HEADER in data:
                        cookie = sucuri.Set_Cookie(data)
                        cj.set_cookie(cookie)
                        cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
    ##                            raise
                        return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)



##            if response:
##                #Log("response='{}'".format(repr(response.info())), xbmc.LOGNONE)
##                if 'Server' in response.headers:
##                    if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
##                        Log(repr(response.status_code))
##                        import sucuri
##                        if sucuri.SCRIPT_HEADER in data:
##                            cookie = sucuri.Set_Cookie(data)
##                            cj.set_cookie(cookie)
##                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
####                            raise
##                            return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)
##            elif socks_response:
##                if 'Server' in socks_response.headers:
##                    if socks_response.status in (200,301)  and socks_response.headers[ 'Server' ] == "Sucuri/Cloudproxy":
##                        import sucuri
##                        if sucuri.SCRIPT_HEADER in data:
##                            cookie = sucuri.Set_Cookie(data)
##                            cj.set_cookie(cookie)
##                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
####                            raise
##                            return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)

##        Log("data='{}'".format(data))


        if not (save_cookie == False) and (cj is not None) :
            r = response
            this_domain = urlparse.urlparse(url).netloc
##            if isinstance(socks_response, urllib3.response.HTTPResponse):
##                r = socks_response
##            else:
##                r = response
##            if isinstance(socks_response, urllib3.response.HTTPResponse):
##                #r = socks_response
####                Log("socks_response['Set-Cookie']={}".format(repr(socks_response.headers)))
##                r = requests.Response()
####f_request = FakeRequest("https://www.porntrex.com/latest-updates/11/")
####f_response = FakeResponse( {'Set-Cookie': 'PHPSESSID=9fe8ec45a9022580c047a96a3522036c; path=/; domain=.porntrex.com; SameSite=Lax
##                #, kt_ips=76.10.152.152; expires=Fri, 12-Mar-2021 17:22:45 GMT; Max-Age=86400; path=/; domain=.porntrex.com; SameSite=Lax', 'Expires': 'Thu, 19 Nov 1981 08:52:00 GMT'
##                #, 'Vary': 'Accept-Encoding', 'Server': 'openresty', 'Connection': 'keep-alive', 'Pragma': 'no-cache', 'Cache-Control': 'no-store, no-cache, must-revalidate', 'Date': 'Thu, 11 Mar 2021 17:22:45 GMT', 'Access-Control-Allow-Origin': '*', 'Content-Type': 'text/html; charset=utf-8'} )
####Log(repr(f_request))
####Log(repr(dir(f_request)))
####Log(repr(f_request.is_unverifiable()))
####t_cj = cookielib.LWPCookieJar()
####t_cj.extract_cookies(f_response,f_request)
####Log("t_cj={}".format(repr(t_cj)))
##                f_request = FakeRequest(url)
##                f_response = FakeResponse(socks_response.headers.copy())
##                t_cj = cookielib.LWPCookieJar()
##                t_cj.extract_cookies(f_response,f_request)
##                r.cookies = t_cj
####                Log(repr(r.cookies))                
####                r.headers = socks_response.headers.copy()
####                raise Exception('cookie processing TBD once I have a socks proxy to test with')
##            else:
##                r = response
            if r is not None:
                for cookie in r.cookies:
                    Log("r.cookie={}".format(repr(cookie)))
                    if save_cookie == True: #save as this domain even if cookie is not marked so
                         cookie.domain = this_domain
                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
##                        Log("saving cookie={}".format(repr(cookie)))
                        cj.set_cookie(cookie)
##                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
##                        Log("saving cookie={} because of cookie_domain param".format(repr(cookie)))
##                        cookie.domain = cookie_domain
##                        cj.set_cookie(cookie)
                        
                cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

##                    ### it turns out that using r.headers[ 'Set-Cookie' ] will join
##                    ###     multiple set-cookie headers using a comma, instead of ','
##                    ###   which means we loose information if I try and use some other libraries
##                    ### For now, just skip this - once I have a socks proxy to test with I can
##                    ###    try something else....
##                        
####                Log(repr(r.cookies))
####                Log(repr(r.headers))
####                for a in r.headers[ 'Set-Cookie' ]:
####                    Log(a)
##                if 'Set-Cookie' in r.headers:
##                    fake_response = FakeResponse(r.headers)
####                    Log("1fake_response={}".format(repr(fake_response)))
####                    Log("2fake_response={}".format(repr(fake_response.info())))
####                    Log("3fake_response={}".format(repr(fake_response.info().getheaders("Set-Cookie2") )))
##                    Log("4fake_response={}".format(repr(fake_response.info().getheaders("Set-Cookie") )))
##                    fake_request = FakeRequest(url)
####                    Log("1fake_request={}".format(repr(fake_request.get_full_url())))
##                    for cookie in cj.make_cookies(fake_response, fake_request):
##                        Log("fake cookie={}".format(repr(cookie)))
##                    Log('done')
##
##                    sc = [r.headers[ 'Set-Cookie' ]]
##                    Log("sc={}".format(sc))
##                    
##                    n_c_t = cj._normalized_cookie_tuples(cookielib.parse_ns_headers(sc))
##                    for tup in n_c_t:
##                        Log("tup={}".format(repr(tup)))
##                        #because i am passing request=None later; I need to makes sure that domain is part of the tupple
####                        Log("tup[2]={}".format(repr(tup[2])))
##                        if 'domain' not in tup[2]: tup[2]['domain']=this_domain
####                        Log("tup[2]={}".format(repr(tup[2])))
##                        cookie = cj._cookie_from_cookie_tuple(tup, None)
####                        Log("cookie={}".format(repr(cookie)))
##                        try:
##                            if not cookie.discard:
##                                if save_cookie == True: #save as this domain event if cookie is not marked so
##                                     cookie.domain = this_domain
##                                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
##                                    cj.set_cookie(cookie)
##                        except:
##                            traceback.print_exc()
####                            Log("sc={}".format(repr(sc)))
####                            Log("tup={}".format(repr(tup)))
####                            Log("tup[2]={}".format(repr(tup[2])))
####                            Log("cookie={}".format(repr(cookie)))
##                            raise
##                            
####                    #todo: use cookielib.make_cookies - with fake request/response if necessary
####                    for cookie in SetCookie_To_Array_Of_Cookie(r.headers[ 'Set-Cookie' ]) :
####                        Log("cookie={}".format(repr(cookie)))
####                        if not cookie.discard:
####                            if save_cookie == True: #save as this domain event if cookie is not marked so
####                                 cookie.domain = this_domain
####                            if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
####                                cj.set_cookie(cookie)
##
##                    cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
####                    Log("saving cookiejar")
####            for cookie in cj:
######                if cookie.domain.endswith(this_domain):
####                Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
####            Log("reloading cookiejar")
####            cj = None
####            cj = cookielib.LWPCookieJar(C.cookiePath)
####            cj.load(ignore_discard=True, ignore_expires=True)
####            for cookie in cj:
######                if cookie.domain.endswith(this_domain):
####                Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)                


    except requests.HTTPError as e:
        Log("repr(e)='{}'".format(repr(e)))
##        Log("dir(e)='{}'".format(dir(e)))
##        Log("dir(e.response)='{}'".format(dir(e.response)))
##        Log("e.errno='{}'".format(e.errno))
##        Log("e.response.content='{}'".format(e.response.content))
##        Log("repr(e.response)='{}'".format(repr(e.response)))
##        if e.response.status_code == 429 and 'ccapimg' in e.response.content:
##            keyname = re.search('key=([^"]+)"', e.response.content).group(1)
##            from resolveurl.plugins.lib import captcha_lib
##            img_url = referer + '/ccapimg?key=' + keyname
####            Log("img_url='{}'".format(img_url))
##            img = captcha_lib.write_img(img_url)
##            solution = captcha_lib.get_response(img, y=225)
##            form_data = {'secimgkey': (None, keyname), 'secimginp': (None, solution)}
##            hdr = getHtml_headers
##            if 'Referer' in hdr:
##                del hdr['Referer']
##            hdr['referer'] = url
##            try:
##                resp = requests.post(url, files=form_data, headers=hdr)
##                resp.encoding = 'ISO-8859-1'
##                result = resp.text
##            finally:
##                if resp: resp.close()
##            return result

        raise
        
    except urllib2.HTTPError as e:
        Log(repr(e.info().get('Content-Encoding')))
        
        if e.info().get('Content-Encoding') == 'gzip':
            import StringIO
            buf = StringIO.StringIO( e.read())
            import gzip
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = e.read()
        #Log(data)  #errors='ignore'
        #notify('Oh oh',data)
        if e.code == 503 and 'cf-browser-verification' in data:
            import cloudflare
            data = cloudflare.solve(url, cj, USER_AGENT)
            
        elif e.code == 404 and ignore404 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        elif e.code == 403 and ignore403 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data
            
        else:
            traceback.print_exc()
            raise urllib2.HTTPError()

    except Exception as e:
        traceback.print_exc()
        if 'SSL23_GET_SERVER_HELLO' in str(e):
            notify('Oh oh','Python version too old - update to Krypton or FTMC')
            raise urllib2.HTTPError()
        else:
            Log("It looks like '{}' is down.".format(url), xbmc.LOGERROR)
            #Notify(msg="It looks like '{}' is down.".format(url), duration=200)
            raise
        return None


    if send_back_response == True:
        return response

    if send_back_redirect == True:
        return data, redirected_url
    
    if response:
        response.close()

    return data
    
#__________________________________________________________________________
#
def postHtml(post_url, sent_data=None, headers=None, compression=True, NoCookie=True):
    #form_data = urllib.urlencode(form_data)
    data = getHtml(url=post_url, headers=headers, save_cookie=(not NoCookie), sent_data=sent_data, method="POST" )
##    Log(data)
    return data

#__________________________________________________________________________
#
def headHtml(head_url, sent_data=None, headers=None, compression=True, NoCookie=True, send_back_redirect=False):
    #form_data = urllib.urlencode(form_data)
    return getHtml(url=head_url, send_back_redirect=send_back_redirect, headers=headers, save_cookie=(not NoCookie), method="HEAD" )


###__________________________________________________________________________
###
##def getHtml2(url):
##    req = Request(url)
##    response = urllib2.urlopen(req, timeout=60)
##    data = response.read()
##    response.close()
##    return data
###__________________________________________________________________________
###
##def getVideoLink(url, referer, hdr=None, data=None):
##    if not hdr:
##        req2 = Request(url, data, DEFAULT_HEADERS)
##    else:
##        req2 = Request(url, data, hdr)
##    if len(referer) > 1:
##        req2.add_header('Referer', referer)
##    url2 = urllib2.urlopen(req2).geturl()
##    return url2
#__________________________________________________________________________
#
def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q
#__________________________________________________________________________
#
cp1252 = {
    # from http://www.microsoft.com/typography/unicode/1252.htm
    u"\u20AC": u"\x80", # EURO SIGN
    u"\u201A": u"\x82", # SINGLE LOW-9 QUOTATION MARK
    u"\u0192": u"\x83", # LATIN SMALL LETTER F WITH HOOK
    u"\u201E": u"\x84", # DOUBLE LOW-9 QUOTATION MARK
    u"\u2026": u"\x85", # HORIZONTAL ELLIPSIS
    u"\u2020": u"\x86", # DAGGER
    u"\u2021": u"\x87", # DOUBLE DAGGER
    u"\u02C6": u"\x88", # MODIFIER LETTER CIRCUMFLEX ACCENT
    u"\u2030": u"\x89", # PER MILLE SIGN
    u"\u0160": u"\x8A", # LATIN CAPITAL LETTER S WITH CARON
    u"\u2039": u"\x8B", # SINGLE LEFT-POINTING ANGLE QUOTATION MARK
    u"\u0152": u"\x8C", # LATIN CAPITAL LIGATURE OE
    u"\u017D": u"\x8E", # LATIN CAPITAL LETTER Z WITH CARON
    u"\u2018": u"\x91", # LEFT SINGLE QUOTATION MARK
    u"\u2019": u"\x92", # RIGHT SINGLE QUOTATION MARK
##    u"\u2019": "\u2019".encode('utf8'), # RIGHT SINGLE QUOTATION MARK
    u"\u201C": u"\x93", # LEFT DOUBLE QUOTATION MARK
    u"\u201D": u"\x94", # RIGHT DOUBLE QUOTATION MARK
    u"\u2022": u"\x95", # BULLET
    u"\u2013": u"\x96", # EN DASH
    u"\u2014": u"\x97", # EM DASH
    u"\u02DC": u"\x98", # SMALL TILDE
    u"\u2122": u"\x99", # TRADE MARK SIGN
    u"\u0161": u"\x9A", # LATIN SMALL LETTER S WITH CARON
    u"\u203A": u"\x9B", # SINGLE RIGHT-POINTING ANGLE QUOTATION MARK
    u"\u0153": u"\x9C", # LATIN SMALL LIGATURE OE
    u"\u017E": u"\x9E", # LATIN SMALL LETTER Z WITH CARON
    u"\u0178": u"\x9F", # LATIN CAPITAL LETTER Y WITH DIAERESIS
}
from htmlentitydefs import name2codepoint
def htmlentitydecode(s):
    return re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: unichr(name2codepoint[m.group(1)]), s)
def cleantext(text):
    #return a unicode string, replacing html special codes with unicode characters

    text = text.replace('\t','')
    text = text.replace('\n','')
    text = text.strip()
    
    #Log(repr(text) + "   org(text)")
    if not isinstance(text, unicode):
        text = text.decode('utf8')

##    text = text.replace(u'\u200b','')
##    from unidecode import unidecode
##    return unidecode(text)
    
##    text = text.decode('ascii', 'xmlcharrefreplace')

    for src, dest in cp1252.items():
        text = text.replace(dest, src )
    

    text = htmlentitydecode(text)
    #Log(repr(text) + "   entity(text)")
##    import unicodedata
##    text = unicodedata.normalize('NFKD',text)
    text = html_parser.unescape(text)
    #Log(repr(text) + "   html(text)")
    
    #to make things easier on future functions that only support
    #   ascii strings, make sure that a cleaned string is encoded as
    #   utf8. This strings should be decoded before being made visible
    #   to user
##    for src, dest in cp1252.items():
##        text = text.replace(src, dest)
##    Log(repr(text) + "   cp1252(text)")
####    text = text.encode('latin1')
####    Log(repr(text) + "   latin(text)")
##    text = text.decode('unicode_escape')
##    Log(repr(text) + "   unicode(text)")
    
##    text = text.decode('utf8')
##    Log(repr(text) + "   utf8(text)")

##    text = text.replace(u"\u2018", u"'").replace(u"\u2019", u"'")
##    Log(repr(text) + "   replace(text)")

    #returned text should be pure unicode
    #no futher encoding should be necessary
    

##
##    text = text.replace('&excl;','!')
##    text = text.replace('&comma;',',')
##    text = text.replace('&lowbar;','_')
##    text = text.replace('&period;','.')
##    text = text.replace('&lpar;','[')
##    text = text.replace('&rpar;',']')

    return text

    #Log(text,xbmc.LOGNONE)
    #text = html_parser.unescape(text.encode('ascii', 'ignore'))
    text = htmlentitydecode(text)
    text = text.replace('&#8211;','-')
    text = text.replace('&ndash;','-')
    
    
    
    text = text.replace('&amp;','&')
    text = text.replace('&#038;','&')
    text = text.replace('&#8217;','\'')
    text = text.replace('&#8216;','\'')
    text = text.replace('&#8230;','...')
    text = text.replace('&quot;','"')
    text = text.replace('&excl;','!')
    text = text.replace('&apos;','\'')
    text = text.replace('&#039;','`')
    text = text.replace(u'ñ','n')


    #Log(text,xbmc.LOGNONE)
    #xbmc.log(  u'ñ'.encode("utf-8").decode("utf-8") , xbmc.LOGNONE)
    #text = text.encode("utf-8").replace('&ntilde;','\xf1').decode("utf-8")
    text = text.replace('&rsquo;','\'')
    text = text.encode('ascii', 'ignore').strip()


    return text


#__________________________________________________________________________
#
def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext

#__________________________________________________________________________
#
def Set_ListItem_Duration(listitem, duration):
    duration=str(duration).lower().strip()
    duration_seconds = 0

    # test cases:
    # 
##    Log(duration, xbmc.LOGNONE)
    
    #somethimes will have a dot
    if '.' in duration:
        duration = duration.split('.')[1]
        
    #sometimes format will be hh:mm:ss: normalize it to what I want
    timearr= ['s','m','h']
    if ':' in duration:
        duration_arr = duration.split(':')
        duration = ""
        i = 0
        for duration_elem in reversed(duration_arr):
            duration = duration_elem + timearr[i] + duration
            i = i+1

    duration = duration.replace(' h', 'h ').replace('h', 'h ').replace('min', 'm ').replace(' m', 'm ').replace('m', 'm ').replace(' s', 's ').replace('s', 's ').strip()

    #sometimes format will be Xh Ym Zs
    try:
        duration_arr = duration.split(' ')
        for duration_elem in duration_arr:
            duration_elem = duration_elem.strip()
            if 'h' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('h',''))*3600
            elif 'm' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('m',''))*60
            elif 's' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('s',''))
            elif duration_elem:
                try:
                    duration_seconds = duration_seconds + int(duration_elem)
                except:
                    pass
    except:
        Log(repr(duration_arr))
        raise

    listitem.setInfo(type="Video", infoLabels={"duration": duration_seconds} )
#__________________________________________________________________________
#
def addDownLink(name, url, mode
                , iconimage=''
                , desc=''
                , stream=None
                , fav='add'
                , noDownload=False
                , duration=None
                , date=None
                , views=None
                , likes=None
                , play_method=None
                , hq_stream=None
                , return_listitem=False
                , icon_url=''
                ):

    if fav == 'add': favtext = "Add to"
    elif fav == 'del': favtext = "Remove from"
    if not date: date = 0
    if not hq_stream: hq_stream = ''
    else:  hq_stream = str(hq_stream)


##    Log(repr(("{}".format(sys.argv[0]), name, url, mode, iconimage
##                , desc
##                , stream
##                , fav
##                , noDownload
##                , duration
##                , date
##                , views
##                , likes
##                , play_method
##                , hq_stream
##                , return_listitem)))
##    assert isinstance(name, unicode)
##    Log(u"&name={}".format(name)) 
##    Log(u"&name={}".format(urllib.quote_plus(name.encode('utf8'))))
##    Log(u"&hq_stream={}".format(urllib.quote_plus(hq_stream)) )
##    Log(u"&img={}".format(urllib.quote_plus(iconimage.encode('utf8')) ))
##    Log(u"&desc={}".format(urllib.quote_plus(desc.encode('utf8'))) )
##    Log(u"&desc={}".format(desc))
##    Log(u"&desc={}".format(urllib.quote_plus(desc)))
##    Log(u"&playmode_string={}".format(play_method))

    if isinstance(url, unicode):
        url = url.encode('utf8')        
    if isinstance(name, unicode):
        name = name.encode('utf8')        
    if isinstance(desc, unicode):
        desc = desc.encode('utf8')        
    if isinstance(iconimage, unicode):
        iconimage = iconimage.encode('utf8')        
        
    u = (
        "{}".format(sys.argv[0])
        + "?url={}".format(urllib.quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(urllib.quote_plus(iconimage) ) 
        + "&name={}".format(urllib.quote_plus(name))
        )
    
    u = (
        "{}".format(sys.argv[0])
        + "?url={}".format(urllib.quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(urllib.quote_plus(iconimage) ) 
        + "&name={}".format(urllib.quote_plus(name))
        + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + "&desc={}".format(urllib.quote_plus(desc)) 
        + "&playmode_string={}".format(play_method)
        )
    download_xbmc_url = (
        "{}".format(sys.argv[0]) 
        + "?url={}".format(urllib.quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(urllib.quote_plus(iconimage) ) 
        + "&name={}".format(urllib.quote_plus(name))
        + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + "&playmode_string={}".format(play_method) 
        + "&download=1"
        )
    favorite = (
        "{}".format(sys.argv[0]) 
        + "?url={}".format(urllib.quote_plus(url)) 
        + "&mode={}".format(C.FAVORITES_MODE) 
        + "&img={}".format(urllib.quote_plus(iconimage) ) 
        + "&name={}".format(urllib.quote_plus(name))
        + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + "&fav={}".format(fav) 
        + "&favmode={}".format(mode)
        + "&desc={}".format(urllib.quote_plus(desc))
        + "&icon_url={}".format(urllib.quote_plus(icon_url))
        )
    play_with_method = (
        "{}".format(sys.argv[0])
        + "?url={}".format(urllib.quote_plus(url))
        + "&mode={}".format(mode)
        + "&img={}".format(urllib.quote_plus(iconimage) )
        #+ "&name={}".format(urllib.quote_plus(name.encode('utf8')))
        + "&name={}".format(urllib.quote_plus(name))
        + "&hq_stream={}".format(urllib.quote_plus(hq_stream))
        + "&playmode_string={}"
        + "&play_profile={}"
        )

    
    if len(iconimage) < 1:
        iconimage = C.uwcicon
    if not '|' in iconimage and 'http' in iconimage:
        iconimage = "{}{}".format(iconimage, Header2pipestring())
    #Log("iconimage={}".format(iconimage))

    liz = xbmcgui.ListItem(name) #, thumbnailImage=iconimage, iconImage="DefaultVideo.png")
    liz.setArt(
        { 'thumb': iconimage
##          , 'icon': iconimage
          , 'fanart': iconimage
##          , 'poster': iconimage
          }
        ) #must include thumb to avoid error messages
##    fanart = os.path.join(rootDir, 'fanart.jpg')
##    if C.addon.getSetting('posterfanart') == 'true':
##        fanart = iconimage
##        liz.setArt({'poster': iconimage})
##    liz.setArt({'fanart': fanart})

    if duration:  
        Set_ListItem_Duration(liz, duration) #2021-01 k17.6 setting duration seems to cause page to be reloaded after play stops 

    liz.setMimeType('video/mp4')
    liz.setContentLookup(False)           
    #  can't set this and use playlists at same time
    #  if false, then 'mark as watched' will not work
    liz.setProperty('IsPlayable', 'false') 
    
    
    if stream:
        #Log("iconimageasdasdf={}".format(iconimage))
        liz.setProperty('IsPlayable', 'true') #can't set this and use playlists at same time

    if len(desc) < 1:  desc = ''
    liz.setInfo(
        type="Video"
        , infoLabels={
            "title": name
            ,"plot": desc
            ,"plotoutline": desc
            }
        )

##    liz.addStreamInfo('video', {'codec': 'h264'})

    contextMenuItems = []

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        
        contextMenuItems.append(
            (
            "[COLOR {}]{} favorites[/COLOR]".format(C.time_text_color, favtext)
            , "xbmc.RunPlugin({})".format(favorite)
            )
        )
        if fav == 'del':
            favorite = (
                "{}".format(sys.argv[0]) 
                + "?url={}".format(urllib.quote_plus(url)) 
                + "&mode={}".format(C.FAVORITES_MODE) 
                + "&img={}".format(urllib.quote_plus(iconimage) ) 
                + "&name={}".format(urllib.quote_plus(name)) 
                + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
                + "&fav={}".format('refresh') 
                + "&favmode={}".format(mode)
                + "&desc={}".format(urllib.quote_plus(desc)) 
                + "&icon_url={}".format(urllib.quote_plus(icon_url))
                )
            contextMenuItems.append(
                (
                "[COLOR {}]{} favorite icon[/COLOR]".format(C.time_text_color, 'Refresh')
                , "xbmc.RunPlugin({})".format(favorite)
                )
            )
            favorite = (
                "{}".format(sys.argv[0]) 
                + "?url={}".format(urllib.quote_plus(url)) 
                + "&mode={}".format(C.FAVORITES_MODE) 
                + "&img={}".format(urllib.quote_plus(iconimage) ) 
                + "&name={}".format(urllib.quote_plus(name)) 
                + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
                + "&fav={}".format('rebuild') 
                + "&favmode={}".format(mode)
                + "&desc={}".format(urllib.quote_plus(desc)) 
                + "&icon_url={}".format(urllib.quote_plus(icon_url))
                )
            contextMenuItems.append(
                (
                "[COLOR {}]{} favorite icon[/COLOR]".format(C.time_text_color, 'Rebuild Icon From Cache')
                , "xbmc.RunPlugin({})".format(favorite)
                )
            )

    #Log("play_method={}".format(play_method))

    max_rez = (C.addon.getSetting("max_rez").lower())
    if not max_rez: max_rez = ('480','720','1080')
    else: max_rez = max_rez.split(',')

    if play_method in {C.PLAYMODE_VARIABLE, None} :
        for rez in max_rez:
            contextMenuItems.append(
                (
                "[COLOR {}]{} {}[/COLOR]".format(C.time_text_color, 'Play Max',rez)
                , "xbmc.RunPlugin({})".format(play_with_method.format(rez, 0))
                )
            )
        
    if play_method in {C.PLAYMODE_INPUTSTREAM, C.PLAYMODE_F4MPROXY, C.PLAYMODE_DIRECT, '', None} :

        contextMenuItems.append(
            (
            "[COLOR {}]{} Direct[/COLOR]".format(C.time_text_color, 'Play')
            , "xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_DIRECT, 0))
            )
        )
        contextMenuItems.append(
            (
            "[COLOR {}]{} Inputstream[/COLOR]".format(C.time_text_color, 'Play')
            , "xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_INPUTSTREAM, 0))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_01_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_01"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_02_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_02"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_03_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_03"))
            )
        )
        
    if noDownload == False:
        contextMenuItems.append(
            (
                "[COLOR {}]Download[/COLOR]".format(C.time_text_color)
                ,"xbmc.RunPlugin({})".format(download_xbmc_url)
            )
        )

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
    else:
        liz.addContextMenuItems([], replaceItems=True)

##    global add_count
##    add_count +=1
##    Log(repr(add_count))
    
    #Log("u='{}'".format(u))
    if return_listitem:
        return(u, liz, False)
    else:
        xbmcplugin.addDirectoryItem(handle=C.addon_handle, url=u, listitem=liz, isFolder=False)
#__________________________________________________________________________
#
def addDir(name, url, mode
           , iconimage=None
           , page=None
           , channel=None
           , section=None
           , keyword=''
           , Folder=True
           , duration=None
           , title=None
           , end_directory=True
           , contextMenu=None
           , contextMenuReplace=True
           , return_listitem=False
           , return_url=False):

    if page is None: page='1'
    u = (sys.argv[0] +
     "?url=" + urllib.quote_plus(str(url)) +
     "&1mode=" + str(mode) +
     "&mode=" + str(mode) +
     "&page=" + str(page) +
     "&channel=" + str(channel) +
     "&section=" + str(section) +
     "&keyword=" + urllib.quote_plus(str(keyword)) +
     "&end_directory=" + str(end_directory) +
     "&name=" + urllib.quote_plus(str(name.encode('utf8'))))

    #Log("u={}".format(u))
    if return_url:
        return u


    if not(iconimage) or (len(iconimage) < 1): iconimage = C.uwcicon

    if not '|' in iconimage and 'http' in iconimage:
        iconimage = u"{}{}".format(iconimage, Header2pipestring())

    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)

    liz.setProperty('IsPlayable', 'false')

##    liz.setArt({'thumb': iconimage, 'icon': iconimage})
##    fanart = os.path.join(C.rootDir, 'fanart.jpg')
##
##    if C.addon.getSetting('posterfanart') == 'true':
##        fanart = iconimage
##        liz.setArt({'poster': iconimage})
##
##    liz.setArt({'fanart': fanart})

    liz.setArt(
        { 'thumb': iconimage
          , 'icon': iconimage
          , 'fanart': iconimage
          , 'poster': iconimage
          }) #must include thumb to avoid error messages

    if duration:
        Set_ListItem_Duration(liz, duration)

    #setting type = music instead of video means no icon to the right of the label
    #liz.setInfo(type="music", infoLabels={"Title": name})

    if title:
        liz.setInfo(type="Video", infoLabels={"Title": title})

    contextMenuItems = []
    if len(keyword) >= 1 and not("next page" in name.lower()):
        keyw = (sys.argv[0] +
            "?mode=" + C.DELETE_KEYWORD +
            "&keyword=" + urllib.quote_plus(keyword))
        #if not contextMenuItems: contextMenuItems = []
        contextMenuItems.append(
                (
                    "[COLOR {}]Remove keyword[/COLOR]".format(C.time_text_color)
                    , "xbmc.RunPlugin({})".format(keyw)
                )
            )

    if section and section == C.INBAND_RECURSE:
        #below will not work well because the 'back' button will return to root of addon, and not where I want     
        u2 = u.replace("&keyword=" + urllib.quote_plus(str(keyword)), "&keyword=" + C.INBAND_RECURSE)
        u2 = u2.replace("&page=" + str(page), "&page=" + str(int(page)-1)) #include the page we are on
        u2 = u2.replace("&page=" + str(page), "&page=1")  #include the page we are on
        contextMenuItems.append( (
            "[COLOR {}]Recurse to Page {}[/COLOR]".format(C.search_text_color, C.MAX_RECURSE_DEPTH)
            , "xbmc.ActivateWindow(Videos,{})".format(u2)  )  )
        contextMenuReplace=False

#####below does not work well because the 'back' button will return to root of addon, and not where I want
##    if add_recursive_search_submenu == True:
##        u2 = (sys.argv[0] +
##         "?url=" +
##         "&mode=" + str(mode) +
##         "&page=-1"
##         "&keyword=" + urllib.quote_plus(str(keyword)) +
##         "&end_directory=False" )
##        #Log("u2={}".format(u2))
##        if not contextMenuItems: contextMenuItems = []
####        contextMenuItems.append( (
####            "[COLOR {}]Recursive Search[/COLOR]".format(search_text_color)
####            , "xbmc.RunPlugin({})".format(u2)  )  )
##        contextMenuItems.append( (
##            "[COLOR {}]Recursive Search[/COLOR]".format(search_text_color)
##            , "ReplaceWindow(Videos," + u2 + ")"  )  )
##            #'XBMC.RunPlugin('+ Pluginurl+')') 
##            #"ActivateWindow(Videos," + u2 + ")"
##            #ReplaceWindow

    if contextMenu:
        contextMenuItems = contextMenu
        
    if contextMenuItems:
##        Log(repr(contextMenuReplace), xbmc.LOGNONE)
        liz.addContextMenuItems(contextMenuItems, replaceItems=contextMenuReplace)

##    global add_count
##    add_count +=1
##    Log(repr(add_count))

    if return_url:
        return u
    elif return_listitem:
        return(u, liz, Folder)
    else:
        xbmcplugin.addDirectoryItem(handle=C.addon_handle, url=u, listitem=liz, isFolder=Folder)
#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
#__________________________________________________________________________
#
def searchDir(url, mode, page='1', end_directory=True):

    label = "{}[COLOR {}]Quick Search[/COLOR]".format(
        C.SPACING_FOR_TOPMOST
        ,C.search_text_color
        ) 
    addDir(
        name=label
        ,url=url 
        ,mode=C.QWIK_SEARCH 
        ,iconimage=C.search_icon 
        ,page=page
        ,channel=mode
        ,end_directory=end_directory)

    addDir(
        "{}[COLOR {}]Add Keyword[/COLOR]".format(C.SPACING_FOR_NEXT,C.search_text_color)
        , url=''
        , mode=C.ADD_KEYWORD
        , iconimage=C.search_icon
        , channel=mode)

    addDir(
        "{}[COLOR {}]Clear list[/COLOR]".format(C.SPACING_FOR_NEXT,C.search_text_color)
        , url=''
        , mode=C.CLEAR_SEARCH
        , iconimage=C.search_icon)

    conn = sqlite3.connect(C.favoritesdb)
    db_cursor = conn.cursor()
    try:
        db_cursor.execute("SELECT * FROM keywords")
        for (keyword,) in db_cursor.fetchall():
            label = "{}[COLOR {}]{}[/COLOR]".format(
                C.SPACING_FOR_NAMES
                , C.time_text_color
                , urllib.unquote_plus(keyword)
                )
            addDir(
                name=label
                , url=url 
                , mode=mode
                , iconimage=C.search_icon 
                , page=page
                , keyword=keyword
                , end_directory=end_directory
                )
    except:
        traceback.print_exc()
        pass

    endOfDirectory()
###__________________________________________________________________________
###
##@C.url_dispatcher.register(C.ADD_KEYWORD, ['channel'])
##def NewSearchKeyword(channel):
##    Log("NewSearchKeyword channel='{}'".format( channel))
##    vq = _get_keyboard(heading="Searching for...")
##    if (not vq):
##        return False, 0
##    keyword = urllib.quote_plus(vq)
##    AddKeyword(keyword)
##    Quick_Search(url='', channel=channel, end_directory=True, page='1', keyword=keyword)
##    #xbmc.executebuiltin('Container.Refresh')
##    endOfDirectory()
##
###__________________________________________________________________________
###
##@C.url_dispatcher.register(C.CLEAR_SEARCH)
##def clearSearch():
##    delallKeyword()
##    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
##def AddKeyword(keyword):
##    Log("AddKeyword keyword='{}'".format(keyword))
##    conn = sqlite3.connect(C.favoritesdb)
##    db_cursor = conn.cursor()
##    db_cursor.execute("INSERT INTO keywords VALUES (?)", (keyword,))
##    conn.commit()
##    conn.close()
###__________________________________________________________________________
###
##def delallKeyword():
##    yes = dialog.yesno('Warning','This will clear all the keywords', 'Continue?', nolabel='No', yeslabel='Yes')
##    if yes:
##        conn = sqlite3.connect(C.favoritesdb)
##        db_cursor = conn.cursor()
##        db_cursor.execute("DELETE FROM keywords;")
##        conn.commit()
##        conn.close()
###__________________________________________________________________________
###
##@C.url_dispatcher.register(C.DELETE_KEYWORD, ['keyword'])
##def delKeyword(keyword):
##    Log('keyword: ' + keyword)
##    conn = sqlite3.connect(C.favoritesdb)
##    db_cursor = conn.cursor()
##    db_cursor.execute("DELETE FROM keywords WHERE keyword = '%s'" % keyword)
##    conn.commit()
##    conn.close()
##    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
##def Get_Sites(filter_category=None):
##    import importlib
##    libDir = os.path.join(C.resDir, 'lib')
##    sitesDir = os.path.join(libDir, 'sites')
##    files = []
##    for r, d, f in os.walk(sitesDir): # r=root, d=directories, f = files
##        for file in f:
##            if file.endswith('.py') and not file.startswith('_') :
##                f2 = file[:-len('.py')]
##                files.append(f2)
##    site_list = {}
##    for f in files:
##        if not f in site_list:
####            Log("added f='{}'".format(f))
##            site_list[f] = ''
##
##    import operator
##    sorted_site_list = sorted(site_list.items(), key=operator.itemgetter(0))
##    import collections
##    sorted_dict = collections.OrderedDict(sorted_site_list)
##
##    aa = None
##    for sitename in sorted_dict:
##        if aa is None:
##            try:
##                module = importlib.import_module('resources.lib.sites.'+sitename)
##                if hasattr(module, "website"):
##                    module = module.website
####                    Log("detected subclass of 'website'")
####                    Log("module.LIST_AREA='{}'".format(module.LIST_AREA))
####                    Log("dir(module.LIST_AREA)='{}'".format(dir(module.LIST_AREA)))
####                    Log("repr(module.LIST_AREA)='{}'".format(repr(module.LIST_AREA)))
##                if filter_category:
##                    if module.LIST_AREA == filter_category:
####                        Log(repr(os.path.join(C.imgDir, sitename + '.png')),C.LOGNONE)
##                        yield (
##                            module.FRIENDLY_NAME
##                            ,module.ROOT_URL
##                            ,module.MAIN_MODE
##                            ,os.path.join(C.imgDir, sitename + '.png')
##                            )
##                else:
####                    Log("sitename='{}'".format(sitename),C.LOGNONE)
##                    aa = (yield (sitename, module))
##                    if aa is not None:
##                        break
####            except GeneratorExit:
####                pass
##            except:
##                Log('failed Get_Sites for {}'.format(sitename), xbmc.LOGWARNING)
##                traceback.print_exc()
###__________________________________________________________________
###
##import Queue
##import threading
##
##
##def crawl(q, all_method_results):
####            Log("repr(q)='{}'".format(repr(q)))
##    while not q.empty():
##        work = q.get(timeout=C.WEBCRAWLER_THREAD_TIMEOUT)
####        Log("repr(work)='{}'".format(repr(work)))
##        index_for_result = work[0]
##        method_to_call = work[1]
##        keyword_arguments_for_method_to_call = work[2]
####        Log("Thread {} start".format(index_for_result), LOGNONE)
##        t_start = time.clock()
##        try:
##            single_method_result = method_to_call(**keyword_arguments_for_method_to_call)
##        except Exception as ex:
##            single_method_result = repr(ex)
##        all_method_results[index_for_result] = single_method_result
##        t_end = time.clock()
##        q.task_done()
####        Log("The time spent in thread {} is {}".format(index_for_result, t_end - t_start), LOGNONE)
##        
##    return True
###__________________________________________________________________________
###
##@C.url_dispatcher.register(C.QWIK_SEARCH, ['url', 'channel'], ['end_directory','page','keyword'])
##def Quick_Search(url, channel, end_directory=True, page='1', keyword=None):
##    Log("Quick_Search url='{}', channel='{}', end_directory='{}', page='{}', keyword='{}'".format( url, channel, end_directory, page, keyword))
##
##    if not keyword:
##        ##get the search string from user; remember it; pre-populate remembered
##        prev_search_string = C.this_addon.getSetting(id='quick_search_string')
##        quick_search_string = _get_keyboard(
##            heading="Search query"
##            ,default=prev_search_string
##            )
##        if  quick_search_string == '' :
##            return False, 0  ## if blank or the user cancelled the keyboard, return
##        C.this_addon.setSetting(id='quick_search_string', value=quick_search_string)
##    else:
##        quick_search_string = keyword
##
##
##    progress_dialog = None
##    progress_dialog = Progress_Dialog(C.addon_name,"searching '{}'".format(quick_search_string))
##
##    try:
##            
##        if C.ROOT_SEARCH_ALL == str(channel):
##            end_directory = False #this sub will set the directory
##
##        get_sites = Get_Sites()
##        q = Queue.Queue()
##        i = 0
##        all_method_results = {}
##        try: 
##            for sitename, module in get_sites:
##                if module.SEARCH_MODE == str(channel) or C.ROOT_SEARCH_ALL == str(channel):
##                    #i = i + 1 #testing
##                    if i > 10: break #testing
##                    all_method_results[sitename] = None
##                    method_to_call = getattr(module, 'Search')
##                    kwargs = {
##                        "searchUrl": module.SEARCH_URL
##                        ,"keyword": quick_search_string
##                        ,"end_directory": end_directory
##                        ,"page": page
##                        ,"progress_dialog": progress_dialog
##                        }
##                    q.put( (sitename,method_to_call,kwargs) )
##                
##            for k in range(5): #C.MAX_WEBCRAWLER_THREADS):
##                worker = threading.Thread(target=crawl, args=(q,all_method_results))
##                worker.daemon = True
##                worker.start()
##            q.join()
##            get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
##        except StopIteration:
##            pass
##        except:
##            traceback.print_exc()
##            
##        for result in all_method_results:
##            if not(all_method_results[result] in [None, True]):
##                addDownLink(
##                    name=C.STANDARD_MESSAGE_FAILED_SEARCH.format(result, all_method_results[result])
##                    ,url=C.DO_NOTHING_URL
##                    ,mode=C.ROOT_INDEX_INDEX
##                    )
##    finally:
##        if progress_dialog: progress_dialog.close()
##
##    Log("Quick_Search ended")
##    endOfDirectory()
###__________________________________________________________________________
###
##@C.url_dispatcher.register(C.ROOT_SEARCH_ALL, ['page'], ['keyword']  )
##def Search_All(page=1, keyword=None):
##
##    if not keyword:
##        searchDir(url=C.DO_NOTHING_URL, mode=C.ROOT_SEARCH_ALL)
##        return
##    
##    #temporarilty force only  X   recurse depth for this feature
##    C.DEFAULT_RECURSE_DEPTH = 1
##    C.MAX_RECURSE_DEPTH = 1
##
##    Quick_Search(url=C.DO_NOTHING_URL,channel=C.ROOT_SEARCH_ALL,keyword=keyword)
##
##    endOfDirectory()
###__________________________________________________________________________
###
##def textBox(heading,announce):
##    class TextBox():
##        WINDOW=10147
##        CONTROL_LABEL=1
##        CONTROL_TEXTBOX=5
##        def __init__(self,*args,**kwargs):
##            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
##            self.win=xbmcgui.Window(self.WINDOW)
##            xbmc.sleep(500)
##            self.setControls()
##        def setControls(self):
##            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
##            try: f=open(announce); text=f.read()
##            except: text=announce
##            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
##            return
##    TextBox()
##    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
##        Sleep(500)

###__________________________________________________________________________
###
##def Log(msg='', loglevel=None):
####    assert isinstance(msg, unicode)
##    if not isinstance(msg, unicode):
##        msg = unicode(msg.decode('utf-8', 'ignore'))
##    try: 
##        msg = "{}:{} {}".format(
##            os.path.basename(traceback.extract_stack(limit=2)[0][0])
##            ,traceback.extract_stack(limit=2)[0][1]
##            ,msg
##            )
##    except:
##        pass
##    msg = "{}: {}".format(C.addon_id, msg.encode('utf-8',errors='ignore') )
##    if  loglevel: xbmc.log(msg , loglevel)
##    elif C.DEBUG:  xbmc.log(msg , xbmc.LOGNONE)
##    else:    xbmc.log(msg)
#####__________________________________________________________________________
###
##def Notify(header=None, msg='', duration=4000, sound=False):
##    if msg == '':
##        msg = header
##        header = ''
##    notify(header, msg, duration, sound)
##def notify(header=None, msg='', duration=C.DEFAULT_NOTIFY_TIME, sound=False):
##    debug = (C.this_addon.getSetting('debug').lower() == "true")
##    if threading.current_thread().name == "MainThread":
##        Log( msg, xbmc.LOGNOTICE)
##        if header==None or header == '':
##            if len(msg) > 30:
##                header = msg[0:30]
##                msg = msg[-30:]
##            else:
##                header=msg
##        xbmcgui.Dialog().notification(header, msg, C.uwcicon, duration, sound=False )
##    elif debug:
##        Log( msg, xbmc.LOGNOTICE)
##
###__________________________________________________________________________
###
##def Header2pipestring(header = C.DEFAULT_HEADERS):
##    q = "|{}".format( urllib.urlencode(header)  )
##    return q

###__________________________________________________________________________
###
##def add_sort_method():
##    sort_order = int(C.addon.getSetting('video_sort_by'))
####    Log(repr(sort_order))
##    if sort_order == 2:
##        sort_order = xbmcplugin.SORT_METHOD_DURATION
####    elif sort_order == :
####        sort_order = xbmcplugin.SORT_METHOD_DATE
##    elif sort_order == 1:
##        sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
##    elif sort_order == 4:
##        sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
##    elif sort_order == 5:
##        sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
##    else:
##        sort_order = xbmcplugin.SORT_METHOD_UNSORTED
##    
##    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=sort_order) #use preferred method first
##    #xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
##    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
###    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
##    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
##    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_DURATION)
###__________________________________________________________________________
###
##@C.url_dispatcher.register(C.CONFIGURE_THIS_ADDON)
##def configure_THIS_addon():
##    import xbmcaddon
##    xbmcaddon.Addon(id=C.addon_id).openSettings()
###__________________________________________________________________________
###
##@C.url_dispatcher.register(C.CONFIGURE_INPUTSTREAM)
##def configure_addon():
##    import xbmcaddon
##    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________________
#
def endOfDirectory(cacheToDisc=True, end_directory=True, allow_sorting=True, inband_recurse=False, updateListing=False):
##    if end_directory is True:  traceback.print_stack()

    if not ( (end_directory == True) or inband_recurse ):
        return
    if allow_sorting == True:
        add_sort_method()
    if int(sys.argv[1]) > 0:
        C.addon_handle = int(sys.argv[1])
        xbmcplugin.endOfDirectory(C.addon_handle, cacheToDisc=cacheToDisc, updateListing=updateListing)
##        traceback.print_stack()
###__________________________________________________________________________
###
##def SortVideos(sources
##               , download
##               , vid_res_column=1
##               , substitute_char='}'
##               , substitute_res='720'
##               , max_video_resolution = C.maximum_video_resolution
##               ):
##
##    Log("SortVideos sources='{}', download='{}', vid_res_column='{}', max_video_resolution='{}'".format(repr(sources), download, vid_res_column, max_video_resolution))
####    global maximum_video_resolution
##    if max_video_resolution:
##        maximum_video_resolution = max_video_resolution
##    else:
##        maximum_video_resolution = C.maximum_video_resolution
####    Log(str(maximum_video_resolution))
##
##    try: 
##        #sometimes we can't get accurate resolutions and end up with a characters instead...
##        # e.g. "http://video.mp4","}"     instead of   "http://video.mp4","480p"
##
####        Log("sources='{}', download='{}'".format(sources,download))
##
##        if (bool(download) == True):
##            maximum_video_resolution = 99999 # allow max resolution on download
####        Log("maximum_video_resolution='{}'".format(maximum_video_resolution))
##
##        s3840p_string = "3840p"
##        s2160p_string = "2160p"
##        s1440p_string = "1440p"
##        s1080p_string = "1080p"
##        s720p_string = "720p"
##        s540p_string = "540p"
##        s480p_string = "480p"
##        s320p_string = "320p"
##
##        #report on what was the maximum resolution available; just for fun
##        try:
##            videos = sorted(sources
##                            , key=lambda tup: int(
##                                                     tup[vid_res_column].lower() \
##                                                     .replace('p60','p') \
##                                                     .replace('720',s720p_string) \
##                                                     .replace(substitute_char   ,substitute_res)\
##                                                     .replace('720' ,'721')\
##                                                     .replace('320' ,'321')\
##                                                     .replace('2160',s2160p_string)\
##                                                     .replace('7p'  ,s2160p_string)\
##                                                     .replace('3840',s3840p_string)\
##                                                     .replace('20p' ,s3840p_string)\
##                                                     .replace('1440',s1440p_string)\
##                                                     .replace('2k',  s1440p_string)\
##                                                     .replace('4k'  ,s3840p_string)\
##                                                     .replace('1080',s1080p_string)\
##                                                     .replace('540' ,s540p_string )\
##                                                     .replace('480' ,s480p_string )\
##                                                     .replace('320' ,s320p_string )\
##                                                     .replace('p','')\
##                                                     .replace('(','')\
##                                                     .replace(')','')\
##                                                     .replace('hd','')\
##                                                     .replace('@60fs','')
##                                                     )
##                            , reverse=True)
####            Log(repr(videos))
##
##            if len(videos) > 1:
##                if vid_res_column == 1:
##                    max_avail_res = videos[0][1]
##                else:
##                    max_avail_res = videos[0][0]
##            else:
##                max_avail_res = 'unknown'
##        except:
##            traceback.print_exc()
##            max_avail_res = 'unknown'
##            pass
##        Log("Best quality for this item is {}".format(max_avail_res))
####        Log("Worst quality for this item is {}".format(videos[-1][vid_res_column]  ))
##
##        #change these subst strings so that they can't be matched when max resolution is less
##        if maximum_video_resolution < 3840:
##            s3840p_string = "40p" 
##        if maximum_video_resolution < 2160:
##            s2160p_string = "60p"
##        if maximum_video_resolution < 1440:
##            s1440p_string = "14p"
##        if maximum_video_resolution < 1080:
##            s1080p_string = "14p"
##        if maximum_video_resolution < 720:
##            s720p_string = "14p"
##        if maximum_video_resolution < 540:
##            s540p_string = "13p"
##        if maximum_video_resolution < 480:
##            s480p_string = "12p"
##
##    ##     the list of videos is a bunch of urls such as xxx\360.mp4
##    ##        i use a lambda(just for fun) to split out the numeric resolution and the reverse sort it;
##    ##        the best resolution should end up on top
##    ##        the 720 is replaced with 721 so that the number ending 20 does not match other possible strings the site may use to define ultra resolutions
##    ##        the letter p is removed so that we can convert to integer and avoid the 720 is better 1080 situation if it were chars
##    ##        the higher resolutions, when we have been told not to use them, are replaced with lower numbered strings 
##
##        try:
##            videos = sorted(sources, key=lambda tup: int(
##                                                     tup[vid_res_column].lower() \
##                                                     .replace('p60','p') \
##                                                     .replace('720',s720p_string) \
##                                                     .replace(substitute_char   ,substitute_res)\
##                                                     .replace('720' ,'721')\
##                                                     .replace('320' ,'321')\
##                                                     .replace('2160',s2160p_string)\
##                                                     .replace('7p'  ,s2160p_string)\
##                                                     .replace('3840',s3840p_string)\
##                                                     .replace('20p' ,s3840p_string)\
##                                                     .replace('1440',s1440p_string)\
##                                                     .replace('2k',  s1440p_string)\
##                                                     .replace('4k'  ,s3840p_string)\
##                                                     .replace('1080',s1080p_string)\
##                                                     .replace('540' ,s540p_string )\
##                                                     .replace('480' ,s480p_string )\
##                                                     .replace('320' ,s320p_string )\
##                                                     .replace('p','')\
##                                                     .replace('(','')\
##                                                     .replace(')','')\
##                                                     .replace('hd','')\
##                                                     .replace('@60fs','')
##                                                     )
##                            , reverse=True)
##        except:
##            videos = None
##            traceback.print_exc()
##
##        Log("videos='{}'".format(videos))
##        if len(videos) < 1:
##            return None
##        if vid_res_column == 1:
##            video_url = videos[0][0]
##        else:
##            video_url = videos[0][1]
##        Log("video_url='{}'".format(video_url))
##        return video_url
##    except:
##         traceback.print_exc()
##         return None

###__________________________________________________________________________
###
##@C.url_dispatcher.register(C.ROOT_TEST_ALL)
##def TEST_ALL(quick_search_string=None):
##
##    #one of the tests is searching via keyword...get a keyword
####    quick_search_string = 'sex'
##    if not quick_search_string:
##        prev_search_string = C.addon.getSetting(id='quick_search_string')
##        quick_search_string = _get_keyboard( heading="Search query", default=prev_search_string  )
##        if  quick_search_string == '' :
##            return False, 0  ## if blank or the user cancelled the keyboard, return
##        C.addon.setSetting(id='quick_search_string', value=quick_search_string)
##
##    progress_dialog = Progress_Dialog(C.addon_name,u"Testing all sites using '{}' as search term".format(quick_search_string))
##
##    try:
##        
##        #generate list of potential test sites by listing dir
##        get_sites = Get_Sites()
##        #add sites to settings.xml [so that we can track which site has been tested today]
##        test_list = C.addon.getSetting(id=C.TESTING_LIST_NAME)
####        test_list = "" #dev test only  ... force all tests regarless if they were run today
##        if test_list == "": test_list = json.loads("{}")
##        else: test_list = json.loads(test_list)
##        for sitename, module in get_sites:
##    ##        Log("sitename='{}'".format(repr(sitename)))
##            if not (sitename in test_list):
##                test_list[sitename] = ''
##        C.addon.setSetting(id=C.TESTING_LIST_NAME, value=json.dumps(test_list))
##
##        
##        #temporarilty force only  X   recurse depth for this feature
##        C.DEFAULT_RECURSE_DEPTH = 1
##        C.MAX_RECURSE_DEPTH = 2
##
##        #perform tests [if not passed test today]
##        today = datetime.datetime.now().strftime("%Y-%m-%d")
##        q = Queue.Queue()
##        i = 0 #dev test only
##        all_method_results = {}
##        try:
##            get_sites = Get_Sites() #refresh this variable
##            for sitename, module in get_sites:
##                all_method_results[sitename] = None #assume success
##                last_success_date = test_list[sitename]
##                if last_success_date < today: #we should test today
##                    i = i + 1 #dev test only
##                    method_to_call = getattr(module, 'Test')
##                    kwargs = {"keyword": quick_search_string, "end_directory": False}
##                    q.put( (sitename,method_to_call,kwargs) )
##                else:
##                    Log("'{}' passed '{}'".format(sitename, last_success_date))
####                if i > 15: break #dev test only
##                     
##            for k in range(C.MAX_WEBCRAWLER_THREADS):
##                worker = threading.Thread(target=crawl, args=(q,all_method_results))
##                worker.daemon = False
##                worker.start()
##            q.join()
##
####            get_sites.send(False) #testing #cancel yield operations; will raise StopIteration inside get_sites
##
##        except StopIteration:
##            pass
##        except:
##            traceback.print_exc()
##
##        #analyze test results and save them
##        something_failed = False
##        for sitename in all_method_results:
##            if not(all_method_results[sitename] in [None, True]): #None or True are the success codes
##                something_failed = True
##                try:
##                    Log(repr( sitename ) )
##                    Log(repr( all_method_results[sitename] ) )
##                    n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(sitename, sitename)
##                    try:
##                        n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(sitename, all_method_results[sitename].decode("utf8", "ignore"))
##                    except:
##                        import unicodedata
##                        n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(
##                            sitename
##                            , unicodedata.normalize('NFKD', all_method_results[sitename]).encode("utf8", "ignore")
##                            )
##
##                except:
##                    traceback.print_exc()
##                addDownLink(
##                    name=n
##                    ,url=C.DO_NOTHING_URL
##                    ,mode=C.NO_ACTION_MODE
##                    )
##            else:
##                test_list[sitename] = today
##        C.addon.setSetting(id=C.TESTING_LIST_NAME, value=json.dumps(test_list))
##        
##        #visual indicator of success
##        if not something_failed:
##            addDownLink(
##                    name="[COLOR {}]all tests passed on {}[/COLOR]".format(C.test_passed_text_color,today)
##                    ,url=C.DO_NOTHING_URL
##                    ,mode=C.NO_ACTION_MODE
##                    )
##
##        
##    finally:
##        if progress_dialog: progress_dialog.close()
##
####    Log(repr(add_count))
##    Log("TEST_ALL ended")
##    endOfDirectory()
#__________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=10):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval
###__________________________________________________________________
###
##def get_set(genset,n):
##    nd = genset.getElementsByTagName(n)
####    Log(repr(nd))
##    nd = nd[0]
##    #Log("get_set='{}'".format(nd))
##    if nd.lastChild is None:
##        #Log("  {}='{}'".format(n,nd.lastChild))
##        return nd.lastChild
##    else:
##        #Log("  {}='{}'".format(n,nd.lastChild.data))
##        return nd.lastChild.data
#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    from xml.dom import minidom
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None

    def Get_Setting_Val(setting):
        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"' +
                                  setting + '"},"id":1}')
        return json.loads(val)['result']['value']
        
    
    try:
        #reading file method
##        guisettings_xml = minidom.parse(xbmc.translatePath('special://home/userdata/guisettings.xml'))
##        usehttpproxy = get_gui_setting(guisettings_xml, 'usehttpproxy')
##        if usehttpproxy and usehttpproxy.lower()=='true':
##            httpproxytype = get_gui_setting(guisettings_xml, 'httpproxytype')
##            httpproxyserver = get_gui_setting(guisettings_xml, 'httpproxyserver')
##            httpproxyport = get_gui_setting(guisettings_xml, 'httpproxyport')
##            httpproxyusername = get_gui_setting(guisettings_xml, 'httpproxyusername')
##            httpproxypassword = get_gui_setting(guisettings_xml, 'httpproxypassword')

##        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"' +
##                                  'network.usehttpproxy' + '"},"id":1}')
        usehttpproxy = Get_Setting_Val('network.usehttpproxy')
        if usehttpproxy and str(usehttpproxy).lower()=='true':
            httpproxytype = Get_Setting_Val('network.httpproxytype') #= get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = Get_Setting_Val('network.httpproxyserver') #= get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = Get_Setting_Val('network.httpproxyport') #= get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = Get_Setting_Val('network.httpproxyusername') #= get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = Get_Setting_Val('network.httpproxypassword') #= get_gui_setting(guisettings_xml, 'httpproxypassword')

    except:
        traceback.print_exc()
##        raise
##        pass
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
##        Log(repr(proxy_info))
        return proxy_info
    
###__________________________________________________________________
###
##def Socks_Proxy_Active():
##    from xml.dom import minidom
##    usehttpproxy = False
##    httpproxytype = -1
##    httpproxyserver = None
##    httpproxyport = 0
##    httpproxyusername = None
##    httpproxypassword = None
##    try:
##        guisettings_xml = minidom.parse(xbmc.translatePath('special://home/userdata/guisettings.xml'))
##        usehttpproxy = get_gui_setting(guisettings_xml, 'usehttpproxy')
##        if usehttpproxy and usehttpproxy.lower()=='true':
##            httpproxytype = get_gui_setting(guisettings_xml, 'httpproxytype')
##            httpproxyserver = get_gui_setting(guisettings_xml, 'httpproxyserver')
##            httpproxyport = get_gui_setting(guisettings_xml, 'httpproxyport')
##            httpproxyusername = get_gui_setting(guisettings_xml, 'httpproxyusername')
##            httpproxypassword = get_gui_setting(guisettings_xml, 'httpproxypassword')
##    except:
##        traceback.print_exc()
####        raise
####        pass
##    finally:
##        proxy_info = {
##             'uhp' : int(httpproxytype)
##            , 'ps' : httpproxyserver
##            , 'pp' : int(httpproxyport)
##            , 'un' : httpproxyusername
##            , 'up' : httpproxypassword
##            }
####        Log(repr(proxy_info))
##        return proxy_info
    
###__________________________________________________________________
###
def SetCookie_To_Array_Of_Cookie(set_cookie_string):
##    Log("set_cookie_string='{}'".format(set_cookie_string))
    cookies_array = []
    #regex = "(?is)(\s?expires=\w\w\w,\s\d\d-\w\w\w-\d{2,4}\s\d{1,2}:\d\d:\d\d(?:\s?\w{3})?;?)"
    regex = "(\s?expires=(.{27,29})(?:;|,)?)"
    regex = "(\s?expires=([^;]+);)"
    
    set_cookie_string_no_expires = re.sub(regex,'',set_cookie_string, flags=re.IGNORECASE)
##    Log("set_cookie_string_no_expires='{}'".format(set_cookie_string_no_expires))
##    return cookies_array
    #https://docs.python.org/2/library/cookielib.html#cookielib.Cookie.is_expired
    for cook in set_cookie_string_no_expires.split(', '):
        if cook == '': break #in case blank cookie
##        Log("cook='{}'".format(repr(cook)))
        morsels = None
        name=None
        value=None
        port=None
        port_specified=False
        domain=''
        domain_specified=False
        domain_initial_dot=False
        path=''
        path_specified=False
        max_age=None
        expire_date=None
        comment=None
        comment_url=None
        discard=False #True if this is a session cookie
        secure=True #True if cookie should only be returned over a secure connection
        for morsel in cook.split('; '):
##            morsel=morsel.rstrip(';') #in case a cookie has only name/value
##            Log("morsel='{}'".format(repr(morsel)))

            if not '=' in morsel:
                ##single word value
                pass ##I am ignoring these ones
            
            else:
                #morsels = morsel.split("=")
                morsels=[morsel[0: morsel.find("=")] , morsel[morsel.find("=")+len("="): (max(morsel.find(";"), len(morsel)))      ] ]
##                Log(str(morsel.find("=")+len("=")))
##                Log(str(morsel.find(";")))
##                Log(str(max(morsel.find(";"), len(morsel))))
                #Log("morsels='{}'".format(repr(morsels)))
                if morsels[0].lower() == 'path':
                    path=morsels[1]
                    path_specified=True
                elif morsels[0].lower() == 'max-age':
                    max_age=morsels[1] #essentially same info as expires; written as seconds(from now, presumably)which means cookie is only good for current session
##                    Log("morsel='{}'".format(repr(morsel)))
##                    Log("morsels[1]='{}'".format(morsels[1]))
##                    Log("max_age='{}'".format(max_age))
                    max_age=int(max_age)
                elif morsels[0].lower() == 'domain':
                    domain=morsels[1]
                    domain_specified=True
                    if domain[0]=='.': domain_initial_dot = True
                elif morsels[0].lower() == 'port':
                    port=morsels[1]
                    port_specified=True
                elif morsels[0].lower() == 'comment':
                    comment=morsels[1]
                elif morsels[0].lower() == 'samesite':
                    pass
                elif morsels[0].lower() == 'comment_url':
                    comment_url=morsels[1]
                else:
                    name=morsels[0]
                    value=morsels[1]
                    regex = "{}={};.*?expires=([^;]+)".format(re.escape(name),re.escape(value))
##                    Log(regex) 
                    try:
                        expire_date_arr= re.compile(regex, re.DOTALL | re.IGNORECASE).findall(set_cookie_string)
                        if len(expire_date_arr)<1:
                            #discard=True
                            Log("Cant find exipre date for regex='{}'".format(regex))
##                            Log("morsel='{}'".format(morsel))
##                            Log("name='{}'".format(name))
##                            Log("value='{}'".format(value))
##                            Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                            Log("cook='{}'".format(cook))
##                            Log("set_cookie_string='{}'".format(set_cookie_string))
##                            Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))

                        else:
                            expire_date = expire_date_arr[0]
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("(type(datetime.datetime.now())='{}'".format(type(datetime.datetime.now())))
##                            Log("{}".format(datetime.datetime(1970,1,1).strftime("%a, %d %b %Y %H:%M:%S %Z")))
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("expire_date='{}'".format(expire_date))

                            expire_formats = {"%a, %d-%b-%Y %H:%M:%S %Z"
                                              , "%a, %d-%b-%y %H:%M:%S %Z"
                                              , "%a, %d %b %Y %H:%M:%S %Z"
                                              , "%a, %d %b %y %H:%M:%S %Z" }
                            for expire_format in expire_formats:
                                try:
                                    expire_date = datetime.datetime.strptime(expire_date, expire_format)
##                                    Log("morsel='{}'".format(morsel))
##                                    Log("Match on {}".format(expire_format)) 
                                    expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
##                                    Log("expire_date='{}' type={}".format(expire_date,type(expire_date)))  
                                    break
                                except TypeError:
##                                    Log("TypeError") 
                                    try:
                                        expire_date = datetime.datetime(*(time.strptime(expire_date, expire_format)[0:6]))
##                                      Log("Match on {} with bugfix ".format(expire_format)) 
                                        expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
                                        break
                                    except:
                                        traceback.print_exc()
                                        pass
                                    
                                except:
                                    traceback.print_exc()
                                    pass
                                
##                                Log("(type(expire_date)='{}'".format(type(expire_date)))
##                                if type(expire_date) == "<type 'datetime.datetime'>":

##                            Log("final (type(expire_date)='{}'".format(type(expire_date)))
##                            Log("final expire_date='{}'".format(expire_date))
                            if not (type(expire_date) == type(0)):
                                Log("Failed to convert expire_date='{}' using format '{}'".format(expire_date,expire_format))  
##                                Log("expire_date='{}'".format(expire_date))  
##                                Log("morsel='{}'".format(repr(morsel)))
##                                Log("name='{}'".format(repr(name)))
##                                Log("value='{}'".format(repr(value)))
##                                Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                                Log("cook='{}'".format(cook))
##                                Log("set_cookie_string='{}'".format(set_cookie_string))
##                                Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                                expire_date = 0
                                

                    except:
                        traceback.print_exc()
                        Log("Error parsing expire value for cookie")
                        Log("name='{}'".format(repr(name)))
                        Log("value='{}'".format(repr(value)))
                        Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
                        Log("cook='{}'".format(cook))
                        Log("set_cookie_string='{}'".format(set_cookie_string))
                        Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                        if expire_date: #might have been set by maxage
                            expire_date = 0
                        pass
                    
        if max_age:
            expire_date = max_age
        
        ck = cookielib.Cookie(version=0,
                      name=name,
                      value=value,
                      port=port,
                      port_specified=port_specified,
                      domain=domain,
                      domain_specified=domain_specified,
                      domain_initial_dot=domain_initial_dot,
                      path=path,
                      path_specified=path_specified,
                      secure=secure,
                      expires=expire_date,
                      discard=discard,
                      comment=comment,
                      comment_url=comment_url,
                      rest={},
                      rfc2109=False)
##        Log("cook='{}'".format(repr(cook)))
##        Log("ck='{}'".format(repr(ck)))
        cookies_array.append(ck)

    return cookies_array

###__________________________________________________________________
###
def parse_m3u_tag(line):
    if ':' not in line:
        return line, []
    tag, attribstr = line.split(':', 1)
    attribs = []
    last = 0
    quote = False
    for i,c in enumerate(attribstr+','):
        if c == '"':
            quote = not quote
        if quote:
            continue
        if c == ',':
            attribs.append(attribstr[last:i])
            last = i+1
    return tag, attribs

###__________________________________________________________________
###
def parse_kv(attribs, known_keys=None):
    d = {}
    for item in attribs:
        k, v = item.split('=', 1)
        k=k.strip()
        v=v.strip().strip('"')
        if known_keys is not None and k not in known_keys:
            raise ValueError("unknown attribute %s"%k)
        d[k] = v
    return d
###__________________________________________________________________
###
def Choose_M3U8_Stream(url, url_contents, maxbitrate, dumpfile, vod):

##    Log("Choose_M3U8_Stream(url='{}' url_contents='{}' maxbitrate='{:,}')".format(url, url_contents, maxbitrate))

    #vod files don't allow us to pick a rate
    if vod == True:
        Log("vod file detected")
        return url, maxbitrate, maxbitrate, maxbitrate        

    maxbitrate = int(maxbitrate)
    variants = []
    variant = None
##    Log(url_contents)
    for line in url_contents.split('\n'): #.iter_lines()
        #we expect some meta-data in a first line; followed by the url in the second
        if line.startswith('#EXT'):
            tag, attribs = parse_m3u_tag(line)
            if tag == '#EXT-X-STREAM-INF':
                #we only want bitrate column
##                Log(repr(dir(attribs)))
                #attribs2 = parse_kv(attribs, ('METHOD', 'URI', 'IV'))
                #Log(repr(attribs2))
                attribs2 = parse_kv(attribs)
##                Log(repr(attribs2))
##                Log(repr(attribs))
                if 'RESOLUTION' in attribs2:
                    variant = (( 'BANDWIDTH='+attribs2['BANDWIDTH'],'RESOLUTION='+attribs2['RESOLUTION']))
                else:
                    variant = (( 'BANDWIDTH='+attribs2['BANDWIDTH'],'RESOLUTION=None'))
        elif variant:
            variants.append((line, variant))
            variant = None
##    Log("variants:{}".format(repr(variants)))
    #make sure _highest_ bitrate is first e.g. [('chunklist_w383802091_b448000_t64RlBTOjMwLjA=.m3u8' , ['BANDWIDTH=488000', 'NAME="FPS:30.0"', 'CODECS="avc1.42c015,mp4a.40.2"', 'RESOLUTION=426x240']), ('chunklist_w383802091_b1148000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=1258000', 'NAME="FPS:30.0"', 'CODECS="avc1.4d401f,mp4a.40.2"', 'RESOLUTION=854x480']), ('chunklist_w383802091_b3096000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=3396000', 'NAME="FPS:30.0"', 'CODECS="avc1.4d401f,mp4a.40.2"', 'RESOLUTION=1280x720']), ('chunklist_w383802091_b5128000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=5628000', 'NAME="FPS:30.0"', 'CODECS="avc1.640028,mp4a.40.2"', 'RESOLUTION=1920x1080'])]
    # [0] is a url; [1][0] is the 'BANDWIDTH=xxx' value
    # [1] is a list of data for the url
    # bandwidth this the first element of the second list
    s_variants = sorted(variants, key=lambda bit_rate: int(
                                                        bit_rate[1][0].lower()
                                                        .split("',")[0]
                                                        .split("=")[1]
                                                        )
                        ,reverse=True)
    Log("s_variants={}".format(repr(s_variants)))

    if len(variants) < 1:
        #some sites don't have a choice, are not listed as VOD, but are otherwise OK
        choice = 0
        lastbitrate=0
        s_variants.append((url, ('BANDWIDTH=1500000', 'RESOLUTION=1280x720')))
        Log("s_variants={}".format(repr(s_variants)))
    elif len(variants) == 1:
        #url = urlparse.urljoin(url, variants[0][0])
        choice = 0
        lastbitrate=0
    elif len(variants) >= 2:
        #Log("More than one variant of the stream was provided.")        
        choice = None
        lastbitrate=0
        
        for i, (vurl, vattrs) in enumerate(s_variants):
            for attr in vattrs:
                key, value = attr.split('=')
                key = key.strip()
                value = value.strip().strip('"')
                if key == 'BANDWIDTH':
                    value = int(value)
                    if (value <= maxbitrate) and (value>lastbitrate):
                        choice = i
                        lastbitrate = value
                elif key == 'PROGRAM-ID':
                    pass
                elif key == 'CODECS':
##                    Log("STREAM-CODECS attribute {}".format(key))
                    pass
                elif key == 'RESOLUTION':
##                    Log("STREAM-RESOLUTION attribute {}".format(key))
                    pass
                else:
##                    Log("unknown STREAM-INF attribute {}".format(key))
                    pass


    Log("choice='{}' lastbitrate='{:,}' maxbitrate='{:,}'".format(choice, lastbitrate, maxbitrate))
    if choice is None :
        if maxbitrate < 1:
            Log("probably wants minimum rate, which is usually last")
            choice=len(s_variants)-1
        elif lastbitrate == 0:
            Log("if lastbitrate was never set, then probably wants minimum rate, which is usually last")
            choice=len(s_variants)-1
        else:
            Log("probably wants max rate, which is usually first")
            choice=0

    if choice >= 0:
        try:
            slightly_worse = s_variants[choice+1][1]
        except: #when choice is the last in a list, we can't increment
            slightly_worse = s_variants[choice][1]
    else: #last entry has been chosen
        slightly_worse = s_variants[choice][1]
    for attr in slightly_worse:
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            slightly_worse= int(value)
            break
    Log("slightly_worse={}".format(slightly_worse))


    if choice >= 1:
        try:
            slightly_better = s_variants[choice-1][1]
        except: #when choice is first in a list, we can't increment
            slightly_better = s_variants[choice][1]
    else: #last entry has been chosen
        slightly_better = s_variants[choice][1]
    for attr in slightly_better:
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            slightly_better= int(value)
            break
    Log("slightly_better={}".format(slightly_better))


    for attr in (s_variants[choice][1]):
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            chosen_bitrate= int(value)
            break
    Log("chosen_bitrate={}".format(chosen_bitrate))

    url = urlparse.urljoin(url, s_variants[choice][0])
    Log("chosen stream url is '{:,} bps' at '{}' ".format(chosen_bitrate, url))

##    raise Exception('devtesting')
    return url, chosen_bitrate, slightly_better, slightly_worse

###__________________________________________________________________
###
def Clean_Filename(s, include_square_braces=True, delete_first_color=False):
    if not s: return ''
    s = s.strip('\r')
    if delete_first_color:
        s = (re.sub(u'(?i)\[cOLOR \w+?\].+?\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(u'(?i)\[\/Color\]','',s))
    if include_square_braces:
        s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_\-]',' ',s))
    else:
        s = (re.sub(u'(?is)[^A-Za-z0-9~     ,\'.&_\-]',' ',s))
    while '  ' in s:
        s = s.replace('  ', ' ')
    return s.strip()
###__________________________________________________________________
###
def Make_HLSRETRYSEEK_file(name):
    import tempfile
##    tmp_file = tempfile.mktemp(
##          dir = GetCacheDirFileSpec()
##        , prefix = Clean_Filename(name)+'.'
##        , suffix = c.TEMP_CACHE_FILE_EXT)
    tmp_file = (
        GetCacheDirFileSpec()
        + '\\'
        + Clean_Filename(name)
        + '.' + 'HLSRETRYSEEK'
        + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S")
        + c.TEMP_CACHE_FILE_EXT
    )
    tmp_file = xbmc.makeLegalFilename(tmp_file)
    return tmp_file
###__________________________________________________________________
###
def Size_HLSRETRYSEEK_file(filespec):
    size = 0
    try:
        size = os.stat(filespec).st_size
##        Log(repr(size))
        size =  os.path.getsize(filespec)
##        Log(repr(size))

    except:
        traceback.print_exc()
    return size
    
    
###__________________________________________________________________
###
