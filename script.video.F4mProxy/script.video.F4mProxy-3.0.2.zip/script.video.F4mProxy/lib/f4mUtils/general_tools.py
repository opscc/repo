#-*- coding: utf-8 -*-
#import Cookie
try:
    import cookielib
except:
    import http.cookiejar as cookielib

import tempfile
import datetime
import time
import json
import os, errno
import re
import requests
import traceback
import urllib3
import xbmc
import xbmcvfs
import xbmcaddon
import simplecache
import sqlite3
import sys
import urllib
import xbmcplugin
import xbmcgui

from f4mUtils import constants as c
from f4mUtils import constants as C

from f4mUtils.constants import urlparse
from f4mUtils.constants import urllib2
from f4mUtils.constants import translatePath
from f4mUtils.constants import makeLegalFilename

#this_addon = C.this_addon
DEBUG = (C.this_addon.getSetting('debug').lower() == "true")

profileDir = C.this_addon.getAddonInfo('profile')
profileDir = translatePath(profileDir)
if not os.path.exists(profileDir): os.makedirs(profileDir)
cookiePath = os.path.join(profileDir, 'cookies.lwp')
cookieJar = cookielib.LWPCookieJar(translatePath(cookiePath))
my_http_session = requests.Session()


if sys.version_info >= (3, 0): from html.parser import HTMLParser
else: from HTMLParser import HTMLParser
html_parser = HTMLParser()

my_http_session = requests.Session()
##from urllib3 import ProxyManager, PoolManager
##pool_proxy = PoolManager(
##    
##    ,ca_certs=certifi.where()
##    )

global_cache = simplecache.SimpleCache()

monitor = xbmc.Monitor()




###__________________________________________________________________
###
#either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
# https://wiki.mozilla.org/CA/Included_Certificates
##if C.DEBUG: urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
##certPath = os.path.join(os.path.dirname(__file__), "cacert.pem")  # located in same folder as this one
import certifi
certPath = certifi.where()

from urllib3 import PoolManager,ProxyManager
proxy = PoolManager()
if certPath:
    pool_proxy = PoolManager(ca_certs=certPath
                             ,cert_reqs = "CERT_NONE")
else:
    pool_proxy = PoolManager(cert_reqs = "CERT_NONE")
    


###__________________________________________________________________
###
def Bool(data): #convert an object into True or False; can't trust python's
    return (str(data) in ['true', 'True'])
###__________________________________________________________________
###
def IsNone(data):
    return (data is None) or (data.encode('ascii','ignore') in ['','None',b'',b'None'] )
    
###__________________________________________________________________
###
def IsNotNone(data):
    return not(IsNone(data))
###__________________________________________________________________
###
def Debugging():
    global DEBUG
    try:
        this_addon = xbmcaddon.Addon('script.video.F4mProxy') #must recreate this for latest value
        DEBUG = (this_addon.getSetting('debug').lower() == "true")
    except:
        traceback.print_exc()
        DEBUG = True
    return  DEBUG
###__________________________________________________________________
###
def Log(msg="", loglevel=None, stacklimit=2):
    if not msg: msg = u""
    if not isinstance(msg, C.text_type): #convert to unicode when it is not
        if C.PY3: msg = str(msg,'utf8','ignore')
        if C.PY2: msg = msg.decode('ascii','ignore').encode('utf8')
    try: 
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklimit)[0][0])
            ,traceback.extract_stack(limit=stacklimit)[0][1]
            ,msg
            )
    except:
        pass
    try:
        msg = u"{}: {}".format(C.addon_id, msg )
        if              loglevel:  xbmc.log(msg , loglevel)
        elif         Debugging():  xbmc.log(msg , xbmc.LOGNONE)
        else:                      xbmc.log(msg)
    except:
        xbmc.log(repr((type(msg),msg)), xbmc.LOGNONE)
###__________________________________________________________________
###
def LogR(msg="", loglevel=None):
    Log(repr((type(msg),msg)),loglevel,stacklimit=3)
###__________________________________________________________________
###
def Setting_MinDiskSpace():
    try:
        this_addon = xbmcaddon.Addon('script.video.F4mProxy') #must recreate this for latest value
        return int(this_addon.getSetting('minimum_free_disk_space'))
    except:
        traceback.print_exc()
        return C.DEFAULT_MINIMUM_FREE_DISK_SPACE
###__________________________________________________________________
###
def Setting_DefaultRecordMinutes():
    try:
        this_addon = xbmcaddon.Addon('script.video.F4mProxy') #must recreate this for latest value
        return int(this_addon.getSetting('default_record_minutes'))
    except:
        traceback.print_exc()
        return C.DEFAULT_RECORD_MINUTES
###__________________________________________________________________
###
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=c.DEFAULT_SLEEP_INTERVAL_STEP):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval
    
###__________________________________________________________________
###
def GetCacheDirFileSpec():
    addon = xbmcaddon.Addon()
    cache_dir = translatePath("special://home/cache")
    if not os.path.exists(cache_dir): os.mkdir(cache_dir)
    cache_dir = os.path.join(cache_dir, "archive_cache")
    if not os.path.exists(cache_dir): os.mkdir(cache_dir)
    cache_dir = os.path.join(cache_dir, c.TEMP_CACHE_FILE_FOLDER)
    if not os.path.exists(cache_dir): os.mkdir(cache_dir)
##    temp_path = os.path.join(cache_dir, c.TEMP_CACHE_FILE_FOLDER)
##    try:
##        os.mkdir(temp_path)
##    except OSError as e:
##        if e.errno == errno.EEXIST:
##            pass
##        else:
##            raise
    return cache_dir

###__________________________________________________________________
###
def CleanCacheDir():
    temp_path = GetCacheDirFileSpec()
    for root, dirs, files in os.walk(temp_path):
        for name in files:
            filename = os.path.join(root, name)
            mtime = os.path.getmtime(filename)
##            Log(repr(time.gmtime(mtime)))
            if (time.time() - mtime) > 120:  #file modified more than 120 seconds
                DeleteCacheFile(filename)
###__________________________________________________________________
###
def DeleteCacheFile(filespec):
#    traceback.print_stack()
    try:
        if filespec.endswith(c.TEMP_CACHE_FILE_EXT):
            Log("deleting filespec='{}'".format(filespec))
##            traceback.print_stack()
            delete_attempt = 0
            while os.path.exists(filespec) and delete_attempt <= c.TEMP_FILE_MANIPULATION_ATTEMPTS:
                delete_attempt += 1
                Sleep(c.TIME_BEFORE_TEMP_FILE_MANIPULATION)
                try:
                    os.remove(filespec)
                except:
                    if delete_attempt == c.TEMP_FILE_MANIPULATION_ATTEMPTS:
                        traceback.print_exc()
                    pass
            else:
                if not os.path.exists(filespec):
                    Log("{} deleted".format(repr(filespec).replace('\\\\', '\\')))
                    
    except:
        Log("deleting filespec='{}'".format(filespec), C.LOGERROR)
##        traceback.print_exc()
        
###__________________________________________________________________
###
def TempCacheFile():
    #return writable file object
    return tempfile.NamedTemporaryFile(
        mode = 'a+b'
        #,suffix = '.tmp.mp4'
        ,suffix = c.TEMP_CACHE_FILE_EXT
        ,dir = GetCacheDirFileSpec()
        ,delete = False
        )
###__________________________________________________________________
###
def Get_URL(url
           ,client_header
           ,stream=False
           ,return_response=False
           ,save_cookie=False
           ,send_back_redirect=False
           ,method='GET'
           ,request_body=''):

##    #must recalc this value if we want to dynamically change debugging verbosity without restart
##    Debugging()
    
##    Log(repr((url
##           ,client_header
##           ,stream
##           ,return_response
##           ,save_cookie
##           ,send_back_redirect
##           ,method
##           ,request_body)))

    if not client_header: client_header = {}

    return getHtml(url
                   , headers=dict(client_header)
                   , send_back_response=return_response
                   , preload_content=not stream
                   , method=method
                   , save_cookie=save_cookie
                   , send_back_redirect=send_back_redirect
                   , sent_data=request_body
                   )



#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data 
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________________
#
def get_setting(setting_name, auto_convert=bool):
##    try:
##        Log(str(C.this_addon.getAddonInfo('id')) , LOGNONE)
##    except:
##        traceback.print_exc()
    this_addon = xbmcaddon.Addon('script.video.F4mProxy') #must recreate this for latest value        
    raw_setting = this_addon.getSetting(setting_name)
    if auto_convert is bool:
        if raw_setting.lower() in ['true','false']:
            return (raw_setting.lower() == 'true')
        if raw_setting.lower() in ['none']:
            return None
        if raw_setting == '':
            return None
    if auto_convert is int:
        if raw_setting == '':
            return 0
        else:
            return int(raw_setting)
    if auto_convert is float:
        #Log("float:"+repr(auto_convert is float), xbmc.LOGNONE)
        return float(raw_setting)
    if auto_convert is str:
        return str(raw_setting)
    splitted = repr(auto_convert).split("','")[0].split("'")[1]
    return raw_setting
#__________________________________________________________________________
#
def set_setting(setting_name, setting_value):
    Log(repr(("set_setting", setting_name,setting_value)))
    C.this_addon.setSetting(id=setting_name, value=str(setting_value))
#__________________________________________________________________________
# wrapper to allow cookie extraction from urllib3 proxy/socks requests
class FakeRequest(object):
    def __init__(self, full_url, headers):
        self.full_url = full_url
        self._headers = headers.copy()
    @property
    def headers(self):
        return self._headers
    @property
    def url(self):
        return self.full_url
    def get_full_url(self):
        return self.full_url
    def is_unverifiable(self, *args, **kargs):
        return True
    def get_origin_req_host(self, *args, **kargs):
        return self.full_url   
#__________________________________________________________________________
#
def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=30
            , sucuri_solved=False
            , method="GET"
            , send_back_response=False
            , auto_encode_content=False
##            , cookie_domain=None
            , size=8192*1000
            , start_point=None
            , preload_content=True
            ):

##    Log(repr((__name__, locals()))
####        ,C.LOGNONE
##        )


##    return

##    Log(repr(xbmc.getIPAddress()),xbmc.LOGNONE)
    ip = xbmc.getIPAddress() #in case we don't have IP
    if not ip or ip.startswith('169.254'): # or ip.startswith('172.'):
        if send_back_redirect == True:
            return '', ''
        return ''


    cj = cookielib.LWPCookieJar(cookiePath)
##    Log(cookiePath, C.LOGNONE)
##    Log(repr(cj), C.LOGNONE)
##    if not os.path.exists(profileDir):
##        Log(profileDir
##            ,C.LOGNONE
##            )
##        os.makedirs(profileDir)
        
    try:
        cj.load(ignore_discard=True, ignore_expires=True)
        cj._now = int(time.time()) #module does not set this if I use internal functions
    except:
        cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
        cj._now = int(time.time())
        pass
    stream=False
    response = None
    redirected_url = None

                        
    try:
                
        if headers is None:
            getHtml_headers = C.DEFAULT_HEADERS.copy()
            r_c_u_a = C.USER_AGENT #random.choice(C._USER_AGENTS)
            getHtml_headers['User-Agent'] = r_c_u_a
        else:
            getHtml_headers = headers #headers.copy()
            
        if len(referer) > 1:
            getHtml_headers['Referer'] = referer

        if sent_data:
            getHtml_headers['Content-Length'] = str(len(sent_data))

        if start_point and int(start_point) > 0:
            getHtml_headers['Range'] = 'bytes={}-'.format(start_point)


        #
        # I don't know how to use cookieJar with SOCKS proxy
        #
        socks_cookies = ''
        this_domain = urlparse.urlparse(url).netloc
##        Log(this_domain)
        temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
##        Log("type temp_cookiejar='{}'".format(type(temp_cookiejar)))
##        Log("type cj='{}'".format(type(cj)))
        if cj:
            for cookie in cj:
##                Log("pre-request cookie='{}'".format(cookie))
                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                    socks_cookies += "{}={};".format(cookie.name,cookie.value)
                    temp_cookiejar.set_cookie(cookie)
    ##                    Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)
##            Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)

##            for cookie in temp_cookiejar: #verification during development 
##                Log("temp_cookiejar_cookie={}".format(repr(cookie)))
##                pass

            if 'Cookie' in getHtml_headers:
    ##            Log("getHtml_headers['Cookie']={}".format(getHtml_headers['Cookie']), xbmc.LOGNONE)
                socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
            if not socks_cookies == '':
                getHtml_headers['Cookie'] = (socks_cookies).strip(';')


    
##        Log("final getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
##        return "" #getHtml_headers testing/dev

        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            proxy = SOCKSProxyManager(proxy_url=socks_string)
            
            socks_response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content 
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if preload_content:
                data = socks_response.data
            redirected_url = socks_response.geturl()
            if not url == redirected_url:
                Log("redirected_url='{}'".format(redirected_url))
            else:
                redirected_url = None



        elif (socks_proxy_info['uhp'] <= -0) :
            
            if socks_proxy_info['ps'] is not None:
                proxy_string = "http://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                proxy = ProxyManager(
                    proxy_url=proxy_string
                    , cert_reqs = "CERT_NONE"
                    )
            else:
                proxy_string = ''
                proxy = pool_proxy
##            Log(proxy_string)

##            Log(url)
            response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content
                
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
 
            #make urllib3.response more like requests.response by adding cookiejar and status
            temp_jar = cookielib.LWPCookieJar()
            fake_request = FakeRequest(url, response.getheaders() )
            requests.cookies.extract_cookies_to_jar(temp_jar, fake_request, response)
            response.cookies = temp_jar
            response.status_code = response.status
            
            if preload_content:
##                Log("preload_content")
                data = response.data

##            Log(repr(urllib3.__version__))
##            Log(data[:500])
##            Log(repr(response.getheaders()))
            redirected_url = response.geturl()
            if not (url == redirected_url):
##                Log(u"redirected_url={}".format(repr(redirected_url)))
                if redirected_url and (not redirected_url.startswith('http')):
                    if response.retries is not None:
                        if len(response.retries.history):
                            redir_domain = response.retries.history[-1].url
                            redirected_url = redir_domain #+ redirected_url
                        else:
                            #URLLIB3 HACK... for some reason the history does not work inside this code
                            #   even when it works in unit testing using the original domain name
                            redirected_url = urlparse.urlparse(url).scheme + "://" + urlparse.urlparse(url).netloc + redirected_url
                if redirected_url and not (redirected_url.startswith('http')):
                    redir_domain = urlparse.urlparse(url).scheme + '://' + urlparse.urlparse(url).netloc
                    redirected_url = redir_domain + redirected_url
                if (url == redirected_url):
                    redirected_url = None
                else:
                    Log(u"processed redirected_url={}".format(repr(redirected_url)))
            else:
                redirected_url = None

##        Log(repr(response.status_code))
        if not(response.status_code in (200,301)):
            raise urllib2.HTTPError(url=url, code=response.status_code, msg="", hdrs=response.headers, fp=None)
##            raise urllib2.HTTPError
            

        if auto_encode_content: 
            if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
                content_type = response.headers['Content-Type']
                if 'charset=' in content_type:
                    ct = content_type.split('charset=')[1]
##                    Log('decoding as {}'.format(repr(ct)))
                    data = data.decode(ct)
        elif not send_back_response:
##            Log('encoding as utf8')
            try:
                data = str(data, 'utf8')
            except:
                pass #leave it as binary; caller will have to deal with any string conversions


        if sucuri_solved == False:
            if 'Server' in response.headers:
                if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                    Log(repr(response.status_code))
                    import sucuri
                    if sucuri.SCRIPT_HEADER in data:
                        cookie = sucuri.Set_Cookie(data)
                        cj.set_cookie(cookie)
                        cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
                        raise
                        return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)


        if not (save_cookie == False) and (cj is not None) :
            r = response
            this_domain = urlparse.urlparse(url).netloc
            if r is not None:
                for cookie in r.cookies:
                    Log("r.cookie={}".format(repr(cookie)))
                    if save_cookie == True: #save as this domain even if cookie is not marked so
                         cookie.domain = this_domain
                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
##                        Log("saving cookie={}".format(repr(cookie)))
                        cj.set_cookie(cookie)
                cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

              


    except requests.HTTPError as e:
        Log("repr(e)='{}'".format(repr(e)))
        Log(repr((__name__, locals()))
##            ,C.LOGNONE
            )

        raise
        
    except urllib2.HTTPError as e:
##        traceback.print_exc()        
##        Log(repr(e.info().get('Content-Encoding')))
##        if e.info().get('Content-Encoding') == 'gzip':
##            import StringIO
##            buf = StringIO.StringIO( e.read())
##            import gzip
##            f = gzip.GzipFile(fileobj=buf)
##            data = f.read()
##            f.close()
##        else:
##            data = e.read()
##        #Log(data)  #errors='ignore'
##        #notify('Oh oh',data)
        data = e.msg

##        if e.code == 503 and 'cf-browser-verification' in data:
##            import cloudflare
##            data = cloudflare.solve(url, cj, USER_AGENT)
            
        if e.code == 404 and ignore404 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        elif e.code == 403 and ignore403 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data
            
        else:
##            traceback.print_exc()
            raise

    except:
        Log(repr((__name__, locals()))
##            ,C.LOGNONE
            )

        raise

    if send_back_response == True:
        return response

    if response:
        response.close()


    if send_back_redirect == True:
        return data, redirected_url

    return data
    
#__________________________________________________________________________
#
def postHtml(post_url, sent_data=None, headers=None, compression=True, NoCookie=True):
    data = getHtml(url=post_url, headers=headers, save_cookie=(not NoCookie), sent_data=sent_data, method="POST" )
##    Log(data)
    return data

#__________________________________________________________________________
#
def headHtml(head_url, sent_data=None, headers=None, compression=True, NoCookie=True, send_back_redirect=False):
    return getHtml(url=head_url, send_back_redirect=send_back_redirect, headers=headers, save_cookie=(not NoCookie), method="HEAD" )


###__________________________________________________________________________
###
##def getHtml2(url):
##    req = Request(url)
##    response = urllib2.urlopen(req, timeout=60)
##    data = response.read()
##    response.close()
##    return data
###__________________________________________________________________________
###
##def getVideoLink(url, referer, hdr=None, data=None):
##    if not hdr:
##        req2 = Request(url, data, DEFAULT_HEADERS)
##    else:
##        req2 = Request(url, data, hdr)
##    if len(referer) > 1:
##        req2.add_header('Referer', referer)
##    url2 = urllib2.urlopen(req2).geturl()
##    return url2
#__________________________________________________________________________
#
def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q

#__________________________________________________________________________
#
def endOfDirectory(cacheToDisc=True, end_directory=True, allow_sorting=True, inband_recurse=False, updateListing=False):
##    if end_directory is True:  traceback.print_stack()

    if not ( (end_directory == True) or inband_recurse ):
        return
    if allow_sorting == True:
        add_sort_method()
    if int(sys.argv[1]) > 0:
        C.addon_handle = int(sys.argv[1])
        xbmcplugin.endOfDirectory(C.addon_handle, cacheToDisc=cacheToDisc, updateListing=updateListing)
#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    from xml.dom import minidom
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None

    def Get_Setting_Val(setting):
        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"' +
                                  setting + '"},"id":1}')
        return json.loads(val)['result']['value']
    
    try:
        usehttpproxy = Get_Setting_Val('network.usehttpproxy')
        if usehttpproxy and str(usehttpproxy).lower()=='true':
            httpproxytype = Get_Setting_Val('network.httpproxytype') #= get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = Get_Setting_Val('network.httpproxyserver') #= get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = Get_Setting_Val('network.httpproxyport') #= get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = Get_Setting_Val('network.httpproxyusername') #= get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = Get_Setting_Val('network.httpproxypassword') #= get_gui_setting(guisettings_xml, 'httpproxypassword')

    except:
        traceback.print_exc()
##        raise
##        pass
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
##        Log(repr(proxy_info))
        return proxy_info
    
###__________________________________________________________________
###
##def Socks_Proxy_Active():
##    from xml.dom import minidom
##    usehttpproxy = False
##    httpproxytype = -1
##    httpproxyserver = None
##    httpproxyport = 0
##    httpproxyusername = None
##    httpproxypassword = None
##    try:
##        guisettings_xml = minidom.parse(xbmc.translatePath('special://home/userdata/guisettings.xml'))
##        usehttpproxy = get_gui_setting(guisettings_xml, 'usehttpproxy')
##        if usehttpproxy and usehttpproxy.lower()=='true':
##            httpproxytype = get_gui_setting(guisettings_xml, 'httpproxytype')
##            httpproxyserver = get_gui_setting(guisettings_xml, 'httpproxyserver')
##            httpproxyport = get_gui_setting(guisettings_xml, 'httpproxyport')
##            httpproxyusername = get_gui_setting(guisettings_xml, 'httpproxyusername')
##            httpproxypassword = get_gui_setting(guisettings_xml, 'httpproxypassword')
##    except:
##        traceback.print_exc()
####        raise
####        pass
##    finally:
##        proxy_info = {
##             'uhp' : int(httpproxytype)
##            , 'ps' : httpproxyserver
##            , 'pp' : int(httpproxyport)
##            , 'un' : httpproxyusername
##            , 'up' : httpproxypassword
##            }
####        Log(repr(proxy_info))
##        return proxy_info
    
###__________________________________________________________________
###
def SetCookie_To_Array_Of_Cookie(set_cookie_string):
##    Log("set_cookie_string='{}'".format(set_cookie_string))
    cookies_array = []
    #regex = "(?is)(\s?expires=\w\w\w,\s\d\d-\w\w\w-\d{2,4}\s\d{1,2}:\d\d:\d\d(?:\s?\w{3})?;?)"
    regex = "(\s?expires=(.{27,29})(?:;|,)?)"
    regex = "(\s?expires=([^;]+);)"
    
    set_cookie_string_no_expires = re.sub(regex,'',set_cookie_string, flags=re.IGNORECASE)
##    Log("set_cookie_string_no_expires='{}'".format(set_cookie_string_no_expires))
##    return cookies_array
    #https://docs.python.org/2/library/cookielib.html#cookielib.Cookie.is_expired
    for cook in set_cookie_string_no_expires.split(', '):
        if cook == '': break #in case blank cookie
##        Log("cook='{}'".format(repr(cook)))
        morsels = None
        name=None
        value=None
        port=None
        port_specified=False
        domain=''
        domain_specified=False
        domain_initial_dot=False
        path=''
        path_specified=False
        max_age=None
        expire_date=None
        comment=None
        comment_url=None
        discard=False #True if this is a session cookie
        secure=True #True if cookie should only be returned over a secure connection
        for morsel in cook.split('; '):
##            morsel=morsel.rstrip(';') #in case a cookie has only name/value
##            Log("morsel='{}'".format(repr(morsel)))

            if not '=' in morsel:
                ##single word value
                pass ##I am ignoring these ones
            
            else:
                #morsels = morsel.split("=")
                morsels=[morsel[0: morsel.find("=")] , morsel[morsel.find("=")+len("="): (max(morsel.find(";"), len(morsel)))      ] ]
##                Log(str(morsel.find("=")+len("=")))
##                Log(str(morsel.find(";")))
##                Log(str(max(morsel.find(";"), len(morsel))))
                #Log("morsels='{}'".format(repr(morsels)))
                if morsels[0].lower() == 'path':
                    path=morsels[1]
                    path_specified=True
                elif morsels[0].lower() == 'max-age':
                    max_age=morsels[1] #essentially same info as expires; written as seconds(from now, presumably)which means cookie is only good for current session
##                    Log("morsel='{}'".format(repr(morsel)))
##                    Log("morsels[1]='{}'".format(morsels[1]))
##                    Log("max_age='{}'".format(max_age))
                    max_age=int(max_age)
                elif morsels[0].lower() == 'domain':
                    domain=morsels[1]
                    domain_specified=True
                    if domain[0]=='.': domain_initial_dot = True
                elif morsels[0].lower() == 'port':
                    port=morsels[1]
                    port_specified=True
                elif morsels[0].lower() == 'comment':
                    comment=morsels[1]
                elif morsels[0].lower() == 'samesite':
                    pass
                elif morsels[0].lower() == 'comment_url':
                    comment_url=morsels[1]
                else:
                    name=morsels[0]
                    value=morsels[1]
                    regex = "{}={};.*?expires=([^;]+)".format(re.escape(name),re.escape(value))
##                    Log(regex) 
                    try:
                        expire_date_arr= re.compile(regex, re.DOTALL | re.IGNORECASE).findall(set_cookie_string)
                        if len(expire_date_arr)<1:
                            #discard=True
                            Log("Cant find exipre date for regex='{}'".format(regex))
##                            Log("morsel='{}'".format(morsel))
##                            Log("name='{}'".format(name))
##                            Log("value='{}'".format(value))
##                            Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                            Log("cook='{}'".format(cook))
##                            Log("set_cookie_string='{}'".format(set_cookie_string))
##                            Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))

                        else:
                            expire_date = expire_date_arr[0]
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("(type(datetime.datetime.now())='{}'".format(type(datetime.datetime.now())))
##                            Log("{}".format(datetime.datetime(1970,1,1).strftime("%a, %d %b %Y %H:%M:%S %Z")))
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("expire_date='{}'".format(expire_date))

                            expire_formats = {"%a, %d-%b-%Y %H:%M:%S %Z"
                                              , "%a, %d-%b-%y %H:%M:%S %Z"
                                              , "%a, %d %b %Y %H:%M:%S %Z"
                                              , "%a, %d %b %y %H:%M:%S %Z" }
                            for expire_format in expire_formats:
                                try:
                                    expire_date = datetime.datetime.strptime(expire_date, expire_format)
##                                    Log("morsel='{}'".format(morsel))
##                                    Log("Match on {}".format(expire_format)) 
                                    expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
##                                    Log("expire_date='{}' type={}".format(expire_date,type(expire_date)))  
                                    break
                                except TypeError:
##                                    Log("TypeError") 
                                    try:
                                        expire_date = datetime.datetime(*(time.strptime(expire_date, expire_format)[0:6]))
##                                      Log("Match on {} with bugfix ".format(expire_format)) 
                                        expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
                                        break
                                    except:
                                        traceback.print_exc()
                                        pass
                                    
                                except:
                                    traceback.print_exc()
                                    pass
                                
##                                Log("(type(expire_date)='{}'".format(type(expire_date)))
##                                if type(expire_date) == "<type 'datetime.datetime'>":

##                            Log("final (type(expire_date)='{}'".format(type(expire_date)))
##                            Log("final expire_date='{}'".format(expire_date))
                            if not (type(expire_date) == type(0)):
                                Log("Failed to convert expire_date='{}' using format '{}'".format(expire_date,expire_format))  
##                                Log("expire_date='{}'".format(expire_date))  
##                                Log("morsel='{}'".format(repr(morsel)))
##                                Log("name='{}'".format(repr(name)))
##                                Log("value='{}'".format(repr(value)))
##                                Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                                Log("cook='{}'".format(cook))
##                                Log("set_cookie_string='{}'".format(set_cookie_string))
##                                Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                                expire_date = 0
                                

                    except:
                        traceback.print_exc()
                        Log("Error parsing expire value for cookie")
                        Log("name='{}'".format(repr(name)))
                        Log("value='{}'".format(repr(value)))
                        Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
                        Log("cook='{}'".format(cook))
                        Log("set_cookie_string='{}'".format(set_cookie_string))
                        Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                        if expire_date: #might have been set by maxage
                            expire_date = 0
                        pass
                    
        if max_age:
            expire_date = max_age
        
        ck = cookielib.Cookie(version=0,
                      name=name,
                      value=value,
                      port=port,
                      port_specified=port_specified,
                      domain=domain,
                      domain_specified=domain_specified,
                      domain_initial_dot=domain_initial_dot,
                      path=path,
                      path_specified=path_specified,
                      secure=secure,
                      expires=expire_date,
                      discard=discard,
                      comment=comment,
                      comment_url=comment_url,
                      rest={},
                      rfc2109=False)
##        Log("cook='{}'".format(repr(cook)))
##        Log("ck='{}'".format(repr(ck)))
        cookies_array.append(ck)

    return cookies_array

###__________________________________________________________________
###
def parse_m3u_tag(line):
    if ':' not in line:
        return line, []
    tag, attribstr = line.split(':', 1)
    attribs = []
    last = 0
    quote = False
    for i,c in enumerate(attribstr+','):
        if c == '"':
            quote = not quote
        if quote:
            continue
        if c == ',':
            attribs.append(attribstr[last:i])
            last = i+1
    return tag, attribs

###__________________________________________________________________
###
def parse_kv(attribs, known_keys=None):
    d = {}
    for item in attribs:
        k, v = item.split('=', 1)
        k=k.strip()
        v=v.strip().strip('"')
        if known_keys is not None and k not in known_keys:
            raise ValueError("unknown attribute %s"%k)
        d[k] = v
    return d
###__________________________________________________________________
###
def Choose_M3U8_Stream(url, url_contents, maxbitrate, dumpfile, vod):
##    Log("Choose_M3U8_Stream(url='{}' url_contents='{}' maxbitrate='{:,}')".format(url, url_contents, maxbitrate))

    #vod files don't allow us to pick a rate
    if vod == True:
        Log("vod file detected")
        return url, maxbitrate, maxbitrate, maxbitrate        

    maxbitrate = int(maxbitrate)
    variants = []
    variant = None
##    Log(url_contents)
    for line in url_contents.split('\n'): #.iter_lines()
##        Log(line)
        #we expect some meta-data in a first line; followed by the url in the second
        if line.startswith('#EXT'):
            tag, attribs = parse_m3u_tag(line)
            if tag == '#EXT-X-STREAM-INF':
                #we only want bitrate column
##                Log(repr(dir(attribs)))
                #attribs2 = parse_kv(attribs, ('METHOD', 'URI', 'IV'))
                #Log(repr(attribs2))
                attribs2 = parse_kv(attribs)
##                Log(repr(attribs2))
##                Log(repr(attribs))
                if 'RESOLUTION' in attribs2:
                    variant = (( 'BANDWIDTH='+attribs2['BANDWIDTH'],'RESOLUTION='+attribs2['RESOLUTION']))
                else:
                    variant = (( 'BANDWIDTH='+attribs2['BANDWIDTH'],'RESOLUTION=None'))
        elif variant:
            variants.append((line, variant))
            variant = None
    Log("variants:{}".format(repr(variants)))
    #make sure _highest_ bitrate is first e.g. [('chunklist_w383802091_b448000_t64RlBTOjMwLjA=.m3u8' , ['BANDWIDTH=488000', 'NAME="FPS:30.0"', 'CODECS="avc1.42c015,mp4a.40.2"', 'RESOLUTION=426x240']), ('chunklist_w383802091_b1148000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=1258000', 'NAME="FPS:30.0"', 'CODECS="avc1.4d401f,mp4a.40.2"', 'RESOLUTION=854x480']), ('chunklist_w383802091_b3096000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=3396000', 'NAME="FPS:30.0"', 'CODECS="avc1.4d401f,mp4a.40.2"', 'RESOLUTION=1280x720']), ('chunklist_w383802091_b5128000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=5628000', 'NAME="FPS:30.0"', 'CODECS="avc1.640028,mp4a.40.2"', 'RESOLUTION=1920x1080'])]
    # [0] is a url; [1][0] is the 'BANDWIDTH=xxx' value
    # [1] is a list of data for the url
    # bandwidth this the first element of the second list
    s_variants = sorted(variants, key=lambda bit_rate: int(
                                                        bit_rate[1][0].lower()
                                                        .split("',")[0]
                                                        .split("=")[1]
                                                        )
                        ,reverse=True)
    Log("{} s_variants={}".format(  len(variants), repr(s_variants)  )   )

    if len(variants) < 1:
        #some sites don't have a choice, are not listed as VOD, but are otherwise OK
        choice = 0
        lastbitrate=0
        s_variants.append((url, ('BANDWIDTH=1500000', 'RESOLUTION=1280x720')))
        Log("s_variants={}".format(repr(s_variants)))
    elif len(variants) == 1:
        #url = urlparse.urljoin(url, variants[0][0])
        choice = 0
        lastbitrate=0
    elif len(variants) >= 2:
        #Log("More than one variant of the stream was provided.")        
        choice = None
        lastbitrate=0
        
        for i, (vurl, vattrs) in enumerate(s_variants):
            for attr in vattrs:
                key, value = attr.split('=')
                key = key.strip()
                value = value.strip().strip('"')
                if key == 'BANDWIDTH':
                    value = int(value)
                    if (value <= maxbitrate) and (value>lastbitrate):
                        choice = i
                        lastbitrate = value
                elif key == 'PROGRAM-ID':
                    pass
                elif key == 'CODECS':
##                    Log("STREAM-CODECS attribute {}".format(key))
                    pass
                elif key == 'RESOLUTION':
##                    Log("STREAM-RESOLUTION attribute {}".format(key))
                    pass
                else:
##                    Log("unknown STREAM-INF attribute {}".format(key))
                    pass


    Log("choice='{}' lastbitrate='{:,}' maxbitrate='{:,}'".format(choice, lastbitrate, maxbitrate))
    if choice is None :
        if maxbitrate < 1:
            Log("probably wants minimum rate, which is usually last")
            choice=len(s_variants)-1
        elif lastbitrate == 0:
            Log("if lastbitrate was never set, then probably wants minimum rate, which is usually last")
            choice=len(s_variants)-1
        else:
            Log("probably wants max rate, which is usually first")
            choice=0

    if choice >= 0:
        try:
            slightly_worse = s_variants[choice+1][1]
        except: #when choice is the last in a list, we can't increment
            slightly_worse = s_variants[choice][1]
    else: #last entry has been chosen
        slightly_worse = s_variants[choice][1]
    for attr in slightly_worse:
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            slightly_worse= int(value)
            break
    Log("slightly_worse={}".format(slightly_worse))


    if choice >= 1:
        try:
            slightly_better = s_variants[choice-1][1]
        except: #when choice is first in a list, we can't increment
            slightly_better = s_variants[choice][1]
    else: #last entry has been chosen
        slightly_better = s_variants[choice][1]
    for attr in slightly_better:
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            slightly_better= int(value)
            break
    Log("slightly_better={}".format(slightly_better))


    for attr in (s_variants[choice][1]):
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            chosen_bitrate= int(value)
            break
    Log("chosen_bitrate={}".format(chosen_bitrate))

    url = urlparse.urljoin(url, s_variants[choice][0])
    Log("chosen stream url is '{:,} bps' at '{}' ".format(chosen_bitrate, url))

##    raise Exception('devtesting')
    return url, chosen_bitrate, slightly_better, slightly_worse

###__________________________________________________________________
###
def Clean_Filename(s, include_square_braces=True, delete_first_color=False):
    if not s: return ''
    s = s.strip('\r')
    if delete_first_color:
        s = (re.sub(u'(?i)\[cOLOR \w+?\].+?\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(u'(?i)\[\/Color\]','',s))
    if include_square_braces:
        s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_\-]',' ',s))
    else:
        s = (re.sub(u'(?is)[^A-Za-z0-9~     ,\'.&_\-]',' ',s))
    while '  ' in s:
        s = s.replace('  ', ' ')
    return s.strip()
###__________________________________________________________________
###
def Make_HLSRETRYSEEK_file(name):
    tmp_file = (
        GetCacheDirFileSpec()
        + '\\'
        + Clean_Filename(name)
        + '.' + 'HLSRETRYSEEK'
        + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S")
        + c.TEMP_CACHE_FILE_EXT
    )
    tmp_file = makeLegalFilename(tmp_file)
    return tmp_file
###__________________________________________________________________
###
def Size_HLSRETRYSEEK_file(filespec):
    size = 0
    try:
        size =  os.path.getsize(filespec)
    except:
        pass
        #traceback.print_exc()
    return size

#__________________________________________________________________________
#
def Normalize_Filespec(filespec):
    #python can get confused with smb://
    if os.name == 'nt':
        filespec = os.path.normpath(filespec)
        if filespec.startswith("smb:"):
            filespec = filespec[4:]
        filespec = os.path.normpath(filespec)
        filespec = filespec.replace("\\\\", "\\")
        if filespec.startswith("\\") and not filespec.startswith("\\\\"):
            filespec = "\\" + filespec
        if filespec.startswith("\\\\") and (':' in filespec):
            #original path contained a port number; remove it for smb:
            filespec = re.sub(r"(\:[^\\]+)","",filespec)
        if len(filespec) > 250: #max path length exceeded; keep file extension
            filespec = filespec[0:240] + "." + filespec.split(".")[-1]
    return filespec
###__________________________________________________________________
###
def Make_download_path(  name = ''
                       , include_date = False
                       , file_extension = ''
                       , folder=None
                       , multiple_per_day=True):
    Log(u"Make_download_path {}".format(
            repr((    name
                     ,include_date
                     ,file_extension
                     ,folder
                     ,multiple_per_day
                 ))
             
            )
        ,C.LOGNONE
        )

##    traceback.print_stack()
    name = Clean_Filename(name)
##    Log(name)

    if folder is None:
        download_folder = GetSetting("tv.download.path").decode('utf8')
        Log("Make_download_path download_path='{}'".format(repr(download_folder)))
        if download_folder in ['','None',None]:
            try:
                download_folder = xbmcgui.Dialog().browse(0, "Specify a folder to save Downloads", 'myprograms', '', False, False)
                C.addon.setSetting(id='download_path', value=download_folder)
                if not os.path.exists(download_folder): os.mkdir(download_folder)
            except:
                traceback.print_exc()
##                raise
    else:
        download_folder = folder

##    Log(download_folder)
    download_folder = Normalize_Filespec(download_folder)

    if not (download_folder in ['','None',None]):
        p = u''
        for a in download_folder.split(os.sep):
            p = p + a + os.sep
            if not os.path.exists(p):
                try:
                    os.mkdir(p)
                except:
                    pass

    if not download_folder.endswith(os.sep):
        download_folder+=os.sep
                
    if include_date:
        date_string = datetime.datetime.now().strftime(".%Y-%m-%d")
    else:
        date_string = ""

    download_path = None
    if multiple_per_day and name:
        append = ''
        probe_filespec = download_folder + name + date_string + append + file_extension
        if not os.path.exists(probe_filespec):
            download_path = probe_filespec
        else:
            for append in range(ord('a'),ord('z')):
                append = chr(append)
                probe_filespec = download_folder + name + date_string + append + file_extension
                if not os.path.exists(probe_filespec):
                    download_path = probe_filespec
                    break
        if not download_path:
            raise Exception(u"can't generate unique name for {}".format(probe_filespec))
    else:
        download_path = download_folder + name + file_extension #.decode('utf8')
    
    Log(u"Make_download_path download_path='{}'".format(download_path)
##        ,C.LOGNONE
        )
##    raise Exception()
    return download_path

##def Make_download_path(  name = ''
##                       , include_date = False
##                       , file_extension = ''
##                       , folder=None
##                       , multiple_per_day=True):
##    Log(u"Make_download_path {}".format(
##            repr((name
##                 ,include_date
##                 ,file_extension
##                 ,folder
##                 ,multiple_per_day
##                 ))
##
##            )
##        #,LOGNONE
##        )
##
##    p = u''
##
##    if os.name == 'nt':
##        split_char = u'\\'
##    else:
##        split_char = u'/'
##
##    for a in folder.split(split_char):
##        p = p + a + split_char
##        if not os.path.exists(p):
##            try:
##                os.mkdir(p)
##            except:
##                pass
##
##    if not os.path.exists(folder):
##        raise Exception('unable to make folder {}'.format(repr(folder)))
##    
##    return folder
    
###__________________________________________________________________
###
def DiskFreeSpace(path):
    import ctypes
    #import platform
    import sys
    import os
    get_free_space_mb = C.DEFAULT_MINIMUM_FREE_DISK_SPACE
    try:
##        if os.name == 'nt':
##            split_char = u'\\'
##        else:
##            split_char = u'/'
##        if platform.system() == 'Windows':
        path = path.rstrip(path.split(os.sep)[-1])
        if os.name == 'nt':
##            Log('he')
            caller_free_bytes = ctypes.c_ulonglong(0)
            ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(path), ctypes.pointer(caller_free_bytes), None, None)
##            Log(repr(caller_free_bytes.value))
            get_free_space_mb = caller_free_bytes.value / 1024.0 / 1024.0
##            Log(repr(get_free_space_mb))
        else:
##            Log('ss')
            st = os.statvfs(path)
            get_free_space_mb = st.f_bavail * st.f_frsize / 1024 / 1024
    except:
        traceback.print_exc()
        
    return int(get_free_space_mb)
###__________________________________________________________________
###
