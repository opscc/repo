#import Cookie
import cookielib
import datetime, time
import os, errno
import re
import requests
import traceback
import urllib3
import urlparse
import xbmc
import xbmcaddon

import constants as c

this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
profileDir = this_addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')
cookieJar = cookielib.LWPCookieJar(xbmc.translatePath(cookiePath))

my_http_session = requests.Session()

###__________________________________________________________________
###
def Bool(data): #convert an object into True or False; can't trust python's
    return (str(data) in ['true', 'True'])

###__________________________________________________________________
###
def IsNotNone(data):
    return not(str(data) in ['None', 'none', ''])

###__________________________________________________________________
###
def Debugging():
    try:    debug = (this_addon.getSetting('debug').lower() == "true")
    except: debug = True
    return  debug

###__________________________________________________________________
###

def Log(msg="", loglevel=None):
    msg = "{}: {}".format(addon_id, msg)
##    xbmc.log(msg , xbmc.LOGNONE)
##    return
    if   loglevel is not None: xbmc.log(msg , loglevel)
    elif          Debugging(): xbmc.log(msg , xbmc.LOGNONE)
    else:                      xbmc.log(msg)

###__________________________________________________________________
###
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=c.DEFAULT_SLEEP_INTERVAL_STEP):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
##    Log("num='{}' sleep_interval='{}'".format(num,sleep_interval))
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval

###__________________________________________________________________
###
def GetCacheDirFileSpec():
    addon = xbmcaddon.Addon()
    profile_dir = addon.getAddonInfo('profile')
    profile_dir = xbmc.translatePath(profile_dir).decode("utf-8")
    temp_path = os.path.join(profile_dir, c.TEMP_CACHE_FILE_FOLDER)
    try:
        os.mkdir(temp_path)
    except OSError as e:
        if e.errno == errno.EEXIST:
            pass
        else:
            raise
##    Log("temp_path='{}'".format(temp_path))
    return temp_path

###__________________________________________________________________
###
def CleanCacheDir():
    temp_path = GetCacheDirFileSpec()
    for root, dirs, files in os.walk(temp_path):
        for name in files:
            filename = os.path.join(root, name)
            DeleteCacheFile(filename)

###__________________________________________________________________
###
def DeleteCacheFile(filespec):
    if filespec.endswith(c.TEMP_CACHE_FILE_EXT):
        Log("deleting filespec='{}'".format(filespec))
        try:
            os.remove(filespec)
        except:
            pass

###__________________________________________________________________
###
def TempCacheFile():
    #return writable file object
    import tempfile
    return tempfile.NamedTemporaryFile(
        mode = 'a+b'
        ,suffix = '.tmp.mp4'
        ,dir = GetCacheDirFileSpec()
        ,delete = False
        )

###__________________________________________________________________
###
def Get_URL(url
           ,client_header
           ,stream=False
           ,return_response=False
           ,save_cookie=True
           ,send_back_redirect=False
           ,method='GET'
           ,request_body=''):

##    Log(("getUrl url='{}'"
##         ", send_back_redirect='{}'"
##         ", return_response='{}'"
##         ", save_cookie='{}'"
##         ", stream='{}'"
##         ).format(
##        url
##        ,send_back_redirect
##        ,return_response
##        ,save_cookie
##        ,stream))

    global cookieJar
    response = None
    redirected_url = None

##    Log("clientHeader='{}'".format(clientHeader))
    getHtml_headers={}
    if client_header:
        for n,v in client_header:
            getHtml_headers[n]=v

    try:

        # I don't know how to use cookieJar with SOCKS proxy; fake it using headers
        socks_cookies = ''
        for cookie in cookieJar:
            this_domain = urlparse.urlparse(url).netloc
            if cookie.domain.endswith(this_domain):
                socks_cookies += "{}={};".format(cookie.name,cookie.value)
        if 'Cookie' in getHtml_headers:
            socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
        if not socks_cookies == '':
            getHtml_headers['Cookie'] = (socks_cookies).strip(';')
##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)

        response = None
        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            proxy = SOCKSProxyManager(proxy_url=socks_string)  #Bases: urllib3.poolmanager.PoolManager, urllib3.request.RequestMethods
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.request.html
            socks_response = proxy.request(
                method
                ,url = url
                ,headers = getHtml_headers
                ,preload_content = not(stream)
                )
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if stream:
                data = None #must not read data now...it will be streamed
            else:
                data = socks_response.data

            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None

        elif (socks_proxy_info['uhp'] == 0) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3 import ProxyManager
            proxy_string = "http://{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp'])
            proxy = ProxyManager(proxy_url=proxy_string)  #Bases: urllib3.poolmanager.PoolManager, urllib3.request.RequestMethods
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.request.html
            socks_response = proxy.request(
                method
                ,url = url
                ,headers = getHtml_headers
                ,preload_content = not(stream)
                )
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if stream:   data = None #must not read data now...it will be streamed
            else:        data = socks_response.data

            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None
            
        elif (socks_proxy_info['uhp'] < 0) :
            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
            else: proxies = {}

            #https://requests.readthedocs.io/en/master/api/#requests.Request            
            response = my_http_session.request(
                method
                , url=url
                , headers=getHtml_headers
                , stream=stream
                , verify=False
                , proxies=proxies) 
            #prepped = my_http_session.prepare_request(my_request)
            #https://requests.readthedocs.io/en/master/api/#requests.Response
            #response = my_http_session.send(prepped, verify=False, proxies=proxies) # https://requests.readthedocs.io/en/master/api/#requests.Response

            if stream:   data = None #must not read data now...it will be streamed
            else:        data = response.content
            
            redirected_url = response.url 
            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
            else: redirected_url = None
            
        if save_cookie == True:
            this_domain = urlparse.urlparse(url).netloc
            if cookieJar is not None and response is not None:
                if 'Set-Cookie' in response.headers:
                    for cookie in SetCookie_To_Array_Of_Cookie(response.headers[ 'Set-Cookie' ]) :
                        if cookie.domain.endswith(this_domain) and not cookie.discard:
                            cookieJar.set_cookie(cookie)
            if cookieJar is not None and socks_response is not None:
                if 'Set-Cookie' in socks_response.headers:
                    for cookie in SetCookie_To_Array_Of_Cookie(socks_response.headers[ 'Set-Cookie' ]) :
                        #Log(repr(cookie))
                        if cookie.domain.endswith(this_domain) and not cookie.discard:
                            #Log(repr(cookie))
                            cookieJar.set_cookie(cookie)
##            Log(cookiePath)
##            cookieJar.save(cookiePath, ignore_expires=True, ignore_discard=True)

    except:
        Log("It looks like '{}' is down.".format(url), xbmc.LOGERROR)
        raise

    if send_back_redirect == True:
        return data, redirected_url
    
    if return_response:
        if response:
            return response
        else:
            return socks_response

    return data


###__________________________________________________________________
###
def get_set(genset,n):
    nd=genset.getElementsByTagName(n)[0]
    #Log("get_set='{}'".format(nd))
    if nd.lastChild is None:
        #Log("  {}='{}'".format(n,nd.lastChild))
        return nd.lastChild
    else:
        #Log("  {}='{}'".format(n,nd.lastChild.data))
        return nd.lastChild.data

###__________________________________________________________________
###
def Socks_Proxy_Active():
    
    from xml.dom import minidom
    gen_set=minidom.parse(xbmc.translatePath('special://home/userdata/guisettings.xml'))
    uhp = get_set(gen_set,"usehttpproxy")
    uhp = uhp.lower()=='true'
    if uhp:
##        Log("a proxy is enabled='{} with value='{}''".format(uhp, int(get_set(gen_set,"httpproxytype")) ))
        #return {'uhp': int(get_set(gen_set,"httpproxytype"))==4  or int(get_set(gen_set,"httpproxytype"))==5  or int(get_set(gen_set,"httpproxytype"))==0
        return {'uhp': int(get_set(gen_set,"httpproxytype"))
                , 'ps': get_set(gen_set,"httpproxyserver")
                , 'pp': int(get_set(gen_set,"httpproxyport"))
                , 'un': get_set(gen_set,"httpproxyusername")
                , 'up': get_set(gen_set,"httpproxypassword")
                }
    else:
        return {'uhp':-1, 'ps':None, 'pp':None, 'un':None, 'up':None}
    
###__________________________________________________________________
###
def SetCookie_To_Array_Of_Cookie(set_cookie_string):
##    Log("set_cookie_string='{}'".format(set_cookie_string))
    cookies_array = []
    #regex = "(?is)(\s?expires=\w\w\w,\s\d\d-\w\w\w-\d{2,4}\s\d{1,2}:\d\d:\d\d(?:\s?\w{3})?;?)"
    regex = "(\s?expires=(.{27,29})(?:;|,)?)"
    regex = "(\s?expires=([^;]+);)"
    
    set_cookie_string_no_expires = re.sub(regex,'',set_cookie_string, flags=re.IGNORECASE)
##    Log("set_cookie_string_no_expires='{}'".format(set_cookie_string_no_expires))
##    return cookies_array
    #https://docs.python.org/2/library/cookielib.html#cookielib.Cookie.is_expired
    for cook in set_cookie_string_no_expires.split(', '):
        if cook == '': break #in case blank cookie
##        Log("cook='{}'".format(repr(cook)))
        morsels = None
        name=None
        value=None
        port=None
        port_specified=False
        domain=''
        domain_specified=False
        domain_initial_dot=False
        path=''
        path_specified=False
        max_age=None
        expire_date=None
        comment=None
        comment_url=None
        discard=False #True if this is a session cookie
        secure=True #True if cookie should only be returned over a secure connection
        for morsel in cook.split('; '):
##            morsel=morsel.rstrip(';') #in case a cookie has only name/value
##            Log("morsel='{}'".format(repr(morsel)))

            if not '=' in morsel:
                ##single word value
                pass ##I am ignoring these ones
            
            else:
                #morsels = morsel.split("=")
                morsels=[morsel[0: morsel.find("=")] , morsel[morsel.find("=")+len("="): (max(morsel.find(";"), len(morsel)))      ] ]
##                Log(str(morsel.find("=")+len("=")))
##                Log(str(morsel.find(";")))
##                Log(str(max(morsel.find(";"), len(morsel))))
                #Log("morsels='{}'".format(repr(morsels)))
                if morsels[0].lower() == 'path':
                    path=morsels[1]
                    path_specified=True
                elif morsels[0].lower() == 'max-age':
                    max_age=morsels[1] #essentially same info as expires; written as seconds(from now, presumably)which means cookie is only good for current session
##                    Log("morsel='{}'".format(repr(morsel)))
##                    Log("morsels[1]='{}'".format(morsels[1]))
##                    Log("max_age='{}'".format(max_age))
                    max_age=int(max_age)
                elif morsels[0].lower() == 'domain':
                    domain=morsels[1]
                    domain_specified=True
                    if domain[0]=='.': domain_initial_dot = True
                elif morsels[0].lower() == 'port':
                    port=morsels[1]
                    port_specified=True
                elif morsels[0].lower() == 'comment':
                    comment=morsels[1]
                elif morsels[0].lower() == 'samesite':
                    pass
                elif morsels[0].lower() == 'comment_url':
                    comment_url=morsels[1]
                else:
                    name=morsels[0]
                    value=morsels[1]
                    regex = "{}={};.*?expires=([^;]+)".format(re.escape(name),re.escape(value))
##                    Log(regex) 
                    try:
                        expire_date_arr= re.compile(regex, re.DOTALL | re.IGNORECASE).findall(set_cookie_string)
                        if len(expire_date_arr)<1:
                            #discard=True
                            Log("Cant find exipre date for regex='{}'".format(regex))
##                            Log("morsel='{}'".format(morsel))
##                            Log("name='{}'".format(name))
##                            Log("value='{}'".format(value))
##                            Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                            Log("cook='{}'".format(cook))
##                            Log("set_cookie_string='{}'".format(set_cookie_string))
##                            Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))

                        else:
                            expire_date = expire_date_arr[0]
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("(type(datetime.datetime.now())='{}'".format(type(datetime.datetime.now())))
##                            Log("{}".format(datetime.datetime(1970,1,1).strftime("%a, %d %b %Y %H:%M:%S %Z")))
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("expire_date='{}'".format(expire_date))

                            expire_formats = {"%a, %d-%b-%Y %H:%M:%S %Z"
                                              , "%a, %d-%b-%y %H:%M:%S %Z"
                                              , "%a, %d %b %Y %H:%M:%S %Z"
                                              , "%a, %d %b %y %H:%M:%S %Z" }
                            for expire_format in expire_formats:
                                try:
                                    expire_date = datetime.datetime.strptime(expire_date, expire_format)
##                                    Log("morsel='{}'".format(morsel))
##                                    Log("Match on {}".format(expire_format)) 
                                    expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
##                                    Log("expire_date='{}' type={}".format(expire_date,type(expire_date)))  
                                    break
                                except TypeError:
##                                    Log("TypeError") 
                                    try:
                                        expire_date = datetime.datetime(*(time.strptime(expire_date, expire_format)[0:6]))
##                                      Log("Match on {} with bugfix ".format(expire_format)) 
                                        expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
                                        break
                                    except:
                                        traceback.print_exc()
                                        pass
                                    
                                except:
                                    traceback.print_exc()
                                    pass
                                
##                                Log("(type(expire_date)='{}'".format(type(expire_date)))
##                                if type(expire_date) == "<type 'datetime.datetime'>":

##                            Log("final (type(expire_date)='{}'".format(type(expire_date)))
##                            Log("final expire_date='{}'".format(expire_date))
                            if not (type(expire_date) == type(0)):
                                Log("Failed to convert expire_date='{}' using format '{}'".format(expire_date,expire_format))  
##                                Log("expire_date='{}'".format(expire_date))  
##                                Log("morsel='{}'".format(repr(morsel)))
##                                Log("name='{}'".format(repr(name)))
##                                Log("value='{}'".format(repr(value)))
##                                Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                                Log("cook='{}'".format(cook))
##                                Log("set_cookie_string='{}'".format(set_cookie_string))
##                                Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                                expire_date = 0
                                

                    except:
                        traceback.print_exc()
                        Log("Error parsing expire value for cookie")
                        Log("name='{}'".format(repr(name)))
                        Log("value='{}'".format(repr(value)))
                        Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
                        Log("cook='{}'".format(cook))
                        Log("set_cookie_string='{}'".format(set_cookie_string))
                        Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                        if expire_date: #might have been set by maxage
                            expire_date = 0
                        pass
                    
        if max_age:
            expire_date = max_age
        
        ck = cookielib.Cookie(version=0,
                      name=name,
                      value=value,
                      port=port,
                      port_specified=port_specified,
                      domain=domain,
                      domain_specified=domain_specified,
                      domain_initial_dot=domain_initial_dot,
                      path=path,
                      path_specified=path_specified,
                      secure=secure,
                      expires=expire_date,
                      discard=discard,
                      comment=comment,
                      comment_url=comment_url,
                      rest={},
                      rfc2109=False)
##        Log("cook='{}'".format(repr(cook)))
##        Log("ck='{}'".format(repr(ck)))
        cookies_array.append(ck)

    return cookies_array

###__________________________________________________________________
###
def parse_m3u_tag(line):
    if ':' not in line:
        return line, []
    tag, attribstr = line.split(':', 1)
    attribs = []
    last = 0
    quote = False
    for i,c in enumerate(attribstr+','):
        if c == '"':
            quote = not quote
        if quote:
            continue
        if c == ',':
            attribs.append(attribstr[last:i])
            last = i+1
    return tag, attribs

###__________________________________________________________________
###
def Choose_M3U8_Stream(url, url_contents, maxbitrate, dumpfile):

##    Log("Choose_M3U8_Stream(url='{}' url_contents='{}' maxbitrate='{:,}')".format(url, url_contents, maxbitrate))

    maxbitrate = int(maxbitrate)
    variants = []
    variant = None
    for line in url_contents.split('\n'): #.iter_lines()
        if line.startswith('#EXT'):
            tag, attribs = parse_m3u_tag(line)
            if tag == '#EXT-X-STREAM-INF':
                variant = attribs
        elif variant:
            variants.append((line, variant))
            variant = None
##    Log("variants:{}".format(repr(variants)))
    #make sure highest bitrate is first e.g. [('chunklist_w383802091_b448000_t64RlBTOjMwLjA=.m3u8' , ['BANDWIDTH=488000', 'NAME="FPS:30.0"', 'CODECS="avc1.42c015,mp4a.40.2"', 'RESOLUTION=426x240']), ('chunklist_w383802091_b1148000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=1258000', 'NAME="FPS:30.0"', 'CODECS="avc1.4d401f,mp4a.40.2"', 'RESOLUTION=854x480']), ('chunklist_w383802091_b3096000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=3396000', 'NAME="FPS:30.0"', 'CODECS="avc1.4d401f,mp4a.40.2"', 'RESOLUTION=1280x720']), ('chunklist_w383802091_b5128000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=5628000', 'NAME="FPS:30.0"', 'CODECS="avc1.640028,mp4a.40.2"', 'RESOLUTION=1920x1080'])]
    s_variants = sorted(variants, key=lambda br: int(br[1][0].lower() \
                                                     .split("',")[0]
                                                     .split("=")[1]
                                                     )
                        ,reverse=True)
    Log("s_variants='{}'".format(repr(s_variants)))


    if len(variants) == 1:
        #url = urlparse.urljoin(url, variants[0][0])
        choice = 0
        lastbitrate=0
    elif len(variants) >= 2:
        #Log("More than one variant of the stream was provided.")        
        choice = None
        lastbitrate=0
        
        for i, (vurl, vattrs) in enumerate(s_variants):
            for attr in vattrs:
                key, value = attr.split('=')
                key = key.strip()
                value = value.strip().strip('"')
                if key == 'BANDWIDTH':
                    value = int(value)
                    if (value <= maxbitrate) and (value>lastbitrate):
                        choice = i
                        lastbitrate = value
                elif key == 'PROGRAM-ID':
                    pass
                elif key == 'CODECS':
##                    Log("STREAM-CODECS attribute {}".format(key))
                    pass
                elif key == 'RESOLUTION':
##                    Log("STREAM-RESOLUTION attribute {}".format(key))
                    pass
                else:
##                    Log("unknown STREAM-INF attribute {}".format(key))
                    pass


    Log("choice='{}' lastbitrate='{:,}' maxbitrate='{:,}'".format(choice, lastbitrate, maxbitrate))
    if choice is None :
        if maxbitrate < 1:
            Log("probably wants minimum rate, which is usually last")
            choice=len(s_variants)-1
        elif lastbitrate == 0:
            Log("if lastbitrate was never set, then probably wants minimum rate, which is usually last")
            choice=len(s_variants)-1
        else:
            Log("probably wants max rate, which is usually first")
            choice=0

    if choice >= 0:
        try:
            slightly_worse = s_variants[choice+1][1]
        except: #when choice is the last in a list, we can't increment
            slightly_worse = s_variants[choice][1]
    else: #last entry has been chosen
        slightly_worse = s_variants[choice][1]
    for attr in slightly_worse:
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            slightly_worse= int(value)
            break
    Log("slightly_worse={}".format(slightly_worse))


    if choice >= 1:
        try:
            slightly_better = s_variants[choice-1][1]
        except: #when choice is first in a list, we can't increment
            slightly_better = s_variants[choice][1]
    else: #last entry has been chosen
        slightly_better = s_variants[choice][1]
    for attr in slightly_better:
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            slightly_better= int(value)
            break
    Log("slightly_better={}".format(slightly_better))


    for attr in (s_variants[choice][1]):
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            chosen_bitrate= int(value)
            break
    Log("chosen_bitrate={}".format(chosen_bitrate))

    url = urlparse.urljoin(url, s_variants[choice][0])
    Log("chosen stream url is '{:,} bps' at '{}' ".format(chosen_bitrate, url))
    
    return url, chosen_bitrate, slightly_better, slightly_worse

###__________________________________________________________________
###
