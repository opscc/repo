#-*- coding: utf-8 -*-
'''
Constants and stuff
'''

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 55334

MAXIMUM_BITRATE_FOR_DOWNLOADS = 999999999



#HLS DOWNLOADER RETRY
INITIAL_BITRATE = None
MAXIMUM_BITRATE = 5000000
ALLOW_UPSCALE = False
UPSCALE_THRESHHOLD = 10
UPSCALE_PENALTY = 30
ALWAYS_REFRESH_M3U8 = False
ALLOW_DOWNSCALE = False
DOWNSCALE_THRESHHOLD = 2
MINIMUM_BITRATE = 100000 

DEFAULT_PRE_CACHE_SIZE_MAX = 1000000
#player will give up if caching is taking too long; avoid this by adjusting
#cache size relative to bitrate such that player only has to wait X seconds
PRE_CACHE_SIZE_BITRATE_MAX_FACTOR = 2

#HACKS: kodi crashes if I ALLOW_UPSCALE when more than this
KODI_CRASH = int(2.9*1000*1000)
MAX_NOTHING_PLAYING_EXCEPTIONS = 4 # often getPlayingFile will return a 'nothing is playing' exception instead of True/False

DEFAULT_SLEEP_TIME = 444 # milliseconds; how long to sleep before asking for a new M3u8 file                    
MIN_SLEEP_TIME     = 101 # milliseconds; minimum

    
DEFAULT_SLEEP_INTERVAL_STEP = 50

TEMP_CACHE_FILE_FOLDER = "cache"
TEMP_CACHE_FILE_EXT = ".tmp.mp4"
