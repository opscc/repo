"""
XBMCLocalProxy 0.1
Copyright 2011 Torben Gerkensmeyer
 
Modified for F4M format by Shani
 
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
 
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
MA 02110-1301, USA.
"""
 
import base64
import datetime

import hashlib
import os
import re
import socket
import sys

import threading

import traceback
import urllib
import urllib2
import urlparse
import xbmc
import xbmcgui


from SocketServer import ThreadingMixIn
from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from StringIO import StringIO

g_currentprocessor = None
monitor = xbmc.Monitor()
        
from f4mUtils import constants as c
from f4mUtils.general_tools import Debugging
from f4mUtils.general_tools import DeleteCacheFile
from f4mUtils.general_tools import IsNotNone
from f4mUtils.general_tools import IsNone
from f4mUtils.general_tools import Make_HLSRETRYSEEK_file
from f4mUtils.general_tools import Size_HLSRETRYSEEK_file
from f4mUtils.general_tools import Log
from f4mUtils.general_tools import Sleep

    
class MyHandler(BaseHTTPRequestHandler):
##https://docs.python.org/2/library/basehttpserver.html

######NOTE:
######RequestHandlerClass
######    The user-provided request handler class; an instance of this
######    class is created for each request.
    
    stop_event = None
    seek_forward_event = None
    monitor = xbmc.Monitor()
##    def __init__( self, *args, **kwargs):
##        Log("__init__")
##        self.stop_event = None
##        self.seek_forward_event = None
##        BaseHTTPRequestHandler.__init__(self, *args)
##
##    def SetStopEvent(self, stop_event):
##        self.stop_event = stop_event
##    def SetSeekForwardEvent(self, seek_forward_event):
##        self.seek_forward_event = seek_forward_event

    def handle_one_request(self):
##        Log ("{} handle_one_request...".format(repr(self)))

##        Log( repr(self.address_string() ))
##        Log( repr(self.server_version ))
##        Log( repr(self.client_address) )
##        Log( repr(self.server ))
##        Log( repr(self.command )) #some items only avail after parsing
##        Log( repr(self.headers ))        

        # 2019-04-18
        # overridde added to deal with race condition error
        #  the self.rfile.readline(65537) seems to close the socket before the
        #  final read can be made; resulting in an error log message
        #
        
        """Handle a single HTTP request.
        You normally don't need to override this method; see the class
        __doc__ string for information on how to handle specific HTTP
        commands such as GET and POST.
        """
        try:
##            Log(repr(self.rfile))
##            Log(repr(dir(self.rfile)))
##            try:
##                Log('error'+repr(dir(self)))
##                Log(repr(self.socket))
##                Log(repr(dir(self.socket)))
##                timeout = self.socket.gettimeout()
##                Log('warning'+repr(timeout))
##            except:
##                pass
##            Log('error'+repr(dir(self.monitor)))
##            Log('warning'+repr(dir(self.monitor.abortRequested())))
            if self.monitor.abortRequested():
                Log("warning handle_one_request stopping because of abortRequested")
                return
            self.raw_requestline = self.rfile.readline(65537)
##            Log(repr(len(self.raw_requestline)))
            if len(self.raw_requestline) > 65536:
                self.requestline = ''
                self.request_version = ''
                self.command = ''
                self.send_error(414)
                return
            if not self.raw_requestline:
                self.close_connection = 1
                return
            if not self.parse_request():
                # An error code has been sent, just exit
                return
            mname = 'do_' + self.command
            if not hasattr(self, mname):
                self.send_error(501, "Unsupported method (%r)" % self.command)
                return
            method = getattr(self, mname)
##            Log( repr(mname))
##            Log( repr(self.server ))
##            Log(repr(method))
            method()
            self.wfile.flush() #actually send the response if not already done.
        except socket.timeout, e: #a read or a write timed out.  Discard this connection
            Log("Request timed out: %r", e)
            self.close_connection = 1
        except:
##            traceback.print_exc()
##            Log('exception')
            self.close_connection = 1
        finally:
##            Log ("{} .. end handle_one_request".format(repr(self)))
            pass

    """
    Serves a HEAD request
    """
    def do_HEAD(self):
        Log ("XBMCLocalProxy: Serving HEAD request...")
        self.send_response(200)
        rtype="flv-application/octet-stream"  #default type could have gone to the server to get it.
        #self.send_header("Accept-Ranges","bytes")
        self.send_header("Content-Type", rtype)
        self.end_headers()
        #s.answer_request(False)

    """
   Serves a GET request.
   """
    def do_GET(s):
##        Log("do_GET={}".format(repr(s)))
##        Log("do_GET={}".format(repr(dir(s))))
        s.answer_request(True)
 
    def log_message(self, format, *args):
        ##Disable the BaseHTTPServer log."""
        return
    
    def answer_request(self, sendData):
##        Log ("answer_request start...")
        global g_currentprocessor

        stop_event = self.stop_event
        seek_forward_event = self.seek_forward_event

        try:

            #Pull apart request path
            request_path=self.path[1:] 
            querystring=request_path            
            request_path=re.sub(r"\?.*","",request_path)
##            Log("request_path='{}'".format(repr(request_path)))
            
            #If a request to stop is sent, shut down the proxy
            if request_path.lower()=="stop":# all special web interfaces here
                Log('request_path.lower()=="stop"')
                sys.exit()
                return
            
            if request_path.lower()=="favicon.ico":
                Log( 'dont have no icon here, may be in future')
                self.wfile.close()
                return
            
            if request_path.lower() == "sendvideopart":
                self.send_response(200)
                rtype="video/MP2T"  #default type could have gone to the server to get it.
##                rtype="flv-application/octet-stream" 
                self.send_header("Content-Type", rtype)
                self.send_header("Connection", 'close') #needed in kodi 18
                self.end_headers()
                initDone = True
                videourl = self.decode_videoparturl(querystring.split('?')[1])
                if g_currentprocessor:
                    g_currentprocessor.sendVideoPart(videourl, self.wfile)
##                Log("sendvideopart finished")
                return

            initDone=False

            try: 
                (
                    name
                    ,url
                    , proxy
                    , use_proxy_for_chunks
                    , maxbitrate
                    , simpledownloader
                    , auth
                    , streamtype
                    , swf
                    , callbackpath
                    , callbackparam
                    , download_path
                    , initial_bitrate
                    , allow_upscale
                    , allow_downscale
                    , always_refresh_m3u8
                    , downscale_threshhold
                    , upscale_threshhold
                    , upscale_penalty
                    , pre_cache_size_max
                    , description
                    , host_name
                    , port_number
                 ) = self.decode_url(request_path)
            except:
                return

            if IsNone(streamtype):
                streamtype='HLSRETRY'

            if streamtype in ['HLSRETRY', 'HLSRETRYSEEK']:
                from HLSDownloaderRetry import HLSDownloaderRetry
                downloader=HLSDownloaderRetry()

                if not downloader.init(
                      url = url
                    , stop_playing_event = stop_event
                    , seek_forward_event = seek_forward_event
                    , maxbitrate = maxbitrate
                    , download_path = download_path
                    , auth = auth
                    , initial_bitrate = initial_bitrate
                    , allow_upscale = allow_upscale
                    , allow_downscale = allow_downscale
                    , always_refresh_m3u8 = always_refresh_m3u8
                    , downscale_threshhold = downscale_threshhold
                    , upscale_threshhold = upscale_threshhold
                    , upscale_penalty = upscale_penalty
                    , pre_cache_size_max = pre_cache_size_max
                    ):
                    raise Exception('{} init failed'.format(repr(streamtype)))
                    
                srange,framgementToSend=(None,None)
                self.send_response(200)
                rtype="flv-application/octet-stream"  #default type could have gone to the server to get it.
                self.send_header("Content-Type", rtype)
                srange=None
                
##            if streamtype=='HDS':
##
##                print 'Url received at proxy',url,proxy,use_proxy_for_chunks,maxbitrate
##
##                #Send file request
##                #self.handle_send_request(download_id,file_url, file_name, requested_range,download_mode ,keep_file,connections)
##                
##                downloader=None
##                #downloader=g_downloader
##                
##                if not downloader or downloader.live==True or  not (downloader.init_done and downloader.init_url ==url):
##                    from f4mDownloader import F4MDownloader
##                    downloader=F4MDownloader()
##                    if not downloader.init(
##                        self.wfile
##                        , url
##                        , proxy
##                        , use_proxy_for_chunks
##                        , stop_event
##                        , maxbitrate
##                        , auth
##                        , swf
##                        ):
##                        raise Exception('HDS.url failed to play\nServer down? check Url.')
####                    g_downloader=downloader
##                    print 'init...' 
##                
##                enableSeek=False
##                requested_range=self.headers.getheader("Range")
##                if IsNone(requested_range): requested_range=""
##                srange, erange=(None,None)
##                
##                            
##                if downloader.live==False and len(requested_range)>0 and not requested_range=="bytes=0-0": #we have to stream?
##                    enableSeek=True
##                    (srange, erange) = self.get_range_request(requested_range, downloader.total_frags)
##                
##                enableSeek=False ##disabled for time being, couldn't find better way to handle
##                
##                framgementToSend=0
##                inflate=1815002 #(6526684-466/3)#*373/downloader.total_frags# 4142*1024*243/8/40 #1#1024*1024
##                if enableSeek:
##                    #rtype="video/x-flv" #just as default
##                    self.send_response(206)
##                    rtype="flv-application/octet-stream" 
##                    self.send_header("Content-Type", rtype)
##                    self.send_header("Accept-Ranges","bytes")
##                    print 'not LIVE,enable seek',downloader.total_frags
##                    
##                    totalsize=downloader.total_frags*inflate
##                    
##                    framgementToSend=1#downloader.total_frags
##                    erange=srange+framgementToSend*inflate
##                    if erange>=totalsize:
##                        erange=totalsize-1
##                    
##                    crange="bytes "+str(srange)+"-" +str(int(erange))+"/*"#+str(totalsize)#recalculate crange based on srange, portionLen and content_size 
##                    print srange/inflate,erange/inflate,totalsize/inflate
##                    self.send_header("Content-Length", str(totalsize))
##                    self.send_header("Content-Range",crange)
##                    etag=self.generate_ETag(url)
##                    self.send_header("ETag",etag)
##                    print crange
##                    self.send_header("Last-Modified","Wed, 21 Feb 2000 08:43:39 GMT")
##                    self.send_header("Cache-Control","public, must-revalidate")
##                    self.send_header("Cache-Control","no-cache")
##                    self.send_header("Pragma","no-cache")
##                    self.send_header("features","seekable,stridable")
##                    self.send_header("client-id","12345")
##                    self.send_header("Connection", 'close')
##                else:
##                    self.send_response(200)
##                    rtype="flv-application/octet-stream"  #default type could have gone to the server to get it.
##                    self.send_header("Content-Type", rtype)
##                    srange=None
                    
##            elif streamtype=='SIMPLE' or simpledownloader :
##                from interalSimpleDownloader import interalSimpleDownloader
##                downloader=interalSimpleDownloader();
##                if not downloader.init(
##                    self.wfile
##                    , url
##                    , proxy
##                    , stop_event
##                    , maxbitrate
##                    ):
##                    raise Exception('SIMPLE.url failed to play\nServer down? check Url.')
##                srange,framgementToSend=(None,None)
##                self.send_response(200)
##                rtype="flv-application/octet-stream"  #default type could have gone to the server to get it.
##                self.send_header("Content-Type", rtype)
##                srange=None

##            elif streamtype=='TSDOWNLOADER':
##                from TSDownloader import TSDownloader
##                downloader=TSDownloader();
##                if not downloader.init(
##                    out_stream=self.wfile
##                    , url = url
##                    , proxy = proxy
##                    , g_stopEvent = stop_event
##                    , maxbitrate = maxbitrate
##                    ):
##                    raise Exception('TS.url failed to play\nServer down? check URL')
##                srange,framgementToSend=(None,None)
##                self.send_response(200)
##                rtype="video/mp2t"  #default type could have gone to the server to get it.
##                self.send_header("Content-Type", rtype)
##                srange=None

##            elif streamtype=='HLS':
##                from hlsDownloader import HLSDownloader
##                downloader=HLSDownloader()
##                if not downloader.init(
##                    self.wfile
##                    ,url
##                    ,proxy
##                    ,use_proxy_for_chunks
##                    ,stop_event
##                    ,maxbitrate
##                    ,auth
##                    ):
##                    raise Exception('HLS.url failed to play\nServer down? check Url.')
##                    
##                srange,framgementToSend=(None,None)
##                self.send_response(200)
##                rtype="flv-application/octet-stream"  #default type could have gone to the server to get it.
##                self.send_header("Content-Type", rtype)
##                srange=None



            elif streamtype in ['MP4']:
                from MP4Downloader import MP4Downloader
                downloader=MP4Downloader()

                if not downloader.init(
                      url = url
                    , stop_playing_event = stop_event
                    , seek_forward_event = seek_forward_event
                    , maxbitrate = maxbitrate
                    , download_path = download_path
                    , auth = auth
                    , initial_bitrate = initial_bitrate
                    , allow_upscale = allow_upscale
                    , allow_downscale = allow_downscale
                    , always_refresh_m3u8 = always_refresh_m3u8
                    , downscale_threshhold = downscale_threshhold
                    , upscale_threshhold = upscale_threshhold
                    , upscale_penalty = upscale_penalty
                    , pre_cache_size_max = pre_cache_size_max
                    ):
                    raise Exception('{} init failed'.format(repr(streamtype)))
                    
                srange,framgementToSend=(None,None)
                self.send_response(200)
                rtype="video/mp4"
                self.send_header("Content-Type", rtype)
                srange=None
                
            elif streamtype=='HLSREDIR':

                from HLSRedirector import HLSRedirector
                downloader=HLSRedirector()
                g_currentprocessor=downloader

                
                if not downloader.init(
                    url = url
                    , stop_playing_event = stop_event
                    , maxbitrate = maxbitrate
                    , initial_bitrate = initial_bitrate
                    , download_path = download_path
                    , host_name = host_name
                    , port_number = port_number
                   ):
                    raise Exception('HLSREDIR.url failed to play\nServer down? check Url.')
                    
                srange,framgementToSend=(None,None)
                self.send_response(200)
                rtype = "application/vnd.apple.mpegurl"  #this is "Content-Type" a normal call would have found at server
                self.send_header("Content-Type", rtype)
                srange = None
                
            self.end_headers()

            
            if srange is not None:
                srange=srange/inflate

            initDone=True

            Log(repr(self.wfile))

            if sendData:
                downloader_result = downloader.keep_sending_video(
                    self.wfile
                    , srange
                    , framgementToSend
                    )
                Log("sendData finished")

        except socket.error as error:
            if error.errno == errno.WSAECONNRESET or error.errno == errno.WSAECONNABORTED:
                if Debugging():
                    Log("socket error '{}'".format(repr(error)))
                    traceback.print_exc()
            else:
                Log("socket error '{}'".format(repr(error)))
                raise

        except Exception as inst:
            Log('answer_request exception')
            traceback.print_exc()
            if not initDone:
                xbmc.executebuiltin("XBMC.Notification(F4mProxy,%s,4000,'')"%inst.message)
                self.send_error(404)


        try:
            self.finish() 
        except:
            pass

        Log ("...answer_request end")
#__________________________________________________________________
#
    def generate_ETag(self, url):
        Log("generate_ETag(self, url):")
        md=hashlib.md5()
        md.update(url)
        return md.hexdigest()
#__________________________________________________________________
#
    def get_range_request(self, hrange, file_size):
        Log("get_range_request(self, hrange, file_size):")
        if hrange is None:
            srange=0
            erange=None
            return (srange, erange)
        try:
            #Get the byte value from the request string.
            hrange=str(hrange)
            splitRange=hrange.split("=")[1].split("-")
            srange=int(splitRange[0])
            erange = splitRange[1]
            if erange=="":
                erange=int(file_size)-1
            #Build range string
        except:
            # Failure to build range string? Create a 0- range.
            srange=0
            erange=int(file_size-1);
        return (srange, erange)
#__________________________________________________________________
#
    def decode_videoparturl(self, url):
        Log("decode_videoparturl(self, url):")
        params=urlparse.parse_qs(url)
        received_url = params['url'][0].replace('\r','')
        return received_url
#__________________________________________________________________
#
    def decode_url(self, url):
        params=urlparse.parse_qs(url)
        Log("params='{}'".format(repr(params)))
        #({'url': url, 'downloadmode': downloadmode, 'keep_file':keep_file,'connections':connections})

        received_url = params['url'][0].replace('\r','')#
        Log("received_url='{}'".format(repr(received_url)))

        name = params['name'][0]

        use_proxy_for_chunks =False
        proxy=None
        try: 
            proxy = params['proxy'][0]
            use_proxy_for_chunks =  params['use_proxy_for_chunks'][0]
        except: pass


        auth=None
        try:    auth = params['auth'][0]
        except: pass
        if IsNone(auth):
            auth=None

        if IsNone(proxy):  # proxy=='None' or proxy=='':
            proxy=None
        if use_proxy_for_chunks=='False':
            use_proxy_for_chunks=False
        simpledownloader=False
        try:
            simpledownloader =  params['simpledownloader'][0]#
            if simpledownloader.lower()=='true':
                print 'params[simpledownloader][0]',params['simpledownloader'][0]
                simpledownloader=True
            else:
                simpledownloader=False
        except: pass

        streamtype='HDS'
        try:    streamtype =  params['streamtype'][0]#            
        except: pass 
        if streamtype=='None' and streamtype=='': streamtype='HDS'

        swf=None
        try:    swf = params['swf'][0]
        except: pass        

        callbackpath=""
        try:    callbackpath = params['callbackpath'][0]
        except: pass        

        callbackparam=None
        try:    callbackparam = params['callbackparam'][0]
        except: pass                

        initial_bitrate = c.INITIAL_BITRATE
        initial_bitrate = int(params['initial_bitrate'][0])

        maxbitrate = c.MAXIMUM_BITRATE
        if initial_bitrate is None: #assume caller is using legacy code and ignore value
            initial_bitrate = int(params['maxbitrate'][0])
        else:
            maxbitrate = int(params['maxbitrate'][0])

        allow_upscale = c.ALLOW_UPSCALE
        try:    allow_upscale = params['allow_upscale'][0]
        except: pass

        allow_downscale = c.ALLOW_DOWNSCALE
        try:    allow_downscale = params['allow_downscale'][0]
        except: pass

        always_refresh_m3u8 = c.ALWAYS_REFRESH_M3U8
        try:    always_refresh_m3u8 = params['always_refresh_m3u8'][0]
        except: pass

        downscale_threshhold = c.DOWNSCALE_THRESHHOLD
        try:    downscale_threshhold = params['downscale_threshhold'][0]
        except: pass

        upscale_threshhold = c.UPSCALE_THRESHHOLD
        try:    upscale_threshhold = params['upscale_threshhold'][0]
        except: pass

        upscale_penalty = c.UPSCALE_PENALTY
        try:    upscale_penalty = params['upscale_penalty'][0]
        except: pass

        pre_cache_size_max = c.DEFAULT_PRE_CACHE_SIZE_MAX
        try:    pre_cache_size_max = params['pre_cache_size_max'][0]
        except: pass

        description = c.DEFAULT_DESCRIPTION
        try:    description = params['description'][0]
        except: pass

        host_name = None
        try:    host_name = params['host_name'][0]
        except: pass

        port_number = None
        try:    port_number = params['port_number'][0]
        except: pass
        
        download_path = None
        try:    download_path = params['download_path'][0]
        except: pass
        if IsNotNone(download_path):
            initial_bitrate = c.MAXIMUM_BITRATE_FOR_DOWNLOADS
            maxbitrate = c.MAXIMUM_BITRATE_FOR_DOWNLOADS
            allow_upscale = False #never upscale

##        # make sure caching does not take too long; else player will give up
##        # can test by combining a low bitrate stream with a large cache size
##        Log("pre_cache_size_max='{:,}'".format(pre_cache_size_max))
##        Log("pre_cache_size_max='{:,}'".format(initial_bitrate * c.PRE_CACHE_SIZE_BITRATE_MAX_FACTOR))
##        pre_cache_size_max = min(pre_cache_size_max, initial_bitrate * c.PRE_CACHE_SIZE_BITRATE_MAX_FACTOR)
##        Log("final pre_cache_size_max='{:,}'".format(pre_cache_size_max))

        return (  name
                , received_url
                , proxy
                , use_proxy_for_chunks
                , maxbitrate
                , simpledownloader
                , auth
                , streamtype
                , swf
                , callbackpath
                , callbackparam
                , download_path
                , initial_bitrate
                , allow_upscale
                , allow_downscale
                , always_refresh_m3u8
                , downscale_threshhold
                , upscale_threshhold
                , upscale_penalty
                , pre_cache_size_max
                , description
                , host_name
                , port_number
                )   
#__________________________________________________________________
#
    """
   Sends the requested file and add additional headers.
   """
class Server(HTTPServer):
    """HTTPServer class with timeout."""
    def get_request(self):
        """Get the request and client address from the socket."""
        self.socket.settimeout(5.0)
        result = None
        while result is None:
            try:
                result = self.socket.accept()
            except socket.timeout:
                pass
        result[0].settimeout(1000)
        return result
#__________________________________________________________________
#
class ThreadedHTTPServer(ThreadingMixIn, Server):
    """Handle requests in a separate thread."""
#__________________________________________________________________
#
class f4mProxy():

    def start(self
              , stop_event
              , seek_forward_event
              , name
              , port_number
              , host_name = c.HOST_NAME
              ):

        socket.setdefaulttimeout(5) #need this delay or else custom httpd will stop
        server_class = ThreadedHTTPServer
        MyHandler.protocol_version = "HTTP/1.1"
        MyHandler.start_time = datetime.datetime.now()

        threading.current_thread().name = name.encode('ascii','ignore') #name should be unicode, which will forced to ascii for thread naming
        threading.current_thread().thread_events = threading.local()
        threading.current_thread().thread_events.stop_event = stop_event
        threading.current_thread().stop_event = stop_event

        MyHandler.stop_event = stop_event
        MyHandler.seek_forward_event = seek_forward_event
       
        httpd = server_class( (host_name, port_number), MyHandler)
        while( True ):
            httpd.handle_request()
            if stop_event.isSet():
                Log("httpd stopping because of stop_event")
                break
            if monitor.waitForAbort(0.5) :
                Log("httpd stopping because of waitForAbort")
                break
            if monitor.abortRequested == True:
                Log("httpd stopping because of abortRequested")
                break
##        else:
##            Log(" f4mProxy.start 'not stop_event.isSet()' ")
        Sleep(1000) #don't close too soon
        httpd.server_close()
        Log("Proxy Stop thread='{}' port='{}:{}'".format(repr(threading.current_thread()), host_name, port_number))

#__________________________________________________________________
#
    def prepare_url(self
                    , name
                    , url
                    , host_name
                    , port_number
                    , proxy=None
                    , use_proxy_for_chunks=True
                    , maxbitrate = c.MAXIMUM_BITRATE
                    , simpleDownloader=False
                    , auth=None
                    , streamtype = 'HDS'
                    , swf = None
                    , callbackpath=""
                    , callbackparam=""
                    , download_path=""
                    , initial_bitrate = c.INITIAL_BITRATE
                    , allow_upscale = c.ALLOW_UPSCALE
                    , allow_downscale = c.ALLOW_DOWNSCALE
                    , always_refresh_m3u8 = c.ALWAYS_REFRESH_M3U8
                    , downscale_threshhold = c.DOWNSCALE_THRESHHOLD
                    , upscale_threshhold = c.UPSCALE_THRESHHOLD
                    , upscale_penalty = c.UPSCALE_PENALTY
                    , pre_cache_size_max = c.DEFAULT_PRE_CACHE_SIZE_MAX
                    , description = c.DEFAULT_DESCRIPTION
                    ):

        if initial_bitrate is None: #assume caller is using legacy code and ignore value
            initial_bitrate = maxbitrate
            
            
        url_to_this_proxy = urllib.urlencode(
                                   {
                                       'name': name.encode('utf8') #was unicode, now utf8; must decode later
                                        , 'url': url
                                        , 'proxy':proxy
                                        , 'use_proxy_for_chunks':use_proxy_for_chunks
                                        , 'maxbitrate':maxbitrate
                                        , 'simpledownloader':simpleDownloader
                                        , 'auth':auth
                                        , 'streamtype':streamtype
                                        , 'swf':swf
                                        , 'callbackpath':callbackpath 
                                        , 'callbackparam':callbackparam
                                        , 'download_path':download_path
                                        , 'initial_bitrate':initial_bitrate
                                        , 'allow_upscale':allow_upscale
                                        , 'allow_downscale':allow_downscale
                                        , 'always_refresh_m3u8':always_refresh_m3u8
                                        , 'downscale_threshhold':downscale_threshhold
                                        , 'upscale_threshhold':upscale_threshhold
                                        , 'upscale_penalty':upscale_penalty
                                        , 'pre_cache_size_max':pre_cache_size_max
                                        , 'description':description.encode('utf8')
                                        , 'host_name':host_name
                                        , 'port_number':port_number
                                   } 
                                 )
        return "http://{}:{}/{}".format(c.HOST_NAME, port_number, url_to_this_proxy)
##        link = 'http://' + c.HOST_NAME + (':%s/'%str(port)) + newurl
##        return (link) #make a url that caller then call load into player


#__________________________________________________________________
# helper function to select an unused port on the host machine
def select_unused_port(host_name=c.HOST_NAME):
##    Log("select_unused_port")
    port = c.PORT_NUMBER
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind((host_name, 0))
##        Log("sock.getsockname()='{}'".format(repr(sock.getsockname())))
        addr, port = sock.getsockname()
        try:
            sock.shutdown(socket.SHUT_RDWR)
        except:
            pass
        sock.close()
    except:
        traceback.print_exc()
##    Log("select_unused_port={}".format(port))
    return port



#__________________________________________________________________________
#
class ThreadWithStopEvent(threading.Thread):
    _stop_event = None
    def __init__(self, group=None, target=None, name=None, args=(), kwargs=None, stop_event=None):
	super(ThreadWithStopEvent,self).__init__(group=group, target=target, name=name, args=args, kwargs=kwargs)
	self.args = args
	self.kwargs = kwargs
        self._stop_event = stop_event
#__________________________________________________________________________
#
def Background_HLSDownloader(
    url
    , name
    , stop_playing_event
    , seek_forward_event
    , maximum_bitrate
    , download_path
    , initial_bitrate
    , allow_upscale
    , allow_downscale
    , always_refresh_m3u8
    , downscale_threshhold
    , upscale_threshhold
    , upscale_penalty
    , pre_cache_size_max
    ):
    Log("Background_HLSDownloader instance")
    try:
        import HLSDownloaderRetry
        downloader = HLSDownloaderRetry.HLSDownloaderRetry()
        downloader.init(
              url = url
            , stop_playing_event = stop_playing_event
            , seek_forward_event = seek_forward_event
            , maxbitrate = maximum_bitrate
            , download_path = download_path
            , initial_bitrate = initial_bitrate
            , allow_upscale = allow_upscale
            , allow_downscale = allow_downscale
            , always_refresh_m3u8 = always_refresh_m3u8
            , downscale_threshhold = downscale_threshhold
            , upscale_threshhold = upscale_threshhold
            , upscale_penalty = upscale_penalty
            , pre_cache_size_max = pre_cache_size_max
            )
        Log("Background_HLSDownloader keep sending start")
        downloader.keep_sending_video(None)
        downloader = None
    except:
        traceback.print_exc()
        raise
    finally:
        Log("End Background_HLSDownloader instance")
#__________________________________________________________________
class f4mProxyHelper():
    def __init__( self, *args, **kwargs):
        self.mplayer = None
        self.stop_event = threading.Event()
        self.seek_forward_event = threading.Event()
#__________________________________________________________________
    def playF4mLink(self
                    , url
                    , name
                    , proxy = None
                    , use_proxy_for_chunks = False
                    , maxbitrate = c.MAXIMUM_BITRATE
                    , simpleDownloader = False
                    , auth = None
                    , streamtype = 'HDS'
                    , setResolved = False
                    , swf = None
                    , callbackpath = ""
                    , callbackparam = ""
                    , iconImage="DefaultVideo.png"
                    , title_info = None
                    , download_path = None
                    , initial_bitrate = c.INITIAL_BITRATE
                    , allow_upscale = c.ALLOW_UPSCALE
                    , allow_downscale = c.ALLOW_DOWNSCALE
                    , always_refresh_m3u8 = c.ALWAYS_REFRESH_M3U8
                    , downscale_threshhold = c.DOWNSCALE_THRESHHOLD
                    , upscale_threshhold = c.UPSCALE_THRESHHOLD
                    , upscale_penalty = c.UPSCALE_PENALTY
                    , pre_cache_size_max = c.DEFAULT_PRE_CACHE_SIZE_MAX
                    , description = c.DEFAULT_DESCRIPTION
                    , host_name = c.HOST_NAME
                    , port_number = select_unused_port()
                    , mimetype = "video/mp2t"
                    ):

        mplayer = None
        try:
            Log(u"playF4mLink url='{}'".format(url))

            try:
                name = (u"{}".format(name))
                description = (u"{}".format(description))
            except UnicodeDecodeError as ex:
                Log(repr(ex))
                name =  name.decode('utf-8')
                description =  description.decode('utf-8')
            except UnicodeEncodeError as ex:
                Log(repr(ex))
                name =  name.encode('utf-8')
                description =  description.encode('utf-8')
            
            if (host_name != c.HOST_NAME): port_number = select_unused_port(host_name)

            f4m_proxy = f4mProxy()
            httpd_thread = ThreadWithStopEvent(
                stop_event= self.stop_event
                ,target = f4m_proxy.start
                ,args=(   self.stop_event
                        , self.seek_forward_event
                        , name
                        , port_number
                    )
                )
            httpd_thread.daemon = True
            httpd_thread.start() #thread will stop via self.stop_event

            url_to_play = f4m_proxy.prepare_url(
                                              name
                                            , url
                                            , proxy = proxy
                                            , use_proxy_for_chunks = use_proxy_for_chunks
                                            , maxbitrate = maxbitrate
                                            , simpleDownloader = simpleDownloader
                                            , auth = auth
                                            , streamtype=streamtype
                                            , swf = swf
                                            , callbackpath = callbackpath
                                            , callbackparam = callbackparam
                                            , download_path = download_path
                                            , initial_bitrate = initial_bitrate
                                            , allow_upscale = allow_upscale
                                            , allow_downscale = allow_downscale
                                            , always_refresh_m3u8 = always_refresh_m3u8
                                            , downscale_threshhold = downscale_threshhold
                                            , upscale_threshhold = upscale_threshhold
                                            , upscale_penalty = upscale_penalty
                                            , pre_cache_size_max = pre_cache_size_max
                                            , description = description
                                            , host_name = host_name
                                            , port_number = port_number
                                            )

            listitem = xbmcgui.ListItem(
                name
                , path=url_to_play
                , iconImage=iconImage
                , thumbnailImage=iconImage
                )
            listitem.setInfo(
                'video'
                , infoLabels={
                    'title': name
                    ,"plot": description
                    ,"plotoutline": description
                    }
                )
    
            if title_info:
                listitem.setInfo('music', title_info)
            listitem.setContentLookup(False)

            #application/x-mpegURL
            if streamtype in ['HLS','HLSRETRY','HLSRETRYSEEK', 'TSDOWNLOADER']:
##                listitem.setMimeType("video/mp2t");
##                listitem.setMimeType("mp2");
                listitem.setMimeType(mimetype)

            elif IsNone(streamtype) or streamtype in ['HDS']:
                listitem.setMimeType("flv-application/octet-stream")
            elif streamtype in ['HLSREDIR']:
                listitem.setMimeType("application/vnd.apple.mpegurl")
            elif streamtype in ['MP4']:
                listitem.setMimeType("video/mp4")
                

            if setResolved: #either we are using our f4mproxy player or built-in kodi
                return url_to_play, listitem

            Log("using MyPlayer to play url") #positive affirmation during dev/logging
            monitor = KodiMonitor()  #xbmc.Monitor() #monitor our infinite loop for app close events
            mplayer = MyPlayer()
            self.mplayer = mplayer
            mplayer.stopPlaying = self.stop_event
            xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
##            xbmc.Player().stop()
            myplaylist=xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            myplaylist.clear()

            #kodi 18 does not allow pausing video; HLSRETRYSEEK created to get around this
            retryseek_thread = None
            if streamtype in ['HLSRETRYSEEK']:
                dialog_progress = xbmcgui.DialogProgress()
                sleep_factor = min(3000,c.TIME_BEFORE_TEMP_FILE_MANIPULATION * max(maxbitrate/2000000.0, 1.1))
##                Log(repr(sleep_factor))
                dialog_progress.create(name, u"pre-loading {:,.1f} seconds of '{}'".format(sleep_factor/1000.0, name))
                download_path = Make_HLSRETRYSEEK_file(name)
                try:
                    retryseek_thread = ThreadWithStopEvent(
                        stop_event = self.stop_event
                        ,target = Background_HLSDownloader
                        ,args=(   url
                                , name
                                , self.stop_event
                                , self.seek_forward_event
                                , maxbitrate #maximum_bitrate
                                , download_path
                                , initial_bitrate
                                , allow_upscale
                                , allow_downscale
                                , always_refresh_m3u8
                                , downscale_threshhold
                                , upscale_threshhold
                                , upscale_penalty
                                , pre_cache_size_max
                            )
                        )
                    retryseek_thread.daemon = True
                    retryseek_thread.start()  #thread will stop via self.stop_event
                    #allow time for some content to be loaded into temp file
                    # minimum time required time depends on site and bitrate...best value is a guess
                    ret = 0
                    Sleep( sleep_factor )
                    while (ret < c.TEMP_FILE_MANIPULATION_ATTEMPTS) and (Size_HLSRETRYSEEK_file(download_path) < 100000):
                        if dialog_progress.iscanceled(): break
                        ret += 1
                        Sleep( sleep_factor )
                finally:
                    if dialog_progress:
                        dialog_progress.close()
                        dialog_progress = None
                        
                    
                Log("adding {} to playlist".format(repr(download_path)))
                myplaylist.add(download_path, listitem)
                
            else:
                myplaylist.add(listitem.getPath(), listitem)
            original_playing_file = listitem.getPath()

            seek_count = 0
            mplayer._seek.set()
            while mplayer.isSeeking(): #kodi 18 does not allow pausing video; HLSRETRYSEEK created to get around this
                mplayer._seek.clear()
                mplayer._seek_stop_playing.clear()
##                Log(repr(mplayer._seek.isSet()))

                Log('playing {}'.format(repr(original_playing_file)))
                mplayer.play(myplaylist)
                Sleep(500) #allow some time for playing to begin or else, when switching tween stream, will close both
                
                seek_count = seek_count + 1
                seek_to = mplayer.seek_to
                Log('seek1= {}'.format(repr(seek_to)))
                Log('seek_count= {}'.format(repr(seek_count)))
                if not(mplayer.seek_to is None) and seek_count < 5:
                    mplayer._seek.set()
                    total_time = None
                    total_time_attempts = 0
                    while total_time is None:
                        try:
                            total_time_attempts += 1
                            if total_time_attempts > 5:
                                Log('giving up')
                                break
                            if xbmc.Player().isPlaying():
                                total_time = mplayer.getTotalTime()
                                Log("isplaying={}".format(repr(total_time)))
                                break
                            else:
                                mplayer.play(myplaylist)
                            if total_time is None:
                                Log('sleeping')
                                Sleep(300)
                        except:
                            Log('except')
                            Sleep(300)                            
                            pass
                    Log("after while={}".format(repr(total_time)))
                    Log('total_time= {:,.2f}'.format(total_time))
                    seek_to = min(seek_to, total_time-1)
                    Log('     seek1= {:,.2f}'.format( seek_to ) )
                    mplayer.seekTime( seek_to )
                    #Sleep(200) #allow some time for seeking to happen
                    Log('after seek')
                    mplayer.seek_to = None
                    mplayer._seek.clear()
                    



                
                while not mplayer._seek_stop_playing.isSet():

                    current_playing_file = original_playing_file #assume we are ok
                    try:
                        if xbmc.Player().isPlaying():
                            current_playing_file = xbmc.Player().getPlayingFile()
                    except:
                        current_playing_file = None
                    try:
                        if self.seek_forward_event.isSet() :
                            self.seek_forward_event.clear()
                            seek_forward_correction_time = 1.0
                            seek_to_time = mplayer.getTime() + seek_forward_correction_time
                            Log("forcing seek forward to '{:,}' from '{:,}' ".format(seek_to_time, mplayer.getTime() ))
                            mplayer.seekTime( seek_to_time )
                    except:
                        pass
                    if (not mplayer.isPlaying() ):
                        Log("ending loop due to isPlaying()={}".format(repr(mplayer.isPlaying())))
                        break
                    if (monitor.waitForAbort( 1.0  )) or (monitor.abortRequested() == True)  :
                        Log("ending thread due to app abort")
                        mplayer._seek.clear()
                        mplayer._pause.clear()
                        mplayer.stopPlaying.set()
                        break
                    if not(current_playing_file == original_playing_file) and not(mplayer.isSeeking()) :
                        Log(repr(original_playing_file))
                        Log(repr(current_playing_file))
                        Log(repr(mplayer.isSeeking()))
                        Log('ending because play file changed')
                        self.stop_event.set()
                        mplayer._seek.clear()
                        mplayer._pause.clear()
                        mplayer._seek_stop_playing.set()

                else:
                    seek_count = 0
                    Log("end loop 'while _seek_stop_playing.isSet()' ")
                    pass


        except: # print any error during playF4mLink
            traceback.print_exc()

        finally:
            if mplayer:
                if mplayer.stopPlaying:
                    mplayer.stopPlaying.set()
            if streamtype in ['HLSRETRYSEEK']:
                try:
                    if retryseek_thread: self.stop_event.set()
                except:
                    #traceback.print_exc()
                    pass
                Sleep(c.TIME_BEFORE_TEMP_FILE_MANIPULATION)
                if not mplayer.isPaused():
                    #allow temp file to stay if play was paused
                    DeleteCacheFile(download_path)
                else:
                    Log('player paused. File will be delted later')

        return True
#__________________________________________________________________
#
class KodiMonitor(xbmc.Monitor):
    def __init__(self, **kwargs):
        xbmc.Monitor.__init__(self)
        #Log("self.abortRequested='{}'".format(repr(self.abortRequested)))
    def onNotification(self, sender, method, data):
        pass
##        import json
##        Log("Kodi_Monitor: sender %s - method: %s  - data: %s" % (sender, method, data))
##        data = json.loads(data)
##        Log("data='{}'".format(repr(data)))
        
#__________________________________________________________________
#
class MyPlayer(xbmc.Player):
    stopPlaying = None #threading.Event()
##    seeking = threading.donotsearchforthis.Event() #prevent infinite loop in overridden seek event
    _seek = None
    _pause = None
    _seek_stop_playing = None
    seek_to = None
    def __init__( self, *args, **kwargs):
        #xbmc.Player.__init__(self, *args)
        super(MyPlayer,self).__init__(args, kwargs)
        self._seek = threading.Event() #prevent infinite loop in overridden seek event
        self._pause = threading.Event()
        self._seek_stop_playing = threading.Event()
##    def play(self, url):
####        self.stopPlaying.set()
####        self.seeking.clear()
##        Log('Now im playing...{}'.format(url))

    def isPaused(self):
        return self._pause.isSet()

    def isSeeking(self):
        return self._seek.isSet()
    
    def onPlayBackPaused(self):
        Log('onPlayBackPaused')
        self._pause.set()

    def onPlayBackResumed(self):
        Log('onPlayBackResumed')
        self._pause.clear()

    def stop(self):
        Log('warning stop')
        xbmc.Player().stop()
        
##    def play(self, *args, **kwargs):
##        Log('Now im playing kwargs...{}'.format(repr(kwargs)))
##        Log('Now im playing args  ...{}'.format(repr(args)))
##        Log(repr(dir(self)))
##        if args:
##            xbmc.Player().play(*args)
##            return
##        if kwargs:
##            xbmc.Player().play(**kwrgs)
##            return
        

##        try:
##            
##            self.stopPlaying.clear()
##            Log("self.stopPlaying={}".format(self.stopPlaying))
##            myplaylist=xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
##            myplaylist.add(listitem.getPath(), listitem)
##            #xbmc.Player().play(url, listitem)
##            
##            xbmc.log("xbmc.Player().play(url, listitem)" , xbmc.LOGERROR)
##        except:
##            traceback.print_exc()
        
    def onPlayBackEnded( self ):
        Log("onPlayBackEnded")
##        self._seek_stop_playing.set()
##        self.stopPlaying.set()
##        self._seek.clear()
##        try:
##            Log("onPlayBackEnded stop_event='{}'".format(repr(self.stopPlaying)))
##            self.stopPlaying.set()
##        except:
##            traceback.print_exc()

    def onPlayBackStopped( self ):
        Log("onPlayBackStopped")
##        self._seek_stop_playing.set()
##        self.stopPlaying.set()
##            self._seek.clear()
##            self._pause.clear()
##        try:
##            Log(repr(self.isSeeking()))
##            if not self.isSeeking():
##                Log("onPlayBackStopped stop_event='{}'".format(repr(self.stopPlaying)))
##                self.stopPlaying.set()
##            else:
##                xbmc.executebuiltin('PlayerControl(Play)') #resume
##                Log(repr(self.isSeeking()))
##                self._seek.clear()
##                Log(repr(self.isSeeking()))
##                
##        except:
##            traceback.print_exc()

            
    def onPlayBackSeek( self, seek_time, seek_offset ):
        try:
            total_time = self.getTotalTime() #seconds
            current_time = self.getTime()
        except:
            total_time = 0
            current_time = 0
            
        seek_time = (seek_time) / 1000.0 #seconds
        diff_seek_current = abs(seek_time - current_time)
        Log("seek_offset={}".format(repr(seek_offset)))
        Log("diff_seek_current={}".format(repr(diff_seek_current)))
        Log("onPlayBackSeek (ms): getTotalTime= {:,.2f} time_to_seek_to= {:,.2f} get_time= {:,.2f}".format(total_time, seek_time, current_time ) )
        try:
            Log("self.seek_to={} self.isSeeking={}".format(repr(self.seek_to),repr(self._seek.isSet())))
            Log("cur>total={}, seek>total={}".format((current_time > total_time) , (seek_time > total_time) ) )
            if (self.seek_to is None) and (not self.isSeeking()) and (current_time > total_time) and (seek_time > total_time) :
                seek_to = max(seek_time, 0) #make sure a positive number is end result
                Log("seeking to: {:,.2f}  total_time= {:,.2f}".format(seek_to, total_time))
                if (seek_to > 0)  and  ( seek_to >  total_time) :
                    self.seek_to = seek_to
                    self._seek.set()
                    self._seek_stop_playing.set()
                    self.stop()
                else:
                    self.seek_to = None
                    pass #normal code can handle backwards and up to previously normal end
##            Sleep(1000) #milliseconds                
##                self._seek.clear()
##            self.seekTime(seek_to)
                
##            self._pause.set()
##            xbmc.executebuiltin('PlayerControl(Play)') #pause
##            Sleep(1000) #milliseconds
##            self._seek.clear()
##            self._pause.clear()
##            xbmc.executebuiltin('PlayerControl(Play)') #resume
        except:
            traceback.print_exc()
            pass        
#__________________________________________________________________
#

