#-*- coding: utf-8 -*-
'''
Constants and stuff
'''
import random
import sys
import os.path
import unicodedata
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

PY3 = sys.version_info >= (3, 0)
PY2 = not PY3

##xbmc.log(repr(sys.path),xbmc.LOGNONE)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
##xbmc.log(repr(sys.path),xbmc.LOGNONE)

if   PY3: from xbmcvfs import translatePath
elif PY2: from xbmc    import translatePath

if   PY3: from xbmcvfs import makeLegalFilename
elif PY2: from xbmc    import makeLegalFilename

if PY3: text_type = str  
if PY2: text_type = unicode #this keyword will raise error in PY3

import importlib
if PY2: from imp import reload
if PY3: from importlib import reload

import io
if PY2: import StringIO
if PY3: StringIO = io.StringIO

if PY2: import Queue
if PY3: import queue as Queue

if PY2: import cookielib
if PY3:     import http.cookiejar as cookielib

if PY2: import BaseHTTPServer
if PY3: import http.server as BaseHTTPServer

if PY2: import SocketServer
if PY3: import socketserver as SocketServer

if PY2: from urllib2 import urlparse    
if PY3: from urllib import parse as urlparse

if PY2: from urllib import urlencode
if PY3: from urllib.parse import urlencode

if PY2: from urllib2 import unquote
if PY3: from urllib.parse import unquote

if PY2: from urllib import unquote_plus
if PY3: from urllib.parse import unquote_plus

if PY2: from urllib2 import quote
if PY3: from urllib.parse import quote

if PY2: from urllib import quote_plus
if PY3: from urllib.parse import quote_plus

if PY2: import urllib2
if PY3: import urllib.error as urllib2

if PY2: import SocketServer
if PY3: import socketserver as SocketServer

if PY2: from HTMLParser import HTMLParser
if PY3: from html.parser import HTMLParser

html_parser = HTMLParser()

#below only for video addons - don't share
##from url_dispatcher import URL_Dispatcher
##url_dispatcher = URL_Dispatcher()

if PY2: from HTMLParser import HTMLParser
if PY3: from html.parser import HTMLParser

#this_addon = xbmcaddon.Addon()
this_addon = xbmcaddon.Addon('script.video.F4mProxy')
addon_id = str(this_addon.getAddonInfo('id'))
##DEBUG = (this_addon.getSetting('debug').lower() == "true")


LOGNONE = xbmc.LOGNONE
LOGWARNING = xbmc.LOGWARNING
LOGNOTICE = 11
LOGERROR = xbmc.LOGERROR

QUESTION_MARK_SUBSTITUTE = unicodedata.lookup('FULLWIDTH QUESTION MARK')

HOST_NAME = 'localhost'
PORT_NUMBER = 55334

MAXIMUM_BITRATE_FOR_DOWNLOADS = 999999999

HTTP_TIMEOUT = 90

#HLS DOWNLOADER RETRY
INITIAL_BITRATE = 5000000
MAXIMUM_BITRATE = 5000000
ALLOW_UPSCALE = False
UPSCALE_THRESHHOLD = 30
UPSCALE_PENALTY = 30
ALWAYS_REFRESH_M3U8 = False
ALLOW_DOWNSCALE = False
DOWNSCALE_THRESHHOLD = 2
MINIMUM_BITRATE = 1000

DEFAULT_DESCRIPTION = ''
DEFAULT_PRE_CACHE_SIZE_MAX = 0 #no cache by default
#player will give up if caching is taking too long; avoid this by adjusting
#cache size relative to bitrate such that player only has to wait PRE_CACHE_SIZE_BITRATE_MAX_FACTOR seconds
PRE_CACHE_SIZE_BITRATE_MAX_FACTOR = 2

#HACKS: kodi crashes if I ALLOW_UPSCALE when more than this
KODI_CRASH = int(2.9*1000*1000)
MAX_NOTHING_PLAYING_EXCEPTIONS = 4 # often getPlayingFile will return a 'nothing is playing' exception instead of True/False

DEFAULT_SLEEP_TIME = 444 # milliseconds; how long to sleep before asking for a new M3u8 file                    
MIN_SLEEP_TIME     = 101 # milliseconds; minimum

DEFAULT_MINIMUM_FREE_DISK_SPACE = 100 #MB
DEFAULT_RECORD_MINUTES = 240

DEFAULT_SLEEP_INTERVAL_STEP = 50

TEMP_CACHE_FILE_FOLDER = "cache"
TEMP_CACHE_FILE_EXT = ".tmp.ts"

TIME_BEFORE_TEMP_FILE_MANIPULATION = 1000 #milliseconds
TEMP_FILE_MANIPULATION_ATTEMPTS = 5


