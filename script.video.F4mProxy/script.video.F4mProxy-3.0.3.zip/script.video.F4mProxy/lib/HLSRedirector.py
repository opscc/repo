"""
Simple HTTP Live Streaming client.

References:
    http://tools.ietf.org/html/draft-pantos-http-live-streaming-08

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

Last updated: July 22, 2012
MODIFIED BY shani to make it work with F4mProxy
"""

import subprocess, os,traceback,cookielib,re,Queue,threading
import xml.etree.ElementTree as etree
import base64
from struct import unpack, pack
import struct
import sys
import io
import os
import time
import itertools
import xbmcaddon
import xbmc
import urllib
import traceback
try:
    import urlparse
except:
    from urllib import parse as urlparse
import posixpath
import re
import hmac
import hashlib
import binascii 
import zlib
from hashlib import sha256
import cookielib
import array, random, string
import requests


from f4mUtils import constants as c
from f4mUtils.general_tools import Bool
from f4mUtils.general_tools import IsNotNone
from f4mUtils.general_tools import Log
from f4mUtils.general_tools import Sleep
from f4mUtils.general_tools import Get_URL as getUrl
from f4mUtils.general_tools import parse_m3u_tag as Parse_M3U_Tag
from f4mUtils.general_tools import Choose_M3U8_Stream


#from Crypto.Cipher import AES
'''
from crypto.cipher.aes      import AES
from crypto.cipher.cbc      import CBC
from crypto.cipher.base     import padWithPadLen
from crypto.cipher.rijndael import Rijndael
from crypto.cipher.aes_cbc import AES_CBC
'''
gproxy=None
gauth=None
nsplayer=False
callbackDRM=None
try:
    from Crypto.Cipher import AES
    USEDec=1 ## 1==crypto 2==local, local pycrypto
except:
    print ('pycrypt not available using slow decryption')
    USEDec=3 ## 1==crypto 2==local, local pycrypto

if USEDec==1:
    #from Crypto.Cipher import AES
    print ('using pycrypto')
elif USEDec==2:
    from decrypter import AESDecrypter
    AES=AESDecrypter()
else:
    from f4mUtils import python_aes
#from decrypter import AESDecrypter

iv=None
key=None
value_unsafe = '%+&;#'
VALUE_SAFE = ''.join(chr(c) for c in range(33, 127)
    if chr(c) not in value_unsafe)
SUPPORTED_VERSION=3
cookieJar=cookielib.LWPCookieJar()

#__________________________________________________________________
#
class HLSRedirector():
    global cookieJar
    """
    A downloader for f4m manifests or AdobeHDS.
    """
#__________________________________________________________________
#
    def __init__(self):
        self.init_done=False
#__________________________________________________________________
#
    def sendVideoPart(
        self
        ,URL
        ,play_on_screen_handle
        ,chunk_size=4096
        ):
        if self.last_chunk_url == URL:
            Log('first chunk gets duplicated for some reason')
            return
        self.last_chunk_url = URL
        #we are _not_ in control of playback - only sending one chunk at a time
        #   therefore don't need xbmc.Monitor()
        for video_chunk in download_chunks(URL # note: url is not the same as self.url
                                           , url_header = self.url_header
                                           , stop_event = self.stop_playing_event
                                           , dumpfile = self.download_filespec_handle):
            Log('playing {:,} sized chunk of {}'.format( len(video_chunk), repr(URL) ))
##            Log('send_back' + repr(video_chunk[0:25]).encode('utf8') )

            send_back(
                video_chunk
                , external_stream = play_on_screen_handle
                , stop_event = self.stop_playing_event
                , dumpfile = self.download_filespec_handle
                )

##        if play_on_screen_handle:
##            Log(repr(play_on_screen_handle))
##            play_on_screen_handle.close()

##
##                #Connection: close
##                if not ('connection=close' in new_url.lower()):
##                    if '|' in new_url:
##                        new_url = new_url + '&Connection=close'
##                    else:
##                        new_url = new_url + '|Connection=close'
                        
        Log("sendVideoPart done")

#__________________________________________________________________
#
    def init( self
         , url
         , stop_playing_event
         , maxbitrate
         , initial_bitrate = c.INITIAL_BITRATE
         , download_path = None
         , host_name = c.HOST_NAME
         , port_number = None
         ):

        try:

            self.download_filespec_handle = None
            self.download_path = download_path
            if IsNotNone(download_path):
                Log ("download_path='{}'".format(download_path))
                self.download_filespec_handle = open(download_path, "ab")
                self.download_path = download_path
                self.name = download_path.split(os.sep)[-1]
                    
            self.host_name = host_name
            self.port_number = port_number
            
            stop_playing_event.clear()
            self.stop_playing_event = stop_playing_event

            self.maxbitrate = maxbitrate
            self.initial_bitrate = abs(int(initial_bitrate))
            if '|' in url:

##                #Connection: close
##                if not ('connection=close' in url.lower()):
##                    if '|' in url:
##                        url = url + '&Connection=close'
##                    else:
##                        url = url + '|Connection=close'
                
                sp = url.split('|')
                url = sp[0]
                g_clientHeader = sp[1]
                g_clientHeader= urlparse.parse_qsl(g_clientHeader)
                self.url_header = g_clientHeader
                Log("header recieved now url and headers are {}{}  ".format(repr(url), repr(g_clientHeader)))

            self.url=url
            self.last_chunk_url = None
            
            return True

        except: 
            traceback.print_exc()
        
#__________________________________________________________________
#
    def keep_sending_video(self
            ,playing_onscreen_handle
            ,segmentToStart = None
            ,totalSegmentToSend=0
            ,download_path = None
        ):
        try:
            downloadInternal(
                self.url
                ,playing_onscreen_handle
                ,url_header = self.url_header
                ,maxbitrate = self.maxbitrate
                ,initial_bitrate = self.initial_bitrate
                ,stop_playing_event = self.stop_playing_event
                ,dumpfile = self.download_filespec_handle
                ,host_name = self.host_name
                ,port_number = self.port_number
                )
        except: 
            traceback.print_exc()
        Log('keep_sending_video finished')
#__________________________________________________________________
#
def download_chunks(
    URL
    , url_header
    , stop_event
    , chunk_size=4096
    , encrypted=None
    , decryptor=None
    , dumpfile=None
    ):
##    Log("download_chunks [URL='{}',chunk_size='{}', encrypted='{}',decryptor='{}',dumpfile='{}']".format(
##        URL
##        , chunk_size
##        , encrypted
##        , decryptor
##        , dumpfile
##        ))

    response = getUrl(
        URL
        , client_header = url_header
        , return_response = True
        , stream = True
        )
    if not response:
        return

    if encrypted and decryptor==3:
        chunk_size *= 32 #keep this _smaller_ when using python AES decode to avoid exponential memory copy penalty
    else:
        chunk_size *= 256
##    Log('chunk_size={:,}'.format(chunk_size))

    stop_yeilding_signal = None
    import urllib3   
    if isinstance(response, urllib3.response.HTTPResponse):  #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
        for chunk in response.stream(chunk_size, decode_content=False):
            Stop_And_Flush(
                stop_event=stop_event
                , response=response
                , chunk=None
                , dumpfile=dumpfile
                )
            stop_yeilding_signal = (yield chunk)
            if stop_yeilding_signal is not None: break
        response.release_conn()
    else:
        for chunk in response.iter_content(chunk_size=chunk_size):
            Stop_And_Flush(
                stop_event=stop_event
                , response=response
                , chunk=None
                , dumpfile=dumpfile
                )
            stop_yeilding_signal = (yield chunk)
            if stop_yeilding_signal is not None: break
        response.close()
#__________________________________________________________________
#
def validate_m3u(conn):
    ''' make sure file is an m3u, and returns the encoding to use. '''
    return 'utf8'
    mime = conn.headers.get('Content-Type', '').split(';')[0].lower()
    if mime == 'application/vnd.apple.mpegurl':
        enc = 'utf8'
    elif mime == 'audio/mpegurl':
        enc = 'iso-8859-1'
    elif conn.url.endswith('.m3u8'):
        enc = 'utf8'
    elif conn.url.endswith('.m3u'):
        enc = 'iso-8859-1'
    else:
        raise Exception("Stream MIME type or file extension not recognized")
    if conn.readline().rstrip('\r\n') != '#EXTM3U':
        raise Exception("Stream is not in M3U format")
    return enc

#__________________________________________________________________
#
def gen_m3u(url, url_header, skip_comments=True):

    response, redirected_url = getUrl(
                                      url
                                      , client_header = url_header
                                      , send_back_redirect = True
                                      )
    if not response:
        yield ''
        raise Exception("No response at url='{}'".format(url))

    for line in response.split('\n'):
        line = line.rstrip('\r\n')
        if not line: # blank line
            continue
        elif line.startswith('#EXT'): # tag
            yield line
        elif line.startswith('#'):    # comment
            if skip_comments:
                continue
            else:
                yield line
        else: # media file
            yield line

#__________________________________________________________________
#
def handle_basic_m3u(
    url
    , url_header
    , host_name
    , port_number
    ):
    global iv
    global key
    global USEDec
    global gauth
    import urlparse,urllib
    global callbackDRM
    
    seq = 1
    enc = None
    nextlen = 5
    duration = 5
    targetduration=5
    aesdone=False
    redirurl=url
    vod=False
    for line in gen_m3u(url, url_header):
##        Log(line)
        if not line.startswith('#EXT'):
            if 1==1:#not line.startswith('http'):
                line = urlparse.urljoin(url, line)
                new_url='sendvideopart?'+urllib.urlencode({'url': line})
                line = "http://{}:{}/{}".format(
                    host_name
                    , port_number
                    , new_url
                    )
        yield line+'\n'
#__________________________________________________________________
#
def Stop_And_Flush(stop_event, response=None, chunk=None, dumpfile=None):
    if stop_event and stop_event.isSet(): #if it says 'stop' then close everything
        if dumpfile:
            dumpfile.close()
            dumpfile = None
        if response:
            response.close()
    if dumpfile: # just save what needs to be saved
        if chunk:
##            Log( 'Stop_And_Flush' + repr(chunk[0:25]).encode('utf8') )
            dumpfile.write(chunk)
        dumpfile.flush()
#__________________________________________________________________
#
def send_back(
    data
    , external_stream
    , stop_event
    , dumpfile
    ):
    import errno, socket
    try:
##        Log(repr(external_stream))
        if external_stream:
            external_stream.write(data)
##        Log( 'send_back' + repr(data[0:25]).encode('utf8') )
##        Stop_And_Flush(stop_event=stop_event, response=None, chunk=data, dumpfile=dumpfile)
    except socket.error as error:
##        raise
        if error.errno == errno.WSAECONNRESET or error.errno == errno.WSAECONNABORTED:
            pass
        else:
            raise
#__________________________________________________________________
#
def downloadInternal(
    url
    , playing_onscreen_handle
    , url_header
    , host_name
    , port_number
    , stop_playing_event
    , maxbitrate
    , initial_bitrate
    , dumpfile
    ):

    (data_from_url, redirected_url) = getUrl( url
                                            , client_header = url_header
                                            , send_back_redirect = True
                                            )
    vod = ("EXT-X-PLAYLIST-TYPE:VOD" in data_from_url)
    Log(repr(vod))
    
    #when redirected, the chunklist needs to be combined with redirection
    if redirected_url: url = redirected_url  
    
    (chunklist_url, chosen_bitrate, slightly_better, slightly_worse) = Choose_M3U8_Stream(
        url
        , data_from_url
        , initial_bitrate
        , dumpfile
        , vod)
    
##    Log(repr(chunklist_url))

    recent_m3u_line = ''    
    for m3u_line in handle_basic_m3u(chunklist_url, url_header, host_name, port_number):
##        Log('writing {:,} sized chunk'.format( len(m3u_line)))
##        Log(repr(m3u_line))
#EXTM3U
#EXT-X-PLAYLIST-TYPE:EVENT
#EXT-X-TARGETDURATION:10
#EXT-X-VERSION:4
##        #always inlcude #EXT-X-PLAYLIST-TYPE:  VOD or EVENT
##        if not ('#EXT-X-PLAYLIST-TYPE' in m3u_line) and recent_m3u_line == '#EXTM3U\n':
##            send_back('#EXT-X-PLAYLIST-TYPE:EVENT\n', playing_onscreen_handle, stop_event=stop_playing_event, dumpfile=None)            
        
        send_back(m3u_line, playing_onscreen_handle, stop_event=stop_playing_event, dumpfile=None)
        recent_m3u_line = m3u_line

##    else:
##        m3u_line = '#EXT-X-ENDLIST'
##        send_back(m3u_line, playing_onscreen_handle, stop_event=stop_playing_event, dumpfile=None)
        
    if vod:
        Log("looping through vod only once")
        #break
        
##        Sleep(10000) #wait for an updated m3u8
        
#__________________________________________________________________
#
