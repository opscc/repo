#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import datetime
import json
import os
import tempfile
import threading
import time
import traceback
import sqlite3
import sys
import urllib
import urllib2
import urlparse
import xbmc
import xbmcvfs
import xbmcgui

import _strptime #because https://www.raspberrypi.org/forums/viewtopic.php?t=166912


import HLSDownloaderRetry

        
from .. import utils
from .. import constants as C
from .. import constants as c

from ..utils import Log as Log
from ..utils import Sleep as Sleep
from ..utils import get_setting as GetSetting
##from resources.lib import thread_cache

monitor = xbmc.Monitor()
       
downloads_db = C.downloadsdb


#__________________________________________________________________________
#
CMD_list ='list'
CMD_cancel = 'cancel'
CMD_download = 'download'
WEB_COMMANDS = (CMD_list,CMD_cancel,CMD_download)

ATTRIB_cmd = "command"
ATTRIB_type = 'type'
ATTRIB_name = 'name'
ATTRIB_mode = 'mode'
ATTRIB_url = 'url'
ATTRIB_url_factory = 'url_factory'
ATTRIB_path = 'download_path'
ATTRIB_repeat = 'repeat_when_available'
ATTRIB_icon_uri = 'icon_URI'

ATTRIB_return_code = 'rc'
ATTRIB_message = 'message'

SUCCESS = 0
NOT_ACTIVE = 1

DOWNLOAD_ATTRIBUTES = (ATTRIB_cmd
,ATTRIB_type
,ATTRIB_name
,ATTRIB_mode
,ATTRIB_url
,ATTRIB_url_factory
,ATTRIB_path
,ATTRIB_repeat
,ATTRIB_icon_uri)

#__________________________________________________________________________
#
def downloadVideo(url, name, mode, url_factory, icon_URI, download_path='', repeat_when_available=False):
    Log(u"DownloadVideo {}".format(repr((url, name
                                         , mode
                                         , url_factory
                                         , icon_URI
                                         , download_path
                                         , repeat_when_available)))
        , xbmc.LOGNONE
        )


    name = utils.Clean_Filename(name)
        
    if repeat_when_available:
        add_download_result = add_download(
            name = name
            , url = url
            , file_spec=download_path
            , expected_size=None
            , start_time=db_date_formatter(datetime.datetime.utcnow())
            , friendly_name = name
            , mode = mode
            , url_factory = url_factory
            , icon_URI = icon_URI
            )


    d_type = None
    attempt_count = 0
    max_attempt_count = 2
    try:

        while not d_type and (attempt_count < max_attempt_count) :

            if url and ('|' in url):
                h=dict(urlparse.parse_qsl( str(url.split('|')[1])))
                u=str(url.split('|')[0])
            else:
                h={}
                u=url
##            Log(repr((h,u)))
            if u and ('http' in u):
                resp, redirected_url = utils.getHtml(url=u, headers=h, send_back_response=True, send_back_redirect=True, method="HEAD", cache_duration=-1)
                if resp:
                    if redirected_url:
                        if not (u == redirected_url):
                            resp, redirected_url = utils.getHtml(url=u, headers=h, send_back_response=True, send_back_redirect=True, method="HEAD", cache_duration=-1)
                            url = redirected_url + utils.Header2pipestring(h)

                    if 'Content-Type' in resp.headers:
                        c_type = resp.headers['Content-Type'].lower()
                        if c_type in [
                            'video/mp4'
                            , 'application/octet-stream'
                            , 'video/mp4, application/octet-stream'
                            ]:
                            
                            d_type = C.TYPE_mp4
                            continue
                        elif c_type in [
                            'application/vnd.apple.mpegurl'
                            ,'application/x-mpegurl'
                            ,'text/plain;charset=utf-8'
                            ,'text/html; charset=utf-8'
                            ]:
                            d_type = C.TYPE_hls
                            continue
                        else:
                            Log("Unhandled content type {}".format(repr(c_type)))
            else:
                Log(u"no http in passed {} {}, must using urlfactory".format(repr(name), repr(url)))

            if d_type:
                continue
            else:
                Log(u"find url via mode {} and information url_factory {}".format(repr(mode),repr(url)))
                if url_factory:
                    queries = {'url':url_factory
                               , 'name':name
                               , 'img':icon_URI
                               , 'testmode': True
                               }
                    return_code = C.url_dispatcher.dispatch(str(mode), queries)
                    url = return_code
                else:
                    attempt_count += max_attempt_count #increment us out of loop
                    
            attempt_count += 1
    except:
        traceback.print_exc()
##        raise


    if (not d_type) and url:
        hls_download = any(x in url for x in ['.m3u8', '/hls/', 'hlsA', C.SCHEDULED_DOWNLOAD_INDICATOR ])
        if hls_download:
            d_type = C.TYPE_hls
        else:
            d_type = C.TYPE_mp4


    if (not download_path) and url_factory: #create daily name for likely webcam
        download_path = Make_download_path(
            name = name
            , include_date = True
            , file_extension = '.ts'
            )
    elif (not download_path):
        if d_type is C.TYPE_hls:
            download_path = Make_download_path(
                name = name
                , file_extension = '.ts'
                )
        elif d_type is C.TYPE_mp4:
            download_path = Make_download_path(
                name = name
                , file_extension = '.mp4'
                )
        else:
            download_path = Make_download_path(
                name = name
                )
            

    sent_data = json.dumps({
                      ATTRIB_cmd: CMD_download
                       ,ATTRIB_type: d_type
                       ,ATTRIB_name: name
                       ,ATTRIB_url: url
                       ,ATTRIB_path: download_path
                       ,ATTRIB_repeat: repeat_when_available
                       ,ATTRIB_url_factory: url_factory
                       ,ATTRIB_icon_uri: icon_URI
                       ,ATTRIB_mode : mode
                       })
    Log(repr(sent_data)
##        ,C.LOGNONE
        )


    utils.postHtml("http://127.0.0.1:{}/".format(GetSetting("download_server_port_current", int))
                   ,sent_data=sent_data
                   ,headers={
                       'Content-Type': 'application/json'
                       }
                   , cache_duration=-1
                   )

    utils.Notify(u"Downloading '{}' in background".format(name))
    
    return True
#__________________________________________________________________________
#
##@C.url_dispatcher.register(C.ROOT_STOP_DOWNLOAD, ['url','name'], ['refresh_container','rowid','desc','hq_stream'])
def Stop_Download(url,name,refresh_container=True,rowid=None,desc=None,hq_stream=None):
    Log("Stop_Download({}) start".format(  repr((url,name,refresh_container,rowid,desc,hq_stream))))
    if desc:
        name = utils.try_decode(desc,'utf8')
    else:
        name = utils.try_decode(name,'utf8')
        name = utils.Clean_Filename(name,delete_first_color=True).strip("'")

    progress_dialog = None
    stop_name = None
    obj = None
    try:
        if refresh_container == True:
            progress_dialog = utils.Progress_Dialog(C.addon_name,u"stopping '{}'".format(name))

        if hq_stream:
            delete_download(url, rowid=hq_stream)
            utils.Notify(u"Stopped scheduled '{}'".format(name))
        else:
            stop_result = utils.postHtml(
                "http://127.0.0.1:{}/".format(GetSetting("download_server_port_current", int))
                ,sent_data= json.dumps({
                            ATTRIB_cmd: CMD_cancel
                           ,ATTRIB_name: name
                           })
                       ,headers={
                           'Content-Type': 'application/json'
                           }
                       , cache_duration=-1 
                       )
            Log(repr(stop_result))
            stop_result = json.loads(stop_result)

            if stop_result[ATTRIB_return_code] == SUCCESS:
                utils.Notify(stop_result[ATTRIB_message])
            elif stop_result[ATTRIB_return_code] == NOT_ACTIVE:
                pass
            else:
                utils.Notify(u"Unknown error stopping '{}'".format(name))

    finally:
        if progress_dialog: progress_dialog.close()
    Log("Stop_Download end '{}'".format(url))

    if refresh_container == True:
        xbmc.executebuiltin("Container.Refresh")
#__________________________________________________________________________
#
##@C.url_dispatcher.register(C.ROOT_MANAGE_DOWNLOADS)
def Manage_Downloads():
    Log("Manage_Downloads start")

    one_instance_found = False
    progress_dialog_message = "Listing background tasks"
    progress_dialog = utils.Progress_Dialog(title=C.addon_name, message=progress_dialog_message)

    try:

##        utils.addDir(
##            name = '[COLOR {}]Look for Scheduled Downloads to Start[/COLOR]'.format(C.highlight_text_color)
##             ,url = C.DO_NOTHING_URL
##             ,mode = C.ROOT_SERVICE_SCAN_START
##             ,Folder = False)
        
        for scheduled_download in scheduled_downloads():
##            Log(repr(scheduled_download))
##            Log(repr(dir(scheduled_download)))
##            Log(repr(scheduled_download.keys()))
            name = scheduled_download['name']
            url  = scheduled_download['url']
            rowid = scheduled_download['id']
            icon_URI = scheduled_download[ATTRIB_icon_uri]
            desc = scheduled_download[ATTRIB_name] #pass info here so formatting cleanup not required
            one_instance_found = True

            name = u"[COLOR {}]Stop scheduled[/COLOR] '{}'".format(
                C.search_text_color
                , name.replace(C.DOWNLOAD_INDICATOR,'')
                )
            #using adddir adds error message to log; shows 'busy' indicator
            #using addownlink has right click menu; manually have to show 'busy' indicator        
            utils.addDownLink(
                name = name
                , url = url
                , mode = C.ROOT_STOP_DOWNLOAD
                , play_method = C.PLAYMODE_NO_OPTIONS
                , iconimage = str(icon_URI)
                , desc = desc
                , hq_stream = rowid  #pass info here too lazy to add other fields names
                , action = C.ROOT_STOP_DOWNLOAD
                )
    except:
        traceback.print_exc()
        utils.addDownLink(
            name = "Fatal error listing scheduled downloads"
            , url=C.DO_NOTHING_URL
            , mode = C.NO_ACTION_MODE
            )

    try:
        if GetSetting("enable_download_service", bool):    
            active_threads = utils.postHtml("http://127.0.0.1:{}/".format(GetSetting("download_server_port_current", int))
                       ,sent_data= json.dumps({
                          ATTRIB_cmd: CMD_list
                           })
                       ,headers={
                           'Content-Type': 'application/json'
                           }
                       , cache_duration=-1 
                       )
        else:
            active_threads = "[]"
        active_threads = json.loads(active_threads)
        for active_download in active_threads:
            active_download = json.loads(active_download)
            one_instance_found = True
            name = u"[COLOR {}]Stop current[/COLOR] '{}'".format(
                C.program_text_color
                , active_download[ATTRIB_name]
                )
            utils.addDownLink(
                name = name
                , url = 'fake'
                , mode = C.ROOT_STOP_DOWNLOAD
                , play_method = C.PLAYMODE_NO_OPTIONS
                , iconimage = str(active_download[ATTRIB_icon_uri])
                , desc = active_download[ATTRIB_name] #pass info here so formatting cleanup not required
                , action = C.ROOT_STOP_DOWNLOAD
                )
    except:
        traceback.print_exc()
        utils.addDownLink(
            name = "Fatal error listing threads"
            , url=C.DO_NOTHING_URL
            , mode = C.NO_ACTION_MODE
            )

    if one_instance_found == False:
        utils.addDir(
            name="Nothing downloading in background"
            , url=C.DO_NOTHING_URL
            , mode=C.ROOT_INDEX_INDEX
            )
    if progress_dialog: progress_dialog.close()

    Log("Manage_Downloads end")
    utils.endOfDirectory()

def active_downloads():
    return Manage_Downloads()
#__________________________________________________________________
#
##@C.url_dispatcher.register(C.ROOT_SERVICE_SCAN_START)  
def scan_and_start_db():
    Log("scan_and_start_db")
    #only starts if there is a camlist table
    #look at downloads table for records that are marked as persistent dowload
    #scan camlist table on matching mode + modelid
    sql_command = (
        "select downloads.*, camlist.video_url as cur_url from downloads"
        " inner join camlist on"
        "          camlist.mode == downloads.mode "
        "   and camlist.modelid == downloads.modelid"
        )
    Log("sql_command='{}'".format(sql_command))


    if GetSetting("enable_download_service", bool):    
        active_threads = utils.postHtml("http://127.0.0.1:{}/".format(GetSetting("download_server_port_current", int))
                   ,sent_data= json.dumps({
                      ATTRIB_cmd: CMD_list
                       })
                   ,headers={
                       'Content-Type': 'application/json'
                       }
                   , cache_duration=-1 
                   )
    else:
        active_threads = "[]"
    active_threads = json.loads(active_threads)
            
    downloads_conn = sqlite3.connect(downloads_db)    
    downloads_conn.row_factory = sqlite3.Row
    downDB_cursor = downloads_conn.cursor()
    downDB_cursor.execute(sql_command)
    scheduled_downloads = downDB_cursor.fetchall()

    for scheduled_download in scheduled_downloads:
##        Log(repr(scheduled_download))

        active = False
        name = scheduled_download['modelID']
        url_factory  = scheduled_download['url_factory']
        url  = scheduled_download['url']
        mode = scheduled_download['mode']
        icon_URI = scheduled_download['icon_URI']
        rowid = scheduled_download['id'] #note: sqlite3 ROWID was _not_ used because it seems to be recycled

        for active_download in active_threads:
            active_download = json.loads(active_download)
            active_name = active_download[ATTRIB_name]
            if name == active_name:
                active = True
                break

        if active:
            Log(u"active thread already exists for {}".format(repr(name)))
        else:
            if url_factory:
                downloadVideo(url=url
                              , name=name
                              , mode=mode
                              , url_factory=url_factory
                              , icon_URI=icon_URI
                              , repeat_when_available=False)
            else:
                downloadVideo(url, name, mode
                              , url_factory=None
                              , icon_URI=icon_URI
                              , repeat_when_available=False)

    Log("end scan_and_start_db")
#__________________________________________________________________________
#
class StopDownloading(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)
#__________________________________________________________________________
#
def Normalize_Filespec(filespec):
    #python can get confused with smb://
    if os.name == 'nt':
        filespec = os.path.normpath(filespec)
        if filespec.startswith("smb:"):
            filespec = filespec[4:]
        filespec = os.path.normpath(filespec)
        filespec = filespec.replace("\\\\", "\\")
        if filespec.startswith("\\") and not filespec.startswith("\\\\"):
            filespec = "\\" + filespec
        if filespec.startswith("\\\\") and (':' in filespec):
            #original path contained a port number; remove it for smb:
            filespec = re.sub(r"(\:[^\\]+)","",filespec)
    return filespec
#__________________________________________________________________________
#
def determine_download_type(url):
    download_type = None
    try:
        if '|' in url:
            url_headers = dict(urlparse.parse_qsl( url.split('|')[1] ) )
        else:
            url_headers = C.DEFAULT_HEADERS
        Log(repr((url,url_headers)))
        
        response = getResponse(url=url, headers=url_headers
                               , method=C.URL_REQUEST_HEAD)

        if response and hasattr(response, 'info'):
            if 'Content-Type' in response.headers:
                c_type = response.headers['Content-Type'].lower()
                if c_type in [
                    'video/mp4'
                    , 'application/octet-stream'
                    , 'video/mp4, application/octet-stream'
                    ]:
                    download_type = 'video/mp4'
                    
                elif c_type in [
                    'application/vnd.apple.mpegurl'
                    ,'application/vnd.apple.mpegurl; charset=utf-8'
                    ,'application/x-mpegurl'
                    ,'application/x-mpegurl; charset=utf-8'
                    ,'text/html; charset=utf-8'
                    ,'video/mp2t'
                    ,'video/mp2t; charset=utf-8'

                    ]:
                    download_type = C.HLS_TYPE_1
                else:
                    Log("Unhandled content type {}".format(repr(c_type)))
        else:
            raise Exception('Info field not in response or HEAD respose error')
            pass
    except:
        traceback.print_exc()
        try:
            if any(x in url for x in ['.m3u8', '/hls/']):
                download_type = C.HLS_TYPE_1
        except:
            raise

    return download_type



#__________________________________________________________________________
#
class HeadRequest(urllib2.Request):
    '''A Request class that sends HEAD requests'''
    def get_method(self):
       return C.URL_REQUEST_HEAD

#__________________________________________________________________________
#
def getResponse(url, headers, size=0, method=C.URL_REQUEST_GET, proxy=None):
##    Log("url={}".format(repr(url)))
##    Log("headers={}".format(repr(headers)))
    url = url.split('|')[0]
##    Log("url={}".format(repr(url)))
    response = None
    try:
        if size > 0:
            size = int(size)
            headers['Range'] = 'bytes=%d-' % size
        if method == C.URL_REQUEST_HEAD:
            request = HeadRequest(url, headers=headers)
        else:
            request = urllib2.Request(url, headers=headers)
##        proxy = "127.0.0.1:1025"
        if proxy: request.set_proxy(proxy, type='http')
        #import ssl
        #response = urllib2.urlopen(request, timeout=30, context=ssl._create_unverified_context())
        response = urllib2.urlopen(request, timeout=30)
    except:
        #pass
        traceback.print_exc()
    return response

#__________________________________________________________________________
#
def Make_download_path(name = ''
                       , include_date = False
                       , file_extension = ''
                       , folder=None
                       , multiple_per_day=True):
    Log(u"Make_download_path {}".format(
            repr((name
                 ,include_date
                 ,file_extension
                 ,folder
                 ,multiple_per_day
                 ))
             
            )
        ,C.LOGNONE
        )
    
    name = utils.Clean_Filename(name)
   
    if folder is None:
        download_folder = GetSetting("tv.download.path").decode('utf8')
        Log("Make_download_path download_path='{}'".format(repr(download_folder)))
        if download_folder in ['','None',None]:
            try:
                download_folder = xbmcgui.Dialog().browse(0, "Specify a folder to save Downloads", 'myprograms', '', False, False)
                C.addon.setSetting(id='download_path', value=download_folder)
                if not os.path.exists(download_folder): os.mkdir(download_folder)
            except:
                raise
    else:
        download_folder = folder

##    Log(repr(xbmc.validatePath(folder)))
##    xbmcvfs.mkdirs(xbmc.translatePath(folder))

    if not (folder in ['','None',None]):
        p = u''
        for a in folder.split(os.sep):
##            Log(a)
            p = p + a + os.sep
##            Log(p)
            if not os.path.exists(p):
                try:
                    os.mkdir(p)
                except:
                    pass
    
            
##    Log(download_folder)
##    if os.sep in download_folder:
##        download_folder = download_folder.replace(os.sep+os.sep, os.sep)
##    Log(download_folder)
##    if not os.path.exists(download_folder): os.mkdir(download_folder)
                
    if include_date:
        date_string = datetime.datetime.now().strftime(".%Y-%m-%d")
    else:
        date_string = ""

    download_path = None
    if multiple_per_day and name:
        append = ''
        probe_filespec = download_folder + name + date_string + append + file_extension
        if not os.path.exists(probe_filespec):
            download_path = probe_filespec
        else:
            for append in range(ord('a'),ord('z')):
                append = chr(append)
                probe_filespec = download_folder + name + date_string + append + file_extension
                if not os.path.exists(probe_filespec):
                    download_path = probe_filespec
                    break
        if not download_path: raise Exception(u"can't generate unique name for {}".format(probe_filespec))
    else:
        download_path = download_folder + name + file_extension.decode('utf8')
    
    Log(u"Make_download_path download_path='{}'".format(download_path)
##        ,C.LOGNONE
        )
##    raise Exception()
    return download_path
#__________________________________________________________________________
#
def _progress_bar_hook(downloaded, filesize, start, name=None, progress_dialog=None):

    try:
        
        percent = min((downloaded*100)/filesize, 100)
        currently_downloaded = float(downloaded) / (1024 * 1024)
        kbps_speed = int(downloaded / (time.clock() - start))

        if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
        else:               eta = 0

        kbps_speed = kbps_speed / 1024
        total = float(filesize) / (1024 * 1024)
        mbs = u"[{:20}]".format(name)
        mbs += u' %.00f MB/%.00f MB' % (currently_downloaded, total)
        e = ' %.0fKbps' % kbps_speed
        e += ' ETA:%01d' % (eta // 60)
        progress_dialog.update(percent,'',mbs + e)

##        try:
##            update_download(C.DOWNLOAD_INDICATOR+name, 'current_size', str(currently_downloaded))
##            update_download(C.DOWNLOAD_INDICATOR+name, 'current_data_rate', str(kbps_speed))
##            update_download(C.DOWNLOAD_INDICATOR+name, 'expected_end_time',   )
##        except:
##            traceback.print_exc()
##            pass

    except:
        traceback.print_exc()
        percent = 100
        progress_dialog.update(percent)
        progress_dialog.close()


###__________________________________________________________________
###
def Size_Filespec(filespec):
    size = 1
    try:
        size = os.stat(filespec).st_size
##        Log(repr(size))
        size =  os.path.getsize(filespec)
##        Log(repr(size))
    except:
        traceback.print_exc()
    return size
###__________________________________________________________________
###
def Delete_File(filespec):
#    traceback.print_stack()
    try:
        Log("deleting filespec='{}'".format(filespec))
        delete_attempt = 0
        while os.path.exists(filespec) and delete_attempt <= C.FILE_MANIPULATION_ATTEMPTS:
            delete_attempt += 1
            Sleep(C.TIME_BEFORE_FILE_MANIPULATION)
            try:
                os.remove(filespec)
            except:
                if delete_attempt == C.FILE_MANIPULATION_ATTEMPTS:
                    traceback.print_exc()
                pass
        else:
            if not os.path.exists(filespec):
                Log("{} deleted".format(repr(filespec).replace('\\\\', '\\')))
                    
    except:
        traceback.print_exc()
#__________________________________________________________________________
#
def doDownload(url, dest, progress_dialog, name, stop_event):

    start = time.clock()

    try:
        
        #url may have include headers to be passed during transaction
        headers = dict('')
        try:
            if '|' in url:
                headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
        except:
            traceback.print_exc()

        url = url.split('|')[0]
        file = dest.rsplit(os.sep, len(os.sep))[-1]

        resp = utils.getHtml(url, headers=headers, send_back_response=True, method="HEAD", size=0)
        
        if not resp:
            utils.Notify(u"Download failed: '{}'".format(url))
            return False

        try:
            if 'Content-Length' in resp.headers:
                content = int(resp.headers['Content-Length'])
            else:
                content = 0
            Log(u"Expected file size {:,} bytes for '{}'".format(content, name))
        except:
            content = 0
            traceback.print_exc()

        try:
            resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
        except:
            resumable = False
        if resumable: Log("Download is resumable: {}".format(url))

        if content < 1:
            utils.Notify(u"Unknown filesize: '{}'".format(url))
            content = 1024*1024*1024

        size = 8192*10
        mb   = content / (1024 * 1024)

        if content < size:
            size = content

        total   = 0
        errors  = 0
        count   = 0
        resume  = 0
        sleep   = 0

        Log('Download File Size : %dMB %s ' % (mb, dest))
##        Log(repr(xbmc.makeLegalFilename(dest)))
##        f = xbmcvfs.File(xbmc.makeLegalFilename(dest), 'w')
##        f = xbmcvfs.File(dest, 'w')
        
        import io
        f = io.open(dest, 'w+b')
##        Log(repr((dir(f))))
##        Log(repr((f,dest)))
##        utils.Sleep(10000)
        
        chunk  = None
        chunks = []

        loop_interruptor = 0
##        resp = utils.getHtml(url, headers=headers, send_back_response=True, preload_content=False)
        
        while True:

            # kill the download if kodi monitor tells us to
            if monitor.abortRequested():
                if monitor.waitForAbort(0.1):
                    Log("shutting down '{}' download thread for '{}'".format(C.addon_id,url), xbmc.LOGNOTICE)
                    break

            if stop_event.isSet() == True:
                Log("stop_event.isSet()")
                break
            
            downloaded = total
            for c in chunks:
                downloaded += len(c)
            percent = min(100 * downloaded / content, 100)


            loop_interruptor += 13 #13 x 8192 is aprox 0.1mb
            if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS:
                loop_interruptor = 0
                _progress_bar_hook(downloaded,content,start,name,progress_dialog)

            chunk = None
            error = False

            try:
##                Log(repr((size)))
                chunk  = resp.read(size)
##                Log(repr(len(chunk)))
                if not chunk:
##                    Log('not chunk')
                    if percent < 99:
                        error = True
                    else:
##                        Log(repr(len(chunks)))
                        while len(chunks) > 0:
                            c = chunks.pop(0)
                            f.write(c)
                            del c

                        f.close()
                        Log( u'download complete'.format(dest))
                        return True

            except Exception as e:
                traceback.print_exc()
                error = True
                sleep = 10
                errno = 0

                if hasattr(e, 'errno'):
                    errno = e.errno
                    Log(repr(errno))

                if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                    pass

                if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                    errors = 10 #force resume
                    sleep  = 10

                if errno == 11001: # 'getaddrinfo failed'
                    errors = 10 #force resume
                    sleep  = 10

            if chunk:
                errors = 0
                chunks.append(chunk)
##                Log(repr((size,len(chunk))))
                if len(chunks) > 5:
                    c = chunks.pop(0)
                    f.write(c)
                    total += len(c)
                    del c

            if error:
                errors += 1
                count  += 1
                utils.Sleep(sleep*1000)

            if (resumable and (resume > 10)) or (errors >= 50) :
                if (not resumable and (resume > 10)  ) or resume >= 10:
                    #Give up!
                    Log ('%s download canceled - too many error while downloading' % (dest))
                    f.close()
                    return False

                resume += 1
                errors  = 0

                if resumable:
                    chunks  = []
                    #create new response
##                    Log ('Download resumed attempt #(%d) %s' % (resume, dest) )
                    #resp = getResponse(url, headers, total)
                    resp = utils.getHtml(url, headers=headers, send_back_response=True, preload_content=False, start_point=total)
##                    Log ('Download 2 resumed (%d) %s' % (resume, dest) )
                else:
                    #use existing response
                    pass

    except:
        traceback.print_exc()
        raise
    finally:
        try:
            if resp:
                resp.release_conn()
                resp.close()
        except:
            pass


#__________________________________________________________________________
#
class MP4Downloader(object):
    def __init__(
        self
        , name
        , stop_playing_event
        , download_path
        , url
        ):
        self.name = name
        self.stop_playing_event = stop_playing_event
        self.download_path = download_path
        self.url = url

    def keep_sending_video( self ) :

        url = self.url
        dest = self.download_path
        name = self.name
        stop_playing_event = self.stop_playing_event

        url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on

        name = utils.Clean_Filename(name)
        Log(repr(name))

        bare_path = Make_download_path() #I want to start with download loacation before crating subfolders

##        Log(repr(self.download_path))
        #self.download_path = dest[0 : len(dest) - len(dest.rsplit(os.sep, 1)[-1]) -1]
        #Log(repr(self.download_path))
##        self.download_path = Normalize_Filespec(self.download_path)
##        Log(repr(self.download_path))
        folder = self.download_path[0 : len(dest) - len(dest.rsplit(os.sep, 1)[-1]) ]
##        Log(repr(self.download_path))
        download_path = Make_download_path(folder=folder) #now create the rest

        progress_dialog = xbmcgui.DialogProgressBG()
        progress_dialog.create(C.addon_name,name[:50])

##        Log(download_path)
        tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
##        Log(tmp_file)
##        tmp_file = xbmc.makeLegalFilename(tmp_file)
##        Log(tmp_file)
        
        start = time.clock()
        downloaded = None
        try:
##            Log("url='{}'".format(url))
            downloaded = doDownload(url, tmp_file, progress_dialog, name, stop_playing_event)
##            return
            if downloaded:
                Log(u"Clean_Filename(name)='{}'".format(utils.Clean_Filename(name,include_square_braces=False)))
                #vidfile = xbmc.makeLegalFilename(download_path) + utils.Clean_Filename(name, include_square_braces=False) + u".mp4"
                vidfile = download_path + utils.Clean_Filename(name, include_square_braces=False)
##                Log(repr(vidfile.endswith(u".mp4")))
                if not vidfile.endswith(u".mp4"):
                    vidfile +=u".mp4"
##                Log(u" vidfile='{}'".format(vidfile))
##                Log(u"tmp_file='{}'".format(tmp_file))
                
                try:
                    os.rename(Normalize_Filespec(tmp_file), Normalize_Filespec(vidfile))
                    return vidfile
                except Exception as e:
##                    traceback.print_exc()
                    try:
                        nfn = vidfile + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S") + '.mp4'
                        Log(u"vidfile='{}'".format(nfn))
##                        os.rename(tmp_file, nfn)
                        os.rename(Normalize_Filespec(tmp_file), Normalize_Filespec(nfn))
                        return nfn
                    except Exception as e2:
                        traceback.print_exc()
                        utils.Notify(msg = u"'{}' name:{} tmp:{}".format(e2,vidfile,tmp_file), duration=20000)
                        return tmp_file
            else:
                raise StopDownloading('Stopped Downloading')
        except StopDownloading:
            try:
                Delete_File(tmp_file)
                #pass
            except:
                traceback.print_exc()
        except:
            traceback.print_exc()
            try:
                Delete_File(tmp_file)
                #pass
            except:
                traceback.print_exc()
        finally:
            if progress_dialog:
                progress_dialog.close()
            progress_dialog = None
#__________________________________________________________________________
#
def Background_MP4Downloader(url, name, mode, url_factory, icon_URI, download_path, stop_event, rowid):
    Log(u"Background_MP4Downloader {}".format(repr((url
                                                    , name
                                                    , mode
                                                    , url_factory
                                                    , icon_URI
                                                    , download_path
                                                    , stop_event
                                                    , rowid
                                                    ))))
    name = utils.Clean_Filename(name)

    Log("Background_MP4Downloader instance")
    downloader = MP4Downloader(
          name = name
        , url = url
        , stop_playing_event = stop_event
        , download_path = download_path
        )
    Log("Background_MP4Downloader keep sending start")
        
    downloader.keep_sending_video()

    Log("Background_MP4Downloader keep sending finish")
    downloader = None
    Stop_Download(url=url, name=name, refresh_container=False, rowid=rowid, desc=name)
#__________________________________________________________________________
#
def Background_HLSDownloader(url, download_path, name, stop_event, repeat_when_available, rowid):
 
    progress_dialog = xbmcgui.DialogProgressBG()
    progress_dialog.create(C.addon_name,name[:50])

    Log(name
        ,C.LOGNONE
        )

    Log(download_path
        ,C.LOGNONE
        )

##    Make_download_path('', False, '', profileDir, False)
##    if not os.path.exists(C.profileDir):
##        Log(profileDir
##            ,C.LOGNONE
##            )
##        os.makedirs(C.profileDir)
    
##    download_path2 = Make_download_path(download_path)
##    Log(download_path2
##        ,C.LOGNONE
##        )    
    try:
        play_profile         = 'profile_00' #the download profile
        initial_bitrate      = int(GetSetting(play_profile + "_" + "initial", float) * 1000 * 1000)
        maximum_bitrate      = int(GetSetting(play_profile + "_" + "maximum", float) * 1000 * 1000)
        allow_upscale        = GetSetting(play_profile     + "_" + "allow_upscale")
        allow_downscale      = GetSetting(play_profile     + "_" + "allow_downscale")
        always_refresh_m3u8  = GetSetting(play_profile     + "_" + "always_refresh_m3u8")
        downscale_threshhold = GetSetting(play_profile     + "_" + "downscale_threshhold", int)
        upscale_threshhold   = GetSetting(play_profile     + "_" + "upscale_threshhold", int)
        upscale_penalty      = GetSetting(play_profile     + "_" + "upscale_penalty", int)
        pre_cache_size_max   = int(GetSetting(play_profile + "_" + "pre_cache_size_max", float)* 1000 * 1000)

        stop_playing_event = stop_event
        seek_forward_event = threading.Event()

        Log("Background_HLSDownloader instance")
        downloader = HLSDownloaderRetry.HLSDownloaderRetry()
        downloader.init(
              url = url
            , stop_playing_event = stop_playing_event
            , seek_forward_event = seek_forward_event
            , maxbitrate = maximum_bitrate
            , download_path = download_path
            , initial_bitrate = initial_bitrate
            , allow_upscale = allow_upscale
            , allow_downscale = allow_downscale
            , always_refresh_m3u8 = always_refresh_m3u8
            , downscale_threshhold = downscale_threshhold
            , upscale_threshhold = upscale_threshhold
            , upscale_penalty = upscale_penalty
            , pre_cache_size_max = pre_cache_size_max
            )

        Log("Background_HLSDownloader keep sending start")
        downloader.keep_sending_video(dest_stream=None, progress_dialog=progress_dialog)
        downloader = None

        Log("Background_HLSDownloader keep sending finish")

        #delete zero byte downloads
##        Log(repr(download_path))
##        Log(repr(Size_Filespec(download_path)))
        if Size_Filespec(download_path) == 0:
            Delete_File(download_path)
            
        Stop_Download(url, name, False) #let service know we are finished and active item should be delted

    except:
        traceback.print_exc()
##        raise
    finally:
        progress_dialog.close()
    
#__________________________________________________________________
#
def make_downloads_db():

    with sqlite3.connect(downloads_db) as downloads_conn:

        downDB_cursor = downloads_conn.cursor()

        sql_command = ( #basic table
            "CREATE TABLE IF NOT EXISTS downloads ("
            "  id INTEGER PRIMARY KEY "
            ", name"
            ", url"
            ", file_spec"
            ", expected_size NUMERIC DEFAULT NULL"
            ", start_time"
            ", update_time"
            ", current_size"
            ", current_data_rate"
            ", expected_end_time"
            ", mode INTEGER DEFAULT NULL"
            ", modelID TEXT DEFAULT NULL"
            ", url_factory TEXT DEFAULT NULL"
            ", icon_URI TEXT DEFAULT NULL"        
            #", thread_object TEXT DEFAULT NULL"
            ");"
            )
##        Log("sql_command='{}'".format(sql_command) )#, C.LOGNONE)
        downDB_cursor.executescript(sql_command)

        sql_command = (
            'CREATE UNIQUE INDEX "idx_url_factory" ON "downloads" (  '
            '"url_factory"	ASC'
                ');'
            )
        try: #update schema with this constraint
            downDB_cursor.executescript(sql_command)
        except sqlite3.OperationalError as ex:
            if not ex.message.startswith('index idx_url_factory already exists'):  #not sure if english text will always be same
                raise
        
        try: #update schema with this column
            downDB_cursor.executescript("ALTER TABLE downloads ADD COLUMN mode INTEGER DEFAULT NULL;")
        except sqlite3.OperationalError as ex:
            if not ex.message.startswith('duplicate column name'):  #not sure if english text will always be same
                raise

#__________________________________________________________________
#
def db_date_formatter(date):
    return date.isoformat() #strftime("%Y%m%d.%H%M%S")
#__________________________________________________________________
#
def clean_downloads(days_too_old=1.0):
    Log("clean_downloads(days_too_old={}) start".format(days_too_old))
    return
    raise NotImplementedError('clean_downloads')
    too_old_day  = db_date_formatter(datetime.datetime.utcnow()-datetime.timedelta(days_too_old))
    too_old_hour = db_date_formatter(datetime.datetime.utcnow()-datetime.timedelta((days_too_old/24.0)))
    sql_command = (
        "SELECT name, url FROM downloads "
        "WHERE "
        "    (start_time  < '{}')"
        "    OR ( "
        "         (update_time < '{}') "
        "         AND "
        "         ( substr(file_spec,length(file_spec)-(length('.ts')-1)) != '.ts')"
	"	);"
        ).format(too_old_day,too_old_hour)
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    try:
        downloads_conn = sqlite3.connect(downloads_db)
        downDB_cursor = downloads_conn.cursor()
        downDB_cursor.execute(sql_command)
        cleanable_items = downDB_cursor.fetchall()
        for name, url in cleanable_items:
            Log("cleaning name='{}'".format(name) )
            proxy_thread = threading.Thread(
                name="download_cleaner."+utils.Clean_Filename(name)
                ,target=Stop_Download
                ,args=(url,name,False)
                )
            proxy_thread.daemon = True
            proxy_thread.start()
    finally:
        if downloads_conn: downloads_conn.close()
        pass
    Log("clean_downloads end")
    return True
#__________________________________________________________________
#
def scheduled_downloads():
    make_downloads_db()
    scheduled = None
    sql_command = "SELECT * FROM downloads"
    with sqlite3.connect(downloads_db) as downloads_conn:
        downloads_conn.row_factory = sqlite3.Row #sqlite3 rows instead of dictionary for this call
        scheduled = downloads_conn.execute(sql_command).fetchall()
##        Log(repr(active), C.LOGNONE)
    return scheduled
#__________________________________________________________________
#
def delete_download(url, rowid=None):
    if rowid:
        sql_command = "DELETE FROM downloads WHERE id == ?"
        param = rowid
    else:
        sql_command = "DELETE FROM downloads WHERE url == ?"
        param = url
    Log("sql_command='{}' '{}'".format(sql_command, repr(param)) )#,LOGNONE)
    with sqlite3.connect(downloads_db) as downloads_conn:
        active = downloads_conn.execute(sql_command,(param,))

##    try:
##        downloads_conn = sqlite3.connect(downloads_db)
##        downloads_conn.execute(sql_command,(param,))
##        downloads_conn.commit()
##    except:
##        traceback.print_exc()
##        pass
##    finally:
##        if downloads_conn: downloads_conn.close()
##        pass
    return True
#__________________________________________________________________
#
def update_download(name, column_name, column_value):
    sql_command_1 = (
        " UPDATE downloads "
        " SET {}={} "
        " WHERE name==? "
        )
    if column_value.startswith('strftime('): # want to be able to use this function during updates
        sql_command_1 = sql_command_1.format((sanitize_sql(column_name)), column_value)
        params = (name,)
    else:
        sql_command_1 = sql_command_1.format((sanitize_sql(column_name)), '?')
        params = (column_value, name)
##    Log("sql_command_1='{}' {}".format(sql_command_1, repr(params)))
    try:
        downloads_conn = sqlite3.connect(downloads_db)
        downloads_conn.execute(sql_command_1, params)
        downloads_conn.commit()
    except:
        traceback.print_exc()
        pass
    finally:
        if downloads_conn: downloads_conn.close()
        pass
    return True
#__________________________________________________________________
#
def rename_download(name, new_name, mode, friendly_name, url_factory):
    make_downloads_db()
    sql_command_1 = (
        " UPDATE downloads "
        " SET modelid=?, url_factory=?, name=? "
        " WHERE name==? and mode==?"
    )
    #sql_command_1 = sql_command_1.format(  sanitize_sql(friendly_name), sanitize_sql(friendly_name)  )
    params = (friendly_name, url_factory, new_name, name, mode)
    Log("sql_command_1='{}'  '{}'".format(sql_command_1, params) )#,LOGNONE)
    try:
        downloads_conn = sqlite3.connect(downloads_db)
        downloads_conn.execute(
            sql_command_1
            , params
            )
        downloads_conn.commit()
    finally:
        if downloads_conn: downloads_conn.close()
        pass
#__________________________________________________________________
#
def add_download(name, url, file_spec, expected_size, start_time, mode, friendly_name, url_factory, icon_URI):
    make_downloads_db()
    sql_command = (
        "INSERT INTO downloads "
        "( name"
        ", url"
        ", file_spec"
        ", expected_size"
        ", start_time"  #note: start time is a parameter in order to force consistent formatting
        ", update_time" #record dead if something has not updated recently
        ", mode"
        ", modelID"
        ", url_factory"
        ", icon_URI"
        ") VALUES "
        "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )
    if expected_size is None:  #expected_size can be None, but I prefer to store as Null
        sql_command = sql_command.replace(", expected_size", '').replace(
              "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            , "(?, ?, ?, ?, ?, ?, ?, ?, ?)"
            )
        params = (
            sanitize_sql(name)
            , sanitize_sql(url)
            , sanitize_sql(file_spec)
            , sanitize_sql(start_time)
            , sanitize_sql(start_time)
            , mode
            , sanitize_sql(friendly_name)
            , url_factory
            , icon_URI
            )
    else:
        params = (
            sanitize_sql(name)
            , sanitize_sql(url)
            , sanitize_sql(file_spec)
            , sanitize_sql(expected_size) 
            , sanitize_sql(start_time)
            , sanitize_sql(start_time)
            , mode
            , sanitize_sql(friendly_name)
            , url_factory
            , icon_URI
            )
    Log("sql_command='{}' params={}".format(sql_command, repr(params)) )#,LOGNONE)
    with sqlite3.connect(downloads_db) as downloads_conn:
        try:
            downloads_conn.execute(sql_command, params) #sqlite3 will auto commit
        except sqlite3.IntegrityError as ex:
            if not ex.message.startswith('UNIQUE constraint failed: downloads.url_factory'):
                raise
##    raise Exception() #used during dev/debug

#__________________________________________________________________________
#
def sanitize_sql(information):
    if information:
        Log(repr(information))
        if sqlite3.complete_statement(information):
            raise sqlite3.IntegrityError
    return information #.replace("'", "''")
#__________________________________________________________________________
#
def un_sanitize_sql(information):
    return information
    #return urllib.unquote_plus(information) #todo: unsanitize info to prevent bad sql command

#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True,delete_first_color=False):
    return utils.Clean_Filename(s, include_square_braces=include_square_braces, delete_first_color=delete_first_color)

