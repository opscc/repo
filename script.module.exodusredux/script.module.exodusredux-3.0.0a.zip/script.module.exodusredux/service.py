import json
import random
import threading
import traceback
import xbmc

from lib.resources.lib import constants as C

from lib.resources.lib.constants import reload

from lib.resources.lib.modules import downloader
from lib.resources.lib.modules import downloadServer
from lib.resources.lib import utils
from lib.resources.lib.utils import Log as Log
from lib.resources.lib.utils import Sleep as Sleep
from lib.resources.lib.utils import get_setting as GetSetting


monitor = xbmc.Monitor()

#__________________________________________________________________________
#
class EndingException(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)


#__________________________________________________________________
#
def download_service(stop_event):

    try:
        download_proxy = None
        while not monitor.abortRequested():
            if stop_event.is_set():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_download_service", bool):
                if not download_proxy:
                    Log("starting download_proxy", utils.LOGNONE)
                    reload(downloadServer) #reload during development so that I dont have to restart program
                    download_proxy = downloadServer.StartListening()
                else:
                    if download_proxy._BaseServer__shutdown_request:
                        Log('internal download_proxy forcestop')
                        download_proxy.server_close()
                        Log('internal download_proxy server_close')
                        download_proxy.socket.close()
                        Log('internal download_proxy close')
                        download_proxy = None
                    if GetSetting("keepalive_download_service", bool):
                        active_threads = utils.postHtml("http://localhost:{}/".format(GetSetting("download_server_port_current", int))
                                   ,sent_data= json.dumps({
                                      downloader.ATTRIB_cmd: downloader.CMD_list
                                       })
                                   ,headers={
                                       'Content-Type': 'application/json'
                                       }
                                   )
                        Log(repr(active_threads))
                        
                    pass
            else:
                if download_proxy or download_proxy._BaseServer__shutdown_request:
                    download_proxy.shutdown()
                    download_proxy.server_close()
                    download_proxy.socket.close()
                    Log('download_proxy stopped')
                    download_proxy = None
            sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
            if sleeptime < 1: sleeptime = 1
            Log("{} monitor sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
    except EndingException as ex:
##        traceback.print_exc()
        Log(ex.value)
    except:
        traceback.print_exc()
    finally:
        try:
            if download_proxy:
                download_proxy.shutdown()
                download_proxy.server_close()
                download_proxy.socket.close()
                Log('Finally download_proxy stopped')
                download_proxy = None
        except:
            traceback.print_exc()

#__________________________________________________________________
#
if __name__ == '__main__':

    C.DEBUG = GetSetting('debug')
    threading.current_thread().name = C.addon_id+".service"

    proxy_thread_download_service = None    
    download_service_stop_event = None

    while not monitor.abortRequested():

        try:

            # start thread for enable_download_service service
            if GetSetting("enable_download_service", bool):
                try:
                    if (not proxy_thread_download_service) or (not proxy_thread_download_service.is_alive()) : # start thread
                        download_service_stop_event = threading.Event()
                        proxy_thread_download_service = threading.Thread(
                            target=download_service
                            ,args=(download_service_stop_event,)
                            ,name=C.addon_id+".download_service"
                            )
                        proxy_thread_download_service.daemon = True
                        proxy_thread_download_service.start()
                    else:
                        pass
                except:
                    traceback.print_exc()
            else:
                if proxy_thread_download_service:
                    if download_service_stop_event: download_service_stop_event.set()
                    proxy_thread_download_service = None

        except:
            traceback.print_exc()

        ## sleep then ... do some work
        sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
        if sleeptime < 1: sleeptime = 1
        if monitor.waitForAbort(sleeptime):
            Log("{} ending due to abort".format(threading.current_thread().name))
            break

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = GetSetting('debug')

    if proxy_thread_download_service:
        if download_service_stop_event: download_service_stop_event.set()
        
#__________________________________________________________________
#
