import socket
try:
    import SocketServer
except:
    import socketserver as SocketServer
    
from . import downloaderHTTPRequestHandler
import threading
from .. import  utils
import traceback

from ..constants import reload

from .. import thread_cache
from ..utils import Log as Log
from ..utils import get_setting as GetSetting
from ..utils import set_setting as SetSetting

#__________________________________________________________________________
#
# helper function to select an unused port on the host machine
def select_unused_port():

    port = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('127.0.0.1', 0))
        addr, port = sock.getsockname()
        #sock.shutdown()
        sock.close()
    except Exception as ex:
        #log('socket exception')
        traceback.print_exc()
        port = 8666
##    return 8666
    return port
#__________________________________________________________________________
#

class ThreadCacheTCPServer(SocketServer.TCPServer):
    thread_cache = thread_cache.uwcSimpleCache()
    thread_cache._identifier = '__tcpserver__'

#__________________________________________________________________________
#
def StartListening():
    try:
        # pick & store a port for the proxy service
        downloader_proxy_port = GetSetting("download_server_port", int)
        if not downloader_proxy_port > 8000:
            downloader_proxy_port = select_unused_port()
            Log("Autodetect for proxy service port selected as '{0}'".format(str(downloader_proxy_port)))
        else:
            Log("Static proxy service port selected as '{0}'".format(str(downloader_proxy_port)))
        SetSetting("download_server_port_current", downloader_proxy_port)

##        Log(repr(GetSetting("download_server_port"        , int)))
##        Log(repr(GetSetting("download_server_port_current", int)))

        reload(downloaderHTTPRequestHandler) #reload during development so that I dont have to restart program

        ##todo; relocate @C.url_dispatcher.register elements so that below is possible
        #reload(utils) #reload during development so that I dont have to restart program
        
        # configure the proxy server
        download_proxy = ThreadCacheTCPServer(
            (
                '127.0.0.1', downloader_proxy_port)
                , downloaderHTTPRequestHandler.downloaderHTTPRequestHandler
            )
        download_proxy.server_activate()
        download_proxy.timeout = 1

        # start thread for proxy server
        proxy_thread = threading.Thread(target=download_proxy.serve_forever)
        proxy_thread.daemon = True
        proxy_thread.start()

        #caller is responsible for sending shut down commands
        return download_proxy
    except:
        traceback.print_exc()
        return None

