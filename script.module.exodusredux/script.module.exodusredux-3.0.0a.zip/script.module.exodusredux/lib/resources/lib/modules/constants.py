#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''



import random
import sys
import os.path
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

PY3 = sys.version_info >= (3, 0)
PY2 = not PY3

if   PY3: from xbmcvfs import translatePath
elif PY2: from xbmc    import translatePath

this_addon = xbmcaddon.Addon()
DEBUG = (this_addon.getSetting('debug').lower() == "true")

IE_USER_AGENT = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko'
FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/{}0101 Firefox/77.0'
FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0'

OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.132 Safari/537.36 OPR/67.0.3575.97'
OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36 OPR/67.0.3575.97'
IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1'
ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.138 Mobile Safari/537.36'
ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Mobile Safari/537.36'
EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.102 Safari/537.36 Edge/18.18363'
EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36 Edge/18.18363'
CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.182 Safari/537.36'
CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.164 Safari/537.36'
##SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15'
_USER_AGENTS = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT]

USER_AGENT = FF_USER_AGENT #_USER_AGENTS[random.randint(0, len(_USER_AGENTS)-1)].format(  random.randint(1111, 7777)  )

##xbmc.log(USER_AGENT,xbmc.LOGNONE)

LOGNONE = xbmc.LOGNONE


DEFAULT_HEADERS = { 
    'DNT': '1'
    , 'Upgrade-Insecure-Requests': '1'
    , 'User-Agent': USER_AGENT  
    , 'Accept': '*/*'
    , 'Sec-Fetch-Site': 'none'
    , 'Sec-Fetch-Mode': 'navigate'
    , 'Sec-Fetch-User': '?1'
    , 'Sec-Fetch-Dest': 'document'
    , 'Accept-Encoding': 'gzip, deflate'
    , 'Accept-Language': 'en-US,en;q=0.9'
##    , 'verifypeer': 'false'
    }
    # , 'Connection': 'close'
##if DEBUG:
##    DEFAULT_HEADERS['verifypeer'] = false'
##xbmc.log(repr(DEFAULT_HEADERS),xbmc.LOGNONE)

##addon_handle = int(sys.argv[1])
addon_id = str(this_addon.getAddonInfo('id'))
addon_name = this_addon.getAddonInfo('name')
addon = this_addon
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = xbmcvfs.translatePath(rootDir)

search_text_color = 'orange' #addon.getSetting('search_text_color').lower()

WAIT_AFTER_STOP_DOWNLOAD_EVENT = 500
WAIT_BETWEEN_TEMP_FILE_REMOVE_ATTEMT = 500
MAX_AGE_OLD_DOWNLOAD = 1.1


DEFAULT_PLAYMODE = addon.getSetting('default_playmode').lower()  #allow playmode to be forced by input command, or use default from addon settings
PLAYMODE_F4MPROXY = 'f4mproxy'
PLAYMODE_INPUTSTREAM = 'inputstream'
PLAYMODE_DIRECT = 'direct'
PLAYMODE_NO_OPTIONS = "NO_OPTIONS"
PLAYMODE_VARIABLE = 'VARIABLE_MAXRES'
PLAYMODE_PROFILE_00 = 'profile_00' #the download profile
PLAYMODE_PROFILE_01 = 'profile_01'
PLAYMODE_PROFILE_02 = 'profile_02'
PLAYMODE_PROFILE_03 = 'profile_03'
VALID_PLAYMODE_PROFILES = [PLAYMODE_PROFILE_00,PLAYMODE_PROFILE_01,PLAYMODE_PROFILE_02,PLAYMODE_PROFILE_03]
DEFAULT_PROFILE_NAME = 'profile_01'

CONFIGURE_INPUTSTREAM = '9999'

NO_ACTION_MODE = '0'
ROOT_INDEX_INDEX = '0'
ROOT_INDEX_SCENES = '1'
##ROOT_STOP_DOWNLOAD = '912'

FLAG_RECURSE_NEXT_PAGES = '-1'
FLAG_USE_RESOLVER_ONLY = 'USE_RESOLVER_ONLY'

DEFAULT_NOTIFY_TIME = 2000

SPACING_FOR_TOPMOST = chr(4)
SPACING_FOR_NAMES =  '' #chr(17)
SPACING_FOR_NEXT = chr(127)



DOWNLOAD_INDICATOR = addon_id+".downlading."



DO_NOTHING_URL = 'DO_NOTHING_URL' #url is required in the adddir function, but there are moments when I don't want to set it

GC_SEARCHLOOP_ITERATIONS = 2000
GC_SEARCHLOOP_PAUSE = 10

VIDEO_NOT_AVAILABLE_WARNINGS = [
    "This video has been flagged for verification"
    ,"This page is not available in your country."
    ,"Video has been removed at the request of "
    ,"Video has been flagged"
    ,"this video is no longer available"
    ,"This Video Is Private"
    ,"this video is private."
    ,"This video does not exist."
    ]

URL_REQUEST_GET = "GET"
URL_REQUEST_HEAD = "HEAD"
URL_REQUESTS = [URL_REQUEST_HEAD,URL_REQUEST_GET]

HLS_TYPE_1 = 'f4mproxy'
HLS_TYPE_2 = 'flv-application/octet-stream'
HLS_TYPE_3 = 'application/vnd.apple.mpegurl'
HLS_TYPE_4 = 'application/x-mpegurl'
HLS_TYPE_5 = 'video/mpeg'
HLS_TYPE_6 = 'video/mp2t'
HLS_DOWNLOAD = [HLS_TYPE_1,HLS_TYPE_2,HLS_TYPE_3,HLS_TYPE_4,HLS_TYPE_5,HLS_TYPE_6]

FAVORITE_LISTING_TIMEOUT = 30 #seconds #how long to wait to discover if webcam model is online

WEBCRAWLER_THREAD_TIMEOUT = 10
MAX_WEBCRAWLER_THREADS = 60

TESTING_LIST_NAME = 'test_list' #setting.xml key containing which sites we have 'tested' and when they 'tested' successfully


#either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
# https://wiki.mozilla.org/CA/Included_Certificates
##if C.DEBUG: urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
certPath = os.path.join(os.path.join(os.path.dirname(__file__), "websocket"),"cacert.2020-10-14.pem")

profileDir = this_addon.getAddonInfo('profile')
profileDir = xbmcvfs.translatePath(profileDir) #.decode("utf-8")
if not os.path.exists(profileDir):
    os.makedirs(profileDir)
downloads_db = os.path.join(profileDir, 'downloads.db')

bad_attributes =  ['thumb'
                   , 'label'
                   , 'imdb'
                   , 'fanart2'
                   , 'imdb_id'
                   , 'metacache'
                   , 'tvdb_id'
                   , 'next'
                   , 'poster3'
                   , 'trailer'
                   #, 'tmdb'
                   , 'tmdb_id'
                   #, 'playcount' #cleared so that value can be read in from database
                   , 'poster'
                   , 'tvdb'
                   , 'banner'
                   , 'fanart']


