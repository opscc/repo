# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import threading, traceback
from resources.lib.modules.log_utils import log as Log
class Thread(threading.Thread):
    _stop_event = None
    def __init__(self, target, *args):
##        #py2
##        threading.Thread.__init__(self)
        #py3
##        super(Thread,self).__init__(target, *args)
        threading.Thread.__init__(self, target=target, args=args)
        self._stop_event = threading.Event()
        self._target = target
        self._args = args
##        Log(repr(self._target))
##        Log(repr(self._target))
    def run(self):
        try:
##            Log(repr(self._target))
##            Log(repr(self._args))
            self._target(*self._args)
        except:
            traceback.print_exc()
    def stop(self):
        self._stop_event.set()
    @property
    def stop_is_set(self):
        return self._stop_event.isSet()
    
