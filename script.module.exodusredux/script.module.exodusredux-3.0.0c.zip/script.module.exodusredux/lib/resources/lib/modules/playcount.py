# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import traceback
import xbmc
import sys
from metahandler import metahandlers
from resources.lib.indexers import episodes

from resources.lib.modules import control
from resources.lib.modules import trakt

from resources.lib.modules.log_utils import log as Log
from resources.lib.modules.log_utils import logR as LogR
from resources.lib.modules import constants as C

import sqlite3
from sqlite3 import dbapi2 as database



METAHANDLER_WATCHED   = 7
METAHANDLER_UNWATCHED = 6


def getMovieIndicators(refresh=False):
    Log(control.myName()); LogR(locals())
    try:
        if trakt.getTraktIndicatorsInfo() == True: raise Exception()
        from metahandler import metahandlers
        indicators = metahandlers_MetaData() #metahandlers.MetaData(preparezip=False)
##        LogR(indicators)
        return indicators
    except:
##        raise
        pass
    try:
        if trakt.getTraktIndicatorsInfo() == False: raise Exception()
        if refresh == False: timeout = 720
        elif trakt.getWatchedActivity() < trakt.timeoutsyncMovies(): timeout = 720
        else: timeout = 0
        indicators = trakt.cachesyncMovies(timeout=timeout)
##        LogR(indicators)
        return indicators
    except:
##        raise
        pass


def getTVShowIndicators(refresh=False):
##    Log(control.myName()); LogR(locals())
    try:
        if trakt.getTraktIndicatorsInfo() == True:
            raise Exception()
        indicators = metahandlers_MetaData()
##        LogR(indicators)
        return indicators
    except:
##        raise
        pass
    try:
        if trakt.getTraktIndicatorsInfo() == False:
            raise Exception()
        if refresh == False: timeout = 720
        elif trakt.getWatchedActivity() < trakt.timeoutsyncTVShows():
            timeout = 720
        else:
            timeout = 0
        indicators = trakt.cachesyncTVShows(timeout=timeout)
        return indicators
    except:
##        raise
        pass

def getSeasonIndicators(imdb):
    try:
        if trakt.getTraktIndicatorsInfo() == False: raise Exception()
        indicators = trakt.syncSeason(imdb)
        return indicators
    except:
        pass


def getMovieOverlay(indicators, imdb):
##    Log(control.myName()); LogR(locals())
    try:
        try:
            if hasattr(indicators, '_get_watched'):
                playcount = indicators._get_watched('movie', imdb, '', '')
            else:
                playcount = indicators._get_watched_movie({'imdb_id' : imdb})
##            LogR(playcount)
            return str(playcount)
        except:
            raise
            playcount = [i for i in indicators if i == imdb]
            playcount = METAHANDLER_WATCHED if len(playcount) > 0 else METAHANDLER_UNWATCHED
##            LogR(playcount)
            return str(playcount)
    except:
##        raise
        return METAHANDLER_UNWATCHED


def getTVShowOverlay(indicators, tvdb):
    playcount = METAHANDLER_UNWATCHED #default
    try:
        playcount = [i[0] for i in indicators if i[0] == tvdb and len(i[2]) >= int(i[1])]
        if len(playcount) > 0:
            playcount = METAHANDLER_WATCHED
        else:
            playcount = METAHANDLER_UNWATCHED
    except:
##        raise
        pass
    return str(playcount)


def getEpisodeOverlay(indicators, imdb, tvdb, season, episode):
    episode_overlay = METAHANDLER_UNWATCHED #default
    try:
        try:
            playcount = indicators._get_watched_episode({
                'imdb_id' : imdb
                , 'season' : season
                , 'episode': episode
                , 'premiered' : ''
                })
            episode_overlay = playcount
        except:
##            Log('e')
            playcount = [i[2] for i in indicators if i[0] == tvdb]
            if len(playcount) > 0:
                playcount = playcount[0] 
            else:
                playcount = []
            playcount = [i for i in playcount if int(season) == int(i[0]) and int(episode) == int(i[1])]
            if len(playcount) > 0:
                episode_overlay = METAHANDLER_WATCHED
            else:
                episode_overlay = METAHANDLER_UNWATCHED
    except:
##        raise
        pass
    return str(episode_overlay)



def markMovieDuringPlayback(imdb, watched):
    try:
        if trakt.getTraktIndicatorsInfo() == False: raise Exception()

        if int(watched) == METAHANDLER_WATCHED: trakt.markMovieAsWatched(imdb)
        else: trakt.markMovieAsNotWatched(imdb)
        trakt.cachesyncMovies()

        if trakt.getTraktAddonMovieInfo() == True:
            trakt.markMovieAsNotWatched(imdb)
    except:
##        raise
        pass

    try:
        from metahandler import metahandlers
        metaget = metahandlers.MetaData(preparezip=False)
        metaget.get_meta('movie', name='', imdb_id=imdb)
        metaget.change_watched('movie', name='', imdb_id=imdb, watched=int(watched))
    except:
##        raise
        pass


def markEpisodeDuringPlayback(imdb, tvdb, season, episode, watched):
    try:
        if trakt.getTraktIndicatorsInfo() == False: raise Exception()

        if int(watched) == METAHANDLER_WATCHED: trakt.markEpisodeAsWatched(tvdb, season, episode)
        else: trakt.markEpisodeAsNotWatched(tvdb, season, episode)
        trakt.cachesyncTVShows()

        if trakt.getTraktAddonEpisodeInfo() == True:
            trakt.markEpisodeAsNotWatched(tvdb, season, episode)
    except:
##        raise
        pass

    try:
        from metahandler import metahandlers
        metaget = metahandlers.MetaData(preparezip=False)
        metaget.get_meta('tvshow', name='', imdb_id=imdb)
        metaget.get_episode_meta('', imdb_id=imdb, season=season, episode=episode)
        metaget.change_watched('episode', '', imdb_id=imdb, season=season, episode=episode, watched=int(watched))
    except:
##        raise
        pass


def movies(imdb, watched):
    Log(control.myName()); LogR(locals())
    try:
        if trakt.getTraktIndicatorsInfo() == False: raise Exception()
        if int(watched) == METAHANDLER_WATCHED: trakt.markMovieAsWatched(imdb)
        else: trakt.markMovieAsNotWatched(imdb)
        trakt.cachesyncMovies()
        control.refresh()
    except:
##        raise
        pass

    try:
        from metahandler import metahandlers
        metaget = metahandlers.MetaData(preparezip=False)
        metaget.get_meta('movie', name='', imdb_id=imdb)
        metaget.change_watched('movie', name='', imdb_id=imdb, watched=int(watched))
        if trakt.getTraktIndicatorsInfo() == False: control.refresh()
    except:
##        raise
        pass


def episodes(imdb, tvdb, season, episode, watched):
    try:
        if trakt.getTraktIndicatorsInfo() == False:
            raise Exception('trakt.getTraktIndicatorsInfo()')
        if int(watched) == METAHANDLER_WATCHED:
            trakt.markEpisodeAsWatched(tvdb, season, episode)
        else:
            trakt.markEpisodeAsNotWatched(tvdb, season, episode)
        trakt.cachesyncTVShows()
        control.refresh()
    except:
##        raise
        pass

    try:
        metaget = metahandlers_MetaData()
        metaget.get_meta(
            'tvshow'
            , name=''
            , imdb_id=imdb
            )
        metaget.get_episode_meta(
            ''
            , imdb_id=imdb
            , season=season
            , episode=episode
            )
        metaget.change_watched('episode'
                               , ''
                               , imdb_id=imdb
                               , season=season
                               , episode=episode
                               , watched=int(watched)
                               )
        if trakt.getTraktIndicatorsInfo() == False:
            control.refresh()
    except:
        raise
        pass


def tvshows(tvshowtitle, imdb, tvdb, season, watched):

##    LogR(locals())
    try:

        if not trakt.getTraktIndicatorsInfo() == False: raise Exception()

##        metaget = metahandlers.MetaData(preparezip=False)
        metaget = metahandlers_MetaData()

        name = control.addonInfo('name')

        dialog = control.progressDialogBG
        dialog.create(str(name), str(tvshowtitle))
        dialog.update(0, str(name), str(tvshowtitle))

        metaget.get_meta('tvshow', name='', imdb_id=imdb)

        from ..indexers import episodes as episode_indexer
        items = episode_indexer.episodes().get(tvshowtitle, '0', imdb, tvdb, '0', idx=False)
##        for i in items:
##            LogR(i)
            
        try: items = [i for i in items if int('%01d' % int(season)) == int('%01d' % int(i['season']))]
        except: pass
        items = [{'label': '%s S%02dE%02d' % (tvshowtitle, int(i['season']), int(i['episode'])), 'season': int('%01d' % int(i['season'])), 'episode': int('%01d' % int(i['episode']))} for i in items]

        for i in range(len(items)):
##            LogR(items[i])
            if xbmc.Monitor().abortRequested(): return sys.exit()

            dialog.update(int((100 // float(len(items))) * i), str(name), str(items[i]['label']))

            season, episode = items[i]['season'], items[i]['episode']
            metaget.get_episode_meta('', imdb_id=imdb, season=season, episode=episode)

            metaget.change_watched('episode', '', imdb_id=imdb, season=season, episode=episode, watched=int(watched))

        try: dialog.close()
        except: pass
    except:
        try: dialog.close()
        except: pass
        raise


    try:
        if trakt.getTraktIndicatorsInfo() == False: raise Exception()

        if season:
            from resources.lib.indexers import episodes
            items = episodes.episodes().get(tvshowtitle, '0', imdb, tvdb, season, idx=False)
            items = [(int(i['season']), int(i['episode'])) for i in items]
            items = [i[1] for i in items if int('%01d' % int(season)) == int('%01d' % i[0])]
            for i in items:
                if int(watched) == METAHANDLER_WATCHED: trakt.markEpisodeAsWatched(tvdb, season, i)
                else: trakt.markEpisodeAsNotWatched(tvdb, season, i)
        else:
            if int(watched) == METAHANDLER_WATCHED: trakt.markTVShowAsWatched(tvdb)
            else: trakt.markTVShowAsNotWatched(tvdb)
        trakt.cachesyncTVShows()
    except:
##        raise
        pass

    control.refresh()



#_______________________________________________________________________________


class metahandlers_MetaData:
    def __init__(self):
        db_version = {
            '17':107  # Krypton
            ,'18':116  # Leia
            ,'19':119  # Matrix
            ,'20':121  # nexus
            ,'21':131  #
            ,'22':137  # omega
        }
        kodi_ver = xbmc.getInfoLabel('System.BuildVersion').split('.')[0]
        video_database_filespec = C.translatePath("special://database/MyVideos%s.db" % db_version.get( kodi_ver, ""))
        if C.PY2: video_database_filespec=video_database_filespec.decode('utf-8')
##        Log(video_database_filespec)
        
        self.dbcon = database.connect(video_database_filespec)

    def _get_watched_episode(self, meta):
        result = METAHANDLER_UNWATCHED
        query = "SELECT * FROM files WHERE strFilename LIKE ? and playCount is not NULL"
        params = ('%imdb={}%season={}%episode={}%'.format(meta['imdb_id'],meta['season'], meta['episode']),)
        try:
            dbcur = self.dbcon.cursor()
            matchedrow = dbcur.execute(query,params).fetchone()
            if matchedrow:
                PLAYCOUNT_COLUMN = 3
                if matchedrow[PLAYCOUNT_COLUMN] > 0:
                    result = METAHANDLER_WATCHED
        except sqlite3.OperationalError as e:
##            LogR(e)
            if e.args[0].startswith("no such table"):
                LogR(e)
                Log("Maybe kodi version change? '{}'".format(video_database_filespec))
        except:
            traceback.print_exc()
        return result


    def _get_watched_movie(self, meta):
        result = METAHANDLER_UNWATCHED
        query = "SELECT * FROM files WHERE strFilename LIKE ? and playCount is not NULL"
        params = ('%imdb={}%'.format(meta['imdb_id']),)
        try:
            dbcur = self.dbcon.cursor()
            matchedrow = dbcur.execute(query,params).fetchone()
            if matchedrow:
                PLAYCOUNT_COLUMN = 3
                if matchedrow[PLAYCOUNT_COLUMN] > 0:
                    result = METAHANDLER_WATCHED
        except sqlite3.OperationalError as e:
            if e.args[0].startswith("no such table"):
                Log(e.args[0] + ' maybe kodi version change?')
        except:
            traceback.print_exc()
        return result


    def get_meta(self, media_type, name, imdb_id='', tmdb_id='', year='', overlay=6, update=False):
        return


    def get_episode_meta(self, tvshowtitle, imdb_id, season, episode, air_date='', episode_title='', overlay=''):
        return


    def change_watched(self, media_type, name, imdb_id, tmdb_id='', season='', episode='', year='', watched='', air_date=''):
##        LogR(locals())
        if watched in [METAHANDLER_WATCHED,str(METAHANDLER_WATCHED)]:
            play_count = 1
        else:
            play_count = None
        query = "UPDATE files SET playCount = ? WHERE strFilename LIKE ? "
        params = '%imdb={}%'.format(imdb_id)
        if tmdb_id:  params += '%tvdb={}%'.format(tmdb_id)
        if season:   params += '%season={}%'.format(season)
        if episode:  params += '%episode={}%'.format(episode)
        params = (play_count, params )
        Log(repr((query,params)))
        try:
            dbcur = self.dbcon.cursor()
            dbcur.execute(query,params)
            self.dbcon.commit()
        except:
            traceback.print_exc()
            raise

