#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import cookielib
import datetime
import json
import os.path
import random
import re
import sqlite3
import sys
import time
import traceback
import threading
import unicodedata
import urllib
import urllib2
import urllib3
import urlparse
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import simplecache

#from resolveurl.plugins.lib import captcha_lib

from xbmc import LOGNONE


import constants as C


if sys.version_info >= (3, 0): from html.parser import HTMLParser
else: from HTMLParser import HTMLParser
html_parser = HTMLParser()

import requests
##my_http_session = requests.Session()
from urllib3 import ProxyManager, PoolManager
if C.certPath:
#    pool_proxy = PoolManager()    
    pool_proxy = PoolManager(ca_certs=C.certPath)
else:
    pool_proxy = PoolManager()


### fake cache created to check memory usage
### ... appears to be zero cost.... memory collection?...
### ram seems to be related to number of thumbnails(size) / skin viewtyep / other things?
class FakeCache():
    empty = json.loads("[]")    
    def get(self,endpoint):
        return self.empty
    
    def set(self,endpoint,data,expiration):
        return
##global_cache = FakeCache()
global_cache = simplecache.SimpleCache()




monitor = xbmc.Monitor()


#__________________________________________________________________________
#
def get_setting(setting_name, auto_convert=bool):
    raw_setting = C.this_addon.getSetting(setting_name)
    if auto_convert is bool:
        if raw_setting.lower() in ['true','false']:
            return (raw_setting.lower() == 'true')
        if raw_setting.lower() in ['none']:
            return None
        if raw_setting == '':
            return None
    if auto_convert is int:
##        Log(repr(("get_setting", setting_name,raw_setting)))
        if raw_setting == '':
            return 0
        else:
            return int(raw_setting)
    if auto_convert is float:
        #Log("float:"+repr(auto_convert is float), xbmc.LOGNONE)
        return float(raw_setting)
    if auto_convert is str:
        return str(raw_setting)
    splitted = repr(auto_convert).split("','")[0].split("'")[1]

    return raw_setting
#__________________________________________________________________________
#
def set_setting(setting_name, setting_value):
    Log(repr(("set_setting", setting_name,setting_value)))
    C.this_addon.setSetting(id=setting_name, value=str(setting_value))
    
#__________________________________________________________________________
#
def playvid(
    video_url
    , name
    , download = None
    , description = u''
    , playmode_string = None
    , play_profile = None
    , download_filespec = None
    , mode = None #30
    , url_factory = None#''
    , icon_URI = None
    , repeat_when_available = False
    , sub_title_url = None
    , mimetype = None #"video/mp2t"
    ):

    import socket
    socket.setdefaulttimeout(30.0)

##    Log(u"playvid video_url='{}', name='{}', download='{}', description='{}', playmode_string='{}', play_profile='{}'".format(
##            video_url
##            , name
##            , download
##            , description
##            , playmode_string
##            , play_profile
##            )
##        , C.LOGNONE
##        )

    try:
        xx = (u"unicode crash tester name={}".format(name))
        xx = (u"unicode crash tester description={}".format(description))
##        Log('here   xcept UnicodeDecodeError:',C.LOGNONE)
    except UnicodeDecodeError:
##        Log('xcept UnicodeDecodeError:',C.LOGNONE)
        name =  name.decode('utf-8')
        description =  description.decode('utf-8')


    if video_url is None:
        return
    
    if len(video_url) > 2000:
        Log("playvid not playing broken videourl".format(video_url[0:100]) )
        return

    if download in [1,'1']:
        import downloader
        downloader.downloadVideo(
            url = video_url
            , name = name
            , mode = mode
            , url_factory = url_factory
            , download_path = download_filespec
            , icon_URI = icon_URI
            , repeat_when_available = repeat_when_available
            )
        return

    #
    # play url as needed
    #
    
    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    if C.xbmc_version[0] > 17 :
        listitem = xbmcgui.ListItem(
            label = name
            , path=video_url
            , offscreen=True #kodi 18+
            )
    else:
        listitem = xbmcgui.ListItem(
            label = name
            , path=video_url
##            , offscreen=True #kodi 18+
            )
        
    listitem.setArt( #setart because other method deprecated
            {
                "icon" : "DefaultVideo.png"
                , "thumb": iconimage
            }
        )
            
    listitem.setInfo(
        'video'
        , infoLabels={
            'title': name
            ,"plot": description
            ,"plotoutline": description
            }
        )
    if sub_title_url: listitem.setSubtitles([sub_title_url]) #todo, sub_title_url might already be a dict
    listitem.setContentLookup(False)
    if mimetype:
        listitem.setMimeType(mimetype)
    listitem.setProperty('IsPlayable', 'false') # true required if you want to track playcount
#    listitem.setProperty('IsPlayable', 'true')

    Log("video_url='{}'".format(video_url) )
    d_type = None
    c_type = ''
    try:
        if '|' in video_url:
            h = dict(urlparse.parse_qsl( str(video_url.split('|')[1])))
            u = str(video_url.split('|')[0])
        else:
            u=h=''
        resp = getHtml(url=u, headers=h, send_back_response=True, method="HEAD")
        if resp:
            if 'Content-Type' in resp.headers:
                c_type = resp.headers['Content-Type'].lower()
                if c_type in ['video/mp4'
                              , 'application/octet-stream'
                              , 'video/mp4, application/octet-stream'
                              ]:
                    listitem.setMimeType(c_type)
                    d_type = C.TYPE_mp4
                elif c_type in ['application/vnd.apple.mpegurl'
                                ,'application/x-mpegurl'
                                ,'text/plain;charset=utf-8'
                                ]:
                    listitem.setMimeType(c_type)
                    d_type = C.TYPE_hls
                else:
                    raise Exception("Unknown content type '{}'".format(c_type))
    except:
        traceback.print_exc()
    Log('Content-Type='+repr((c_type,d_type)))
####    return

    if not video_url == '' and not '|' in video_url:
        video_url = video_url + Header2pipestring()
    Log("video_url='{}'".format(video_url) )

    Log("begin playmode_string='{}'".format(playmode_string)  )
    if str(playmode_string) in ['None',''] or str(playmode_string).isdigit():
        if d_type and d_type == C.TYPE_hls:
            playmode_string = C.DEFAULT_PLAYMODE
        elif d_type and d_type == C.TYPE_mp4:
            playmode_string = C.PLAYMODE_DIRECT
        elif (".m3u8" in str(video_url)):
            playmode_string = C.DEFAULT_PLAYMODE
        elif ("/hls/" in video_url) or ("hlsA/" in video_url):
            playmode_string = C.DEFAULT_PLAYMODE
        else:
            Log('direct')
            playmode_string = C.PLAYMODE_DIRECT
    Log("playmode_string='{}'".format(playmode_string)  )

    try:
        if playmode_string == C.PLAYMODE_DIRECT:
            Log("direct video_url")
            pass

        elif playmode_string == C.PLAYMODE_F4MPROXY:

            Log("play_profile='{}'".format(play_profile)  )
            if play_profile not in C.VALID_PLAYMODE_PROFILES:
                play_profile = C.DEFAULT_PROFILE_NAME
            Log("play_profile='{}'".format(play_profile)  )

            initial_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "initial"))* 1000 * 1000)
            maximum_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "maximum"))* 1000 * 1000)
            allow_upscale = C.addon.getSetting(play_profile + "_" + "allow_upscale")
            allow_downscale = C.addon.getSetting(play_profile + "_" + "allow_downscale")
            always_refresh_m3u8 = C.addon.getSetting(play_profile + "_" + "always_refresh_m3u8")
            downscale_threshhold = C.addon.getSetting(play_profile + "_" + "downscale_threshhold")
            upscale_threshhold = C.addon.getSetting(play_profile + "_" + "upscale_threshhold")
            upscale_penalty = C.addon.getSetting(play_profile + "_" + "upscale_penalty")
            pre_cache_size_max = int(float(C.addon.getSetting(play_profile + "_" + "pre_cache_size_max"))* 1000 * 1000)
            stream_type = C.addon.getSetting(play_profile + "_" + "stream_type").upper()

            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            if not stream_type:
                stream_type = 'HLSRETRY'
                
            #run in separate thread so that plugin can finish
            proxy_thread = threading.Thread(
                name="playF4mLink."#+Clean_Filename(video_url)
                ,target=f4mp.playF4mLink
                ,args=(
                        video_url
                        , name
                        , None #proxy = None
                        , False #use_proxy_for_chunks = False
                        , maximum_bitrate #maxbitrate = maximum_bitrate
                        , False #simpleDownloader = False
                        , None #auth = None
                        , stream_type #streamtype = stream_type
                        , False #setResolved = False
                        , None #swf = None
                        , "" #callbackpath = ""
                        , "" #callbackparam = ""
                        , iconimage #iconImage = iconimage
                        , None #title_info
                        , None #download_path
                        , initial_bitrate #initial_bitrate = initial_bitrate
                        , allow_upscale #allow_upscale = allow_upscale
                        , allow_downscale #allow_downscale = allow_downscale
                        , always_refresh_m3u8 #always_refresh_m3u8 = always_refresh_m3u8
                        , downscale_threshhold #downscale_threshhold = downscale_threshhold
                        , upscale_threshhold #upscale_threshhold = upscale_threshhold
                        , upscale_penalty #upscale_penalty = upscale_penalty
                        , pre_cache_size_max #pre_cache_size_max = pre_cache_size_max
                        , description #description = description
                    )
                )
            proxy_thread.daemon = True
            proxy_thread.start()

            listitem.setProperty('IsPlayable', 'true')
            if C.addon_handle > 0:
                xbmcplugin.setResolvedUrl(C.addon_handle, True, listitem)
                pass

            return True
        
        elif playmode_string == C.PLAYMODE_INPUTSTREAM :
            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            stream_headers = urllib.unquote_plus( video_url.split('|')[1])
    ##        video_url = urllib.unquote_plus( video_url.split('|')[0])
            Log("stream_headers='{}'".format(stream_headers)  )
            listitem.setProperty('inputstream.adaptive.stream_headers', stream_headers)
            Log("using inputstream")
        else:
            Log('Unknown playmode for link. Using direct')

        if C.addon_handle > 0:
            #????with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
            xbmcplugin.setResolvedUrl(C.addon_handle, True, listitem)
            Log("using setResolved", C.LOGNONE)
        else:
            # ??? if the icon we created is listed as a folder, we must use the playlist technique
            xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        ##    listitem.setProperty('IsPlayable', 'true') #????with kodi 18.9 and and launching from widgets/lyrebird, this needs to happen
            myPlayList.add( video_url, listitem)
            xbmc.Player().play(myPlayList)
            Log("using playlist", C.LOGNONE)
    except:
        traceback.print_exc()        
        raise

#__________________________________________________________________________
# wrapper to allow cookie extraction from urllib3 proxy/socks requests
class FakeRequest(object):
    def __init__(self, full_url, headers):
        self.full_url = full_url
        self._headers = headers.copy()
    @property
    def headers(self):
        return self._headers
    @property
    def url(self):
        return self.full_url
    def get_full_url(self):
        return self.full_url
    def is_unverifiable(self, *args, **kargs):
        return True
    def get_origin_req_host(self, *args, **kargs):
        return self.full_url   
#__________________________________________________________________________
#
def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=10
            , sucuri_solved=False
            , method="GET"
            , send_back_response=False
            , auto_encode_content=False
##            , cookie_domain=None
            , size=8192*1000
            , start_point=None
            , preload_content=True
            , cache_duration=C.default_GETHTML_cache_duration #seconds
            ):


##    Log(repr(('getHtml'
##                , url
##                , referer
##                , headers
##                , save_cookie
##                , sent_data
##                , ignore404
##                , ignore403
##                , send_back_redirect
##                , http_timeout
##                , sucuri_solved
##                , "method="+ repr(method)
##                , "send_back_response="+ repr(send_back_response)
##                , "auto_encode_content="+ repr(auto_encode_content)
##                , "size="+ repr(size)
##                , "start_point="+ repr(start_point)
##                , "preload_content="+ repr(preload_content)
##                , "cache_duration="+ repr(cache_duration )
##              ))
##            , C.LOGNONE
##        )


    if not url:
        if send_back_redirect == True:
            return '', ''
        return ''

    cache_id = C.addon_id+'_gethtml_'+url
    if  (send_back_response == False) and \
        (cache_duration > 0) and \
        method=="GET" :
        cached_value = global_cache.get(cache_id)
        if cached_value:
            Log('value is cached'
##                ,C.LOGNONE
                )
            if send_back_redirect:
                return cached_value, url
            return cached_value             

##    Log('after cached'
##        ,C.LOGNONE
##        )


    if not Is_Online():
        if send_back_redirect == True:
            return '', ''
        return ''

##    Log('after Is_Online'
##        ,C.LOGNONE
##        )


    cj = cookielib.LWPCookieJar(C.cookiePath)
    try:
        cj.load(ignore_discard=True, ignore_expires=True)
        cj._now = int(time.time()) #module does not set this if I use internal functions
    except:
        cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
        cj._now = int(time.time())
        pass
    stream=False
    response = None
    redirected_url = None

##    Log('after cookie'
##        ,C.LOGNONE
##        )

##    ##cookiedump
####    Log(C.cookiePath)
##    this_domain = urlparse.urlparse(url).netloc
####    Log(this_domain)
####    Log(repr(cj))
##    for cookie in cj:
####        Log(cookie.domain)
####        Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
##        if this_domain.endswith(cookie.domain):
##        #if cookie.domain.endswith(this_domain):
##            Log("filtered cookie={}".format(repr(cookie)), xbmc.LOGNONE)
####    return
                        
    try:

        if '|' in url:
            headers = dict(urlparse.parse_qsl( str(url.split('|')[1])))
            url = url.split('|')[0]


        if headers is None:
##            Log("copying default header dictionary")
            getHtml_headers = C.DEFAULT_HEADERS.copy()
            r_c_u_a = C.USER_AGENT #random.choice(C._USER_AGENTS)
    ##        Log("r_c_u_a={}".format(r_c_u_a), xbmc.LOGNONE)
            getHtml_headers['User-Agent'] = r_c_u_a
    ##        Log("rand choice getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
        else:
            getHtml_headers = headers #headers.copy()
##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
            
        if len(referer) > 1:
            getHtml_headers['Referer'] = referer

        if sent_data:
            getHtml_headers['Content-Length'] = str(len(sent_data))

        if start_point and int(start_point) > 0:
            getHtml_headers['Range'] = 'bytes={}-'.format(start_point)
            
##        Log("getHtml_headers='{}'".format(repr(getHtml_headers))
####            , C.LOGNONE
##            )
##        return None


        #
        # I don't know how to use cookieJar with SOCKS proxy
        #
        socks_cookies = ''
        if url:
            this_domain = urlparse.urlparse(url).netloc
        
####
##        #either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
##          urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        



        temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
        if cj and url:
            for cookie in cj:
                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                    socks_cookies += "{}={};".format(cookie.name,cookie.value)
                    temp_cookiejar.set_cookie(cookie)
##            for cookie in temp_cookiejar: #verification during development 
##                Log("temp_cookiejar_cookie={}".format(repr(cookie)))
##                pass
            if 'Cookie' in getHtml_headers:
                socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
            if not socks_cookies == '':
                getHtml_headers['Cookie'] = (socks_cookies).strip(';')

    
##        Log("final getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
##        return "" #getHtml_headers testing/dev

        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            if C.certPath: 
                proxy = SOCKSProxyManager(proxy_url=socks_string, ca_certs=C.certPath)
            else:
                proxy = SOCKSProxyManager(proxy_url=socks_string)
            
            socks_response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            
            if preload_content:
                data = socks_response.data

            redirected_url = socks_response.geturl()
            if not url == redirected_url:
                Log(repr((url,redirected_url)))
                Log("redirected_url='{}'".format(redirected_url))
            else:
                redirected_url = None



        elif (socks_proxy_info['uhp'] <= -0) :

            if socks_proxy_info['ps'] is not None: # and '://localhost/' not in url and '://127.0.0.1/' not in url:
                proxy_string = "http://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                proxy = ProxyManager(proxy_url=proxy_string, ca_certs=C.certPath)
            else:
                proxy_string = ''
                #proxy = PoolManager()
                proxy = pool_proxy

##            Log(repr(proxy) )
##            Log(repr(dir(proxy)) )            
##            Log(repr(dir(proxy)) )

            response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
 
            #make urllib3.response more like requests.response by adding cookiejar and status
            temp_jar = cookielib.LWPCookieJar()
            fake_request = FakeRequest(url, response.getheaders() )
            requests.cookies.extract_cookies_to_jar(temp_jar, fake_request, response)
            response.cookies = temp_jar
            response.status_code = response.status

            if preload_content:
                data = response.data
##            Log(data[:500])

            redirected_url = response.geturl()
            if not (url == redirected_url):
                Log(repr((url,redirected_url)))
                if redirected_url and not ('http' in redirected_url):
                    Log('no http')
                    Log(repr(response.retries))
                    Log(repr(response.retries.history))
                    if (response.retries is not None):
                        if len(response.retries.history):
                            redir_domain =''
##                            Log(repr(response.retries.history[-1]))
                            redirect_location = response.retries.history[-1].redirect_location
                            redirect_url = response.retries.history[-1].url
##                            Log(repr(redirect_location))
##                            Log(repr(redirect_url))
                            if not ('http' in redirect_location):
                                if not ('http' in redirect_url):
                                    redir_domain = urlparse.urlparse(url).scheme + '://' + urlparse.urlparse(url).netloc
                                else:
                                    redir_domain = urlparse.urlparse(redirect_url).scheme + '://' + urlparse.urlparse(redirect_url).netloc
##                            Log(repr((redir_domain,redirect_location)))
                            redirected_url = redir_domain + redirected_url
                Log("redirected_url={}".format(repr(redirected_url)))
            else:
                redirected_url = None
 
            
        elif (socks_proxy_info['uhp'] <= 0) :

            
            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
            else: proxies = {}
##            Log("proxies='{}'".format(repr(proxies)))


            #https://requests.readthedocs.io/en/master/api/#requests.Request
            response = my_http_session.request(
                method
                , url=url
                , headers=getHtml_headers
                , data = sent_data
                , stream=stream
                , allow_redirects=True
                , proxies=proxies
                , cookies=temp_cookiejar
                , verify=C.certPath
                )

            if response.status_code == 429:
                response.raise_for_status()

##            if response.headers['Content-Encoding'] == 'gzip':
##                import gzip, StringIO
##                buf = StringIO.StringIO( e.read())
##                f = gzip.GzipFile(fileobj=buf)
##                data = f.read()
##                f.close()
##            else:
            data = response.content

##            Log(data[:1000])
            
            redirected_url = response.url 
            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
            else: redirected_url = None


        if auto_encode_content: 
            if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
                content_type = response.headers['Content-Type']
                if 'charset=' in content_type:
                    ct = content_type.split('charset=')[1]
##                    Log('decoding as {}'.format(repr(ct)))
                    data = data.decode(ct)
            
        if sucuri_solved == False:
            if 'Server' in response.headers:
                if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                    Log(repr(response.status_code))
                    import sucuri
                    if sucuri.SCRIPT_HEADER in data:
                        cookie = sucuri.Set_Cookie(data)
                        cj.set_cookie(cookie)
                        cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
    ##                            raise
                        return getHtml(url, referer, headers
                                       , save_cookie, sent_data
                                       , ignore404, ignore403
                                       , send_back_redirect, http_timeout
                                       , sucuri_solved = True, method=method)

        if not (save_cookie == False) and (cj is not None) :
            r = response
            this_domain = urlparse.urlparse(url).netloc

            if r is not None:
                for cookie in r.cookies:
                    Log("r.cookie={}".format(repr(cookie)))
                    if save_cookie == True: #save as this domain even if cookie is not marked so
                         cookie.domain = this_domain
                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                        cj.set_cookie(cookie)
                        
                cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

             

        if send_back_response == True:
            if send_back_redirect == True:
                return response, redirected_url
            else:
                return response



##        Log(cache_id)
        if  (send_back_response == False) and \
            (cache_duration > 0):

            if 'Content-Type' in response.headers:
                ctype = response.headers['Content-Type'].lower()
                if ctype and ctype in [
                                                        'application/xml; charset=utf-8'
                                                        ,'application/xml;charset=utf-8'
                                                        ,'application/xml'
                                                        , 'application/json; charset=utf-8'
                                                        , 'application/json;charset=utf-8'
                                                        , 'application/json'
                                                        , 'text/html; charset=utf-8'
                                                        , 'text/html;charset=utf-8'
                                                        , 'text/html'
                                                        , 'application/javascript; charset=utf-8'
                                                        ]:
                    global_cache.set(
                        endpoint = cache_id
                        ,data = data  #.decode('utf8')
                        ,expiration = datetime.timedelta(seconds=cache_duration)
                        )
                else:
                    Log("not caching ctype = {}".format(repr(ctype)))
                    pass
            
        if send_back_redirect == True:
            return data, redirected_url

        if response:
            response.close()

        return data


    except requests.HTTPError as e:
        Log("repr(e)='{}'".format(repr(e)))
        raise

    except urllib2.HTTPError as e:
        Log(repr(e.info().get('Content-Encoding')))
        
        if e.info().get('Content-Encoding') == 'gzip':
            import StringIO
            buf = StringIO.StringIO( e.read())
            import gzip
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = e.read()
        #Log(data)  #errors='ignore'
        #notify('Oh oh',data)
        if e.code == 503 and 'cf-browser-verification' in data:
            import cloudflare
            data = cloudflare.solve(url, cj, USER_AGENT)
            
        elif e.code == 404 and ignore404 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        elif e.code == 403 and ignore403 == True:
            Log("403_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data
            
        else:
            traceback.print_exc()
            raise urllib2.HTTPError()




    except Exception as e:
        traceback.print_exc()
##        if 'SSL23_GET_SERVER_HELLO' in str(e):
##            notify('Oh oh','Python version too old - update to Krypton or FTMC')
##            raise urllib2.HTTPError()
##        else:
##            Log("It looks like '{}' is down.".format(url), C.LOGERROR)
##            #Notify(msg="It looks like '{}' is down.".format(url), duration=200)
##            raise

    if send_back_redirect == True:
        return None, None
    else:
        return None
   
#__________________________________________________________________________
#
def postHtml(post_url, sent_data=None, headers=None, compression=True, NoCookie=True, cache_duration=-1):
    #form_data = urllib.urlencode(form_data)
    data = getHtml(url=post_url
                   , headers=headers
                   , save_cookie=(not NoCookie)
                   , sent_data=sent_data
                   , method="POST"
                   , cache_duration=-1)
    return data

#__________________________________________________________________________
#
def headHtml(head_url, sent_data=None, headers=None, compression=True, NoCookie=True, send_back_redirect=False, cache_duration=-1):
    return getHtml(url=head_url
                   , send_back_redirect=send_back_redirect
                   , headers=headers
                   , save_cookie=(not NoCookie)
                   , method="HEAD"
                   , cache_duration=-1 )

#__________________________________________________________________________
#
def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q
#__________________________________________________________________________
#
cp1252 = {
    # from http://www.microsoft.com/typography/unicode/1252.htm
    u"\u20AC": u"\x80", # EURO SIGN
    u"\u201A": u"\x82", # SINGLE LOW-9 QUOTATION MARK
    u"\u0192": u"\x83", # LATIN SMALL LETTER F WITH HOOK
    u"\u201E": u"\x84", # DOUBLE LOW-9 QUOTATION MARK
    u"\u2026": u"\x85", # HORIZONTAL ELLIPSIS
    u"\u2020": u"\x86", # DAGGER
    u"\u2021": u"\x87", # DOUBLE DAGGER
    u"\u02C6": u"\x88", # MODIFIER LETTER CIRCUMFLEX ACCENT
    u"\u2030": u"\x89", # PER MILLE SIGN
    u"\u0160": u"\x8A", # LATIN CAPITAL LETTER S WITH CARON
    u"\u2039": u"\x8B", # SINGLE LEFT-POINTING ANGLE QUOTATION MARK
    u"\u0152": u"\x8C", # LATIN CAPITAL LIGATURE OE
    u"\u017D": u"\x8E", # LATIN CAPITAL LETTER Z WITH CARON
    u"\u2018": u"\x91", # LEFT SINGLE QUOTATION MARK
    u"\u2019": u"\x92", # RIGHT SINGLE QUOTATION MARK
##    u"\u2019": "\u2019".encode('utf8'), # RIGHT SINGLE QUOTATION MARK
    u"\u201C": u"\x93", # LEFT DOUBLE QUOTATION MARK
    u"\u201D": u"\x94", # RIGHT DOUBLE QUOTATION MARK
    u"\u2022": u"\x95", # BULLET
    u"\u2013": u"\x96", # EN DASH
    u"\u2014": u"\x97", # EM DASH
    u"\u02DC": u"\x98", # SMALL TILDE
    u"\u2122": u"\x99", # TRADE MARK SIGN
    u"\u0161": u"\x9A", # LATIN SMALL LETTER S WITH CARON
    u"\u203A": u"\x9B", # SINGLE RIGHT-POINTING ANGLE QUOTATION MARK
    u"\u0153": u"\x9C", # LATIN SMALL LIGATURE OE
    u"\u017E": u"\x9E", # LATIN SMALL LETTER Z WITH CARON
    u"\u0178": u"\x9F", # LATIN CAPITAL LETTER Y WITH DIAERESIS
}
from htmlentitydefs import name2codepoint
def htmlentitydecode(s):
    return re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: unichr(name2codepoint[m.group(1)]), s)

def try_decode(text, encoding="utf-8"):
    '''helper to decode a string to unicode'''
    try:
        return text.decode(encoding, "ignore")
    except Exception:
        return text
def cleantext(text):



    '''normalize string, strip all special chars'''
    text = text.replace('\t','')
    text = text.replace('\n','')
##    text = text.replace(":", "")
##    text = text.replace("/", "-")
##    text = text.replace("\\", "-")
##    text = text.replace("<", "")
##    text = text.replace(">", "")
##    text = text.replace("*", "")
##    text = text.replace("?", "")
##    text = text.replace('|', "")
##    text = text.replace('(', "")
##    text = text.replace(')', "")
##    text = text.replace("\"", "")
    text = text.strip()
    text = text.rstrip('.')
    text = unicodedata.normalize('NFKD', try_decode(text))

    text = html_parser.unescape(text)
    text = htmlentitydecode(text)
    for src, dest in cp1252.items():
        text = text.replace(dest, src )

    text = text.replace('&colon;',':')
    text = text.replace('&comma;',',')
    text = text.replace('&lowbar;','_')
    text = text.replace('&period;','.')
    text = text.replace('&lbrace;','(')
    text = text.replace('&DiacriticalAcute;','`')
    text = text.replace('&lcub;','{')
    text = text.replace('&rcub;','}')
    text = text.replace('&sol;','/')
    text = text.replace('&lpar;','(')
    text = text.replace('&rpar;',')')
    text = text.replace('&quest;','?')
    text = text.replace('&apos;','\'')
    text = text.replace('&percnt;','%')
    text = text.replace('&num;','#')
    return text
##
##    #return a unicode string, replacing html special codes with unicode characters
##
##    text = text.replace('\t','')
##    text = text.replace('\n','')
##    text = text.strip()
##    
##    #Log(repr(text) + "   org(text)")
##    if not isinstance(text, unicode):
##        text = text.decode('utf8')
##
##    text = htmlentitydecode(text)
##    text = html_parser.unescape(text)
##
##    for src, dest in cp1252.items():
##        text = text.replace(dest, src )
##
##    #return text        
##    return unicodedata.normalize(
##             'NFKD', text
##             ).encode('utf8','ignore')
##
####    text = text.replace(u'\u200b','')
####    from unidecode import unidecode
####    return unidecode(text)
##    
####    text = text.decode('ascii', 'xmlcharrefreplace')
##
##
##    
##
##    text = htmlentitydecode(text)
##    #Log(repr(text) + "   entity(text)")
####    import unicodedata
####    text = unicodedata.normalize('NFKD',text)
##    text = html_parser.unescape(text)
##    #Log(repr(text) + "   html(text)")
##    
##    #to make things easier on future functions that only support
##    #   ascii strings, make sure that a cleaned string is encoded as
##    #   utf8. This strings should be decoded before being made visible
##    #   to user
####    for src, dest in cp1252.items():
####        text = text.replace(src, dest)
####    Log(repr(text) + "   cp1252(text)")
######    text = text.encode('latin1')
######    Log(repr(text) + "   latin(text)")
####    text = text.decode('unicode_escape')
####    Log(repr(text) + "   unicode(text)")
##    
####    text = text.decode('utf8')
####    Log(repr(text) + "   utf8(text)")
##
####    text = text.replace(u"\u2018", u"'").replace(u"\u2019", u"'")
####    Log(repr(text) + "   replace(text)")
##
##    #returned text should be pure unicode
##    #no futher encoding should be necessary
##    
##
####
####    text = text.replace('&excl;','!')
####    text = text.replace('&lpar;','[')
####    text = text.replace('&rpar;',']')
##
##    return text
##
##    #Log(text,xbmc.LOGNONE)
##    #text = html_parser.unescape(text.encode('ascii', 'ignore'))
##    text = htmlentitydecode(text)
##    text = text.replace('&#8211;','-')
##    text = text.replace('&ndash;','-')
##    
##    
##    
##    text = text.replace('&amp;','&')
##    text = text.replace('&#038;','&')
##    text = text.replace('&#8217;','\'')
##    text = text.replace('&#8216;','\'')
##    text = text.replace('&#8230;','...')
##    text = text.replace('&quot;','"')
##    text = text.replace('&excl;','!')
##    text = text.replace('&apos;','\'')
##    text = text.replace('&#039;','`')
##    text = text.replace(u'ñ','n')
##
##
##    #Log(text,xbmc.LOGNONE)
##    #xbmc.log(  u'ñ'.encode("utf-8").decode("utf-8") , xbmc.LOGNONE)
##    #text = text.encode("utf-8").replace('&ntilde;','\xf1').decode("utf-8")
##    text = text.replace('&rsquo;','\'')
##    text = text.encode('ascii', 'ignore').strip()
##
##
##    return text


#__________________________________________________________________________
#
def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext

#__________________________________________________________________________
#
def Set_ListItem_Duration(listitem, duration):
    duration=str(duration).lower().strip()
    duration_seconds = 0

    # test cases:
    # 
##    Log(duration, xbmc.LOGNONE)
    
    #somethimes will have a dot
    if '.' in duration:
        duration = duration.split('.')[1]
        
    #sometimes format will be hh:mm:ss: normalize it to what I want
    timearr= ['s','m','h']
    if ':' in duration:
        duration_arr = duration.split(':')
        duration = ""
        i = 0
        for duration_elem in reversed(duration_arr):
            duration = duration_elem + timearr[i] + duration
            i = i+1

    duration = duration.replace(' h', 'h ').replace('h', 'h ').replace('min', 'm ').replace(' m', 'm ').replace('m', 'm ').replace(' s', 's ').replace('s', 's ').strip()

    #sometimes format will be Xh Ym Zs
    try:
        duration_arr = duration.split(' ')
        for duration_elem in duration_arr:
            duration_elem = duration_elem.strip()
            if 'h' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('h',''))*3600
            elif 'm' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('m',''))*60
            elif 's' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('s',''))
            elif duration_elem:
                try:
                    duration_seconds = duration_seconds + int(duration_elem)
                except:
                    pass
    except:
        Log(repr(duration_arr))
        raise

    listitem.setInfo(type="Video", infoLabels={"duration": duration_seconds} )
#__________________________________________________________________________
#
def addDownLink(name, url, mode
                , iconimage=''
                , desc=''
                , stream=None
                , fav='add'
                , noDownload=False
                , duration=None
                , date=None
                , views=None
                , likes=None
                , play_method=None
                , hq_stream=None
                , return_listitem=False
                , icon_url=''
                , action=''
                ):

    if fav == 'add': favtext = "Add to"
    elif fav == 'del': favtext = "Remove from"
    if not date: date = 0
    if not hq_stream: hq_stream = ''
    else:  hq_stream = str(hq_stream)


    if isinstance(url, unicode):
        url = url.encode('utf8')        
    if isinstance(name, unicode):
        name = name.encode('utf8')        
    if isinstance(desc, unicode):
        desc = desc.encode('utf8')        
    if isinstance(iconimage, unicode):
        iconimage = iconimage.encode('utf8')        
        
    u = (
        "{}".format(sys.argv[0])
        + "?url={}".format(urllib.quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(urllib.quote_plus(iconimage) ) 
        + "&name={}".format(urllib.quote_plus(name))
        + "&action={}".format(action)
        )
    
    u = (
        "{}".format(sys.argv[0])
        + "?url={}".format(urllib.quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(urllib.quote_plus(iconimage) ) 
        + "&name={}".format(urllib.quote_plus(name))
        + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + "&desc={}".format(urllib.quote_plus(desc)) 
        + "&playmode_string={}".format(play_method)
        + "&action={}".format(action)
        )
    download_xbmc_url = (
        "{}".format(sys.argv[0]) 
        + "?url={}".format(urllib.quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(urllib.quote_plus(iconimage) ) 
        + "&name={}".format(urllib.quote_plus(name))
        + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + "&playmode_string={}".format(play_method) 
        + "&download=1"
        + "&icon_URI={}".format(urllib.quote_plus(iconimage) )
        + "&action={}".format(action)
        )
    favorite = (
        "{}".format(sys.argv[0]) 
        + "?url={}".format(urllib.quote_plus(url)) 
        + "&mode={}".format(C.FAVORITES_MODE) 
        + "&img={}".format(urllib.quote_plus(iconimage) ) 
        + "&name={}".format(urllib.quote_plus(name))
        + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
        + "&fav={}".format(fav) 
        + "&favmode={}".format(mode)
        + "&desc={}".format(urllib.quote_plus(desc))
        + "&icon_url={}".format(urllib.quote_plus(icon_url))
        + "&action={}".format(action)
        )
    play_with_method = (
        "{}".format(sys.argv[0])
        + "?url={}".format(urllib.quote_plus(url))
        + "&mode={}".format(mode)
        + "&img={}".format(urllib.quote_plus(iconimage) )
        + "&name={}".format(urllib.quote_plus(name))
        + "&hq_stream={}".format(urllib.quote_plus(hq_stream))
        + "&playmode_string={}"
        + "&play_profile={}"
        + "&action={}".format(action)
        )

    
    if len(iconimage) < 1:                 iconimage = C.default_icon
    if not '|' in iconimage and 'http' in iconimage: iconimage = "{}{}".format(iconimage, Header2pipestring())
    #Log("iconimage={}".format(iconimage))

    if C.xbmc_version[0] > 17 :
        liz = xbmcgui.ListItem(
            label = name
            , offscreen=True #kodi 18+
            )
    else:
        liz = xbmcgui.ListItem(
            label = name
##            , offscreen=True #kodi 18+
            )
        
    liz.setArt(
        { 'thumb': iconimage #must include thumb to avoid error log messages
##          , 'icon': iconimage
          , 'fanart': iconimage #must include fanart for infowall view
          , 'poster': iconimage
          }
        ) 

    if duration:  
        Set_ListItem_Duration(liz, duration) #2021-01 k17.6 setting duration seems to cause page to be reloaded after play stops 

    liz.setMimeType('video/mp4')
    liz.setContentLookup(False)           
    #  if 'IsPlayable' true, don't use playlists (?)
    #  if 'IsPlayable' true, will trigger a container refresh [randomly?]
    #  if 'IsPlayable' true, file-not-found will log 'ERROR: ... '  ERROR: Playlist Player: skipping unplayable item ... CVideoPlayer::OpenInputStream - error opening.....'
    #  if 'IsPlayable' false, then 'mark as watched' will not work
    liz.setProperty('IsPlayable', 'false') 
##    liz.setProperty('IsPlayable', 'true')     
    
    if stream:
        liz.setProperty('IsPlayable', 'true') #can't set this and use playlists at same time

    if len(desc) < 1:  desc = ''
    liz.setInfo(
        type="Video"
        , infoLabels={
            "title": name
            ,"plot": desc
            ,"plotoutline": desc
            }
        )

##    liz.addStreamInfo('video', {'codec': 'h264'})

    contextMenuItems = []

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        
        contextMenuItems.append(
            (
            "[COLOR {}]{} favorites[/COLOR]".format(C.refresh_text_color, favtext)
            , "xbmc.RunPlugin({})".format(favorite)
            )
        )
        if fav == 'del':
            favorite = (
                "{}".format(sys.argv[0]) 
                + "?url={}".format(urllib.quote_plus(url)) 
                + "&mode={}".format(C.FAVORITES_MODE) 
                + "&img={}".format(urllib.quote_plus(iconimage) ) 
                + "&name={}".format(urllib.quote_plus(name)) 
                + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
                + "&fav={}".format('refresh') 
                + "&favmode={}".format(mode)
                + "&desc={}".format(urllib.quote_plus(desc)) 
                + "&icon_url={}".format(urllib.quote_plus(icon_url))
                )
            contextMenuItems.append(
                (
                "[COLOR {}]{}[/COLOR]".format(C.refresh_text_color, 'Refresh')
                , "xbmc.RunPlugin({})".format(favorite)
                )
            )
##            favorite = (
##                "{}".format(sys.argv[0]) 
##                + "?url={}".format(urllib.quote_plus(url)) 
##                + "&mode={}".format(C.FAVORITES_MODE) 
##                + "&img={}".format(urllib.quote_plus(iconimage) ) 
##                + "&name={}".format(urllib.quote_plus(name)) 
##                + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
##                + "&fav={}".format('rebuild') 
##                + "&favmode={}".format(mode)
##                + "&desc={}".format(urllib.quote_plus(desc)) 
##                + "&icon_url={}".format(urllib.quote_plus(icon_url))
##                )
##            contextMenuItems.append(
##                (
##                "[COLOR {}]{} fav[/COLOR]".format(C.refresh_text_color, 'Rebuild')
##                , "xbmc.RunPlugin({})".format(favorite)
##                )
##            )
            favorite = (
                "{}".format(sys.argv[0]) 
                + "?url={}".format(urllib.quote_plus(url)) 
                + "&mode={}".format(C.FAVORITES_MODE) 
                + "&img={}".format(urllib.quote_plus(iconimage) ) 
                + "&name={}".format(urllib.quote_plus(name)) 
                + "&hq_stream={}".format(urllib.quote_plus(hq_stream)) 
                + "&fav={}".format('rename') 
                + "&favmode={}".format(mode)
                + "&desc={}".format(urllib.quote_plus(desc)) 
                + "&icon_url={}".format(urllib.quote_plus(icon_url))
                )
            contextMenuItems.append(
                (
                "[COLOR {}]{}[/COLOR]".format(C.refresh_text_color, 'Rename')
                , "xbmc.RunPlugin({})".format(favorite)
                )
            )

    max_rez = (C.addon.getSetting("max_rez").lower())
    if not max_rez: max_rez = ('480','720','1080')
    else: max_rez = max_rez.split(',')

    if play_method in {C.PLAYMODE_VARIABLE, None} :
        for rez in max_rez:
            contextMenuItems.append(
                (
                "[COLOR {}]{} {}[/COLOR]".format(C.highlight_text_color, 'Play Max',rez)
                , "xbmc.RunPlugin({})".format(play_with_method.format(rez, 0))
                )
            )
        
    if play_method in {C.PLAYMODE_INPUTSTREAM, C.PLAYMODE_F4MPROXY, C.PLAYMODE_DIRECT, '', None} :

        contextMenuItems.append(
            (
            "[COLOR {}]{} Direct[/COLOR]".format(C.time_text_color, 'Play')
            , "xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_DIRECT, 0))
            )
        )
        contextMenuItems.append(
            (
            "[COLOR {}]{} Inputstream[/COLOR]".format(C.time_text_color, 'Play')
            , "xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_INPUTSTREAM, 0))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_01_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_01"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_02_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_02"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_03_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_03"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_04_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_04"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_05_alias"))
            ,"xbmc.RunPlugin({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_05"))
            )
        )        
    if noDownload == False:
        contextMenuItems.append(
            (
                "[COLOR {}]Download[/COLOR]".format(C.search_text_color)
                ,"xbmc.RunPlugin({})".format(download_xbmc_url)
            )
        )

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
    else:
        liz.addContextMenuItems([], replaceItems=True)

##    Log(u"u={}".format(repr(u)))
    if return_listitem:
        return(u, liz, False)
    else:
        xbmcplugin.addDirectoryItem(handle=C.addon_handle, url=u, listitem=liz, isFolder=False)
#__________________________________________________________________________
#
def addDir(name, url, mode
           , iconimage=None
           , page=None
           , channel=None
           , section=None
           , keyword=''
           , Folder=True
           , duration=None
           , title=None
           , end_directory=True
           , contextMenu=None
           , contextMenuReplace=True
           , return_listitem=False
           , return_url=False):

    if page is None: page='1'
    u = (sys.argv[0] +
     "?url=" + urllib.quote_plus(str(url)) +
     "&1mode=" + str(mode) +
     "&mode=" + str(mode) +
     "&page=" + str(page) +
     "&channel=" + str(channel) +
     "&section=" + str(section) +
     "&keyword=" + urllib.quote_plus(str(keyword)) +
     "&end_directory=" + str(end_directory) +
     "&name=" + urllib.quote_plus(str(name.encode('utf8'))))

    if return_url:
        return u


    if not(iconimage) or (len(iconimage) < 1): iconimage = C.default_icon

    if not '|' in iconimage and 'http' in iconimage:
        iconimage = u"{}{}".format(iconimage, Header2pipestring())

##    liz = xbmcgui.ListItem(
##        name
##        , iconImage=iconimage
##        , thumbnailImage=iconimage
##        )
    if C.xbmc_version[0] > 17 :
        liz = xbmcgui.ListItem(
            label = name
            , iconImage=iconimage
            , thumbnailImage=iconimage
            , offscreen=True #kodi 18+
            )
    else:
        liz = xbmcgui.ListItem(
            label = name
            , iconImage=iconimage
            , thumbnailImage=iconimage
##            , offscreen=True #kodi 18+
            )


    liz.setProperty('IsPlayable', 'false')

##    liz.setArt({'thumb': iconimage, 'icon': iconimage})
##    fanart = os.path.join(C.rootDir, 'fanart.jpg')
##
##    if C.addon.getSetting('posterfanart') == 'true':
##        fanart = iconimage
##        liz.setArt({'poster': iconimage})
##
##    liz.setArt({'fanart': fanart})

    liz.setArt(
        { 'thumb': iconimage
          , 'icon': iconimage
          , 'fanart': iconimage
          , 'poster': iconimage
          }) #must include thumb to avoid error messages

    if duration:
        Set_ListItem_Duration(liz, duration)

    #setting type = music instead of video means no icon to the right of the label
    #liz.setInfo(type="music", infoLabels={"Title": name})

    if title:
        liz.setInfo(type="Video", infoLabels={"Title": title})

    contextMenuItems = []
    if len(keyword) >= 1 and not("next page" in name.lower()):
        keyw = (sys.argv[0] +
            "?mode=" + C.DELETE_KEYWORD +
            "&keyword=" + urllib.quote_plus(keyword))
        #if not contextMenuItems: contextMenuItems = []
        contextMenuItems.append(
                (
                    "[COLOR {}]Remove keyword[/COLOR]".format(C.time_text_color)
                    , "xbmc.RunPlugin({})".format(keyw)
                )
            )

    if section and section == C.INBAND_RECURSE:
        #below will not work well because the 'back' button will return to root of addon, and not where I want     
        u2 = u.replace("&keyword=" + urllib.quote_plus(str(keyword)), "&keyword=" + C.INBAND_RECURSE)
        u2 = u2.replace("&page=" + str(page), "&page=" + str(int(page)-1)) #include the page we are on
        u2 = u2.replace("&page=" + str(page), "&page=1")  #include the page we are on
        contextMenuItems.append( (
            "[COLOR {}]Recurse to Page {}[/COLOR]".format(C.search_text_color, C.MAX_RECURSE_DEPTH)
            , "xbmc.ActivateWindow(Videos,{})".format(u2)  )  )
        contextMenuReplace=False

#####below does not work well because the 'back' button will return to root of addon, and not where I want
##    if add_recursive_search_submenu == True:
##        u2 = (sys.argv[0] +
##         "?url=" +
##         "&mode=" + str(mode) +
##         "&page=-1"
##         "&keyword=" + urllib.quote_plus(str(keyword)) +
##         "&end_directory=False" )
##        #Log("u2={}".format(u2))
##        if not contextMenuItems: contextMenuItems = []
####        contextMenuItems.append( (
####            "[COLOR {}]Recursive Search[/COLOR]".format(search_text_color)
####            , "xbmc.RunPlugin({})".format(u2)  )  )
##        contextMenuItems.append( (
##            "[COLOR {}]Recursive Search[/COLOR]".format(search_text_color)
##            , "ReplaceWindow(Videos," + u2 + ")"  )  )
##            #'XBMC.RunPlugin('+ Pluginurl+')') 
##            #"ActivateWindow(Videos," + u2 + ")"
##            #ReplaceWindow

    if contextMenu:
        contextMenuItems = contextMenu
        
    if contextMenuItems:
##        Log(repr(contextMenuReplace), xbmc.LOGNONE)
        liz.addContextMenuItems(contextMenuItems, replaceItems=contextMenuReplace)

##    global add_count
##    add_count +=1
##    Log(repr(add_count))

    if return_url:
        return u
    elif return_listitem:
        return(u, liz, Folder)
    else:
        xbmcplugin.addDirectoryItem(
            handle=C.addon_handle
            , url=u
            , listitem=liz
            , isFolder=Folder
            )
###__________________________________________________________________________
###
#__________________________________________________________________________
#
def Get_Sites(filter_category=None,icon_function=None):
    import importlib
    libDir = os.path.join(C.resDir, 'lib')
    sitesDir = os.path.join(libDir, 'sites')
    files = []
    for r, d, f in os.walk(sitesDir): # r=root, d=directories, f = files
        for file in f:
            if file.endswith('.py') and not file.startswith('_') :
                f2 = file[:-len('.py')]
                files.append(f2)
    site_list = {}
    for f in files:
        if not f in site_list:
##            Log("added f='{}'".format(f))
            site_list[f] = ''

    import operator
    sorted_site_list = sorted(site_list.items(), key=operator.itemgetter(0))
    import collections
    sorted_dict = collections.OrderedDict(sorted_site_list)

    aa = None
    for sitename in sorted_dict:
        if aa is None:
            try:
                module = importlib.import_module('resources.lib.sites.'+sitename)
##                Log(repr('resources.lib.sites.'+sitename))
##                Log(repr(module))
##                Log(repr(dir(module)))
                
                if hasattr(module, "website"):
                    module = module.website
##                    Log("detected subclass of 'website'")
##                    Log("module.LIST_AREA='{}'".format(module.LIST_AREA))
##                    Log("dir(module.LIST_AREA)='{}'".format(dir(module.LIST_AREA)))
##                    Log("repr(module.LIST_AREA)='{}'".format(repr(module.LIST_AREA)))
                if filter_category:
                    if module.LIST_AREA == filter_category:
##                        Log(repr(os.path.join(C.imgDir, sitename + '.png')),C.LOGNONE)
                        yield (
                            module.FRIENDLY_NAME
                            ,module.ROOT_URL
                            ,module.MAIN_MODE
                            ,os.path.join(C.imgDir, sitename + '.png')
                            )
                elif icon_function==True:
                    aa = (yield (module ,module.MAIN_MODE))
                    if aa is not None:
                        break
                else:
##                    Log("sitename='{}'".format(sitename),C.LOGNONE)
                    aa = (yield (sitename, module))
                    if aa is not None:
                        break
            except GeneratorExit:
                pass
            except:
                Log('failed Get_Sites for {}'.format(sitename), xbmc.LOGWARNING)
                traceback.print_exc()



#__________________________________________________________________________
#

def Log(msg='', loglevel=None):
    if not isinstance(msg, unicode):
##        xbmc.log('xx', xbmc.LOGNONE)
        msg = unicode(msg.decode('utf-8', 'ignore'))
    try:
##        xbmc.log('yy', xbmc.LOGNONE)
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=2)[0][0])
            ,traceback.extract_stack(limit=2)[0][1]
            ,msg
            )
    except:
##        xbmc.log('zz', xbmc.LOGNONE)
        pass
    msg = "{}: {}".format(C.addon_id, msg.encode('utf-8',errors='ignore') )
    if  loglevel: xbmc.log(msg , loglevel)
    elif C.DEBUG:  xbmc.log(msg , xbmc.LOGNONE)
    else:    xbmc.log(msg)
#__________________________________________________________________________
#
def Notify(header=None, msg='', duration=4000, sound=False, allow_all_thread_names=False):
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound, allow_all_thread_names=allow_all_thread_names)
def notify(header=None, msg='', duration=C.DEFAULT_NOTIFY_TIME, sound=False, allow_all_thread_names=False):
    debug = (C.this_addon.getSetting('debug').lower() == "true")
    if allow_all_thread_names or (threading.current_thread().name == "MainThread"):
        Log( msg, xbmc.LOGNOTICE)
        if header==None or header == '':
            if len(msg) > 30:
                header = msg[0:30]
                msg = msg[-30:]
            else:
                header=msg
        xbmcgui.Dialog().notification(header, msg, C.default_icon, duration, sound=False )
    elif debug:
        #Log( msg, xbmc.LOGNONE)
        pass

#__________________________________________________________________________
#
def Header2pipestring(header = C.DEFAULT_HEADERS):
    q = "|{}".format( urllib.urlencode(header)  )
    return q

#__________________________________________________________________________
#
def add_sort_method():
    sort_order = None  ##int(C.addon.getSetting('video_sort_by'))
    if sort_order == 2:
        sort_order = xbmcplugin.SORT_METHOD_DURATION
##    elif sort_order == :
##        sort_order = xbmcplugin.SORT_METHOD_DATE
    elif sort_order == 1:
        sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
    elif sort_order == 4:
        sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
    elif sort_order == 5:
        sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
    else:
        sort_order = xbmcplugin.SORT_METHOD_UNSORTED
    
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=sort_order) #use preferred method first
    #xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
#    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_DURATION)

#__________________________________________________________________________
#
def endOfDirectory(cacheToDisc=True, end_directory=True, allow_sorting=True, inband_recurse=False, updateListing=False):
##    if end_directory is True:  traceback.print_stack()

    if not ( (end_directory == True) or inband_recurse ):
        return
    if allow_sorting == True:
        add_sort_method()
    if int(sys.argv[1]) > 0:
        C.addon_handle = int(sys.argv[1])
        xbmcplugin.endOfDirectory(C.addon_handle, cacheToDisc=cacheToDisc, updateListing=updateListing)
##        traceback.print_stack()
#__________________________________________________________________________
#
def SortVideos(sources
               , download
               , vid_res_column=1
               , substitute_char='}'
               , substitute_res='720'
               , max_video_resolution = C.maximum_video_resolution
               ):

    Log("SortVideos sources='{}', download='{}', vid_res_column='{}', max_video_resolution='{}'".format(repr(sources), download, vid_res_column, max_video_resolution))
##    global maximum_video_resolution
    if max_video_resolution:
        maximum_video_resolution = max_video_resolution
    else:
        maximum_video_resolution = C.maximum_video_resolution
##    Log(str(maximum_video_resolution))

    try: 
        #sometimes we can't get accurate resolutions and end up with a characters instead...
        # e.g. "http://video.mp4","}"     instead of   "http://video.mp4","480p"

##        Log("sources='{}', download='{}'".format(sources,download))

        if (bool(download) == True):
            maximum_video_resolution = 99999 # allow max resolution on download
##        Log("maximum_video_resolution='{}'".format(maximum_video_resolution))

        s3840p_string = "3840p"
        s2160p_string = "2160p"
        s1440p_string = "1440p"
        s1080p_string = "1080p"
        s720p_string = "720p"
        s540p_string = "540p"
        s480p_string = "480p"
        s320p_string = "320p"

        #report on what was the maximum resolution available; just for fun
        try:
            videos = sorted(sources
                            , key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('p60','p') \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True)
##            Log(repr(videos))

            if len(videos) > 1:
                if vid_res_column == 1:
                    max_avail_res = videos[0][1]
                else:
                    max_avail_res = videos[0][0]
            else:
                max_avail_res = 'unknown'
        except:
            traceback.print_exc()
            max_avail_res = 'unknown'
            pass
        Log("Best quality for this item is {}".format(max_avail_res))
##        Log("Worst quality for this item is {}".format(videos[-1][vid_res_column]  ))

        #change these subst strings so that they can't be matched when max resolution is less
        if maximum_video_resolution < 3840:
            s3840p_string = "40p" 
        if maximum_video_resolution < 2160:
            s2160p_string = "60p"
        if maximum_video_resolution < 1440:
            s1440p_string = "14p"
        if maximum_video_resolution < 1080:
            s1080p_string = "14p"
        if maximum_video_resolution < 720:
            s720p_string = "14p"
        if maximum_video_resolution < 540:
            s540p_string = "13p"
        if maximum_video_resolution < 480:
            s480p_string = "12p"

    ##     the list of videos is a bunch of urls such as xxx\360.mp4
    ##        i use a lambda(just for fun) to split out the numeric resolution and the reverse sort it;
    ##        the best resolution should end up on top
    ##        the 720 is replaced with 721 so that the number ending 20 does not match other possible strings the site may use to define ultra resolutions
    ##        the letter p is removed so that we can convert to integer and avoid the 720 is better 1080 situation if it were chars
    ##        the higher resolutions, when we have been told not to use them, are replaced with lower numbered strings 

        try:
            videos = sorted(sources, key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('p60','p') \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True)
        except:
            videos = None
            traceback.print_exc()

        Log("videos='{}'".format(videos))
        if len(videos) < 1:
            return None
        if vid_res_column == 1:
            video_url = videos[0][0]
        else:
            video_url = videos[0][1]
        Log("video_url='{}'".format(video_url))
        return video_url
    except:
         traceback.print_exc()
         return None

#__________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=10):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval
#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    from xml.dom import minidom
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None

    def Get_Setting_Val(setting):
        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"' +
                                  setting + '"},"id":1}')
        return json.loads(val)['result']['value']
        
    
    try:
        usehttpproxy = Get_Setting_Val('network.usehttpproxy')
        if usehttpproxy and str(usehttpproxy).lower()=='true':
            httpproxytype = Get_Setting_Val('network.httpproxytype') #= get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = Get_Setting_Val('network.httpproxyserver') #= get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = Get_Setting_Val('network.httpproxyport') #= get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = Get_Setting_Val('network.httpproxyusername') #= get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = Get_Setting_Val('network.httpproxypassword') #= get_gui_setting(guisettings_xml, 'httpproxypassword')

    except:
        traceback.print_exc()
##        raise
##        pass
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
##        Log(repr(proxy_info))
        return proxy_info
#__________________________________________________________________
#
def RandomNumber(return_integer=True,length=18):
    import random
    nc_string = str(random.random())
    if return_integer:
        nc_string = nc_string.split('.')[1]
    while len(nc_string) < length:
        nc_string += str(random.randint(10,99))
    if len(nc_string) > length:
        nc_string = nc_string[0:length]
    return nc_string
#__________________________________________________________________
#
def Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode):
    #helper function to make code look smaller
    # check for a minimum length; raise error if necessary; add item if not enough
    if len(info) < 1:
        label = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "No items")
        if not keyword == '':
            label += " for [COLOR {}]{}[/COLOR]".format(C.refresh_text_color,keyword)
        label +=  " on '{}'".format(ROOT_URL)
        addDir(
            name=label
            ,url=C.DO_NOTHING_URL
            ,mode=MAIN_MODE
            ,iconimage=C.not_found_icon
            )
        if testmode:
            raise OSError    
#__________________________________________________________________
#
def Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page):
    #helper function to make code look smaller
    inband_recurse = (keyword==C.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = C.MAX_RECURSE_DEPTH
    else:
        max_search_depth = C.DEFAULT_RECURSE_DEPTH
    if end_directory == True and SEARCH_URL:
        addDir(
            name=C.STANDARD_MESSAGE_SEARCH
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon )

        addDir(
            name=C.STANDARD_MESSAGE_SEARCH_RECURSIVE
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon
            ,end_directory=False
            ,page=C.FLAG_RECURSE_NEXT_PAGES)
##    Log("url={}".format(repr(url)))
##    Log("page={}".format(repr(page)))    
    if ('{}' in url) and page:
        list_url = url.format(page)
    else:
        list_url = url
    Log("list_url='{}'".format(list_url))

    return inband_recurse, end_directory, max_search_depth, list_url
#__________________________________________________________________
#
def Normalize_HD_String(hd):
    hd = hd.lower()
    if   ('2160'           in hd
          or 'uhd'         in hd
          or '4k'          in hd
          or '2k'          in hd
          or '1440'        in hd): hd = C.STANDARD_MESSAGE_UHD
    elif ('class="fullhd"' in hd
          or 'fullhd'      in hd
          or 'full_hd'     in hd
          or    'fhd'      in hd
          or '1080'        in hd): hd = C.STANDARD_MESSAGE_FHD
    elif (   'class="hd"'  in hd
          or 'hd'          in hd
          or 'icon-hd'     in hd
          or '720'         in hd): hd = C.STANDARD_MESSAGE_HD
    else:                          hd = C.STANDARD_MESSAGE_NOHD

    return hd
#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True, delete_first_color=False):
    import unicodedata
    if not s: return ''
    s = s.strip('\r')

    if not isinstance(s, unicode):
##        Log('not unicode yet')
##        Log(repr(s))
        s = s.decode('utf8')
##        Log(repr(s))


##    Log(repr((type(s),s)))
    if delete_first_color:
        s = (re.sub(u'(?i)\[cOLOR \w+?\].+?\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(u'(?i)\[\/Color\]','',s))
##    Log(repr((type(s),s)))

    s = unicodedata.normalize('NFKD', s).encode("ascii", "ignore")
##    s = unicodedata.normalize('NFKD', s).encode("utf8", "ignore")
##    s = unicodedata.normalize('NFKD', try_decode(s))
##    Log(repr((type(s),s)))

    #s = unicode(s.encode("utf8"), 'utf8')
    s = unicode(s.encode("ascii",'ignore'), 'utf8')
    Log(repr((type(s),s)))

##[\[\] ,\'\.\&\_\-]
## orignally only allow these     s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_\-]',' ',s))


    
    #s = (re.sub(u'(?is)[\?]',u'¿',s)) #this symbol is closest I can think of to subsitute
    s = (re.sub(u'(?is)[\?]',u'',s)) #¿ no longer used; kodi ignores files like this even if valid
    if include_square_braces: #permit_square_braces
        s = (re.sub(u'(?is)[    \\\/\:\*\"\<\>\|]',' ',s))
    else:
        s = (re.sub(u'(?is)[\[\]\\\/\:\*\"\<\>\|]',' ',s))

##    Log(repr((type(s),s)))
    
    while '  ' in s:
        s = s.replace('  ', ' ')
    s = s.strip()

##    Log(repr((type(s),s)))

    return s

    if include_square_braces:
        s = (re.sub("(?is)[^A-Z0-9.' &_\-\]\[]"," ",s))
    else:
        s = (re.sub("(?is)[^A-Z0-9.' &_\-    ]"," ",s))
        #s = (re.sub(u'(?is)[^A-Za-z0-9~     ,\'.&_\-]',' ',s))

    while '  ' in s:
        s = s.replace('  ', ' ')
    return s.strip()
#__________________________________________________________________________
#
class Progress_Dialog(object):
    import threading, xbmcgui
    def __init__(
        self
        , title
        , message
        ):
        if threading.current_thread().name != "MainThread":
            self.dialog_progress = None
        self.dialog_progress = xbmcgui.DialogProgress()
        self.dialog_progress.create(title, message)
        self.percent = 0.01
        
    def iscanceled(self):
        if self.dialog_progress:
            return self.dialog_progress.iscanceled()
        else:
            return True
    def close(self):
        if not self.dialog_progress: return
        self.dialog_progress.close()
        self.dialog_progress = None
    def increment_percent(self, val=0.07):
        self.percent += val
        self.percent = min(self.percent,100)
        self.dialog_progress.update(int(self.percent))
        if self.percent == 100:
            self.percent = 80
    def percent(self):
        return self.percent
    def update(self
               ,percent
               ,message=None
               ,line2=None
               ,line3=None
               ):
        if not self.dialog_progress: return

        percent = min(percent,100)
##        Log(repr(percent),xbmc.LOGNONE)
        if not message:
            self.dialog_progress.update(int(percent))
            self.percent = percent
            return
        if line2 is None:
            self.dialog_progress.update(int(percent), message)
            self.percent = percent
            return
        if line3 is None:
            self.dialog_progress.update(int(percent), message, line2)
            self.percent = percent
            return
        self.dialog_progress.update(int(percent), message, line2, line3)
        self.percent = percent

        if self.percent == 100:
            self.percent = 90
#__________________________________________________________________
#
def Add_Refresh_Item(mode, name=C.STANDARD_MESSAGE_REFRESH, iconimage=C.refresh_icon, progress_dialog=None, end_directory=False, duration=C.STANDARD_DURATION_REFRESH ):
##    Kodi 18 needs these options for container.refresh to work
##        ,duration=C.STANDARD_DURATION_REFRESH 
##        ,Folder=False 
    if progress_dialog:
        if progress_dialog.iscanceled():
            end_directory = False
            addDir(
                name='Refresh this Cancelled Listing'
                ,url=C.DO_NOTHING_URL
                ,mode=mode
                ,iconimage=C.warning_icon
                ,duration=duration
                ,Folder=False 
                )
    if end_directory:
        addDir(
            name=name
            ,url=C.DO_NOTHING_URL
            ,mode=mode
            ,iconimage=iconimage
            ,duration=duration
            ,Folder=False 
            )
#__________________________________________________________________________
#
class ThreadWithStopEvent(threading.Thread):
    _stop_event = None
    def __init__(self, group=None, target=None, name=None, args=(), kwargs=None, stop_event=None):
	super(ThreadWithStopEvent,self).__init__(group=group, target=target, name=name, args=args, kwargs=kwargs)
	self.args = args
	self.kwargs = kwargs
        self._stop_event = stop_event
#__________________________________________________________________
#
def Is_Online(server=C.DEFAULT_IS_ONLINE_SERVER_NAME, port=C.DEFAULT_IS_ONLINE_SERVER_PORT):

    #todo: maybe change this to be proxy aware i.e. do a http get to server
    
    #use simplecache to store last time we did a network check
    # ... works like a static var across all threads
    cache_id = C.addon_id+'.Is_Online.'+"last_online_check"
    last_online_check = global_cache.get(cache_id)
    if last_online_check:
##        Log("skip Is_Online() Error to be more obvious on logs") #dev
        return True

    
    ip = xbmc.getIPAddress() #in case we don't have IP
    if (not ip) or ip.startswith('169.254'): # or ip.startswith('172.'):
        Log("Is_Online() Error false because lack of IP", C.LOGNONE)
        return False

    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(5)
    try:
        qq = s.connect_ex((server, int(port)))
        if not qq == 0: raise Exception(qq)
    except:
        if C.DEBUG: traceback.print_exc()
        Log("Is_Online() Error false because connect_ex error to {}:{}".format(server,port), C.LOGNONE)
        return False
    finally:
        s.close()

    last_online_check = datetime.datetime.now()
    global_cache.set(
        endpoint = cache_id
        ,data = repr(datetime.datetime.now())
        ,expiration = datetime.timedelta(seconds=C.default_ISONLINE_cache_duration)
        )
    
    return True
#__________________________________________________________________
#
def crawl(q, all_method_results):
##    Log(repr(q.empty()))
    while not q.empty():
        work = q.get(timeout=C.WEBCRAWLER_THREAD_TIMEOUT)
##        Log(repr(work))
        index_for_result = work[0]
        method_to_call = work[1]
        keyword_arguments_for_method_to_call = work[2]
        import time
        t_start = time.clock()
        try:
            single_method_result = method_to_call(**keyword_arguments_for_method_to_call)
        except Exception as ex:
            single_method_result = repr(ex)
        all_method_results[index_for_result] = single_method_result
        t_end = time.clock()
        q.task_done()
        Log("The time spent in thread {} is {}".format(index_for_result, t_end - t_start)
##            , C.LOGNONE
            )
        
    return True
#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
#__________________________________________________________________
#
