# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os,sys,re,json,zipfile,datetime,time,traceback
import io,xbmc

from resources.lib.modules import trakt
from resources.lib.modules import cleantitle
from resources.lib.modules import cleangenre
from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import playcount
from resources.lib.modules import workers
from resources.lib.modules import views
from resources.lib.modules import utils

from resources.lib.modules.log_utils import log as Log
from resources.lib.modules.log_utils import logR as LogR
from resources.lib import constants as C


##,StringIO,urllib,

from resources.lib.constants import StringIO
from resources.lib.constants import urlparse
from resources.lib.constants import urlencode
from resources.lib.constants import quote_plus

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()

action = params.get('action')

METAHANDLER_WATCHED = 7
METAHANDLER_UNWATCHED = 6

class seasons:
    def __init__(self):
        self.list = []

        self.lang = control.apiLanguage()['tvdb']
        self.showunaired = control.setting('showunaired') or 'true'
        self.unairedcolor = control.setting('unaired.identify')
        if self.unairedcolor == '':
            self.unairedcolor = 'red'
        self.datetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
        self.today_date = (self.datetime).strftime('%Y-%m-%d')
        self.tvdb_key = control.setting('tvdb.user')
        if self.tvdb_key == '' or self.tvdb_key == None:
            self.tvdb_key = '1D62F2F90030C444'
        self.tvdb_info_link = 'https://thetvdb.com/api/%s/series/%s/all/%s.zip' % (self.tvdb_key, '%s', '%s')
        self.tvdb_by_imdb = 'https://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s'
        self.tvdb_by_query = 'https://thetvdb.com/api/GetSeries.php?seriesname=%s'
        self.tvdb_image = 'https://thetvdb.com/banners/{}|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36&Accept-Encoding=gzip'
        #self.tvdb_image = 'https://thetvdb.com/banners/{}|'
        ##self.tvdb_image = 'https://thetvdb.com/banners/{}'
        self.tvdb_poster = 'https://thetvdb.com/banners/_cache/'


    def get(self, tvshowtitle, year, imdb, tvdb, idx=True, create_directory=True):
        if control.window.getProperty('PseudoTVRunning') == 'True':
            return episodes().get(tvshowtitle, year, imdb, tvdb)

        if idx == True:
            self.list = cache.get(self.tvdb_list, 24, tvshowtitle, year, imdb, tvdb, self.lang)
            if create_directory == True: self.seasonDirectory(self.list)
            return self.list
        else:
            self.list = self.tvdb_list(tvshowtitle, year, imdb, tvdb, 'en')
            return self.list


    def tvdb_list(self, tvshowtitle, year, imdb, tvdb, lang, limit='',tmdb='0'):
        Log(control.myName(__name__))
        try:

            if imdb == '0':
                Log("imdb == '0'")
                try:
                    t_show = trakt.SearchTVShow(tvshowtitle, year, full=False)
                    imdb = t_show[0]
                    imdb = imdb.get('show', '0')
                    imdb = imdb.get('ids', {}).get('imdb', '0')
                    imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))

                    if not imdb: imdb = '0'
                except:
                    imdb = '0'
                    raise

            if tvdb == '0' and not imdb == '0':
                Log("tvdb == '0' and not imdb == '0'")
                url = self.tvdb_by_imdb % imdb

                result = client.request(url, timeout='10')

                try: tvdb = client.parseDOM(result, 'seriesid')[0]
                except: tvdb = '0'

                try: name = client.parseDOM(result, 'SeriesName')[0]
                except: name = '0'
                dupe = re.compile(r'[***]Duplicate (\d*)[***]').findall(name)
                if len(dupe) > 0: tvdb = str(dupe[0])

                if tvdb == '': tvdb = '0'

            if tmdb == '0':
                Log("tmdb == '0'")
                t_show = trakt.SearchTVShow(tvshowtitle, year, full=False)
                tmdb = t_show[0]
                tmdb = tmdb.get('show', '0')
                tmdb = tmdb.get('ids', {}).get('tmdb', '0')
                tmdb = str(tmdb)
                    

            if tvdb == '0':
                Log("tvdb == '0' for {}".format(tvshowtitle),C.LOGERROR)

##GET https://api.trakt.tv//search/tmdb/66732?type=show HTTP/1.1
##Host: api.trakt.tv
##User-Agent: python-requests/2.31.0
##Accept-Encoding: gzip, deflate
##Accept: */*
##Connection: keep-alive
##trakt-api-version: 2
##trakt-api-key: e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467
##Content-Type: application/json


                url = self.tvdb_by_query % (quote_plus(tvshowtitle))

                years = [str(year), str(int(year)+1), str(int(year)-1)]

                tvdb = client.request(url, timeout='10')
                tvdb = re.sub(r'[^\x00-\x7F]+', '', tvdb)
                tvdb = client.replaceHTMLCodes(tvdb)
                tvdb = client.parseDOM(tvdb, 'Series')
                tvdb = [(x, client.parseDOM(x, 'SeriesName'), client.parseDOM(x, 'FirstAired')) for x in tvdb]
                tvdb = [(x, x[1][0], x[2][0]) for x in tvdb if len(x[1]) > 0 and len(x[2]) > 0]
                tvdb = [x for x in tvdb if cleantitle.get(tvshowtitle) == cleantitle.get(x[1])]
                tvdb = [x[0][0] for x in tvdb if any(y in x[2] for y in years)][0]
                tvdb = client.parseDOM(tvdb, 'seriesid')[0]

                if tvdb == '': tvdb = '0'
        except:
            traceback.print_exc()
            raise

        episodes = seasons = []

        try:
            if tvdb == '0':
                Log('tvdb is zero')
                return

            url = self.tvdb_info_link % (tvdb, 'en')
            data = client.request(url,timeout=20)

            if C.PY3:
                zip = zipfile.ZipFile(io.BytesIO(data))
            else:
                zip = zipfile.ZipFile(StringIO.StringIO(data))
            result = zip.read('%s.xml' % 'en')
            artwork = zip.read('banners.xml')
            try: actors_xml = zip.read('actors.xml')
            except: actors_xml = None
            zip.close()

            dupe = client.parseDOM(result, 'SeriesName')[0]
            dupe = re.compile(r'[***]Duplicate (\d*)[***]').findall(dupe)

            if len(dupe) > 0:
                tvdb = str(dupe[0]).encode('utf-8')

                url = self.tvdb_info_link % (tvdb, 'en')
                data = client.request(url,timeout=20)


                if C.PY3:
                    zip = zipfile.ZipFile(StringIO.BytesIO(data))
                else:
                    zip = zipfile.ZipFile(StringIO.StringIO(data))

                result = zip.read('%s.xml' % 'en')
                artwork = zip.read('banners.xml')
                zip.close()

            if not lang == 'en':
                url = self.tvdb_info_link % (tvdb, lang)
                data = client.request(url,timeout=30)

                if C.PY3:
                    zip = zipfile.ZipFile(StringIO.BytesIO(data))
                else:
                    zip = zipfile.ZipFile(StringIO.StringIO(data))

                result2 = zip.read('%s.xml' % lang)
                zip.close()
            else:
                result2 = result


            #py3 issue
            if C.PY3:
                if isinstance(artwork, bytes): artwork = artwork.decode()
                if isinstance(result, bytes):  result = result.decode()
                if isinstance(result2, bytes): result2 = result2.decode()
    
            artwork = artwork.split('<Banner>')
            artwork = [i for i in artwork if '<Language>en</Language>' in i and '<BannerType>season</BannerType>' in i]
            artwork = [i for i in artwork if not 'seasonswide' in re.findall('<BannerPath>(.+?)</BannerPath>', i)[0]]



            result = result.split('<Episode>')
            result2 = result2.split('<Episode>')

            item = result[0] ; item2 = result2[0]

            episodes = [i for i in result if '<EpisodeNumber>' in i]
            if control.setting('tv.specials') == 'true':
                episodes = [i for i in episodes]
            else:
                episodes = [i for i in episodes if not '<SeasonNumber>0</SeasonNumber>' in i]
                episodes = [i for i in episodes if not '<EpisodeNumber>0</EpisodeNumber>' in i]

            seasons = [i for i in episodes if '<EpisodeNumber>1</EpisodeNumber>' in i]

            locals = [i for i in result2 if '<EpisodeNumber>' in i]

            result = '' ; result2 = ''

            if limit == '':
                episodes = []
            elif limit == '-1':
                seasons = []
            else:
                episodes = [i for i in episodes if '<SeasonNumber>%01d</SeasonNumber>' % int(limit) in i]
                seasons = []

            try: poster = client.parseDOM(item, 'poster')[0]
            except: poster = ''
            if not poster == '': poster = self.tvdb_image.format(poster)
            else: poster = '0'
            poster = client.replaceHTMLCodes(poster)
            if C.PY2: poster = poster.encode('utf-8')

            try: banner = client.parseDOM(item, 'banner')[0]
            except: banner = ''
            if not banner == '': banner = self.tvdb_image.format(banner)
            else: banner = '0'
            banner = client.replaceHTMLCodes(banner)
            if C.PY2: banner = banner.encode('utf-8')

            try: fanart = client.parseDOM(item, 'fanart')[0]
            except: fanart = ''
            if not fanart == '': fanart = self.tvdb_image.format(fanart)
            else: fanart = '0'
            fanart = client.replaceHTMLCodes(fanart)
            if C.PY2: fanart = fanart.encode('utf-8')

            if not poster == '0': pass
            elif not fanart == '0': poster = fanart
            elif not banner == '0': poster = banner

            if not banner == '0': pass
            elif not fanart == '0': banner = fanart
            elif not poster == '0': banner = poster

            try: status = client.parseDOM(item, 'Status')[0]
            except: status = ''
            if status == '': status = 'Ended'
            status = client.replaceHTMLCodes(status)
            if C.PY2: status = status.encode('utf-8')

            try: studio = client.parseDOM(item, 'Network')[0]
            except: studio = ''
            if studio == '': studio = '0'
            studio = client.replaceHTMLCodes(studio)
            if C.PY2: studio = studio.encode('utf-8')

            try: genre = client.parseDOM(item, 'Genre')[0]
            except: genre = ''
            genre = [x for x in genre.split('|') if not x == '']
            genre = ' / '.join(genre)
            if genre == '': genre = '0'
            genre = client.replaceHTMLCodes(genre)
            if C.PY2: genre = genre.encode('utf-8')

            try: duration = client.parseDOM(item, 'Runtime')[0]
            except: duration = ''
            if duration == '': duration = '0'
            duration = client.replaceHTMLCodes(duration)
            if C.PY2: duration = duration.encode('utf-8')

            try: rating = client.parseDOM(item, 'Rating')[0]
            except: rating = ''
            if rating == '': rating = '0'
            rating = client.replaceHTMLCodes(rating)
            if C.PY2: rating = rating.encode('utf-8')

            try: votes = client.parseDOM(item, 'RatingCount')[0]
            except: votes = '0'
            if votes == '': votes = '0'
            votes = client.replaceHTMLCodes(votes)
            if C.PY2: votes = votes.encode('utf-8')

            try: mpaa = client.parseDOM(item, 'ContentRating')[0]
            except: mpaa = ''
            if mpaa == '': mpaa = '0'
            mpaa = client.replaceHTMLCodes(mpaa)
            if C.PY2: mpaa = mpaa.encode('utf-8')

            if actors_xml:
                try:
                    cast = client.parseDOM(actors_xml, 'Actors')
                    cast = client.parseDOM(cast, 'Actor')
                except: cast = []                
            else:
                try: cast = client.parseDOM(item, 'Actors')[0]
                except: cast = ''
                cast = [x for x in cast.split('|') if not x == '']
                try:
                    if C.PY2: cast = [(x.encode('utf-8'), '') for x in cast]
                    else: cast = [(x, '') for x in cast]
                except: cast = []

            try: label = client.parseDOM(item2, 'SeriesName')[0]
            except: label = '0'
            label = client.replaceHTMLCodes(label)
            if C.PY2: label = label.encode('utf-8')

            try: plot = client.parseDOM(item2, 'Overview')[0]
            except: plot = ''
            if plot == '': plot = '0'
            plot = client.replaceHTMLCodes(plot)
            if C.PY2: plot = plot.encode('utf-8')


            first_air_date_year = client.parseDOM(item, 'FirstAired')[0]
            if first_air_date_year == '' or '-00' in first_air_date_year: first_air_date_year = '0'
            first_air_date_year = first_air_date_year[0:4]
            
            
            unaired = ''
        except:
            traceback.print_exc()
            pass

        for item in seasons: #only used in flattened season view
##            LogR(item) #this the first individual Episode in a season;  some info will not exist
            try:

                premiered = client.parseDOM(item, 'FirstAired')[0]
                if premiered == '' or '-00' in premiered: premiered = '0'
                premiered = client.replaceHTMLCodes(premiered)
                if C.PY2: premiered = premiered.encode('utf-8')

                if status == 'Ended': pass
                elif premiered == '0':
                    LogR(item,C.LOGWARNING)
                    Log('FirstAired/premiered is zero; sometimes because it is future season/episode',C.LOGWARNING)
                    #raise Exception('premiered is zero; sometimes because it is future season/episode')
                elif int(re.sub('[^0-9]', '', str(premiered))) > int(re.sub('[^0-9]', '', str(self.today_date))):
                    unaired = 'true'
                    if self.showunaired != 'true': #continue only if we must display unaired episodes
                        continue

                season = client.parseDOM(item, 'SeasonNumber')[0]
                season = '%01d' % int(season)
                if C.PY2: season = season.encode('utf-8')

                thumb = [i for i in artwork if client.parseDOM(i, 'Season')[0] == season]
                try: thumb = client.parseDOM(thumb[0], 'BannerPath')[0]
                except: thumb = ''
                if not thumb == '': thumb = self.tvdb_image.format(thumb)
                else: thumb = '0'
                thumb = client.replaceHTMLCodes(thumb)
                if C.PY2: thumb = thumb.encode('utf-8')

                if thumb == '0': thumb = poster

                aa = {'season': season
                      , 'tvshowtitle': tvshowtitle
                      , 'label': label
                      , 'year': year
                      , 'premiered': premiered
                      , 'status': status
                      , 'studio': studio
                      , 'genre': genre
                      , 'duration': duration
                      , 'rating': rating
                      , 'votes': votes
                      , 'mpaa': mpaa
                      , 'cast': cast
                      , 'plot': plot
                      , 'imdb': imdb
                      , 'tvdb': tvdb
                      , 'tmdb': tmdb
                      , 'poster': poster
                      , 'tmdb': tmdb
                      , 'banner': thumb
                      , 'fanart': thumb
                      , 'thumb': thumb
                      , 'first_air_date_year': first_air_date_year
                      #, 'unaired': unaired
                    }

                self.list.append(aa)
            except StopIteration:
                pass
            except:
                traceback.print_exc()
                raise
                pass

        duplicate_detector = {}
        for item in episodes: #this part will only be processed when 'flat' season is chosen
            #LogR(item,C.LOGWARNING)
            try:
                premiered = client.parseDOM(item, 'FirstAired')[0]
                if premiered == '' or '-00' in premiered: premiered = '0'
                premiered = client.replaceHTMLCodes(premiered)
                if C.PY2: premiered = premiered.encode('utf-8')

                if status == 'Ended': pass
                elif premiered == '0':
                    pass
##                    premiered = '2001-12-12'
##                    raise Exception()
                elif int(re.sub('[^0-9]', '', str(premiered))) > int(re.sub('[^0-9]', '', str(self.today_date))):
                    unaired = 'true'
                    if self.showunaired != 'true': #continue only if we must display unaired episodes
##                        raise Exception()
                        raise StopIteration


                if premiered == '0':
                    pre = client.parseDOM(item, 'FirstAired')[0]
                    if pre:
                        premiered = pre
                    else:
                        premiered = '2001-12-12'
                    LogR((pre,premiered))
                if C.PY2: premiered = premiered.encode('utf-8')
                    
    
                season = client.parseDOM(item, 'SeasonNumber')[0]
                season = '%01d' % int(season)
                if C.PY2: season = season.encode('utf-8')

                episode = client.parseDOM(item, 'EpisodeNumber')[0]
                episode = re.sub('[^0-9]', '', '%01d' % int(episode))
                if C.PY2: episode = episode.encode('utf-8')

                title = client.parseDOM(item, 'EpisodeName')[0]
                if title == '': title = '0'
                title = client.replaceHTMLCodes(title)
                if C.PY2: title = title.encode('utf-8')

                try: thumb = client.parseDOM(item, 'filename')[0]
                except: thumb = ''
                if not thumb == '': thumb = self.tvdb_image.format(thumb)
                else: thumb = '0'
                thumb = client.replaceHTMLCodes(thumb)
                if C.PY2: thumb = thumb.encode('utf-8')

                if not thumb == '0': pass
                elif not fanart == '0': thumb = fanart.replace(self.tvdb_image, self.tvdb_poster)
                elif not poster == '0': thumb = poster

                try: rating = client.parseDOM(item, 'Rating')[0]
                except: rating = ''
                if rating == '': rating = '0'
                rating = client.replaceHTMLCodes(rating)
                if C.PY2: rating = rating.encode('utf-8')

                try: director = client.parseDOM(item, 'Director')[0]
                except: director = ''
                director = [x for x in director.split('|') if not x == '']
                director = ' / '.join(director)
                if director == '': director = '0'
                director = client.replaceHTMLCodes(director)
                if C.PY2: director = director.encode('utf-8')

                try: writer = client.parseDOM(item, 'Writer')[0]
                except: writer = ''
                writer = [x for x in writer.split('|') if not x == '']
                writer = ' / '.join(writer)
                if writer == '': writer = '0'
                writer = client.replaceHTMLCodes(writer)
                if C.PY2: writer = writer.encode('utf-8')

                try: guestStars = client.parseDOM(item, 'GuestStars')[0]
                except: guestStars = []
##                LogR(guestStars)
                guestStars = ["<name>{}</name><role></role><image></image><sortorder>99</sortorder>".format(x) for x in guestStars.split('|') if not x == '']
##                LogR(guestStars)
##                try:
##                    if C.PY2: guestStars = [(x.encode('utf-8'), '') for x in guestStars]
##                    else: guestStars = [(x, '') for x in guestStars]
##                except: guestStars = []
##                LogR(cast)
##                LogR(guestStars)
                cast2 = cast + guestStars
##                cast2 = guestStars                
##                LogR(cast2)

                try:
                    local = client.parseDOM(item, 'id')[0]
                    local = [x for x in locals if '<id>%s</id>' % str(local) in x][0]
                except:
                    local = item

                label = client.parseDOM(local, 'EpisodeName')[0]
                if label == '': label = '0'
                label = client.replaceHTMLCodes(label)
                if C.PY2: label = label.encode('utf-8')

                try: episodeplot = client.parseDOM(local, 'Overview')[0]
                except: episodeplot = ''
                if episodeplot == '': episodeplot = '0'
                if episodeplot == '0': episodeplot = plot
                episodeplot = client.replaceHTMLCodes(episodeplot)
                try:
                    if C.PY2: episodeplot = episodeplot.encode('utf-8')
                except: pass


                aa = {  'title': title
                      , 'label': label
                      , 'season': season
                      , 'episode': episode
                      , 'tvshowtitle': tvshowtitle
                      , 'year': year
                      , 'premiered': premiered
                      , 'status': status
                      , 'studio': studio
                      , 'genre': genre
                      , 'duration': duration
                      , 'rating': rating
                      , 'votes': votes
                      , 'mpaa': mpaa
                      , 'director': director
                      , 'writer': writer
                      , 'cast': cast2
                      , 'plot': episodeplot
                      , 'imdb': imdb
                      , 'tvdb': tvdb
                      , 'tmdb': tmdb
                      , 'poster': poster
                      , 'banner': thumb
                      , 'fanart': thumb
                      , 'thumb': thumb
                      , 'first_air_date_year' : first_air_date_year
                      #, 'unaired': unaired
                      }
                
                #compensate for tvdb buggy data
                duplicate_index = "{}x{}".format(season,episode)

                if C.PY2:
                    if not duplicate_detector.has_key(duplicate_index):
                        duplicate_detector[duplicate_index] = aa
                        self.list.append(aa)
                else:
                    if not duplicate_index in duplicate_detector.keys():
                        duplicate_detector[duplicate_index] = aa
                        self.list.append(aa)
                        
            except StopIteration:
                pass
            except:
                LogR(item,C.LOGWARNING)
                traceback.print_exc()
##                raise
                pass

##        LogR(self.list)
##        raise Exception()
        return self.list


    def seasonDirectory(self, items):
        LogR(control.myName(__name__))
##        LogR(locals())
        
        if items == None or len(items) == 0:
            syshandle = int(sys.argv[1])
            control.directory(syshandle, cacheToDisc=True)
            control.idle()
            sys.exit()

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        addonPoster, addonBanner = control.addonPoster(), control.addonBanner()

        addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')

        traktCredentials = trakt.getTraktCredentialsInfo()

        try: isOld = False ; control.item().getArt('type')
        except: isOld = True

        try:
            indicators = playcount.getSeasonIndicators(items[0]['imdb'])
        except:
            raise
            pass

        watchedMenu = control.lang(32068).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32066).encode('utf-8')

        unwatchedMenu = control.lang(32069).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32067).encode('utf-8')

        queueMenu = control.lang(32065).encode('utf-8')

        traktManagerMenu = control.lang(32070).encode('utf-8')

        #labelMenu = control.lang(32055).encode('utf-8')
        if C.PY2:
            labelMenu = control.lang(32055).encode('utf-8')
        else:
            labelMenu = control.lang(32055)

        playRandom = control.lang(32535).encode('utf-8')

        addToLibrary = control.lang(32551).encode('utf-8')

        for i in items:
##            LogR(i)
            try:
                label = '%s %s' % (labelMenu, i['season'])
                try:
                    if i['unaired'] == 'true':
                        label = '[COLOR darkred][I]%s[/I][/COLOR]' % label
                except:
                    pass
                systitle = sysname = quote_plus(i['tvshowtitle'])

                imdb, tvdb, year, season= i['imdb'], i['tvdb'], i['year'], i['season']
                if 'tmdb' in i: tmdb = str(i['tmdb'])
                else: tmdb = '0'

                if C.PY2:
                    meta = dict((k,v) for k, v in i.iteritems() if not v == '0')
                else:
                    meta = dict((k,v) for k, v in i.items() if not v == '0')
                meta.update({'code': imdb, 'imdbnumber': imdb, 'imdb_id': imdb})
                meta.update({'tvdb_id': tvdb})
                meta.update({'tmdb_id': tmdb})
                meta.update({'mediatype': 'tvshow'})
                meta.update({'trailer': '%s?action=trailer&name=%s' % (sysaddon, sysname)})

                if not 'duration' in i: meta.update({'duration': '60'})
                elif i['duration'] == '0': meta.update({'duration': '60'})
                try: meta.update({'duration': str(int(meta['duration']) * 60)})
                except: pass
                try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
                except: pass

                try:
                    if indicators and (season in indicators):
                        meta.update({'playcount': 1, 'overlay': METAHANDLER_WATCHED})
                    else:
                        meta.update({'playcount': 0, 'overlay': METAHANDLER_UNWATCHED})
                except:
                    raise
                    pass


                url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s&season=%s' % (sysaddon, systitle, year, imdb, tvdb, season)

                cm = []
                
                cm.append((playRandom, 'RunPlugin(%s?action=random&rtype=episode&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s&season=%s)' % (sysaddon, quote_plus(systitle), quote_plus(year), quote_plus(imdb), quote_plus(tvdb), quote_plus(season))))

                cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                cm.append((watchedMenu, 'RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tvdb=%s&season=%s&query=7)' % (sysaddon, systitle, imdb, tvdb, season)))

                cm.append((unwatchedMenu, 'RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tvdb=%s&season=%s&query=6)' % (sysaddon, systitle, imdb, tvdb, season)))

                if traktCredentials == True:
                    cm.append((traktManagerMenu, 'RunPlugin(%s?action=traktManager&name=%s&tvdb=%s&content=tvshow)' % (sysaddon, sysname, tvdb)))

                if isOld == True:
                    cm.append((control.lang2(19033).encode('utf-8'), 'Action(Info)'))

                cm.append((addToLibrary, 'RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s)' % (sysaddon, systitle, year, imdb, tvdb)))

                item = control.item(label=label)
                item.setContentLookup(False) #prevent HEAD requests

                art = {}

                if 'thumb' in i and not i['thumb'] == '0':
                    art.update({'icon': i['thumb'], 'thumb': i['thumb'], 'poster': i['thumb']})
                elif 'poster' in i and not i['poster'] == '0':
                    art.update({'icon': i['poster'], 'thumb': i['poster'], 'poster': i['poster']})
                else:
                    art.update({'icon': addonPoster, 'thumb': addonPoster, 'poster': addonPoster})

                if 'banner' in i and not i['banner'] == '0':
                    art.update({'banner': i['banner']})
                elif 'fanart' in i and not i['fanart'] == '0':
                    art.update({'banner': i['fanart']})
                else:
                    art.update({'banner': addonBanner})

                if settingFanart == 'true' and 'fanart' in i and not i['fanart'] == '0':
                    item.setProperty('Fanart_Image', i['fanart'])
                elif not addonFanart == None:
                    item.setProperty('Fanart_Image', addonFanart)

##                LogR(art)
                item.setArt(art)
                item.addContextMenuItems(cm)




                if C.PY2:
                    max_loops = 1000
                    loop_count = 0
                    was_changed = True
                    while (was_changed == True)  and  (loop_count < max_loops) :
                        loop_count = loop_count + 1
                        was_changed = False
                        for a in meta:
                            if a == 'imdb':
                                was_changed = True
                                meta['imdbnumber'] = meta[a]
                                meta.pop(a)
                                break
                            if a in C.bad_attributes:
                                was_changed = True
                                meta.pop(a)
                                break
                    item.setInfo(type='Video', infoLabels = meta)
                    video_streaminfo = {'codec': 'h264'}
                    item.addStreamInfo('video', video_streaminfo)
                else:
                    videoInfoTag = item.getVideoInfoTag()
##                    vsd = xbmc.VideoStreamDetail()
##                    vsd.setCodec('h264')
##                    videoInfoTag.addVideoStream(vsd) #probably not needed
                    for a in meta:
##                        Log(repr((a,meta[a])))
                        if a == "tvshowtitle": videoInfoTag.setTvShowTitle(meta[a])
                        if a == "title": videoInfoTag.setTitle(meta[a])
                        if a == "originaltitle": videoInfoTag.setOriginalTitle(meta[a])
                        if a == "first_air_date_year": videoInfoTag.setYear(int(meta[a]))
                        if a == "premiered": videoInfoTag.setPremiered(meta[a])
                        if a == "duration": videoInfoTag.setDuration(int(meta[a]))
                        if a == "rating": videoInfoTag.setRating(float(meta[a]))
                        if a == "mpaa": videoInfoTag.setMpaa(meta[a])
                        if a == "plot": videoInfoTag.setPlot(meta[a])
                        if a == "tagline": videoInfoTag.setTagLine(meta[a])
                        if a == "code": videoInfoTag.setProductionCode(meta[a])
                        if a == "imdbnumber": videoInfoTag.setIMDBNumber(meta[a])
                        if a == "mediatype": videoInfoTag.setMediaType(meta[a])
                        if a == "dateadded": videoInfoTag.setDateAdded(meta[a])
                        if a == "cast":
                            actors = []
                            for actor_info in meta[a]:
                                name = client.parseDOM(actor_info, 'name')[0]
                                t = client.parseDOM(actor_info, 'image')[0]
                                if t: thumbnail = self.tvdb_image.format(t)
                                else: thumbnail = ""
                                role = client.parseDOM(actor_info, 'role')[0]
                                order = int(client.parseDOM(actor_info, 'sortorder')[0])
                                actors.append(xbmc.Actor(name=name,thumbnail=thumbnail,role=role,order=order))
                            videoInfoTag.setCast(actors)


                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
            except:
                traceback.print_exc()

        try: control.property(syshandle, 'showplot', items[0]['plot'])
        except: pass

        control.content(syshandle, 'seasons')
        control.directory(syshandle, cacheToDisc=True)
        views.setView('seasons', {'skin.estuary': 55, 'skin.confluence': 500})


class episodes:
    def __init__(self):
        self.list = []

        self.trakt_link = 'http://api.trakt.tv'
        self.tvmaze_link = 'http://api.tvmaze.com'
        self.tvdb_key = control.setting('tvdb.user')
        if self.tvdb_key == '' or self.tvdb_key == None:
            self.tvdb_key = '1D62F2F90030C444'
        self.datetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
        self.systime = (self.datetime).strftime('%Y%m%d%H%M%S%f')
        self.today_date = (self.datetime).strftime('%Y-%m-%d')
        self.trakt_user = control.setting('trakt.user').strip()
        self.lang = control.apiLanguage()['tvdb']
        self.showunaired = control.setting('showunaired') or 'true'

        self.tvdb_info_link = 'https://thetvdb.com/api/%s/series/%s/all/%s.zip' % (self.tvdb_key, '%s', '%s')
        #self.tvdb_image = 'https://thetvdb.com/banners/{}|User-Agent%3A+Mozilla%2F5.0+(Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A136.0)+Gecko%2F20100101+Firefox%2F136.0%0D%0A'
        self.tvdb_image = 'https://thetvdb.com/banners1111/{}|User-Agent%3A+Mozilla%0D%0A'
        self.tvdb_poster = 'https://thetvdb.com/banners/_cache/'

        self.added_link = 'http://api.tvmaze.com/schedule'
        #https://api.trakt.tv/calendars/all/shows/date[30]/31 #use this for new episodes?
        #self.mycalendar_link = 'http://api.trakt.tv/calendars/my/shows/date[29]/60/'
        self.mycalendar_link = 'http://api.trakt.tv/calendars/my/shows/date[30]/31/' #go back 30 and show all shows aired until tomorrow
        self.trakthistory_link = 'http://api.trakt.tv/users/me/history/shows?limit=300'
        self.progress_link = 'http://api.trakt.tv/users/me/watched/shows'
        self.hiddenprogress_link = 'http://api.trakt.tv/users/hidden/progress_watched?limit=1000&type=show'
        self.calendar_link = 'http://api.tvmaze.com/schedule?date=%s'
        self.onDeck_link = 'http://api.trakt.tv/sync/playback/episodes?extended=full&limit=10'
        self.traktlists_link = 'http://api.trakt.tv/users/me/lists'
        self.traktlikedlists_link = 'http://api.trakt.tv/users/likes/lists?limit=1000000'
        self.traktlist_link = 'http://api.trakt.tv/users/%s/lists/%s/items'



            
    def get(self, tvshowtitle, year, imdb, tvdb, season=None, episode=None, idx=True, create_directory=True):
        Log(control.myName(__name__))
        try:
            if idx == True:
                if season == None and episode == None:
                    Log('season == None and episode == None')
                    self.list = cache.get(seasons().tvdb_list, 1, tvshowtitle, year, imdb, tvdb, self.lang, '-1')
                elif episode == None:
                    Log('episode == None')
                    self.list = cache.get(seasons().tvdb_list, 1, tvshowtitle, year, imdb, tvdb, self.lang, season)
                else:
                    Log('idx3')
                    self.list = cache.get(seasons().tvdb_list, 1, tvshowtitle, year, imdb, tvdb, self.lang, '-1')
                    num = [x for x,y in enumerate(self.list) if y['season'] == str(season) and  y['episode'] == str(episode)][-1]
                    self.list = [y for x,y in enumerate(self.list) if x >= num]

                if create_directory == True:
                    self.episodeDirectory(self.list)
                return self.list
            else:
                self.list = seasons().tvdb_list(tvshowtitle, year, imdb, tvdb, 'en', '-1')
                return self.list
        except:
            traceback.print_exc()
            pass


    def calendar(self, url):
        Log(control.myName(__name__))
        try:
            try: url = getattr(self, url + '_link')
            except: pass

            if self.trakt_link in url and url == self.onDeck_link:
                self.blist = cache.get(self.trakt_episodes_list, 720, url, self.trakt_user, self.lang)
                self.list = []
                self.list = cache.get(self.trakt_episodes_list, 0, url, self.trakt_user, self.lang)
                self.list = self.list[::-1]

            elif self.trakt_link in url and url == self.progress_link:
                self.blist = cache.get(self.trakt_progress_list, 720, url, self.trakt_user, self.lang)
                self.list = []
                self.list = cache.get(self.trakt_progress_list, 0, url, self.trakt_user, self.lang)

            elif self.trakt_link in url and url == self.mycalendar_link:
                self.blist = cache.get(self.trakt_episodes_list, 720, url, self.trakt_user, self.lang)
                self.list = []
                self.list = cache.get(self.trakt_episodes_list, 0, url, self.trakt_user, self.lang)

            elif self.trakt_link in url and '/users/' in url:
                self.list = cache.get(self.trakt_list, 0, url, self.trakt_user)
                self.list = self.list[::-1]

            elif self.trakt_link in url:
                self.list = cache.get(self.trakt_list, 1, url, self.trakt_user)


            elif self.tvmaze_link in url and url == self.added_link:
                urls = [i['url'] for i in self.calendars(idx=False)][:5]
                self.list = []
                for url in urls:
                    self.list += cache.get(self.tvmaze_list, 720, url, True)

            elif self.tvmaze_link in url:
                self.list = cache.get(self.tvmaze_list, 1, url, False)

            self.episodeDirectory(self.list)

            
            return self.list
        except:
            traceback.print_exc()
##            raise
            pass


    def widget(self):
        if trakt.getTraktIndicatorsInfo() == True:
            setting = control.setting('tv.widget.alt')
        else:
            setting = control.setting('tv.widget')

        if setting == '2':
            self.calendar(self.progress_link)
        elif setting == '3':
            self.calendar(self.mycalendar_link)
        else:
            self.calendar(self.added_link)


    def calendars(self, idx=True):
        if C.PY2: m = control.lang(32060).encode('utf-8').split('|')
        else: m = control.lang(32060).split('|')
        
        try: months = [(m[0], 'January'), (m[1], 'February'), (m[2], 'March'), (m[3], 'April'), (m[4], 'May'), (m[5], 'June'), (m[6], 'July'), (m[7], 'August'), (m[8], 'September'), (m[9], 'October'), (m[10], 'November'), (m[11], 'December')]
        except: months = []

        if C.PY2: d = control.lang(32061).encode('utf-8').split('|')
        else:     d = control.lang(32061).split('|')
            
        try: days = [(d[0], 'Monday'), (d[1], 'Tuesday'), (d[2], 'Wednesday'), (d[3], 'Thursday'), (d[4], 'Friday'), (d[5], 'Saturday'), (d[6], 'Sunday')]
        except: days = []

        for i in range(0, 30):
            try:
                name = (self.datetime - datetime.timedelta(days = i))
                name = (control.lang(32062) % (name.strftime('%A'), name.strftime('%d %B')))
                if C.PY2: name = name.encode('utf-8')
                for m in months: name = name.replace(m[1], m[0])
                for d in days: name = name.replace(d[1], d[0])
                try: name = name.encode('utf-8')
                except: pass

                url = self.calendar_link % (self.datetime - datetime.timedelta(days = i)).strftime('%Y-%m-%d')

                self.list.append({'name': name, 'url': url, 'image': 'calendar.png', 'action': 'calendar'})
            except:
                pass
        if idx == True: self.addDirectory(self.list)

        return self.list


    def userlists(self):
        try:
            userlists = []
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            activity = trakt.getActivity()
        except:
            pass

        try:
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlists_link, self.trakt_user): raise Exception()
                userlists += cache.get(self.trakt_user_list, 720, self.traktlists_link, self.trakt_user)
            except:
                userlists += cache.get(self.trakt_user_list, 0, self.traktlists_link, self.trakt_user)
        except:
            pass
        try:
            self.list = []
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlikedlists_link, self.trakt_user): raise Exception()
                userlists += cache.get(self.trakt_user_list, 720, self.traktlikedlists_link, self.trakt_user)
            except:
                userlists += cache.get(self.trakt_user_list, 0, self.traktlikedlists_link, self.trakt_user)
        except:
            pass

        self.list = userlists
        for i in range(0, len(self.list)): self.list[i].update({'image': 'userlists.png', 'action': 'calendar'})
        self.addDirectory(self.list, queue=True)
        return self.list


    def trakt_list(self, url, user):
        try:
            for i in re.findall(r'date\[(\d+)\]', url):
                url = url.replace('date[%s]' % i, (self.datetime - datetime.timedelta(days = int(i))).strftime('%Y-%m-%d'))

            q = dict(urlparse.parse_qsl(urlparse.urlsplit(url).query))
            q.update({'extended': 'full'})
            q = (urlencode(q)).replace('%2C', ',')
            u = url.replace('?' + urlparse.urlparse(url).query, '') + '?' + q

            itemlist = []
            items = trakt.getTraktAsJson(u)
        except:
            print("Unexpected error in info builder script:", sys.exc_info()[0])
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type, exc_tb.tb_lineno)
            return

        for item in items:
            try:
                title = item['episode']['title']
                if title == None or title == '': raise Exception()
                title = client.replaceHTMLCodes(title)

                season = item['episode']['season']
                season = re.sub('[^0-9]', '', '%01d' % int(season))
                if season == '0': raise Exception()

                episode = item['episode']['number']
                episode = re.sub('[^0-9]', '', '%01d' % int(episode))
                if episode == '0': raise Exception()

                tvshowtitle = item['show']['title']
                if tvshowtitle == None or tvshowtitle == '': raise Exception()
                tvshowtitle = client.replaceHTMLCodes(tvshowtitle)

                year = item['show']['year']
                year = re.sub('[^0-9]', '', str(year))

                imdb = item['show']['ids']['imdb']
                if imdb == None or imdb == '': imdb = '0'
                else: imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))

                tvdb = item['show']['ids']['tvdb']
                if tvdb == None or tvdb == '': raise Exception()
                tvdb = re.sub('[^0-9]', '', str(tvdb))

                try:
                    tmdb = str(item['show']['ids']['tmdb'])
                except:
                    tmdb = '0'


                premiered = item['episode']['first_aired']
                try: premiered = re.compile(r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
                except: premiered = '0'

                studio = item['show']['network']
                if studio == None: studio = '0'

                genre = item['show']['genres']
                genre = [i.title() for i in genre]
                if genre == []: genre = '0'
                genre = ' / '.join(genre)

                try: duration = str(item['show']['runtime'])
                except: duration = '0'
                if duration == None: duration = '0'

                try: rating = str(item['episode']['rating'])
                except: rating = '0'
                if rating == None or rating == '0.0': rating = '0'

                try: votes = str(item['show']['votes'])
                except: votes = '0'
                try: votes = str(format(int(votes),',d'))
                except: pass
                if votes == None: votes = '0'

                mpaa = item['show']['certification']
                if mpaa == None: mpaa = '0'

                plot = item['episode']['overview']
                if plot == None or plot == '': plot = item['show']['overview']
                if plot == None or plot == '': plot = '0'
                plot = client.replaceHTMLCodes(plot)

                try:
                    if self.lang == 'en': raise Exception()

                    item = trakt.getTVShowTranslation(imdb, lang=self.lang, season=season, episode=episode,  full=True)

                    title = item.get('title') or title
                    plot = item.get('overview') or plot

                    tvshowtitle = trakt.getTVShowTranslation(imdb, lang=self.lang) or tvshowtitle
                except:
                    pass

                itemlist.append({  'title': title
                                 , 'season': season
                                 , 'episode': episode
                                 , 'tvshowtitle': tvshowtitle
                                 , 'year': year
                                 , 'premiered': premiered
                                 , 'status': 'Continuing'
                                 , 'studio': studio
                                 , 'genre': genre
                                 , 'duration': duration
                                 , 'rating': rating
                                 , 'votes': votes
                                 , 'mpaa': mpaa
                                 , 'plot': plot
                                 , 'imdb': imdb
                                 , 'tvdb': tvdb
                                 , 'tmdb': tmdb
                                 , 'poster': '0'
                                 , 'thumb': '0'})
            except:
                traceback.print_exc()
                pass

        itemlist = itemlist[::-1]
        return itemlist


    def trakt_progress_list(self, url, user, lang):
        try:
            url += '?extended=full'
            result = trakt.getTraktAsJson(url)
            items = []
        except:
            return

        sortorder = control.setting('prgr.sortorder')
        for item in result:
            try:
                num_1 = 0
                for i in range(0, len(item['seasons'])):
                    if item['seasons'][i]['number'] > 0: num_1 += len(item['seasons'][i]['episodes'])
                num_2 = int(item['show']['aired_episodes'])
                if num_1 >= num_2: raise Exception()

                season = str(item['seasons'][-1]['number'])

                episode = [x for x in item['seasons'][-1]['episodes'] if 'number' in x]
                episode = sorted(episode, key=lambda x: x['number'])
                episode = str(episode[-1]['number'])

                tvshowtitle = item['show']['title']
                if tvshowtitle == None or tvshowtitle == '': raise Exception()
                tvshowtitle = client.replaceHTMLCodes(tvshowtitle)

                year = item['show']['year']
                year = re.sub('[^0-9]', '', str(year))
                if int(year) > int(self.datetime.strftime('%Y')): raise Exception()

                imdb = item['show']['ids']['imdb']
                if imdb == None or imdb == '': imdb = '0'

                tvdb = item['show']['ids']['tvdb']
                if tvdb == None or tvdb == '': raise Exception()
                tvdb = re.sub('[^0-9]', '', str(tvdb))

                last_watched = item['last_watched_at']
                if last_watched == None or last_watched == '': last_watched = '0'
                items.append({'imdb': imdb
                              , 'tvdb': tvdb
                              , 'tmdb': tmdb
                              , 'tvshowtitle': tvshowtitle, 'year': year
                              , 'snum': season, 'enum': episode
                              , '_last_watched': last_watched})
            except:
                pass

        try:
            result = trakt.getTraktAsJson(self.hiddenprogress_link)
            result = [str(i['show']['ids']['tvdb']) for i in result]

            items = [i for i in items if not i['tvdb'] in result]
        except:
            pass

        def items_list(i):

            try:
                item = [x for x in self.blist if x['tvdb'] == i['tvdb'] and x['snum'] == i['snum'] and x['enum'] == i['enum']][0]
                item['action'] = 'episodes'
                self.list.append(item)
                return
            except:
                pass

            try:
                url = self.tvdb_info_link % (i['tvdb'], lang)
                data = client.request(url,timeout=10)


                zip = zipfile.ZipFile(StringIO.StringIO(data))
                result = zip.read('%s.xml' % lang)
                artwork = zip.read('banners.xml')
                zip.close()

                result = result.split('<Episode>')
                item = [x for x in result if '<EpisodeNumber>' in x]
                item2 = result[0]

                num = [x for x,y in enumerate(item) if re.compile('<SeasonNumber>(.+?)</SeasonNumber>').findall(y)[0] == str(i['snum']) and re.compile('<EpisodeNumber>(.+?)</EpisodeNumber>').findall(y)[0] == str(i['enum'])][-1]
                item = [y for x,y in enumerate(item) if x > num][0]

                premiered = client.parseDOM(item, 'FirstAired')[0]
                if premiered == '' or '-00' in premiered: premiered = '0'
                premiered = client.replaceHTMLCodes(premiered)
                if C.PY2: premiered = premiered.encode('utf-8')

                try: status = client.parseDOM(item2, 'Status')[0]
                except: status = ''
                if status == '': status = 'Ended'
                status = client.replaceHTMLCodes(status)
                if C.PY2: status = status.encode('utf-8')
                
                unaired = ''

                if status == 'Ended': pass
                elif premiered == '0': raise Exception()
                elif int(re.sub('[^0-9]', '', str(premiered))) > int(re.sub('[^0-9]', '', str(self.today_date))):
                    unaired = 'true'
                    if self.showunaired != 'true': #continue only if we must display unaired episodes
                        raise Exception()
                        raise StopIteration
                        

                title = client.parseDOM(item, 'EpisodeName')[0]
                if title == '': title = '0'
                title = client.replaceHTMLCodes(title)
                if C.PY2: title = title.encode('utf-8')

                season = client.parseDOM(item, 'SeasonNumber')[0]
                season = '%01d' % int(season)
                if C.PY2: season = season.encode('utf-8')

                episode = client.parseDOM(item, 'EpisodeNumber')[0]
                episode = re.sub('[^0-9]', '', '%01d' % int(episode))
                if C.PY2: episode = episode.encode('utf-8')

                tvshowtitle = i['tvshowtitle']
                imdb, tvdb, tmdb = i['imdb'], i['tvdb'], i['tmdb']

                year = i['year']
##                try: year = year.encode('utf-8')
##                except: pass

                try: poster = client.parseDOM(item2, 'poster')[0]
                except: poster = ''
                if not poster == '': poster = self.tvdb_image.format(poster)
                else: poster = '0'
                poster = client.replaceHTMLCodes(poster)
                if C.PY2: poster = poster.encode('utf-8')

                try: banner = client.parseDOM(item2, 'banner')[0]
                except: banner = ''
                if not banner == '': banner = self.tvdb_image.format(banner)
                else: banner = '0'
                banner = client.replaceHTMLCodes(banner)
                if C.PY2: banner = banner.encode('utf-8')

                try: fanart = client.parseDOM(item2, 'fanart')[0]
                except: fanart = ''
                if not fanart == '': fanart = self.tvdb_image.format(fanart)
                else: fanart = '0'
                fanart = client.replaceHTMLCodes(fanart)
                if C.PY2: fanart = fanart.encode('utf-8')

                try: thumb = client.parseDOM(item, 'filename')[0]
                except: thumb = ''
                if not thumb == '': thumb = self.tvdb_image.format(thumb)
                else: thumb = '0'
                thumb = client.replaceHTMLCodes(thumb)
                if C.PY2: thumb = thumb.encode('utf-8')

                if not poster == '0': pass
                elif not fanart == '0': poster = fanart
                elif not banner == '0': poster = banner

                if not banner == '0': pass
                elif not fanart == '0': banner = fanart
                elif not poster == '0': banner = poster

                if not thumb == '0': pass
                elif not fanart == '0': thumb = fanart.replace(self.tvdb_image, self.tvdb_poster)
                elif not poster == '0': thumb = poster

                try: studio = client.parseDOM(item2, 'Network')[0]
                except: studio = ''
                if studio == '': studio = '0'
                studio = client.replaceHTMLCodes(studio)
                if C.PY2: studio = studio.encode('utf-8')

                try: genre = client.parseDOM(item2, 'Genre')[0]
                except: genre = ''
                genre = [x for x in genre.split('|') if not x == '']
                genre = ' / '.join(genre)
                if genre == '': genre = '0'
                genre = client.replaceHTMLCodes(genre)
                if C.PY2: genre = genre.encode('utf-8')

                try: duration = client.parseDOM(item2, 'Runtime')[0]
                except: duration = ''
                if duration == '': duration = '0'
                duration = client.replaceHTMLCodes(duration)
                if C.PY2: duration = duration.encode('utf-8')

                try: rating = client.parseDOM(item, 'Rating')[0]
                except: rating = ''
                if rating == '': rating = '0'
                rating = client.replaceHTMLCodes(rating)
                if C.PY2: rating = rating.encode('utf-8')

                try: votes = client.parseDOM(item2, 'RatingCount')[0]
                except: votes = '0'
                if votes == '': votes = '0'
                votes = client.replaceHTMLCodes(votes)
                if C.PY2: votes = votes.encode('utf-8')

                try: mpaa = client.parseDOM(item2, 'ContentRating')[0]
                except: mpaa = ''
                if mpaa == '': mpaa = '0'
                mpaa = client.replaceHTMLCodes(mpaa)
                if C.PY2: mpaa = mpaa.encode('utf-8')

                try: director = client.parseDOM(item, 'Director')[0]
                except: director = ''
                director = [x for x in director.split('|') if not x == '']
                director = ' / '.join(director)
                if director == '': director = '0'
                director = client.replaceHTMLCodes(director)
                if C.PY2: director = director.encode('utf-8')

                try: writer = client.parseDOM(item, 'Writer')[0]
                except: writer = ''
                writer = [x for x in writer.split('|') if not x == '']
                writer = ' / '.join(writer)
                if writer == '': writer = '0'
                writer = client.replaceHTMLCodes(writer)
                if C.PY2: writer = writer.encode('utf-8')

                try: cast = client.parseDOM(item2, 'Actors')[0]
                except: cast = ''
                cast = [x for x in cast.split('|') if not x == '']
                try: cast = [(x.encode('utf-8'), '') for x in cast]
                except: cast = []

                try: plot = client.parseDOM(item, 'Overview')[0]
                except: plot = ''
                if plot == '':
                    try: plot = client.parseDOM(item2, 'Overview')[0]
                    except: plot = ''
                if plot == '': plot = '0'
                plot = client.replaceHTMLCodes(plot)
                if C.PY2: plot = plot.encode('utf-8')

                aa = ({   'title': title
                        , 'season': season
                        , 'episode': episode
                        , 'tvshowtitle': tvshowtitle
                        , 'year': year
                        , 'premiered': premiered
                        , 'status': status
                        , 'studio': studio
                        , 'genre': genre
                        , 'duration': duration
                        , 'rating': rating
                        , 'votes': votes
                        , 'mpaa': mpaa
                        , 'director': director
                        , 'writer': writer
                        , 'cast': cast
                        , 'plot': plot
                        , 'imdb': imdb
                        , 'tvdb': tvdb
                        , 'tmdb': tmdb
                        , 'poster': poster
                        #, 'banner': banner, 'fanart': fanart
                        , 'thumb': thumb
                        , 'snum': i['snum']
                        , 'enum': i['enum']
                        , 'action': 'episodes'
                        #, 'unaired': unaired
                        , '_last_watched': i['_last_watched']
                        , '_sort_key': max(i['_last_watched'],premiered)
                        })
                LogR(aa)
                self.list.append(aa)
                
            except StopIteration:
                pass
            except:
                traceback.print_exc()
                pass


        items = items[:100]

        threads = []
        for i in items: threads.append(workers.Thread(items_list, i))
        [i.start() for i in threads]
        [i.join() for i in threads]


        try:
            if sortorder == '0':
                self.list = sorted(self.list, key=lambda k: k['premiered'], reverse=True)
            else:
                self.list = sorted(self.list, key=lambda k: k['_sort_key'], reverse=True)
        except: pass

        return self.list


    def trakt_episodes_list(self, url, user, lang):
        Log(control.myName())
        
        items = self.trakt_list(url, user)

        def items_list(i):
            try:
                item = [x for x in self.blist if x['tvdb'] == i['tvdb'] and x['season'] == i['season'] and x['episode'] == i['episode']][0]
                if item['poster'] == '0': raise Exception()
                self.list.append(item)
                return
            except:
                pass

            try:
                url = self.tvdb_info_link % (i['tvdb'], lang)
                data = client.request(url,timeout=10)

                zip = zipfile.ZipFile(StringIO.StringIO(data))
                result = zip.read('%s.xml' % lang)
                artwork = zip.read('banners.xml')
                zip.close()

                result = result.split('<Episode>')
                item = [(re.findall('<SeasonNumber>%01d</SeasonNumber>' % int(i['season']), x), re.findall('<EpisodeNumber>%01d</EpisodeNumber>' % int(i['episode']), x), x) for x in result]
                item = [x[2] for x in item if len(x[0]) > 0 and len(x[1]) > 0][0]
                item2 = result[0]

                premiered = client.parseDOM(item, 'FirstAired')[0]
                if premiered == '' or '-00' in premiered: premiered = '0'
                premiered = client.replaceHTMLCodes(premiered)
                premiered = premiered.encode('utf-8')

                try: status = client.parseDOM(item2, 'Status')[0]
                except: status = ''
                if status == '': status = 'Ended'
                status = client.replaceHTMLCodes(status)
                status = status.encode('utf-8')

                title = client.parseDOM(item, 'EpisodeName')[0]
                if title == '': title = '0'
                title = client.replaceHTMLCodes(title)
                title = title.encode('utf-8')

                season = client.parseDOM(item, 'SeasonNumber')[0]
                season = '%01d' % int(season)
                season = season.encode('utf-8')

                episode = client.parseDOM(item, 'EpisodeNumber')[0]
                episode = re.sub('[^0-9]', '', '%01d' % int(episode))
                episode = episode.encode('utf-8')

                tvshowtitle = i['tvshowtitle']
                imdb, tvdb, tmdb = i['imdb'], i['tvdb'], i['tmdb']

                year = i['year']
                try: year = year.encode('utf-8')
                except: pass

                try: poster = client.parseDOM(item2, 'poster')[0]
                except: poster = ''
                if not poster == '': poster = self.tvdb_image.format(poster)
                else: poster = '0'
                poster = client.replaceHTMLCodes(poster)
                poster = poster.encode('utf-8')

                try: banner = client.parseDOM(item2, 'banner')[0]
                except: banner = ''
                if not banner == '': banner = self.tvdb_image.format(banner)
                else: banner = '0'
                banner = client.replaceHTMLCodes(banner)
                banner = banner.encode('utf-8')

                try: fanart = client.parseDOM(item2, 'fanart')[0]
                except: fanart = ''
                if not fanart == '': fanart = self.tvdb_image.format(fanart)
                else: fanart = '0'
                fanart = client.replaceHTMLCodes(fanart)
                fanart = fanart.encode('utf-8')

                try: thumb = client.parseDOM(item, 'filename')[0]
                except: thumb = ''
                if not thumb == '': thumb = self.tvdb_image.format(thumb)
                else: thumb = '0'
                thumb = client.replaceHTMLCodes(thumb)
                thumb = thumb.encode('utf-8')

                if not poster == '0': pass
                elif not fanart == '0': poster = fanart
                elif not banner == '0': poster = banner

                if not banner == '0': pass
                elif not fanart == '0': banner = fanart
                elif not poster == '0': banner = poster

                if not thumb == '0': pass
                elif not fanart == '0': thumb = fanart.replace(self.tvdb_image, self.tvdb_poster)
                elif not poster == '0': thumb = poster

                try: studio = client.parseDOM(item2, 'Network')[0]
                except: studio = ''
                if studio == '': studio = '0'
                studio = client.replaceHTMLCodes(studio)
                studio = studio.encode('utf-8')

                try: genre = client.parseDOM(item2, 'Genre')[0]
                except: genre = ''
                genre = [x for x in genre.split('|') if not x == '']
                genre = ' / '.join(genre)
                if genre == '': genre = '0'
                genre = client.replaceHTMLCodes(genre)
                genre = genre.encode('utf-8')

                try: duration = client.parseDOM(item2, 'Runtime')[0]
                except: duration = ''
                if duration == '': duration = '0'
                duration = client.replaceHTMLCodes(duration)
                duration = duration.encode('utf-8')

                try: rating = client.parseDOM(item, 'Rating')[0]
                except: rating = ''
                if rating == '': rating = '0'
                rating = client.replaceHTMLCodes(rating)
                rating = rating.encode('utf-8')

                try: votes = client.parseDOM(item2, 'RatingCount')[0]
                except: votes = '0'
                if votes == '': votes = '0'
                votes = client.replaceHTMLCodes(votes)
                votes = votes.encode('utf-8')

                try: mpaa = client.parseDOM(item2, 'ContentRating')[0]
                except: mpaa = ''
                if mpaa == '': mpaa = '0'
                mpaa = client.replaceHTMLCodes(mpaa)
                mpaa = mpaa.encode('utf-8')

                try: director = client.parseDOM(item, 'Director')[0]
                except: director = ''
                director = [x for x in director.split('|') if not x == '']
                director = ' / '.join(director)
                if director == '': director = '0'
                director = client.replaceHTMLCodes(director)
                director = director.encode('utf-8')

                try: writer = client.parseDOM(item, 'Writer')[0]
                except: writer = ''
                writer = [x for x in writer.split('|') if not x == '']
                writer = ' / '.join(writer)
                if writer == '': writer = '0'
                writer = client.replaceHTMLCodes(writer)
                writer = writer.encode('utf-8')

                try: cast = client.parseDOM(item2, 'Actors')[0]
                except: cast = ''
                cast = [x for x in cast.split('|') if not x == '']
                try: cast = [(x.encode('utf-8'), '') for x in cast]
                except: cast = []

                try: plot = client.parseDOM(item, 'Overview')[0]
                except: plot = ''
                if plot == '':
                    try: plot = client.parseDOM(item2, 'Overview')[0]
                    except: plot = ''
                if plot == '': plot = '0'
                plot = client.replaceHTMLCodes(plot)
                plot = plot.encode('utf-8')

                aa =  (
                    {
                    'title': title
                    , 'season': season, 'episode': episode
                    , 'tvshowtitle': tvshowtitle
                    , 'year': year
                    , 'premiered': premiered
                    , 'status': status
                    , 'studio': studio
                    , 'genre': genre
                    , 'duration': duration
                    , 'rating': rating
                    , 'votes': votes
                    , 'mpaa': mpaa
                    , 'director': director
                    , 'writer': writer
                    , 'cast': cast
                    , 'plot': plot
                    , 'imdb': imdb
                    , 'tmdb': tmdb
                    #, 'tvdb': tvdb
                    , 'poster': poster
                    #, 'banner': banner, 'fanart': fanart
                    , 'thumb': thumb
                    }
                       )
                LogR(aa)
                self.list.append(aa)
            except:
                traceback.print_exc()
                pass


        items = items[:100]

        threads = []
        for i in items: threads.append(workers.Thread(items_list, i))
        [i.start() for i in threads]
        [i.join() for i in threads]

        return self.list


    def trakt_user_list(self, url, user):
        try:
            items = trakt.getTraktAsJson(url)
        except:
            pass

        for item in items:
            try:
                try: name = item['list']['name']
                except: name = item['name']
                name = client.replaceHTMLCodes(name)

                try: url = (trakt.slug(item['list']['user']['username']), item['list']['ids']['slug'])
                except: url = ('me', item['ids']['slug'])
                url = self.traktlist_link % url
                url = url.encode('utf-8')

                self.list.append({'name': name, 'url': url, 'context': url})
            except:
                pass

                self.list = sorted(self.list, key=lambda k: utils.title_key(k['name']))
        return self.list


    def tvmaze_list(self, url, limit):
        Log(__name__); LogR(locals())
        try:
            result = client.request(url)
            itemlist = []
            items = json.loads(result)
        except:
            raise
            return

        for item in items:
            try:

                if item['show'] and item['show']['language']:
                    if not 'english' in item['show']['language'].lower():
                        continue

                if limit == True and not 'scripted' in item['show']['type'].lower():
                    raise Exception()

                title = item['name']
                if title == None or title == '': raise Exception()
                title = client.replaceHTMLCodes(title)
                if C.PY2: title = title.encode('utf-8')

                season = item['season']
                season = re.sub('[^0-9]', '', '%01d' % int(season))
                if season == '0': raise Exception()
                if C.PY2: season = season.encode('utf-8')

                episode = item['number']
                episode = re.sub('[^0-9]', '', '%01d' % int(episode))
                if episode == '0': raise Exception()
                if C.PY2: episode = episode.encode('utf-8')

                tvshowtitle = item['show']['name']
                if tvshowtitle == None or tvshowtitle == '': raise Exception()
                tvshowtitle = client.replaceHTMLCodes(tvshowtitle)
                if C.PY2: tvshowtitle = tvshowtitle.encode('utf-8')

                year = item['show']['premiered']
                year = re.findall(r'(\d{4})', year)[0]
                if C.PY2: year = year.encode('utf-8')

                imdb = item['show']['externals']['imdb']
                if imdb == None or imdb == '': imdb = '0'
                else: imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))
                if C.PY2: imdb = imdb.encode('utf-8')

                tvdb = item['show']['externals']['thetvdb']
                if tvdb == None or tvdb == '':
                    continue
##                    LogR(item)
##                    raise Exception()
                tvdb = re.sub('[^0-9]', '', str(tvdb))
                if C.PY2: tvdb = tvdb.encode('utf-8')

                try: 
                    tmdb = item['show']['externals']['thetmdb']
                    if C.PY2: tmdb = str(tmdb).encode('utf-8')
                except:
##                    try: 
##                        tmdb = item['show']['externals']['tvrage']
##                        tmdb = str(tmdb).encode('utf-8')
##                    except:
##                        tmdb = '0'
                    tmdb = 'None'

                poster = '0'
                try: poster = item['show']['image']['original']
                except: poster = '0'
                if poster == None or poster == '': poster = '0'
                if C.PY2: poster = poster.encode('utf-8')

                try: thumb1 = item['show']['image']['original']
                except: thumb1 = '0'
                try: thumb2 = item['image']['original']
                except: thumb2 = '0'
                if thumb2 == None or thumb2 == '0': thumb = thumb1
                else: thumb = thumb2
                if thumb == None or thumb == '': thumb = '0'
                if C.PY2: thumb = thumb.encode('utf-8')

                premiered = item['airdate']
                try: premiered = re.findall(r'(\d{4}-\d{2}-\d{2})', premiered)[0]
                except: premiered = '0'
                if C.PY2: premiered = premiered.encode('utf-8')

                try: studio = item['show']['network']['name']
                except: studio = '0'
                if studio == None: studio = '0'
                if C.PY2: studio = studio.encode('utf-8')

                try: genre = item['show']['genres']
                except: genre = '0'
                genre = [i.title() for i in genre]
                if genre == []: genre = '0'
                genre = ' / '.join(genre)
                if C.PY2: genre = genre.encode('utf-8')

                try: duration = item['show']['runtime']
                except: duration = '0'
                if duration == None: duration = '0'
                duration = str(duration)
                if C.PY2: duration = duration.encode('utf-8')

                try: rating = item['show']['rating']['average']
                except: rating = '0'
                if rating == None or rating == '0.0': rating = '0'
                rating = str(rating)
                if C.PY2: rating = rating.encode('utf-8')

                try: plot = item['show']['summary']
                except: plot = '0'
                if plot == None: plot = '0'
                plot = re.sub('<.+?>|</.+?>|\n', '', plot)
                plot = client.replaceHTMLCodes(plot)
                if C.PY2: plot = plot.encode('utf-8')

                itemlist.append({'title': title
                                 , 'season': season
                                 , 'episode': episode
                                 , 'tvshowtitle': tvshowtitle
                                 , 'year': year
                                 , 'premiered': premiered
                                 , 'status': 'Continuing'
                                 , 'studio': studio
                                 , 'genre': genre
                                 , 'duration': duration
                                 , 'rating': rating
                                 , 'plot': plot
                                 , 'imdb': imdb
                                 , 'tvdb': tvdb
                                 , 'tmdb': tmdb
                                 , 'poster': poster
                                 , 'thumb': thumb
                                 })
            except:
##                traceback.print_exc()
##                raise
                #don't investigate too much if data is broken for an item
                pass

        itemlist = itemlist[::-1]

        return itemlist


    def episodeDirectory(self, items):
        Log(control.myName(__name__))
##        LogR(locals())

        if items == None or len(items) == 0: control.idle() ; sys.exit()

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        addonPoster, addonBanner = control.addonPoster(), control.addonBanner()

        addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')

        traktCredentials = trakt.getTraktCredentialsInfo()

        try: isOld = False ; control.item().getArt('type')
        except: isOld = True

        if not 'plugin' in control.infoLabel('Container.PluginName'):
            isPlayable = 'true'
        else:
            isPlayable = 'false'

        try:        
            indicators = playcount.getTVShowIndicators(refresh=True)
        except:
            traceback.print_exc()
            pass

        try: multi = [i['tvshowtitle'] for i in items]
        except: multi = []

        multi_show = len([x for y,x in enumerate(multi) if x not in multi[:y]])
        if multi_show > 1: #there are many different tvshows in this view
            multi_show = True  
        else:
            multi_show = False

        try: sysaction = items[0]['action']
        except: sysaction = ''

        if not sysaction == 'episodes':
            isFolder = False
        else:
            isFolder = True

        playbackMenu= control.lang(32063).encode('utf-8') if control.setting('hosts.mode') == '2' else control.lang(32064).encode('utf-8')

        watchedMenu = control.lang(32068).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32066).encode('utf-8')

        unwatchedMenu = control.lang(32069).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32067).encode('utf-8')

        queueMenu = control.lang(32065).encode('utf-8')

        traktManagerMenu = control.lang(32070).encode('utf-8')

        tvshowBrowserMenu = control.lang(32071).encode('utf-8')

        addToLibrary = control.lang(32551).encode('utf-8')

        for i in items:
            
            title = i['title']
            tvshowtitle = i['tvshowtitle']
            season = int(i['season'])
            episode = int(i['episode'])

##            LogR((title,tvshowtitle,season,episode))
            try:
                if not 'label' in i:
                    i['label'] = title
                label = i['label']
##                LogR(label)
##
                if label == '0':
                    label   = '%sx%02d . %s %s' % (i['season'], int(i['episode']), 'Episode', i['episode'])
##                else: #include season/episode number
##                    pass

                if multi_show == True:  #there are multiple tvshows in this view; include tvshow title
                     label = '%s - %s' % (tvshowtitle, label)

                #if there are multiple episodes for the same tvshow; append episode/season
                multi_episode = False
                episode_count = 0
                temp_dict = []
                for x in multi:
                    if x == tvshowtitle:
                        episode_count += 1
                        if episode_count > 1:
##                            Log("multi_episodes of same series = True")
                            multi_episode = True  #there are multiple tvshows in this view
                            #break


                #show episodenumber when not in season view for a single tvshow
                #   user can choose sort-by-episode in skin
                if multi_episode and (episode_count<len(multi)):
                    label = '%s - %sx%02d' % (label, season, episode)

                try:
                    if i['unaired'] == 'true':
                        label = '[COLOR darkred][I]%s[/I][/COLOR]' % label
                except:
                    pass

##                Log(repr((label, title, tvshowtitle)))

                imdb, tvdb, year, tmdb = i['imdb'], i['tvdb'], i['year'], i['tmdb']
                
                systitle = quote_plus(i['title'])
                systvshowtitle = quote_plus(i['tvshowtitle'])
                syspremiered = quote_plus(i['premiered'])

                if C.PY2:
                    meta = dict((k,v) for k, v in i.iteritems() if not v == '0')
                else:
                    meta = dict((k,v) for k, v in i.items() if not v == '0')
                meta.update({'mediatype': 'episode'})
                meta.update({'trailer': '%s?action=trailer&name=%s' % (sysaddon, systvshowtitle)})
                if not 'duration' in i: meta.update({'duration': '60'})
                elif i['duration'] == '0': meta.update({'duration': '60'})
                try: meta.update({'duration': str(int(meta['duration']) * 60)})
                except: pass
                try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
                except: pass

                try: p_d = datetime.datetime.strptime(syspremiered, '%Y-%m-%d')
                except TypeError:
                    try:
                        p_d = datetime.datetime(*(time.strptime(syspremiered, '%Y-%m-%d')[0:6]))
                    except:
                        pass
                    

                try: meta.update({'year': p_d.year})
                except: pass
                try: meta.update({'title': label})
                except: pass

                #python bug/ strptime function can break; restart open to fix
                try:
                    if 'premiered' in i:
                        prem = p_d.date()
                except:
                    traceback.print_exc()
                    raise
                try: meta.update({'dateadded': p_d.strftime('%Y-%m-%d 00:00:00')})
                except: pass
                try: meta.update({'date': p_d.strftime('%d.%m.%Y')})
                except: pass


                sysmeta = quote_plus(json.dumps(meta))


                url = '%s?action=play&title=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&t=%s' % (sysaddon, systitle, year, imdb, tvdb, season, episode, systvshowtitle, syspremiered, sysmeta, self.systime)
                #remove t= from url so that 'mark as watched' will work(?)
                url = '%s?action=play&title=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s' % (sysaddon, systitle, year, imdb, tvdb, season, episode, systvshowtitle, syspremiered, sysmeta)
                sysurl = quote_plus(url)

                path = '%s?action=play&title=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s' % (sysaddon, systitle, year, imdb, tvdb, season, episode, systvshowtitle, syspremiered)

                if isFolder == True:
                    url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s' % (sysaddon, systvshowtitle, year, imdb, tvdb, season, episode)


                cm = []

                cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                if multi_show == True:
                    cm.append((tvshowBrowserMenu, 'Container.Update(%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s,return)' % (sysaddon, systvshowtitle, year, imdb, tvdb)))

                try:
                    overlay = int(playcount.getEpisodeOverlay(indicators, imdb, tvdb, season, episode))
##                    LogR(overlay)
                    if overlay == METAHANDLER_WATCHED:
##                        cm.append((unwatchedMenu, 'RunPlugin(%s?action=episodePlaycount&imdb=%s&tvdb=%s&season=%s&episode=%s&query=%s)' % (sysaddon, imdb, tvdb, season, episode, METAHANDLER_UNWATCHED)))
                        meta.update({
                            'playcount': 1
                            , 'overlay': METAHANDLER_WATCHED
                            })
                    else:
##                        cm.append(  (watchedMenu, 'RunPlugin(%s?action=episodePlaycount&imdb=%s&tvdb=%s&season=%s&episode=%s&query=%s)' % (sysaddon, imdb, tvdb, season, episode, METAHANDLER_WATCHED)))
                        meta.update({
                            'playcount': 0
                            , 'overlay': METAHANDLER_UNWATCHED
                            })
                except:
                    raise
                    pass

                if traktCredentials == True:
                    cm.append((traktManagerMenu, 'RunPlugin(%s?action=traktManager&name=%s&tvdb=%s&content=tvshow)' % (sysaddon, systvshowtitle, tvdb)))

                if isFolder == False:
                    cm.append((playbackMenu, 'RunPlugin(%s?action=alterSources&url=%s&meta=%s)' % (sysaddon, sysurl, sysmeta)))

                if isOld == True:
                    cm.append((control.lang2(19033).encode('utf-8'), 'Action(Info)'))

                cm.append((addToLibrary, 'RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s)' % (sysaddon, systvshowtitle, year, imdb, tvdb)))

                cm.append(('Exodus Redux Settings', 'RunPlugin(%s?action=openSettings&query=(0,0))' % sysaddon))
                
                
                art = {}
                if 'poster' in i and not i['poster'] == '0':
                    art.update({'poster': i['poster'], 'tvshow.poster': i['poster'], 'season.poster': i['poster']})
                else:
                    art.update({'poster': addonPoster})
                if 'thumb' in i and not i['thumb'] == '0':
                    art.update({'icon': i['thumb'], 'thumb': i['thumb']})
                elif 'fanart' in i and not i['fanart'] == '0':
                    art.update({'icon': i['fanart'], 'thumb': i['fanart']})
                elif 'poster' in i and not i['poster'] == '0':
                    art.update({'icon': i['poster'], 'thumb': i['poster']})
                else:
                    art.update({'icon': addonFanart, 'thumb': addonFanart})
                if 'banner' in i and not i['banner'] == '0':
                    art.update({'banner': i['banner']})
                elif 'fanart' in i and not i['fanart'] == '0':
                    art.update({'banner': i['fanart']})
                else:
                    art.update({'banner': addonBanner})

                item = control.item(label=label)
                item.setArt(art)
##                LogR(art)
                item.addContextMenuItems(cm)

                item.setProperty('IsPlayable', isPlayable)

                item.setContentLookup(False) #prevent HEAD requests

##                max_loops = 1000
##                loop_count = 0
##                was_changed = True
##                while (was_changed == True)  and  (loop_count < max_loops) :
##                    loop_count = loop_count + 1
##                    was_changed = False
##                    for a in meta:
##                        if a == 'imdb':
##                            was_changed = True
##                            meta['imdbnumber'] = meta[a]
##                            meta.pop(a)
##                            break
##                        if a in C.bad_attributes:
##                            was_changed = True
##                            meta.pop(a)
##                            break
##
##                if 'tmdb' in meta:
##                    meta.pop('tmdb')
                    
##                item.setInfo(type='Video', infoLabels = meta)

                if C.PY2:
                    item.setInfo(type='Video', infoLabels = meta)
                    video_streaminfo = {'codec': 'h264'}
                    item.addStreamInfo('video', video_streaminfo)
                else:
                    videoInfoTag = item.getVideoInfoTag()
                    for a in meta:
##                        Log(repr((a,meta[a])))
                        if a == "tvshowtitle": videoInfoTag.setTvShowTitle(meta[a]) #needed by embuary
                        if a == "title": videoInfoTag.setTitle(meta[a])
                        if a == "mediatype": videoInfoTag.setMediaType(meta[a])
                        if a == "originaltitle": videoInfoTag.setOriginalTitle(meta[a])
                        if a == "first_air_date_year": videoInfoTag.setYear(int(meta[a])) #needed by embuary
                        if a == "premiered": videoInfoTag.setPremiered(meta[a])
                        if a == "duration": videoInfoTag.setDuration(int(meta[a]))
                        if a == "mpaa": videoInfoTag.setMpaa(meta[a])
                        if a == "plot": videoInfoTag.setPlot(meta[a])
                        if a == "tagline": videoInfoTag.setTagLine(meta[a])
                        if a == "code": videoInfoTag.setProductionCode(meta[a])
                        if a == "imdbnumber": videoInfoTag.setIMDBNumber(meta[a])
                        if a == "playcount": videoInfoTag.setPlaycount(meta[a])
                        if a == "cast":
                            actors = []
                            for actor_info in meta[a]:
                                name = client.parseDOM(actor_info, 'name')[0]
                                t = client.parseDOM(actor_info, 'image')[0]
                                if t: thumbnail = self.tvdb_image.format(t)
                                else: thumbnail = ""
                                role = client.parseDOM(actor_info, 'role')[0]
                                order = int(client.parseDOM(actor_info, 'sortorder')[0])
                                actors.append(xbmc.Actor(name=name,thumbnail=thumbnail,role=role,order=order))
                            videoInfoTag.setCast(actors)
                    videoInfoTag.setEpisode(episode)
                    videoInfoTag.setSeason(season)
                    videoInfoTag.setDateAdded(syspremiered)
##                    videoInfoTag.setFirstAired(syspremiered) #must not be set or else first_air_date_year is nulled
                    vsd = xbmc.VideoStreamDetail()
                    vsd.setCodec('h264')
                    videoInfoTag.addVideoStream(vsd)
                        
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)

##                LogR(item)
##class 'list'>, ['__class__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__',
                ##'__init__', '__init_subclass__', '__le__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__',
                #'__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'addAvailableArtwork', 'addContextMenuItems', 'addSeason',
                #'addStreamInfo', 'getArt',
                #'getDateTime', 'getGameInfoTag', 'getLabel', 'getLabel2', 'getMusicInfoTag', 'getPath',
                #'getPictureInfoTag', 'getProperty', 'getRating', 'getUniqueID', 'getVideoInfoTag', 'getVotes',
                #'isFolder', 'isSelected', 'select', 'setArt', 'setAvailableFanart', 'setCast', 'setContentLookup',
                #'setDateTime', 'setInfo', 'setIsFolder', 'setLabel', 'setLabel2', 'setMimeType',
                #'setPath', 'setProperties', 'setProperty', 'setRating', 'setSubtitles', 'setUniqueIDs'])
##                LogR(item.getLabel2())
##                LogR(item.getRating())
##                LogR(item.getVideoInfoTag())
##                LogR(dir(item.getVideoInfoTag()))
##                LogR(item.getVideoInfoTag().getEpisode())
##                LogR(item.getVideoInfoTag().getSeason())
##                LogR(item.getVideoInfoTag().getFirstAiredAsW3C())
##                LogR(item.getVideoInfoTag().getDuration())
##episodes.py:2014 (<class 'list'>, ['__class__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__'
##                , '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__init_subclass__'
##                , '__le__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__'
##                , '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'addAudioStream', 'addAvailableArtwork'
##                , 'addSeason', 'addSeasons', 'addSubtitleStream', 'addVideoStream', 'getActors', 'getAlbum'
##                , 'getArtist'
##                , 'getCast', 'getDbId', 'getDirector', 'getDirectors', 'getDuration', 'getEpisode'
##                , 'getFile', 'getFilenameAndPath', 'getFirstAired', 'getFirstAiredAsW3C', 'getGenre'
##                , 'getGenres', 'getIMDBNumber', 'getLastPlayed', 'getLastPlayedAsW3C', 'getMediaType'
##                , 'getOriginalTitle', 'getPath', 'getPictureURL', 'getPlayCount', 'getPlot', 'getPlotOutline'
##                , 'getPremiered', 'getPremieredAsW3C', 'getRating', 'getResumeTime', 'getResumeTimeTotal'
##                , 'getSeason', 'getTVShowTitle', 'getTagLine', 'getTitle', 'getTrack', 'getTrailer'
##                , 'getUniqueID', 'getUserRating', 'getVotes', 'getVotesAsInt', 'getWriters'
##                , 'getWritingCredits', 'getYear', 'setAlbum', 'setArtists', 'setCast', 'setCountries'
##                , 'setDateAdded', 'setDbId', 'setDirectors', 'setDuration', 'setEpisode'
                ##                , , 'setEpisodeGuide'
                #, 'setFilenameAndPath', 'setFirstAired', 'setGenres', 'setIMDBNumber', 'setLastPlayed'
                #, 'setMediaType', 'setMpaa', 'setOriginalTitle', 'setPath', 'setPlaycount', 'setPlot'
                #, 'setPlotOutline', 'setPremiered', 'setProductionCode', 'setRating', 'setRatings'
                #, 'setResumePoint', 'setSeason', 'setSet', 'setSetId', 'setSetOverview'
##                , 'setShowLinks', 'setSortEpisode', 'setSortSeason', 'setSortTitle', 'setStudios', 'setTagLine', 'setTags'
                ##, 'setTitle', 'setTop250', 'setTrackNumber', 'setTrailer', 'setTvShowStatus', 'setTvShowTitle', 'setUniqueID'
                ##, 'setUniqueIDs', 'setUserRating', 'setVideoAssetTitle', 'setVotes', 'setWriters', 'setYear'])

            except:
                traceback.print_exc()
                raise
                pass

        control.content(syshandle, 'episodes')
        control.directory(syshandle, cacheToDisc=True,episode_first=True)


    def addDirectory(self, items, queue=False):
        if items == None or len(items) == 0: control.idle() ; sys.exit()

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        addonFanart, addonThumb, artPath = control.addonFanart(), control.addonThumb(), control.artPath()

        queueMenu = control.lang(32065).encode('utf-8')

        for i in items:
            try:
                name = i['name']

                if i['image'].startswith('http'): thumb = i['image']
                elif not artPath == None: thumb = os.path.join(artPath, i['image'])
                else: thumb = addonThumb

                url = '%s?action=%s' % (sysaddon, i['action'])
                try: url += '&url=%s' % quote_plus(i['url'])
                except: pass

                cm = []

                if queue == True:
                    cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                item = control.item(label=name)
                item.setContentLookup(False) #prevent HEAD requests

                item.setArt({'icon': thumb, 'thumb': thumb})
                if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)

                item.addContextMenuItems(cm)

                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
            except:
                pass

        control.content(syshandle, 'addons')

        control.directory(syshandle, cacheToDisc=True)


