# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.modules import trakt
from resources.lib.modules import cleangenre
from resources.lib.modules import cleantitle
from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import metacache
from resources.lib.modules import playcount
from resources.lib.modules import workers
from resources.lib.modules import views
from resources.lib.modules import utils
from resources.lib.indexers import navigator

from resources.lib.modules.log_utils import Log,LogR
from resources.lib.utils import Header2pipestring
from resources.lib import constants as C


import os,sys,re,json,urllib,datetime,xbmc,traceback,random

from resources.lib.constants import urlparse
from resources.lib.constants import urlencode
from resources.lib.constants import quote_plus

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()

action = params.get('action')

class movies:
    def __init__(self):
        self.list = []

        self.imdb_link = 'https://www.imdb.com'
        self.trakt_link = 'https://api.trakt.tv'
        self.datetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
        self.systime = (self.datetime).strftime('%Y%m%d%H%M%S%f')
        self.year_date = (self.datetime - datetime.timedelta(days = 365)).strftime('%Y-%m-%d')
        self.today_date = (self.datetime).strftime('%Y-%m-%d')
        self.trakt_user = control.setting('trakt.user').strip()
        self.imdb_user = control.setting('imdb.user').replace('ur', '')
        self.tm_user = control.setting('tm.user')
        self.fanart_tv_user = control.setting('fanart.tv.user')
        self.user = str(control.setting('fanart.tv.user')) + str(control.setting('tm.user'))
        self.lang = control.apiLanguage()['trakt']
        self.hidecinema = control.setting('hidecinema')

        self.search_link = 'https://api.trakt.tv/search/movie/?limit=12&page=1&query='
        self.fanart_tv_art_link = ''#'https://webservice.fanart.tv/v3/movies/%s'
        self.fanart_tv_level_link = ''#'https://webservice.fanart.tv/v3/level'
        self.tm_art_link = ''#'https://api.themoviedb.org/3/movie/%s/images?api_key=%s&language=en-US&include_image_language=en,%s,null' % ('%s', self.tm_user, self.lang)
        self.tm_img_link = 'https://image.tmdb.org/t/p/w%s%s'

        self.persons_link = 'https://www.imdb.com/search/name/?count=100&name='
        self.personlist_link = 'https://www.imdb.com/search/name/?count=100&gender=male,female'
        self.person_link = 'https://www.imdb.com/search/title/?title_type=feature,tv_movie&production_status=released&role=%s&sort=year,desc&count=40&start=1'
        self.keyword_link = 'https://www.imdb.com/search/title/?title_type=feature,tv_movie,documentary&num_votes=100,&release_date=,date[0]&keywords=%s&sort=moviemeter,asc&count=40&start=1'
        self.oscars_link = 'https://www.imdb.com/search/title/?title_type=feature,tv_movie&production_status=released&groups=oscar_best_picture_winners&sort=year,desc&count=40&start=1'

        self.theaters_link = ('https://www.imdb.com/search/title/?title_type=feature&num_votes=1000'
                              ',&countries=us&sort=release_date,desc'
                              '&count=25&start=1'
                              ) #start is ignored as of 2023-12


        '''tmdb
POST https://www.themoviedb.org/discover/movie HTTP/1.1
Host: www.themoviedb.org
Connection: keep-alive
Content-Length: 515
sec-ch-ua: "Microsoft Edge";v="119", "Chromium";v="119", "Not?A_Brand";v="24"
Accept: text/html, */*; q=0.01
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
X-Requested-With: XMLHttpRequest
sec-ch-ua-mobile: ?0
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0
sec-ch-ua-platform: "Windows"
Origin: https://www.themoviedb.org
Sec-Fetch-Site: same-origin
Sec-Fetch-Mode: cors
Sec-Fetch-Dest: empty
Referer: https://www.themoviedb.org/movie/now-playing
Accept-Encoding: gzip, deflate, br
Accept-Language: en-US,en;q=0.9

air_date.gte=&air_date.lte=&certification=&debug=&page=2

air_date.gte=&air_date.lte=&certification=&debug=&first_air_date.gte=&first_air_date.lte=&page=1&primary_release_date.gte=&primary_release_date.lte=&region=&release_date.gte=2022-10-25&release_date.lte=2023-12-06&show_me=0&sort_by=primary_release_date.desc&vote_average.gte=0&vote_average.lte=10&vote_count.gte=300&with_genres=&with_keywords=&with_networks=&with_origin_country=&with_original_language=&with_watch_monetization_types=&with_watch_providers=&with_release_type=3&with_runtime.gte=0&with_runtime.lte=400
        '''
        self.year_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&num_votes=100,&production_status=released&year=%s,%s&sort=moviemeter,asc&count=40&start=1'
        self.popular_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&num_votes=1000,&production_status=released&groups=top_1000&sort=moviemeter,asc&count=40&start=1'
        self.views_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&num_votes=1000,&production_status=released&sort=num_votes,desc&count=40&start=1'
        self.featured_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&num_votes=1000,&production_status=released&release_date=date[365],date[60]&sort=moviemeter,asc&count=40&start=1'
##        self.genre_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie,documentary&num_votes=1000,&release_date=,date[0]&genres=%s' #&sort=moviemeter,asc&count=40&start=1'
        self.genre_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&num_votes=1000,&release_date=,date[0]&genres=%s' #&sort=moviemeter,asc&count=40&start=1'
        self.language_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&num_votes=100,&production_status=released&primary_language=%s&sort=moviemeter,asc&count=40&start=1'
        self.certification_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&num_votes=100,&production_status=released&certificates=US:%s&sort=moviemeter,asc&count=40&start=1'
##                                    https://www.imdb.com/search/title/?title_type=feature,tv_movie&num_votes=100,&certificates=US:R
        self.boxoffice_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&production_status=released&sort=boxoffice_gross_us,desc&count=16&start=1'
        self.added_link = u'https://www.imdb.com/search/title/?title_type=feature,tv_movie&languages=en&num_votes=500,&production_status=released&release_date=%s,%s&sort=release_date,desc&count=20&start=1' % (self.year_date, self.today_date)

        force_latest_trakt = not(C.DEBUG)
        if force_latest_trakt:
            Log('force_latest_trakt={}'.format(force_latest_trakt))
            self.trending_link = 'https://api.trakt.tv/movies/trending?limit=12&page=1' + '&_='+str(random.randint(100000,9999999)) #cloudflare caches data too long without
        else:
            #force one just for today
            self.trending_link = 'https://api.trakt.tv/movies/trending?limit=12&page=1' + '&_=' + datetime.datetime.now().isoformat()[0:10]
        #note: trakt_list method will auto-increment update the page number
            

        self.traktlists_link = u'https://api.trakt.tv/users/me/lists'
        self.traktlikedlists_link = u'https://api.trakt.tv/users/likes/lists?limit=1000000'
        self.traktlist_link = u'https://api.trakt.tv/users/%s/lists/%s/items'
        self.traktcollection_link = u'https://api.trakt.tv/users/me/collection/movies'
        self.traktwatchlist_link = u'https://api.trakt.tv/users/me/watchlist/movies'
        self.traktfeatured_link = u'https://api.trakt.tv/recommendations/movies?limit=12'
        self.trakthistory_link = u'https://api.trakt.tv/users/me/history/movies?limit=12&page=1'

        self.imdblists_link = u'https://www.imdb.com/user/ur%s/lists?tab=all&sort=mdfd&order=desc&filter=titles' % self.imdb_user
        self.imdblist_link = u'https://www.imdb.com/list/%s/?view=detail&sort=alpha,asc&title_type=movie,short,tvMovie,tvSpecial,video&start=1'
        self.imdblist2_link = u'https://www.imdb.com/list/%s/?view=detail&sort=date_added,desc&title_type=movie,short,tvMovie,tvSpecial,video&start=1'
        self.imdbwatchlist_link = u'http://www.imdb.com/user/ur%s/watchlist?sort=alpha,asc' % self.imdb_user
        self.imdbwatchlist2_link = u'http://www.imdb.com/user/ur%s/watchlist?sort=date_added,desc' % self.imdb_user


    def get(self, url, idx=True, create_directory=True):
        try:
##            LogR(locals())
##            traceback.print_stack()

            try: url = getattr(self, url + '_link')
            except: pass

            try: u = urlparse.urlparse(url).netloc.lower()
            except: pass


            if u in self.trakt_link and '/users/' in url:
                try:
                    if url == self.trakthistory_link: raise Exception()
                    if not '/users/me/' in url: raise Exception()
                    if trakt.getActivity() > cache.timeout(self.trakt_list, url, self.trakt_user): raise Exception()
                    self.list = cache.get(self.trakt_list, 720, url, self.trakt_user)
                except:
                    self.list = cache.get(self.trakt_list, 0, url, self.trakt_user)

                if '/users/me/' in url and '/collection/' in url:
                    self.list = sorted(self.list, key=lambda k: utils.title_key(k['title']))

                if idx == True: self.worker()

            elif u in self.trakt_link and self.search_link in url:
                self.list = cache.get(self.trakt_list, 1, url, self.trakt_user)
                if idx == True:
                    self.worker(level=0)

            elif u in self.trakt_link:
                self.list = cache.get(self.trakt_list, 24, url, self.trakt_user)
                if idx == True:
                    self.worker()

            elif u in self.imdb_link and ('/user/' in url or '/list/' in url):
                self.list = cache.get(self.imdb_list, 0, url)
                if idx == True: self.worker()

            elif u in self.imdb_link:

                self.list = cache.get(self.imdb_list, 24, url)
               
                if idx == True:
                    self.worker()

##            return
            if idx == True and create_directory == True:
                self.movieDirectory(self.list)
                
            return self.list
        except:
            traceback.print_exc()
            pass

    def widget(self):
        setting = control.setting('movie.widget')

        if setting == '2':
            self.get(self.trending_link)
        elif setting == '3':
            self.get(self.popular_link)
        elif setting == '4':
            self.get(self.theaters_link)
        elif setting == '5':
            self.get(self.added_link)
        else:
            self.get(self.featured_link)

    def search(self):
        navigator.navigator().addDirectoryItem(32603, 'movieSearchnew', 'search.png', 'DefaultMovies.png')
        search_history = control.setting('moviesearch')
        if search_history:
            for term in search_history.split('\n'):
                if term:
                    navigator.navigator().addDirectoryItem(term, 'movieSearchterm&name=%s' % term, 'search.png', 'DefaultMovies.png')
            navigator.navigator().addDirectoryItem(32605, 'clearCacheSearch', 'tools.png', 'DefaultAddonProgram.png')
        navigator.navigator().endDirectory()


    def search_new(self):
        t = control.lang(32010).encode('utf-8')
        k = control.keyboard('', t) ; k.doModal()
        q = k.getText().strip() if k.isConfirmed() else None
        if not q: return

        search_history = control.setting('moviesearch')
        if q not in search_history.split('\n'):
            control.setSetting('moviesearch', q + '\n' + search_history)

        url = self.search_link + quote_plus(q)
        self.get(url)


    def search_term(self, name):
        url = self.search_link + quote_plus(name)
        self.get(url)


    def person(self):
        t = control.lang(32010).encode('utf-8')
        k = control.keyboard('', t) ; k.doModal()
        q = k.getText().strip() if k.isConfirmed() else None
        if not q: return
##        q = 'brosnan'
        url = self.persons_link + quote_plus(q)
        self.persons(url)

    def genres(self):
        genres = [
            ('Action', 'action', True),
            ('Adventure', 'adventure', True),
            ('Animation', 'animation', True),
            ('Anime', 'anime', False),
            ('Biography', 'biography', True),
            ('Comedy', 'comedy', True),
            ('Crime', 'crime', True),
            ('Documentary', 'documentary', True),
            ('Drama', 'drama', True),
            ('Family', 'family', True),
            ('Fantasy', 'fantasy', True),
            ('History', 'history', True),
            ('Horror', 'horror', True),
            ('Music ', 'music', True),
            ('Musical', 'musical', True),
            ('Mystery', 'mystery', True),
            ('Romance', 'romance', True),
            ('Science Fiction', 'sci_fi', True),
            ('Sport', 'sport', True),
            ('Thriller', 'thriller', True),
            ('War', 'war', True),
            ('Western', 'western', True)
        ]

        for i in genres: self.list.append(
            {
                'name': cleangenre.lang(i[0], self.lang),
                'url': self.genre_link % i[1] if i[2] else self.keyword_link % i[1],
                'image': 'genres.png',
                'action': 'movies'
            })

        self.addDirectory(self.list)
        return self.list

    def languages(self):
        languages = [
            ('Arabic', 'ar'),
            ('Bosnian', 'bs'),
            ('Bulgarian', 'bg'),
            ('Chinese', 'zh'),
            ('Croatian', 'hr'),
            ('Dutch', 'nl'),
            ('English', 'en'),
            ('Finnish', 'fi'),
            ('French', 'fr'),
            ('German', 'de'),
            ('Greek', 'el'),
            ('Hebrew', 'he'),
            ('Hindi ', 'hi'),
            ('Hungarian', 'hu'),
            ('Icelandic', 'is'),
            ('Italian', 'it'),
            ('Japanese', 'ja'),
            ('Korean', 'ko'),
            ('Macedonian', 'mk'),
            ('Norwegian', 'no'),
            ('Persian', 'fa'),
            ('Polish', 'pl'),
            ('Portuguese', 'pt'),
            ('Punjabi', 'pa'),
            ('Romanian', 'ro'),
            ('Russian', 'ru'),
            ('Serbian', 'sr'),
            ('Slovenian', 'sl'),
            ('Spanish', 'es'),
            ('Swedish', 'sv'),
            ('Turkish', 'tr'),
            ('Ukrainian', 'uk')
        ]

        for i in languages: self.list.append({'name': str(i[0]), 'url': self.language_link % i[1], 'image': 'languages.png', 'action': 'movies'})
        self.addDirectory(self.list)
        return self.list

    def certifications(self):
        certificates = ['G', 'PG', 'PG-13', 'R', 'NC-17']

        for i in certificates:
            self.list.append(
                    {  'name': str(i)
                     , 'url': self.certification_link % str(i)#.replace('-', '_').lower()
                     , 'image': 'certificates.png'
                     , 'action': 'movies'
                     }
                )
        self.addDirectory(self.list)
        return self.list

    def years(self):
        year = (self.datetime.strftime('%Y'))

        for i in range(int(year)-0, 1900, -1): self.list.append({'name': str(i), 'url': self.year_link % (str(i), str(i)), 'image': 'years.png', 'action': 'movies'})
        self.addDirectory(self.list)
        return self.list

    def persons(self, url):
        if url == None:
            self.list = cache.get(self.imdb_person_list, 24, self.personlist_link)
        else:
            self.list = cache.get(self.imdb_person_list, 1, url)

        for i in range(0, len(self.list)): self.list[i].update({'action': 'movies'})
        self.addDirectory(self.list)
        return self.list

    def userlists(self):
        try:
            userlists = []
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            activity = trakt.getActivity()
        except:
            pass

        try:
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlists_link, self.trakt_user): raise Exception()
                userlists += cache.get(self.trakt_user_list, 720, self.traktlists_link, self.trakt_user)
            except:
                userlists += cache.get(self.trakt_user_list, 0, self.traktlists_link, self.trakt_user)
        except:
            pass
        try:
            self.list = []
            if self.imdb_user == '': raise Exception()
            userlists += cache.get(self.imdb_user_list, 0, self.imdblists_link)
        except:
            pass
        try:
            self.list = []
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlikedlists_link, self.trakt_user): raise Exception()
                userlists += cache.get(self.trakt_user_list, 720, self.traktlikedlists_link, self.trakt_user)
            except:
                userlists += cache.get(self.trakt_user_list, 0, self.traktlikedlists_link, self.trakt_user)
        except:
            pass

        self.list = userlists
        for i in range(0, len(self.list)): self.list[i].update({'image': 'userlists.png', 'action': 'movies'})
        self.addDirectory(self.list, queue=True)
        return self.list

    def trakt_list(self, url, user):

        Log('trakt_list({},{})'.format(repr(url), repr(user)))
        
        try:
            q = dict(urlparse.parse_qsl(urlparse.urlsplit(url).query))
            q.update({'extended': 'full'})
            q = (urlencode(q)).replace('%2C', ',')
            u = url.replace('?' + urlparse.urlparse(url).query, '') + '?' + q

            result = trakt.getTraktAsJson(u)

            items = []
            for i in result:
                try: items.append(i['movie'])
                except: pass
            if len(items) == 0:
                items = result
        except:
            raise #
            return

        try:
            q = dict(urlparse.parse_qsl(urlparse.urlsplit(url).query))
            if not int(q['limit']) == len(items):
                LogR(q)
                LogR(len(items))
                raise Exception()
            q.update({'page': str(int(q['page']) + 1)})
            q = (urlencode(q)).replace('%2C', ',')
            my_next = url.replace('?' + urlparse.urlparse(url).query, '') + '?' + q
            if C.PY2: my_next = my_next.encode('utf-8')

        except:
            raise #
            my_next = ''
    
        for item in items:
            try:
                
                title = item['title']
                title = client.replaceHTMLCodes(title)

                year = item['year']
                year = re.sub('[^0-9]', '', str(year))

                if int(year) > int((self.datetime).strftime('%Y')): raise Exception()

                imdb = item['ids']['imdb']
                if imdb == None or imdb == '': raise Exception()
                imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))

                tmdb = str(item.get('ids', {}).get('tmdb', 0))

                try: premiered = item['released']
                except: premiered = '0'
                try: premiered = re.compile(r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
                except: premiered = '0'

                try: genre = item['genres']
                except: genre = '0'
                genre = [i.title() for i in genre]
                if genre == []: genre = '0'
                genre = ' / '.join(genre)

                try: duration = str(item['runtime'])
                except: duration = '0'
                if duration == None: duration = '0'

                try: rating = str(item['rating'])
                except: rating = '0'
                if rating == None or rating == '0.0': rating = '0'

                try: votes = str(item['votes'])
                except: votes = '0'
                try: votes = str(format(int(votes),',d'))
                except: pass
                if votes == None: votes = '0'

                try: mpaa = item['certification']
                except: mpaa = '0'
                if mpaa == None: mpaa = '0'

                try: plot = item['overview']
                except: plot = '0'
                if plot == None: plot = '0'
                plot = client.replaceHTMLCodes(plot)

                try: tagline = item['tagline']
                except: tagline = '0'
                if tagline == None: tagline = '0'
                tagline = client.replaceHTMLCodes(tagline)


        
                try:
                    poster = '0'
                    if 'images' in item:
                        if 'poster' in item['images']:
                            poster = item['images']['poster'][0]
                            if not poster.startswith('http'):
                                poster = 'https://' + poster
                            poster += Header2pipestring()
                            #raise Exception(poster)
                            
                except:
##                    raise
                    pass
                        


                self.list.append({'title': title
                                  , 'originaltitle': title
                                  , 'year': year
                                  , 'premiered': premiered
                                  , 'genre': genre
                                  , 'duration': duration
                                  , 'rating': rating, 'votes': votes
                                  , 'mpaa': mpaa
                                  , 'plot': plot
                                  , 'tagline': tagline
                                  , 'imdb': imdb
                                  , 'tmdb': tmdb
                                  , 'tvdb': '0'
                                  , 'poster': poster
                                  , 'next': my_next
                                  })
            except:
                raise #
                pass

        return self.list

    def trakt_user_list(self, url, user):
        try:
            items = trakt.getTraktAsJson(url)
        except:
            pass

        for item in items:
            try:
                try: name = item['list']['name']
                except: name = item['name']
                name = client.replaceHTMLCodes(name)

                try: url = (trakt.slug(item['list']['user']['username']), item['list']['ids']['slug'])
                except: url = ('me', item['ids']['slug'])
                url = self.traktlist_link % url
                url = url.encode('utf-8')

                self.list.append({'name': name, 'url': url, 'context': url})
            except:
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k['name']))
        return self.list

    def imdb_poster(self, url):
        result = client.request(url, cache_seconds=50000)
        regex = (
            ',"image":"(.+?)"'
            )
        values = re.findall(regex, result)
##        Log(repr(values))
        if values:
            val = values[0]
            return '{{"movieposter":"{}","poster":"{}","moviebanner":"{}"}}'.format(val,val,val)
        else:
            return '{}'
        
        
    def imdb_list(self, url):
        Log(__name__) ; LogR(locals())
        try:
            control.busy()
    
            try:
                regex = r'count=(\d+?)&start=(\d+?)'
                values = re.findall(regex, url)
                for count,start in values:
                    next_values = url.replace('&start={}'.format(start), '&start={}'.format(int(count) + int(start)))
            except:
                traceback.print_exc()
                next_values = ''
            for i in re.findall(r'date\[(\d+)\]', url):
                url = url.replace('date[%s]' % i, (self.datetime - datetime.timedelta(days = int(i))).strftime('%Y-%m-%d'))
        
            result = client.request(url)
            result = result.replace('\n', ' ')


            regex = '<script id="__NEXT_DATA__" type="application/json">(.+?)</script><script>'
            json_text = re.findall(regex, result)[0]
            json_values = json.loads(json_text)
            titleListItems = json_values['props']['pageProps']['searchResults']['titleResults']['titleListItems']


            for titleListItem in titleListItems:
##                LogR(titleListItem)
                try: mpaa = titleListItem['certificate']
                except: mpaa = ''
                try: duration = (titleListItem['runtime'])/60
                except: duration = 0
                try: released = titleListItem['released']
                except:
                    try: released = titleListItem['releaseYear']
                    except: released = ''
                    
                i = {   'title': titleListItem['titleText']
                      , 'originaltitle': titleListItem['originalTitleText']
                      , 'year': released
                      , 'genre': repr(titleListItem['genres'])
                      , 'duration': duration
                      , 'rating': titleListItem['ratingSummary']['aggregateRating']
                      , 'votes': titleListItem['ratingSummary']['voteCount']
                      , 'mpaa': mpaa
                      , 'director': repr(titleListItem['directors'])
                      , 'cast': '0'#repr(titleListItem['topCast'])
                      , 'plot': titleListItem['plot']
                      , 'tagline': '0'
                      , 'imdb': titleListItem['titleId']
                      , 'tmdb': '0'
                      , 'tvdb': '0'
                      , 'poster': titleListItem['primaryImage']['url']
                      , 'next': next_values
                      }
                self.list.append(i)

        except:
            traceback.print_exc()
            raise

        return self.list
    
##        try:
##            for i in re.findall('date\[(\d+)\]', url):
##                url = url.replace('date[%s]' % i, (self.datetime - datetime.timedelta(days = int(i))).strftime('%Y-%m-%d'))
##
##            def imdb_watchlist_id(url):
##                return client.parseDOM(client.request(url), 'meta', ret='content', attrs = {'property': 'pageId'})[0]
##
##            if url == self.imdbwatchlist_link:
##                Log(
##                    repr('self.imdbwatchlist_link')
##                    ,xbmc.LOGNONE
##                    )
##
##                url = cache.get(imdb_watchlist_id, 8640, url)
##                url = self.imdblist_link % url
##
##            elif url == self.imdbwatchlist2_link:
##                Log(
##                    repr('self.imdbwatchlist2_link')
##                    ,xbmc.LOGNONE
##                    )
##
##                url = cache.get(imdb_watchlist_id, 8640, url)
##                url = self.imdblist2_link % url
##            else:
##                Log(
##                    repr(url)
##                    ,xbmc.LOGNONE
##                    )                
##
##            result = client.request(url)
##
##            result = result.replace('\n', ' ')
##
##            Log(
##                repr(result)
##                ,xbmc.LOGNONE
##                )
##                
####            items = client.parseDOM(result, 'div', attrs = {'class': 'lister-item .+?'})
####            items += client.parseDOM(result, 'div', attrs = {'class': 'list_item.+?'})
##            items = client.parseDOM(result, 'li', attrs = {'class': 'ipc-metadata-list-summary-item'})
####            items += client.parseDOM(items, 'div', attrs = {'class': 'ipc-metadata-list-summary-item.+?'})
##
##        except:
##            traceback.print_exc()
##            return
##
####        Log(
####            repr(items)
####            ,xbmc.LOGNONE
####            )
##        
##        try:
##            next = client.parseDOM(result, 'a', ret='href', attrs = {'class': '.+?ister-page-nex.+?'})
##
##            if len(next) == 0:
####                next = client.parseDOM(result, 'div', attrs = {'class': 'pagination'})[0]
##                next = client.parseDOM(result, 'div', attrs = {'class': 'ipc-see-more__text'})[0]
##
##
##                next = zip(client.parseDOM(next, 'a', ret='href'), client.parseDOM(next, 'a'))
##                next = [i[0] for i in next if 'Next' in i[1]]
##
##            next = url.replace(urlparse.urlparse(url).query, urlparse.urlparse(next[0]).query)
##            next = client.replaceHTMLCodes(next)
##            next = next.encode('utf-8')
##        except:
####            traceback.print_exc()
##            next = ''
##
##        for item in items:
##            try:
##
##                Log(repr(item))
##                
##                title = client.parseDOM(item, 'a')[1]
##                title = client.replaceHTMLCodes(title)
####                Log(repr(title))
##                title = title.encode('utf-8')
##
####                year = client.parseDOM(item, 'span', attrs = {'class': 'lister-item-year.+?'})
####                year += client.parseDOM(item, 'span', attrs = {'class': 'year_type'})
####                try: year = re.compile('(\d{4})').findall(year)[0]
####                except: year = '0'
####                year = year.encode('utf-8')
####                if int(year) > int((self.datetime).strftime('%Y')): raise Exception()
##
##                imdb = client.parseDOM(item, 'a', ret='href')[0]
##                imdb = re.findall('(tt\d*)', imdb)[0]
##                imdb = imdb.encode('utf-8')
##
##
####                try: poster = client.parseDOM(item, 'img', ret='loadlate')[0]
##                try:
##                    poster = client.parseDOM(item, 'img', ret='src')[0]
####                    Log(repr(poster))
##                except: poster = '0'
##                if '/nopicture/' in poster: poster = '0'
##                poster = re.sub('(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', poster)
##                poster = client.replaceHTMLCodes(poster)
##                poster = poster.encode('utf-8')
####                raise Exception(poster)
##
####                try: genre = client.parseDOM(item, 'span', attrs = {'class': 'genre'})[0]
####                except: genre = '0'
####                genre = ' / '.join([i.strip() for i in genre.split(',')])
####                if genre == '': genre = '0'
####                genre = client.replaceHTMLCodes(genre)
####                genre = genre.encode('utf-8')
##
####                try: duration = re.findall('(\d+?) min(?:s|)', item)[-1]
####                except: duration = '0'
####                duration = duration.encode('utf-8')
##
####                rating = '0'
####                try: rating = client.parseDOM(item, 'span', attrs = {'class': 'rating-rating'})[0]
####                except: pass
####                try: rating = client.parseDOM(rating, 'span', attrs = {'class': 'value'})[0]
####                except: rating = '0'
####                try: rating = client.parseDOM(item, 'div', ret='data-value', attrs = {'class': '.*?imdb-rating'})[0]
####                except: pass
####                if rating == '' or rating == '-': rating = '0'
####                rating = client.replaceHTMLCodes(rating)
####                rating = rating.encode('utf-8')
##
####                try: votes = client.parseDOM(item, 'div', ret='title', attrs = {'class': '.*?rating-list'})[0]
####                except: votes = '0'
####                try: votes = re.findall('\((.+?) vote(?:s|)\)', votes)[0]
####                except: votes = '0'
####                if votes == '': votes = '0'
####                votes = client.replaceHTMLCodes(votes)
####                votes = votes.encode('utf-8')
##
####                try: mpaa = client.parseDOM(item, 'span', attrs = {'class': 'certificate'})[0]
####                except: mpaa = '0'
####                if mpaa == '' or mpaa == 'NOT_RATED': mpaa = '0'
####                mpaa = mpaa.replace('_', '-')
####                mpaa = client.replaceHTMLCodes(mpaa)
####                mpaa = mpaa.encode('utf-8')
##
####                try: director = re.findall('Director(?:s|):(.+?)(?:\||</div>)', item)[0]
####                except: director = '0'
####                director = client.parseDOM(director, 'a')
####                director = ' / '.join(director)
####                if director == '': director = '0'
####                director = client.replaceHTMLCodes(director)
####                director = director.encode('utf-8')
##
####                try: cast = re.findall('Stars(?:s|):(.+?)(?:\||</div>)', item)[0]
####                except: cast = '0'
####                cast = client.replaceHTMLCodes(cast)
####                cast = cast.encode('utf-8')
####                cast = client.parseDOM(cast, 'a')
####                if cast == []: cast = '0'
##
####                plot = '0'
####                try: plot = client.parseDOM(item, 'p', attrs = {'class': 'text-muted'})[0]
####                except: pass
####                try: plot = client.parseDOM(item, 'div', attrs = {'class': 'item_description'})[0]
####                except: pass
####                plot = plot.rsplit('<span>', 1)[0].strip()
####                plot = re.sub('<.+?>|</.+?>', '', plot)
####                if plot == '': plot = '0'
####                plot = client.replaceHTMLCodes(plot)
####                plot = plot.encode('utf-8')
##
##                i = {'title': title
##                      , 'originaltitle': title
##                      , 'year': 0
####                      , 'genre': genre
####                      , 'duration': duration
####                      , 'rating': rating
####                      , 'votes': votes
####                      , 'mpaa': mpaa
####                      , 'director': director
####                      , 'cast': cast
####                      , 'plot': plot
##                      , 'tagline': '0'
##                      , 'imdb': imdb
##                      , 'tmdb': '0'
##                      , 'tvdb': '0'
##                      , 'poster': poster
##                      , 'next': next
##                      }
####                Log(repr(i))
##                self.list.append(i)
##            except:
##                traceback.print_exc()
##                pass
##
##        return self.list

    def imdb_person_list(self, url):
        try:
            result = client.request(url)
##            items = client.parseDOM(result, 'div', attrs = {'class': '.+?etail'})
            items = client.parseDOM(result, 'li', attrs = {'class': 'ipc-metadata-list-summary-item'})
        except:
            Log('todo remove raise')
            raise
            return

        for item in items:
            try:
                name = client.parseDOM(item, 'img', ret='alt')[0]
                if C.PY2: name = name.encode('utf-8')

                url = client.parseDOM(item, 'a', ret='href')[0]
                url = re.findall(r'(nm\d*)', url, re.I)[0]
                url = self.person_link % url
                url = client.replaceHTMLCodes(url)
                if C.PY2: url = url.encode('utf-8')

                image = client.parseDOM(item, 'img', ret='src')[0]
##                if not ('._SX' in image or '._SY' in image): raise Exception()
##                image = re.sub('(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', image)
                image = client.replaceHTMLCodes(image)
                if C.PY2: image = image.encode('utf-8')

                person = {
                    'name': name
                    , 'url': url
                    , 'image': image
                    }
##                LogR(person)
                self.list.append(person)
            except:
                LogR(item)
                pass

        return self.list

    def imdb_user_list(self, url):
        try:
            result = client.request(url)
            items = client.parseDOM(result, 'li', attrs = {'class': 'ipl-zebra-list__item user-list'})
        except:
            pass

        for item in items:
            try:
##                name = client.parseDOM(item, 'a')[0]
                name = client.parseDOM(item, 'img', ret='alt' )[0]
                name = client.replaceHTMLCodes(name)
                if C.PY2: name = name.encode('utf-8')

                url = client.parseDOM(item, 'a', ret='href')[0]
                url = url.split('/list/', 1)[-1].strip('/')
                url = self.imdblist_link % url
                url = client.replaceHTMLCodes(url)
                if C.PY2: url = url.encode('utf-8')

                self.list.append({'name': name, 'url': url, 'context': url})
            except:
                LogR(item)
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k['name']))
        return self.list

    def worker(self, level=1):
        self.meta = []
##        Log(repr(self.list)
##            , C.LOGNONE
##            )
        if not self.list: return
        total = len(self.list)

        #self.fanart_tv_headers = {'api-key': 'ZDY5NTRkYTk2Yzg4ODFlMzdjY2RkMmQyNTlmYjk1MzQ='.decode('base64')} #d6954da96c8881e37ccdd2d259fb9534
        self.fanart_tv_headers = {'api-key': 'b00850f5e8d662cd5484c6a2af1233fa'}
        #self.fanart_tv_headers = {'client-key': 'dc7806bf1ba09774b8dcfbf28b68dc31'}
        #7984cb9b3243e61c8699cb1d3ee21ca1
        if not self.fanart_tv_user == '':
            self.fanart_tv_headers.update({'client-key': self.fanart_tv_user})

        for i in range(0, total): self.list[i].update({'metacache': False})

        self.list = metacache.fetch(self.list, self.lang, self.user)

        for r in range(0, total, 40):
            threads = []
            for i in range(r, r+40):
                if i <= total: threads.append(workers.Thread(self.super_info, i))
            [i.start() for i in threads]
            [i.join() for i in threads]

            if self.meta: metacache.insert(self.meta)

        self.list = [i for i in self.list if not i['imdb'] == '0']

##        self.list = metacache.local(self.list, self.tm_img_link, 'poster3', 'fanart2')

        if self.fanart_tv_user == '':
            for i in self.list:
                i.update({'clearlogo': '0', 'clearart': '0'})

    def super_info(self, i):
##        control.busy()
        try:

            if i >= len(self.list):
                return #skip this for 'Next Page' type controls

            if self.list[i]['metacache'] == True:
                if 'poster' in self.list[i] and self.list[i]['poster'] and self.list[i]['poster']!='0':
                    raise StopIteration


            if len(self.list)-1>=i and ('imdb' in self.list[i]):
                imdb = self.list[i]['imdb']
            else :
                Log('no imdb after ' + repr(self.list[i-1]))
                return

            item = trakt.getMovieSummary(imdb)
            
            if not item:
                Log('getMovieSummary='+str(imdb) + repr(item))
                return
            
            title = item.get('title')
            title = client.replaceHTMLCodes(title)

            originaltitle = title

            year = item.get('year', 0)
            year = re.sub('[^0-9]', '', str(year))

            imdb = item.get('ids', {}).get('imdb', '0')
            imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))

            tmdb = str(item.get('ids', {}).get('tmdb', 0))

            premiered = item.get('released', '0')
            try:
                premiered = re.compile(r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
            except:
                premiered = '0'

            genre = item.get('genres', [])
            genre = [x.title() for x in genre]
            genre = ' / '.join(genre).strip()
            if not genre: genre = '0'

            duration = str(item.get('Runtime', 0))

            rating = item.get('rating', '0')
            if not rating or rating == '0.0': rating = '0'

            votes = item.get('votes', '0')
            try: votes = str(format(int(votes), ',d'))
            except: pass

            mpaa = item.get('certification', '0')
            if not mpaa: mpaa = '0'

            tagline = item.get('tagline', '0')

            plot = item.get('overview', '0')

            people = trakt.getPeople(imdb, 'movies')

            director = writer = ''
            if 'crew' in people and 'directing' in people['crew']:
                director = ', '.join([director['person']['name'] for director in people['crew']['directing'] if director['job'].lower() == 'director'])
            if 'crew' in people and 'writing' in people['crew']:
                writer = ', '.join([writer['person']['name'] for writer in people['crew']['writing'] if writer['job'].lower() in ['writer', 'screenplay', 'author']])

            cast = []
            for person in people.get('cast', []):
                cast.append({'name': person['person']['name'], 'role': person['character']})
            cast = [(person['name'], person['role']) for person in cast]

            try:
                if self.lang == 'en' or self.lang not in item.get('available_translations', [self.lang]): raise Exception()

                trans_item = trakt.getMovieTranslation(imdb, self.lang, full=True)

                title = trans_item.get('title') or title
                tagline = trans_item.get('tagline') or tagline
                plot = trans_item.get('overview') or plot
            except:
                pass

##            try:
#cache.get(self.imdb_list, 0, url)
            art = self.imdb_poster("https://www.imdb.com/title/{}/".format(imdb))
##            art = cache.get(self.imdb_poster, 24, "https://www.imdb.com/title/{}/".format(imdb))
            artmeta = True
            #if self.fanart_tv_user == '': raise Exception()
##                art = client.request(self.fanart_tv_art_link % imdb, headers=self.fanart_tv_headers, timeout='10', error=True)
##                art = ""
##            Log(repr((title,art)))
            try:
                art = json.loads(art)
            except:
                artmeta = False
                raise
##            except:
##                raise
##                pass

            try:
                poster2 = art['movieposter']
##                poster2 = [x for x in poster2 if x.get('lang') == self.lang][::-1] + [x for x in poster2 if x.get('lang') == 'en'][::-1] + [x for x in poster2 if x.get('lang') in ['00', '']][::-1]
##                poster2 = poster2[0]['url'].encode('utf-8')
##                Log(repr(poster2))
            except:
##                raise
                poster2 = '0'

            try:
                if 'moviebackground' in art: fanart = art['moviebackground']
                else: fanart = art['moviethumb']
                fanart = [x for x in fanart if x.get('lang') == self.lang][::-1] + [x for x in fanart if x.get('lang') == 'en'][::-1] + [x for x in fanart if x.get('lang') in ['00', '']][::-1]
                fanart = fanart[0]['url'].encode('utf-8')
            except:
                fanart = '0'

            try:
                banner = art['moviebanner']
                banner = [x for x in banner if x.get('lang') == self.lang][::-1] + [x for x in banner if x.get('lang') == 'en'][::-1] + [x for x in banner if x.get('lang') in ['00', '']][::-1]
                banner = banner[0]['url'].encode('utf-8')
            except:
                banner = '0'

            try:
                if 'hdmovielogo' in art: clearlogo = art['hdmovielogo']
                else: clearlogo = art['clearlogo']
                clearlogo = [x for x in clearlogo if x.get('lang') == self.lang][::-1] + [x for x in clearlogo if x.get('lang') == 'en'][::-1] + [x for x in clearlogo if x.get('lang') in ['00', '']][::-1]
                clearlogo = clearlogo[0]['url'].encode('utf-8')
            except:
                clearlogo = '0'

            try:
                if 'hdmovieclearart' in art: clearart = art['hdmovieclearart']
                else: clearart = art['clearart']
                clearart = [x for x in clearart if x.get('lang') == self.lang][::-1] + [x for x in clearart if x.get('lang') == 'en'][::-1] + [x for x in clearart if x.get('lang') in ['00', '']][::-1]
                clearart = clearart[0]['url'].encode('utf-8')
            except:
                clearart = '0'

            try:
                if self.tm_user == '': raise Exception()

                art2 = client.request(self.tm_art_link % imdb, timeout='10', error=True)
                art2 = json.loads(art2)
            except:
                pass

            try:
                poster3 = art2['posters']
                poster3 = [x for x in poster3 if x.get('iso_639_1') == self.lang] + [x for x in poster3 if x.get('iso_639_1') == 'en'] + [x for x in poster3 if x.get('iso_639_1') not in [self.lang, 'en']]
                poster3 = [(x['width'], x['file_path']) for x in poster3]
                poster3 = [(x[0], x[1]) if x[0] < 300 else ('300', x[1]) for x in poster3]
                poster3 = self.tm_img_link % poster3[0]
                poster3 = poster3.encode('utf-8')
            except:
                poster3 = '0'

            try:
                fanart2 = art2['backdrops']
                fanart2 = [x for x in fanart2 if x.get('iso_639_1') == self.lang] + [x for x in fanart2 if x.get('iso_639_1') == 'en'] + [x for x in fanart2 if x.get('iso_639_1') not in [self.lang, 'en']]
                fanart2 = [x for x in fanart2 if x.get('width') == 1920] + [x for x in fanart2 if x.get('width') < 1920]
                fanart2 = [(x['width'], x['file_path']) for x in fanart2]
                fanart2 = [(x[0], x[1]) if x[0] < 1280 else ('1280', x[1]) for x in fanart2]
                fanart2 = self.tm_img_link % fanart2[0]
                fanart2 = fanart2.encode('utf-8')
            except:
                fanart2 = '0'

            item = {'title': title
                    , 'originaltitle': originaltitle
                    , 'year': year
                    , 'imdb': imdb
                    , 'tmdb': tmdb
##                    , 'poster': poster2
                    #, 'poster2': poster2
##                    , 'poster3': poster2
##                    , 'banner': banner
                    #, 'fanart': fanart
##                    , 'fanart2': poster2
                    #, 'clearlogo': clearlogo
                    #, 'clearart': clearart
                    , 'premiered': premiered
                    , 'genre': genre
                    , 'duration': duration
                    , 'rating': rating, 'votes': votes
                    , 'mpaa': mpaa
                    , 'director': director
                    , 'writer': writer
                    , 'cast': cast
                    , 'plot': plot
                    , 'tagline': tagline}

##            Log(repr(item))
            if C.PY2:
                item = dict((k,v) for k, v in item.iteritems() if not v == '0')
            else:
                item = dict((k,v) for k, v in item.items() if not v == '0')
            self.list[i].update(item)
##            Log(repr(self.list[i]))
            
##            if artmeta == False:
##                raise Exception()

            meta = {'imdb': imdb
                    , 'tmdb': tmdb
                    , 'tvdb': '0'
                    , 'lang': self.lang
                    , 'user': self.user
                    , 'item': item}
            self.meta.append(meta)

        except StopIteration:
            pass
        except:
            Log(repr(self.list[i]))
            traceback.print_exc()
            pass

    def movieDirectory(self, items):
##        Log(repr((type(items),items)))
##        return
        if items == None or len(items) == 0: control.idle() ; sys.exit()

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        addonPoster, addonBanner = control.addonPoster(), control.addonBanner()

        addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')

        traktCredentials = trakt.getTraktCredentialsInfo()

        try: isOld = False ; control.item().getArt('type')
        except: isOld = True

        isPlayable = 'true' if not 'plugin' in control.infoLabel('Container.PluginName') else 'false'

##        indicators = playcount.getMovieIndicators(refresh=True) if action == 'movies' else playcount.getMovieIndicators()
        try:        
            indicators = playcount.getMovieIndicators(refresh=True)
        except:
            traceback.print_exc()
            pass
        
        playbackMenu = control.lang(32063).encode('utf-8') if control.setting('hosts.mode') == '2' else control.lang(32064).encode('utf-8')

        watchedMenu = control.lang(32068).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32066).encode('utf-8')

        unwatchedMenu = control.lang(32069).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32067).encode('utf-8')

        queueMenu = control.lang(32065).encode('utf-8')

        traktManagerMenu = control.lang(32070).encode('utf-8')

        nextMenu = control.lang(32053).encode('utf-8')

        addToLibrary = control.lang(32551).encode('utf-8')

        for i in items:

            try:
                label = '%s (%s)' % (i['title'], i['year'])
                imdb, tmdb, title, year = i['imdb'], i['tmdb'], i['originaltitle'], i['year']
                sysname = quote_plus('%s (%s)' % (title, year))
                systitle = quote_plus(title)

                if C.PY2:
                    meta = dict((k,v) for k, v in i.iteritems() if not v == '0')
                else:
                    meta = dict((k,v) for k, v in i.items() if not v == '0')
##                Log(repr((type(meta),meta)))
                meta.update({'code': imdb, 'imdbnumber': imdb, 'imdb_id': imdb})
                meta.update({'tmdb_id': tmdb})
                meta.update({'mediatype': 'movie'})
                meta.update({'trailer': '%s?action=trailer&name=%s' % (sysaddon, quote_plus(label))})
                #meta.update({'trailer': 'plugin://script.extendedinfo/?info=playtrailer&&id=%s' % imdb})
                if not 'duration' in i: meta.update({'duration': '120'})
                elif i['duration'] == '0': meta.update({'duration': '120'})
                try: meta.update({'duration': str(int(meta['duration']) * 60)})
                except: pass
                try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
                except: pass
                try:
                    if 'premiered' in meta:
                        meta.update({'dateadded': meta['premiered']+' 12:12:12'})
                except:
                    traceback.print_exc()
                    pass


                poster = [i[x] for x in ['poster3', 'poster', 'poster2'] if i.get(x, '0') != '0']
                poster = poster[0] if poster else addonPoster
                meta.update({'poster': poster})

##                Log(repr((type(meta),meta)))

                sysmeta = quote_plus(json.dumps(meta))

#                url = '%s?action=play&title=%s&year=%s&imdb=%s&meta=%s&t=%s' % (sysaddon, systitle, year, imdb, sysmeta, self.systime)
                #systime needs to be remvoed or else kodi adds it as unique
                url = '%s?action=play&title=%s&year=%s&imdb=%s&meta=%s' % (sysaddon, systitle, year, imdb, sysmeta)
                sysurl = quote_plus(url)

                path = '%s?action=play&title=%s&year=%s&imdb=%s' % (sysaddon, systitle, year, imdb)

                cm = []

                cm.append(('Find similar',
                           'ActivateWindow(10025,%s?action=movies&url=https://api.trakt.tv/movies/%s/related,return)' % (
                           sysaddon, imdb)))

                cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                try:
                    overlay = int(playcount.getMovieOverlay(indicators, imdb))
                    METAHANDLER_WATCHED   = 7
                    METAHANDLER_UNWATCHED = 6
##                    LogR((imdb,overlay,METAHANDLER_UNWATCHED,METAHANDLER_WATCHED))
                    if overlay == METAHANDLER_WATCHED:
##                        cm.append((unwatchedMenu, 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=%s)' % (sysaddon, imdb, METAHANDLER_UNWATCHED)))
                        meta.update({'playcount': 1, 'overlay': METAHANDLER_WATCHED})
                    else:
##                        cm.append((watchedMenu, 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=%s)' % (sysaddon, imdb, METAHANDLER_WATCHED)))
                        meta.update({'playcount': 0, 'overlay': METAHANDLER_UNWATCHED})
                except:
                    raise
                    pass

                if traktCredentials == True:
                    cm.append((traktManagerMenu, 'RunPlugin(%s?action=traktManager&name=%s&imdb=%s&content=movie)' % (sysaddon, sysname, imdb)))

                cm.append((playbackMenu, 'RunPlugin(%s?action=alterSources&url=%s&meta=%s)' % (sysaddon, sysurl, sysmeta)))

                if isOld == True:
                    cm.append((control.lang2(19033).encode('utf-8'), 'Action(Info)'))

                cm.append((addToLibrary, 'RunPlugin(%s?action=movieToLibrary&name=%s&title=%s&year=%s&imdb=%s&tmdb=%s)' % (sysaddon, sysname, systitle, year, imdb, tmdb)))
                
                cm.append(('Exodus Redux Settings', 'RunPlugin(%s?action=openSettings&query=(0,0))' % sysaddon))
                
                item = control.item(label=label)
                item.setContentLookup(False) #prevent HEAD requests

                art = {}
                art.update({'icon': poster, 'thumb': poster, 'poster': poster})

                if 'banner' in i and not i['banner'] == '0':
                    art.update({'banner': i['banner']})
                else:
                    art.update({'banner': addonBanner})

                if 'clearlogo' in i and not i['clearlogo'] == '0':
                    art.update({'clearlogo': i['clearlogo']})

                if 'clearart' in i and not i['clearart'] == '0':
                    art.update({'clearart': i['clearart']})

                if settingFanart == 'true' and 'fanart2' in i and not i['fanart2'] == '0':
                    item.setProperty('Fanart_Image', i['fanart2'])
                elif settingFanart == 'true' and 'fanart' in i and not i['fanart'] == '0':
                    item.setProperty('Fanart_Image', i['fanart'])
                elif not addonFanart == None:
                    item.setProperty('Fanart_Image', addonFanart)

                item.setArt(art)
                item.addContextMenuItems(cm)
##                item.setProperty('IsPlayable', isPlayable)

                max_loops = 1000
                loop_count = 0
                was_changed = True
                while (was_changed == True)  and  (loop_count < max_loops) :
                    loop_count = loop_count + 1
                    was_changed = False
                    for a in meta:
                        if a == 'imdb':
                            was_changed = True
                            meta['imdbnumber'] = meta[a]
                            meta.pop(a)
                            break
                        if a in C.bad_attributes:
                            was_changed = True
                            meta.pop(a)
                            break

                if 'tmdb' in meta:
                    meta.pop('tmdb')

                if C.PY2:
                    item.setInfo(type='Video', infoLabels = meta)
                    video_streaminfo = {'codec': 'h264'}
                    item.addStreamInfo('video', video_streaminfo)
                else:
                    videoInfoTag = item.getVideoInfoTag()
##                    LogR(videoInfoTag.getPlayCount())
##                    LogR(videoInfoTag.getPlayCount())
##                    LogR(videoInfoTag.getLastPlayedAsW3C())
                    for a in meta:
##                        Log(repr(meta[a]))
                        if a == "title": videoInfoTag.setTitle(meta[a])
                        if a == "originaltitle": videoInfoTag.setOriginalTitle(meta[a])
                        if a == "year":
                            if type(meta[a]) is str or type(meta[a]) is int:
                                videoInfoTag.setYear(int(meta[a]))
                        if a == "premiered": videoInfoTag.setPremiered(meta[a])
##                        if a == "genre": videoInfoTag.setGenres(meta[a])
                        if a == "duration": videoInfoTag.setDuration(int(meta[a]))
                        if a == "rating": videoInfoTag.setRating(float(meta[a]))
                        if a == "votes":
                            if type(meta[a]) is str:
                                meta[a] = meta[a].replace(",","")
                            videoInfoTag.setVotes(int(float(meta[a])))
                        if a == "mpaa": videoInfoTag.setMpaa(meta[a])
                        if a == "plot": videoInfoTag.setPlot(meta[a])
                        if a == "tagline": videoInfoTag.setTagLine(meta[a])
                        if a == "code": videoInfoTag.setProductionCode(meta[a])
                        if a == "imdbnumber": videoInfoTag.setIMDBNumber(meta[a])
                        if a == "mediatype": videoInfoTag.setMediaType(meta[a])
                        if a == "dateadded": videoInfoTag.setDateAdded(meta[a])
                        if a == "playcount":
                            LogR(meta[a])
                            videoInfoTag.setPlaycount(meta[a])
                            

                        
                    vsd = xbmc.VideoStreamDetail()
                    vsd.setCodec('h264')
                    videoInfoTag.addVideoStream(vsd)
                    
##                item.setProperty('IsPlayable', 'false')
                item.setMimeType('video/mp4') #prevent HEAD requests
                item.setContentLookup(False)  #prevent HEAD requests
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
            except:
                LogR(i)
                traceback.print_exc()
                pass

        try:
            url = items[0]['next']
            if url == '': raise StopIteration('No NEXT link')
            icon = control.addonNext()
            url = '%s?action=moviePage&url=%s' % (sysaddon, quote_plus(url))
            item = control.item(label=nextMenu)
            item.setArt({  'icon': icon
                         , 'thumb': icon
                         , 'poster': icon
                         , 'banner': icon
                         }
                        )
            if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)

            item.setMimeType('video/mp4') #prevent HEAD requests
            item.setContentLookup(False) #prevent HEAD requests
            control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
        except StopIteration:
            traceback.print_exc()
            pass
        except:
            traceback.print_exc()
            pass

        control.content(syshandle, 'movies')
        control.directory(syshandle, cacheToDisc=True)
        views.setView('movies', {'skin.estuary': 55, 'skin.confluence': 500})

    def addDirectory(self, items, queue=False):
        if items == None or len(items) == 0: control.idle() ; sys.exit()

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        addonFanart, addonThumb, artPath = control.addonFanart(), control.addonThumb(), control.artPath()

        queueMenu = control.lang(32065).encode('utf-8')

        playRandom = control.lang(32535).encode('utf-8')

        addToLibrary = control.lang(32551).encode('utf-8')

        for i in items:
            try:
                name = i['name']

                if i['image'].startswith('http'): thumb = i['image']
                elif not artPath == None: thumb = os.path.join(artPath, i['image'])
                else: thumb = addonThumb

                url = '%s?action=%s' % (sysaddon, i['action'])
                try: url += '&url=%s' % quote_plus(i['url'])
                except: pass

                cm = []
                
                cm.append(('Settings', 'RunPlugin(%s?action=openSettings&query=0.0)' % sysaddon))
                
                cm.append((playRandom, 'RunPlugin(%s?action=random&rtype=movie&url=%s)' % (sysaddon, quote_plus(i['url']))))

                if queue == True:
                    cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                try: cm.append((addToLibrary, 'RunPlugin(%s?action=moviesToLibrary&url=%s)' % (sysaddon, quote_plus(i['context']))))
                except: pass

                item = control.item(label=name)
                item.setArt({'icon': thumb, 'thumb': thumb})
                if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)
                item.addContextMenuItems(cm)
                
                item.setMimeType('video/mp4') #prevent HEAD requests
                item.setContentLookup(False) #prevent HEAD requests
                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
            except:
                traceback.print_exc()
                pass

        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)
