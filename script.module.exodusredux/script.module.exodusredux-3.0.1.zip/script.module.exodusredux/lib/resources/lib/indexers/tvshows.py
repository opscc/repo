# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os,sys,re,json,datetime
import traceback,random
import xbmc

from resources.lib.modules import trakt
from resources.lib.modules import cleangenre
from resources.lib.modules import cleantitle
from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import metacache
from resources.lib.modules import playcount
from resources.lib.modules import workers
from resources.lib.modules import views
from resources.lib.modules import utils
from resources.lib.indexers import navigator

from resources.lib import constants as C

from resources.lib.constants import urlparse
from resources.lib.constants import urlencode
from resources.lib.constants import quote_plus
from resources.lib.modules.log_utils import Log,LogR


params = dict(urlparse.parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()

action = params.get('action')

class tvshows:
    def __init__(self):
        self.list = []
        self.imdb_link = 'http://www.imdb.com'
        self.trakt_link = 'https://api.trakt.tv'
        self.tvmaze_link = 'https://www.tvmaze.com'
        self.logo_link = 'https://i.imgur.com/'
        self.tvdb_key = control.setting('tvdb.user')
        if self.tvdb_key == '' or self.tvdb_key == None:
            self.tvdb_key = '1D62F2F90030C444'
        self.datetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
        self.trakt_user = control.setting('trakt.user').strip()
        self.imdb_user = control.setting('imdb.user').replace('ur', '')
        self.fanart_tv_user = control.setting('fanart.tv.user')
        self.fanart_tv_api = control.setting('fanart.tv.api')
        
        self.user = control.setting('fanart.tv.user') + str('')
        self.lang = control.apiLanguage()['tvdb']

        self.search_link = 'https://api.trakt.tv/search/show?limit=20&page=1&query='
        self.tvmaze_info_link = 'https://api.tvmaze.com/shows/%s'
        self.tvdb_info_link = 'https://thetvdb.com/api/%s/series/%s/%s.xml' % (self.tvdb_key, '%s', self.lang)
        self.fanart_tv_art_link = 'https://webservice.fanart.tv/v3/tv/%s'
        self.fanart_tv_level_link = 'https://webservice.fanart.tv/v3/level'
        self.tvdb_by_imdb = 'https://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s'
        self.tvdb_by_query = 'https://thetvdb.com/api/GetSeries.php?seriesname=%s'
        self.tvdb_image = 'https://thetvdb.com/banners/'

##        self.persons_link = 'https://www.imdb.com/search/name?count=100&name='
        self.persons_link = 'https://www.imdb.com/search/name/?count=100&name='

        self.personlist_link = 'https://www.imdb.com/search/name/?count=100&gender=male,female'
        self.popular_link = 'https://www.imdb.com/search/title/?title_type=tv_movie,tv_series,tv_episode,tv_miniseries&num_votes=100,&start=1&ref_=adv_nxt'
        self.airing_link = 'https://www.imdb.com/search/title/?title_type=tv_series,tv_episode&release_date=date[1],date[0]&sort=moviemeter,asc&count=40&start=1'
        self.active_link = 'https://www.imdb.com/search/title/?title_type=tv_series,tv_episode,mini_series&num_votes=10,&production_status=active&sort=moviemeter,asc&count=40&start=1'
        #self.premiere_link = 'https://www.imdb.com/search/title?title_type=tv_series,mini_series&languages=en&num_votes=10,&release_date=date[60],date[0]&sort=moviemeter,asc&count=40&start=1'
        self.premiere_link = 'https://www.imdb.com/search/title/?title_type=tv_series,mini_series&languages=en&num_votes=10,&release_date=date[60],date[0]&sort=release_date,desc&count=40&start=1'
##        self.rating_link = 'https://www.imdb.com/search/title?title_type=tv_series,mini_series&num_votes=5000,&release_date=,date[0]&sort=user_rating,desc&count=40&start=1'
        self.rating_link = 'https://www.imdb.com/search/title/?title_type=tv_series,mini_series&num_votes=5000,&release_date=,date[0]&sort=user_rating,desc&count=40&start=1'

        self.views_link = 'https://www.imdb.com/search/title/?title_type=tv_series,mini_series&num_votes=100,&release_date=,date[0]&sort=num_votes,desc&count=40&start=1'
        self.person_link = 'https://www.imdb.com/search/title/?title_type=tv_series,mini_series&release_date=,date[0]&role=%s&sort=year,desc&count=40&start=1'
        #self.genre_link = 'https://www.imdb.com/search/title?title_type=tv_series,mini_series&release_date=,date[0]&genres=%s&sort=moviemeter,asc&count=40&start=1'
        self.genre_link = 'https://www.imdb.com/search/title/?title_type=tv_series,mini_series&release_date=,date[0]&genres=%s&sort=moviemeter,asc&count=40&start=1'
        self.keyword_link = 'https://www.imdb.com/search/title/?title_type=tv_series,mini_series&release_date=,date[0]&keywords=%s&sort=moviemeter,asc&count=40&start=1'
        self.language_link = 'https://www.imdb.com/search/title/?title_type=tv_series,mini_series&num_votes=100,&production_status=released&primary_language=%s&sort=moviemeter,asc&count=40&start=1'
        self.certification_link = 'https://www.imdb.com/search/title/?title_type=tv_series,mini_series&release_date=,date[0]&certificates=us:%s&sort=moviemeter,asc&count=40&start=1'
        #https://trakt.docs.apiary.io/#
        #https://twitter.com/traktapi
        
        force_latest_trakt = not(C.DEBUG)
        if force_latest_trakt:
            LogR(force_latest_trakt)
            self.trending_link = 'https://api.trakt.tv/shows/trending?limit=12&page=1' + '&_='+str(random.randint(100000,9999999)) #cloudflare caches data too long without
        else:
            #force one just for today
            self.trending_link = 'https://api.trakt.tv/shows/trending?limit=12&page=1' + '&_=' + datetime.datetime.now().isoformat()[0:10]
        #note: trakt_list method will auto-increment update the page number
        
        self.traktlists_link = 'https://api.trakt.tv/users/me/lists'
        self.traktlikedlists_link = 'https://api.trakt.tv/users/likes/lists?limit=1000000'
        self.traktlist_link = 'https://api.trakt.tv/users/%s/lists/%s/items'
        self.traktcollection_link = 'https://api.trakt.tv/users/me/collection/shows'
        self.traktwatchlist_link = 'https://api.trakt.tv/users/me/watchlist/shows'
        self.traktfeatured_link = 'https://api.trakt.tv/recommendations/shows?limit=40'
        self.imdblists_link = 'https://www.imdb.com/user/ur%s/lists?tab=all&sort=mdfd&order=desc&filter=titles' % self.imdb_user
        self.imdblist_link = 'https://www.imdb.com/list/%s/?view=detail&sort=alpha,asc&title_type=tvSeries,tvMiniSeries&start=1'
        self.imdblist2_link = 'https://www.imdb.com/list/%s/?view=detail&sort=date_added,desc&title_type=tvSeries,tvMiniSeries&start=1'
        self.imdbwatchlist_link = 'http://www.imdb.com/user/ur%s/watchlist?sort=alpha,asc' % self.imdb_user
        self.imdbwatchlist2_link = 'http://www.imdb.com/user/ur%s/watchlist?sort=date_added,desc' % self.imdb_user


    def get(self, url, idx=True, create_directory=True):

        try:
                
            try: url = getattr(self, url + '_link')
            except: pass

            try: u = urlparse.urlparse(url).netloc.lower()
            except: pass

            if u in self.trakt_link and '/users/' in url:
                Log(url)

                try:
                    if not '/users/me/' in url: raise Exception()
                    if trakt.getActivity() > cache.timeout(self.trakt_list, url, self.trakt_user): raise Exception()
                    self.list = cache.get(self.trakt_list, 720, url, self.trakt_user)
                except:
                    self.list = cache.get(self.trakt_list, 0, url, self.trakt_user)

                if '/users/me/' in url and '/collection/' in url:
                    self.list = sorted(self.list, key=lambda k: utils.title_key(k['title']))

                if idx == True: self.worker()

            elif u in self.trakt_link and self.search_link in url:
                self.list = cache.get(self.trakt_list, 1, url, self.trakt_user)
                if idx == True: self.worker(level=0)

            elif u in self.trakt_link:
                self.list = cache.get(self.trakt_list, 24, url, self.trakt_user)
                if idx == True: self.worker()

            elif u in self.imdb_link and ('/user/' in url or '/list/' in url):
                self.list = cache.get(self.imdb_list, 0, url)
                if idx == True: self.worker()

            elif u in self.imdb_link:
                Log('todo cache this',C.LOGWARNING)
                self.list = self.imdb_list(url)
                if idx == True: self.worker()

            elif u in self.tvmaze_link:
                self.list = cache.get(self.tvmaze_list, 168, url)
                if idx == True: self.worker()

            if idx == True and create_directory == True:
                self.tvshowDirectory(self.list)

##            LogR(self.list,C.LOGWARNING)
            return self.list
        except:
            raise
            pass

    def search(self):
        navigator.navigator().addDirectoryItem(32603, 'tvSearchnew', 'search.png', 'DefaultTVShows.png')
        search_history = control.setting('tvsearch')
        if search_history:
            for term in search_history.split('\n'):
                if term:
                    navigator.navigator().addDirectoryItem(term, 'tvSearchterm&name=%s' % term, 'search.png', 'DefaultTVShows.png')
            navigator.navigator().addDirectoryItem(32605, 'clearCacheSearch', 'tools.png', 'DefaultAddonProgram.png')
        navigator.navigator().endDirectory()


    def search_new(self):
        Log(control.myName(__name__))

        t = control.lang(32010).encode('utf-8')
        k = control.keyboard('', t) ; k.doModal()
        q = k.getText().strip() if k.isConfirmed() else None
        if not q: return

        search_history = control.setting('tvsearch')
        if q not in search_history.split('\n'):
            control.setSetting('tvsearch', q + '\n' + search_history)

        url = self.search_link + quote_plus(q)
        self.get(url)


    def search_term(self, name):
        url = self.search_link + quote_plus(name)
        self.get(url)


    def person(self, pers=None):
##        Log(__name__)
        if not pers:
            t = control.lang(32010).encode('utf-8')
            k = control.keyboard('', t) ; k.doModal()
            q = k.getText().strip() if k.isConfirmed() else None
            if not q: return
        else: q = pers
        url = self.persons_link + quote_plus(q)
        self.persons(url)

    def genres(self):
        genres = [
            ('Action', 'action', True),
            ('Adventure', 'adventure', True),
            ('Animation', 'animation', True),
            ('Anime', 'anime', False),
            ('Biography', 'biography', True),
            ('Comedy', 'comedy', True),
            ('Crime', 'crime', True),
            ('Drama', 'drama', True),
            ('Family', 'family', True),
            ('Fantasy', 'fantasy', True),
            ('Game-Show', 'game_show', True),
            ('History', 'history', True),
            ('Horror', 'horror', True),
            ('Music ', 'music', True),
            ('Musical', 'musical', True),
            ('Mystery', 'mystery', True),
            ('News', 'news', True),
            ('Reality-TV', 'reality_tv', True),
            ('Romance', 'romance', True),
            ('Science Fiction', 'sci_fi', True),
            ('Sport', 'sport', True),
            ('Talk-Show', 'talk_show', True),
            ('Thriller', 'thriller', True),
            ('War', 'war', True),
            ('Western', 'western', True)
        ]

        for i in genres: self.list.append(
            {
                'name': cleangenre.lang(i[0], self.lang),
                'url': self.genre_link % i[1] if i[2] else self.keyword_link % i[1],
                'image': 'genres.png',
                'action': 'tvshows'
            })

        self.addDirectory(self.list)
        return self.list

    def networks(self):
        networks = [
        ('A&E', '/networks/29/ae', 'https://i.imgur.com/xLDfHjH.png'),
        ('ABC', '/networks/3/abc', 'https://i.imgur.com/qePLxos.png'),
        ('AMC', '/networks/20/amc', 'https://i.imgur.com/ndorJxi.png'),
        ('AT-X', '/networks/167/at-x', 'https://i.imgur.com/JshJYGN.png'),
        ('Adult Swim', '/networks/10/adult-swim', 'https://i.imgur.com/jCqbRcS.png'),
        ('Amazon', '/webchannels/3/amazon', 'https://i.imgur.com/ru9DDlL.png'),
        ('Animal Planet', '/networks/92/animal-planet', 'https://i.imgur.com/olKc4RP.png'),
        ('Audience', '/networks/31/audience-network', 'https://i.imgur.com/5Q3mo5A.png'),
        ('BBC America', '/networks/15/bbc-america', 'https://i.imgur.com/TUHDjfl.png'),
        ('BBC Four', '/networks/51/bbc-four', 'https://i.imgur.com/PNDalgw.png'),
        ('BBC One', '/networks/12/bbc-one', 'https://i.imgur.com/u8x26te.png'),
        ('BBC Three', '/webchannels/71/bbc-three', 'https://i.imgur.com/SDLeLcn.png'),
        ('BBC Two', '/networks/37/bbc-two', 'https://i.imgur.com/SKeGH1a.png'),
        ('BET', '/networks/56/bet', 'https://i.imgur.com/ZpGJ5UQ.png'),
        ('Bravo', '/networks/52/bravo', 'https://i.imgur.com/TmEO3Tn.png'),
        ('CBC', '/networks/36/cbc', 'https://i.imgur.com/unQ7WCZ.png'),
        ('CBS', '/networks/2/cbs', 'https://i.imgur.com/8OT8igR.png'),
        ('CTV', '/networks/48/ctv', 'https://i.imgur.com/qUlyVHz.png'),
        ('CW', '/networks/5/the-cw', 'https://i.imgur.com/Q8tooeM.png'),
        ('CW Seed', '/webchannels/13/cw-seed', 'https://i.imgur.com/nOdKoEy.png'),
        ('Cartoon Network', '/networks/11/cartoon-network', 'https://i.imgur.com/zmOLbbI.png'),
        ('Channel 4', '/networks/45/channel-4', 'https://i.imgur.com/6ZA9UHR.png'),
        ('Channel 5', '/networks/135/channel-5', 'https://i.imgur.com/5ubnvOh.png'),
        ('Cinemax', '/networks/19/cinemax', 'https://i.imgur.com/zWypFNI.png'),
        ('Comedy Central', '/networks/23/comedy-central', 'https://i.imgur.com/ko6XN77.png'),
        ('Crackle', '/webchannels/4/crackle', 'https://i.imgur.com/53kqZSY.png'),
        ('Discovery Channel', '/networks/66/discovery-channel', 'https://i.imgur.com/8UrXnAB.png'),
        ('Discovery ID', '/networks/89/investigation-discovery', 'https://i.imgur.com/07w7BER.png'),
        ('Disney Channel', '/networks/78/disney-channel', 'https://i.imgur.com/ZCgEkp6.png'),
        ('Disney XD', '/networks/25/disney-xd', 'https://i.imgur.com/PAJJoqQ.png'),
        ('E! Entertainment', '/networks/43/e', 'https://i.imgur.com/3Delf9f.png'),
        ('E4', '/networks/41/e4', 'https://i.imgur.com/frpunK8.png'),
        ('FOX', '/networks/4/fox', 'https://i.imgur.com/6vc0Iov.png'),
        ('FX', '/networks/13/fx', 'https://i.imgur.com/aQc1AIZ.png'),
        ('Freeform', '/networks/26/freeform', 'https://i.imgur.com/f9AqoHE.png'),
        ('HBO', '/networks/8/hbo', 'https://i.imgur.com/Hyu8ZGq.png'),
        ('HGTV', '/networks/192/hgtv', 'https://i.imgur.com/INnmgLT.png'),
        ('Hallmark', '/networks/50/hallmark-channel', 'https://i.imgur.com/zXS64I8.png'),
        ('History Channel', '/networks/53/history', 'https://i.imgur.com/LEMgy6n.png'),
        ('ITV', '/networks/35/itv', 'https://i.imgur.com/5Hxp5eA.png'),
        ('Lifetime', '/networks/18/lifetime', 'https://i.imgur.com/tvYbhen.png'),
        ('MTV', '/networks/22/mtv', 'https://i.imgur.com/QM6DpNW.png'),
        ('NBC', '/networks/1/nbc', 'https://i.imgur.com/yPRirQZ.png'),
        ('National Geographic', '/networks/42/national-geographic-channel', 'https://i.imgur.com/XCGNKVQ.png'),
        ('Netflix', '/webchannels/1/netflix', 'https://i.imgur.com/jI5c3bw.png'),
        ('Nickelodeon', '/networks/27/nickelodeon', 'https://i.imgur.com/OUVoqYc.png'),
        ('PBS', '/networks/85/pbs', 'https://i.imgur.com/r9qeDJY.png'),
        ('Showtime', '/networks/9/showtime', 'https://i.imgur.com/SawAYkO.png'),
        ('Sky1', '/networks/63/sky-1', 'https://i.imgur.com/xbgzhPU.png'),
        ('Starz', '/networks/17/starz', 'https://i.imgur.com/Z0ep2Ru.png'),
        ('Sundance', '/networks/33/sundance-tv', 'https://i.imgur.com/qldG5p2.png'),
        ('Syfy', '/networks/16/syfy', 'https://i.imgur.com/9yCq37i.png'),
        ('TBS', '/networks/32/tbs', 'https://i.imgur.com/RVCtt4Z.png'),
        ('TLC', '/networks/80/tlc', 'https://i.imgur.com/c24MxaB.png'),
        ('TNT', '/networks/14/tnt', 'https://i.imgur.com/WnzpAGj.png'),
        ('TV Land', '/networks/57/tvland', 'https://i.imgur.com/1nIeDA5.png'),
        ('Travel Channel', '/networks/82/travel-channel', 'https://i.imgur.com/mWXv7SF.png'),
        ('TruTV', '/networks/84/trutv', 'https://i.imgur.com/HnB3zfc.png'),
        ('USA', '/networks/30/usa-network', 'https://i.imgur.com/Doccw9E.png'),
        ('VH1', '/networks/55/vh1', 'https://i.imgur.com/IUtHYzA.png'),
        ('WGN', '/networks/28/wgn-america', 'https://i.imgur.com/TL6MzgO.png')
        ]

        for i in networks: self.list.append({'name': i[0], 'url': self.tvmaze_link + i[1], 'image': i[2], 'action': 'tvshows'})
        self.addDirectory(self.list)
        return self.list

    def languages(self):
        languages = [
            ('Arabic', 'ar'),
            ('Bosnian', 'bs'),
            ('Bulgarian', 'bg'),
            ('Chinese', 'zh'),
            ('Croatian', 'hr'),
            ('Dutch', 'nl'),
            ('English', 'en'),
            ('Finnish', 'fi'),
            ('French', 'fr'),
            ('German', 'de'),
            ('Greek', 'el'),
            ('Hebrew', 'he'),
            ('Hindi ', 'hi'),
            ('Hungarian', 'hu'),
            ('Icelandic', 'is'),
            ('Italian', 'it'),
            ('Japanese', 'ja'),
            ('Korean', 'ko'),
            ('Macedonian', 'mk'),
            ('Norwegian', 'no'),
            ('Persian', 'fa'),
            ('Polish', 'pl'),
            ('Portuguese', 'pt'),
            ('Punjabi', 'pa'),
            ('Romanian', 'ro'),
            ('Russian', 'ru'),
            ('Serbian', 'sr'),
            ('Slovenian', 'sl'),
            ('Spanish', 'es'),
            ('Swedish', 'sv'),
            ('Turkish', 'tr'),
            ('Ukrainian', 'uk')
        ]

        for i in languages: self.list.append({'name': str(i[0]), 'url': self.language_link % i[1], 'image': 'languages.png', 'action': 'tvshows'})
        self.addDirectory(self.list)
        return self.list

    def certifications(self):
        certificates = ['TV-G', 'TV-PG', 'TV-14', 'TV-MA']

        for i in certificates: self.list.append({'name': str(i), 'url': self.certification_link % str(i).replace('-', '_').lower(), 'image': 'certificates.png', 'action': 'tvshows'})
        self.addDirectory(self.list)
        return self.list

    def persons(self, url):
        Log(control.myName(__name__))

        if url == None:
            Log('1')
            self.list = cache.get(self.imdb_person_list, 24, self.personlist_link)
        else:
            self.list = cache.get(self.imdb_person_list, 1, url)

        for i in range(0, len(self.list)): self.list[i].update({'action': 'tvshows'})

##        LogR(self.list)
        self.addDirectory(self.list)
        navigator.navigator().endDirectory()
        return self.list
    
    def userlists(self):
        Log(control.myName(__name__))

        try:
            userlists = []
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            activity = trakt.getActivity()
        except:
            pass

        try:
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlists_link, self.trakt_user): raise Exception()
                userlists += cache.get(self.trakt_user_list, 720, self.traktlists_link, self.trakt_user)
            except:
                userlists += cache.get(self.trakt_user_list, 0, self.traktlists_link, self.trakt_user)
        except:
            pass
        try:
            self.list = []
            if self.imdb_user == '': raise Exception()
            userlists += cache.get(self.imdb_user_list, 0, self.imdblists_link)
        except:
            pass
        try:
            self.list = []
            if trakt.getTraktCredentialsInfo() == False: raise Exception()
            try:
                if activity > cache.timeout(self.trakt_user_list, self.traktlikedlists_link, self.trakt_user): raise Exception()
                userlists += cache.get(self.trakt_user_list, 720, self.traktlikedlists_link, self.trakt_user)
            except:
                userlists += cache.get(self.trakt_user_list, 0, self.traktlikedlists_link, self.trakt_user)
        except:
            pass

        self.list = userlists
        for i in range(0, len(self.list)): self.list[i].update({'image': 'userlists.png', 'action': 'tvshows'})
        self.addDirectory(self.list)
        return self.list

    def trakt_list(self, url, user):
        Log(control.myName(__name__))

        try:
            dupes = []

            q = dict(urlparse.parse_qsl(urlparse.urlsplit(url).query))
            q.update({'extended': 'full'})
            q = (urlencode(q)).replace('%2C', ',')
            u = url.replace('?' + urlparse.urlparse(url).query, '') + '?' + q

            result = trakt.getTraktAsJson(u)
            
            items = []
            for i in result:
                try: items.append(i['show'])
                except: pass

            if len(items) == 0:
                items = result
        except:
            traceback.print_exc()
            return

        try:
            q = dict(urlparse.parse_qsl(urlparse.urlsplit(url).query))
            if not int(q['limit']) == len(items): raise Exception()
            q.update({'page': str(int(q['page']) + 1)})
            q = (urlencode(q)).replace('%2C', ',')
            next = url.replace('?' + urlparse.urlparse(url).query, '') + '?' + q
            if C.PY2: next = next.encode('utf-8')
        except:
            traceback.print_exc()
            next = ''

        for item in items:

            try:
                title = item['title']
                title = re.sub(r'\s(|[(])(UK|US|AU|\d{4})(|[)])$', '', title)
                title = client.replaceHTMLCodes(title)

                try:
                    year = item['year']
                    year = re.sub(r'[^0-9]', '', str(year))
                    if int(year) > int((self.datetime).strftime('%Y')):
                        year = int((self.datetime).strftime('%Y'))
                except:
                    traceback.print_exc()
                    Log(repr(item))
                
                try:
                    imdb = item['ids']['imdb']
                except:
                    imdb = ''
                    
                if imdb == None or imdb == '': imdb = '0'
                else: imdb = 'tt' + re.sub(r'[^0-9]', '', str(imdb))

                try:
                    tvdb = item['ids']['tvdb']
                    tvdb = re.sub(r'[^0-9]', '', str(tvdb))
                except:
                    tvdb = '0' #no more tvdb
                    raise Exception()
                    

                tmdb = item['ids']['tmdb']
                if tmdb in [None,''] or (tmdb in dupes):
                    Log('tmdb issue ' + repr(item))
                    continue
                dupes.append(tmdb)

                try: premiered = item['first_aired']
                except: premiered = '0'
                try: premiered = re.compile(r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
                except: premiered = '0'

                try: studio = item['network']
                except: studio = '0'
                if studio == None: studio = '0'

                try: genre = item['genres']
                except: genre = '0'
                genre = [i.title() for i in genre]
                if genre == []: genre = '0'
                genre = ' / '.join(genre)

                try: duration = str(item['runtime'])
                except: duration = '0'
                if duration == None: duration = '0'

                try: rating = str(item['rating'])
                except: rating = '0'
                if rating == None or rating == '0.0': rating = '0'

                try: votes = str(item['votes'])
                except: votes = '0'
                try: votes = str(format(int(votes),',d'))
                except: pass
                if votes == None: votes = '0'

                try: mpaa = item['certification']
                except: mpaa = '0'
                if mpaa == None: mpaa = '0'

                try: plot = item['overview']
                except: plot = '0'
                if plot == None: plot = '0'
                plot = client.replaceHTMLCodes(plot)

                i =    {  'title': title
                          , 'originaltitle': title
                          , 'year': year
                          , 'premiered': premiered
                          , 'studio': studio
                          , 'genre': genre
                          , 'duration': duration
                          , 'rating': rating
                          , 'votes': votes
                          , 'mpaa': mpaa
                          , 'plot': plot
                          , 'imdb': imdb
                          , 'tmdb': tmdb
                          , 'tvdb': tvdb
                          , 'poster': '0'
                          , 'next': next
                          }
##                if C.PY3: item['tmdb']=tmdb
##                if C.PY3: item['first_air_date_year']=first_air_date_year
            
                self.list.append(i)
            except:
                LogR(item)                
                traceback.print_exc()
##                continue
##                raise

        return self.list

    def trakt_user_list(self, url, user):
        try:
            items = trakt.getTraktAsJson(url)
        except:
            pass

        for item in items:
            try:
                try: name = item['list']['name']
                except: name = item['name']
                name = client.replaceHTMLCodes(name)

                try: url = (trakt.slug(item['list']['user']['username']), item['list']['ids']['slug'])
                except: url = ('me', item['ids']['slug'])
                url = self.traktlist_link % url
                url = url.encode('utf-8')

                self.list.append({'name': name, 'url': url, 'context': url})
            except:
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k['name']))
        return self.list

    def imdb_list(self, url):
        Log(control.myName(__name__))        

        try:
            dupes = []
            for i in re.findall(r'date\[(\d+)\]', url):
                url = url.replace('date[%s]' % i, (self.datetime - datetime.timedelta(days = int(i))).strftime('%Y-%m-%d'))
            def imdb_watchlist_id(url):
                return client.parseDOM(client.request(url), 'meta', ret='content', attrs = {'property': 'pageId'})[0]
            if url == self.imdbwatchlist_link:
                url = cache.get(imdb_watchlist_id, 8640, url)
                url = self.imdblist_link % url
            elif url == self.imdbwatchlist2_link:
                url = cache.get(imdb_watchlist_id, 8640, url)
                url = self.imdblist2_link % url
            Log(url,C.LOGWARNING)
            result = client.request(url)
            result = result.replace('\n', ' ')
            items = client.parseDOM(result, 'li', attrs = {'class': 'ipc-metadata-list-summary-item'})

        except:
            traceback.print_exc()
            return

        Log('ister-page-ne')
        try:
            next_ = client.parseDOM(result, 'a', ret='href', attrs = {'class': '.+?ister-page-nex.+?'})

            if len(next_) == 0:
                next_ = client.parseDOM(result, 'div', attrs = {'class': 'pagination'})[0]
                next_ = zip(client.parseDOM(next_, 'a', ret='href'), client.parseDOM(next_, 'a'))
                next_ = [i[0] for i in next_ if 'Next' in i[1]]

            next_ = url.replace(urlparse.urlparse(url).query, urlparse.urlparse(next[0]).query)
            next_ = client.replaceHTMLCodes(next_)
            next_ = next_.encode('utf-8')
        except:
            next_ = ''

        for item in items:
            try:
                title = client.parseDOM(item, 'h3', attrs = {'class': 'ipc-title__text'})[0]
                try: title = re.findall(r'\d+?\.\s*(.*)', title)[0] #
                except: pass
                if C.PY2: title = title.encode('utf-8')

                year = client.parseDOM(item, 'span', attrs = {'class': '.+?dli-title-metadata-item'})
                year = re.findall(r'(\d{4})', year[0])[0]
                if C.PY2: year = year.encode('utf-8')

                if int(year) > int((self.datetime).strftime('%Y')): raise Exception()

                imdb = client.parseDOM(item, 'a', ret='href')[0]
                imdb = re.findall(r'(tt\d*)', imdb)[0]
                if C.PY2: imdb = imdb.encode('utf-8')

            
                if imdb in dupes: raise Exception()
                dupes.append(imdb)

                try: poster = client.parseDOM(item, 'img', ret='src')[0]
                except: poster = '0'
                if '/nopicture/' in poster: poster = '0'
                poster = client.replaceHTMLCodes(poster)
                if C.PY2: poster = poster.encode('utf-8')

            
                rating = '0'
                try: rating = client.parseDOM(item, 'span', attrs = {'class': 'ipc-rating-star--rating'})[0]
                except: pass
                if rating == '' or rating == '-': rating = '0'
                rating = client.replaceHTMLCodes(rating)
                if C.PY2: rating = rating.encode('utf-8')


            
                plot = '0'
                try: plot = client.parseDOM(item, 'div', attrs = {'class': 'ipc-html-content-inner-div'})[0]
                except: pass
                plot = re.sub(r'<.+?>|</.+?>', '', plot)
                if plot == '': plot = '0'
                plot = client.replaceHTMLCodes(plot)
                if C.PY2: plot = plot.encode('utf-8')

                self.list.append(
                    {
                        'title': title
                        , 'originaltitle': title
                        , 'year': year
                        , 'rating': rating
                        , 'plot': plot
                        , 'imdb': imdb
                        , 'tmdb': '0' #imdb does not provide this
                        , 'tvdb': '0' #imdb does not provide this
                        , 'poster': poster
                        , 'next': next_
                    }
                    )
            except:
                traceback.print_exc()
##                self.list = None
                pass
            
        return self.list

    def imdb_person_list(self, url):
        try:
            result = client.request(url)
            items = client.parseDOM(result, 'li', attrs = {'class': 'ipc-metadata-list-summary-item'})
        except:
            raise
            return

    
        for item in items:
            try:
                name = client.parseDOM(item, 'img', ret='alt' )[0]
                name = client.replaceHTMLCodes(name)
                if C.PY2: name = name.encode('utf-8')

                url = client.parseDOM(item, 'a', ret='href')[0]
                url = re.findall(r'(nm\d*)', url, re.I)[0]
                url = self.person_link % url
                url = client.replaceHTMLCodes(url)
                if C.PY2: url = url.encode('utf-8')

                image = client.parseDOM(item, 'img', ret='src')[0]
##                if not ('._SX' in image or '._SY' in image): raise Exception()
##                image = re.sub('(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', image)
                image = client.replaceHTMLCodes(image)
                if C.PY2: image = image.encode('utf-8')

                person = {
                    'name': name
                    , 'url': url
                    , 'image': image
                    }
                self.list.append(person)
                
            except:
##                raise
                pass

        LogR(self.list)
        return self.list


    def imdb_user_list(self, url):
        Log(control.myName(__name__))
        try:
            result = client.request(url)
            items = client.parseDOM(result, 'li', attrs = {'class': 'ipl-zebra-list__item user-list'})
        except:
            pass

        for item in items:
            try:
                name = client.parseDOM(item, 'a')[0]
                name = client.replaceHTMLCodes(name)
                name = name.encode('utf-8')

                url = client.parseDOM(item, 'a', ret='href')[0]
                url = url = url.split('/list/', 1)[-1].strip('/')
                url = self.imdblist_link % url
                url = client.replaceHTMLCodes(url)
                if C.PY2: url = url.encode('utf-8')

                self.list.append({
                      'name': name
                    , 'url': url
                    , 'context': url
                    })
            except:
                pass

        self.list = sorted(self.list, key=lambda k: utils.title_key(k['name']))
        return self.list

    def tvmaze_list(self, url):
        Log(control.myName(__name__))
        try:
            result = client.request(url)
            result = client.parseDOM(result, 'section', attrs = {'id': 'this-seasons-shows'})

            items = client.parseDOM(result, 'div', attrs = {'class': 'content auto cell'})
            items = [client.parseDOM(i, 'a', ret='href') for i in items]
            items = [i[0] for i in items if len(i) > 0]
            items = [re.findall(r'/(\d+)/', i) for i in items]
            items = [i[0] for i in items if len(i) > 0]
            items = items[:50]
        except:
            return

        def items_list(i):
            try:
                url = self.tvmaze_info_link % i

                item = client.request(url)
                item = json.loads(item)

                title = item['name']
                title = re.sub(r'\s(|[(])(UK|US|AU|\d{4})(|[)])$', '', title)
                title = client.replaceHTMLCodes(title)
                if C.PY2: title = title.encode('utf-8')

                year = item['premiered']
                year = re.findall(r'(\d{4})', year)[0]
                if C.PY2: year = year.encode('utf-8')

                first_air_date_year = year
                
                if int(year) > int((self.datetime).strftime('%Y')): raise Exception('year in the future?')

                imdb = item['externals']['imdb']
                if imdb == None or imdb == '': imdb = '0'
                else: imdb = 'tt' + re.sub(r'[^0-9]', '', str(imdb))
                if C.PY2: imdb = imdb.encode('utf-8')

                tvdb = item['externals']['thetvdb']
                tvdb = re.sub(r'[^0-9]', '', str(tvdb))
                if C.PY2: tvdb = tvdb.encode('utf-8')
                if tvdb == None or tvdb == '':
                    raise KeyError('missing thetvdb')
                
                try:
                    tmdb = item['externals']['thetmdb']
                    if C.PY2: tmdb = tmdb.encode('utf-8')
                except: tmdb = '0'

                try: poster = item['image']['original']
                except: poster = '0'
                if poster == None or poster == '': poster = '0'
                if C.PY2: poster = poster.encode('utf-8')

                premiered = item['premiered']
                try: premiered = re.findall(r'(\d{4}-\d{2}-\d{2})', premiered)[0]
                except: premiered = '0'
                if C.PY2: premiered = premiered.encode('utf-8')

                try: studio = item['network']['name']
                except: studio = '0'
                if studio == None: studio = '0'
                if C.PY2: studio = studio.encode('utf-8')

                try: genre = item['genres']
                except: genre = '0'
                genre = [i.title() for i in genre]
                if genre == []: genre = '0'
                genre = ' / '.join(genre)
                if C.PY2: genre = genre.encode('utf-8')

                try: duration = item['runtime']
                except: duration = '0'
                if duration == None: duration = '0'
                duration = str(duration)
                if C.PY2: duration = duration.encode('utf-8')

                try: rating = item['rating']['average']
                except: rating = '0'
                if rating == None or rating == '0.0': rating = '0'
                rating = str(rating)
                if C.PY2: rating = rating.encode('utf-8')

                try: plot = item['summary']
                except: plot = '0'
                if plot == None: plot = '0'
                plot = re.sub(r'<.+?>|</.+?>|\n', '', plot)
                plot = client.replaceHTMLCodes(plot)
                if C.PY2: plot = plot.encode('utf-8')

                try: content = item['type'].lower()
                except: content = '0'
                if content == None or content == '': content = '0'
                if C.PY2: content = content.encode('utf-8')

                item = {'title': title
                        , 'originaltitle': title
                        , 'tvshowtitle': title  
                        , 'year': year
                        , 'premiered': premiered
                        , 'studio': studio
                        , 'genre': genre
                        , 'duration': duration
                        , 'rating': rating
                        , 'plot': plot
                        , 'imdb': imdb
                        , 'tmdb': tmdb
                        , 'tvdb': tvdb
                        , 'poster': poster
                        , 'content': content
                          }
##                if C.PY3: item['tmdb']=tmdb
##            if C.PY3: item['first_air_date_year']=first_air_date_year
            
                self.list.append(item)
            except:
                LogR(item)
                raise
                pass

        try:
            threads = []
            for i in items: threads.append(workers.Thread(items_list, i))
            [i.start() for i in threads]
            [i.join() for i in threads]

            filter = [i for i in self.list if i['content'] == 'scripted']
            filter += [i for i in self.list if not i['content'] == 'scripted']
            self.list = filter

            return self.list
        except:
            return


    def super_info(self, i):
        Log(control.myName(__name__))

        try:
            if i >= len(self.list):
                return

            if 'metacache' in self.list[i]:
                if self.list[i]['metacache'] == True:
                    raise IndexError(repr(self.list[i]))

            imdb = self.list[i]['imdb']   if 'imdb'   in self.list[i] else '0'
            tmdb = self.list[i]['tmdb']   if 'tmdb'   in self.list[i] else '0'
            tmdb = self.list[i]['tvrage'] if 'tvrage' in self.list[i] else '0'
            tvdb = self.list[i]['tvdb']   if 'tvdb'   in self.list[i] else '0'



            if imdb == '0':
                try:
                    t_show = trakt.SearchTVShow(quote_plus(self.list[i]['title']), self.list[i]['year'], full=False)
                    for t in t_show:
                        if str(t['show']['year']) == str(self.list[i]['year']):
                            imdb = t
                            break
                    imdb = imdb.get('show', '0')
                    imdb = imdb.get('ids', {}).get('imdb', '0')
                    imdb = 'tt' + re.sub(r'[^0-9]', '', str(imdb))

                    if not imdb: imdb = '0'
                except:
                    imdb = '0'


            
            if tvdb == '0' and not imdb == '0':
                url = self.tvdb_by_imdb % imdb

                result = client.request(url, timeout='10')

                try: tvdb = client.parseDOM(result, 'seriesid')[0]
                except: tvdb = '0'

                try: name = client.parseDOM(result, 'SeriesName')[0]
                except: name = '0'
                dupe = re.findall(r'[***]Duplicate (\d*)[***]', name)
                if dupe: tvdb = str(dupe[0])

                if tvdb == '': tvdb = '0'

            if tvdb in ['0','']:

##GET https://api.trakt.tv//search/imdb/tt66732?type=show HTTP/1.1
##Host: api.trakt.tv
##User-Agent: python-requests/2.31.0
##Accept-Encoding: gzip, deflate
##Accept: */*
##Connection: keep-alive
##trakt-api-version: 2
##trakt-api-key: e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467
##Content-Type: application/json

                headers = {
                    'User-Agent': 'python-requests/2.31.0'
                    ,'Accept-Encoding': 'gzip, deflate'
                    ,'Accept': '*/*'
                    ,'Connection': 'keep-alive'
                    ,'trakt-api-version': '2'
                    ,'trakt-api-key': 'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467'
                    ,'Content-Type': 'application/json'
                    }
                url = 'https://api.trakt.tv/search/imdb/{}?type=show'.format(imdb)
                tvdb_json = client.request(url, headers=headers, timeout='10')
##                LogR(tvdb_json)
                tvdb = str(json.loads(tvdb_json)[0]['show']['ids']['tvdb'])
##                url = self.tvdb_by_query % (quote_plus(self.list[i]['title']))
##                years = [str(self.list[i]['year']), str(int(self.list[i]['year'])+1), str(int(self.list[i]['year'])-1)]
##                tvdb = client.request(url, timeout='10')
##                tvdb = re.sub(r'[^\x00-\x7F]+', '', tvdb)
##                tvdb = client.replaceHTMLCodes(tvdb)
##                tvdb = client.parseDOM(tvdb, 'Series')
##                tvdb = [(x, client.parseDOM(x, 'SeriesName'), client.parseDOM(x, 'FirstAired')) for x in tvdb]
##                tvdb = [(x, x[1][0], x[2][0]) for x in tvdb if len(x[1]) > 0 and len(x[2]) > 0]
##                tvdb = [x for x in tvdb if cleantitle.get(self.list[i]['title']) == cleantitle.get(x[1])]
##                try: 
##                    tvdb = [x[0][0] for x in tvdb if any(y in x[2] for y in years)][0]
##                    tvdb = client.parseDOM(tvdb, 'id')[0]
##                except:
##                    tvdb = "0"
##                    pass
                
                if not tvdb: tvdb = '0'

            INFO_TIMEOUT = '5' #seconds

##            Log("TRAKT has better i")
            # TRAKT has better info, but has a 1000query/hour limit without an account, but TVDB has art information
            # Do we do both? ...sacrifice accuracy for fewer network calls?
            url =  "{}/search/tvdb/{}?type=show&extended=full".format(self.trakt_link,tvdb)
            trakt_item = None
            if trakt_item: trakt_item = json.loads(trakt_item)[0]['show']
            url = self.tvdb_info_link % tvdb
            tvdb_item = client.request(url, timeout=INFO_TIMEOUT) 

            
            if tvdb_item == None:
                raise Exception('tvdb_item == None')

            if imdb == '0':
                if trakt_item:
                    try: imdb = trakt_item['ids']['imdb']
                    except: pass
                else:
                    try: imdb = client.parseDOM(tvdb_item, 'IMDB_ID')[0]
                    except: pass
                if imdb == '': imdb = '0'
                if C.PY2: imdb = imdb.encode('utf-8')

            if trakt_item:
                try: title = trakt_item['title']
                except: title = u''
            else:
                try: title = client.parseDOM(tvdb_item, 'SeriesName')[0]
                except: title = u''
            if not title: title = u'0'
            title = client.replaceHTMLCodes(title)
            if C.PY2: title = title.encode('utf-8')

            if trakt_item:
                try: year = str(trakt_item['year'])
                except: year = ''
            else:
                try: year = client.parseDOM(tvdb_item, 'FirstAired')[0]
                except: year = ''
                try: year = re.compile(r'(\d{4})').findall(year)[0]
                except: year = ''
            if year == '': year = '0'
            if C.PY2: year = year.encode('utf-8')

            if trakt_item:
                try: premiered = trakt_item['first_aired'][0:4]
                except: premiered = ''
            else:            
                try: premiered = client.parseDOM(tvdb_item, 'FirstAired')[0]
                except: premiered = '0'
            if premiered == '': premiered = '0'
            premiered = client.replaceHTMLCodes(premiered)
            if C.PY2: premiered = premiered.encode('utf-8')

            if trakt_item:
                try: studio = trakt_item['network']
                except: studio = ''
            else:
                try: studio = client.parseDOM(tvdb_item, 'Network')[0]
                except: studio = ''
            if studio == '': studio = '0'
            studio = client.replaceHTMLCodes(studio)
            if C.PY2: studio = studio.encode('utf-8')

            if trakt_item:
                try: genre = trakt_item['genres']
                except: genre = ''
            else:
                try: genre = client.parseDOM(tvdb_item, 'Genre')[0]
                except: genre = ''
                genre = [x for x in genre.split('|') if not x == '']
            genre = ' / '.join(genre)
            if genre == '': genre = '0'
            genre = client.replaceHTMLCodes(genre)
            if C.PY2: genre = genre.encode('utf-8')

            if trakt_item:
                try: duration = str(trakt_item['runtime'])
                except: duration = ''
            else:
                try: duration = client.parseDOM(tvdb_item, 'Runtime')[0]
                except: duration = ''
            if duration == '': duration = '0'
            duration = client.replaceHTMLCodes(duration)
            if C.PY2: duration = duration.encode('utf-8')

            if trakt_item:
                try: rating = str(trakt_item['rating'])
                except: rating = ''
            else:
                try: rating = client.parseDOM(tvdb_item, 'Rating')[0]
                except: rating = ''
            if 'rating' in self.list[i] and not self.list[i]['rating'] == '0':
                rating = self.list[i]['rating']
            if rating == '': rating = '0'
            try:    rating = client.replaceHTMLCodes(rating)
            except:
                LogR(rating,C.LOGERR0R)
                rating = '0'
            if C.PY2: rating = rating.encode('utf-8')

            if trakt_item:
                try: votes = str(trakt_item['votes'])
                except: votes = ''
            else:
                try: votes = client.parseDOM(tvdb_item, 'RatingCount')[0]
                except: votes = ''
            if 'votes' in self.list[i] and not self.list[i]['votes'] == '0':
                votes = self.list[i]['votes']
            if votes == '': votes = '0'
            votes = client.replaceHTMLCodes(votes)
            if C.PY2: votes = votes.encode('utf-8')

            if trakt_item:
                try: mpaa = trakt_item['certification']
                except: mpaa = ''
                if not mpaa: mpaa = '0'
            else:
                try: mpaa = client.parseDOM(tvdb_item, 'ContentRating')[0]
                except: mpaa = ''
                if mpaa == '': mpaa = '0'
                mpaa = client.replaceHTMLCodes(mpaa)
            if C.PY2: mpaa = mpaa.encode('utf-8')

            try: cast = client.parseDOM(tvdb_item, 'Actors')[0]
            except: cast = ''
            cast = [x for x in cast.split('|') if not x == '']
            if C.PY2:
                try: cast = [(x.encode('utf-8'), '') for x in cast]
                except: cast = []
            if cast == []: cast = '0'

            if trakt_item:
                try: plot = trakt_item['overview']
                except: plot = ''
            else:
                try: plot = client.parseDOM(tvdb_item, 'Overview')[0]
                except: plot = ''
            if plot == '': plot = '0'
            plot = client.replaceHTMLCodes(plot)
            if C.PY2: plot = plot.encode('utf-8')

            first_air_date_year = client.parseDOM(tvdb_item, 'FirstAired')[0]
            if first_air_date_year == '' or '-00' in first_air_date_year: first_air_date_year = '0'
            first_air_date_year = first_air_date_year[0:4]

            try: poster = client.parseDOM(tvdb_item, 'poster')[0]
            except: poster = ''
            if not poster == '': poster = self.tvdb_image + poster
            else: poster = '0'
            if 'poster' in self.list[i] and poster == '0': poster = self.list[i]['poster']
            poster = client.replaceHTMLCodes(poster)
            if C.PY2: poster = poster.encode('utf-8')

            try: banner = client.parseDOM(tvdb_item, 'banner')[0]
            except: banner = ''
            if not banner == '': banner = self.tvdb_image + banner
            else: banner = '0'
            banner = client.replaceHTMLCodes(banner)
            if C.PY2: banner = banner.encode('utf-8')

            try: fanart = client.parseDOM(tvdb_item, 'fanart')[0]
            except: fanart = ''
            if not fanart == '': fanart = self.tvdb_image + fanart
            else: fanart = '0'
            fanart = client.replaceHTMLCodes(fanart)
            if C.PY2: fanart = fanart.encode('utf-8')

            try:
                artmeta = True
                try: art = json.loads(art)
                except: artmeta = False
            except:
                pass

            try:
                poster2 = art['tvposter']
                poster2 = [x for x in poster2 if x.get('lang') == self.lang][::-1] + [x for x in poster2 if x.get('lang') == 'en'][::-1] + [x for x in poster2 if x.get('lang') in ['00', '']][::-1]
                if C.PY2: poster2 = poster2[0]['url'].encode('utf-8')
                else: poster2 = poster2[0]['url']
            except: poster2 = '0'

            try:
                fanart2 = art['showbackground']
                fanart2 = [x for x in fanart2 if x.get('lang') == self.lang][::-1] + [x for x in fanart2 if x.get('lang') == 'en'][::-1] + [x for x in fanart2 if x.get('lang') in ['00', '']][::-1]
                if C.PY2: fanart2 = fanart2[0]['url'].encode('utf-8')
                else: fanart2 = fanart2[0]['url']
            except: fanart2 = '0'

            try:
                banner2 = art['tvbanner']
                banner2 = [x for x in banner2 if x.get('lang') == self.lang][::-1] + [x for x in banner2 if x.get('lang') == 'en'][::-1] + [x for x in banner2 if x.get('lang') in ['00', '']][::-1]
                if C.PY2: banner2 = banner2[0]['url'].encode('utf-8')
                else: banner2 = banner2[0]['url']
            except: banner2 = '0'

            try:
                if 'hdtvlogo' in art: clearlogo = art['hdtvlogo']
                else: clearlogo = art['clearlogo']
                clearlogo = [x for x in clearlogo if x.get('lang') == self.lang][::-1] + [x for x in clearlogo if x.get('lang') == 'en'][::-1] + [x for x in clearlogo if x.get('lang') in ['00', '']][::-1]
                if C.PY2: clearlogo = clearlogo[0]['url'].encode('utf-8')
                else: clearlogo = clearlogo[0]['url']
            except: clearlogo = '0'

            try:
                if 'hdclearart' in art: clearart = art['hdclearart']
                else: clearart = art['clearart']
                clearart = [x for x in clearart if x.get('lang') == self.lang][::-1] + [x for x in clearart if x.get('lang') == 'en'][::-1] + [x for x in clearart if x.get('lang') in ['00', '']][::-1]
                if C.PY2: clearart = clearart[0]['url'].encode('utf-8')
                else: clearart = clearart[0]['url']
            except: clearart = '0'

            item = {      'title': title
                        , 'tvshowtitle': title
                        , 'year': year
                        , 'imdb': imdb
                        , 'tvdb': tvdb
                        , 'tmdb': tmdb
                        , 'poster': poster
                        , 'poster2': poster2
                        , 'banner': banner
                        , 'banner2': banner2
                        , 'fanart': fanart
                        , 'fanart2': fanart2
                        , 'clearlogo': clearlogo
                        , 'clearart': clearart
                        , 'premiered': premiered
                        , 'studio': studio
                        , 'genre': genre
                        , 'duration': duration
                        , 'rating': rating
                        , 'votes': votes
                        , 'mpaa': mpaa
                        , 'cast': cast
                        , 'plot': plot
                        #, 'first_air_date_year': first_air_date_year
                        }
            if C.PY3: item['first_air_date_year']=first_air_date_year
            if C.PY2:
                item = dict((k,v) for k, v in item.iteritems() if not v == '0')
            else:
                item = dict((k,v) for k, v in item.items() if not v == '0')
            self.list[i].update(item)

            meta = {'imdb': imdb
                    , 'tmdb': tmdb
                    , 'tvdb': tvdb
                    , 'lang': self.lang
                    , 'user': self.user
                    , 'item': item
                    , 'cast': cast
                    }
            if C.PY3: item['tmdb']=tmdb

            self.meta.append(meta)
        except IndexError:
            raise
            pass
        except:
            traceback.print_exc()
            pass


    def worker(self, level=1):
        Log(control.myName(__name__))
        
        self.meta = []

        if self.list:
            total = len(self.list)
        else:
            return
            total = 0

        #self.fanart_tv_headers = {'api-key': 'ZDY5NTRkYTk2Yzg4ODFlMzdjY2RkMmQyNTlmYjk1MzQ='.decode('base64')}
        self.fanart_tv_headers = {'api-key': self.fanart_tv_api}
        if not self.fanart_tv_user == '':
            self.fanart_tv_headers.update({'client-key': self.fanart_tv_user})

        for i in range(0, total):
            self.list[i].update({'metacache': False})

        self.list = metacache.fetch(self.list, self.lang, self.user)

        for r in range(0, total, 40):
            threads = []
            for i in range(r, r+40):
                if i <= total:
                    threads.append(
                        workers.Thread(
                             self.super_info
                            ,i
                            )
                        )
            [i.start() for i in threads]
            [i.join() for i in threads]

            if self.meta:
                Log('meta insert')
                metacache.insert(self.meta)
                LogR(self.meta)

        self.list = [i for i in self.list if not i['tvdb'] == '0']

        if self.fanart_tv_user == '':
            for i in self.list:
                i.update({'clearlogo': '0', 'clearart': '0'})

    def tvshowDirectory(self, items):
        Log(control.myName(__name__))
        try:
            if items == None or len(items) == 0:
                control.idle()
                raise SystemExit()
                #sys.exit()

            sysaddon = sys.argv[0]
            syshandle = int(sys.argv[1])

            addonPoster, addonBanner = control.addonPoster(), control.addonBanner()

            addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')

            traktCredentials = trakt.getTraktCredentialsInfo()

            try: isOld = False ; control.item().getArt('type')
            except: isOld = True

            indicators = playcount.getTVShowIndicators(refresh=True) if action == 'tvshows' else playcount.getTVShowIndicators()

            flatten = True if control.setting('flatten.tvshows') == 'true' else False

            watchedMenu = control.lang(32068).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32066).encode('utf-8')

            unwatchedMenu = control.lang(32069).encode('utf-8') if trakt.getTraktIndicatorsInfo() == True else control.lang(32067).encode('utf-8')

            queueMenu = control.lang(32065).encode('utf-8')

            traktManagerMenu = control.lang(32070).encode('utf-8')

            nextMenu = control.lang(32053).encode('utf-8')

            playRandom = control.lang(32535).encode('utf-8')

            addToLibrary = control.lang(32551).encode('utf-8')


            for i in items:
                try:
                    label = i['title']
                    systitle = sysname = quote_plus(i['originaltitle'])
                    sysimage = quote_plus(i['poster'])
                    imdb, tvdb, year, tmdb = i['imdb'], i['tvdb'], i['year'], i['tmdb']

                    if C.PY2:
                        meta = dict((k,v) for k, v in i.iteritems() if not v == '0')
                    else:
                        meta = dict((k,v) for k, v in i.items() if not v == '0')
                    meta.update({'code': imdb, 'imdbnumber': imdb, 'imdb_id': imdb})
                    meta.update({'tvdb_id': tvdb})
                    meta.update({'mediatype': 'tvshow'})
                    #meta.update({'tvshowtitle': systitle})
                    meta.update({'trailer': '%s?action=trailer&name=%s' % (sysaddon, quote_plus(label))})
                    if not 'duration' in i: meta.update({'duration': '60'})
                    elif i['duration'] == '0': meta.update({'duration': '60'})
                    try: meta.update({'duration': str(int(meta['duration']) * 60)})
                    except: pass
                    try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
                    except: pass

                    try:
                        overlay = int(playcount.getTVShowOverlay(indicators, tvdb))
                        if overlay == 7: meta.update({'playcount': 1, 'overlay': 7})
                        else: meta.update({'playcount': 0, 'overlay': 6})
                    except:
                        pass

                    if flatten == True:
                        url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s' % (sysaddon, systitle, year, imdb, tvdb)
                    else:
                        url = '%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s' % (sysaddon, systitle, year, imdb, tvdb)


                    cm = []

                    cm.append(('Find similar',
                               'ActivateWindow(10025,%s?action=tvshows&url=https://api.trakt.tv/shows/%s/related,return)' % (
                               sysaddon, imdb)))

                    cm.append((playRandom, 'RunPlugin(%s?action=random&rtype=season&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s)' % (sysaddon, quote_plus(systitle), quote_plus(year), quote_plus(imdb), quote_plus(tvdb))))

                    cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                    cm.append((watchedMenu, 'RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tvdb=%s&query=7)' % (sysaddon, systitle, imdb, tvdb)))

                    cm.append((unwatchedMenu, 'RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tvdb=%s&query=6)' % (sysaddon, systitle, imdb, tvdb)))

                    if traktCredentials == True:
                        cm.append((traktManagerMenu, 'RunPlugin(%s?action=traktManager&name=%s&tvdb=%s&content=tvshow)' % (sysaddon, sysname, tvdb)))

                    if isOld == True:
                        cm.append((control.lang2(19033).encode('utf-8'), 'Action(Info)'))

                    cm.append((addToLibrary, 'RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tvdb=%s)' % (sysaddon, systitle, year, imdb, tvdb)))

                    cm.append(('Exodus Redux Settings', 'RunPlugin(%s?action=openSettings&query=(0,0))' % sysaddon))

                    item = control.item(label=label)
                    item.setContentLookup(False) #prevent HEAD requests

                    art = {}

                    if 'poster' in i and not i['poster'] == '0':
                        art.update({'icon': i['poster'], 'thumb': i['poster'], 'poster': i['poster']})
                    #elif 'poster2' in i and not i['poster2'] == '0':
                        #art.update({'icon': i['poster2'], 'thumb': i['poster2'], 'poster': i['poster2']})
                    else:
                        art.update({'icon': addonPoster, 'thumb': addonPoster, 'poster': addonPoster})

                    if 'banner' in i and not i['banner'] == '0':
                        art.update({'banner': i['banner']})
                    #elif 'banner2' in i and not i['banner2'] == '0':
                        #art.update({'banner': i['banner2']})
                    elif 'fanart' in i and not i['fanart'] == '0':
                        art.update({'banner': i['fanart']})
                    else:
                        art.update({'banner': addonBanner})

                    if 'clearlogo' in i and not i['clearlogo'] == '0':
                        art.update({'clearlogo': i['clearlogo']})

                    if 'clearart' in i and not i['clearart'] == '0':
                        art.update({'clearart': i['clearart']})

                    if settingFanart == 'true' and 'fanart' in i and not i['fanart'] == '0':
                        item.setProperty('Fanart_Image', i['fanart'])
                    #elif settingFanart == 'true' and 'fanart2' in i and not i['fanart2'] == '0':
                        #item.setProperty('Fanart_Image', i['fanart2'])
                    elif not addonFanart == None:
                        item.setProperty('Fanart_Image', addonFanart)

                    item.setArt(art)
                    item.addContextMenuItems(cm)

                    if C.PY2:
                        max_loops = 1000
                        loop_count = 0
                        was_changed = True
                        while (was_changed == True)  and  (loop_count < max_loops) :
                            loop_count = loop_count + 1
                            was_changed = False
                            for a in meta:
                                if a == 'imdb':
                                    was_changed = True
                                    meta['imdbnumber'] = meta[a]
                                    meta.pop(a)
                                    break
                                if a in C.bad_attributes:
                                    was_changed = True
                                    meta.pop(a)
                                    break

                        if 'tmdb' in meta:
                            meta.pop('tmdb')
                        item.setInfo(type='Video', infoLabels = meta)
                        video_streaminfo = {'codec': 'h264'}
                        item.addStreamInfo('video', video_streaminfo)
                    else:
                        videoInfoTag = item.getVideoInfoTag()
##                        vsd = xbmc.VideoStreamDetail()
##                        vsd.setCodec('h264')
##                        videoInfoTag.addVideoStream(vsd) #probably not needed
                        for a in meta:
##                            Log(repr((a,meta[a])))
                            if a == "tvshowtitle": videoInfoTag.setTvShowTitle(meta[a])
                            if a == "title": videoInfoTag.setTitle(meta[a])
                            if a == "originaltitle": videoInfoTag.setOriginalTitle(meta[a])
                            if a == "first_air_date_year": videoInfoTag.setYear(int(meta[a]))
                            if a == "premiered": videoInfoTag.setPremiered(meta[a])
                            if a == "duration": videoInfoTag.setDuration(int(meta[a]))
                            if a == "rating": videoInfoTag.setRating(float(meta[a]))
                            if a == "mpaa": videoInfoTag.setMpaa(meta[a])
                            if a == "plot": videoInfoTag.setPlot(meta[a])
                            if a == "tagline": videoInfoTag.setTagLine(meta[a])
                            if a == "code": videoInfoTag.setProductionCode(meta[a])
                            if a == "imdbnumber": videoInfoTag.setIMDBNumber(meta[a])
                            if a == "mediatype": videoInfoTag.setMediaType(meta[a])
                            if a == "dateadded": videoInfoTag.setDateAdded(meta[a])
                            if a == "playcount": videoInfoTag.setPlaycount(meta[a])
                            if a == "cast":
                                actors = [xbmc.Actor(name=actor) for actor in meta[a]]
                                videoInfoTag.setCast(actors)

                    item.setMimeType('video/mp4') #prevent HEAD requests

                    control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                except:
                    LogR(i)
                    traceback.print_exc()

            try:
                url = items[0]['next']
                if url == '': raise Exception()

                icon = control.addonNext()
                url = '%s?action=tvshowPage&url=%s' % (sysaddon, quote_plus(url))

                item = control.item(label=nextMenu)
                item.setContentLookup(False) #prevent HEAD requests

                item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'banner': icon})
                if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)

                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
            except:
                LogR('toddeal with next')
##                traceback.print_exc()
                pass

        except SystemExit:
            syshandle = int(sys.argv[1])
            item = control.item(label='No more items')
            control.addItem(handle=syshandle, url='', listitem=item, isFolder=False)
        except:
            traceback.print_exc()
            pass
        finally:
            control.content(syshandle, 'tvshows')
            control.directory(syshandle, cacheToDisc=True)
            views.setView('tvshows', {'skin.estuary': 55, 'skin.confluence': 500})

        
    def addDirectory(self, items, queue=False):
        Log(__name__); LogR(locals())
        syshandle = int(sys.argv[1])
        try:        
            if items == None or len(items) == 0: control.idle() ; sys.exit()

            sysaddon = sys.argv[0]

            addonFanart, addonThumb, artPath = control.addonFanart(), control.addonThumb(), control.artPath()

            queueMenu = control.lang(32065).encode('utf-8')

            playRandom = control.lang(32535).encode('utf-8')

            addToLibrary = control.lang(32551).encode('utf-8')

            for i in items:
                try:
                    name = i['name']

                    if i['image'].startswith('http'): thumb = i['image']
                    elif not artPath == None: thumb = os.path.join(artPath, i['image'])
                    else: thumb = addonThumb

                    url = '%s?action=%s' % (sysaddon, i['action'])
                    try: url += '&url=%s' % quote_plus(i['url'])
                    except: pass

                    cm = []

                    cm.append((playRandom, 'RunPlugin(%s?action=random&rtype=show&url=%s)' % (sysaddon, quote_plus(i['url']))))

                    if queue == True:
                        cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                    try: cm.append((addToLibrary, 'RunPlugin(%s?action=tvshowsToLibrary&url=%s)' % (sysaddon, quote_plus(i['context']))))
                    except: pass

                    item = control.item(label=name)
                    item.setArt({'icon': thumb, 'thumb': thumb})
                    if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)
                    item.addContextMenuItems(cm)

                    item.setMimeType('video/mp4') #prevent HEAD requests
                    item.setContentLookup(False) #prevent HEAD requests
                    control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                except:
                    pass
        finally:
            control.content(syshandle, 'addons')
            control.directory(syshandle, cacheToDisc=True)
