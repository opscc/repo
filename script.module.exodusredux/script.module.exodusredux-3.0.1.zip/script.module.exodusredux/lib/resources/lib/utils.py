#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import gzip    
import datetime
import json
import os.path
import random
import re
import requests
import simplecache
import sqlite3
import socket
import sys
import time
import traceback
import threading
import unicodedata
import urllib

import importlib
import operator
import collections
    
import urllib3



from xml.dom import minidom
    
from .constants import urllib2
from .constants import cookielib
from .constants import StringIO
    
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
from  . import constants as C
from .constants import quote_plus
from .constants import urlparse
from .constants import urlencode
from .constants import HTMLParser
html_parser = HTMLParser()
import simplecache

if C.PY2: from htmlentitydefs import name2codepoint
if C.PY3: from html.entities import name2codepoint


##if sys.version_info >= (3, 0): from html.parser import HTMLParser
##else: from HTMLParser import HTMLParser


my_http_session = requests.Session()
from urllib3 import ProxyManager, PoolManager
if C.certPath:
    pool_proxy = PoolManager(ca_certs=C.certPath)
else:
    pool_proxy = PoolManager()


### fake cache created to check memory usage
### ... appears to be zero cost.... memory collection?...
### ram seems to be related to number of thumbnails(size) / skin viewtyep / other things?
class FakeCache():
    empty = json.loads("[]")    
    def get(self,endpoint):
        return self.empty
    
    def set(self,endpoint,data,expiration):
        return
##global_cache = FakeCache()
global_cache = simplecache.SimpleCache()
global_cache.enable_mem_cache=False




#__________________________________________________________________________
#
#__________________________________________________________________________
# routine for PY2/PY3 compatibility
def s_e(s):
    if C.PY2:
        #change unicode to str or bool,float,int to str
        if type(s) in [str]:
            return s
        elif type(s) in [bool,float,int]:
            return str(s)
        elif s is None:
            return s
        else:
            return s.encode('utf8')
    else:
        if type(s) in [bool,float,int]:
            return str(s)
        elif s is None:
            return s
        else:
            return s
def s_d(s):
    if C.PY2:
        #cast str to unicode
        if s and not isinstance(s, C.text_type):
            return s.decode('utf8')
        else:
            return s
    else:
        return s
    
#__________________________________________________________________________
#
def get_setting(setting_name, auto_convert=bool):
    raw_setting = C.this_addon.getSetting(setting_name)
    if auto_convert is bool:
        if raw_setting.lower() in ['true','false']:
            return (raw_setting.lower() == 'true')
        if raw_setting.lower() in ['none']:
            return None
        if raw_setting == '':
            return None
    if auto_convert is int:
##        Log(repr(("get_setting", setting_name,raw_setting)))
        if raw_setting == '':
            return 0
        else:
            return int(raw_setting)
    if auto_convert is float:
        #Log("float:"+repr(auto_convert is float), xbmc.LOGNONE)
        return float(raw_setting)
    if auto_convert is str:
        return str(raw_setting)
    splitted = repr(auto_convert).split("','")[0].split("'")[1]

    return raw_setting
#__________________________________________________________________________
#
def set_setting(setting_name, setting_value):
    #Log(repr(("set_setting", setting_name,setting_value)))
    C.this_addon.setSetting(id=setting_name, value=str(setting_value))
    
#__________________________________________________________________________
#
def playvid(
    video_url
    , name
    , download = None
    , description = u''
    , playmode_string = None
    , play_profile = None
    , download_filespec = None
    , mode = None #30
    , url_factory = None#''
    , icon_URI = None
    , repeat_when_available = False
    , sub_title_url = None
    , mimetype = None #"video/mp2t"
    ):

    raise Exception()
    import player
    player.playvid(
            video_url = video_url
            , name = name
            , download = download
            , description = description
            , playmode_string = playmode_string
            , play_profile = play_profile
            , download_filespec = download_filespec
            , mode = mode
            , url_factory = url_factory
            , icon_URI = icon_URI
            , repeat_when_available = repeat_when_available
            , sub_title_url = sub_title_url
            , mimetype = mimetype
        )

#__________________________________________________________________________
# wrapper to allow cookie extraction from urllib3 proxy/socks requests
class FakeRequest(object):
    def __init__(self, full_url, headers):
        self.full_url = full_url
        self._headers = headers.copy()
    @property
    def headers(self):
        return self._headers
    @property
    def url(self):
        return self.full_url
    def get_full_url(self):
        return self.full_url
    def is_unverifiable(self, *args, **kargs):
        return True
    def get_origin_req_host(self, *args, **kargs):
        return self.full_url   
#__________________________________________________________________________
#
def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=15 #seconds
            , sucuri_solved=False
            , method="GET"
            , send_back_response=False
            , auto_encode_content=False
##            , cookie_domain=None
            , size=8192*1000
            , start_point=None
            , preload_content=True
            , cache_duration=C.default_GETHTML_cache_duration #seconds
            ):

##    LogR(locals(),C.LOGWARNING)
    socket.setdefaulttimeout(http_timeout)
    response = None

    if not url:
        if send_back_redirect == True:
            return '', ''
        return ''

    cache_id = C.addon_id+'_gethtml_'+url
    if  (send_back_response == False) and \
        (cache_duration > 0) and \
        method=="GET" :
        cached_value = global_cache.get(cache_id)
        if cached_value:
##                Log('value is cached {}'.format(url)
##                    ,C.LOGNONE
##                    )
            if send_back_redirect:
                return cached_value, url
            return cached_value             

##    Log('after cached'
##        ,C.LOGNONE
##        )


    if not Is_Online():
        if send_back_redirect == True:
            return '', ''
        return ''

##    Log('after Is_Online'
##        ,C.LOGNONE
##        )


    cj = cookielib.LWPCookieJar(C.cookiePath)
    try:
        cj.load(ignore_discard=True, ignore_expires=True)
        cj._now = int(time.time()) #module does not set this if I use internal functions
    except:
        cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
        cj._now = int(time.time())
        pass
    stream=False
    response = None
    redirected_url = None

    try:

        if '|' in url:
            headers = dict(urlparse.parse_qsl( str(url.split('|')[1])))
            url = url.split('|')[0]


        if headers is None:
##            Log("copying default header dictionary")
            getHtml_headers = C.DEFAULT_HEADERS.copy()
            r_c_u_a = C.USER_AGENT #random.choice(C._USER_AGENTS)
    ##        Log("r_c_u_a={}".format(r_c_u_a), xbmc.LOGNONE)
            getHtml_headers['User-Agent'] = r_c_u_a
    ##        Log("rand choice getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
        else:
            getHtml_headers = headers #headers.copy()
##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
            
        if len(referer) > 1:
            getHtml_headers['Referer'] = referer

        if sent_data:
            getHtml_headers['Content-Length'] = str(len(sent_data))

        if start_point and int(start_point) > 0:
            getHtml_headers['Range'] = 'bytes={}-'.format(start_point)
            
##        Log("getHtml_headers='{}'".format(repr(getHtml_headers))
####            , C.LOGNONE
##            )
##        return None


        #
        # I don't know how to use cookieJar with SOCKS proxy
        #
        socks_cookies = ''
        if url:
            this_domain = urlparse.urlparse(url).netloc
            
        temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
        if cj and url:
            for cookie in cj:
                if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                    socks_cookies += "{}={};".format(cookie.name,cookie.value)
                    temp_cookiejar.set_cookie(cookie)
##            for cookie in temp_cookiejar: #verification during development 
##                Log("temp_cookiejar_cookie={}".format(repr(cookie)))
##                pass
            if 'Cookie' in getHtml_headers:
                socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
            if not socks_cookies == '':
                getHtml_headers['Cookie'] = (socks_cookies).strip(';')

    
##        Log("final getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
##        return "" #getHtml_headers testing/dev

        bypass_proxy_list = get_setting('bypass_proxy_list')
        if not bypass_proxy_list: bypass_proxy_list=''
        should_bypass_proxy = urlparse.urlparse(url).netloc in (bypass_proxy_list.split(','))
        if not should_bypass_proxy:
            socks_proxy_info = Socks_Proxy_Active()
        else:
            socks_proxy_info = None
            
        if socks_proxy_info and (socks_proxy_info['uhp'] in (4,5))  :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            if C.certPath: 
                proxy = SOCKSProxyManager(proxy_url=socks_string, ca_certs=C.certPath)
            else:
                proxy = SOCKSProxyManager(proxy_url=socks_string)
            
            socks_response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            
            if preload_content:
                data = socks_response.data

            redirected_url = socks_response.geturl()
            if not url == redirected_url:
                Log(repr((url,redirected_url)))
                Log("redirected_url='{}'".format(redirected_url))
            else:
                redirected_url = None



##        elif (socks_proxy_info['uhp'] <= -0) :
        else:

            if socks_proxy_info and socks_proxy_info['ps'] is not None:
                proxy_string = "http://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                proxy = ProxyManager(proxy_url=proxy_string, ca_certs=C.certPath)
            else:
                proxy_string = ''
                #proxy = PoolManager()
                proxy = pool_proxy

##            Log(repr(proxy) )
##            Log(repr(dir(proxy)) )            
##            Log(repr(dir(proxy)) )

            response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                ,preload_content = preload_content
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
 
            #make urllib3.response more like requests.response by adding cookiejar and status
            temp_jar = cookielib.LWPCookieJar()
            fake_request = FakeRequest(url, response.getheaders() )
            requests.cookies.extract_cookies_to_jar(temp_jar, fake_request, response)
            response.cookies = temp_jar
            response.status_code = response.status

            if preload_content:
                data = response.data
##            Log(data[:500])

            redirected_url = response.geturl()
            if not (url == redirected_url):
##                LogR((url,redirected_url))
                if redirected_url and not (redirected_url.startswith('http')):
                    Log('no http from response.geturl() maybe a urllib3 bug if STREAMING')
##                    Log(repr(response.retries))
##                    Log(repr(response.retries.history))
                    if (response.retries is not None):
                        if len(response.retries.history): #there is a history
                            redir_domain =''
                            redirect_location = response.retries.history[-1].redirect_location
                            redirect_url = response.retries.history[-1].url
##                            Log("redirected_url={}".format(repr(redirected_url)))
                            if not (redirected_url.startswith('http')):
                                if not (redirect_url.startswith('http')):
##                                if not ('http' in redirect_url):
                                    redir_domain = urlparse.urlparse(url).scheme + '://' + urlparse.urlparse(url).netloc
                                else:
                                    redir_domain = urlparse.urlparse(redirect_url).scheme + '://' + urlparse.urlparse(redirect_url).netloc
                            redirected_url = redir_domain + redirected_url

##                Log("redirected_url={}".format(repr(redirected_url)))
                if redirected_url and not (redirected_url.startswith('http')):
                    redir_domain = urlparse.urlparse(url).scheme + '://' + urlparse.urlparse(url).netloc
                    redirected_url = redir_domain + redirected_url
                Log("redirected_url={}".format(repr(redirected_url)))
            else:
                redirected_url = None
                    


        if auto_encode_content: 
            if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
                content_type = response.headers['Content-Type']
                if 'charset=' in content_type:
                    ct = content_type.split('charset=')[1]
##                    Log('decoding as {}'.format(repr(ct)))
                    data = data.decode(ct)
            
        if sucuri_solved == False:
            if 'Server' in response.headers:
                if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                    Log(repr(response.status_code))
                    import sucuri
                    if sucuri.SCRIPT_HEADER in data:
                        cookie = sucuri.Set_Cookie(data)
                        cj.set_cookie(cookie)
                        cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
    ##                            raise
                        return getHtml(url, referer, headers
                                       , save_cookie, sent_data
                                       , ignore404, ignore403
                                           , send_back_redirect
                                           , http_timeout
                                           , sucuri_solved = True
                                           , method=method
                                           )

        if not (save_cookie == False) and (cj is not None) :
            r = response
            this_domain = urlparse.urlparse(url).netloc

            if r is not None:
                for cookie in r.cookies:
                       #Log("r.cookie={}".format(repr(cookie)))
                    if save_cookie == True: #save as this domain even if cookie is not marked so
                         cookie.domain = this_domain
                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                        cj.set_cookie(cookie)
                        
                cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

             

        if send_back_response == True:
            if send_back_redirect == True:
                return response, redirected_url
            else:
                return response


        if  (send_back_response == False) and \
            (cache_duration > 0):

            if 'Content-Type' in response.headers:
                ctype = response.headers['Content-Type'].lower().split('charset=utf-8')[0].rstrip(' ;')
                if ctype and ctype in [
                                                            'application/xml'
                                                            , 'application/json'
                                                            , 'text/html'
                                                            , 'application/javascript'
                                                            , 'application/x-mpegurl'
                                                        ]:
                    global_cache.set(
                        endpoint = cache_id
                        ,data = data  #.decode('utf8')
                        ,expiration = datetime.timedelta(seconds=cache_duration)
                        )
                else:
                    Log("not caching ctype = {}".format(repr(ctype)))
                    pass
            
        if send_back_redirect == True:
            return data, redirected_url

        if response:
            response.close()

        return data


    except requests.HTTPError as e:
        Log("repr(e)='{}'".format(repr(e)))
        raise

    except urllib2.HTTPError as e:
        Log(repr(e.info().get('Content-Encoding')))
        
        if e.info().get('Content-Encoding') == 'gzip':
            import StringIO
            buf = StringIO.StringIO( e.read())
            import gzip
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = e.read()
        #Log(data)  #errors='ignore'
        #notify('Oh oh',data)
        if e.code == 503 and 'cf-browser-verification' in data:
            import cloudflare
            data = cloudflare.solve(url, cj, USER_AGENT)
            
        elif e.code == 404 and ignore404 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        elif e.code == 403 and ignore403 == True:
            Log("403_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data
            
        else:
            traceback.print_exc()
            raise urllib2.HTTPError()

    except Exception:
##        traceback.print_exc()
        #log a lot of info unless it seems to be internal timeout
        if http_timeout > 1:
            LogR(locals())
            raise
        else:
            Log("internal timeout",C.LOGWARNING)
    finally:
        if not send_back_response:
            if response:
                response.close()
                
#__________________________________________________________________________
#
def postHtml(post_url
             , sent_data=None
             , headers=None
             , compression=True
             , NoCookie=True
             , cache_duration=-1
             , http_timeout=15
             ):
    data = getHtml(url=post_url
                   , headers=headers
                   , save_cookie=(not NoCookie)
                   , sent_data=sent_data
                   , method="POST"
                   , http_timeout=http_timeout
                   , cache_duration=-1)
    return data

#__________________________________________________________________________
#
def headHtml(head_url
             , sent_data=None
             , headers=None
             , compression=True
             , NoCookie=True
             , send_back_redirect=False
             , http_timeout=15
             , cache_duration=-1):
    return getHtml(url=head_url
                   , send_back_redirect=send_back_redirect
                   , headers=headers
                   , save_cookie=(not NoCookie)
                   , method="HEAD"
                   , http_timeout=http_timeout
                   , cache_duration=-1 )

#__________________________________________________________________________
#
def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q
#__________________________________________________________________________
#
cp1252 = {
    # from http://www.microsoft.com/typography/unicode/1252.htm
    u"\u20AC": u"\x80", # EURO SIGN
    u"\u201A": u"\x82", # SINGLE LOW-9 QUOTATION MARK
    u"\u0192": u"\x83", # LATIN SMALL LETTER F WITH HOOK
    u"\u201E": u"\x84", # DOUBLE LOW-9 QUOTATION MARK
    u"\u2026": u"\x85", # HORIZONTAL ELLIPSIS
    u"\u2020": u"\x86", # DAGGER
    u"\u2021": u"\x87", # DOUBLE DAGGER
    u"\u02C6": u"\x88", # MODIFIER LETTER CIRCUMFLEX ACCENT
    u"\u2030": u"\x89", # PER MILLE SIGN
    u"\u0160": u"\x8A", # LATIN CAPITAL LETTER S WITH CARON
    u"\u2039": u"\x8B", # SINGLE LEFT-POINTING ANGLE QUOTATION MARK
    u"\u0152": u"\x8C", # LATIN CAPITAL LIGATURE OE
    u"\u017D": u"\x8E", # LATIN CAPITAL LETTER Z WITH CARON
    u"\u2018": u"\x91", # LEFT SINGLE QUOTATION MARK
    u"\u2019": u"\x92", # RIGHT SINGLE QUOTATION MARK
##    u"\u2019": "\u2019".encode('utf8'), # RIGHT SINGLE QUOTATION MARK
    u"\u201C": u"\x93", # LEFT DOUBLE QUOTATION MARK
    u"\u201D": u"\x94", # RIGHT DOUBLE QUOTATION MARK
    u"\u2022": u"\x95", # BULLET
    u"\u2013": u"\x96", # EN DASH
    u"\u2014": u"\x97", # EM DASH
    u"\u02DC": u"\x98", # SMALL TILDE
    u"\u2122": u"\x99", # TRADE MARK SIGN
    u"\u0161": u"\x9A", # LATIN SMALL LETTER S WITH CARON
    u"\u203A": u"\x9B", # SINGLE RIGHT-POINTING ANGLE QUOTATION MARK
    u"\u0153": u"\x9C", # LATIN SMALL LIGATURE OE
    u"\u017E": u"\x9E", # LATIN SMALL LETTER Z WITH CARON
    u"\u0178": u"\x9F", # LATIN CAPITAL LETTER Y WITH DIAERESIS
}
try:
    from htmlentitydefs import name2codepoint
except:
    from html.entities import name2codepoint
def htmlentitydecode(s):
    return re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: unichr(name2codepoint[m.group(1)]), s)

def try_decode(text, encoding="utf-8"):
    '''helper to decode a string to unicode'''
    try:
        return text.decode(encoding, "ignore")
    except Exception:
        return text
def cleantext(text):

    '''normalize string, strip all special chars'''
    text = text.replace('\t','')
    text = text.replace('\n','')

    text = text.strip()
    text = text.rstrip('.')
    text = unicodedata.normalize('NFKD', try_decode(text))


    text = html_parser.unescape(text)
##    LogR(dir(C.html_parser),C.LOGWARNING)
    text = htmlentitydecode(text)
    for src, dest in cp1252.items():
        text = text.replace(dest, src )

##    raise Exception()

    text = text.replace('\\u0026','&')
    text = text.replace('&colon;',':')
    text = text.replace('&comma;',',')
    text = text.replace('&lowbar;','_')
    text = text.replace('&period;','.')
    text = text.replace('&lbrace;','(')
    text = text.replace('&DiacriticalAcute;','`')
    text = text.replace('&lcub;','{')
    text = text.replace('&rcub;','}')
    text = text.replace('&sol;','/')
    text = text.replace('&lpar;','(')
    text = text.replace('&rpar;',')')
    text = text.replace('&quest;','?')
    text = text.replace('&apos;','\'')
    text = text.replace('&percnt;','%')
    text = text.replace('&num;','#')
    return text
#__________________________________________________________________________
#
def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext
#__________________________________________________________________________
#
def Set_ListItem_Duration(listitem, duration):
    duration=str(duration).lower().strip()
    duration_seconds = 0

    # test cases:
    # 
##    Log(duration, xbmc.LOGNONE)
    
    #somethimes will have a dot
    if '.' in duration:
        duration = duration.split('.')[1]
        
    #sometimes format will be hh:mm:ss: normalize it to what I want
    timearr= ['s','m','h']
    if ':' in duration:
        duration_arr = duration.split(':')
        duration = ""
        i = 0
        for duration_elem in reversed(duration_arr):
            duration = duration_elem + timearr[i] + duration
            i = i+1

    duration = duration.replace(' h', 'h ').replace('h', 'h ').replace('min', 'm ').replace(' m', 'm ').replace('m', 'm ').replace(' s', 's ').replace('s', 's ').strip()

    #sometimes format will be Xh Ym Zs
    try:
        duration_arr = duration.split(' ')
        for duration_elem in duration_arr:
            duration_elem = duration_elem.strip()
            if 'h' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('h',''))*3600
            elif 'm' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('m',''))*60
            elif 's' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('s',''))
            elif duration_elem:
                try:
                    duration_seconds = duration_seconds + int(duration_elem)
                except:
                    pass
    except:
        Log(repr(duration_arr))
        duration_seconds = 600
        #raise

    return duration_seconds
    listitem.setInfo(type="Video", infoLabels={"duration": duration_seconds} )
#__________________________________________________________________________
#
def addDownLink(name, url, mode
                , iconimage=''
                , desc=''
                , stream=None
                , fav='add'
                , noDownload=False
                , duration=None
                , date=None
                , views=None
                , likes=None
                , play_method=None
                , hq_stream=None
                , return_listitem=False
                , icon_url=''
                , actors_xml = ''
                , action=''
                ):

    if fav == 'add': favtext = "Add to"
    elif fav == 'del': favtext = "Remove from"
    if not date: date = 0
    if not hq_stream: hq_stream = ''
    else:  hq_stream = str(hq_stream)


##    if isinstance(url, unicode):
##        url = url.encode('utf8')        
##    if isinstance(name, unicode):
##        name = name.encode('utf8')        
##    if isinstance(desc, unicode):
##        desc = desc.encode('utf8')        
##    if isinstance(iconimage, unicode):
##        iconimage = iconimage.encode('utf8')        
        
    u = (
        "{}".format(sys.argv[0])
        + "?url={}".format(quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(quote_plus(iconimage) ) 
        + "&name={}".format(quote_plus(name))
        + "&action={}".format(action)
        )
    
    u = (
        "{}".format(sys.argv[0])
        + "?url={}".format(quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(quote_plus(iconimage) ) 
        + "&name={}".format(quote_plus(name))
        + "&hq_stream={}".format(quote_plus(hq_stream)) 
        + "&desc={}".format(quote_plus(desc)) 
        + "&playmode_string={}".format(play_method)
        + "&action={}".format(action)
        )
    download_xbmc_url = (
        "{}".format(sys.argv[0]) 
        + "?url={}".format(quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(quote_plus(iconimage) ) 
        + "&name={}".format(quote_plus(name))
        + "&hq_stream={}".format(quote_plus(hq_stream)) 
        + "&playmode_string={}".format(play_method) 
        + "&download=1"
        + "&icon_URI={}".format(quote_plus(iconimage) ) 
        + "&action={}".format(action)
        )
    favorite = (
        "{}".format(sys.argv[0]) 
        + "?url={}".format(quote_plus(url)) 
        + "&mode={}".format(C.FAVORITES_MODE) 
        + "&img={}".format(quote_plus(iconimage) ) 
        + "&name={}".format(quote_plus(name))
        + "&hq_stream={}".format(quote_plus(hq_stream)) 
        + "&fav={}".format(fav) 
        + "&favmode={}".format(mode)
        + "&desc={}".format(quote_plus(desc))
        + "&icon_url={}".format(quote_plus(icon_url))
        + "&action={}".format(action)
        )
    play_with_method = (
        "{}".format(sys.argv[0])
        + "?url={}".format(quote_plus(url))
        + "&mode={}".format(mode)
        + "&img={}".format(quote_plus(iconimage) )
        + "&name={}".format(quote_plus(name))
        + "&hq_stream={}".format(quote_plus(hq_stream))
        + "&playmode_string={}"
        + "&play_profile={}"
        + "&action={}".format(action)
        )

    
    if len(iconimage) < 1:                 iconimage = C.default_icon
    if not '|' in iconimage and 'http' in iconimage: iconimage = "{}{}".format(iconimage, Header2pipestring())

    if C.xbmc_version[0] > 17 :
        liz = xbmcgui.ListItem(
            label = name
            , offscreen=True #kodi 18+
            )
    else:
        liz = xbmcgui.ListItem(
            label = name
##            , offscreen=True #kodi 18+
            )
        
    liz.setArt(
        { 'thumb': iconimage #must include thumb to avoid error log messages
         , 'fanart': iconimage #must include fanart for infowall view
##          , 'fanart': iconimage #must include fanart for infowall view
##          , 'poster': iconimage
          }
        ) 

    if duration:  
        Set_ListItem_Duration(liz, duration) #2021-01 k17.6 setting duration seems to cause page to be reloaded after play stops 

    liz.setMimeType('video/mp4')
    liz.setContentLookup(False)           
    #  if 'IsPlayable' true, don't use playlists (?)
    #  if 'IsPlayable' true, will trigger a container refresh [randomly?]
    #  if 'IsPlayable' true, file-not-found will log 'ERROR: ... '  ERROR: Playlist Player: skipping unplayable item ... CVideoPlayer::OpenInputStream - error opening.....'
    #  if 'IsPlayable' false, then 'mark as watched' will not work
    liz.setProperty('IsPlayable', 'false') 
##    liz.setProperty('IsPlayable', 'true')
    
    if stream:
        LogR(stream)
##        liz.setProperty('IsPlayable', 'true') #can't set this and use playlists at same time

    if len(desc) < 1:  desc = ''

    if C.PY2:
        liz.setInfo(
            type="Video"
            , infoLabels={
                "title": name
                ,"plot": desc
                ,"plotoutline": desc
                }
            )
    if C.PY3:
        liz.getVideoInfoTag().setTitle(name)
        liz.getVideoInfoTag().setPlot(name+'[CR][CR]'+desc)
        liz.getVideoInfoTag().setMpaa("R")
        liz.getVideoInfoTag().setMediaType('episode') #required for skin to show 'cast'
        vsd = xbmc.VideoStreamDetail()
        vsd.setCodec('h264')
        liz.getVideoInfoTag().addVideoStream(vsd)
        actors = []
        for actor_info in actors_xml:
            dom = minidom.parseString("<a>"+actor_info+"</a>")
            name = dom.getElementsByTagName('name')[0].lastChild.data
            actors.append(xbmc.Actor(name=name
    ##                                 ,thumbnail=thumbnail
    ##                                 ,role=role
    ##                                 ,order=order
                                     ))
        liz.getVideoInfoTag().setCast(actors)



    contextMenuItems = []

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        
        contextMenuItems.append(
            (
            "[COLOR {}]{} favorites[/COLOR]".format(C.refresh_text_color, favtext)
            , "RunPlugin({})".format(favorite)
            )
        )
        if fav == 'del':
            favorite = (
                "{}".format(sys.argv[0]) 
                + "?url={}".format(quote_plus(url)) 
                + "&mode={}".format(C.FAVORITES_MODE) 
                + "&img={}".format(quote_plus(iconimage) ) 
                + "&name={}".format(quote_plus(name)) 
                + "&hq_stream={}".format(quote_plus(hq_stream)) 
                + "&fav={}".format('refresh') 
                + "&favmode={}".format(mode)
                + "&desc={}".format(quote_plus(desc)) 
                + "&icon_url={}".format(quote_plus(icon_url))
                )
            contextMenuItems.append(
                (
                "[COLOR {}]{}[/COLOR]".format(C.refresh_text_color, 'Refresh')
                , "RunPlugin({})".format(favorite)
                )
            )
            favorite = (
                "{}".format(sys.argv[0]) 
                + "?url={}".format(quote_plus(url)) 
                + "&mode={}".format(C.FAVORITES_MODE) 
                + "&img={}".format(quote_plus(iconimage) ) 
                + "&name={}".format(quote_plus(name)) 
                + "&hq_stream={}".format(quote_plus(hq_stream)) 
                + "&fav={}".format('rename') 
                + "&favmode={}".format(mode)
                + "&desc={}".format(quote_plus(desc)) 
                + "&icon_url={}".format(quote_plus(icon_url))
                )
            contextMenuItems.append(
                (
                "[COLOR {}]{}[/COLOR]".format(C.refresh_text_color, 'Rename')
                , "RunPlugin({})".format(favorite)
                )
            )

    max_rez = (C.addon.getSetting("max_rez").lower())
    if not max_rez: max_rez = ('480','720','1080')
    else: max_rez = max_rez.split(',')

    if play_method in {C.PLAYMODE_VARIABLE, None} :
        for rez in max_rez:
            contextMenuItems.append(
                (
                "[COLOR {}]{} {}[/COLOR]".format(C.highlight_text_color, 'Play Max',rez)
                , "PlayMedia({})".format(play_with_method.format(rez, 0))
                )
            )
        
    if play_method in {C.PLAYMODE_INPUTSTREAM, C.PLAYMODE_F4MPROXY, C.PLAYMODE_DIRECT, '', None} :

        contextMenuItems.append(
            (
            "[COLOR {}]{} Direct[/COLOR]".format(C.time_text_color, 'Play')
            , "PlayMedia({})".format(play_with_method.format(C.PLAYMODE_DIRECT, 0))
            )
        )
        contextMenuItems.append(
            (
            "[COLOR {}]{} Inputstream[/COLOR]".format(C.time_text_color, 'Play')
            , "PlayMedia({})".format(play_with_method.format(C.PLAYMODE_INPUTSTREAM, 0))
            
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_01_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_01"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_02_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_02"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_03_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_03"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_04_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_04"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_05_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_05"))
            )
        )        
    if noDownload == False:
        contextMenuItems.append(
            (
                "[COLOR {}]Download[/COLOR]".format(C.search_text_color)
                ,"RunPlugin({})".format(download_xbmc_url)
            )
        )

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
    else:
        liz.addContextMenuItems([], replaceItems=True)

##    Log(u"u={}".format(repr(u)))
    if return_listitem:
        return(u, liz, False)
    else:
        xbmcplugin.addDirectoryItem(handle=C.addon_handle, url=u, listitem=liz, isFolder=False)
#__________________________________________________________________________
#
def addDir(name, url, mode
           , iconimage=None
           , page=None
           , channel=None
           , section=None
           , keyword=''
           , Folder=True
           , duration=None
           , title=None
           , end_directory=True
           , contextMenu=None
           , contextMenuReplace=True
           , return_listitem=False
           , return_url=False):

    if page is None: page='1'
    u = (sys.argv[0] +
     "?url=" + quote_plus(str(url)) +
     "&1mode=" + str(mode) +
     "&mode=" + str(mode) +
     "&page=" + str(page) +
     "&channel=" + str(channel) +
     "&section=" + str(section) +
     "&keyword=" + quote_plus(str(keyword)) +
     "&end_directory=" + str(end_directory) +
     "&name=" + quote_plus(str(name.encode('utf8'))))

    if return_url:
        return u


    if not(iconimage) or (len(iconimage) < 1): iconimage = C.default_icon

    if not '|' in iconimage and 'http' in iconimage:
        iconimage = u"{}{}".format(iconimage, Header2pipestring())

##    liz = xbmcgui.ListItem(
##        name
##        , iconImage=iconimage
##        , thumbnailImage=iconimage
##        )
    if C.xbmc_version[0] > 17 :
        liz = xbmcgui.ListItem(
            label = name.encode('utf8')
            , offscreen=True #kodi 18+
            )
    else:
        liz = xbmcgui.ListItem(
            label = name #.encode('utf8')
            )
##    LogR(name)
    
    liz.setProperty('IsPlayable', 'false')

    liz.setArt(
        { 'thumb': iconimage
          , 'icon': iconimage
          , 'fanart': iconimage
          , 'poster': iconimage
          }
        ) #must include thumb to avoid error messages

    if duration:
        Set_ListItem_Duration(liz, duration)

    #setting type = music instead of video means no icon to the right of the label
    #liz.setInfo(type="music", infoLabels={"Title": name})

    if title:
        if C.PY2: liz.setInfo(type="Video", infoLabels={"Title": title})
        if C.PY3: liz.getVideoInfoTag().setTitle(title)

    contextMenuItems = []
    if len(keyword) >= 1 and not("next page" in name.lower()):
        keyw = (sys.argv[0] +
            "?mode=" + C.DELETE_KEYWORD +
            "&keyword=" + quote_plus(keyword))
        #if not contextMenuItems: contextMenuItems = []
        contextMenuItems.append(
                (
                    "[COLOR {}]Remove keyword[/COLOR]".format(C.time_text_color)
                    , "RunPlugin({})".format(keyw)
                )
            )

    if section and section == C.INBAND_RECURSE:
        #below will not work well because the 'back' button will return to root of addon, and not where I want     
        u2 = u.replace("&keyword=" + quote_plus(str(keyword)), "&keyword=" + C.INBAND_RECURSE)
        u2 = u2.replace("&page=" + str(page), "&page=" + str(int(page)-1)) #include the page we are on
        u2 = u2.replace("&page=" + str(page), "&page=1")  #include the page we are on
        contextMenuItems.append( (
            "[COLOR {}]Recurse to Page {}[/COLOR]".format(C.search_text_color, C.MAX_RECURSE_DEPTH)
            , "ActivateWindow(Videos,{})".format(u2)  )  )
        contextMenuReplace=False

    if contextMenu:
        contextMenuItems = contextMenu

    if contextMenuItems:
        liz.addContextMenuItems(contextMenuItems, replaceItems=contextMenuReplace)

    if return_url:
        return u
    elif return_listitem:
        return(u, liz, Folder)
    else:
        xbmcplugin.addDirectoryItem(
            handle=C.addon_handle
            , url=u
            , listitem=liz
            , isFolder=Folder
            )
#__________________________________________________________________________
#
def Get_Sites(filter_category=None,icon_function=None):
    import importlib
    libDir = os.path.join(C.resDir, 'lib')
    sitesDir = os.path.join(libDir, 'sites')
    files = []
    for r, d, f in os.walk(sitesDir): # r=root, d=directories, f = files
        for file in f:
            if file.endswith('.py') and not file.startswith('_') :
                f2 = file[:-len('.py')]
                files.append(f2)
    site_list = {}
    for f in files:
        if not f in site_list:
            site_list[f] = ''

    sorted_site_list = sorted(site_list.items(), key=operator.itemgetter(0))

    sorted_dict = collections.OrderedDict(sorted_site_list)
   
    aa = None
    for sitename in sorted_dict:
        if aa is None:
            try:
                module = importlib.import_module('resources.lib.sites.'+sitename)
                if hasattr(module, "website"):
                    module = module.website
                if filter_category:
                    if module.LIST_AREA == filter_category:
                        yield (
                            module.FRIENDLY_NAME
                            ,module.ROOT_URL
                            ,module.MAIN_MODE
                            ,os.path.join(C.imgDir, sitename + '.png')
                            )
                elif icon_function==True:
                    aa = (yield (module ,module.MAIN_MODE))
                    if aa is not None:
                        break
                else:
                    aa = (yield (sitename, module))
                    if aa is not None:
                        break
            except GeneratorExit:
                pass
            except:
                Log('failed Get_Sites for {}'.format(sitename), xbmc.LOGWARNING)
                traceback.print_exc()



#__________________________________________________________________________
#

def Log(msg='', loglevel=None, stacklevel=2):
    if C.DEBUG and not(loglevel): loglevel = C.LOGNONE
    if not loglevel: return
    if not msg: msg = u""
    if not isinstance(msg, C.text_type):
        if C.PY3: msg = str(msg,'utf8','ignore')
        if C.PY2: msg = msg.decode('ascii','ignore').encode('utf8')
    try:
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
            ,traceback.extract_stack(limit=stacklevel)[0][1]
            ,msg
            )
    except:
        pass
    msg = u"{}: {}".format(C.addon_id, msg)
##    msg = u"{}: {}".format(C.addon_id, msg.encode('utf-8',errors='ignore') )
    if  loglevel: xbmc.log(msg , loglevel)
##    elif C.DEBUG: xbmc.log(msg , C.LOGNONE)
    else:         xbmc.log(msg)
#__________________________________________________________________________
#
def LogR(msg='', loglevel=None, include_type=False,stacklevel=3):
    if include_type: t = (type(msg), msg)
    else: t = (msg,)
    Log(repr(t), loglevel, stacklevel=stacklevel)

#__________________________________________________________________________
#
def Notify(header=None, msg='', duration=4000, sound=False, allow_all_thread_names=False):
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound, allow_all_thread_names=allow_all_thread_names)
def notify(
    header=None
    , msg=''
    , duration=C.DEFAULT_NOTIFY_TIME
    , sound=False
    , allow_all_thread_names=False
    ):
    debug = (C.this_addon.getSetting('debug').lower() == "true")
    if allow_all_thread_names or (threading.current_thread().name == "MainThread"):
        if header==None or header == '':
            if len(Clean_Filename(msg)) > 29:
                header = msg[0:29] #header will begin scrolling after 29
                msg = msg[-29:]
            else:
                header=msg
        xbmcgui.Dialog().notification(header, msg, C.default_icon, duration, sound=False )
        Log( repr((header,msg)), C.LOGNONE)
    elif debug:
        Log( msg, xbmc.LOGWARNING)
#__________________________________________________________________________
#
def Header2pipestring(header = C.DEFAULT_HEADERS):
    if C.PY2:
        q = "|{}".format( urllib.urlencode(header)  )
    else:
        q = "|{}".format( urlencode(header)  )
    return q

#__________________________________________________________________________
#
def add_sort_method():
    sort_order = None  ##int(C.addon.getSetting('video_sort_by'))
    if sort_order == 2:
        sort_order = xbmcplugin.SORT_METHOD_DURATION
##    elif sort_order == :
##        sort_order = xbmcplugin.SORT_METHOD_DATE
    elif sort_order == 1:
        sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
    elif sort_order == 4:
        sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
    elif sort_order == 5:
        sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
    else:
        sort_order = xbmcplugin.SORT_METHOD_UNSORTED
    
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=sort_order) #use preferred method first
    #xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
#    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(C.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_DURATION)

#__________________________________________________________________________
#
def endOfDirectory(cacheToDisc=True, end_directory=True, allow_sorting=True, inband_recurse=False, updateListing=False):
##    if end_directory is True:  traceback.print_stack()

    if not ( (end_directory == True) or inband_recurse ):
        return
    if allow_sorting == True:
        add_sort_method()
    if int(sys.argv[1]) > 0:
        C.addon_handle = int(sys.argv[1])
        xbmcplugin.endOfDirectory(C.addon_handle, cacheToDisc=cacheToDisc, updateListing=updateListing)
##        traceback.print_stack()
#__________________________________________________________________________
#
def SortVideos(sources
               , download
               , vid_res_column=1
               , substitute_char='}'
               , substitute_res='720'
               , max_video_resolution = C.maximum_video_resolution
               ):

##    Log(repr((__name__, locals()))
##        ,C.LOGWARNING
##        )
   
##    global maximum_video_resolution
    if max_video_resolution:
        maximum_video_resolution = max_video_resolution
    else:
        maximum_video_resolution = C.maximum_video_resolution
##    Log(str(maximum_video_resolution))

    try: 
        #sometimes we can't get accurate resolutions and end up with a characters instead...
        # e.g. "http://video.mp4","}"     instead of   "http://video.mp4","480p"

##        Log("sources='{}', download='{}'".format(sources,download))

        if (bool(download) == True):
            maximum_video_resolution = 99999 # allow max resolution on download
##        Log("maximum_video_resolution='{}'".format(maximum_video_resolution))

        s3840p_string = "3840p"
        s2160p_string = "2160p"
        s1440p_string = "1440p"
        s1080p_string = "1080p"
        s720p_string = "720p"
        s540p_string = "540p"
        s480p_string = "480p"
        s320p_string = "320p"

        #report on what was the maximum resolution available; just for fun
        try:
            videos = sorted(sources
                            , key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('p60','p') \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('multi',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('uhd 4k'  ,s3840p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True)
##            LogR(videos)

            if len(videos) > 1:
                if vid_res_column == 1:
                    max_avail_res = videos[0][1]
                else:
                    max_avail_res = videos[0][0]
            else:
                max_avail_res = 'unknown'
        except:
            traceback.print_exc()
            max_avail_res = 'unknown'
            pass
        
        Log("Best quality for this item is {}".format(max_avail_res))
        Log("Worst quality for this item is {}".format(videos[-1][vid_res_column]  ))

        #change/poison these subst strings so that they can't be matched
        #   poison values must be less than maximum_video_resolution
        #   poison are chosen so that the highest value
        #      
        if maximum_video_resolution < 3840:  s3840p_string = "11" 
        if maximum_video_resolution < 2160:  s2160p_string = "12"
        if maximum_video_resolution < 1440:  s1440p_string = "13"
        if maximum_video_resolution < 1080:  s1080p_string = "14"
        if maximum_video_resolution < 720:    s720p_string = "15"
        if maximum_video_resolution < 540:    s540p_string = "16"
        if maximum_video_resolution < 480:    s480p_string = "17"
        LogR((maximum_video_resolution, s3840p_string,  s2160p_string
              ,s1440p_string
              ,s1080p_string, s720p_string, s540p_string, s480p_string))

        ## the list of videos is a bunch of urls such as xxx\360.mp4
        ## i use a lambda(just for ?fun?) to split out the numeric
        ##    resolution and the reverse sort it;
        ## the best resolution should end up on top
        ## the 720 is replaced with 721 so that the number ending
        ##    20 does not match other possible strings the site may use to
        ##    define ultra resolutions
        ## the letter p is removed so that we can convert to integer
        ##    and avoid the '720 is better 1080' situation if it were chars
        ## the higher resolutions, when we have been told not to use them,
        ##   are replaced with lower numbered strings 

        try:
            videos = sorted(sources, key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('p60','p') \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('multi',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('uhd 4k'  ,s3840p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True
                            )
        except:
            videos = None
            raise

        Log("videos='{}'".format(videos))
        if len(videos) < 1:
            return None
        if vid_res_column == 1:
            video_url = videos[0][0]
        else:
            video_url = videos[0][1]
        video_url = s_e(video_url)

    except:
        traceback.print_exc()
        video_url = None

    LogR(video_url)
##    raise Exception()
    return video_url
    
#__________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=100, stop_event=None ,monitor=None):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    try:
        while num > 0: #used to include an 'abort requested' check, but but that caused problems
            if monitor.abortRequested(): 
               Log('sleep abortRequested',stacklevel=3)
               return
            sleep_interval = min(check_interval, num)
            time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
            num = num - sleep_interval
    except SystemExit: #common when closing app
        Log('SystemExit',stacklevel=3)
        pass
#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None

    def Get_Setting_Val(setting):
        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"' +
                                  setting + '"},"id":1}')
        return json.loads(val)['result']['value']
    
    try:
        usehttpproxy = Get_Setting_Val('network.usehttpproxy')
        if usehttpproxy and str(usehttpproxy).lower()=='true':
            httpproxytype = Get_Setting_Val('network.httpproxytype') #= get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = Get_Setting_Val('network.httpproxyserver') #= get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = Get_Setting_Val('network.httpproxyport') #= get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = Get_Setting_Val('network.httpproxyusername') #= get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = Get_Setting_Val('network.httpproxypassword') #= get_gui_setting(guisettings_xml, 'httpproxypassword')

    except:
        traceback.print_exc()
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
        return proxy_info
#__________________________________________________________________
#
def RandomNumber(return_integer=True,length=18):
    nc_string = str(random.random())
    if return_integer:
        nc_string = nc_string.split('.')[1]
    while len(nc_string) < length:
        nc_string += str(random.randint(10,99))
    if len(nc_string) > length:
        nc_string = nc_string[0:length]
    return nc_string
#__________________________________________________________________
#
def Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode):
    #helper function to make code look smaller
    # check for a minimum length; raise error if necessary; add item if not enough
    if len(info) < 1:
        label = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "No more items")
        if not keyword == '':
            label += " for [COLOR {}]{}[/COLOR]".format(C.refresh_text_color,keyword)
        label +=  " on '{}'".format(ROOT_URL)
        addDir(
            name=label
            ,url=C.DO_NOTHING_URL
            ,mode=MAIN_MODE
            ,iconimage=C.not_found_icon
            ,end_directory=False
            ,Folder=False
            )
        if testmode:
            raise OSError    
#__________________________________________________________________
#
def Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page):
    #helper function to make code look smaller
    inband_recurse = (keyword==C.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = C.MAX_RECURSE_DEPTH
    else:
        max_search_depth = C.DEFAULT_RECURSE_DEPTH
    if end_directory == True and SEARCH_URL:
        addDir(
            name=C.STANDARD_MESSAGE_SEARCH
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon )

        addDir(
            name=C.STANDARD_MESSAGE_SEARCH_RECURSIVE
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon
            ,end_directory=False
            ,page=C.FLAG_RECURSE_NEXT_PAGES)
##    Log("url={}".format(repr(url)))
##    Log("page={}".format(repr(page)))    
    if ('{}' in url) and page:
        list_url = url.format(page)
    else:
        list_url = url
    Log("list_url='{}'".format(list_url))

    return inband_recurse, end_directory, max_search_depth, list_url
#__________________________________________________________________
#
def Normalize_HD_String(hd):
    hd = hd.lower()
    if   ('2160'           in hd
          or 'uhd'         in hd
          or '4k'          in hd
          or '2k'          in hd
          or '1440'        in hd): hd = C.STANDARD_MESSAGE_UHD
    elif ('class="fullhd"' in hd
          or 'fullhd'      in hd
          or 'full_hd'     in hd
          or    'fhd'      in hd
          or '1080'        in hd): hd = C.STANDARD_MESSAGE_FHD
    elif (   'class="hd"'  in hd
          or 'hd'          in hd
          or 'icon-hd'     in hd
          or '720'         in hd): hd = C.STANDARD_MESSAGE_HD
    else:
##                                LogR(hd, C.LOGERROR)
                                hd = C.STANDARD_MESSAGE_NOHD

    return hd
#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True, delete_first_color=False):
    if not s: return ''
    s = s.strip('\r')
    if not isinstance(s, C.text_type):
##        Log('not unicode yet')
##        Log(repr(s))
        s = s.decode('utf8')
##        Log(repr(s))
    if delete_first_color:
        s = (re.sub(r'(?i)\[cOLOR \w+?\].+?\[\/Color\]','',s))
    s = (re.sub(r'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(r'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(r'(?i)\[\/Color\]','',s))

    if C.PY2:
        s = unicodedata.normalize('NFKD', s).encode("ascii", "ignore")
    else:
        s = unicodedata.normalize('NFKD', s)
##    s = unicodedata.normalize('NFKD', s).encode("utf8", "ignore")
##    s = unicodedata.normalize('NFKD', try_decode(s))
##    Log(repr((type(s),s)))

    #s = unicode(s.encode("utf8"), 'utf8')
##    try: s = unicode(s.encode("ascii",'ignore'), 'utf8')
##    except: pass
##    Log(repr((type(s),s)))

##[\[\] ,\'\.\&\_\-]
## orignally only allow these     s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_\-]',' ',s))

    s = (re.sub(r'(?is)[\?]',C.QUESTION_MARK_SUBSTITUTE,s)) #this symbol is closest I can think of to subsitute
    if include_square_braces: #permit_square_braces
        s = (re.sub(r'(?is)[    \\\/\:\*\"\<\>\|]',' ',s))
    else:
        s = (re.sub(r'(?is)[\[\]\\\/\:\*\"\<\>\|]',' ',s))

##    Log(repr((type(s),s)))
    while '  ' in s:
        s = s.replace('  ', ' ')
    s = s.strip()
    return s
#__________________________________________________________________________
#
class Progress_Dialog(object):
    import threading, xbmcgui
    def __init__(
        self
        , title
        , message
        ):
        if threading.current_thread().name != "MainThread":
            self.dialog_progress = None
        self.dialog_progress = xbmcgui.DialogProgress()
        self.dialog_progress.create(title, message)
        self.percent = 0.01
        
    def iscanceled(self):
        if self.dialog_progress:
            return self.dialog_progress.iscanceled()
        else:
            return True
    def close(self):
        if not self.dialog_progress: return
        self.dialog_progress.close()
        self.dialog_progress = None
    def increment_percent(self, val=0.07):
        self.percent += val
        self.percent = min(self.percent,100)
        self.dialog_progress.update(int(self.percent))
        if self.percent == 100:
            self.percent = 75
    def percent(self):
        return self.percent
    def update(self
               ,percent
               ,message=None
               ,line2=None
               ,line3=None
               ):
        if not self.dialog_progress: return

        percent = min(percent,100)
##        Log(repr(percent),xbmc.LOGNONE)
        if not message:
            self.dialog_progress.update(int(percent))
            self.percent = percent
            return
        if line2 is None:
            self.dialog_progress.update(int(percent), message)
            self.percent = percent
            return
        if line3 is None:
            self.dialog_progress.update(int(percent), message, line2)
            self.percent = percent
            return
        
        #self.dialog_progress.update(int(percent), message, line2, line3) #pre kodi 19
        self.dialog_progress.update(int(percent), message+'[CR]'+line2+'[CR]'+line3) #post kodi 18
        self.percent = percent

        if self.percent == 100:
            self.percent = 75
#__________________________________________________________________
#
def Add_Refresh_Item(
    mode
    , name=C.STANDARD_MESSAGE_REFRESH
    , iconimage=C.refresh_icon
    , progress_dialog=None
    , end_directory=False
    , duration=C.STANDARD_DURATION_REFRESH
    ):
##    Kodi 18 needs these options for container.refresh to work
##        ,duration=C.STANDARD_DURATION_REFRESH 
##        ,Folder=False 
    if progress_dialog:
        if progress_dialog.iscanceled():
            end_directory = False
            addDir(
                name='Refresh this Cancelled Listing'
                ,url=C.DO_NOTHING_URL
                ,mode=mode
                ,iconimage=C.warning_icon
                ,duration=duration
                ,Folder=False 
                )
    if end_directory:
        addDir(
            name=name
            ,url=C.DO_NOTHING_URL
            ,mode=mode
            ,iconimage=iconimage
            ,duration=duration
            ,Folder=False 
            )
#__________________________________________________________________________
#
class ThreadWithStopEvent(threading.Thread):
    _stop_event = None
    def __init__(self, group=None, target=None, name=None
                 , args=(), kwargs=None, stop_event=None):
        super(ThreadWithStopEvent,self).__init__(group=group
                                                 , target=target, name=name
                                                 , args=args, kwargs=kwargs)
        self.args = args
        self.kwargs = kwargs
        self._stop_event = stop_event
#__________________________________________________________________
#
def Is_Online(
    server=C.DEFAULT_IS_ONLINE_SERVER_NAME
    , port=C.DEFAULT_IS_ONLINE_SERVER_PORT
    ):

    #todo: maybe change this to be proxy aware i.e. do a http get to server
    
    #use simplecache to store last time we did a network check
    # ... works like a static var across all threads
    cache_id = C.addon_id+'.Is_Online.'+"last_online_check"
    last_online_check = global_cache.get(cache_id)
    if last_online_check:
        Log("using cached Is_Online() "
##            , C.LOGWARNING
            )
        return True

    ip = None
    try:
        #xbmc function will not reliably report on IP when multiple are defined
        ip = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ip.settimeout(3)
        ip.connect((server,int(port)))
        ip = ip.getsockname()[0]
    except:
        LogR('no ip via getsockname'
##             , C.LOGWARNING
             )
        ip = xbmc.getIPAddress() #in case we don't have IP
    if (not ip) or ip.startswith('169.254') or ip.startswith('172.'):
        Log(u"reported ip is '{}'".format(ip), C.LOGWARNING)
        return False

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(3)
    try:
        qq = s.connect_ex((server, int(port)))
        if not qq == 0:
            raise Exception(qq)
    except:
        if C.DEBUG: traceback.print_exc()
        try:
            Sleep(1000)
            qq = s.connect_ex((server, int(port)))
            if not qq == 0:
                raise Exception(qq)
        except:
            return False
            raise
    finally:
        s.close()

    last_online_check = datetime.datetime.now()
    global_cache.set(
        endpoint = cache_id
        ,data = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ,expiration = datetime.timedelta(seconds=C.default_ISONLINE_cache_duration)
        )
    
    return True
#__________________________________________________________________
#
def crawl(q, all_method_results):
   #Log(repr(q.empty()))
    while not q.empty():
        work = q.get(timeout=C.WEBCRAWLER_THREAD_TIMEOUT)
       #Log(repr(work))
        index_for_result = work[0]
        method_to_call = work[1]
        keyword_arguments_for_method_to_call = work[2]
        import time
        t_start = time.time()
        try:
            single_method_result = method_to_call(**keyword_arguments_for_method_to_call)
        except Exception as ex:
            single_method_result = repr(ex)
        all_method_results[index_for_result] = single_method_result
        t_end = time.time()
        q.task_done()
       #Log("The time spent in thread {} is {}".format(index_for_result, t_end - t_start), C.LOGNONE)
        
    return True
#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
##        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
#__________________________________________________________________
# helper function to select an unused port on the host machine
def select_unused_port():
    import socket
    port = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('localhost', 0))
        addr, port = sock.getsockname()
        #sock.shutdown()
        sock.close()
    except Exception as ex:
        traceback.print_exc()
        port = 8666
    return port
#__________________________________________________________________________
# complicated PY3/PY2 compatible way of getting unix-style timestamp for UTCnow
def UTC_timestamp(asfloat=True):
    n = datetime.datetime.now() # utc is the target, but testing shows that utcnow() is wrong for py2 and py3
    #py3 has millisecond resolution, PY2 not - use a PY2 compatible style
    t = "{:.3f}".format(time.mktime(n.timetuple()) + n.microsecond / 1000000.0)
    if asfloat:
        return float(t)
    else:
        return t
#__________________________________________________________________________
#
def Normalize_Filespec(filespec):
##    LogR(os.name)
    #'posix' is android
    #python can get confused with smb://
##    if True :
    if os.name == 'nt':
        double_backslash = os.sep+os.sep
        filespec = os.path.normpath(filespec)
        if filespec.startswith("smb:"):
            filespec = filespec[len("smb:"):]
        filespec = os.path.normpath(filespec)
        filespec = filespec.replace(double_backslash, os.sep)
        if filespec.startswith(os.sep) and not filespec.startswith(double_backslash):
            filespec = os.sep + filespec
        if filespec.startswith(double_backslash) and (':' in filespec):
            #original path contained a port number; remove it for smb:
            filespec = re.sub(r"(\:[^\\]+)","",filespec)
    return filespec
#__________________________________________________________________________
#  dump stuff to xmbc.log so that i can debug
def LogFlush():
    return
##    LogR(sys.argv)
##    traceback.print_stack()
    Log("\nLogflush1", C.LOGNONE)
    if C.PY2: return
    import string
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    
    exit(0)
def FlushLog():
    LogFlush()
def Flush():
    LogFlush()
