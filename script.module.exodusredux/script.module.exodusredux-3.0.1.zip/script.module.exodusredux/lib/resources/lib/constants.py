#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import random
import sys
import os.path
import unicodedata
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

PY3 = sys.version_info >= (3, 0)
PY2 = not PY3

##xbmc.log(repr(sys.path),xbmc.LOGNONE)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
##xbmc.log(repr(sys.path),xbmc.LOGNONE)

if   PY3: from xbmcvfs import translatePath
elif PY2: from xbmc    import translatePath

if   PY3: from xbmcvfs import makeLegalFilename
elif PY2: from xbmc    import makeLegalFilename

import io
if PY2: import StringIO
if PY3: StringIO = io.StringIO

if PY3: text_type = str  
if PY2: text_type = unicode #this keyword will raise error in PY3

import importlib
if PY2: from imp import reload
if PY3: from importlib import reload

if PY2: import Queue
if PY3: import queue as Queue

if PY2: import cookielib
if PY3:     import http.cookiejar as cookielib

if PY2: import BaseHTTPServer
if PY3: import http.server as BaseHTTPServer

if PY2: from urllib2 import urlparse    
if PY3: from urllib import parse as urlparse

if PY3:     from urllib.parse import quote_plus
else:       from urllib import quote_plus

if PY2: from urllib import unquote_plus
if PY3: from urllib.parse import unquote_plus

if PY2: import SocketServer
if PY3: import socketserver as SocketServer

if PY2: from urllib import urlencode
if PY3: from urllib.parse import urlencode
    
if PY2:
    from urllib2 import unquote
    from urllib2 import unquote as urldecode

if PY3:
    from urllib.parse import unquote
    from urllib.parse import unquote as urldecode
    
if PY2: from urllib2 import quote
if PY3: from urllib.parse import quote

if PY2: import urllib2
if PY3: import urllib.request as urllib2

if PY2: import urllib2 as Request
if PY3: import urllib.request as Request

if PY2: from HTMLParser import HTMLParser
if PY3: from html.parser import HTMLParser

html_parser = HTMLParser()
if PY2:
    def unescape(s):
        return(html_parser.unescape(s))
if PY3: from html import unescape


##this_addon = xbmcaddon.Addon()
this_addon = xbmcaddon.Addon('plugin.video.exodusredux')

DEBUG = (this_addon.getSetting('debug').lower() == "true")
#2020   So DEBUG+all others in debug mode and only INFO, WARNING, ERROR and FATAL in normal.
LOGNONE = xbmc.LOGNONE
LOGINFO = xbmc.LOGNONE
LOGNOTICE =  12 #xbmc.LOGNOTICE
LOGERROR = xbmc.LOGERROR
LOGWARNING = xbmc.LOGWARNING

IE_USER_AGENT = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko'
FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/{}0101 Firefox/77.0'
OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.132 Safari/537.36 OPR/67.0.3575.97'
IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1'
ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.138 Mobile Safari/537.36'
EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.102 Safari/537.36 Edge/18.18363'
CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.182 Safari/537.36'
#SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15'
_USER_AGENTS = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT]

#USER_AGENT = _USER_AGENTS[random.randint(0, len(_USER_AGENTS)-1)].format(  random.randint(1111, 7777)  )
#USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/112.0"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0"

##xbmc.log(USER_AGENT,xbmc.LOGNONE)

def module_name():
    return sys._getframe(1).f_code.co_name


DEFAULT_HEADERS = {
    'User-Agent': USER_AGENT  
    
##    , 'Upgrade-Insecure-Requests': '1'
#    , 'DNT': '1'
    #, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    , 'Accept': '*/*'
##    , 'verifypeer': 'false'
    , 'Accept-Encoding': 'gzip, deflate'
    , 'Accept-Language': 'en-US,en;q=0.9'
    }
    #, 'verifypeer': 'false'
    # , 'Connection': 'close'
##if DEBUG:
##    DEFAULT_HEADERS['verifypeer'] = 'false'
##xbmc.log(repr(DEFAULT_HEADERS),xbmc.LOGNONE)

##xbmc.log(repr(sys),xbmc.LOGNONE)
##xbmc.log(repr(sys.argv),xbmc.LOGNONE)
if len(sys.argv) > 1:
    addon_handle = int(sys.argv[1])
else:
    addon_handle = -1

        
addon_id = str(this_addon.getAddonInfo('id'))
#xbmc.log("addon_id={}".format(addon_id), xbmc.LOGNONE)
addon_name = this_addon.getAddonInfo('name')
addon = this_addon
progress = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = translatePath(rootDir)
resDir = os.path.join(rootDir, 'resources')
imgDir = os.path.join(resDir, 'images')

default_icon = translatePath(os.path.join(rootDir, 'icon.png'))
profileDir = addon.getAddonInfo('profile')
profileDir = translatePath(profileDir) #.decode("utf-8")
if not os.path.exists(profileDir):
    os.makedirs(profileDir)
        
cookiePath = os.path.join(profileDir, 'cookies.lwp')

refresh_text_color = addon.getSetting('refresh_text_color').lower()
search_text_color = addon.getSetting('search_text_color').lower()
time_text_color = addon.getSetting('time_text_color').lower()
highlight_text_color = addon.getSetting('highlight_text_color').lower()
program_text_color = addon.getSetting('program_text_color').lower()
test_text_color = addon.getSetting('test_text_color').lower()

test_passed_text_color = highlight_text_color

icon_set = addon.getSetting('icon_set').lower()

##maximum_video_resolution = int(addon.getSetting("maximum_video_resolution"))#do this early so that it can be overriden later if necessary
maximum_video_resolution = 1080 #int(addon.getSetting("maximum_video_resolution"))#do this early so that it can be overriden later if necessary

DEFAULT_PLAYMODE = addon.getSetting('default_playmode').lower()  #allow playmode to be forced by input command, or use default from addon settings
PLAYMODE_F4MPROXY = 'f4mproxy'
PLAYMODE_INPUTSTREAM = 'inputstream'
PLAYMODE_DIRECT = 'direct'
PLAYMODE_NO_OPTIONS = "NO_OPTIONS"
PLAYMODE_VARIABLE = 'VARIABLE_MAXRES'

PLAYMODE_PROFILE_00 = 'profile_00' #the download profile
PLAYMODE_PROFILE_01 = 'profile_01'
PLAYMODE_PROFILE_02 = 'profile_02'
PLAYMODE_PROFILE_03 = 'profile_03'
PLAYMODE_PROFILE_04 = 'profile_04'
VALID_PLAYMODE_PROFILES = [PLAYMODE_PROFILE_00,PLAYMODE_PROFILE_01,PLAYMODE_PROFILE_02,PLAYMODE_PROFILE_03,PLAYMODE_PROFILE_04]

MAX_RECURSE_DEPTH = 10 #some sites will bann IP if too many requests

refresh_icon   = translatePath(os.path.join(rootDir, 'icon.png'))

if not os.path.exists(profileDir):
    os.makedirs(profileDir)

favoritesdb = os.path.join(profileDir, 'favorites.db')
downloadsdb = os.path.join(profileDir, 'downloads.db')

NO_ACTION_MODE = '0'
ROOT_INDEX_INDEX = '0'
ROOT_INDEX_SCENES = '1'
ROOT_INDEX_MOVIES = '2'
ROOT_INDEX_HENTAI = '3'
ROOT_INDEX_DOWNLOAD_FOLDER = '4'
ROOT_TEST_ALL = '5'
ROOT_INDEX_TUBES = '6'
ROOT_INDEX_CAMS = '7'
ROOT_SEARCH_ALL = '8'
ROOT_SERVICE_UPDATE = '9'
ROOT_SERVICE_SCAN_START = '10'
REFRESH_IMAGES_MODE = '11'#'898'
REFRESH_CONTAINER_MODE = '12'#'899'
FAVORITES_MODE = '13'#'900'
ROOT_INDEX_FAVORITES = '14'#'901'
ADD_KEYWORD = '15'#'902'
CLEAR_SEARCH = '16'#'903'
DELETE_KEYWORD = '17'#'904'
QWIK_SEARCH = '18'#'905'
ROOT_FRONT_PAGE = '19'#'906'
ROOT_MANAGE_DOWNLOADS = '20'#'911'
ROOT_STOP_DOWNLOAD = '21'#'912'
CONFIGURE_INPUTSTREAM = '9999'
CONFIGURE_THIS_ADDON = '9998'
CLEAN_TEXTURES = '9997'
CLEAN_SIMPLECACHE = '9996'



FLAG_RECURSE_NEXT_PAGES = '-1'
FLAG_USE_RESOLVER_ONLY = 'USE_RESOLVER_ONLY'

DEFAULT_NOTIFY_TIME = 2000

SPACING_FOR_TOPMOST = chr(4)
SPACING_FOR_NAMES =  '' #chr(17)
SPACING_FOR_NEXT = chr(127)

DEFAULT_PROFILE_NAME = 'profile_01'


DOWNLOAD_INDICATOR = addon_id+".downlading."
SCHEDULED_DOWNLOAD_INDICATOR = ''#"SCHEDULED/hls/" #no longer used

DO_NOTHING_URL = 'DO_NOTHING_URL' #url is required in the adddir function, but there are moments when I don't want to set it

GC_SEARCHLOOP_ITERATIONS = 2000
GC_SEARCHLOOP_PAUSE = 50


STANDARD_MESSAGE_CATEGORY_LABEL = u"{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color, '{}')
STANDARD_MESSAGE_NO_VIDEO_FILE = u"Not found or deleted '{}' {}"
STANDARD_MESSAGE_NO_COUNTRY = u"Page {} is not available in your country"
STANDARD_MESSAGE_FAILED_SEARCH=u"[COLOR {}]failed search[/COLOR] on {} [error: {}]".format(highlight_text_color, '{}', '{}')
STANDARD_MESSAGE_CANCELLED_SEARCH=u"[COLOR {}]Search was Cancelled. Listing may be incompete[/COLOR]".format(highlight_text_color, )
STANDARD_MESSAGE_NEXT_PAGE = u"{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, search_text_color, '{}')
STANDARD_MESSAGE_NP_INFO = u"np_info not found in url='{}'"
STANDARD_MESSAGE_CATEGORIES = u"{}[COLOR {}]Categories[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_SEARCH = u"{}[COLOR {}]Search[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_SEARCH_RECURSIVE = u"{}[COLOR {}]Search Recursive[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_REFRESH = u"{}[COLOR {}]Refresh[/COLOR]".format(SPACING_FOR_TOPMOST, refresh_text_color)
STANDARD_DURATION_REFRESH = 55*60*60+55*60+55  #a cool-looking size for this number

STANDARD_MESSAGE_UHD  = u" [COLOR {}]uhd[/COLOR]".format(search_text_color)
STANDARD_MESSAGE_FHD  = u" [COLOR {}]fhd[/COLOR]".format(refresh_text_color)
STANDARD_MESSAGE_HD   = u" [COLOR {}]hd[/COLOR]".format(time_text_color)
STANDARD_MESSAGE_NOHD = ""

VIDEO_NOT_AVAILABLE_WARNINGS = [
    "This video has been flagged for verification"
    ,"This page is not available in your country."
    ,"Video has been removed at the request of "
    ,"Video has been flagged"
    ,"this video is no longer available"
    ,"This Video Is Private"
    ,"this video is private."
    ,"This video does not exist."
    ]


FAVORITE_LISTING_TIMEOUT = 30 #seconds #how long to wait to discover if webcam model is online
WEBCRAWLER_THREAD_TIMEOUT = 10
MAX_WEBCRAWLER_THREADS = 60


TYPE_hls = 'hls'
TYPE_mp4 = 'mp4'
DOWNLOAD_TYPES = (TYPE_hls, TYPE_mp4)

HLS_TYPE_1 = 'f4mproxy'
HLS_TYPE_2 = 'flv-application/octet-stream'
HLS_TYPE_3 = 'application/vnd.apple.mpegurl'
HLS_TYPE_4 = 'application/x-mpegurl'
HLS_TYPE_5 = 'video/mpeg'
HLS_TYPE_6 = 'video/mp2t'
HLS_DOWNLOAD = [HLS_TYPE_1,HLS_TYPE_2,HLS_TYPE_3,HLS_TYPE_4,HLS_TYPE_5,HLS_TYPE_6]

URL_REQUEST_GET = "GET"
URL_REQUEST_HEAD = "HEAD"
URL_REQUESTS = [URL_REQUEST_HEAD,URL_REQUEST_GET]

    
TESTING_LIST_NAME = 'test_list' #setting.xml key containing which sites we have 'tested' and when they 'tested' successfully

MODE_LIST_OFFSET = 1
MODE_PLAY_OFFSET = 2
MODE_CATEGORY_OFFSET = 3
MODE_SEARCH_OFFSET = 4
MODE_TEST_OFFSET = 5
MODE_ICON_OFFSET = 6

## keep all the MAIN_MODE for all the sites we support so that we know what is in use
# spaced 10 apart because [so far] at most most 5 items needed
MAIN_MODE_base_website     = '40'  #dev testing

#either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
# https://wiki.mozilla.org/CA/Included_Certificates
##if C.DEBUG: urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
#certPath = os.path.join(os.path.join(os.path.dirname(__file__), "websocket"),"cacert.2020-10-14.pem")
import certifi
certPath = certifi.where()

QUESTION_MARK_SUBSTITUTE = unicodedata.lookup('FULLWIDTH QUESTION MARK')

xbmc_version = xbmc.getInfoLabel('System.BuildVersion').split(' ')[0].split('.')
try:
    x2 = [] #deal with beta versions
    for x in xbmc_version:
        try:
            x2.append(int(x))
        except:
            x2.append(x)
    xbmc_version = x2
    #xbmc_version = [int(x) for x in xbmc_version]
except:
    raise
    pass

try: default_GETHTML_cache_duration = int(addon.getSetting("GETHTML_cache_duration"))
except: default_GETHTML_cache_duration = 300 #seconds
try: default_ISONLINE_cache_duration = int(addon.getSetting("ISONLINE_cache_duration"))
except: default_ISONLINE_cache_duration = 77 #seconds

DEFAULT_IS_ONLINE_SERVER_NAME = '1.1.1.1'
DEFAULT_IS_ONLINE_SERVER_PORT = '80'

SERVICE_FIRST_SLEEPTIME = 10 #seconds before service begins; long enough for other stuff to start

FILE_MANIPULATION_ATTEMPTS = 3
TIME_BEFORE_FILE_MANIPULATION = 1000 #milliseconds

bad_attributes =  ['thumb'
                   , 'label'
                   , 'imdb'
                   , 'fanart2'
                   , 'imdb_id'
                   , 'metacache'
                   , 'tvdb_id'
                   , 'next'
                   , 'poster3'
                   , 'trailer'
                   #, 'tmdb'
                   , 'tmdb_id'
                   #, 'playcount' #cleared so that value can be read in from database
                   , 'poster'
                   , 'tvdb'
                   , 'banner'
                   , 'fanart']

