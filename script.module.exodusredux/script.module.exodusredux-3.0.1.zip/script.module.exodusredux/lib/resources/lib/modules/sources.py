# -*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import datetime
import json
import random
import re
import sys
import time
import threading
import urllib


from openscrapers import sources as openscraper_sources

from resources.lib.constants import urlparse
from resources.lib.constants import urlencode
from resources.lib.constants import quote_plus
from resources.lib.constants import unquote_plus

import xbmc

from resources.lib.modules import (cleantitle, client, control, debrid,
                                   log_utils, source_utils, trakt, tvmaze,
                                   workers)

from resources.lib.modules.log_utils import log as Log
from resources.lib.modules.log_utils import logR as LogR
from resources.lib import constants as C

from resources.lib.modules import downloader

from resources.lib import player

                    
import traceback
import os


try:
    from sqlite3 import dbapi2 as database
except Exception:
    from pysqlite2 import dbapi2 as database

try:
    import resolveurl
except:
    traceback.print_exc()
    raise
    

monitor = xbmc.Monitor()


class sources:
    def __init__(self):
        self.getConstants()
        self.sources = []

    def play(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, meta, select):

        url = None

        try:

            items = self.getSources(title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered)
            if select is None:
                select = control.setting('hosts.mode')
            if not tvshowtitle is None:
                title = tvshowtitle

            if control.window.getProperty('PseudoTVRunning') == 'True':
                return control.resolve(int(sys.argv[1]), True, control.item(path=str(self.sourcesDirect(items))))

            if items and len(items) > 0:

                Log(repr(control.infoLabel('Container.PluginName')))
                if select == '1' and ('plugin' in control.infoLabel('Container.PluginName')):
                    control.window.clearProperty(self.itemProperty)
                    control.window.setProperty(self.itemProperty, json.dumps(items))
                    control.window.clearProperty(self.metaProperty)
                    control.window.setProperty(self.metaProperty, meta)

                    control.sleep(1000) #else a 'playback failed' notice occurs
                    
                    exe = 'Container.Update({}?action=addItem&title={})'.format(
                                           sys.argv[0]
                                            , quote_plus(title))
                    Log(repr(exe))
                    return control.execute(exe)

                elif select == '0' or select == '1':
                    url = self.sourcesDialog(items)

                else:
                    url = self.sourcesDirect(items)

            if url is None:
                return self.errorForSources()

            try:
                meta = json.loads(meta)
            except Exception:
                pass

##            from resources.lib.modules.player import player
            Log(repr((title, year, season, episode, imdb, tmdb, tvdb, url, meta)))
##            player().run(title, year, season, episode, imdb, tvdb, url, meta)
    
            
        except Exception:
            traceback.print_exc()
            pass

    def addItem(self, title):
        control.playlist.clear()

##        xbmc.executebuiltin( "Dialog.Close(busydialog)" )

        items = control.window.getProperty(self.itemProperty)
        items = json.loads(items)

        if items is None or len(items) == 0:
            control.idle()
            sys.exit()

        meta = control.window.getProperty(self.metaProperty)
        meta = json.loads(meta)
        #Log(repr(meta))
        meta['imdbnumber'] = meta['imdb']
        if not hasattr(meta, 'season'): meta['season'] = '0'
        if not hasattr(meta, 'episode'): meta['episode'] = '0'
        
##        # (Kodi bug?) [name,role] is incredibly slow on this directory, [name] is barely tolerable, so just nuke it for speed!
##        if 'cast' in meta: del(meta['cast'])

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        downloads = True if control.setting('downloads') == 'true' and not (control.setting(
            'movie.download.path') == '' or control.setting('tv.download.path') == '') else False

        systitle = sysname = quote_plus(title)
##        Log(repr(systitle))
##        sysname = '232'
##        systitle = '333333'

        if 'tvshowtitle' in meta and 'season' in meta and 'episode' in meta:
            sysname += quote_plus(' S%02dE%02d' % (int(meta['season']), int(meta['episode'])))
        elif 'year' in meta:
            sysname += quote_plus(' (%s)' % meta['year'])
##        Log(repr(systitle))
##        Log(repr(sysname))

        
        poster = meta['poster3'] if 'poster3' in meta else '0'
        if poster == '0':
            poster = meta['poster'] if 'poster' in meta else '0'

        fanart = meta['fanart2'] if 'fanart2' in meta else '0'
        if fanart == '0':
            fanart = meta['fanart'] if 'fanart' in meta else '0'

        thumb = meta['thumb'] if 'thumb' in meta else '0'
        if thumb == '0':
            thumb = poster
        if thumb == '0':
            thumb = fanart

        banner = meta['banner'] if 'banner' in meta else '0'
        if banner == '0':
            banner = poster

        if poster == '0':
            poster = control.addonPoster()
        if banner == '0':
            banner = control.addonBanner()
        if not control.setting('fanart') == 'true':
            fanart = '0'
        if fanart == '0':
            fanart = control.addonFanart()
        if thumb == '0':
            thumb = control.addonFanart()

        sysimage = quote_plus(poster.encode('utf-8'))

        downloadMenu = control.lang(32403).encode('utf-8')


        ##  Log(repr(meta))
        max_loops = 1000
        loop_count = 0
        was_changed = True
        while (was_changed == True)  and  (loop_count < max_loops) :
            loop_count = loop_count + 1
            was_changed = False
            for a in meta:
                if a == 'imdb':
                    was_changed = True
                    meta['imdbnumber'] = meta[a]
                    meta.pop(a)
                    break
                if a in C.bad_attributes:
                    was_changed = True
                    meta.pop(a)
                    break
                        
        for i in range(len(items)):

##            Log(repr(i),C.LOGNONE)
            try:
                label = items[i]['label']

                syssource = quote_plus(json.dumps([items[i]]))

                play_method = None
                play_profile = None
                sysurl = ('%s?action=playItem&title=%s&source=%s&play_method=%s&play_profile=%s&imdb=%s&season=%s&episode=%s' %
                            (sysaddon, systitle, syssource, play_method, play_profile, meta['imdbnumber'], meta['season'], meta['episode']))

                cm = []

                play_profile = None
                play_method = C.PLAYMODE_DIRECT
                menu_description = "Play {}".format(play_method.capitalize())
                cm.append((menu_description
                           , 'PlayMedia({}?action=playItem&title={}&image={}&source={}&play_method={}&play_profile={}&imdb={}&season={}&episode={})'.format(
                               sysaddon
                               , systitle
                               , sysimage
                               , syssource
                               , play_method
                               , play_profile
                               , meta['imdbnumber']
                               , meta['season']
                               , meta['episode']
                               )
                           ))
                play_profile = None
                play_method = C.PLAYMODE_INPUTSTREAM
                menu_description = "Play {}".format(play_method.capitalize())
                cm.append((menu_description, 'PlayMedia(%s?action=playItem&title=%s&image=%s&source=%s&play_method=%s&play_profile=%s&imdb=%s&season=%s&episode=%s)' %
                           (sysaddon, systitle, sysimage, syssource, play_method, play_profile, meta['imdbnumber'], meta['season'], meta['episode'])))
                play_profile = C.PLAYMODE_PROFILE_01
                play_method = C.PLAYMODE_F4MPROXY
                menu_description = "Play {} {}".format(play_method.capitalize(), C.addon.getSetting(play_profile + "_alias"))
                cm.append((menu_description, 'PlayMedia(%s?action=playItem&title=%s&image=%s&source=%s&play_method=%s&play_profile=%s&imdb=%s&season=%s&episode=%s)' %
                           (sysaddon, systitle, sysimage, syssource, play_method, play_profile, meta['imdbnumber'], meta['season'], meta['episode'])))
                play_profile = C.PLAYMODE_PROFILE_02
                play_method = C.PLAYMODE_F4MPROXY
                menu_description = "Play {} {}".format(play_method.capitalize(), C.addon.getSetting(play_profile + "_alias"))
                cm.append((menu_description, 'PlayMedia(%s?action=playItem&title=%s&image=%s&source=%s&play_method=%s&play_profile=%s&imdb=%s&season=%s&episode=%s)' %
                           (sysaddon, systitle, sysimage, syssource, play_method, play_profile, meta['imdbnumber'], meta['season'], meta['episode'])))
                play_profile = C.PLAYMODE_PROFILE_03
                play_method = C.PLAYMODE_F4MPROXY
                menu_description = "Play {} {}".format(play_method.capitalize(), C.addon.getSetting(play_profile + "_alias"))
                cm.append((menu_description, 'PlayMedia(%s?action=playItem&title=%s&image=%s&source=%s&play_method=%s&play_profile=%s&imdb=%s&season=%s&episode=%s)' %
                           (sysaddon, systitle, sysimage, syssource, play_method, play_profile, meta['imdbnumber'], meta['season'], meta['episode'])))


                if downloads is True:
                    play_profile = C.PLAYMODE_PROFILE_00
                    play_method = C.PLAYMODE_F4MPROXY
                    menu_description = downloadMenu
                    cm.append((menu_description, 'RunPlugin(%s?action=download&title=%s&image=%s&source=%s&play_method=%s&play_profile=%s&imdb=%s&season=%s&episode=%s)' %
                               (sysaddon, systitle, sysimage, syssource, play_method, play_profile, meta['imdbnumber'], meta['season'], meta['episode'])))


                item = control.item(label=label)
                
                item.setArt({'icon': thumb, 'thumb': thumb, 'poster': poster, 'banner': banner})
##                item.setProperty('Fanart_Image', fanart)
                item.addContextMenuItems(cm)

                meta['title'] = label #force usage of label when displaying source combined with kodi sorting being turned on
                

##                item.setInfo(type='Video', infoLabels=meta)
                if C.PY2:
                    item.setInfo(type='Video', infoLabels = meta)
                    video_streaminfo = {'codec': 'h264'}
                    item.addStreamInfo('video', video_streaminfo)
                else:
                    videoInfoTag = item.getVideoInfoTag()
                    for a in meta:
##                            Log(repr((a,meta[a])))
                        if a == "title": videoInfoTag.setTitle(meta[a])
                        if a == "originaltitle": videoInfoTag.setOriginalTitle(meta[a])
                        if a == "year": videoInfoTag.setYear(int(meta[a]))
                        if a == "premiered": videoInfoTag.setPremiered(meta[a])
##                        if a == "genre": videoInfoTag.setGenres(meta[a])
                        if a == "duration": videoInfoTag.setDuration(int(meta[a]))
                        if a == "playcount": videoInfoTag.setPlaycount(meta[a])
                    


                
                item.setProperty('IsPlayable', 'false')
                item.setMimeType('video/mp4') #prevent HEAD requests
                item.setContentLookup(False) #prevent HEAD requests
##                Log(repr((sysurl,)))
                control.addItem(handle=syshandle, url=sysurl, listitem=item, isFolder=False)
            except Exception:
                traceback.print_exc()
                pass

        control.content(syshandle, 'files')
        control.directory(syshandle, cacheToDisc=True)

    def playItem(
        self
        , title
        , source
        , play_method
        , play_profile
        , download=False
        , timeout=40
        ):
##        LogR(locals(),C.LOGNONE)
    
        is_alive_check = 0.5
        try:
            timeout = int(control.setting('scrapers.timeout.1'))
        except Exception:
            pass
        if timeout < 45: timeout=46
       
        try:
            meta = control.window.getProperty(self.metaProperty)
            if meta:
                meta = json.loads(meta)
            else:
                meta = {
                            'year':'2000'
                            ,'title': title
                            ,'plot': ''
                        }

            year = meta['year'] if 'year' in meta else None
            season = meta['season'] if 'season' in meta else None
            episode = meta['episode'] if 'episode' in meta else None

            imdb = meta['imdb'] if 'imdb' in meta else None
            tmdb = meta['tmdb'] if 'tmdb' in meta else None
            tvdb = meta['tvdb'] if 'tvdb' in meta else None

            next = []
            prev = []
            total = []

            



                   
            for i in range(1, 1000):
                try:
                    u = control.infoLabel('ListItem(%s).FolderPath' % str(i))
                    if u in total:
                        raise Exception()
                    total.append(u)
                    u = dict(urlparse.parse_qsl(u.replace('?', '')))
                    u = json.loads(u['source'])[0]
                    next.append(u)
                except Exception:
                    break
            for i in range(-1000, 0)[::-1]:
                try:
                    u = control.infoLabel('ListItem(%s).FolderPath' % str(i))
                    if u in total:
                        raise Exception()
                    total.append(u)
                    u = dict(urlparse.parse_qsl(u.replace('?', '')))
                    u = json.loads(u['source'])[0]
                    prev.append(u)
                except Exception:
                    break

            items = json.loads(source)
            items = [i for i in items+next+prev][:40]

            header = control.addonInfo('name')
            header2 = header.upper()

            progressDialog = control.progressDialog if control.setting(
                'progress.dialog') == '0' else control.progressDialogBG
            progressDialog.create(header, '')
            progressDialog.update(0)

            block = None

            for i in range(len(items)):
                try:
                    try:
                        if progressDialog.iscanceled():
                            break
                        progressDialog.update(int((100 / float(len(items))) * i), str(items[i]['label']), str(' '))
                    except Exception:
                        if C.PY2: progressDialog.update(int((100 / float(len(items))) * i), str(header2), str(items[i]['label']))
                        else: progressDialog.update(int((100 // float(len(items))) * i), str(header2) + str(items[i]['label']))
                    if items[i]['source'] == block:
                        raise Exception()

                    w = workers.Thread(self.sourcesResolve, items[i])
                    w.start()

                    if items[i].get('source') in self.hostcapDict:
                        offset = timeout * 3 #hosts with captcha get 3x longer to respond
                    else:
                        offset = 0

                    m = ''

                    for x in range(3600):
                        try:
                            if monitor.abortRequested():
                                return sys.exit()
                            if progressDialog.iscanceled():
                                return progressDialog.close()
                        except Exception:
                            pass

                        k = control.condVisibility('Window.IsActive(virtualkeyboard)')
                        if k:
                            m += '1'
                            m = m[-1]
                        if (  (w.is_alive() is False) or (x > (timeout + offset) )) and not k:
                            break
                        k = control.condVisibility('Window.IsActive(yesnoDialog)')
                        if k:
                            m += '1'
                            m = m[-1]
                        if (w.is_alive() is False or (x > (timeout + offset))) and not k:
                            break
                        time.sleep(is_alive_check)

                    for x in range(int(timeout/is_alive_check)): #check timeout/0.5 seconds for a resposive resolver
                        try:
                            if monitor.abortRequested():
                                return sys.exit()
                            if progressDialog.iscanceled():
                                return progressDialog.close()
                        except Exception:
                            pass

                        if m == '':
                            break
                        if w.is_alive() is False:
                            break
                        time.sleep(is_alive_check)

                    if w.is_alive() is True:
                        block = items[i]['source']

                    if self.url is None:
                        continue
                        raise Exception()

                    try:
                        progressDialog.close()
                    except Exception:
                        pass

                    control.sleep(200)
                    control.execute('Dialog.Close(virtualkeyboard)')
                    control.execute('Dialog.Close(yesnoDialog)')


                    m_title = meta['title'] if 'title' in meta else title
                    m_title = meta['tvshowtitle'] if 'tvshowtitle' in meta else m_title

##                    traceback.print_stack()
            

                    download_pathspec = downloader.Normalize_Filespec(control.transPath(control.setting('tv.download.path')))
                    LogR(download_pathspec)
                    LogR(title)
                    if C.PY2:
                        download_pathspec = os.path.join(download_pathspec, title.translate(None, r'\/:*?"<>|').strip('.'))
                    else:
                        tt = str.maketrans({":":"","?":"","\\":"","/":"","*":"","\"":"","<":"",">":"","|":""})
                        download_pathspec = os.path.join(download_pathspec, title.translate(tt).strip('.'))                    
                    
                    if season is not None and episode is not None:
                        m_name        = u"{} s{:02d}e{:02d}".format(m_title, int(season), int(episode))
                        download_pathspec = os.path.join(download_pathspec,  'Season {}'.format(int(season)))
                    else:
                        m_name        = u"{} {}".format(m_title, meta['year'])


                    download_type = downloader.determine_download_type(self.url)
                    Log("download_type='{}'".format(download_type)  )                    
                    if download_type in C.HLS_DOWNLOAD:
                        download_name = m_name + u'.ts'
                    else:
                        play_method = C.PLAYMODE_DIRECT
                        download_name = m_name + u'.mp4'
                    Log("play_method='{}'".format(play_method)  )                    

                    download_filespec = os.path.join(download_pathspec, downloader.Clean_Filename(download_name   ))
                    Log(u"download_filespec='{}'".format(download_filespec))

                    Log("download='{}'".format(repr(download)) )
                    if download == False:
                        Log("download='{}'".format(repr(download)) )
                        if play_method == 'falsedasdf': #C.PLAYMODE_DIRECT :
                            Log("play_method='{}'".format(repr(play_method)))
##                            from resources.lib.modules.player import player
                            Log(repr((title
                                         , year
                                         , season
                                         , episode
                                         , imdb
                                         , tmdb
                                         , tvdb
                                         , self.url
                                         , meta)))
##                            player().run(title
##                                         , year
##                                         , season
##                                         , episode
##                                         , imdb
##                                         , tmdb
##                                         , tvdb
##                                         , self.url
##                                         , meta)
                            
                        else:
                            Log("play_method='{}'".format(repr(play_method)))
                            playvid(
                                self.url
                                    , name=m_name
                                    , download=None
                                    , description=m_title + ":" + meta['title']  + '[CR]' +  meta['plot']  + '[CR]' +  self.url
                                    , playmode_string= play_method
                                    , play_profile = play_profile
                                    , download_filespec = download_filespec
                                    )
                    else:
                        downloader.downloadVideo(
                            url = self.url
                            , name = download_name
                            , download_path = download_filespec
                            , mode=0
                            , url_factory=''
                            , icon_URI = ''
                            )


                    return self.url
                except Exception:
                    traceback.print_exc()
                    raise
                finally:
                    pass
            try:
                progressDialog.close()
            except:
                pass

            self.errorForSources()
        except Exception:
            Log("playItem(self, title, source, play_method, play_profile, download=False):", xbmc.LOGNONE)
            traceback.print_exc()
##            raise
##            pass

    def getSources(self, title, year, imdb, tmdb, tvdb, season, episode, tvshowtitle, premiered, quality='HD', timeout=30):
##        Log(control.myName()); LogR(locals())

        progressDialog = control.progressDialog if control.setting('progress.dialog') == '0' else control.progressDialogBG
        progressDialog.create(control.addonInfo('name'), '')
        progressDialog.update(0)
    
        self.prepareSources()
    
        sourceDict = self.sourceDict
##        LogR(sourceDict)
        
        progressDialog.update(0, control.lang(32600).encode('utf-8'))

        if tvshowtitle is None: content = 'movie'
        else: content = 'episode'
        
        if content == 'movie':
            sourceDict = [  (i[0], i[1], getattr(i[1], 'movie', None)) for i in sourceDict]
            
            genres = trakt.getGenre('movie', 'imdb', imdb)
        else:
            sourceDict = [(i[0], i[1], getattr(i[1], 'tvshow', None)) for i in sourceDict]
            genres = trakt.getGenre('show', 'tvdb', tvdb)
            if tmdb in [ u'None', None]:
                ids = trakt.IdLookup('show', 'tvdb', tvdb)
                if 'tmdb' in ids: tmdb = ids['tmdb']
##        LogR(sourceDict)


        
        sourceDict = [(i[0], i[1], i[2]) for i in sourceDict if not hasattr(i[1], 'genre_filter')
                      or not i[1].genre_filter or any(x in i[1].genre_filter for x in genres)]

        sourceDict = [(i[0], i[1]) for i in sourceDict if not i[2] is None]


        language = self.getLanguage()
        sourceDict = [(i[0], i[1], i[1].language) for i in sourceDict]
        sourceDict = [(i[0], i[1]) for i in sourceDict if any(x in i[2] for x in language)]


        
        try:
            sourceDict = [(i[0], i[1], control.setting('provider.' + i[0])) for i in sourceDict]
        except Exception:
            sourceDict = [(i[0], i[1], 'true') for i in sourceDict]
        sourceDict = [(i[0], i[1]) for i in sourceDict if not i[2] == 'false']

        sourceDict = [(i[0], i[1], i[1].priority) for i in sourceDict]

        random.shuffle(sourceDict)
        sourceDict = sorted(sourceDict, key=lambda i: i[2])

     

        threads = []

        if content == 'movie':
            if C.PY2:
                title = self.getTitle(title.decode('utf8').encode('ascii', "ignore"))
            else:
                title = self.getTitle(title)
            localtitle = self.getLocalTitle(title, imdb, tvdb, content)
            aliases = self.getAliasTitles(imdb, localtitle, content, year)
            for i in sourceDict:
                threads.append(workers.Thread(self.getMovieSource
                                              , title
                                              , localtitle
                                              , aliases
                                              , year
                                              , imdb
                                              , tmdb
                                              , i[0]
                                              , i[1])
                               )
        else:
            tvshowtitle = self.getTitle(tvshowtitle)
            localtvshowtitle = self.getLocalTitle(tvshowtitle, imdb, tvdb, content)
            aliases = self.getAliasTitles(imdb, localtvshowtitle, content, year)
            Log(u"localtvshowtitle={}".format(repr(localtvshowtitle)))            
            Log(u"aliases={}".format(repr(aliases)))
            # thexem Disabled on 11/11/17 due to hang. Should be checked in the future and possible enabled again.
            # season, episode = thexem.thexem(tvdb, season, episode)
            for i in sourceDict:
##                LogR(i)
                threads.append(workers.Thread(self.getEpisodeSource
                                              , title
                                              , year
                                              , imdb
                                              , tmdb
                                              , tvdb
                                              , season
                                              , episode
                                              , tvshowtitle
                                              , localtvshowtitle
                                              , aliases
                                              , premiered
                                              , i[0]
                                              , i[1]
                                              )
                               )

        s = [i[0] + (i[1],) for i in zip(sourceDict, threads)]
        s = [(i[3].getName(), i[0], i[2]) for i in s]

        mainsourceDict = [i[0] for i in s if i[2] == 0]
        sourcelabelDict = dict([(i[0], i[1].upper()) for i in s])

        [i.start() for i in threads]

        string1 = control.lang(32404)
        if C.PY2: string1 = string1.encode('utf-8')
        string2 = control.lang(32405)
        if C.PY2: string2 = string2.encode('utf-8')
        string3 = control.lang(32406)
        if C.PY2: string3 = string3.encode('utf-8')

        string4 = control.lang(32601).encode('utf-8')
        string4 = control.lang(32601)
        if C.PY2: string4 = string4.encode('utf-8')

        string5 = control.lang(32602).encode('utf-8')
        string5 = control.lang(32602)
        if C.PY2: string5 = string5.encode('utf-8')

        string6 = control.lang(32606).encode('utf-8')
        string6 = control.lang(32606)
        if C.PY2: string6 = string6.encode('utf-8')

        string7 = control.lang(32607).encode('utf-8')
        string7 = control.lang(32607)
        if C.PY2: string7 = string7.encode('utf-8')


        try:
            timeout = int(control.setting('scrapers.timeout.1'))
        except Exception:
            pass

        quality = control.setting('hosts.quality')
        if quality == '':
            quality = '0'

        line1 = line2 = line3 = ""

        debrid_only = control.setting('debrid.only')

        pre_emp =  control.setting('preemptive.termination')
        pre_emp_limit = control.setting('preemptive.limit')

        source_4k = d_source_4k = 0
        source_1080 = d_source_1080 = 0
        source_720 = d_source_720 = 0
        source_sd = d_source_sd = 0
        total = d_total = 0

        debrid_list = debrid.debrid_resolvers
        debrid_status = debrid.status()

        total_format = '[COLOR %s][B]%s[/B][/COLOR]'
        pdiag_format = ' 4K: %s | 1080p: %s | 720p: %s | SD: %s | %s: %s'.split('|')
        pdiag_bg_format = '4K:%s(%s)|1080p:%s(%s)|720p:%s(%s)|SD:%s(%s)|T:%s(%s)'.split('|')

        for i in range(0, 4 * timeout):
            if str(pre_emp) == 'true':
                if quality in ['0','1']:
                    if (source_1080 + d_source_1080) >= int(pre_emp_limit): break
                elif quality in ['2']:
                    if (source_720 + d_source_720) >= int(pre_emp_limit): break
                elif quality in ['3']:
                    if (source_sd + d_source_sd) >= int(pre_emp_limit): break
                else:
                    if (source_sd + d_source_sd) >= int(pre_emp_limit): break

            try:
                if monitor.abortRequested():
                    Log("warning xbmc.abortRequested")
                    for t in threads:
                        t.stop()

                    return sys.exit()

                try:
                    if progressDialog.iscanceled():
                        break
                except Exception:
                    pass

                if len(self.sources) > 0:
                    if quality in ['0']:
                        source_4k = len([e for e in self.sources if e['quality'] == '4K' and e['debridonly'] is False])
                        source_1080 = len([e for e in self.sources if e['quality'] in [
                                          '1440p', '1080p'] and e['debridonly'] is False])
                        source_720 = len([e for e in self.sources if e['quality'] in [
                                         '720p', 'HD'] and e['debridonly'] is False])
                        source_sd = len([e for e in self.sources if e['quality'] == 'SD' and e['debridonly'] is False])
                    elif quality in ['1']:
                        source_1080 = len([e for e in self.sources if e['quality'] in [
                                          '1440p', '1080p'] and e['debridonly'] is False])
                        source_720 = len([e for e in self.sources if e['quality'] in [
                                         '720p', 'HD'] and e['debridonly'] is False])
                        source_sd = len([e for e in self.sources if e['quality'] == 'SD' and e['debridonly'] is False])
                    elif quality in ['2']:
                        source_1080 = len([e for e in self.sources if e['quality']
                                           in ['1080p'] and e['debridonly'] is False])
                        source_720 = len([e for e in self.sources if e['quality'] in [
                                         '720p', 'HD'] and e['debridonly'] is False])
                        source_sd = len([e for e in self.sources if e['quality'] == 'SD' and e['debridonly'] is False])
                    elif quality in ['3']:
                        source_720 = len([e for e in self.sources if e['quality'] in [
                                         '720p', 'HD'] and e['debridonly'] is False])
                        source_sd = len([e for e in self.sources if e['quality'] == 'SD' and e['debridonly'] is False])
                    else:
                        source_sd = len([e for e in self.sources if e['quality'] == 'SD' and e['debridonly'] is False])

                    total = source_4k + source_1080 + source_720 + source_sd

                    if debrid_status:
                        if quality in ['0']:
                            for d in debrid_list:
                                d_source_4k = len([e for e in self.sources if e['quality']
                                                   == '4K' and d.valid_url(str(e['url']), e['source'])])
                                d_source_1080 = len([e for e in self.sources if e['quality'] in [
                                                    '1440p', '1080p'] and d.valid_url(str(e['url']), e['source'])])
                                d_source_720 = len([e for e in self.sources if e['quality'] in [
                                                   '720p', 'HD'] and d.valid_url(str(e['url']), e['source'])])
                                d_source_sd = len([e for e in self.sources if e['quality']
                                                   == 'SD' and d.valid_url(str(e['url']), e['source'])])
                        elif quality in ['1']:
                            for d in debrid_list:
                                d_source_1080 = len([e for e in self.sources if e['quality'] in [
                                                    '1440p', '1080p'] and d.valid_url(str(e['url']), e['source'])])
                                d_source_720 = len([e for e in self.sources if e['quality'] in [
                                                   '720p', 'HD'] and d.valid_url(str(e['url']), e['source'])])
                                d_source_sd = len([e for e in self.sources if e['quality']
                                                   == 'SD' and d.valid_url(str(e['url']), e['source'])])
                        elif quality in ['2']:
                            for d in debrid_list:
                                d_source_1080 = len([e for e in self.sources if e['quality'] in [
                                                    '1080p'] and d.valid_url(str(e['url']), e['source'])])
                                d_source_720 = len([e for e in self.sources if e['quality'] in [
                                                   '720p', 'HD'] and d.valid_url(str(e['url']), e['source'])])
                                d_source_sd = len([e for e in self.sources if e['quality']
                                                   == 'SD' and d.valid_url(str(e['url']), e['source'])])
                        elif quality in ['3']:
                            for d in debrid_list:
                                d_source_720 = len([e for e in self.sources if e['quality'] in [
                                                   '720p', 'HD'] and d.valid_url(str(e['url']), e['source'])])
                                d_source_sd = len([e for e in self.sources if e['quality']
                                                   == 'SD' and d.valid_url(str(e['url']), e['source'])])
                        else:
                            for d in debrid_list:
                                d_source_sd = len([e for e in self.sources if e['quality']
                                                   == 'SD' and d.valid_url(str(e['url']), e['source'])])

                        d_total = d_source_4k + d_source_1080 + d_source_720 + d_source_sd

                if debrid_status:
                    d_4k_label = total_format % (
                        'red', d_source_4k) if d_source_4k == 0 else total_format % (
                        'lime', d_source_4k)
                    d_1080_label = total_format % (
                        'red', d_source_1080) if d_source_1080 == 0 else total_format % (
                        'lime', d_source_1080)
                    d_720_label = total_format % (
                        'red', d_source_720) if d_source_720 == 0 else total_format % (
                        'lime', d_source_720)
                    d_sd_label = total_format % (
                        'red', d_source_sd) if d_source_sd == 0 else total_format % (
                        'lime', d_source_sd)
                    d_total_label = total_format % (
                        'red', d_total) if d_total == 0 else total_format % (
                        'lime', d_total)

                source_4k_label = total_format % (
                    'red', source_4k) if source_4k == 0 else total_format % (
                    'lime', source_4k)
                source_1080_label = total_format % (
                    'red', source_1080) if source_1080 == 0 else total_format % (
                    'lime', source_1080)
                source_720_label = total_format % (
                    'red', source_720) if source_720 == 0 else total_format % (
                    'lime', source_720)
                source_sd_label = total_format % (
                    'red', source_sd) if source_sd == 0 else total_format % (
                    'lime', source_sd)
                source_total_label = total_format % ('red', total) if total == 0 else total_format % ('lime', total)

                if (i / 2) < timeout:
                    try:
                        mainleft = [sourcelabelDict[x.getName()] for x in threads if x.is_alive() is
                                    True and x.getName() in mainsourceDict]
                        info = [sourcelabelDict[x.getName()] for x in threads if x.is_alive() is True]
                        if i >= timeout and len(mainleft) == 0 and len(self.sources) >= 100 * len(info):
                            break  # improve responsiveness
                        if debrid_status:
                            if quality in ['0']:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = ('%s:' + '|'.join(pdiag_format)) % (string6, d_4k_label,
                                                                                d_1080_label, d_720_label, d_sd_label, str(string4), d_total_label)
                                    line2 = ('%s:' + '|'.join(pdiag_format)) % (string7, source_4k_label,
                                                                                source_1080_label, source_720_label, source_sd_label, str(string4),
                                                                                source_total_label)
##                                    print line1, line2
                                else:
                                    line1 = '|'.join(
                                        pdiag_bg_format[: -1]) % (
                                        source_4k_label, d_4k_label, source_1080_label, d_1080_label, source_720_label,
                                        d_720_label, source_sd_label, d_sd_label)
                            elif quality in ['1']:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = (
                                        '%s:' + '|'.join(pdiag_format[1:])) % (string6, d_1080_label, d_720_label, d_sd_label, str(string4), d_total_label)
                                    line2 = (
                                        '%s:' + '|'.join(pdiag_format[1:])) % (
                                        string7, source_1080_label, source_720_label, source_sd_label, str(string4),
                                        source_total_label)
                                else:
                                    line1 = '|'.join(
                                        pdiag_bg_format[1:]) % (
                                        source_1080_label, d_1080_label, source_720_label, d_720_label, source_sd_label,
                                        d_sd_label, source_total_label, d_total_label)
                            elif quality in ['2']:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = (
                                        '%s:' + '|'.join(pdiag_format[1:])) % (string6, d_1080_label, d_720_label, d_sd_label, str(string4), d_total_label)
                                    line2 = (
                                        '%s:' + '|'.join(pdiag_format[1:])) % (
                                        string7, source_1080_label, source_720_label, source_sd_label, str(string4),
                                        source_total_label)
                                else:
                                    line1 = '|'.join(
                                        pdiag_bg_format[1:]) % (
                                        source_1080_label, d_1080_label, source_720_label, d_720_label, source_sd_label,
                                        d_sd_label, source_total_label, d_total_label)
                            elif quality in ['3']:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = ('%s:' + '|'.join(pdiag_format[2:])) % (string6,
                                                                                    d_720_label, d_sd_label, str(string4), d_total_label)
                                    line2 = (
                                        '%s:' + '|'.join(pdiag_format[2:])) % (string7, source_720_label, source_sd_label, str(string4), source_total_label)
                                else:
                                    line1 = '|'.join(
                                        pdiag_bg_format[2:]) % (
                                        source_720_label, d_720_label, source_sd_label, d_sd_label, source_total_label,
                                        d_total_label)
                            else:
                                if not progressDialog == control.progressDialogBG:
                                    line1 = ('%s:' + '|'.join(pdiag_format[3:])) % (string6,
                                                                                    d_sd_label, str(string4), d_total_label)
                                    line2 = ('%s:' + '|'.join(pdiag_format[3:])) % (string7,
                                                                                    source_sd_label, str(string4), source_total_label)
                                else:
                                    line1 = '|'.join(
                                        pdiag_bg_format[3:]) % (
                                        source_sd_label, d_sd_label, source_total_label, d_total_label)
                        else:
                            if quality in ['0']:
                                line1 = '|'.join(pdiag_format) % (source_4k_label, source_1080_label,
                                                                  source_720_label, source_sd_label, str(string4), source_total_label)
                            elif quality in ['1']:
                                line1 = '|'.join(
                                    pdiag_format[1:]) % (
                                    source_1080_label, source_720_label, source_sd_label, str(string4),
                                    source_total_label)
                            elif quality in ['2']:
                                line1 = '|'.join(
                                    pdiag_format[1:]) % (
                                    source_1080_label, source_720_label, source_sd_label, str(string4),
                                    source_total_label)
                            elif quality in ['3']:
                                line1 = '|'.join(
                                    pdiag_format[2:]) % (
                                    source_720_label, source_sd_label, str(string4),
                                    source_total_label)
                            else:
                                line1 = '|'.join(pdiag_format[3:]) % (source_sd_label, str(string4), source_total_label)

                        if debrid_status:
                            if len(info) > 6:
                                line3 = string3 % (str(len(info)))
                            elif len(info) > 0:
                                line3 = string3 % (', '.join(info))
                            else:
                                break
                            percent = int(100 * float(i) / (2 * timeout) + 0.5)
                            if not progressDialog == control.progressDialogBG:
                                progressDialog.update(max(1, percent), line1 + '[CR]' + line2 + '[CR]' +  line3)
                            else:
                                progressDialog.update(max(1, percent), line1 + '[CR]' + line3)
                        else:
##                            LogR(info)
##                            LogR(string3)
                            if len(info) > 6:
                                line2 = string3 % (str(len(info)))
                            elif len(info) > 0:
                                line2 = string3 % (u', '.join(info))
                            else:
                                break
                            percent = int(100 * float(i) / (2 * timeout) + 0.5)
                            if C.PY2:
                                progressDialog.update(max(1, percent), line1, line2)
                            else:
                                progressDialog.update(max(1, percent), line1 + '[CR]' + line2)
                                
                    except Exception:
                        traceback.print_exc()
                else:
                    try:
                        mainleft = [sourcelabelDict[x.getName()] for x in threads if x.is_alive() is
                                    True and x.getName() in mainsourceDict]
                        info = mainleft
                        if debrid_status:
                            if len(info) > 6:
                                line3 = 'Waiting for: %s' % (str(len(info)))
                            elif len(info) > 0:
                                line3 = 'Waiting for: %s' % (', '.join(info))
                            else:
                                break
                            percent = int(100 * float(i) / (2 * timeout) + 0.5) % 100
                            if not progressDialog == control.progressDialogBG:
                                progressDialog.update(max(1, percent), line1 + '[CR]' +  line2 + '[CR]' +  line3)
                            else:
                                progressDialog.update(max(1, percent), line1 + '[CR]' +  line3)
                        else:
                            if len(info) > 6:
                                line2 = 'Waiting for: %s' % (str(len(info)))
                            elif len(info) > 0:
                                line2 = 'Waiting for: %s' % (', '.join(info))
                            else:
                                break
                            percent = int(100 * float(i) / (2 * timeout) + 0.5) % 100
                            progressDialog.update(max(1, percent), line1  + '[CR]' +  line2)
                    except Exception:
                        traceback.print_exc()
                        break

                time.sleep(0.2)
            except Exception:
                traceback.print_exc()
                raise
                pass

        for t in threads:
            try:
                t.stop()
            except Exception:
                pass


        try:
            progressDialog.close()
        except Exception:
            pass

##        Log("self.sources={}".format(repr(self.sources)))
        self.sourcesFilter()
##        Log("self.sources={}".format(repr(self.sources)))
##        raise Exception()
        return self.sources

    def prepareSources(self):

        try:
            control.makeFile(control.dataPath)
            self.sourceFile = control.providercacheFile
            dbcon = database.connect(self.sourceFile)
            dbcur = dbcon.cursor()
            dbcur.execute(
                "CREATE TABLE IF NOT EXISTS rel_url ("
                "source TEXT, "
                "imdb_id TEXT, "
                "season TEXT, "
                "episode TEXT, "
                "rel_url TEXT, "
                "UNIQUE(source, imdb_id, season, episode)"
                ");")
            dbcur.execute(
                "CREATE TABLE IF NOT EXISTS rel_src ("
                "source TEXT, "
                "imdb_id TEXT, "
                "season TEXT, "
                "episode TEXT, "
                "hosts TEXT, "
                "added TEXT, "
                "UNIQUE(source, imdb_id, season, episode)"
                ");")
        except Exception:
##            traceback.print_exc()
##            raise
            pass

    def getMovieSource(self, title, localtitle, aliases, year, imdb, tmdb, source, call):
        
        try:
            dbcon = database.connect(self.sourceFile)
            dbcur = dbcon.cursor()
        except Exception:
            traceback.print_exc()
            raise
            pass

        ''' Fix to stop items passed with a 0 IMDB id pulling old unrelated sources from the database. '''
        if imdb == '0':
            try:
                dbcur.execute(
                    "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                    (source, imdb, '', ''))
                dbcur.execute(
                    "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                    (source, imdb, '', ''))
                dbcon.commit()
            except Exception:
                traceback.print_exc()
                raise

                pass
        ''' END '''

        try:
            sources = []
            query = "SELECT * FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" % (source, imdb, '', '')
            dbcur.execute(query)
            match = dbcur.fetchone()
            if not match: raise EOFError()
            t1 = int(re.sub('[^0-9]', '', str(match[5])))
            t2 = int(datetime.datetime.now().strftime("%Y%m%d%H%M"))
            update = abs(t2 - t1) > 60
            if update is False:
                if C.PY2: sources = eval(match[4].encode('utf-8'))
                else:   sources = eval(match[4])
                return self.sources.extend(sources)
        except EOFError:
            pass #probably not in database
        except Exception: 
            traceback.print_exc()
            pass

        try:
            url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            url = dbcur.fetchone()
            url = eval(url[4].encode('utf-8'))
        except Exception:
            #if C.DEBUG: traceback.print_exc()
            pass

        try:
            if url is None:
                url = call.movie(imdb, tmdb, title, localtitle, aliases, year)
            if url is None: raise StopIteration(call.__module__)
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            dbcur.execute("INSERT INTO rel_url Values (?, ?, ?, ?, ?)", (source, imdb, '', '', repr(url)))
            dbcon.commit()
        except StopIteration:
            #raise
            pass
        except Exception:
            if C.DEBUG:
                Log('Exception from {}'.format(repr(call.__module__)))
                traceback.print_exc()
            pass

        try:
            sources = []
            sources = call.sources(url, self.hostDict, self.hostprDict)
            if sources is None or sources == []: raise StopIteration(call.__module__)
            sources = [json.loads(t) for t in set(json.dumps(d, sort_keys=True) for d in sources)]
            for i in sources:
                i.update({'provider': source})
            self.sources.extend(sources)
            dbcur.execute(
                "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            dbcur.execute("INSERT INTO rel_src Values (?, ?, ?, ?, ?, ?)", (source, imdb, '',
                                                                            '', repr(sources), datetime.datetime.now().strftime("%Y-%m-%d %H:%M")))
            dbcon.commit()
        except StopIteration:
            #raise
            pass
        except Exception:
            if C.DEBUG: traceback.print_exc()
            pass

    def getEpisodeSource(
            self, title, year, imdb, tmdb, tvdb
            , season, episode
            , tvshowtitle, localtvshowtitle, aliases, premiered, source
            , call):

        Log(__name__); LogR(locals())
        
        try:
            dbcon = database.connect(self.sourceFile)
            dbcur = dbcon.cursor()
        except Exception:
            pass

        try:
            sources = []
            dbcur.execute(
                "SELECT * FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, season, episode))
            match = dbcur.fetchone()
            
            t1 = int(re.sub('[^0-9]', '', str(match[5])))
            t2 = int(datetime.datetime.now().strftime("%Y%m%d%H%M"))
            update = abs(t2 - t1) > 60
            if update is False:
                sources = eval(match[4].encode('utf-8'))
                return self.sources.extend(sources)
        except Exception:
            pass

        try:
            url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            url = dbcur.fetchone()
            url = eval(url[4].encode('utf-8'))
        except Exception:
            pass

        try:
            if url is None:
                url = call.tvshow(imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year, season)
            if url is None: raise StopIteration(call.__module__)
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, '', ''))
            dbcur.execute("INSERT INTO rel_url Values (?, ?, ?, ?, ?)", (source, imdb, '', '', repr(url)))
            dbcon.commit()
        except StopIteration: #ignore when no reults
            Log('zero results from {}'.format(repr(call.__module__)))
            pass
        except Exception:
            if C.DEBUG:
                Log('Exception from {}'.format(repr(call.__module__)))
                traceback.print_exc()
            pass

        try:
            ep_url = None
            dbcur.execute(
                "SELECT * FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, season, episode))
            ep_url = dbcur.fetchone()
            ep_url = eval(ep_url[4].encode('utf-8'))
        except Exception:
            #if C.DEBUG: traceback.print_exc()
            pass

        try:
            if url is None: raise StopIteration()
            if ep_url is None:
                ep_url = call.episode(url, imdb, tmdb, tvdb, title, premiered, season, episode)
            if ep_url is None: raise StopIteration(call.__module__)
            dbcur.execute(
                "DELETE FROM rel_url WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, season, episode))
            dbcur.execute("INSERT INTO rel_url Values (?, ?, ?, ?, ?)", (source, imdb, season, episode, repr(ep_url)))
            dbcon.commit()
        except StopIteration: #ignore when no results
            Log('zero results from {}'.format(repr(call.__module__)))
            pass
        except Exception:
            if C.DEBUG:
                Log('Exception from {}'.format(repr(call.__module__)))
                traceback.print_exc()

            pass

        try:
            sources = []
            sources = call.sources(ep_url, self.hostDict, self.hostprDict)
            if sources is None or sources == []: raise StopIteration(call.__module__)
            sources = [json.loads(t) for t in set(json.dumps(d, sort_keys=True) for d in sources)]
            for i in sources: i.update({'provider': source})
            self.sources.extend(sources)
            dbcur.execute(
                "DELETE FROM rel_src WHERE source = '%s' AND imdb_id = '%s' AND season = '%s' AND episode = '%s'" %
                (source, imdb, season, episode))
            dbcur.execute("INSERT INTO rel_src Values (?, ?, ?, ?, ?, ?)", (source, imdb, season,
                                                                            episode, repr(sources), datetime.datetime.now().strftime("%Y-%m-%d %H:%M")))
            dbcon.commit()
        except StopIteration: #ignore when no reults
            Log('warning zero results from {}'.format(repr(call.__module__)))
            pass
        except Exception:
            if C.DEBUG:
                Log('Exception from {}'.format(repr(call.__module__)))
                traceback.print_exc()

            pass

    def alterSources(self, url, meta):
        try:
            if control.setting('hosts.mode') == '2':
                url += '&select=1'
            else:
                url += '&select=2'
            control.execute('RunPlugin(%s)' % url)
        except Exception:
            pass

    def clearSources(self):

        try:
            control.makeFile(control.dataPath)
            dbcon = database.connect(control.providercacheFile)
            dbcur = dbcon.cursor()
            dbcur.execute("DROP TABLE IF EXISTS rel_src")
            dbcur.execute("DROP TABLE IF EXISTS rel_url")
            dbcur.execute("VACUUM")
            dbcon.commit()
            control.infoDialog(control.myName() + ' ' + control.lang(32408), sound=False, icon='INFO')
        except Exception:
##            raise
            pass

    def sourcesFilter(self):
        provider = control.setting('hosts.sort.provider')
        if provider == '':
            provider = 'false'

        debrid_only = control.setting('debrid.only')
        if debrid_only == '': 
            debrid_only = 'false'

        sortthemup = control.setting('torrent.sort.them.up')
        if sortthemup == '':
            sortthemup = 'false'

        quality = control.setting('hosts.quality')
        if quality == '':
            quality = '0'

        captcha = control.setting('hosts.captcha')
        if captcha == '':
            captcha = 'true'

        HEVC = control.setting('HEVC')

        random.shuffle(self.sources)

        if provider == 'true':
            self.sources = sorted(self.sources, key=lambda k: k['provider'])


        for i in self.sources:
            if 'checkquality' in i and i['checkquality'] is True:
                if not i['source'].lower() in self.hosthqDict and i['quality'] not in ['SD', 'SCR', 'CAM']:
                    i.update({'quality': 'SD'})

##        LogR(self.sources)
        
        local = [i for i in self.sources if 'local' in i and i['local'] is True]
        for i in local:
            i.update({'language': self._getPrimaryLang() or 'en'})
        self.sources = [i for i in self.sources if i not in local]

        filter = []
        filter += [i for i in self.sources if i['direct'] is True]
        filter += [i for i in self.sources if i['direct'] is False]
        self.sources = filter

        filter = []

        for d in debrid.debrid_resolvers:
            valid_hoster = set([i['source'] for i in self.sources])
            valid_hoster = [i for i in valid_hoster if d.valid_url('', i)]
            if sortthemup == 'true':
                filter += [dict(i.items() + [('debrid', d.name)]) for i in self.sources if str(i['url']).startswith('magnet:')]
                filter += [dict(i.items() + [('debrid', d.name)]) for i in self.sources if i['source'] in valid_hoster and 'magnet:' not in str(i['url'])]
            else:
                filter += [dict(i.items() + [('debrid', d.name)]) for i in self.sources if i['source'] in valid_hoster or str(i['url']).startswith('magnet:')]
#        filter += [i for i in self.sources if not i['source'].lower() in self.hostprDict and i['debridonly'] is False]
        if debrid_only == 'false' or  debrid.status() == False:
            filter += [i for i in self.sources if not i['source'].lower() in self.hostprDict and i['debridonly'] is False]
        self.sources = filter

        for i in range(len(self.sources)):
            q = self.sources[i]['quality']
            if q == 'HD':
                self.sources[i].update({'quality': '720p'})

        filter = []
        filter += local

##        LogR(self.sources)
        
        if quality in ['0']:
            filter += [i for i in self.sources if i['quality'] == '4K' and 'debrid' in i]
        if quality in ['0']:
            filter += [i for i in self.sources if i['quality'] == '4K' and 'debrid' not in i and 'memberonly' in i]
        if quality in ['0']:
            filter += [i for i in self.sources if i['quality'] == '4K' and 'debrid' not in i and 'memberonly' not in i]

        if quality in ['0', '1']:
            filter += [i for i in self.sources if i['quality'] == '1440p' and 'debrid' in i]
        if quality in ['0', '1']:
            filter += [i for i in self.sources if i['quality'] == '1440p' and 'debrid' not in i and 'memberonly' in i]
        if quality in ['0', '1']:
            filter += [i for i in self.sources if i['quality'] ==
                       '1440p' and 'debrid' not in i and 'memberonly' not in i]

        if quality in ['0', '1', '2']:
            filter += [i for i in self.sources if i['quality'] == '1080p' and 'debrid' in i]
        if quality in ['0', '1', '2']:
            filter += [i for i in self.sources if i['quality'] == '1080p' and 'debrid' not in i and 'memberonly' in i]
        if quality in ['0', '1', '2']:
            filter += [i for i in self.sources if i['quality'] ==
                       '1080p' and 'debrid' not in i and 'memberonly' not in i]

        if quality in ['0', '1', '2', '3']:
            filter += [i for i in self.sources if i['quality'] == '720p' and 'debrid' in i]
        if quality in ['0', '1', '2', '3']:
            filter += [i for i in self.sources if i['quality'] == '720p' and 'debrid' not in i and 'memberonly' in i]
        if quality in ['0', '1', '2', '3']:
            filter += [i for i in self.sources if i['quality'] ==
                       '720p' and 'debrid' not in i and 'memberonly' not in i]

##        LogR(self.sources)
        
        filter += [i for i in self.sources if i['quality'] in ['SD', 'SCR', 'CAM']]
        self.sources = filter

        if not captcha == 'true':
            filter = [i for i in self.sources if i['source'].lower() in self.hostcapDict and 'debrid' not in i]
            self.sources = [i for i in self.sources if i not in filter]

        filter = [i for i in self.sources if i['source'].lower() in self.hostblockDict and 'debrid' not in i]
        self.sources = [i for i in self.sources if i not in filter]

        multi = [i['language'] for i in self.sources]
        multi = [x for y, x in enumerate(multi) if x not in multi[:y]]
        multi = True if len(multi) > 1 else False

        if multi is True:
            self.sources = [i for i in self.sources if not i['language'] ==
                            'en'] + [i for i in self.sources if i['language'] == 'en']

        self.sources = self.sources[:4000]

        extra_info = control.setting('sources.extrainfo')

        prem_identify = control.setting('prem.identify')
        if prem_identify == '':
            prem_identify = 'blue'
        prem_identify = self.getPremColor(prem_identify)

        torr_identify = control.setting('torrent.identify')
        if torr_identify == '':
            torr_identify = 'magenta'
        torr_identify = self.getPremColor(torr_identify)

        for i in range(len(self.sources)):

            if extra_info == 'true':
                t = source_utils.getFileType(self.sources[i]['url'])
            else:
                t = None

            u = self.sources[i]['url']

            p = self.sources[i]['provider']

            q = self.sources[i]['quality']

            s = self.sources[i]['source']

            s = s.rsplit('.', 1)[0]

            l = self.sources[i]['language']

            try:
                f = (' | '.join(['[I]%s [/I]' % info.strip() for info in self.sources[i]['info'].split('|')]))
            except Exception:
                f = ''

            try:
                d = self.sources[i]['debrid']
            except Exception:
                d = self.sources[i]['debrid'] = ''

            if d.lower() == 'real-debrid':
                d = 'RD'

            if not d == '':
                label = '%02d | [B]%s | %s[/B] | ' % (int(i+1), d, p)
            else:
                label = '%02d | [B]%s[/B] | ' % (int(i+1), p)

            if multi is True and not l == 'en':
                label += '[B]%s[/B] | ' % l

            if t:
                if q in ['4K', '1440p', '1080p', '720p']:
                    label += '%s | [B][I]%s [/I][/B] | [I]%s[/I] | %s' % (s, q, t, f)
                elif q == 'SD':
                    label += '%s | %s | [I]%s[/I]' % (s, f, t)
                else:
                    label += '%s | %s | [I]%s [/I] | [I]%s[/I]' % (s, f, q, t)
            else:
                if q in ['4K', '1440p', '1080p', '720p']:
                    label += '%s | [B][I]%s [/I][/B] | %s' % (s, q, f)
                elif q == 'SD':
                    label += '%s | %s' % (s, f)
                else:
                    label += '%s | %s | [I]%s [/I]' % (s, f, q)
            label = label.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            label = re.sub(r'\[I\]\s+\[/I\]', ' ', label)
            label = re.sub(r'\|\s+\|', '|', label)
            label = re.sub(r'\|(?:\s+|)$', '', label)

            if d:
                if 'torrent' in s.lower():
                    if not torr_identify == 'nocolor':
                        self.sources[i]['label'] = ('[COLOR %s]' % (torr_identify)) + label.upper() + '[/COLOR]'
                    else:
                        self.sources[i]['label'] = label.upper()
                else:
                    if not prem_identify == 'nocolor':
                        self.sources[i]['label'] = ('[COLOR %s]' % (prem_identify)) + label.upper() + '[/COLOR]'
                    else:
                        self.sources[i]['label'] = label.upper()
            else:
                self.sources[i]['label'] = label.upper()

        try:
            if not HEVC == 'true':
                self.sources = [i for i in self.sources if 'HEVC' not in i['label']]
        except Exception:
            pass

        self.sources = [i for i in self.sources if 'label' in i]

        return self.sources

    def sourcesResolve(self, item, info=False):
        Log(control.myName()); LogR(locals())
        try:
            self.url = None

            u = url = item['url']
            d = item['debrid']
            direct = item['direct']
            local = item.get('local', False)

            provider = item['provider']
            call = [i[1] for i in self.sourceDict if i[0] == provider][0]
            u = url = call.resolve(url)
            if url is None or ('://' not in str(url) and not local and 'magnet:' not in str(url)):
                raise Exception(" call.resolve(url) returned blank")

            if not local:
                if url.startswith('stack:'):
                    url = url[8:]

                urls = []
                for part in url.split(' , '):
                    Log(repr(part))
                    u = part
                    if not d == '':
                        part = debrid.resolver(part, d)
                    elif direct is not True:
                        Log(repr(url))
                        hmf = resolveurl.HostedMediaFile(url=u, include_disabled=True, include_universal=False)
                        Log(repr(hmf))
                        if hmf.valid_url() is True:
                            part = hmf.resolve()
                            Log(repr(part))
                        else:
                            Log(u"hmf says not valid url {}".format(repr(hmf)))
                    Log("appending{}".format(repr(part)))
                    urls.append(part)

                url = 'stack://' + ' , '.join(urls) if len(urls) > 1 else urls[0]

            if url is False or url is None:
                raise Exception()

            ext = url.split('?')[0].split('&')[0].split('|')[0].rsplit('.')[-1].replace('/', '').lower()
            if ext == 'rar':
                raise Exception()

            try:
                headers = url.rsplit('|', 1)[1]
                u = url.rsplit('|', 1)[0]
            except Exception:
                headers = ''
                
            headers = quote_plus(headers).replace('%3D', '=') if ' ' in headers else headers
            headers = dict(urlparse.parse_qsl(headers))
            if not ('User-Agent' in headers):
                headers['User-Agent'] = C.USER_AGENT
                url = u + "|{}".format( urlencode(headers)  )
            Log(repr(headers))
            if url.startswith('http') and '.m3u8' in url:
                result = client.request(url.split('|')[0], headers=headers, output='geturl', timeout='30')
                if result is None:
                    raise Exception()

            self.url = url

            Log(url)
            return url
        except Exception:
##            raise
            if info is True:
                self.errorForSources()
            return

    def sourcesDialog(self, items):
        try:

            labels = [i['label'] for i in items]

            select = control.selectDialog(labels)
            if select == -1:
                return 'close://'

            next = [y for x, y in enumerate(items) if x >= select]
            prev = [y for x, y in enumerate(items) if x < select][::-1]

            items = [items[select]]
            items = [i for i in items+next+prev][:40]

            header = control.addonInfo('name')
            header2 = header.upper()

            progressDialog = control.progressDialog if control.setting(
                'progress.dialog') == '0' else control.progressDialogBG
            progressDialog.create(header, '')
            progressDialog.update(0)

            block = None

            for i in range(len(items)):
                try:
                    if items[i]['source'] == block:
                        raise Exception()

                    w = workers.Thread(self.sourcesResolve, items[i])
                    w.start()

                    try:
                        if progressDialog.iscanceled():
                            break
                        progressDialog.update(int((100 / float(len(items))) * i), str(items[i]['label']), str(' '))
                    except Exception:
                        progressDialog.update(int((100 / float(len(items))) * i), str(header2), str(items[i]['label']))

                    m = ''

                    for x in range(3600):
                        try:
                            if monitor.abortRequested():
                                return sys.exit()
                            if progressDialog.iscanceled():
                                return progressDialog.close()
                        except Exception:
                            pass

                        k = control.condVisibility('Window.IsActive(virtualkeyboard)')
                        if k:
                            m += '1'
                            m = m[-1]
                        if (w.is_alive() is False or x > 30) and not k:
                            break
                        k = control.condVisibility('Window.IsActive(yesnoDialog)')
                        if k:
                            m += '1'
                            m = m[-1]
                        if (w.is_alive() is False or x > 30) and not k:
                            break
                        time.sleep(0.5)

                    for x in range(30):
                        try:
                            if monitor.abortRequested():
                                return sys.exit()
                            if progressDialog.iscanceled():
                                return progressDialog.close()
                        except Exception:
                            pass

                        if m == '':
                            break
                        if w.is_alive() is False:
                            break
                        time.sleep(0.5)

                    if w.is_alive() is True:
                        block = items[i]['source']

                    if self.url is None:
                        raise Exception()

                    self.selectedSource = items[i]['label']

                    try:
                        progressDialog.close()
                    except Exception:
                        pass

                    control.execute('Dialog.Close(virtualkeyboard)')
                    control.execute('Dialog.Close(yesnoDialog)')
                    traceback.print_stack()
                    return self.url
                except Exception:
                    pass

            try:
                progressDialog.close()
            except Exception:
##                raise
                pass

        except Exception as e:
            try:
                progressDialog.close()
            except Exception:
                pass
            log_utils.log('Error %s' % str(e), log_utils.LOGNOTICE)

    def sourcesDirect(self, items):
        filter = [i for i in items if i['source'].lower() in self.hostcapDict and i['debrid'] == '']
        items = [i for i in items if i not in filter]

        filter = [i for i in items if i['source'].lower() in self.hostblockDict and i['debrid'] == '']
        items = [i for i in items if i not in filter]

        items = [i for i in items if ('autoplay' in i and i['autoplay'] is True) or 'autoplay' not in i]

        if control.setting('autoplay.sd') == 'true':
            items = [i for i in items if i['quality'] not in ['4K', '1440p', '1080p', 'HD']]

        u = None

        header = control.addonInfo('name')
        header2 = header.upper()

        try:
            control.sleep(1000)

            progressDialog = control.progressDialog if control.setting(
                'progress.dialog') == '0' else control.progressDialogBG
            progressDialog.create(header, '')
            progressDialog.update(0)
        except Exception:
            pass

        for i in range(len(items)):
            try:
                if progressDialog.iscanceled():
                    break
                progressDialog.update(int((100 / float(len(items))) * i), str(items[i]['label']), str(' '))
            except Exception:
                progressDialog.update(int((100 / float(len(items))) * i), str(header2), str(items[i]['label']))

            try:
                if monitor.abortRequested():
                    return sys.exit()

                url = self.sourcesResolve(items[i])
                traceback.print_stack()
                if u is None:
                    u = url
                if url is not None:
                    break
            except Exception:
                pass

        try:
            progressDialog.close()
        except Exception:
            pass

        return u

    def errorForSources(self):
        control.infoDialog(control.lang(32401).encode('utf-8'), sound=False, icon='INFO')

    def getLanguage(self):
        langDict = {
            'English': ['en'],
            'German': ['de'],
            'German+English': ['de', 'en'],
            'French': ['fr'],
            'French+English': ['fr', 'en'],
            'Portuguese': ['pt'],
            'Portuguese+English': ['pt', 'en'],
            'Polish': ['pl'],
            'Polish+English': ['pl', 'en'],
            'Korean': ['ko'],
            'Korean+English': ['ko', 'en'],
            'Russian': ['ru'],
            'Russian+English': ['ru', 'en'],
            'Spanish': ['es'],
            'Spanish+English': ['es', 'en'],
            'Greek': ['gr'],
            'Italian': ['it'],
            'Italian+English': ['it', 'en'],
            'Greek+English': ['gr', 'en']}
        name = control.setting('providers.lang')
        return langDict.get(name, ['en'])

    def getLocalTitle(self, title, imdb, tvdb, content):
        lang = self._getPrimaryLang()
        if not lang:
            return title

        if content == 'movie':
            t = trakt.getMovieTranslation(imdb, lang)
        else:
            t = tvmaze.tvMaze().getTVShowTranslation(tvdb, lang)

        return t or title

    def getAliasTitles(self, imdb, localtitle, content, year=None):

##        Log(repr((imdb, localtitle, content, year)))
        
        trakt_alias_titles = []
        
        safe_countries_for_titles = ['', 'us', 'gb'] #, 'fr', 'br']
        safe_countries_for_titles.append(   self._getPrimaryLang() )

        try:
            if content == 'movie':
                all_trakt_info = trakt.getMovieAliases(imdb)
            else:
                all_trakt_info = trakt.getTVShowAliases(imdb)

            Log(repr(all_trakt_info))                
            for trakt_info in all_trakt_info:
                trakt_country = trakt_info.get('country', '').lower()
                trakt_title = trakt_info.get('title', '').lower()
                if ((trakt_country in safe_countries_for_titles )
                    and (trakt_title != localtitle.lower())):
                    already_there = False
                    for alias in trakt_alias_titles:
                        if trakt_title == alias['title'].lower():
                            already_there = True
                            break
                    if not already_there:
                        trakt_alias_titles.append(trakt_info)
            if year and not(year in localtitle):
                trakt_info_with_year = {'country': trakt_country
                                        , 'title': localtitle + ' ' + year
                                        }
                trakt_alias_titles.append(trakt_info_with_year)
        except Exception:
            pass
            #raise
##        Log(repr(trakt_alias_titles))
##        Log(repr(dir(trakt_alias_titles)))
        fallback_alias_title = {'country': '', 'title': localtitle}
##        Log(repr(fallback_alias_title))
##        Log(repr(dir(fallback_alias_title)))
        trakt_alias_titles.append(fallback_alias_title)
##        Log(repr(trakt_alias_titles))
        return trakt_alias_titles

    def _getPrimaryLang(self):
        langDict = {
            'English': 'en', 'German': 'de', 'German+English': 'de', 'French': 'fr', 'French+English': 'fr',
            'Portuguese': 'pt', 'Portuguese+English': 'pt', 'Polish': 'pl', 'Polish+English': 'pl', 'Korean': 'ko',
            'Korean+English': 'ko', 'Russian': 'ru', 'Russian+English': 'ru', 'Spanish': 'es', 'Spanish+English': 'es',
            'Italian': 'it', 'Italian+English': 'it', 'Greek': 'gr', 'Greek+English': 'gr'}
        name = control.setting('providers.lang')
        lang = langDict.get(name)
        return lang

    def getTitle(self, title):
        title = cleantitle.normalize(title)
        return title

    def getConstants(self):
        self.itemProperty = 'plugin.video.exodusredux.container.items'
        self.metaProperty = 'plugin.video.exodusredux.container.meta'

        self.sourceDict = openscraper_sources()
##        LogR(self.sourceDict)
        
        try:
            self.hostDict = resolveurl.relevant_resolvers(order_matters=True)
            host_dictionary = []
            for i in self.hostDict:
                if '*' not in i.domains:
                    host_dictionary.append(i.domains)
            self.hostDict = host_dictionary
                    
            from functools import reduce
            self.hostDict = [i.lower() for i in reduce(lambda x, y: x+y, self.hostDict)]
            self.hostDict = [x for y, x in enumerate(self.hostDict) if x not in self.hostDict[:y]]
        except Exception:
            traceback.print_exc()
            self.hostDict = []
##        Log(repr(self.hostDict))

        self.hostprDict = ['1fichier.com', 'oboom.com', 'rapidgator.net', 'rg.to', 'uploaded.net',
                           'uploaded.to', 'ul.to', 'filefactory.com', 'nitroflare.com', 'turbobit.net', 'uploadrocket.net']

        self.hostcapDict = ['hugefiles.net', 'kingfiles.net', 'openload.io', 'openload.co',
                            'oload.tv', 'thevideo.me', 'vidup.me', 'streamin.to', 'torba.se']

        self.hosthqDict = [
            'gvideo', 'google.com', 'openload.io', 'openload.co', 'oload.tv', 'thevideo.me', 'rapidvideo.com',
            'raptu.com', 'filez.tv', 'uptobox.com', 'uptobox.com', 'uptostream.com', 'xvidstage.com', 'streamango.com']

        self.hostblockDict = []

    def getPremColor(self, n):
        if n == '0':
            n = 'blue'
        elif n == '1':
            n = 'red'
        elif n == '2':
            n = 'yellow'
        elif n == '3':
            n = 'deeppink'
        elif n == '4':
            n = 'cyan'
        elif n == '5':
            n = 'lawngreen'
        elif n == '6':
            n = 'gold'
        elif n == '7':
            n = 'magenta'
        elif n == '8':
            n = 'yellowgreen'
        elif n == '9':
            n = 'nocolor'
        else:
            n == 'blue'
        return n

#__________________________________________________________________________
#
def Header2pipestring(header = C.DEFAULT_HEADERS):
    q = "|{}".format( urlencode(header)  )
    return q
#__________________________________________________________________________
#
def playvid(
    video_url
    , name
    , download = None
    , description = u''
    , playmode_string = None
    , play_profile = None
    , download_filespec = None
    ):

    player.playvid(
        video_url = video_url
        , name = name
        , download = download
        , description = description
        , playmode_string = playmode_string
        , play_profile = play_profile
        , download_filespec = download_filespec
        )
#__________________________________________________________________________
#


