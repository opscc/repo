"""
    tknorris shared module
    Copyright (C) 2016 tknorris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
																	   

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import cProfile
import json
import os
import pstats
from resources.lib.constants import StringIO
import time
from datetime import datetime
import traceback
from resources.lib import constants as C

import xbmc
from resources.lib.modules import control
from xbmc import (LOGDEBUG, LOGERROR, LOGFATAL, LOGINFO,  # @UnusedImport
                  LOGNONE, LOGWARNING)

import os,os.path,sys
PY3 = sys.version_info >= (3, 0)
PY2 = not PY3
if PY3: text_type = str  
if PY2: text_type = unicode #this keyword will raise error in PY3

name = C.addon_name
# Using color coding, for color formatted log viewers like Assassin's Tools
##DEBUGPREFIX = '[COLOR red][ EXODUS REDUX DEBUG ][/COLOR]'
try:
    DEBUGPREFIX = str(control.addonInfo('id')) + ': '
except:
    DEBUGPREFIX = "plugin.video.exodusredux: "
LOGPATH = C.translatePath('special://logpath/')

def Log(msg='', loglevel=None, stacklevel=2):

    if C.DEBUG and not(loglevel): loglevel = C.LOGNONE
    if not loglevel: return
    if not msg: msg = u""
    if not isinstance(msg, C.text_type):
        if C.PY3: msg = str(msg,'utf8','ignore')
        if C.PY2: msg = msg.decode('ascii','ignore').encode('utf8')
    try: 
        msg = u"{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
            ,traceback.extract_stack(limit=stacklevel)[0][1]
            ,msg
            )
    except:
        pass
    
    if PY3: msg = "{}: {}".format(DEBUGPREFIX, msg )
    if PY2: msg = "{}: {}".format(DEBUGPREFIX, msg.encode('utf-8',errors='ignore') )

    if  loglevel: xbmc.log(msg , loglevel)
##    elif C.DEBUG:  xbmc.log(msg , xbmc.LOGNONE)
    else:    xbmc.log(msg, xbmc.LOGNONE)

    
####    xbmc.log(DEBUGPREFIX + "'%s'" % (msg), xbmc.LOGNONE)
####    return
##
##    debug_enabled = control.setting('debug')
##    debug_log = control.setting('debug.location')
##
##    if not control.setting('debug') == 'true':
##        return
##
##    if extraNesting:
##        stack_limit = 3
##    else:
##        stack_limit = 2    
##    try: 
##        msg = "{}:{} {}".format(
##            os.path.basename(traceback.extract_stack(limit=stack_limit)[0][0])
##            ,traceback.extract_stack(limit=stack_limit)[0][1]
##            ,msg
##            )
##    except:
##        pass
##
##    try:
##
##        if not control.setting('debug.location') == '0':
##            log_file = os.path.join(LOGPATH, 'atreides.log')
##            if not os.path.exists(log_file):
##                f = open(log_file, 'w')
##                f.close()
##            with open(log_file, 'a') as f:
##                line = '[%s %s] %s: %s' % (datetime.now().date(), str(datetime.now().time())[:8], DEBUGPREFIX, msg)
##                f.write(line.rstrip('\r\n')+'\n')
##        else:
##            #print('%s: %s' % (DEBUGPREFIX, msg))
##            xbmc.log(('%s%s' % (DEBUGPREFIX, msg)), LOGNONE)
##
##    except Exception as e:
##        try:
##            xbmc.log('Logging Failure: %s' % (e), level)
##        except Exception:
##            raise
##            pass

#
def log(msg='', level=LOGNONE):
    Log(msg, loglevel=level, stacklevel=3)
#__________________________________________________________________________
#
def logR(msg='', loglevel=None, include_type=False):
    if include_type: t = (type(msg), msg)
    else: t = (msg,)
    Log(repr(t), loglevel, stacklevel=3)
#__________________________________________________________________________
#
def LogR(msg='', loglevel=None, include_type=False):
    if include_type: t = (type(msg), msg)
    else: t = (msg,)
    Log(repr(t), loglevel, stacklevel=3)


class Profiler(object):
    def __init__(self, file_path, sort_by='time', builtins=False):
        self._profiler = cProfile.Profile(builtins=builtins)
        self.file_path = file_path
        self.sort_by = sort_by

    def profile(self, f):
        def method_profile_on(*args, **kwargs):
            try:
                self._profiler.enable()
                result = self._profiler.runcall(f, *args, **kwargs)
                self._profiler.disable()
                return result
            except Exception as e:
                log('Profiler Error: %s' % (e), LOGWARNING)
                return f(*args, **kwargs)

        def method_profile_off(*args, **kwargs):
            return f(*args, **kwargs)

        if _is_debugging():
            return method_profile_on
        else:
            return method_profile_off

    def __del__(self):
        self.dump_stats()

    def dump_stats(self):
        if self._profiler is not None:
            s = C.StringIO()
            params = (self.sort_by,) if isinstance(self.sort_by, basestring) else self.sort_by
            ps = pstats.Stats(self._profiler, stream=s).sort_stats(*params)
            ps.print_stats()
            if self.file_path is not None:
                with open(self.file_path, 'w') as f:
                    f.write(s.getvalue())


def trace(method):
    def method_trace_on(*args, **kwargs):
        start = time.time()
        result = method(*args, **kwargs)
        end = time.time()
        log('{name!r} time: {time:2.4f}s args: |{args!r}| kwargs: |{kwargs!r}|'.format(
            name=method.__name__, time=end - start, args=args, kwargs=kwargs), LOGDEBUG)
        return result

    def method_trace_off(*args, **kwargs):
        return method(*args, **kwargs)

    if _is_debugging():
        return method_trace_on
    else:
        return method_trace_off


def _is_debugging():
    command = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.getSettings',
               'params': {'filter': {'section': 'system', 'category': 'logging'}}}
    js_data = execute_jsonrpc(command)
    for item in js_data.get('result', {}).get('settings', {}):
        if item['id'] == 'debug.showloginfo':
            return item['value']

    return False


def execute_jsonrpc(command):
    if not isinstance(command, basestring):
        command = json.dumps(command)
    response = control.jsonrpc(command)
    return json.loads(response)
