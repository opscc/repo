import threading
import time
import traceback
import xbmc

from lib.resources.lib import constants as C

from lib.resources.lib.constants import reload

from lib.resources.lib.modules import downloader
from lib.resources.lib.modules import downloadServer
from lib.resources.lib import utils
from lib.resources.lib.utils import Log,LogR #,Sleep
from lib.resources.lib.utils import get_setting as GetSetting


monitor = None # xbmc.Monitor() #behaves stragely if kodi closes too soon?

#__________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def SleepX(num, check_interval=100, stop_event=None): # ,monitor=None):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
##    monitor=None
##    if not monitor: monitor = xbmc.Monitor()
##    LogR(monitor.abortRequested(),stacklevel=4)
    try:
        while num > 0: 
##            Log('peep',stacklevel=3)
##            LogR(monitor.abortRequested(),stacklevel=4)
            if monitor.abortRequested():
                Log('sleep abortRequested',stacklevel=3)
                return
            if stop_event and stop_event.is_set():
                Log('sleep stop_event',stacklevel=3)
                return
            time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
            num = num - sleep_interval
    except SystemExit: #common when closing app
        Log('error SystemExit',stacklevel=3)
        pass
    
#__________________________________________________________________
#
def Sleep_Start(sleep_time):
##    xbmc.log("Begin {}s sleep for {}:{}".format(
##            sleep_time
##            , threading.current_thread().name
##            , threading.current_thread().ident
##            )
##            ,xbmc.LOGINFO)
    Log("Begin {}s sleep for {}:{}".format(
            sleep_time
            , threading.current_thread().name
            , threading.current_thread().ident
            )
        ,stacklevel=3
        )
#__________________________________________________________________
#
def Sleep_End(sleep_time):
##    xbmc.log("End {}s sleep for {}:{}".format(
##            sleep_time
##            , threading.current_thread().name
##            , threading.current_thread().ident
##            )
##            ,xbmc.LOGINFO)
    Log("End {}s sleep for {}:{}".format(
            sleep_time
            , threading.current_thread().name
            , threading.current_thread().ident
            )
        ,stacklevel=3
        )
    
#__________________________________________________________________________
#
class EndingException(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)


#__________________________________________________________________
#
def download_service(stop_event):
    try:
        download_proxy = None
        while not monitor.abortRequested():
            if stop_event.is_set():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_download_service", bool):
                if not download_proxy:
                    Log("starting download_proxy", C.LOGNONE)
                    download_proxy = downloadServer.StartListening()
            else:
                Log('not enabled. download_proxy will be stopped')
                stop_event.set()
                
            sleep_time = max(1,GetSetting("min_service_interval", int))
##            Sleep_Start(sleep_time)
##            Sleep(sleep_time*1000,stop_event=stop_event)
            monitor.waitForAbort(sleep_time)
##            Sleep_End(sleep_time)

        Log('abortrequested')
    except EndingException as ex:
        Log(ex.value,C.LOGINFO)
    except SystemExit as ex:
        Log('SystemExit',C.LOGERROR)
        traceback.print_exc()
    except:
        traceback.print_exc()
    finally:
        stop_event.set()
        if download_proxy:
            Log('Finally download_proxy stoppING')
            download_proxy.shutdown()
            download_proxy.socket.close()
        Log('Finally download_proxy stopped')

#__________________________________________________________________
#
try:
##    LogR(__name__,C.LOGWARNING)
    if __name__ != '__main__':
##        xbmc.log(repr(__name__),xbmc.LOGERROR)

        traceback.print_stack()
        exit(0)

    monitor = xbmc.Monitor()

##    xbmc.log("a",xbmc.LOGERROR)    
    C.DEBUG = GetSetting('debug')
    threading.current_thread().name = C.addon_id+".service"
##    LogR(threading.current_thread().ident,xbmc.LOGERROR)
    LogR(threading.current_thread().ident)
##    xbmc.log("a",xbmc.LOGERROR)

    proxy_thread_download_service = None    
    download_service_stop_event = threading.Event()

    while not monitor.abortRequested():
##        LogR(monitor.abortRequested())
        try:
            # start thread for enable_download_service service
            if GetSetting("enable_download_service", bool):
                if not proxy_thread_download_service: # start thread
                    download_service_stop_event.clear()
                    proxy_thread_download_service = threading.Thread(
                        target=download_service
                        ,args=(download_service_stop_event,)
                        ,name=C.addon_id+".download_service"
                        )
##                    proxy_thread_download_service.daemon = True
                    proxy_thread_download_service.start()
                    LogR(proxy_thread_download_service.ident)
                else:
                    Log('proxy_thread_download_service already started')
            else:
                Log("proxy_thread_download_service=false. Will turn off if active")
                download_service_stop_event.set()
                proxy_thread_download_service = None
        except:
            traceback.print_exc()                

        ## sleep then ... do some work
        sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
        sleep_time = 5# max(1,sleeptime,300)
##        Sleep_Start(sleep_time)
##        Sleep(sleep_time*1000)
        monitor.waitForAbort(sleep_time)
##        Sleep_End(sleep_time)

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = GetSetting('debug')

    Log('abortrequested')
##    exit(0)
except:
    traceback.print_exc()
finally:
    Log("service finally")
    if proxy_thread_download_service:
        Log("proxy_thread_download_service")
        download_service_stop_event.set()
        proxy_thread_download_service.join()
        Log('proxy_thread_download_service joined')
    Log("service should be stopped",C.LOGERROR)
        
#__________________________________________________________________
#
