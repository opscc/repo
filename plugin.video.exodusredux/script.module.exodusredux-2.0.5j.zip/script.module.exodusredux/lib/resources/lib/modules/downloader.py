#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.modules.log_utils import log as Log
from resources.lib.modules import constants as C
import os.path
import re
import sys
import time
import threading
import traceback
import urlparse
import urllib
import urllib2
from utils import *
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin

import sqlite3
import datetime
import _strptime #because https://www.raspberrypi.org/forums/viewtopic.php?t=166912

downloads_db = ":memory:" #maybe one day create a service that keeps conn in memory; easier to clean dead connections
downloads_db = C.downloads_db

#__________________________________________________________________________
#
class Progress_Dialog(object):
    import threading, xbmcgui
    def __init__(
        self
        , title
        , message
        ):
        if threading.current_thread().name != "MainThread":
            self.dialog_progress = None
        self.dialog_progress = xbmcgui.DialogProgress()
        self.dialog_progress.create(title, message)
    def iscanceled(self):
        if self.dialog_progress:
            return self.dialog_progress.iscanceled()
        else:
            return True
    def close(self):
        if not self.dialog_progress: return
        self.dialog_progress.close()
        self.dialog_progress = None
    def update(self
               ,percent
               ,message=None
               ,line2=None
               ,line3=None
               ):
        if not self.dialog_progress: return

        if not message:
            self.dialog_progress.update(percent)
            return
        if not line2:
            self.dialog_progress.update(percent, message)
            return
        if not line3:
            self.dialog_progress.update(percent, message, line2)
            return
        self.dialog_progress.update(percent, message, line2, line3)
#__________________________________________________________________________
#
class StopDownloading(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)
#__________________________________________________________________________
#
def endOfDirectory(cacheToDisc=True):
    if int(sys.argv[1]) > 0:
        C.addon_handle = int(sys.argv[1])
        xbmcplugin.endOfDirectory(C.addon_handle, cacheToDisc=cacheToDisc)
#__________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=10):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval
#__________________________________________________________________________
#
def addDownLink(name, url, mode
                , iconimage=None
                , play_method = C.PLAYMODE_NO_OPTIONS
                , noDownload = False
                , isFolder = False
                ):

    u = (
        u"{}".format(sys.argv[0])
        + u"?url={}".format(urllib.quote_plus(url)) 
        + u"&action={}".format(mode)
        + u"&name={}".format(urllib.quote_plus(name)) 
        )

    list_item = xbmcgui.ListItem(name)
    list_item.setContentLookup(False)
    list_item.setProperty('IsPlayable', 'false')
    
    xbmcplugin.addDirectoryItem(handle=C.addon_handle, url=u, listitem=list_item, isFolder=isFolder)
#__________________________________________________________________________
#
def addDir(name, url, mode, iconimage=None):
    addDownLink(name, url, mode, iconimage, isFolder = True)
    pass
#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True):
    if not s: return ''
    s = s.strip('\r')
    s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(u'(?i)\[\/Color\]','',s))
    if include_square_braces:
        s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ \/,\'.&_]',' ',s))
    else:
        s = (re.sub(u'(?is)[^A-Za-z0-9~ ,\'.&_]',' ',s))
    while '  ' in s:
        s = s.replace('  ', ' ')
    return s.strip();

#__________________________________________________________________________
#
def Notify(header=None, msg='', duration=3000, sound=False):
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound)
def notify(header=None, msg='', duration=C.DEFAULT_NOTIFY_TIME, sound=False):
    debug = (C.this_addon.getSetting('debug').lower() == "true")
    if threading.current_thread().name == "MainThread":
        Log( msg, xbmc.LOGNOTICE)
        if header==None or header == '':
            if len(msg) > 30:
                header = msg[0:30]
                msg = msg[-30:]
            else:
                header=msg
        xbmcgui.Dialog().notification(header, msg, xbmcgui.NOTIFICATION_INFO, duration, sound=False )
        #xbmc.executebuiltin( "XBMC.Notification(%s,%s,%i)" % ( header, msg, duration))
    elif debug:
        Log( msg, xbmc.LOGNOTICE)

#__________________________________________________________________________
#
def Normalize_Filespec(filespec):
    #python can get confused with smb://
    if os.name == 'nt':
        filespec = os.path.normpath(filespec)
        if filespec.startswith("smb:"):
            filespec = filespec[4:]
        filespec = os.path.normpath(filespec)
        filespec = filespec.replace("\\\\", "\\")
        if filespec.startswith("\\") and not filespec.startswith("\\\\"):
            filespec = "\\" + filespec
        if filespec.startswith("\\\\") and (':' in filespec):
            #original path contained a port number; remove it for smb:
            filespec = re.sub(r"(\:[^\\]+)","",filespec)
    return filespec
#__________________________________________________________________________
#
def mkdirs(path, prev_path=None):
##    Log(repr(path))
##    Log(repr(prev_path))
    if prev_path == path:
##        Log('end recursion')
        return #end recursion
    if prev_path is None: prev_path = path
    if 'mkdirs' in dir(os):
        os.mkdirs(path)
    else:
        mkdirs(os.path.dirname(path), path)
        try:
            os.mkdir(path)
        except:
            pass
#__________________________________________________________________________
#
def Make_download_path(name = '', include_date = False, file_extension = '', folder=None):
    Log(u"Make_download_path name='{}'".format(repr(name)))

    name = Clean_Filename(name)

##    raise Exception(name)

    if folder is None:
        download_path = unicode(C.addon.getSetting("tv.download.path").lower())
        Log("Make_download_path download_path='{}'".format(download_path))    
        if download_path in ['','None',None]:
            try:
                download_path = xbmcgui.Dialog().browse(0, "Download Path", 'myprograms', '', False, False)
                C.addon.setSetting(id='download_path', value=download_path)
                if not os.path.exists(download_path): mkdirs(download_path)
            except:
                raise
    else:
        download_path = folder

    Log("download_path='{}'".format(repr(download_path)))
    download_path = Normalize_Filespec(download_path)
    Log("download_path='{}'".format(repr(download_path)))
    if not os.path.exists(download_path):
        Log("download_path.dirname='{}'".format(repr(  os.path.dirname(download_path) + os.path.sep )))
        mkdirs( os.path.dirname(download_path) )

    download_path = os.path.join(download_path, name)
    Log("download_path='{}'".format(repr(download_path)))

    if include_date:
        download_path = download_path + datetime.datetime.now().strftime(".%Y-%m-%d")

    download_path = download_path + file_extension
    
    Log("Make_download_path download_path='{}'".format(repr(download_path)))
    return download_path
#__________________________________________________________________________
#
def Stop_Download(url,name,refresh_container=True):
    Log("Stop_Download({},{}) start".format(name, url))
    name = Clean_Filename(name)
    Log("Stop_Download({},{}) start".format(name, url))

##    Log(repr(sys.argv)+repr(sys.argv[2]),LOGNONE)
    
##    if refresh_container == False:
##        Manage_Downloads()
####        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
####        xbmc.executebuiltin("Container.Refresh")
##        Log("Stop_Download end '{}'".format(url))
##        return

    
    progress_dialog = None
    if refresh_container == True:
        progress_dialog = Progress_Dialog(C.addon_name,"stopping '{}'".format(name))

##    progress_dialog = None
##    if threading.current_thread().name == "MainThread":
##        progress_dialog = xbmcgui.DialogProgress()
##        progress_dialog.create(C.addon_name,"stopping {}".format(name))
    
    import gc
    stop_name = None
    loop_interruptor = 0
    for obj in gc.get_objects():
        loop_interruptor += 1
        if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS: # pause to allow other stuff
            if progress_dialog and progress_dialog.iscanceled():
                obj = None
                break
            Sleep(C.GC_SEARCHLOOP_PAUSE) # pause to allow other stuff
            loop_interruptor = 0
        try:
            if (obj is not None) and '__class__' in repr(dir(obj)) :
                if (
                    'HLSDownloaderRetry.HLSDownloaderRetry' in repr(obj.__class__)
                    or
                    'MP4Downloader' in repr(obj.__class__)
                    ):
                    if hasattr(obj, 'stop_playing_event') and hasattr(obj, 'url'):
                        if url.startswith(obj.url) and obj.stop_playing_event:
                            obj.stop_playing_event.set()
                            stop_name = obj.name
                            obj = None
                            Sleep(C.WAIT_AFTER_STOP_DOWNLOAD_EVENT)
                            break
        except:
            traceback.print_exc()
            Log("already collected?", C.LOGNONE)
            pass
    else:
        pass
##        Log("does this happen on loop break?", LOGNONE)
##        obj = None


    if stop_name and obj is None:
##        delete_download(url)        
        proxy_thread = threading.Thread(
            name='delete_download.'+name
            ,target=delete_download
            ,args=(url,)
            )
        proxy_thread.daemon = True
        proxy_thread.start()
        Notify("Stopped '{}'".format(stop_name))
    elif obj: #went through everything but not background thread in gc
        #delete_download(url)        
        proxy_thread = threading.Thread(
            name='delete_download.'+name
            ,target=delete_download
            ,args=(url,)
            )
        proxy_thread.daemon = True
        proxy_thread.start()
        Notify("Deleted <inactive> '{}' from database".format(name))
        #raise Exception("found obj, but could not stop")
    else:
        Log("Cancelled delete of {}".format(name))

    if progress_dialog: progress_dialog.close()

    Log("Stop_Download end '{}'".format(url))

    if refresh_container == True:
        Log("Container.Refresh")
        xbmc.executebuiltin("Container.Refresh")
#__________________________________________________________________________
#
def Manage_Downloads():
    Log("Manage_Downloads start")
##    Log(threading.current_thread().name, LOGNONE)
##    threading.current_thread().name = "Manage_Downloads"
##    Log(threading.current_thread().name, LOGNONE)

    one_instance_found = False
    for name, url, c, d, start_time, e, f, g, h in active_downloads():
        one_instance_found = True
##        name = "[COLOR {}]Stop downloading[/COLOR] '{}'".format(
##            C.search_text_color
##            , name[len(C.DOWNLOAD_INDICATOR):]
##            )
        name = "[COLOR {}]{}[/COLOR]".format(
            C.search_text_color
            , name[len(C.DOWNLOAD_INDICATOR):]
            )
        #using adddir adds error message to log; shows 'busy' indicator
##        addDir(
##            name = name
##            , url = url
##            , mode = C.ROOT_STOP_DOWNLOAD
##            )
        #using addownlink has right click menu; manully have to show 'busy' indicator        
        addDownLink(
            name = name
            , url = url
            , mode = C.ROOT_STOP_DOWNLOAD
            , play_method = C.PLAYMODE_NO_OPTIONS
            )
    if one_instance_found == False:
        addDir(
            name="Nothing downloading in background"
            , url=C.DO_NOTHING_URL
            , mode=C.ROOT_INDEX_INDEX
            )

    proxy_thread = threading.Thread(
        name='clean_downloads'
        ,target=clean_downloads
        )
    proxy_thread.daemon = True
    proxy_thread.start()
##    clean_downloads()
    
    Log("Manage_Downloads end")    
    endOfDirectory()
#__________________________________________________________________________
#
def _pbhook(downloaded, filesize, start, name=None, progress_dialog=None):
    try:
        percent = min((downloaded*100)/filesize, 100)
        currently_downloaded = float(downloaded) / (1024 * 1024)
        kbps_speed = int(downloaded / (time.clock() - start))

        if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
        else:           eta = 0

        kbps_speed = kbps_speed / 1024
        total = float(filesize) / (1024 * 1024)
        mbs = "[{:20}]".format(name)
        mbs += ' %.00f MB/%.00f MB' % (currently_downloaded, total)
        e = ' %.0fKbps' % kbps_speed
        e += ' ETA:%01d' % (eta // 60)
        progress_dialog.update(percent,'',mbs + e)
    except:
        traceback.print_exc()
        percent = 100
        progress_dialog.update(percent)
        progress_dialog.close()

#__________________________________________________________________________
#
class HeadRequest(urllib2.Request):
    '''A Request class that sends HEAD requests'''
    def get_method(self):
       return C.URL_REQUEST_HEAD
#__________________________________________________________________________
#
def getResponse(url, headers, size=0, method=C.URL_REQUEST_GET, proxy=None):
##    Log("url={}".format(repr(url)))
##    Log("headers={}".format(repr(headers)))
    url = url.split('|')[0]
##    Log("url={}".format(repr(url)))
    response = None
    try:
        if size > 0:
            size = int(size)
            headers['Range'] = 'bytes=%d-' % size
        if method == C.URL_REQUEST_HEAD:
            request = HeadRequest(url, headers=headers)
        else:
            request = urllib2.Request(url, headers=headers)
##        proxy = "127.0.0.1:1025"
        if proxy: request.set_proxy(proxy, type='http')
        #import ssl
        #response = urllib2.urlopen(request, timeout=30, context=ssl._create_unverified_context())
        response = urllib2.urlopen(request, timeout=30)
    except:
        #pass
        traceback.print_exc()
    return response
#__________________________________________________________________________
#
def doDownload(url, dest_file_object, progress_dialog, name, stop_event):

    start = time.clock()

    MAX_RESUME_ERRORS = 500

    try:
        
        #url may have include headers to be passed during transaction
        try:
            headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
        except:
            #traceback.print_exc()
            headers = dict('')

        url = url.split('|')[0]
##        file = dest.rsplit(os.sep, 1)[-1]

#            Log("headers='{}'".format(headers))

        resp = getResponse(url, headers, 0)
        #utils.getHtml(url, headers=headers)
        
        if not resp:
            Notify("Download failed: {}".format(url))
            return False

        try:
            content = int(resp.headers['Content-Length'])
            Log("Expected file size {:,} bytes for '{}'".format(content, name))
        except: content = 0

        try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
        except: resumable = False
        if resumable: Log("Download is resumable: {}".format(url))

        if content < 1:
            Notify("Unknown filesize: {}".format(url))
            content = 1024*1024*1024


        size = 8192
        mb   = content / (1024 * 1024)

        if content < size:
            size = content

        total   = 0
        errors  = 0
        count   = 0
        resume  = 0
        sleep   = 0

##        Log('Download File Size : %dMB %s ' % (mb, dest))
##        f = xbmcvfs.File(dest, 'w')
        Log('Download File Size : %dMB %s ' % (mb, dest_file_object.name))


        chunk  = None
        chunks = []

        while True:

            # kill the download if kodi monitor tells us to
            monitor = xbmc.Monitor()
            if monitor.abortRequested():
                if monitor.waitForAbort(0.1):
                    Log("shutting down '{}' download thread for '{}'".format(addon_id,url), xbmc.LOGNOTICE)
                    return False

            if stop_event.isSet() == True:
                Log("stop_event.isSet()")
                return False
            
            downloaded = total
            for c in chunks:
                downloaded += len(c)
            percent = min(100 * downloaded / content, 100)

            _pbhook(downloaded,content,start,name,progress_dialog)

            chunk = None
            error = False

            try:
                chunk = resp.read(size)
##                chunk = None #fake test short circut tesing
##                percent = 100 #fake test short circut tesing
                if not chunk:
                    if percent < 99:
                        error = True
                    else:
                        while len(chunks) > 0:
                            c = chunks.pop(0)
                            dest_file_object.write(c)
                            del c
                        dest_file_object.close()
                        Log( '%s download complete' % (dest_file_object.name) )
                        return True
                

            except Exception as e:
                traceback.print_exc()
                error = True
                sleep = 10
                errno = 0

                if hasattr(e, 'errno'):
                    errno = e.errno
                    Log(repr(errno))

                if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                    pass

                if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                    errors = 10 #force resume
                    sleep  = 10

                if errno == 11001: # 'getaddrinfo failed'
                    errors = 10 #force resume
                    sleep  = 10

            if chunk:
                errors = 0
                chunks.append(chunk)
                if len(chunks) > 5:
                    c = chunks.pop(0)
                    dest_file_object.write(c)
                    total += len(c)
                    del c

            if error:
                errors += 1
                count  += 1
                xbmc.sleep(sleep*1000)

            if (resumable and errors > 0) or errors >= MAX_RESUME_ERRORS:
                if (not resumable and resume >= MAX_RESUME_ERRORS) or resume >= MAX_RESUME_ERRORS:
                    #Give up!
                    Log ('%s download canceled - too many error whilst downloading' % (dest_file_object.name))
                    dest_file_object.close()
                    return False

                resume += 1
                errors  = 0

                if resumable:
                    chunks  = []
                    #create new response
                    Log ('Download resumed (%d) %s' % (resume, dest_file_object.name) )
                    resp = getResponse(url, headers, total)
                else:
                    #use existing response
                    pass
        else:
            Log('while loop finished')
            return False #only way to get here is an unknown failure

    except:
        traceback.print_exc()
        #raise

#__________________________________________________________________________
#
class MP4Downloader(object):
    def __init__(
        self
        , name
        , stop_playing_event
        , download_path
        , url
        ):
        self.name = name
        self.stop_playing_event = stop_playing_event
        self.download_path = download_path
        self.url = url
#__________________________________________________________________________
#
    def keep_sending_video( self ) :
        Log("keep_sending_video start")
        url = self.url
        destination_filespec = self.download_path
        name = self.name
        stop_playing_event = self.stop_playing_event

        url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on

        name = Clean_Filename(name)
        download_path = Make_download_path() #I want to start with path only
            
        progress_dialog = xbmcgui.DialogProgressBG()
        progress_dialog.create(C.addon_name,name[:50])
##        progress_dialog = Progress_Dialog(C.addon_name,name[:50])

        import tempfile
        Log(repr(download_path))
        tmp_file = tempfile.NamedTemporaryFile(dir=download_path, suffix=".mp4", delete=False)
        Log("tmp_file.name={}".format(repr(tmp_file.name)))
##        Log("tmp_file='{}'".format(repr(tmp_file)))
##        tmp_file = xbmc.makeLegalFilename(tmp_file)
##        Log("tmp_file='{}'".format(tmp_file))
        
        start = time.clock()
        successful_downloaded = None
        try:
            Log("url='{}'".format(url))
            Log("destination_filespec='{}'".format(repr(destination_filespec)))
        
            successful_downloaded = doDownload(url, tmp_file, progress_dialog, name, stop_playing_event)
            if successful_downloaded:
                if not destination_filespec:
                    Log("Clean_Filename(name)='{}'".format(Clean_Filename(name,include_square_braces=False)))
                    vidfile = xbmc.makeLegalFilename(download_path + Clean_Filename(name, include_square_braces=False) + ".mp4")
                else:
                    Make_download_path(folder=destination_filespec) #create dir structure if necessary
                    vidfile = destination_filespec
                Log("vidfile='{}'".format(vidfile))
                try:
                    os.rename(tmp_file.name, vidfile)
                    return vidfile
                except:
                    traceback.print_exc()
                    try:
                        nfn = vidfile + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S") + '.mp4'
                        Log("vidfile='{}'".format(nfn))
                        os.rename(tmp_file.name, nfn)
                        return nfn
                    except Exception as e2:
                        traceback.print_exc()
                        Notify(msg = "'{}' name:{} tmp:{}".format(e2,vidfile,tmp_file.name), duration=20000)
                        return tmp_file.name
            else:
                raise StopDownloading('Stopped Downloading')
        except StopDownloading:
##            traceback.print_exc()
            temp_name = tmp_file.name
            try: tmp_file.close()
            except: pass
            temp_name = Normalize_Filespec(temp_name)
            Log("removing '{}'".format(temp_name))
            while os.path.exists(temp_name):
                try:
                    os.remove(temp_name)
                    Sleep(C.WAIT_BETWEEN_TEMP_FILE_REMOVE_ATTEMT)
                except:
                    traceback.print_exc()
        except:
            traceback.print_exc()
            temp_name = tmp_file.name
            try: tmp_file.close()
            except: pass
            temp_name = Normalize_Filespec(temp_name)
            Log("removing '{}'".format(temp_name))
            while os.path.exists(temp_name):
                try:
                    os.remove(temp_name)
                    Sleep(C.WAIT_BETWEEN_TEMP_FILE_REMOVE_ATTEMT)
                except:
                    traceback.print_exc()
        finally:
            if progress_dialog: progress_dialog.close()
            progress_dialog = None

        Log("keep_sending_video end")
#__________________________________________________________________________
#
def Background_MP4Downloader(url, download_path, name):

    stop_playing_event = threading.Event()
    name = Clean_Filename(name)

    Log("Background_MP4Downloader instance")
    downloader = MP4Downloader(
          name = name
        , url = url
        , stop_playing_event = stop_playing_event
        , download_path = download_path
        )

    Log("Background_MP4Downloader keep sending start")
    now = datetime.datetime.utcnow()
    add_download_result = add_download(
        name=C.DOWNLOAD_INDICATOR+name
        , url=url
        , file_spec=download_path
        , expected_size=None
        , start_time=db_date_formatter(now)
        )

    if add_download_result != True:
        Log("seem to be already downloading, but that is a success for now")
        downloader = None
        return True

    try:        
        downloader.keep_sending_video()
    except:
        traceback.print_exc()
        
    Log("Background_MP4Downloader keep sending finish")
    downloader = None
    Stop_Download(url, name, False)
#__________________________________________________________________________
#
def Background_HLSDownloader(url, download_path, name):

    progress_dialog = xbmcgui.DialogProgressBG()
    progress_dialog.create(C.addon_name,name[:50])

    play_profile = 'profile_00' #the download profile
    initial_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "initial"))* 1000 * 1000)
    maximum_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "maximum"))* 1000 * 1000)
    allow_upscale = C.addon.getSetting(play_profile + "_" + "allow_upscale")
    allow_downscale = C.addon.getSetting(play_profile + "_" + "allow_downscale")
    always_refresh_m3u8 = C.addon.getSetting(play_profile + "_" + "always_refresh_m3u8")
    downscale_threshhold = C.addon.getSetting(play_profile + "_" + "downscale_threshhold")
    upscale_threshhold = C.addon.getSetting(play_profile + "_" + "upscale_threshhold")
    upscale_penalty = C.addon.getSetting(play_profile + "_" + "upscale_penalty")
    pre_cache_size_max = int(float(C.addon.getSetting(play_profile + "_" + "pre_cache_size_max"))* 1000 * 1000)

    stop_playing_event = threading.Event()
    seek_forward_event = threading.Event()
    import HLSDownloaderRetry

    Log("Background_HLSDownloader instance")
    downloader = HLSDownloaderRetry.HLSDownloaderRetry()
    downloader.init(
          url = url
        , stop_playing_event = stop_playing_event
        , seek_forward_event = seek_forward_event
        , maxbitrate = maximum_bitrate
        , download_path = download_path
        , initial_bitrate = initial_bitrate
        , allow_upscale = allow_upscale
        , allow_downscale = allow_downscale
        , always_refresh_m3u8 = always_refresh_m3u8
        , downscale_threshhold = downscale_threshhold
        , upscale_threshhold = upscale_threshhold
        , upscale_penalty = upscale_penalty
        , pre_cache_size_max = pre_cache_size_max
        )
    Log("Background_HLSDownloader keep sending start")

##    for obj in threading.enumerate():
##        Log("obj='{}'".format(dir(obj)))
##        Log("obj.name='{}'".format(obj.name))

    downloader.keep_sending_video(None)
    Log("Background_HLSDownloader keep sending finish")

    downloader = None

    Stop_Download(url, name, False)

    if progress_dialog: progress_dialog.close()
    progress_dialog = None
#__________________________________________________________________________
#
def Test_All():
    #test: if url already there; check if task is in progress
    #test: in progress, report success
    #test: NOT in progress, delete old and add new and start
##    for (qq) in active_downloads():
##        Log(repr(qq))
##        pass
    return
#__________________________________________________________________________
#
def download(name, image, url, download_path=None):
    downloadVideo(url,name,download_path)
#__________________________________________________________________________
#
def determine_download_type(url):
    download_type = None
    try:
        if '|' in url:
            url_headers = dict(urlparse.parse_qsl( url.split('|')[1] ) )
        else:
            url_headers = C.DEFAULT_HEADERS
        Log(repr((url,url_headers)))
        
        response = getResponse(url=url, headers=url_headers, method=C.URL_REQUEST_HEAD)

##        Log(repr(response))
##        Log(repr(response.info()))
        if response and hasattr(response, 'info'):            
            download_type = response.info()["Content-Type"].lower()
        else:
##            raise Exception('Info field not in response')
            raise Exception('Info field not in response or HEAD respose error')
            pass
        #return response.info()["Content-Type"].lower()
    except:
        traceback.print_exc()
        try:
            if any(x in url for x in ['.m3u8', '/hls/']):
                download_type = C.HLS_TYPE_1
        except:
            raise

    return download_type       
#__________________________________________________________________________
#
def downloadVideo(url, name, download_path=None):
    
    Log(u"DownloadVideo name={} url={} download_path={}".format(Clean_Filename(name),url,repr(download_path)), xbmc.LOGNONE)
    Notify(u"Downloading '{}' in background".format(Clean_Filename(name)))

    if name in [None,'','none','None']: raise Exception("missing name")
    now = datetime.datetime.utcnow()
    name = Clean_Filename(name)

    download_type = determine_download_type(url)
    Log("download_type='{}'".format(download_type))

    if download_type in C.HLS_DOWNLOAD:
        Log("hls download")
        if download_path is None:   
            download_path = Make_download_path(name, file_extension = '.ts')
        else:
            Make_download_path(folder = download_path) #make sure directory structure is there
            
        add_download_result = add_download(
            name=C.DOWNLOAD_INDICATOR+name
            , url=url
            , file_spec=download_path
            , expected_size=None
            , start_time=db_date_formatter(now)
            )

        if add_download_result != True:
            Log("seem to be already downloading, but that is a success for now")
            return

        proxy_thread = threading.Thread(
            name=C.DOWNLOAD_INDICATOR+name
            ,target=Background_HLSDownloader
            ,args=(url, download_path, name)
            )
        proxy_thread.daemon = True
        proxy_thread.start()

##        for obj in threading.enumerate():
##            Log("obj='{}'".format(dir(obj)))
##            Log("obj.name='{}'".format(obj.name))

        return

    else:
        Log("mp4 download")
        if download_path is None:   
            download_path = Make_download_path(name, file_extension = '.mp4')
        Log("download_path='{}'".format(download_path))

        proxy_thread = threading.Thread(
            name=C.DOWNLOAD_INDICATOR+name
            ,target=Background_MP4Downloader
            ,args=(url, download_path, name )
            )
        proxy_thread.daemon = True
        proxy_thread.start()
        Log("mp4 download started ")

##        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        endOfDirectory()
        return True

    raise Exception("should not reach here")
#__________________________________________________________________
#
def make_downloads_db():
    sql_command = (
        "CREATE TABLE IF NOT EXISTS downloads ("
        #"CREATE TABLE downloads ("
        "name"
        ", url"
        ", file_spec"
        ", expected_size"
        ", start_time"
        ", update_time"
        ", current_size"
        ", current_data_rate"
        ", expected_end_time"
        ");"
        )
    Log("sql_command='{}'".format(sql_command) )#, LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        conn.text_factory = str
        downDB_cursor = conn.cursor()
        downDB_cursor.executescript(sql_command)
        conn.commit()
##        Log(repr(active_downloads()), LOGNONE)
    finally:
        if conn: conn.close()
    return True

#__________________________________________________________________
#
def db_date_formatter(date):
    return date.isoformat() #strftime("%Y%m%d.%H%M%S")
#__________________________________________________________________
#
def clean_downloads(days_too_old=C.MAX_AGE_OLD_DOWNLOAD):
    Log("clean_downloads(days_too_old={}) start".format(days_too_old))
##    raise NotImplementedError('clean_downloads')
    too_old_day  = db_date_formatter(datetime.datetime.utcnow()-datetime.timedelta(days_too_old))
    too_old_hour = db_date_formatter(datetime.datetime.utcnow()-datetime.timedelta((days_too_old/24.0)))
    sql_command = (
        "SELECT name, url FROM downloads "
        "WHERE "
        "    (start_time  < '{}')"
        "    OR ( "
        "         (update_time < '{}') "
        "         AND "
        "         ( substr(file_spec,length(file_spec)-(length('.ts')-1)) != '.ts')"
	"	);"
        ).format(too_old_day,too_old_hour)
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        downDB_cursor = conn.cursor()
        downDB_cursor.execute(sql_command)
        cleanable_items = downDB_cursor.fetchall()
        conn.close()
        for name, url in cleanable_items:
            proxy_thread = threading.Thread(
                name="download_cleaner."+Clean_Filename(name)
                ,target=Stop_Download
                ,args=(url,name,False)
                )
            proxy_thread.daemon = True
            proxy_thread.start()
    finally:
        if conn: conn.close()
    Log("clean_downloads end")
    return True
#__________________________________________________________________
#
def active_downloads():
    make_downloads_db()
    active = None
    sql_command = "SELECT * FROM downloads"
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        downDB_cursor = conn.cursor()
        downDB_cursor.execute(sql_command)
        active = downDB_cursor.fetchall()
##        Log(repr(active), LOGNONE)
    finally:
        if conn: conn.close()
    return active
#__________________________________________________________________
#
def delete_download(url):
    sql_command = "DELETE FROM downloads WHERE url = '{}'".format(sanitize_sql(url))
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        conn.execute(sql_command)
        conn.commit()
    finally:
        if conn: conn.close()
    return True
#__________________________________________________________________
#
def add_download(name, url, file_spec, expected_size, start_time):
    make_downloads_db()
    sql_command_1 = (
        "SELECT file_spec FROM downloads " #url could be different when retrying same download
        #"WHERE  file_spec LIKE '{}'".format(sanitize_sql(file_spec))
        "WHERE  file_spec LIKE (?)"
        )
    sql_command_2 = (
        "INSERT INTO downloads "
        "( name"
        ", url"
        ", file_spec"
        ", expected_size"
        ", start_time" #note: start time is a parameter in order to force consistent formatting
        ", update_time" #record dead if something has not updated recently
        ") VALUES "
        "(?, ?, ?, ?, ?, ?)"
##        "'{}','{}','{}','{}','{}','{}'"
##        ")".format(
##              sanitize_sql(name)
##            , sanitize_sql(url)
##            , sanitize_sql(file_spec)
##            , sanitize_sql(str(expected_size)) #size can be None
##            , sanitize_sql(start_time)
##            , sanitize_sql(start_time)
##            )
        )
    Log("sql_command_1='{}'".format(sql_command_1) )#,LOGNONE)
    Log("sql_command_2='{}'".format(sql_command_2) )#,LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        downDB_cursor = conn.cursor()
        #downDB_cursor.execute(sql_command_1)
        #Log(   (sanitize_sql(file_spec))  )
        downDB_cursor.execute(
            sql_command_1
            , (sanitize_sql(file_spec),)
            )
        items = downDB_cursor.fetchall()
        if len(items) > 0 :
            Log("url already there")
            return False
        else:
##            downDB_cursor.execute(sql_command_2)
            downDB_cursor.execute(
                sql_command_2
                ,   ( sanitize_sql(name)
                    , sanitize_sql(url)
                    , sanitize_sql(file_spec)
                    , sanitize_sql(str(expected_size)) #size can be None
                    , sanitize_sql(start_time)
                    , sanitize_sql(start_time)
                    )
                )                
            conn.commit()
    finally:
        if conn: conn.close()
    return True
#__________________________________________________________________________
#
def sanitize_sql(information):
    if sqlite3.complete_statement(information):
        raise sqlite3.IntegrityError
    return information #.replace("'", "''")
#__________________________________________________________________________
#
def un_sanitize_sql(information):
    return information
    #return urllib.unquote_plus(information) #todo: unsanitize info to prevent bad sql command
#__________________________________________________________________________
#
