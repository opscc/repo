'''
    Ultimate Whitecream
    Copyright (C) 2018 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import json
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

FRIENDLY_NAME = '[COLOR {}]Hentai Haven[/COLOR]'.format(utils.time_text_color)
LIST_AREA = utils.LIST_AREA_HENTAI
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://hentaihaven.co"

SEARCH_URL = ROOT_URL + '/wp-admin/admin-ajax.php'

URL_RECENT = ROOT_URL + '/wp-admin/admin-ajax.php'

#URL_CATEGORIES_1 = ROOT_URL + '/genre/hentai-uncensored/page/{}/'
#URL_CATEGORIES_1 = ROOT_URL + '/genre/hentai-uncensored-on/page/{}/'

URL_CATEGORIES_1 = ROOT_URL + '/uncensored1/page/{}/'


URL_CATEGORIES_2021 = ROOT_URL +  '/genre/2021/page/{}/'
URL_CATEGORIES_2020 = ROOT_URL +  '/genre/2020/page/{}/'
URL_CATEGORIES_2019 = ROOT_URL +  '/genre/2019/page/{}/'
URL_CATEGORIES_2018 = ROOT_URL +  '/genre/2018/page/{}/'
URL_CATEGORIES_2017 = ROOT_URL +  '/genre/2017/page/{}/'
URL_CATEGORIES_2016 = ROOT_URL +  '/genre/2016/page/{}/'
URL_CATEGORIES_2015 = ROOT_URL +  '/genre/2015/page/{}/'

MAIN_MODE       = '460'
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
REFRESH_MODE       = str(int(MAIN_MODE) + 4)
SEARCH_MODE        = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#


@utils.url_dispatcher.register(MAIN_MODE)
def Main():
##
##    utils.addDir(name="{}[COLOR {}]Uncensored[/COLOR]".format( 
##        SPACING_FOR_TOPMOST, utils.search_text_color)
##        ,url=URL_CATEGORIES_1
##        ,mode=LIST_MODE 
##        ,iconimage=utils.category_icon
##        , end_directory=True, keyword='', page=1         )
##
##    utils.addDir(name="{}[COLOR {}]2020[/COLOR]".format( 
##        SPACING_FOR_TOPMOST, utils.search_text_color)
##        ,url=URL_CATEGORIES_2020
##        ,mode=LIST_MODE 
##        ,iconimage=utils.category_icon
##        ,end_directory=True, keyword='', page=1       )
##    
##    utils.addDir(name="{}[COLOR {}]2019[/COLOR]".format( 
##        SPACING_FOR_TOPMOST, utils.search_text_color)
##        ,url=URL_CATEGORIES_2019
##        ,mode=LIST_MODE 
##        ,iconimage=utils.category_icon
##        ,end_directory=True, keyword='', page=1         )
##    
##    utils.addDir(name="{}[COLOR {}]2018[/COLOR]".format( 
##        SPACING_FOR_TOPMOST, utils.search_text_color)
##        ,url=URL_CATEGORIES_2018
##        ,mode=LIST_MODE 
##        ,iconimage=utils.category_icon
##        ,end_directory=True, keyword='', page=1         )
##
##    utils.addDir(name="{}[COLOR {}]2017[/COLOR]".format( 
##        SPACING_FOR_TOPMOST, utils.search_text_color)
##        ,url=URL_CATEGORIES_2017
##        ,mode=LIST_MODE 
##        ,iconimage=utils.category_icon 
##        ,end_directory=True, keyword='', page=1         )
##    
##    utils.addDir(name="{}[COLOR {}]2016[/COLOR]".format( 
##        SPACING_FOR_TOPMOST, utils.search_text_color)
##        ,url=URL_CATEGORIES_2016
##        ,mode=LIST_MODE 
##        ,iconimage=utils.category_icon 
##        ,end_directory=True, keyword='', page=1         )
##    
##    utils.addDir(name="{}[COLOR {}]2015[/COLOR]".format( 
##        SPACING_FOR_TOPMOST, utils.search_text_color)
##        ,url=URL_CATEGORIES_2015
##        ,mode=LIST_MODE 
##        ,iconimage=utils.category_icon
##        ,end_directory=True, keyword='', page=1         )

    
##    utils.addDir('[COLOR hotpink]Uncensored[/COLOR]','https://animeidhentai.com/genre/hentai-uncensored/', 661, '', '')
##    utils.addDir('[COLOR hotpink]Search[/COLOR]','https://animeidhentai.com/?s=', 664, '', '')
##    animeidhentai_list('https://animeidhentai.com/genre/2019/')

    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon, page=1)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=utils.FLAG_RECURSE_NEXT_PAGES)


    #
    # read html
    #
    from requests import Request, Session
    s = Session()
    headers = {
        "User-Agent": utils.USER_AGENT
        , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        , "Accept": "*/*"
        , "Origin": ROOT_URL
        , "X-Requested-With": "XMLHttpRequest"
        , "Referer": ROOT_URL
        , "Accept-Encoding": "gzip"
        , "Accept-Language": "en-US,en;q=0.9"
    }

    data = "action=action_pagination&genre=all&page={}&typex=newest&search={}&pagetype=home".format(page, 'all')
    video_region = utils.postHtml(url, sent_data=data, headers=headers)

##    proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
##    #proxies = {"https": "127.0.0.1:8888"}
##    #data = "action=ajax_pagination&query_vars=null&page={}&order=latest&search={}".format(page, keyword)
##    data = "action=action_pagination&genre=all&page={}&typex=newest&search={}&pagetype=home".format(page, 'all')
##    Log("data='{}'".format(data))
##    req = Request('POST', url, data=data, headers=headers)
##    prepped = s.prepare_request(req)
##    resp = s.send(prepped , verify=False, proxies=proxies)
##    if resp.apparent_encoding == 'gzip':
##        buf = StringIO( resp.content)
##        f = gzip.GzipFile(fileobj=buf)
##        video_region = f
##    else:
##        video_region = resp.content

##    Log("video_region={}".format(video_region))
    
    if "but no results were found" in video_region or "No hay articulos" in video_region:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)

    Parse_List_Items(video_region, keyword)

    #
    # next page items
    #
##    try:
##        regex = 'class="loop-nav-inner"(.+)'
##        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##    except:
##        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
##        next_page_html = listhtml
##    next_page_regex = 'pagination.+?"[^"]+/page/(\d+)/" class="next'
##    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    ##
    np_info = 'fake'  #2020-08 site does not have working last page, im not going to work for it
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_number=int(page) + 1
            Log("np_number={}".format(np_number))
            np_url = url
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword, page=np_number)
            break

                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
def Parse_List_Items(video_region, keyword):

    #
    # parse out list items
    #
    regex = '<a class="thumbnail-image".+?src="([^"]+)".+?class="tags">(.+?)class="description".+?href="([^"]+)">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #Log("info={}".format(info))
    if len(info) < 1:
        label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
        
    for thumb, other, videourl, label  in info:
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in label: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("duration={}".format(duration))
##        Log("other={}".format(other))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , desc = ROOT_URL
            , iconimage = thumb)

    regex = 'div class="result-item".*?<a href="([^"]+)">.*?<img\s*src="([^"]+)"\s*alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label   in info:
        Notify("skipped " + label)

        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    html = utils.getHtml(url, ROOT_URL)
    regex = '<iframe src="([^"]+)"'
    next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)[0]

    html = utils.getHtml(next_link, url)
    isHLS = False
    try:
        #working 2020-07
        from resources.lib import jsunpack
        unpacked_src = jsunpack.unpack(html)
        Log("unpacked_src='{}'".format(unpacked_src))
        
        regex = 'sources:(\[.*?\])'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
        Log("sources_list='{}'".format(sources_list))
        sources = json.loads(sources_list[0])
        Log("sources='{}'".format(sources))
        Log("sources[file]='{}'".format(sources[0]['file']))
        video_url = sources[0]['file']

    except:
        #working 2020-08
        regex = 'FirePlayer\(vhash, (.+), false\);'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
        Log("sources_list='{}'".format(sources_list))
        sources = json.loads(sources_list[0])
        Log("sources='{}'".format(sources))
        video_url = "https://htstreaming.com{}?s={}&d=".format(sources['videoUrl'], sources['videoServer'])
        #https://htstreaming.com/cdn/hls/b4351fbdd294cc1f13037ff2e7cb9d6d/master.txt?s=sv2&d=
        #https://htstreaming.com/cdn/hls/d249a6fc7236089b3bfe84fde25f9d59/master.txt/?s=sv2&d=
        Log("video_url={}".format(video_url.encode()))
        isHLS = sources['videoData']['videoSources'][0]['type'] == u'hls'

    headers = {
        'User-Agent': utils.USER_AGENT
        ,'Referer': next_link
       }
    headers = utils.DEFAULT_HEADERS.copy()
    headers['Referer'] = next_link

    video_url +=  utils.Header2pipestring(headers)  #required or else acces denied
    Log("video_url={}".format(video_url.encode()))


##    utils.playvid(video_url, name, download, description=ROOT_URL)
##    return

    if isHLS:
        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        proxy = None
        #proxy = "127.0.0.1:8888"
        streamtype = 'HLSREDIR'
        #streamtype = 'TSDOWNLOADER'
##        streamtype = 'HLS'
        streamtype = 'HLSRETRY'
        download_path = ""
        if download == 1:
            download_path = utils.Make_download_path(name,file_extension='.mp4')
            
        f4mp.playF4mLink(
            video_url
            , name = name
            , proxy = proxy
            , use_proxy_for_chunks = False
##            , maxbitrate = utils.MAX_BIT_RATE
            , simpleDownloader = False
            , auth = None
            , streamtype = streamtype
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , download_path = download_path
            )
            
        return
    

    if download == 1:
        utils.downloadVideo(video_url, name)
    else:    
        import xbmc, xbmcgui
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name)
        xbmc.Player().play(item=video_url, listitem=listitem)
        
    return
            
##    referrer = url
##    html = utils.getHtml(url, referrer)
##    utils.playvideo(videosource=html, url=url, name=name, download=download, description=name)
##    return

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, '')

    regex = '<li.+?class=".+?menu-item-object-post_tag.+?"><a href="(.+?)">(.+?)</a></li>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    for videourl, label in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        keyword = videourl.split('tag/')[1].split('/')[0]
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,keyword=keyword )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
##    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=1):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon, page=1)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=utils.FLAG_RECURSE_NEXT_PAGES)
        
    from requests import Request, Session
    s = Session()
    url = searchUrl
    headers = {
        "User-Agent": utils.USER_AGENT
        , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        , "Accept": "*/*"
        , "Origin": ROOT_URL
        , "X-Requested-With": "XMLHttpRequest"
        , "Referer": ROOT_URL + "/search/{}".format(keyword)
        , "Accept-Encoding": "gzip"
        , "Accept-Language": "en-US,en;q=0.9"
    }

    data = "action=action_update_search_term&term={}".format(keyword)
    page_html = utils.postHtml(url, sent_data=data, headers=headers)

    
##    proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
##    #proxies = {"https": "127.0.0.1:8888"}
##    data = "action=action_update_search_term&term={}".format(keyword)
##    Log("data='{}'".format(data))
##    req = Request('POST', url, data=data, headers=headers)
##    prepped = s.prepare_request(req)
##    resp = s.send(prepped , verify=False, proxies=proxies)
##
##    if resp.apparent_encoding == 'gzip':
##        buf = StringIO( resp.content)
##        f = gzip.GzipFile(fileobj=buf)
##        page_html = f
##    else:
##        page_html = resp.content
##    Log("page_html='{}'".format(page_html))

    search_results_regex = 'href="([^"]+)"'
    sub_pages = re.compile(search_results_regex, re.DOTALL | re.IGNORECASE).findall(page_html)

    for sub_page in sub_pages:

        page_html = utils.getHtml(sub_page, ROOT_URL)        
        #
        # parse out list items
        #
        Parse_List_Items(page_html, keyword)
    

##    next_page_regex = 'current" class="page-link" href="' + searchUrl + '(?:\?paged=\d+|)">(\d+)<'
##    Log("next_page_regex='{}'".format(next_page_regex))
##    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(page_html)
##
##    last_page_regex = searchUrl + '\?paged=(\d+)" class="next'
##    Log("last_page_regex='{}'".format(next_page_regex))    
##    lp_info = re.compile(last_page_regex, re.DOTALL | re.IGNORECASE).findall(page_html)
##    
##    if lp_info and np_info:
##        if str(lp_info[0]) == str(np_info[0]):
##            Log("lp_info found; setting np to empty set")
##            np_info = {}
##    if not np_info:
####        Log("page_html='{}'".format(page_html))
##        Log("np_info not found")
##    for np_number in np_info:
##        Log("more pages")
##        np_number = int(np_number) + 1
##        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
##        if end_directory == True:
##            utils.addDir(
##                name= np_label
##                ,url=SEARCH_URL 
##                ,mode=SEARCH_MODE 
##                ,iconimage=utils.next_icon 
##                ,page=np_number
##                ,keyword=keyword
##                ,end_directory=end_directory)
##        else:
##            if int(np_number) <= (max_search_depth):
##                utils.Notify(msg=SEARCH_URL.format(keyword, np_number), duration=200)  #let user know something is happening
##                Search(searchUrl=searchUrl, keyword=keyword, end_directory=end_directory, page=np_number)
##        break #there should not be any more...but just in case
            
    if end_directory == True or str(page) == utils.FLAG_RECURSE_NEXT_PAGES:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

 
