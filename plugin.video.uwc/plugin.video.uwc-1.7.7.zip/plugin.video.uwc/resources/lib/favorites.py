'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sqlite3

import re

import xbmc, xbmcplugin

from resources.lib import utils
from resources.lib.utils import Log as Log

from sites.chaturbate import ROOT_URL as chaturbate_ROOT_URL
from sites.chaturbate import PLAY_MODE as chaturbate_PLAY_MODE
from sites.chaturbate import clean_database as chaturbate_clean
from sites.chaturbate import GetCamgirlList as chaturbate_getCamgirlList

from sites.cam4 import ROOT_URL as cam4_ROOT_URL
from sites.cam4 import PLAY_MODE as cam4_PLAY_MODE
from sites.cam4 import clean_database as cam4_clean
from sites.cam4 import GetCamgirlList as cam4_GetCamgirlList

from sites.streamate import ROOT_URL as streamate_ROOT_URL
from sites.streamate import PLAY_MODE as streamate_PLAY_MODE
from sites.streamate import clean_database as streamate_clean
from sites.streamate import GetCamgirlList as streamate_GetCamgirlList

from sites.naked import ROOT_URL as naked_ROOT_URL
from sites.naked import PLAY_MODE as naked_PLAY_MODE
from sites.naked import clean_database as naked_clean
from sites.naked import GetCamgirlList as naked_GetCamgirlList

from sites.bongacams import ROOT_URL as bongacams_ROOT_URL
from sites.bongacams import PLAY_MODE as bongacams_PLAY_MODE
from sites.bongacams import clean_database as bongacams_clean
from sites.bongacams import GetCamgirlList as bongacams_GetCamgirlList

from sites.myfreecams import ROOT_URL as mfc_ROOT_URL
from sites.myfreecams import PLAY_MODE as mfc_PLAY_MODE
from sites.myfreecams import getCamgirlList as mfc_getCamgirlList
from sites.myfreecams import getCamgirlInfo as getCamgirlInfo
from sites.myfreecams import clean_database as mfc_clean

import time
import traceback

favoritesdb = utils.favoritesdb

conn = sqlite3.connect(favoritesdb)
c = conn.cursor()
try:
    c.executescript("CREATE TABLE IF NOT EXISTS favorites (name, url, mode, image);")
    c.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
except:
    pass
conn.close()

REFRESH_IMAGES_MODE = '898'
REFRESH_CONTAINER_MODE = '899'


##@utils.url_dispatcher.register(REFRESH_IMAGES_MODE)
def RefreshImages():
    chaturbate_clean(False)
    cam4_clean(False)
    naked_clean(False)
    mfc_clean(False)
    streamate_clean(False)
    bongacams_clean(False)


@utils.url_dispatcher.register(REFRESH_CONTAINER_MODE)  
def RefreshContainter():
    xbmc.executebuiltin('Container.Refresh')

@utils.url_dispatcher.register(utils.ROOT_INDEX_FAVORITES)  
def List():

    if utils.addon.getSetting("auto_clean_img_database").lower() == "true":
        RefreshImages()

    manually_refresh_favorites = (utils.addon.getSetting("manually_refresh_favorites").lower() == "true")
##    hq_bonus = int(utils.addon.getSetting("hq_bonus").lower())
    play_method = str(utils.addon.getSetting("default_playmode").lower())

    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()

    utils.addDir(
        name="{}[COLOR {}]Refresh[/COLOR]".format(utils.SPACING_FOR_TOPMOST, utils.refresh_text_color)
        ,url='' 
        ,mode=REFRESH_CONTAINER_MODE 
        ,iconimage=utils.refresh_icon
        ,duration=1 #55*60*60+55*60+55
        ,Folder=False )
    
    try:

        try:
            bongacams_girls = None
            bongacams_girls_favorites = (utils.addon.getSetting("bongacams_girls_favorites").lower() == "true")
            if bongacams_girls_favorites:
                bongacams_girls, online_count = bongacams_GetCamgirlList(depth=2, notify=False)
        except: traceback.print_exc()
        try:
            naked_girls = None
            naked_girls_favorites = (utils.addon.getSetting("naked_girls_favorites").lower() == "true")
            if naked_girls_favorites:
                naked_girls = naked_GetCamgirlList(depth=2, notify=False)
        except: traceback.print_exc()
        try:
            streamate_girls = None
            streamate_girls_favorites = (utils.addon.getSetting("streamate_girls_favorites").lower() == "true")
            if streamate_girls_favorites:
                streamate_girls = streamate_GetCamgirlList(depth=2, notify=False)
        except: traceback.print_exc()
        try:
            cam4_girls = None
            cam4_girls_favorites = (utils.addon.getSetting("cam4_girls_favorites").lower() == "true")
            if cam4_girls_favorites:
                cam4_girls = cam4_GetCamgirlList(notify=False)
        except: traceback.print_exc()
        try:
            chaturbate_girls = None
            chaturbate_girls_favorites = (utils.addon.getSetting("chaturbate_girls_favorites").lower() == "true")
            if chaturbate_girls_favorites:
                chaturbate_girls = chaturbate_getCamgirlList(depth=3, notify=False)
        except: traceback.print_exc()
        try:
            mfcgirls = None #when testing
            mfc_girls_favorites = (utils.addon.getSetting("mfc_girls_favorites").lower() == "true")
            if mfc_girls_favorites:
                mfcgirls = mfc_getCamgirlList(notify=True) #note: slower than most
        except: traceback.print_exc()
        
        c.execute("SELECT * FROM favorites")        
        for (name, url, mode, img) in c.fetchall():
            
            try:

##                Log("name='{}',url='{}',mode='{}',img='{}'".format(name, url, mode, img))
                
                if cam4_girls and str(mode)==cam4_PLAY_MODE :
                    root_url = cam4_ROOT_URL
                    model_found = False
                    for model in cam4_girls:
                        if name == model["username"]:
                            model_found = True
                            break
                    if model_found:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = utils.PLAYMODE_DEFAULT
                        model['description'] = root_url
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        )

                elif bongacams_girls and str(mode)==bongacams_PLAY_MODE :
                    root_url = bongacams_ROOT_URL
                    model_found = False
                    for model in bongacams_girls:
                        if name == model["username"]:
                            model_found = True
                            break
                    if model_found:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = utils.PLAYMODE_DEFAULT
                        model['description'] = root_url
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        )

                elif naked_girls and str(mode)==naked_PLAY_MODE :
                    root_url = naked_ROOT_URL
##                    Log("name='{}',url='{}',mode='{}',img='{}'".format(name, url, mode, img))
####                    model_found = False
##                    for model in naked_girls:
##                        if name == model:
##                            Log("'{}'".format(naked_girls[model]))
##                            model_found = True
##                            Log("name='{}',url='{}',mode='{}',img='{}'".format(name, url, mode, img))
##                            break
####                    if model_found:
                    
                    # trying two ways to do this, not sure which is better
                    # naked_girls as a list [6 lines, used in the other items], or naked_girls as a dictionary [4 lines]
                    model = None
                    if name in naked_girls:
                        model = naked_girls[name]
                        Log("'{}'".format(model))
                    if model:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = utils.PLAYMODE_DEFAULT
                        model['description'] = root_url
                        model['video_host'] = None
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        , hq_stream = model['video_host']
                        )
                    
                elif streamate_girls and str(mode)==streamate_PLAY_MODE :
                    root_url = streamate_ROOT_URL
                    model_found = False
                    for model in streamate_girls:
                        if name == model["username"]:
                            model_found = True
                            break
                    if model_found:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = utils.PLAYMODE_DEFAULT
                        model['description'] = root_url
                        model['username'] = ''
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        , date = model['username']
                        )
                    


                elif chaturbate_girls and str(mode)==chaturbate_PLAY_MODE :
                    root_url = chaturbate_ROOT_URL
                    model_found = False
                    for model in chaturbate_girls:
                        if name == model["username"]:
                            model_found = True
                            break
                    if model_found:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = utils.PLAYMODE_DEFAULT
                        model['description'] = root_url
                        model['username'] = ''
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        )

                elif mfcgirls and str(mode)==mfc_PLAY_MODE:
                    #Log("mfc img='{}'".format(name))
                    root_url = mfc_ROOT_URL
                    
                    serverNumber,modelID,hq_stream,camscore, icon_img, icon_label = getCamgirlInfo(name, mfcgirls)
                    if not camscore: camscore=0
                    
                    Log("name={},serverNumber={},modelID={},hq_stream={},camscore={},icon_img={},icon_label={}".format(name,serverNumber,modelID,hq_stream,camscore, icon_img, icon_label))
                    if serverNumber > 0: #    if model server found; an online/active image can be used

##                        if hq_stream and hq_bonus:
##                            camscore = camscore * hq_bonus
                            
                        utils.addDownLink(
                            name = icon_label
                            , url = url
                            , mode = mode
                            , iconimage = icon_img
                            , fav = 'del'
                            , duration=str(int(camscore))
                            , play_method=utils.PLAYMODE_DEFAULT
                            , hq_stream=hq_stream
                            , desc = root_url
                            )
                        #, stream = True #must be true to use setResolvedUrl
                    else:  #else use default avatar image 
                        if "snap.mfcimg.com/" in img:
                            modelid = img.split('/')[6]
                            #the 1 indicates model was in public chat when bookmark created
                            if modelid.startswith("mfc_a_1"):
                               modelid = modelid[len("mfc_a_1"):] 
                            if modelid.startswith("mfc_1"):
                               modelid = modelid[len("mfc_1"):] 
                            if modelid[0] == '0':
                                modelid = modelid[1:] #trim zero from front
                            img = "https://img.mfcimg.com/photos2/{}/{}/avatar.300x300.jpg".format(modelid[:3], modelid)
                        utils.addDownLink(
                            name = name
                            , url = url
                            , mode = mode
                            , iconimage = img
                            , fav = 'del'
                            , duration=str(int(camscore))
                            , desc = root_url
                            )


                else:
                    utils.addDownLink(name.strip(), url, int(mode), img, '', '', 'del')

            except:
                traceback.print_exc()

        
    except Exception,e:
        Log("Exception,e={}".format(str(e)), xbmc.LOGERROR)
        utils.notify('No Favorites','No Favorites found')

    utils.add_sort_method()
    utils.endOfDirectory(cacheToDisc= ( manually_refresh_favorites == True) )

    conn.close()
    return


@utils.url_dispatcher.register(utils.FAVORITES_MODE, ['fav','favmode','name','url','img'])  
def Favorites(fav,favmode,name,url,img):
    if fav == "add":
        delFav(url)
        addFav(favmode, name, url, img)
        utils.Notify("Added fav:'{}' url:{}".format(name,url))
                     
    elif fav == "del":
        delFav(url)
        utils.Notify("Deleted fav:{} url:{}".format(name,url))
        #xbmc.executebuiltin('Container.Refresh')

def clean_filename(s):
    if not s:
        return ''
    s = re.sub(u'(?is)[^A-Za-z0-9~_\]\[ \/,\'.&]','',s)
    return s.strip();

def addFav(mode,name,url,img):

    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = name.strip('\r')
    #name = clean_filename(name)
    name = name.strip(' ')
    if "[/COLOR]" in name:
        n1 = name.split("[/COLOR]")
        if n1[1] == '': name = n1[0]
        else: name = n1[1]
        if "[COLOR" in name:
            name = name.split("[COLOR")[0]
        name = name.strip(' ')

    utils.Log("name='{}'".format(name))
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("INSERT INTO favorites VALUES (?,?,?,?)", (name, url, mode, img))
    conn.commit()
    conn.close()

def delFav(url):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM favorites WHERE url = '%s'" % url)
    conn.commit()
    conn.close()
