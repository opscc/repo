#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import sqlite3
import threading
import traceback
from uuid import uuid4
import xbmc
#import internal addon libraries
import utils
import constants as C
import queries as Q
#define frequenctly used aliases
from utils import Log,LogR
from constants import Queue
from constants import unquote_plus

KEYWORD_DB_VERSION_1 = 1
KEYWORD_DB_VERSION_2 = 2
KEYWORD_DB_VERSION_3 = 3
KEYWORD_DB_VERSION_CURRENT = KEYWORD_DB_VERSION_3


#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
##        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ADD_KEYWORD, ['channel'])
def NewSearchKeyword(channel):
    LogR((__name__,locals()))
##    Log("NewSearchKeyword channel='{}'".format( channel))

    Log("NewSearchKeyword channel='{}'".format( channel))
    vq = _get_keyboard(heading="Searching for...")
    if (not vq):
        return False, 0
    keyword = utils.quote_plus(vq)
##    Log('todo, uncomment above',C.LOGWARNING)
##    keyword = 'maya'
    AddKeyword(keyword)

    if channel:
        Quick_Search(
            url=C.DO_NOTHING_URL
            ,channel = channel
            ,keyword=keyword
            ,bulk_operation=False
            )
        utils.endOfDirectory()

    #2025-07 currently endOfDirectory error message because I want folder-like
        # xbmc dir stuff when adding keyword+channel<>null
        # but xbmc item stuff when channel==null
#__________________________________________________________________
#
def TableCreateString(db_version):
    if db_version == KEYWORD_DB_VERSION_1:
        return (
            "keyword TEXT"
            )
    if db_version == KEYWORD_DB_VERSION_2:
        return (
            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL DEFAULT 0 UNIQUE"
            ", keyword TEXT UNIQUE"
            ", sequence INTEGER DEFAULT 0"
            )
    else:
        raise Exception('unkown DB version {}'.format(repr(db_version)))
#__________________________________________________________________
#
def Create_Table(local_db_conn):
    sql_command = ( 'pragma user_version' )
    LogR(sql_command)
    db_cursor = local_db_conn.cursor()
    try: #update schema
        user_version = db_cursor.execute( sql_command ).fetchone()[0]
        LogR(user_version)
##sqllite does not allow setting primary key or autoincrement; migration is only option
        if user_version in [None,0,KEYWORD_DB_VERSION_1]:
            sql_command  = "BEGIN TRANSACTION;"
            sql_command += "ALTER TABLE main.keywords RENAME TO keywords_{};".format(user_version)
            sql_command += "CREATE TABLE keywords ("
            sql_command += TableCreateString(KEYWORD_DB_VERSION_CURRENT)
            sql_command += ");"
            sql_command += 'INSERT INTO keywords (keyword) SELECT distinct keyword from keywords_{};'.format(user_version)
            #sql_command += 'drop table keywords_{};'.format(user_version)
            sql_command +=  "COMMIT;"
            sql_command += "PRAGMA user_version = {};".format(KEYWORD_DB_VERSION_CURRENT)
            local_db_conn.executescript(sql_command)
        else:
            raise  NotImplementedError(__name__,user_version)
    
##    except sqlite3.OperationalError as ex:
##        LogR(ex)
    finally:
        db_cursor.close()
        

#__________________________________________________________________
#
def Get_DB_PRAGMA_version(db_conn): #favDB_conn
    sql_command = "PRAGMA user_version;"
    Log("sql_command='{}'".format(sql_command) )
    id_column_count =  db_conn.execute( sql_command )
    for a in id_column_count:
        return a[0]
#__________________________________________________________________
#
def Get_DB_PRAGMA_filename(db_conn):
    sql_command = 'SELECT file FROM pragma_database_list;'
    Log("sql_command='{}'".format(sql_command) )
    id_column_count =  db_conn.execute( sql_command )
    for a in id_column_count:
        return a[0]

#__________________________________________________________________________
#
def Create_Keyword_Table(db_conn):
    query = Q.KEYWORD_SCHEMA_STRING(KEYWORD_DB_VERSION_CURRENT, None)
    result = db_conn.executescript(query)
#__________________________________________________________________________
#
def Import_Export(new_db_conn, old_db_conn):
    new_f = Get_DB_PRAGMA_filename(new_db_conn)
    old_f = Get_DB_PRAGMA_filename(old_db_conn)
    new_v = Get_DB_PRAGMA_version(new_db_conn)
    old_v = Get_DB_PRAGMA_version(old_db_conn)

    C.DEBUG = True
    max_rows = 1000
    newdb_cursor = new_db_conn.cursor()
    olddb_cursor = old_db_conn.cursor()

    Create_Keyword_Table(new_db_conn)

    LogR(new_db_conn.total_changes)
    
    def row_generator(db_cursor):
        query = "select keyword, sequence from keywords"
##        Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
        params = ()
        db_cursor.row_factory = sqlite3.Row
        try:
            db_cursor.execute(query, params)
            for a in db_cursor.fetchmany(size=max_rows):
    ##            LogR(list(a))
                yield(a)
        except:
            Log('probably no fav table')

    for cur_data in row_generator(olddb_cursor):
        try:
            query = Q.INSERT_KEYWORD(KEYWORD_DB_VERSION_CURRENT)
            params = tuple(cur_data) + (utils.UTC_timestamp(),str(uuid4()))
##            Log(query.replace("?", "'%s'") % tuple(params))  #see exact query during debugging
            result = newdb_cursor.execute(query, params )
            if result.rowcount > 0:
                LogR(("inserted rows", result.rowcount))
##                loop_number_changed_rows += result.rowcount
        except sqlite3.IntegrityError as e:
            if e.args != ('UNIQUE constraint failed: keywords.keyword',):
                LogR(e.args)
                Log(query.replace("?", "'%s'") % tuple(params))  #see exact query during debugging
                raise
        except:
            Log(query.replace("?", "'%s'") % tuple(params))  #see exact query during debugging
            raise

    LogR(new_db_conn.total_changes)
    new_db_conn.commit()
    LogR(new_db_conn.total_changes)
##    new_db_conn.close()
    Log('Import_Export finished')
#__________________________________________________________________________
#
def AddKeyword(keyword):
    Log("AddKeyword keyword='{}'".format(keyword))

    favDB_conn = sqlite3.connect(C.favoritesdb)
    local_db_conn = sqlite3.connect(C.keywordsdb)

    Import_Export(local_db_conn, favDB_conn)

    query = Q.INSERT_KEYWORD(KEYWORD_DB_VERSION_CURRENT)
    params = (keyword, 0, utils.UTC_timestamp(),str(uuid4()))
    Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
    try:
        result = local_db_conn.execute(query, params)
        LogR(list(result))
        local_db_conn.commit()
    except sqlite3.IntegrityError as e:
        if e.args != ('UNIQUE constraint failed: keywords.keyword',):
            LogR(e.args)
            Log(query.replace("?", "'%s'") % tuple(cur_data))  #see exact query during debugging
            raise      
        
##    Create_Table(favDB_conn)
##   
##    db_cursor = local_db_conn.cursor()
##    try:
##        db_cursor.execute("INSERT INTO keywords (keyword) VALUES (?)", (keyword,))
##        favDB_conn.commit()
##    except sqlite3.IntegrityError:
##        ##UNIQUE constraint failed: keywords.keyword
##        pass

    LogR(local_db_conn.total_changes)
    local_db_conn.close()
    favDB_conn.close()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.DELETE_KEYWORD, ['keyword'])
def delKeyword(keyword):
    Log("keyword delete requested for '{}'".format(keyword), C.LOGNONE)
    local_db_conn = sqlite3.connect(C.keywordsdb)
    query = Q.DELETE_KEYWORD(KEYWORD_DB_VERSION_CURRENT)
    params = (keyword,)
    Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
    result = local_db_conn.execute(query, params)
    LogR(list(result))
    local_db_conn.commit()
    Log("number of keywords deleted {}".format(local_db_conn.total_changes), C.LOGNONE)
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    C.QWIK_SEARCH
    , ['url', 'bulk_operation', 'channel']
    , ['end_directory','page_start','page_end','keyword']
    )
def Quick_Search(
    url
    , bulk_operation
    , channel # = C.ROOT_SEARCH_ALL
    , end_directory=False
    , page_start='1'
    , page_end='1'
    , keyword=None
    ):
    LogR(locals())

    if not keyword:
        ##get the search string from user; remember it; pre-populate remembered
        prev_search_string = C.this_addon.getSetting(id='quick_search_string')
        quick_search_string = _get_keyboard(
            heading="Search query"
            ,default=prev_search_string
            )
        if  quick_search_string == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.this_addon.setSetting(id='quick_search_string', value=quick_search_string)
    else:
        quick_search_string = keyword


    progress_dialog = utils.Progress_Dialog(
        C.addon_name
        ,u"searching '{}'".format(quick_search_string)
        )

    worker_threads = []
    monitor = xbmc.Monitor()

    try:
            
##        if bulk_operation:
##            end_directory = False #this sub will set the directory

        get_sites = utils.Get_Sites()
        i = 0
        
        try: 
            for sitename, module in get_sites:
                #if module.SEARCH_MODE == str(channel) or (C.ROOT_SEARCH_ALL == str(channel)):
                if str(channel) in [module.SEARCH_MODE, C.ROOT_SEARCH_ALL]:
                    #testing
                    #i = i + 1 
                    if i > 20: break
                    #/testing
                    method_to_call = getattr(module, 'Search')
                    kwargs = {
                        "searchUrl": module.SEARCH_URL
                        ,"bulk_operation": bulk_operation
                        ,"keyword": quick_search_string
                        ,"end_directory": False #end_directory
                        ,"page_start": page_start
                        ,"page_end": page_end
                        ,"progress_dialog": progress_dialog
                        }
                    Log(sitename + repr(kwargs)
                        )

                    worker = threading.Thread(name=sitename
                                              ,target=method_to_call
##                                              ,args= (module.SEARCH_URL
##                                                     ,bulk_operation 
##                                                     ,quick_search_string
##                                                     ,end_directory
##                                                     ,page_start
##                                                     ,page_end
##                                                     ,progress_dialog
##                                                     )
                                              ,kwargs=kwargs
                                              )


                    worker.daemon = True
                    worker_threads.append(worker)
                    worker.start()
            

            max_time = 240 #seconds_to_wait_for_search
            cur_time = 0
            still_working = True
            while still_working :
                Log('still_working'
                    ,C.LOGNONE
                    )
                if progress_dialog.iscanceled():
                    Log("progress_dialog.iscanceled()")
                    break #stop waiting

                if cur_time > max_time:
                    Log("cur_time > max_time")
                    break #stop waiting
                    
                progress_dialog.increment_percent()
                cur_time += 1
                utils.Sleep(250)
                still_working = False
                for worker in worker_threads:
                    if worker.is_alive():
                        Log(worker.name + " is alive - warning"
                            ,C.LOGNONE
                            )
                        still_working = True
                        break #keep waiting for active task
                    else:
                        pass
                        
                
            get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
            
        except StopIteration:
            #Log("StopIteration")
            pass
        except GeneratorExit:
            #Log("GeneratorExit")
            pass
        except:
            traceback.print_exc()

    finally:
        try:
            LogR( ('len(worker_threads)',len(worker_threads) ) )
            for worker in worker_threads:
                if worker.isAlive():
                    Log("Warning: killed thread {}".format(repr(worker.name)))
                    worker._Thread__stop()
        except:
            traceback.print_exc()
                    
        if progress_dialog:
            if progress_dialog.iscanceled():
                utils.addDownLink(
                    name=C.STANDARD_MESSAGE_CANCELLED_SEARCH
                    ,url=C.DO_NOTHING_URL
                    ,duration = C.STANDARD_DURATION_REFRESH
                    ,mode=C.ROOT_INDEX_INDEX
                    )
            progress_dialog.close()

    Log("Quick_Search ended")
    utils.endOfDirectory(
        updateListing=False #2025-07-24 changemind
##        updateListing=True
        ,end_directory=end_directory
        )
    Log("Quick_Search ended")
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    C.ROOT_SEARCH_ALL
    , ['page_start']
    , ['page_end', 'keyword', 'end_directory']
    )
def Search_All(page_start=1, page_end=1, keyword=None, end_directory=True):

    if not keyword:
        searchDir(
            url=C.DO_NOTHING_URL
            , mode=C.ROOT_SEARCH_ALL
            , bulk_operation=True
            , end_directory=True
        )
        return
    
    #temporarilty force only  X   recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 2
    C.MAX_RECURSE_DEPTH = 2

    Quick_Search(
        url=C.DO_NOTHING_URL
        ,channel=C.ROOT_SEARCH_ALL
        ,keyword=keyword
        ,bulk_operation=True
        ,end_directory=False
        )

    utils.endOfDirectory()
#__________________________________________________________________________
#
def searchDir(url
              , mode
              , bulk_operation
              , page_start='1'
              , page_end=None
              , end_directory=False
              ):

    try:
        label = "{}[COLOR {}]Quick Search[/COLOR]".format(
            C.SPACING_FOR_TOPMOST
            ,C.search_text_color
            ) 
        utils.addDir(
            name=label
            ,url=url
            ,channel=mode
            ,mode=C.QWIK_SEARCH 
            ,iconimage=C.search_icon 
            ,page_start=page_start
            ,page_end=page_end
            ,bulk_operation=bulk_operation
            ,end_directory=True
            )

        utils.addDir(
            "{}[COLOR {}]Add Keyword[/COLOR]".format(
                C.SPACING_FOR_NEXT
                ,C.search_text_color
                )
            , url=''
            , mode=C.ADD_KEYWORD
            , channel=mode #(int(mode)//10*10)#each site is allocated 10 values
            , iconimage=C.search_icon
            )

        db_conn = sqlite3.connect(C.keywordsdb)
        Create_Keyword_Table(db_conn)
        db_cursor = db_conn.cursor()

        try:
            query = Q.LIST_KEYWORD(KEYWORD_DB_VERSION_CURRENT)
            params = []
##            Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
            for keyword in db_cursor.execute(query, params).fetchall():
                if C.PY2: keyword = unicode(keyword[0])
                if C.PY3: keyword = keyword[0]
                label = "{}[COLOR {}]{}[/COLOR]".format(
                    C.SPACING_FOR_NAMES
                    , C.time_text_color
                    , unquote_plus(keyword)
                    )
                utils.addDir(
                    name=label
                    , url=url 
                    , mode=mode
                    , iconimage=C.search_icon 
                    , page_start=page_start
                    , page_end=page_end
                    , keyword=keyword
                    , end_directory=True
                    )
        except:
##            traceback.print_exc()
##            pass
            raise
            
    except:
##        traceback.print_exc()
        raise

    utils.endOfDirectory()
#__________________________________________________________________________
#
