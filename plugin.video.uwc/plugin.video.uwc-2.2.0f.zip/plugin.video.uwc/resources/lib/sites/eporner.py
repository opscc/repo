'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#todo: when search for 'anal';  website will redirect to a cached list but we can't change page numbers


import re
import utils
import constants as C
from base_website import Base_Website
from utils import Log 
from utils import LogR

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]eporner[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True
    
    _ROOT_URL        = "https://www.eporner.com"
    _URL_CATEGORIES  = _ROOT_URL + '/cats/'
    _URL_RECENT      = _ROOT_URL + '/{}/'
    _SEARCH_URL      = _ROOT_URL + '/search/{}/{}/'
    _MAIN_MODE = C.MAIN_MODE_eporner
    _FIRST_PAGE = 1

    _LIST_REDIRECTED_URL_BECOMES_LISTURL = False
    _LIST_REDIRECTED_URL_BECOMES_LISTURL = True

    _size_filter_min = 800 #seconds ; shortest clip 


    _BAD_IMAGE_SIZES = [5175]

##2026-05-11 workaround found    
##    _MAX_RES_PLAY = 720     # 2026-04 site requires login for 1080
##    _MAX_RES_DOWNLOAD = 720 # 2026-04 site requires login for 1080

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "Video has been deleted"
        ,"..but you can check other awesome videos"
        ]
    #__________________________________________________________________________
    #specific header required for listing
##    _LIST_HEADERS = {
##        "Accept":"application/json, text/plain, */*"
##        ,"DNT":"1"
##        ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"
##        ,"Origin":"https://beeg.com"
##        ,"Referer":"https://beeg.com/"
##        ,"Accept-Encoding":"gzip, deflate"
##        ,"Accept-Language":"en-US,en;q=0.9"
##    }
    #__________________________________________________________________________
    # add an alternative way to resolve listing
    def List_URL_Normalize(self, url, page):
        if url.endswith('/1/'): #reduce 301 on this site for first pages
            url = url[:-2]
        return url

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = 'id="vidresults"(.+?)(?:class="clear"|id="foot")'
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        '<div class="mb(?:"| )'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?(?:data-src|img src)="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        '.+?class="mvhdico"'
        '.+?<span>(?P<hd>[^<]+)<'
        '.+?title="Duration">(?P<duration>[^<]+)<'
        )
    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = r'class="numlist2"(.+)'
    _REGEX_next_page_regex = r"<a href='([^']+?(\d+)\/)' class='nmnext' title='Next page'>"

    #__________________________________________________________________________
    #where categories can be found
    _REGEX_categories_region = 'id="div-search-results"(.+)id="foot'
    _REGEX_categories = (
        'class="categoriesbox".+?href="(?P<videourl>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        )
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = self._ROOT_URL + url
        url = url + "{}/"
        return url

    #__________________________________________________________________________
    #where playable urls live
##2026-05-11 commented out in order to implement 1080p download
##    _REGEX_play_region = (
##        '<div class="dloaddivcol">(.+?)</div>'
##        )
##    _REGEX_playsearch_01 = (
##        '<u>(?P<res>\d+)'
##        '.+?h264.+?href="(?P<url>[^"]+?)"'
##        )
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        _REGEX_play_region = (
            r'<div class="dloaddivcol">(.+?)</div>'
            )
        _REGEX_playsearch_01 = (
            r'<u>(?P<res>\d+)'
            r'.+?h264.+?href="(?P<url>[^"]+?)"'
            )

        sources_region = re.compile(_REGEX_play_region, re.DOTALL | re.IGNORECASE).findall(full_html)
        if not sources_region:
            Log('warning sources_region')
            return
        else:
            sources_region = sources_region[0]
            
        sources_list = re.compile(_REGEX_playsearch_01, re.DOTALL | re.IGNORECASE).finditer(sources_region)
        if not sources_list:
            Log('warning sources_list')
            return

        # this site blocks higher rez, but I have a workaround
        for url_source in sources_list:
            video_url = self._ROOT_URL+url_source.group('url')
            if self._PLAY_HEADERS:
                #url will already have | symbol; we should append to existing
##                video_url = video_url + utils.Header2pipestring(self._PLAY_HEADERS)
                headers = self._PLAY_HEADERS 
            if not('|' in video_url): #always set referrer so that 'kodi' does not appear to the target server
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = url + '/'
##                video_url = video_url + utils.Header2pipestring(headers)
##            Log(video_url)
            response, redirected_url = utils.getHtml(
                url=video_url
                 , headers=headers
                 , send_back_redirect=True
                 , method="HEAD"
                )
##            LogR(response)
            LogR(redirected_url)
            from constants import quote_plus
##            import urllib.parse
##            redirected_url = quote_plus(redirected_url.lstrip('https://'))
##            LogR(redirected_url)
##            u2 = urllib.parse.urlparse(redirected_url)
            u2 = C.urlparse.urlparse(redirected_url)
            LogR(u2)
##            redirected_url = urllib.parse.urlunparse((
            redirected_url = C.urlunparse((
                u2.scheme
                ,u2.netloc
                ,u2.path
                ,u2.params
                ,quote_plus(u2.query)
                ,''
                ))
            
            redirected_url = redirected_url.replace(url_source.group('res')+'p.mp4', '<rez>')
            LogR(redirected_url)
##            headers['Referer'] = redirected_url
##            LogR(dir(resp))
            break
##        return

        for url_source in sources_list:
##            LogR(url_source)
##            alt_results.append(  (url_source.group('res'), self._ROOT_URL+url_source.group('url') )  )
            alt_results.append(
                (
                    url_source.group('res')
                    , redirected_url.replace('<rez>',url_source.group('res')+'p.mp4') + utils.Header2pipestring(headers)
                )
            )

            
        Log("alt_results={}".format(alt_results))
##        ret = list()
##        for a in alt_results:
##            ret.
##        LogR(ret)
        return alt_results
        raise Exception()
        
    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by site
    def Video_Source_URL_Normalize(self, url):
        url = "".join((self._ROOT_URL, url))
##        Log(url)
        return url
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags =        r'class="vit-pornstar.+?href="/pornstar/.+?>([^<]+)<\/a>'
    _REGEX_tags_region = r"(.+)"           #'class="categorieswrapper(.+?)<noscript>'
##    #__________________________________________________________________________
##    # add an alternative way to resolve listing
##    def List_URL_Normalize(self, url, page):
##
##        url = url + "limit=48&offset={}"
##        url = url.format(48*(int(page)-1))
##        LogR(locals())
##        return url
##    #__________________________________________________________________________
##    # add an alternative way to resolve a playable thumbnail
##    def Normalize_ThumbURL(self, thumb, duration, videourl):
##        from utils import RandomNumber as RandomNumber
##        thumb_url = "https://thumbs-015.externulls.com/"
##        try: #sometimes there is a 'set' of images; sometime not
##            int(thumb)
##            thumb_url = thumb_url + "sets/{}/thumbs/{}-{}.jpg?size=320x180"
##            thumb = "{:>05d}".format(int(thumb))
##            thumb = thumb_url.format(thumb, thumb, '{}')
##            frame = "{:>04d}".format( (int(duration)/10) + (int(RandomNumber(length=1))) )  #Site allows global frame grabs...10% into vid seems ok...but the official list is ordered in such a way to make regex capture too hard
##        except:
##            thumb = thumb_url + "videos/{}/{}.jpg?size=320x180".format(videourl, '{}')
##            frame = "{}".format( (int(duration)/10) + (int(RandomNumber(length=1))) )  #Site allows global frame grabs...10% into vid seems ok...but the official list is ordered in such a way to make regex capture too hard
##        thumb = thumb.format(frame)        
##        return thumb
##    #__________________________________________________________________________
##    # add update duration as necessary
##    def Normalize_Duration(self, duration):
####        Log(repr(duration))
##        if '"_completeness": "Full-To-Clip"' in duration or \
##           '"_completeness": "Full-4-Clip"' in duration :
##            regex = 'fc_created".+?"fc_end": (?P<end>\d+).+?"fc_start": (?P<start>\d+)'
##            info = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(duration)
##            for item in info:
####                Log(repr(item))
##                start = item.group('start')
##                end = item.group('end')
##                duration = int(end)-int(start)
##                #break
##        else:
##            regex = '"fl_duration": (?P<end>\d+)'
##            info = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(duration)
##            for item in info:
##                duration = int(item.group('end'))
##                break
####        Log(repr(duration))
####        duration = min(640,duration)
##        return duration
##    #__________________________________________________________________________
##    # add an alternative way to resolve a playable thumbnail
##    def Normalize_ThumbURL(self, thumb, duration, videourl):
####        Log(repr((thumb, duration, videourl)))
##        from utils import RandomNumber as RandomNumber
##        thumb_url = "https://thumbs.externulls.com/"
##        frame = "{}".format( (int(max(100,duration))//10) + (int(RandomNumber(length=1))) )  #Site allows global frame grabs...10% into vid seems ok...but the official list is ordered in such a way to make regex capture too hard
##        thumb = "{}videos/{}/{}.webp?size=480x270".format(thumb_url, thumb, frame)
##
####        thumb = thumb.format(frame)
####        Log(repr(thumb))
##        return thumb
##    #__________________________________________________________________________
##    # Change video url created by List as neeeded by website
##    def Normalize_VideoURL(self, videourl):
##        videourl = "https://store.externulls.com/facts/file/{}".format(videourl)
##        return videourl
##    #__________________________________________________________________________
##    # add an alternative way to resolve a playable video url
##    # returned items must be a list of (res, url) items
##    def _ALTERNATE_playsearch_01(self, *args, **kargs):
##        alt_results = list()
##        full_html = kargs["full_html"]
##        url = kargs["referer"]
##        return alt_results
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        #note: site actually uses websockets to generate a 'slug' value for some searches
        # but I don't want to worry for this low quality site
        keyword = keyword.replace('+',' ').replace(' ','-')
        return keyword
##    #__________________________________________________________________________
##    # Change SEARCH_URL to replace spaces with a char that website wants
##    def Search_URL_Normalize(self, search_url, keyword):
##        search_url = search_url.format(keyword)
##        return search_url
##    #__________________________________________________________________________
##    # Change LIST to enable max recurse depth
##    def List(self, url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
##        try:
##            org = C.MAX_RECURSE_DEPTH
##            if C.PY3:                       super().List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            if C.PY2: super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            C.MAX_RECURSE_DEPTH = org
##        except:
##            pass
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(
    url
    , name
    , download=None
    , playmode_string=None
    , play_profile=None
    , testmode=False
    , icon_URI=None
    ):
    #default to 720 because website hides other rez without hack
    if not playmode_string: playmode_string = "720" 
    return website.Playvid(
        url
        , name
        , download=download
        , playmode_string=playmode_string
        , play_profile=play_profile
        , testmode=testmode
        , icon_URI=icon_URI
        , skip_head = True
##        , mimetype = 'video/mp4'
        )
#__________________________________________________________________________
#
