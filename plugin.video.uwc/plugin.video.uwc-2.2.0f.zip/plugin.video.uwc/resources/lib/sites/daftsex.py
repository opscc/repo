'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#2025-04 more and more items cloudflare


#import base libraries
import base64
import json
import re
import time
import traceback
#import internal addon libraries
import utils
from base_website import Base_Website
import constants as C
#define frequenctly used aliases
from utils import Log,LogR


class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]daftsex[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True
    #_ROOT_URL        = "https://biqle.ru"
    #_ROOT_URL        = "https://daft.sex"
    _ROOT_URL        = "https://mat6tube.com"
    _URL_CATEGORIES  = None #_ROOT_URL + '/videos/category/798?page_id={}'
    _URL_RECENT      = _ROOT_URL #2021-09-23
    _URL_RECENT      = _ROOT_URL +'/video/sex?p={}' #2022-08-08 #due to old url takedown
    _URL_RECENT      = _ROOT_URL +'/popular/recent?p={}' #2025-04  #seems to work
    _SEARCH_URL      = _ROOT_URL + '/video/{}?p={}'

    _MAIN_MODE = C.MAIN_MODE_daftsex
    _FIRST_PAGE = 0
    _FIRST_SEARCH_PAGE = 0
    _Right_Click_Option = None # C.DEFAULT_PLAYMODE # None to allow all possibilities [e.g. present HLS or MP4 play options]

##    _SAVE_COOKIES = True       #if we need to save html cookies
##    _SAVE_COOKIES = False       #if we need to save html cookies
    _SAVE_COOKIES = (
        '_cfuvid',
        )
    
    _ITEMS_NOT_FOUND_INDICATORS = [
        'Nothing Found',
##        '>Sorry, this video has been deleted.</',
        ] #which to strings may indicate that there is nothing to be found

    _MIN_VALID_IMAGE_SIZE = 1500
    _BAD_IMAGE_SIZES = [576,1391]

##    #override categor from a basic url to custom function
##    def _URL_CATEGORIES(self):
##        cat_url = self._ROOT_URL + '/genres/uncensored/page/{}/' #2021-09-12
##        addDir(
##            name = '[COLOR {}]Uncensored[/COLOR]'.format(C.search_text_color)
##            ,url = cat_url
##            ,mode = self.LIST_MODE
##            ,page = self._FIRST_PAGE
##            ,iconimage=C.category_icon)
##        pass
##    def Categories(self, url, end_directory=True):
##        return True

    #__________________________________________________________________________
    # Change label created by List as neeeded by website
    def Normalize_ListLabel(self, label, hd):
##        LogR(label, C.LOGNONE)
        label = re.sub(r'(?i)[^a-z0-9 \&\;,\\\/\:\*\"\<\>\|]',' ',label)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        label = label.replace("\\\"", "'")
        while "  " in label:
            label = label.replace("  ", " ")
        return label

    
    #__________________________________________________________________________
    #videos on this page
    _REGEX_video_region = (
        '(?:div id="browse_section"|div class="videolist_results"|id="search_results_block")'
        '(.+?)'
        '(?:</videolisting>|id="w_pagination"|class="title_inactive")'
        )
    _REGEX_video_region = (
        '(?:div class="list_videos")'
        '(.+?)'
        '<div class="more"'
        )

    _REGEX_list_items = (
        #last daftsex to work before site went down 2023-08
        '<div class="video-item'  
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?data-thumb="(?P<thumb>[^"]+)"'
        '.+?<span class="video-time">(?P<duration>[^<]+)<'
        r'.+?"setTitle\(this\);">(?P<label>[^<]+)<'
        r'(?P<hd>(?:\[[^\]<]+(?:\]|<)|))'
        '(?P<desc>)'
        )

    _REGEX_list_items = (
        #lastest daftsex to work
        '<div class="item'  
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        '.+?(?P<hd>)'
        #(?:<i class="hd_mark">HD</i>|))'
        '.+?<div class="m_time">.+?</use></svg>(?P<duration>[^<]+)<'
        '(?P<desc>)'
        )
    
##    _IGNORE_404 = False

    #_LIST_METHOD = "POST"
    _LIST_HEADERS = {
        "User-Agent": C.USER_AGENT
        , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        , "Referer": _ROOT_URL
        , "X-Requested-With": "XMLHttpRequest"
        , "Accept-Encoding": "gzip"
        , "Accept-Language": "en-US,en;q=0.9"
    }
    def LIST_DATA(self, **kargs):
        page = kargs["page"]
        return "page={}".format(page)
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = '<nav class="pagination(.+?)</nav>'
    _REGEX_next_page_regex = '(>Show more<)' #as long as result is not empty

    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self.ROOT_URL + videourl
##        Log(videourl)
        return videourl
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):

        thumb2 = thumb.split('/i.mycdn.me/')
        if thumb2 and len(thumb2)>1:
            thumb = '//i.mycdn.me/'+thumb2[1]
        thumb2 = re.findall(r'(/[\w\-]+?\.userapi\.com/.+)', thumb)
        if thumb2 and len(thumb2)>0:
            thumb = '/'+thumb2[0]
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        thumb = thumb.replace('&amp;','&')
        headers = None #2022-12 thumbs need referrer
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
        if headers:
            thumb = thumb + utils.Header2pipestring(headers)

##        Log(thumb)
        return thumb
   
##    #__________________________________________________________________________
##    _REGEX_categories_region = 
##        (
##        'class="main_category_header"(.+)'
##        )
##    _REGEX_categories = (
##        '<span class="ic-check icr"><span>(?P<label>.+?)<'
##        '.+?<li data-id="(P<videourl>.+?)"'
##        '(?P<thumb>)'
##        )
##    def Category_URL_Normalize(self, url): # Change url found in via regex with structure neeeded by website
##        return self.ROOT_URL + url + '?page={}'

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        keyword = keyword.replace('+',' ').replace(' ','%20')
        return search_url.format(keyword, '{}')

##    #__________________________________________________________________________
##    #where playable urls live
    _REGEX_playsearch_01 = None #not for this site
##    (
##        ',?"?mediaDefinitions?"?:(?P<json>.+?\]),'  #video data as json
##        'data-hls-src(?P<res>\d+)'                #video data as res+url
##        '="(?P<url>[^"]+)"'
##        )
    #description for the playable url
    _REGEX_tags = None        #'<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    _REGEX_tags_region = None #'class="detail-video-block"(.+?)class="comments-wrapper"'

    #__________________________________________________________________________
    #
    _REGEX_icon_search = (
        '<link rel="preload" as="image" href="([^"]+)"',
        '<meta property="og:image" content="([^"]+)"',
        )
    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
        Log(u"Icon_Search url={}, pattern={}, referer={}".format(repr(url),repr(pattern),repr(referer))
            , C.LOGNONE
            )
        url = url.replace('daftsex.com', 'daft.sex')
        url = url.replace('daft.sex', 'mat6tube.com')

        thumb = None
        page_content = utils.getHtml(url, referer)
        for p in pattern:
            t = re.compile(p, re.DOTALL | re.IGNORECASE).findall(page_content)
            if t: thumb = self.Normalize_ThumbURL( t[0] )
            else: continue
            thumb = C.unescape(thumb)
            try:
                test_load = utils.getHtml(thumb)
                if len(test_load) < self._MIN_VALID_IMAGE_SIZE:
                    thumb = None
                    Log('image too small to be real')
                if len(test_load) in self._BAD_IMAGE_SIZES:
                    thumb = None
                    Log('known bad image size')

                #good thumb...will save it
                break
            except Exception as ex:
                LogR(ex)



        if not thumb:
            Log('vk thumb',C.LOGINFO,)
            try:
                vk_access_token = self.Get_vk_access_token(url)
                vk_api_images = self.Get_vk_api_json(url)['response']['items'][0]['image']
                for items in vk_api_images:
                    thumb = items['url']
            except Exception as ex:
                LogR(traceback.format_exc(),C.LOGWARNING)
            finally:
                if thumb:
                    try:
                        test_load = utils.getHtml(thumb)
                    except Exception as ex:
                        test_load = 0
                        LogR(traceback.format_exc(),C.LOGWARNING)
                    if len(test_load) < self._MIN_VALID_IMAGE_SIZE:
                        Log('image too small to be real',C.LOGINFO,)
                        thumb = None
                    if len(test_load) in self._BAD_IMAGE_SIZES:
                        thumb = None
                        Log('known bad image size',C.LOGINFO,)            

##                raise Exception('image too small to be real')

        if not thumb:
##            traceback.print_exc()

            try: #try the vk url
                _REGEX_icon_search = (
                    ',"jpg":"([^"]+)"'
                    )
##                vk_url = "https://m.vk.com/video"+url.replace("https://mat6tube.com/watch/","") #vk_url pre 2026-08-24
                vk_url = "https://m.vkvideo.ru/video"+url.replace("https://mat6tube.com/watch/","") #vk_url that 2026-08-24
                LogR(vk_url)
                headers = C.DEFAULT_HEADERS.copy()
##                headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
                headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0"
                headers['Referer'] = self._ROOT_URL
##                headers['Cookie'] = 'remixmdevice=1746/982/1.100000023841858/!!-!!!!!!!!' #kookie that 2026-08-24
                headers['Cookie'] = 'remixstlid=9116234238301878539_iBA2mmEIw6HkqmccuUeL8dZhlEIoTkWGjbfQts4f4x0; remixff=10111111111101; remixua=45%7C-1%7C333%7C3588003755; remixmdevice=1408/792/1.3636363636363635/!!-!!!!!!!!/1408; _ignoreAutoLogin=1; remixstid=292174542_Ohf7mMspu9jTZofrZDu81vSmlJWezhpdPqwGCvwjuSk; remixdark_color_scheme=1; remixcolor_scheme_mode=auto; remixgp=5466691db018ed6f3c5a8e87b810ede9; remixdt=-25200; remixmvk-fp=4b50eac873c93ac31884ca08bb779d2a'
##                LogR(vk_url)
                vk_html = utils.getHtml(vk_url, headers=headers)
                for p in pattern:
                    thumb = re.compile(p, re.DOTALL | re.IGNORECASE).findall(vk_html)
                    if thumb: thumb[0] = self.Normalize_ThumbURL( thumb[0] )
                    else: continue
                    LogR(thumb)
                    try:
                        test_load = utils.getHtml(thumb)
                        if len(test_load) < self._MIN_VALID_IMAGE_SIZE:
                            thumb = None
                            Log('image too small to be real')
                        if len(test_load) in self._BAD_IMAGE_SIZES:
                            thumb = None
                            Log('known bad image size')
                        #good thumb...will save it
                        break
                    except Exception as ex:
                        LogR(ex)
                LogR(thumb)
            except Exception as ex:
                LogR(ex)
##                traceback.print_exc()
                thumb = None

        if not thumb:
            Log('not thumb')
            try:
                regex = (
                    r',"image":(\[.+?\])'
                         )
                image_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(vk_html)
                if image_region: image_region = image_region[0]
                else: image_region = ''
##                    LogR(image_region)

                image_list = json.loads(image_region)
##                    LogR(image_list)
                def my(n):
                    return n['width']
                thumb = sorted(image_list, key=my, reverse=True)[0]['url']
                thumb = self.Normalize_ThumbURL(thumb)
##                thumb = thumb.replace('&amp;','&')
                test_load = utils.getHtml(thumb)
                if len(test_load) < self._MIN_VALID_IMAGE_SIZE:
                    thumb = None
                    raise Exception('image too small to be real')                    
            except Exception as ex:
                LogR(traceback.format_exc(),C.LOGWARNING)
                LogR(url)


                

        if not thumb:

            Log('try this hardcode',C.LOGWARNING)
            regex = (
                r'(/-?\d+(?:_|/)\d+)'
                     )
            vid_num = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(url)
            LogR(vid_num)
            vid_num = vid_num[0].replace("_", "/")
            thumb = "https://cdn2.pvvstream.pro/videos/{}/preview_320.jpg".format(vid_num)
            thumb = self.Normalize_ThumbURL(thumb)
                    
                    
        LogR(thumb, C.LOGNONE)
        thumb = self.Normalize_ThumbURL(thumb)
        
        LogR(thumb, C.LOGNONE)
##        exit(0)    
        return thumb

    #__________________________________________________________________________
    # Change LIST to enable max recurse depth
    def List(
        self
        , url
        , page_start=None
        , page_end=None
        , end_directory=True
        , keyword=''
        , testmode=False
        , progress_dialog=None
        , bulk_operation=False
        ):

        LogR(locals())
        org = C.MAX_RECURSE_DEPTH
        C.MAX_RECURSE_DEPTH = 10
        #py3
##        class Foo(Bar):
##    def baz(self, **kwargs):
##        return super().baz(**kwargs
        #python 2
        url = url + '&_=' + str(int(time.time()))
        super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
        C.MAX_RECURSE_DEPTH = org

    #__________________________________________________________________________
    # Get_vk_client_id
    def Get_vk_client_id(self):
        cache_id = 'vk_access_token'
        return utils.global_cache.get(
            endpoint = cache_id+'_'+'client_id',
            )
    #__________________________________________________________________________
    # Get_vk_api_version
    def Get_vk_api_version(self):
        cache_id = 'vk_access_token'
        return utils.global_cache.get(
            endpoint = cache_id+'_'+'api_version',
            )


    #__________________________________________________________________________
    # get_vk_access_token
    def Get_vk_access_token(
        self,
        url,
        ):

        app_id = api_version = client_secret = None
        
        #check if we already have an 'access_token'
        cache_id = 'vk_access_token'
        vk_access_token = utils.global_cache.get(cache_id)
        if vk_access_token:
            Log('access token found in global cache warning',C.LOGINFO)
            return vk_access_token

        client_id = app_id = utils.global_cache.get(
            endpoint = cache_id+'_'+'client_id',
            )
        api_version = utils.global_cache.get(
            endpoint = cache_id+'_'+'api_version',
            )
        LogR((app_id,api_version,client_secret),C.LOGWARNING,)

        #
        #get vk access token
        #

        
        vk_url = "https://m.vkvideo.ru/video"+url.replace("https://mat6tube.com/watch/","") #vk_url that 2026-08-24
        headers = C.DEFAULT_HEADERS.copy()
        headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0"
##                headers['Referer'] = 'https://m.vkvideo.ru/'
        headers['Accept'] = '*/*'
        headers['Cookie'] = 'remixua=45%7C-1%7C333%7C3588003755; remixmdevice=1408/792/1.3636363636363635/!!-!!!!!!!!/703'




        try:
            #try to get api value via this
            vk_html, vk_redir = utils.getHtml(
                vk_url,
                headers=headers,
                send_back_response=True,
                send_back_redirect=True,
                allow_redirects=False,
                cache_duration=-1, #ignore cached value
                )
            LogR(vk_html.getheaders()['Location'],C.LOGINFO,)
            x = C.urlparse.urlparse(vk_html.getheaders()['Location'])
            LogR(x,C.LOGINFO,)
            app_id = C.urldecode(
                x.query
                )['app_id'][0]
            client_id = app_id

    ##        LogR(api_version,C.LOGINFO,)
    ##        raise Exception()
            utils.global_cache.set(
                endpoint = cache_id+'_'+'client_id',
                data = client_id,
    ##            expiration=login_json['data']['expires'],
                expiration = utils.datetime.timedelta(hours=12),
                )

        except:
            LogR(traceback.format_exc(),C.LOGWARNING)
        LogR((app_id,api_version,client_secret),C.LOGWARNING,)

        #https://vkvideo.ru/video-212396640_456240103
        #client_id also available herer
        
        #read all the source files and look for secret    
        vk_html= utils.getHtml(
            vk_url,
            headers=headers,
            )
        regex = r'<link rel="preload"(.+)<link rel="stylesheet"'
        script_region = re.compile(
            regex,
            re.DOTALL | re.IGNORECASE,
            ).findall(vk_html)[0]
##                LogR(script_region,C.LOGNONE)
##                return
        #read all the source files and look for secret
        regex = r'<script src="(.+?)"'
        script_sources = re.compile(
            regex,
            re.DOTALL | re.IGNORECASE,
            ).findall(script_region)


##                LogR(script_sources,C.LOGNONE)
        for vk_script_url in script_sources:
            Log(vk_script_url,C.LOGNONE,)
##                    return
##                    continue
            try:
                script_src = utils.getHtml(
                    vk_script_url,
                    headers=headers,
                    )
            except Exception as ex:
                LogR(traceback.format_exc(),C.LOGWARNING)
                script_src = ""
               
            if not api_version:
                #api_version = '5.285'
                regex_api_version = r'API_VERSION:function\(\){return \w}}\);(?:const|let) \w="(.+?)"},\d+'
                api_version = re.compile(
                    regex_api_version,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(script_src)
                if api_version: api_version = api_version[0]
                LogR((app_id,api_version,client_secret),C.LOGWARNING,)
                utils.global_cache.set(
                    endpoint = cache_id+'_'+'api_version',
                    data = api_version,
                    expiration = utils.datetime.timedelta(hours=12),
                    )
        
            if not app_id:
                #app_id = '52649896'
                regex_app_id = r'VK_WEB_VKVIDEO_APP_ID:function\(\).+?g=(\d+)'                
                app_id = re.compile(
                    regex_app_id,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(script_src)
                if app_id: app_id = app_id[0]
                client_id = app_id
                LogR((app_id,api_version,client_secret),C.LOGNONE,)
                utils.global_cache.set(
                    endpoint = cache_id+'_'+'client_id',
                    data = client_id,
                    expiration = utils.datetime.timedelta(hours=12),
                    )
        

            #client_secret="WStp4ihWG4l3nmXZgIbC"
            if not client_secret:
                regex_client_secret = r'VK_WEB_VKVIDEO_APP_ID:function\(\).+?c="(.+?)"'
                regex_client_secret = r'\.isMvkVKVideo\)\(\)\&\&.+?\w="(.+?)"\),'
                client_secret = re.compile(
                    regex_client_secret,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(script_src)
                if client_secret: client_secret = client_secret[0]
##                    LogR((app_id,api_version,client_secret),C.LOGNONE,)
            if app_id and api_version and client_secret:
                Log('all info found', C.LOGINFO,)
                break



        if not(app_id and api_version and client_secret):
            raise Exception('login info not found')

        """
POST https://login.vk.ru/?act=get_anonym_token HTTP/1.1
Host: login.vk.ru
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0
Accept: */*
Accept-Language: en-US,en;q=0.9
Accept-Encoding: gzip, deflate, br
Referer: https://m.vkvideo.ru/
Content-Type: application/x-www-form-urlencoded
Content-Length: 193
Origin: https://m.vkvideo.ru
Sec-Fetch-Storage-Access: none
DNT: 1
Sec-GPC: 1
Connection: keep-alive
Cookie: remixstid=786646658_QZWFQnDzDUMOrBxSpLLrimH3Uc38TFLAnYsZqjgWOfo; remixstlid=9100471639648367984_olM38GFS2YIU6911h7hisgp8r7hTKsye5VTuuQhoop8
Sec-Fetch-Dest: empty
Sec-Fetch-Mode: cors
Sec-Fetch-Site: cross-site
Priority: u=4
        """
        
        headers['Accept-Language'] = 'en-US,en;q=0.9'
        headers['Accept-Encoding'] = 'gzip, deflate, br'
        headers['Referer'] = 'https://m.vkvideo.ru/'
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        headers['Origin'] = 'https://m.vkvideo.ru'
        headers['Sec-Fetch-Storage-Access'] = 'none'
        headers['DNT'] = 1
        headers['Sec-GPC'] = 1
        headers['Connection'] = 'keep-alive'
        headers['Sec-Fetch-Dest'] = 'empty'
        headers['Sec-Fetch-Mode'] = 'cors'
        headers['Sec-Fetch-Site'] = 'cross-site'
        headers['Priority'] = 'u=4'


        post_data = {
            "client_secret":  client_secret ,
            "client_id":client_id,
            "scopes":"audio_anonymous,video_anonymous,photos_anonymous,profile_anonymous",
            "isApiOauthAnonymEnabled":'false',
            "version":api_version,
            "app_id":app_id
            }
##                LogR(C.urlencode(post_data),C.LOGNONE,)
##                return
        login_html = utils.getHtml(
            'https://login.vk.ru/?act=get_anonym_token',
            headers=headers,
            method="POST",
            sent_data=C.urlencode(post_data),
            )
        login_json = json.loads(login_html)
##                LogR(C.urlencode(post_data),C.LOGNONE,)
        vk_access_token = login_json['data']['access_token']
        LogR(vk_access_token,C.LOGNONE,)

        utils.global_cache.set(
            endpoint = cache_id,
            data = vk_access_token,
##            expiration=login_json['data']['expires'],
            expiration = utils.datetime.timedelta(hours=12),
            )



        Log('access token found warning',C.LOGINFO)
        return vk_access_token


    #__________________________________________________________________________
    def Get_vk_api_json(self,url):

        headers = {
            'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',
            'Accept' : '*/*',
            'Accept-Language' : 'en-US,en;q=0.9',
            'Accept-Encoding' : 'gzip, deflate, br',
            'Referer' : 'https://m.vkvideo.ru/',
            'Content-Type' : 'application/x-www-form-urlencoded',
            'Origin' : 'https://m.vkvideo.ru',
            'Sec-Fetch-Storage-Access' : 'none',
            'DNT' : '1',
            'Sec-GPC' : '1',
            'Connection' : 'keep-alive',
            'Sec-Fetch-Dest' : 'empty',
            'Sec-Fetch-Mode' : 'cors',
            'Sec-Fetch-Site' : 'cross-site',
            'Priority' : 'u=4',
            }

        vk_api_url = 'https://api.vk.ru/method/video.getByIds?v=5.285&client_id=52649896'
        vk_api_url = 'https://api.vk.ru/method/video.getByIds?v={}&client_id={}'.format(
            self.Get_vk_api_version(),
            self.Get_vk_client_id(),
            )
        post_data = {
            "videos":  url.replace("https://mat6tube.com/watch/","") ,
            "video_fields":"added,episodes,files,image,is_favorite,subtitles,timeline_thumbs,trailer,volume_multiplier",
            "access_token": self.Get_vk_access_token(url),
            }
##                LogR(C.urlencode(post_data),C.LOGNONE,)
##                LogR(vk_api_url,C.LOGNONE,)
##                return
        vk_api_html = utils.getHtml(
            vk_api_url,
            headers=headers,
            method="POST",
            sent_data=C.urlencode(post_data),
            )
        vk_api_json = json.loads(vk_api_html)
        return vk_api_json

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url; returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        Log("_ALTERNATE_playsearch_01(args='{}',kargs='{}'".format(repr(args)[0:250], repr(kargs)[0:250]))

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]



        video_url = None
        server = None

        class FinishException(Exception):
            def __init__(self, value):
                self.value = value
                LogR(value, loglevel=C.LOGWARNING, stacklevel=3)
            def __str__(self):
                return repr(self.value)


        len_alt_results = 0
        try:
            try:
                #2026-08 vk version
                vk_access_token = self.Get_vk_access_token(url)
                vk_api_files = self.Get_vk_api_json(url)['response']['items'][0]['files']
                for  item in vk_api_files:
                    if 'mp4_' in item:
                        alt_results.append((
                            item.replace('mp4_',''),
                            vk_api_files[item],
                            ))
                    if item == 'hls':
                        alt_results.append((
                            '1080', 
                            vk_api_files[item],
                            ))
                return alt_results
            except FinishException as ex:
##                LogR(traceback.format_stack(), C.LOGWARNING)
                pass
            except Exception as ex:
                LogR(traceback.format_stack(), C.LOGWARNING)
            finally:
                if len(alt_results) > len_alt_results:
                    LogR(alt_results)
                    Log('found VK result')
                    len_alt_results = len(alt_results)
                else:
                    Log('NO found VK result')

            try:
                regex = (
                    r'<div id="player_box">(.+?)window.ads'
                         )
                url2 = re.compile(
                    regex,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(full_html)
                if not url2: raise FinishException("second url not found via regex:{}".format(regex))

                regex = (
                    r"<script>\s*window.playlistUrl\s*=\s*'(.+?)'"
                         )
                url3 = re.compile(
                    regex,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(url2[0])
                if url3: url3=self._ROOT_URL + url3[0]
                else: raise FinishException

                json_html = utils.getHtml(
                    url3,
                    self._ROOT_URL,
                    )
                try:                    
                    json_sources = json.loads(json_html)
                except:
                    if json_html:
                        Log(repr(json_html)[0:300])

                    json_sources = 'error'

                if "error" in json_sources:
                    raise StopIteration

                vid_list = list()
                key_list = list()
                if "sources" in json_sources:
                    for json_item in json_sources["sources"]:
                        Log("json_item={}".format(repr(json_item)))
                        res = json_item['label']
                        video_url = json_item['file']
##                        if not 'cdn2.pvvstream.pro' in video_url:
##                            alt_results.append( (res, video_url) )
                                
            except FinishException as e:
##                LogR(e)
                pass
            except:
                pass
            finally:
                if len(alt_results) > len_alt_results:
                    Log('found "player_box2" result')
                    len_alt_results += 1


            try: #2025-04  avoid cloudflare by reading html from download page
                regex = (
                    'window.downloadUrl="(.+?)"'
                         )
                download_url = re.compile(
                    regex,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(full_html)
                if not download_url:
                    raise FinishException("not found via regex:" + regex)
                else: download_url = download_url[0]

                full_html = utils.getHtml(
                    self._ROOT_URL + download_url,
                    self._ROOT_URL,
                    save_cookie=self._SAVE_COOKIES,
                    )

                Log('download page successfully read')
            except FinishException as e:
##                LogR(e)
                pass

            try : #try this way
                regex = (
##                    "<script>\s*window.playlist = (.+?)(?:\}\;|,\"trusted\")"
                    r"<script>\s*window.playlist = (.+?\});"
                         )
                json_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
                if json_html: json_html=json_html[0]

                try:                    
                    json_sources = json.loads(json_html)
                except Exception as ex:
                    LogR(traceback.format_stack(), C.LOGWARNING)
##                    if full_html: Log(repr(full_html)[0:-1000])
##                    if json_html: Log(repr(json_html)[0:500])
##                    if json_html: Log(repr(json_html))
                    json_sources = 'error'

                if "error" in json_sources:
                    Log(repr(json_sources))
                    raise FinishException('"error" in json_sources')

                vid_list = list()
                key_list = list()
                headers = C.DEFAULT_HEADERS.copy()
                headers['Accept'] = 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5'
                headers['Referer'] = kargs["referer"]
                if "sources" in json_sources:
                    for json_item in json_sources["sources"]:
##                        Log("json_item={}".format(repr(json_item)))
                        res = json_item['label']
                        video_url = C.unquote_plus(json_item['file'])
                        video_url = video_url #+ '&dl=1'


                        if 'cdn2.pvvstream.pro'in video_url:
                            utils.Notify("A cdn2.pvvstream.pro source detected.  May not work") # due to cloudflare
                            try:
                                #make it less likely to be chosen
                                res = str(int(res) - 1)
                            except:
                                pass

                        if '|' not in video_url:
                            video_url += utils.Header2pipestring(headers)
                            
                        alt_results.append( (res, video_url) )


                            
            except FinishException as e:
##                LogR(e)
                pass
            finally:
                if len(alt_results) > len_alt_results:
                    LogR(alt_results)
                    Log('found "player_box3" result')
                    len_alt_results = len(alt_results)
            
            try :  #get the max 720p version ##2021-04 second file now has data

                regex = 'window.globEmbedUrl = \'([^\']+)\'.+?hash: "([^"]+)".+?color: "([^"]+)"'   ##2021-04 second file now has data
                url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
                if url2:
                    url2 = "{}{}?color={}".format(url2[0][0], url2[0][1], url2[0][2])
                    Log(repr(url2))
                    full_html = utils.getHtml(url2, self._ROOT_URL)
                else:
                    pass
                vid_id = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)    
                token = re.compile('access_token: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
                videos = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
                extra_key = re.compile('extra_key: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
                sig = re.compile(r'\s(?:sig|credentials):\s*"([^"]+?)",', re.DOTALL | re.IGNORECASE).findall(full_html)
                ckey = re.compile('c_key: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
                thumb = re.compile('thumb: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
                cdn_files = re.compile('cdn_files: {([^}]+)}', re.DOTALL | re.IGNORECASE).findall(full_html)
                server = re.compile('server: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
                partial = re.compile('partial: {"quality":({"[^}]+})', re.DOTALL | re.IGNORECASE).findall(full_html)
                #different versions of web page may not have same data
                try:    token = token[0]
                except: token = None
                try:    videos = videos[0]
                except: videos = None
                try:    ckey = ckey[0]
                except: ckey = None
                try: extra_key = extra_key[0]
                except: extra_key = None
                try:    cdn_files = cdn_files[0]
                except: cdn_files = None
                try:    thumb = base64.b64decode(thumb[0]).strip("thumb.jpg")
                except: thumb = None
                try:    server = base64.b64decode(server[0][::-1]) #reverse string then decode it
                except: server = None
                try:    sig = sig[0]
                except: sig = None
                try:    vid_id = vid_id[0]
                except: vid_id = None
                try: partial = json.loads(partial[0])
                except: partial = None
                if cdn_files: #newer style
                    Log('#newer style')
                    regex = r'"mp4_(\d+)":"([^"]+)'
                    vid_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cdn_files)
                    for res, vid in vid_list:
                        baseurl = "https://{}/videos/{}/".format(server, videos.replace("_","/"))
                        video_url = "{}{}".format(baseurl, vid.replace(".",".mp4?extra=") )
                        alt_results.append( (res, video_url) )
                    Log(repr(alt_results), C.LOGNONE)

                elif server: #older styple
                    base_str = "https://{}/method/video.get/{}?token={}&videos={}&ckey={}&credentials={}"
                    intermediate_url = base_str.format(server,vid_id,token,videos,ckey,sig)
                    http_referrer = "https://daxab.com/"

                    headers = C.DEFAULT_HEADERS.copy()
                    headers['Referer'] = self._ROOT_URL
                    headers['User-Agent'] = "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0)"
                    
                    json_html = utils.getHtml(intermediate_url, http_referrer)
                    try:                    
                        json_sources = json.loads(json_html)
                    except:
                        if json_html:
                            Log(repr(json_html)[0:300])
                            pass
                        json_sources = 'error'

                    if "error" in json_sources:
                        Log(repr(json_sources))
                        raise StopIteration

                    vid_list = list()
                    key_list = list()
                    if "response" in json_sources:
                        for json_item in json_sources["response"]["items"]:
                            for vid_src in json_item["files"]:
                                Log("vid_src={}".format(repr(vid_src)))
                                res = vid_src.split('=')[0].replace('mp4_','')
                                v_url = json_item["files"][vid_src]
                                Log("res={}".format(repr(res)))
                                vid_list.append( (res, v_url) )
                    Log("vid_list={}".format(repr(vid_list)))

                    
                    for q,u in vid_list: #this site needs quality info
                        video_proxy_res = None    
                        Log("q={}".format(q))
                        Log("u={}".format(u))
                        Log(repr(partial))
                        video_url = u
                        #if video_url == u:
                        if q in partial:
                            video_proxy_res = q
                            extra_key_hidden = partial[q]
                            if video_proxy_res:
                                video_url = video_url.replace("https://", "https://"+server+"/") #needs this remote proxy
                                video_url = video_url + "&videos={}&extra_key={}&videos={}".format(vid_id, extra_key_hidden, vid_id)
                                video_url += utils.Header2pipestring(headers)
                            
                            
                        else:
                            continue #if no extra_key, then res not available
                        LogR(alt_results)
                        alt_results.append( (q, video_url) )
            except StopIteration:
                pass
            finally:
                if len(alt_results) > len_alt_results:
##                    LogR(alt_results)                    
                    Log('found "access_token" result')
                    len_alt_results = len(alt_results)
                    
        except:
            traceback.print_exc()
            utils.Notify("Unknown error for url {}".format(url))
        finally:
            LogR(alt_results)
                
##        raise Exception()
        return alt_results

#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.REBUILD_ICON, ['url'])
def Rebuild_Icon(url):
    website.Rebuild_Icon(url)
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.PLAY_MODE
    , ['url', 'name']
    , ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode']
    )
def Playvid(
    url
    , name
    , download=None
    , playmode_string=None
    , play_profile=None
    , testmode=False
    , icon_URI=None
    ):

##    import io
##    string_file = io.StringIO(u"")
##    traceback.print_stack(file=string_file)
##    LogR(string_file, C.LOGNONE)

##    LogR(traceback.extract_stack(), C.LOGWARNING)
##    LogR(locals(), C.LOGNONE)
    
    url = url.replace('daftsex.com', 'daft.sex')
    url = url.replace('daft.sex', 'mat6tube.com' )
    u =  website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
    LogR(u)
    return u
#__________________________________________________________________________
#
