#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

Workaround: find proper UI description file (DialogButtonMenu.xml)
and tweak exit button type from internal Kodi's Quit() function
call to sending signal from outside system to Kodi. Here
is one-liner that makes modifications to any skin from the default Kodi
package:

# find /usr/share/kodi/addons/skin.* -name DialogButtonMenu.xml-exec sed -i 's%<onclick>Quit()</onclick>%<onclick>System.Exec ("killall --signal SIGHUP kodi.bin")</onclick>%' {} 


'''

import json
import re
import os
import os.path
import sys
import threading
import traceback
import xbmc
import xbmcgui
import xbmcplugin

import downloader
import fav_dbconn
import fav_schema
import favorites
import replication
import fav_tests

import utils
from utils import Log,LogR

import constants as C
import configure 
import search 
import tests 

from constants import Queue
from constants import quote_plus

import xml.etree.ElementTree as ET
import ctypes
import platform

if int(sys.argv[1]) > 0: 
    xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available


def Get_Youtube_Url(videoId):
    import json

    def _generate_cpn(_alphabet=('abcdefghijklmnopqrstuvwxyz'
                                 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                                 '0123456789-_')):
        # https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/youtube.py#L1381
        # LICENSE: The Unlicense
        # cpn generation algorithm is reverse engineered from base.js.
        # In fact it works even with dummy cpn.
        import random
        return ''.join([random.choice(_alphabet) for _ in range(16)])
    
##    _PLAYER_PARAMS = {
##        'default': '8AEB',
##        'testsuite': '2AMB',
##    }
##    BASE_URL_MOBILE = 'https://m.youtube.com'
##    c = {'android': {
##            '_disabled': True,
##            '_id': {
##                'client_id': 3,
##                'client_name': 'ANDROID',
##                'client_version': '20.10.38',
##                'android_sdk_version': '32',
##                'os_name': 'Android',
##                'os_version': '15',
##                'package_id': 'com.google.android.youtube',
##                'platform': 'MOBILE',
##            },
##            '_auth_type': False,
##            '_use_subtitles': 'optional',
##            'json': {
##                'context': {
##                    'client': {
##                        'clientName': '{_id[client_name]}',
##                        'clientVersion': '{_id[client_version]}',
##                        'androidSdkVersion': '{_id[android_sdk_version]}',
##                        'osName': '{_id[os_name]}',
##                        'osVersion': '{_id[os_version]}',
##                        'platform': '{_id[platform]}',
##                    },
##                },
##                'cpn': None,
##                'params': _PLAYER_PARAMS['default'],
##            },
##            'headers': {
##                'Origin': BASE_URL_MOBILE,
##                'User-Agent': (
##                    '{_id[package_id]}/{_id[client_version]}'
##                    ' (Linux; U;'
##                    ' {_id[os_name]} {_id[os_version]}'
##                    ') gzip'
##                ),
##                'X-YouTube-Client-Name': '{_id[client_id]}',
##                'X-YouTube-Client-Version': '{_id[client_version]}',
##            }
##        }
##    }
##
##    Log(json.dumps(c['android']))
##    Log(json.dumps(c['android']['headers']).format(c['android']['_id']))
##    return 

    #first post to get a visitor ID
    V1_API_URL = 'https://www.youtube.com/youtubei/v1/player?prettyPrint=False'
    first_post_headers = {
        'User-Agent':'Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version'
        ,'Accept-Encoding':'gzip, deflate'
        ,'Accept':'*/*'
        ,'Connection':'keep-alive'
        ,'Accept-Charset':'ISO-8859-1,utf-8;q=0.7,*;q=0.7'
        ,'X-YouTube-Client-Name':'65'
        ,'Accept-Language':'en-US,en;q=0.5'
        ,'X-YouTube-Client-Version':'6.36'
        ,'Content-Type':'application/json'
    }
    first_post_data = {
        "user": {
            "lockedSafetyMode": False
            }
        , "context": {
            "client": {
                "utcOffsetMinutes": 0
                , "gl": "US"
                , "clientVersion": "6.36"
                , "clientName": "TVHTML5_UNPLUGGED"
                , "hl": "en_US"
                }
            , "request": {
                "internalExperimentFlags": []
                , "useSsl": True
                }
            }
        , "racyCheckOk": True
        , "contentCheckOk": True
        , "videoId": videoId
        , "thirdParty": {}
    }
##    Log(json.dumps(first_post_data))

    post_url = V1_API_URL
    if C.DEBUG: post_url += "&_=1_"+videoId
    r = utils.postHtml(
        post_url = post_url
        , headers = first_post_headers
        , sent_data = json.dumps(first_post_data)
        , NoCookie = False
        )
##    LogR(r)
    post_response_json = json.loads(r)
    visitor_data = post_response_json['responseContext']['visitorData']
##    Log(visitor_data)

    #send again with visitordata
    second_post_headers = first_post_headers.copy()
    second_post_headers['User-Agent'] = (
                'Mozilla/5.0'
                ' (ChromiumStylePlatform)'
                ' Cobalt/Version'
            )
    second_post_headers['X-YouTube-Client-Name']='7'
    second_post_headers['X-YouTube-Client-Version']='7.20250923.13.00'
    second_post_headers['X-Goog-Visitor-Id'] = visitor_data

    second_post_data = first_post_data.copy()
    second_post_data["context"]["client"]['visitorData'] = visitor_data
    second_post_data["context"]["client"]['clientName'] = 'TVHTML5'
    second_post_data["context"]["client"]['clientVersion'] = '7.20250923.13.00'
    second_post_data["context"]["client"]['device_make'] = 'Samsung'
    second_post_data["context"]["client"]['device_model'] = 'SmartTV'
    second_post_data["context"]["client"]['osName'] = 'Tizen'
    second_post_data["context"]["client"]['osVersion'] = '4.0.0.2'
    second_post_data["context"]["client"]['platform'] = 'TV'
    second_post_data["context"]["client"]['utcOffsetMinutes'] = 0
##    Log(json.dumps(second_post_data))

    post_url = V1_API_URL
    if C.DEBUG: post_url += "&_=2_"+videoId
    r = utils.postHtml(
        post_url = post_url
        , headers = second_post_headers
        , sent_data = json.dumps(second_post_data)
        )
##    LogR(r)
    post_response_json = json.loads(r)

    if 'streamingData' in post_response_json:
        Log('a')
        if "hlsManifestUrl" in post_response_json['streamingData']:
            Log('b')
            u = post_response_json['streamingData']['hlsManifestUrl']
            return u
        

    #try again with different client
    second_post_headers['Origin'] = 'https://m.youtube.com'
    second_post_headers['User-Agent'] = (
                'com.google.android.youtube'
                '/'
                '20.10.38'
                ' (Linux; U;'
                    'Android'
                    ' '
                    '15'
                ') gzip'
            )
    second_post_headers['X-YouTube-Client-Name']=3
    second_post_headers['X-YouTube-Client-Version']= '20.10.38'
    second_post_headers['X-Goog-Visitor-Id'] = visitor_data
    second_post_data = first_post_data.copy()
    second_post_data["context"]["client"]['visitorData'] = visitor_data
    second_post_data["context"]["client"]['clientName'] = 'ANDROID'
    second_post_data["context"]["client"]['clientVersion'] = '20.10.38'
    second_post_data["context"]["client"]['androidSdkVersion'] = '32'
    second_post_data["context"]["client"]['osName'] = 'Android'
    second_post_data["context"]["client"]['osVersion'] = '15'
    second_post_data["context"]["client"]['platform'] = 'MOBILE'
    second_post_data["context"]["client"]['utcOffsetMinutes'] = 0
    post_url = V1_API_URL
    if C.DEBUG: post_url += "&_=3_"+videoId
    r = utils.postHtml(
        post_url = post_url
        , headers = second_post_headers
        , sent_data = json.dumps(second_post_data)
        )
##    post_response_json = json.loads(r)
    if 'streamingData' in post_response_json:
        Log('a')
        if "hlsManifestUrl" in post_response_json['streamingData']:
            Log('b')
            u = post_response_json['streamingData']['hlsManifestUrl']
            return u



    #try again with different client
    second_post_headers['User-Agent'] = 'com.google.ios.youtube/20.20.7 (iPhone16,2; U; CPU iOS 18_5_0 like Mac OS X)'
    second_post_headers['Origin'] = 'https://m.youtube.com'
    second_post_headers['X-YouTube-Client-Name']=5
    second_post_headers['X-YouTube-Client-Version']= '20.20.7'
    second_post_headers['X-Goog-Visitor-Id'] = visitor_data
    second_post_data = first_post_data.copy()

    second_post_data["context"]["client"]['device_model'] = "iPhone16,2"
    second_post_data["context"]["client"]['utcOffsetMinutes'] = 0
    second_post_data["context"]["client"]['platform'] = 'MOBILE'
    second_post_data["context"]["client"]['clientName'] = "IOS"
    second_post_data["context"]["client"]['osName'] = 'iOS'
    second_post_data["context"]["client"]['deviceMake'] = 'Apple'
    second_post_data["context"]["client"]['clientVersion'] = '20.20.7'
    second_post_data["context"]["client"]['osVersion'] = '18.5.0.22F76'
    second_post_data["context"]["client"]['visitorData'] = visitor_data
    second_post_data["context"]["params"] = "2AMB"
    second_post_data["context"]["cpn"] = _generate_cpn()



    post_url = V1_API_URL
    if C.DEBUG: post_url += "&_=3_"+videoId
    r = utils.postHtml(
        post_url = post_url
        , headers = second_post_headers
        , sent_data = json.dumps(second_post_data)
        )
    post_response_json = json.loads(r)
    if 'streamingData' in post_response_json:
        Log('a')
        if "hlsManifestUrl" in post_response_json['streamingData']:
            Log('b')
            u = post_response_json['streamingData']['hlsManifestUrl']
            return u
        
    pass

##    import json
##    request = {
##        "jsonrpc" :"2.0"
##        , "method" : "Settings.SetSettingValue"
##        , "params" : {
##            "setting" : "network.usehttpproxy"
##            ,"value": True
##        }
##        , "id" : 1
##        }
##    val = xbmc.executeJSONRPC(json.dumps(request))
####    LogR(json.loads(val))
##
##
##    request = [{
##        "jsonrpc" :"2.0"
##        , "method" : "Files.GetFileDetails"
##        , "params" : {
##            #"file" : "plugin://plugin.video.uwc/?url=https%3A%2F%2Fwww.xvideos.com%2Fvideo.udcbtld8d14%2Fsummer_time_saga_-_01_-_darkcookie_&mode=522&img=https%3A%2F%2Fthumb-cdn77.xvideos-cdn.com%2F18e74301-c4db-45fc-b40e-f32044060139%2F0%2Fxv_2_t.jpg&name=Summer+Time+Saga+-+%2801%29+-+%7BDarkCookie%7D+120mSD&hq_stream=&playmode_string=inputstream&play_profile=0&uuid=ea56f36d-b2d0-4828-bf4a-927a3963bdeb"
##            "file" : "C:\\Temp\\current_audio.mp4"
##            #"file" : "C:/Temp/current_audio.mp4"
####            , "media": "files"
##            , "media": "video"
####            "C:\\Temp\\current_audio.mp4"
##            ,"properties": ["playcount"] 
##            #,"value": True
##            }
##        , "id" : 1
##        }]
##    Log(json.dumps(request))
##    val = xbmc.executeJSONRPC(json.dumps(request))
##    LogR(json.loads(val))
##
##    q =         { "jsonrpc": "2.0", "method": "Files.GetFileDetails", 
##        "params": { "file": "C:\\Temp\\to\\files\\Whatever.mp4", 
##        "media": "video", "properties": ["playcount"] } 
##        , "id": 339 }
##        
##    val = xbmc.executeJSONRPC(str(q))
##    LogR(json.loads(val))
##
##    return    
    

#__________________________________________________________________________
# random dev stuff
#    make sure the icon for this is 'playable' to use resolveUrl
@C.url_dispatcher.register("devtest")
def TempDevTest():

    media_url = 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8'
    listitem = xbmcgui.ListItem(
        label = 'test'
        , path=media_url
        , offscreen=True #kodi 18+
        )
    listitem.setMimeType('application/vnd.apple.mpegurl')
    listitem.setContentLookup(False)
    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( media_url, listitem)
    xbmc.Player().play(myPlayList)
            
    return


    media_url = 'https://s2.maxstream.org/hls2/01/00010/fbwzn06bg05g_n/master.m3u8?t=XATWIMl9t3Y67aAhTuvU8_fTn-CK3dbHScxlwUPz48Q&s=1778182113&e=43200&f=54436&i=0.3|Referer=https%3A%2F%2Fjav.guru%2F&User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A147.0%29+Gecko%2F20100101+Firefox%2F147.0'
    media_url = 'https://s100-wyl5.s1q2105.com/hls/ScH4XBBuMgnDU2hJOTXNLk4FaaqSvSVL/master.m3u8?token=de9aeac7e1c83761a5d9ac70db95f462-1778800534-209.227.155.125-38bb1342d1fa7162cacec2f2b3ec865f059842d3820b337967fd73f017850ac5'
    media_url = 'https://tmstr5.neonhorizonworkshops.com/pl/H4sIAAAAAAAAAw3Hy3KDIBQA0F8CRE26a6po04gjwkXdMWDHqlibV02.vj27E9mYuoC4CFG3M.h_MSUoJoh.0l0U25eCYKayjmgfXrgXuYLXu2z4l1kOQ5lD4DK.KYIfH8_3zQRsKfU1bP22yqV9qPzIHBaJg4OGdCgqBZ30TosmpfW0L4qFYeXDJ.CjKRuRnoLibqftu11cVDZzaWR3dhMzdSPORYoCtbTnfpoxKEWUxikkkOhs_RWIe522YTUeNJ_5TSzzjecrEc_jatFEjQ6vJulEX.99n3asSNTmsg1LzDPD3E9VX6iFuYJxMJyt1GKG2rENob6.CZjuvXRDpQHkaIPKc3LCq7AJ10qi_R_E7hnaQQEAAA--/4819a13157d0a04e1f8d6c89893d4b4b/index.m3u8'
    media_url = 'https://black.tylerfisher55.workers.dev/afc7d47f/uz5gyMPGU9TVujalv1-l0sEucQ-XYzGWexlrPi5Zzp-1NnU9GvcV7ha7FAlxqBFDF1kTWXdxU0Cwn3j7O7hcCNMip83Y-_fG8Wtol19H0wIXrui0xcbiwv2gdLOcbbWK7n_y4Qck7R5XcbKdTuOUz9rysfEkGGIQCl_RjzjVQ_yryatvDoGekRtVyr4wyjJxkyA1L9VlqhMfp5Qy1eeS-1WUaXHDJ3c4uuRycQQjgEArwN0dJjX612aeldDK0gkmLNNHURZVrjOoFawpxn0VqPkZpJ_TeHknFPTJ3bPgsaiL7ERc8Y8NckI7kHgxXowqp5JK3uaKlqQgwxSjRqfPSyv1wKbMA70_ewGwFGvQoi-SaTzWKZnL5llFJW0fCFRJqEZvP81NYS4iVCE50tISmPmsyoszse2J9iJvhuSX7J_fToG9ME1m7OWE2Z6b0Jes49ZE19xRSeSe4RC0Pch3fYk3llzYW8AoC1PIRdsesWPIJvYpEe3DGpNnPGZvMRQvCm6u6Uq2SEh1EBbi6i-bZr23-LP6YAz3OYuJ1BileisR8zqxOiDjhV42-qk7PfM_4fSfr5DC6scfJ0ZoSZGG4OsK6I_dp1xsGYYTQ9wsNC2H7c-mYNqFbEbnYqz6xV1vupJFCJ7WP6WbTxEbxgvkJoQm7DYw0ENqIOaV62ZVS6gTfYZOXGionfiXjI-wGyOU7W3cuLDDFJVs2Rx8538hug.m3u8'
    media_url = 'https://s2-100-wyl4.s1q2105.com/hls/wBAMQu9Zj3eRTxXjmCv4SZmjiqoRRzWO/master.m3u8?token=94625732e617bb7e03cc9f59c887dccc-1779736333-173.206.143.62-51403bcb549023a9ae7f399623ddf6d605bb8622e8fa6a3c63f5fcf2f57eb63f'
    media_url = 'https://jolly.tylerfisher55.workers.dev/afc7d47f/ma9yIsUHLd1oEUKmveBRDwcekqKyBrxVnEMZcqLb7GPXK8SY_uYV9o0P8zuN-qvtDzDwCK77nX9McUg3S5xAyN1kpOQ6b7eR5EJDzoXxAexmozn4KPBEv8HjZ4hqpLcRZYPij4TmeLPCdGqtpEMtSuYWqF-SXgfmLkGP4Rbq7Ss9Cdn0pKGw0ElHQJ0SsHxGD-ku9jNH9D5vSJCoMaqRhR6LvuIfo80RV95STOWcgthp00X10KJKmm9EBEdQPODE6S9XckmcnJoY4sy7-O3w6RDv0oxW9FpblFES_3Z3ebV37aF4BU7_OvkIJpwG9c-wOwIXAyK-M6JyIzkzlsU5KYMSB63v3rvqZ0KW48zGh-aYIpku_cKhEcL0T8MwGrJILXlP0uKdg2LqXcxgesfWHNgkJbNbYSAABPITu5Ssy_g1h-9SnCPgZ4ffRLzZtWJzqLYyVDUuorgMgYszDye-KIsJxs_afzAAtJT4mtuEaVhWfTkJ6eCNrjojdffpWAuuhXgQ7cKvQJEhowXqc4g0auAjFrS0tgPaDUQ6o4ey-XYyzhFmIrMD_MK8Iirj7KyLznTZSmevl4lj0cv8YohQR3SswWYNj729ylrDzLhI1-t6-D0qBHc-QYNv-lJWeqkLoAS8Utq6ssHI08rsW2bTvGZtn6o4yBdknzcozXiA8y713HYGRNDNREUjXaIJPixf.m3u8'
    media_url = 'https://server.digitalsun.app/?type=hls&q=VDUxbEstYXdUZGRPR2pxdTh2SjQwUTpaaTljNGRyQ3otRlhSWGRJZ2M1Wnd4UHFabVVPTUQyWUtDTDN2TFZkcTBPX05zc0VfblBodDFmZk5wSl95RUJ3N29PTFg2cnFrdnI1ekN1ZmROU1dQV25WbjZQd01KNkI0bDZUdnB4U0o2bkdmb25TeXhmN09hN2Izck5obmVITzczcUMyMmxxQ0V0c0hsZzh3YjZyMkx5Z2oyTkdpS1dyU3dTWGxfSnAtSlU%3D'
    media_url = 'https://server.digitalsun.app/video.m3u8?q=am5uOFhoakRFVmpRdzdIcWtYVHAxZzo1R2I4LVRWZlQyMm1UdjY4TGlEd0NNbFo4Y1FEbEpQRDFCelZaZ1YyMWJvZncwdGhmUnE3M2pERWhHd3BmaGhoZkk3WnBDdzhucVlfQVVWUk1wWEx3WkdaVWVnMGxLUHlxUXdNbHVHMEhZRFlGU1ZxXzlzT05nVzV3eXNTSHRxaWhyMGtoVTh1V0xBSHZncTFHR2JoVWtVY0F2SkZQQWlzZDNUT3NneWlsZHc&type=hls'

    head = '''
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0
Accept: */*
Accept-Language: en-US,en;q=0.9
Accept-Encoding: gzip, deflate, br
Referer: https://vidcore.net/
Origin: https://vidcore.net
DNT: 1
Sec-GPC: 1
Connection: keep-alive
Sec-Fetch-Dest: empty
Sec-Fetch-Mode: cors
Sec-Fetch-Site: cross-site

'''
    headers = {}
    for h in head.split('\n'):
        h4 = h.split(':', maxsplit=1)
        #print(h4)
        #print(h4)
        #print(len(h4))
        if len(h4) < 2: continue
        headers[h4[0].strip(' ')] = h4[1].strip(' ')
    LogR(headers)

    if '|' not in media_url: media_url += utils.Header2pipestring(headers)

    import player
    player.playvid(
        media_url
          ,name = 'spierman.ts'
          ,description = u'spierman.ts'
          ,download=True
##            ,download=False
    ##                      ,play_profile='profile_00' #download
    ##                  ,play_profile='profile_04'
    ##                      ,playmode_string = C.PLAYMODE_F4MPROXY
    ##                      ,play_profile='profile_01' #high quality
    ##                      ,play_profile='profile_03' #low quality
    ##                      ,playmode_string = C.PLAYMODE_DIRECT
##        ,playmode_string = C.PLAYMODE_INPUTSTREAM
        , mimetype = "application/vnd.apple.mpegurl"
        , skip_head = True #should not request HEAD for some sites
                      )
    return


    import resolveurl
##    reload(downloader)
    source_url = 'https://hls.uniquestream.net/local_embed?id=H5iszo93ljqen5mybejct9'
    media_url = resolveurl.resolve(source_url)
    LogR(media_url)
##    return
    import player
    player.playvid(
        media_url

          ,'Giants vs Steelers'
          ,description = u'Giants vs Steelers'
          #,download=True
            ,download=False
    ##                      ,play_profile='profile_00' #download
    ##                  ,play_profile='profile_04'
    ##                      ,playmode_string = C.PLAYMODE_F4MPROXY
    ##                      ,play_profile='profile_01' #high quality
    ##                      ,play_profile='profile_03' #low quality
    ##                      ,playmode_string = C.PLAYMODE_DIRECT
        ,playmode_string = C.PLAYMODE_INPUTSTREAM
        , mimetype = "application/vnd.apple.mpegurl"
        , skip_head = True #should not request HEAD for some sites
                      )
    return

    #url = Get_Youtube_Url("Ymu8JZMWqD0") #outside
##    url = Get_Youtube_Url("GENH9mWlvb4") #chapel
##    url = Get_Youtube_Url("XuZAl-ZPEcA") #euronews
    url = Get_Youtube_Url("EQYVJQ3Ze0o") #fireplace
    Log(url)
    if not url: return
    import player
    #url = r"c:\temp\uwu.m3u8"
##    url = 'http://raid/tv/Outlander/uwu.m3u8'
##    url = 'https://manifest.googlevideo.com/api/manifest/hls_variant/expire/1775588644/ei/xADVafDrIcupir4Pqd3HwAQ/ip/66.49.210.41/id/GENH9mWlvb4.3/source/yt_live_broadcast/requiressl/yes/xpc/EgVo2aDSNQ%3D%3D/tx/51819631/txs/51819628%2C51819629%2C51819630%2C51819631%2C51819632/hfr/1/playlist_duration/30/manifest_duration/30/demuxed/1/maudio/1/bui/AUUZDGLARIM-in9s0nIwemuwgHLrrgALQvCp1Nuz7HNCKiwWIUSPmn0sYeS1aFz4qjxf3C3rj6eHf7sD/spc/jlWavdZBagzSj194q70bLHS46GXSmLnfzxedK_A-JkmdDoTPBhahxN2irQ/vprv/1/go/1/rqh/5/reg/0/pacing/0/nvgoi/1/short_key/1/ncsapi/1/keepalive/yes/fexp/51565115%2C51565682%2C51835933/dover/13/itag/0/playlist_type/DVR/sparams/expire%2Cei%2Cip%2Cid%2Csource%2Crequiressl%2Cxpc%2Ctx%2Ctxs%2Chfr%2Cplaylist_duration%2Cmanifest_duration%2Cdemuxed%2Cmaudio%2Cbui%2Cspc%2Cvprv%2Cgo%2Crqh%2Creg%2Citag%2Cplaylist_type/sig/AHEqNM4wRgIhAM50WIMAkpdDgRZbg9456-6UnUkkP5QIVmWNwsGTMF1OAiEAokELU2h4PdeDkzm_w3wnfSTZYx2wszLCtmrPAg7GTS8%3D/file/index.m3u8'
##    url = r"c:\temp\fatima.m3u8"
##    url = r"c:\temp\fatima.strm"
##    url = 'https://manifest.googlevideo.com/api/manifest/hls_playlist/expire/1775588644/ei/xADVafDrIcupir4Pqd3HwAQ/ip/66.49.210.41/id/GENH9mWlvb4.3/itag/229/source/yt_live_broadcast/requiressl/yes/ratebypass/yes/live/1/sgovp/gir%3Dyes%3Bitag%3D133/rqh/1/hls_chunk_host/rr17---sn-ojtt15-5j.googlevideo.com/xpc/EgVo2aDSNQ%3D%3D/playlist_duration/30/manifest_duration/30/bui/AUUZDGLARIM-in9s0nIwemuwgHLrrgALQvCp1Nuz7HNCKiwWIUSPmn0sYeS1aFz4qjxf3C3rj6eHf7sD/spc/jlWavdZBagzSj194q70bLHS46GXSmLnfzxedK_A-JkmdDoTPBhahxN2irQ/vprv/1/reg/0/playlist_type/DVR/initcwndbps/3205000/met/1775567276,/mh/US/mm/44/mn/sn-ojtt15-5j/ms/lva/mv/m/mvi/17/pl/20/rms/lva,lva/dover/13/pacing/0/short_key/1/keepalive/yes/fexp/51565115,51565682,51835933/mt/1775566857/sparams/expire,ei,ip,id,itag,source,requiressl,ratebypass,live,sgovp,rqh,xpc,playlist_duration,manifest_duration,bui,spc,vprv,reg,playlist_type/sig/AHEqNM4wRgIhAJQiXOGbYYdRGit0zGXXdxmtNQ3uoV9G5Z53_bWX-hokAiEAwBM-vQuq2ybzmZSQLGXX4T1lzAVBXvf-iDLA2yAO8xo%3D/lsparams/hls_chunk_host,initcwndbps,met,mh,mm,mn,ms,mv,mvi,pl,rms/lsig/APaTxxMwRgIhAKncR7gLBgpArPfacq7xpsL4C3k5QWjWlLek-z68lOAoAiEAwTAzSei_RWoUXJii764k-doUvSY0z_znXlV_2S0KbJ4%3D/playlist/index.m3u8'
##    url = 'https://manifest.googlevideo.com/api/manifest/hls_playlist/expire/1775588644/ei/xADVafDrIcupir4Pqd3HwAQ/ip/66.49.210.41/id/GENH9mWlvb4.3/itag/230/source/yt_live_broadcast/requiressl/yes/ratebypass/yes/live/1/sgovp/gir%3Dyes%3Bitag%3D134/rqh/1/hls_chunk_host/rr17---sn-ojtt15-5j.googlevideo.com/xpc/EgVo2aDSNQ%3D%3D/playlist_duration/30/manifest_duration/30/bui/AUUZDGLARIM-in9s0nIwemuwgHLrrgALQvCp1Nuz7HNCKiwWIUSPmn0sYeS1aFz4qjxf3C3rj6eHf7sD/spc/jlWavdZBagzSj194q70bLHS46GXSmLnfzxedK_A-JkmdDoTPBhahxN2irQ/vprv/1/reg/0/playlist_type/DVR/initcwndbps/3205000/met/1775567276,/mh/US/mm/44/mn/sn-ojtt15-5j/ms/lva/mv/m/mvi/17/pl/20/rms/lva,lva/dover/13/pacing/0/short_key/1/keepalive/yes/fexp/51565115,51565682,51835933/mt/1775566857/sparams/expire,ei,ip,id,itag,source,requiressl,ratebypass,live,sgovp,rqh,xpc,playlist_duration,manifest_duration,bui,spc,vprv,reg,playlist_type/sig/AHEqNM4wRQIhAMKdmSFZ3HdIXOVzpuNnvzYCzMwa1DiRTfb1xhnhu4TIAiBFl8rkphkcdyaIa-4TzRnYOLFulr4-EX3Hc8A221k-mg%3D%3D/lsparams/hls_chunk_host,initcwndbps,met,mh,mm,mn,ms,mv,mvi,pl,rms/lsig/APaTxxMwRQIhAKNaG9zXp3SLmNnhmBTU1UVDPQ3LgWNGNg20YvrouAqlAiArTFEEMO551-tWB3CccwdE3ntbPOsYxvO2Hq5Em4SQHw%3D%3D/playlist/index.m3u8'
    #url = 'http://raid/tv/Outlander/audio.m3u8'
    #url = 'http://raid/tv/Outlander/video.m3u8'
    player.playvid(  url

                      ,'Giants vs Steelers'
                      ,description = u'Giants vs Steelers'
                      #,download=True
                        ,download=False
##                      ,play_profile='profile_00' #download
    ##                  ,play_profile='profile_04'
##                      ,playmode_string = C.PLAYMODE_F4MPROXY
##                      ,play_profile='profile_01' #high quality
##                      ,play_profile='profile_03' #low quality
##                      ,playmode_string = C.PLAYMODE_DIRECT
                    ,playmode_string = C.PLAYMODE_INPUTSTREAM
        , mimetype = "application/vnd.apple.mpegurl"
        , skip_head = True #should not request HEAD for some sites
                      )
        


##    utils.Sleep(500)
    return

    #make sure 
####    url = "https://manifest.googlevideo.com/api/manifest/hls_variant/expire/1768686886/ei/xrBrafmcKfmz-coP2Y6T0Qc/ip/173.206.104.147/id/a2fb5ff123d4b242/source/youtube/requiressl/yes/xpc/EgVo2aDSNQ%3D%3D/playback_host/rr1---sn-vgqsknse.googlevideo.com/cps/169/met/1768665286%2C/mh/zC/mm/31%2C29/mn/sn-vgqsknse%2Csn-tt1e7nlz/ms/au%2Crdu/mv/m/mvi/1/pl/19/rms/au%2Cau/tx/51539831/txs/51539830%2C51539831/hfr/1/tts_caps/1/maudio/1/initcwndbps/3730000/bui/AW-iu_ptd4S_YTNQFOnxLE9djcr9hP_6CBo6SqZHIEVdJMljVjwtRQUMmn0Qtg4Xul9MkWmJwkVgmUl2/spc/q5xjPHNBFcdzJV5M6FxjUBRUdCILSpKIDpZrE5Im_DNG5MbDyKw4_4xkK8_SFnqX4aOQNA/vprv/1/go/1/ns/bZ18-OaMPblNv4cUP4OZ9IAR/rqh/5/mt/1768664935/fvip/2/nvgoi/1/ncsapi/1/keepalive/yes/fexp/51355912%2C51552689%2C51565115%2C51565682%2C51580968/dover/11/n/uETz8oQ9FHJx2cew2UX/itag/0/playlist_type/CLEAN/sparams/expire%2Cei%2Cip%2Cid%2Csource%2Crequiressl%2Cxpc%2Ctx%2Ctxs%2Chfr%2Ctts_caps%2Cmaudio%2Cbui%2Cspc%2Cvprv%2Cgo%2Cns%2Crqh%2Citag%2Cplaylist_type/sig/AJfQdSswRQIgfx5vy-ZqvzO9jpvCSKZg5dCGgRQaFx0RLgSyGsApPpUCIQC7bpdTjBcJoah3FgT32v6M6IPBCtaXx8IShdHoE9rV4Q%3D%3D/lsparams/playback_host%2Ccps%2Cmet%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps/lsig/APaTxxMwRQIgLWNccVoAau2GI1GSL1T-KsJLqfFbPSZ-X1lb1d3-HwcCIQDUWRuHmSg-BuKFuEpxrRBKtoj_XfhXnTV9pOhdGAqOaw%3D%3D/file/index.m3u8"
####    url = 'https://manifest.googlevideo.com/api/manifest/hls_variant/expire/1768683176/ei/SKJrabjoHZTA-coPu8X7wAE/ip/173.206.104.147/id/7430ea0f5fc7821a/source/youtube/requiressl/yes/xpc/EgVo2aDSNQ%3D%3D/playback_host/rr3---sn-vgqsknsk.googlevideo.com/cps/0/met/1768661576%2C/mh/GA/mm/31%2C29/mn/sn-vgqsknsk%2Csn-tt1e7nlz/ms/au%2Crdu/mv/m/mvi/3/pl/19/rms/au%2Cau/tx/51539831/txs/51539830%2C51539831/hfr/1/demuxed/1/tts_caps/1/maudio/1/initcwndbps/3723750/bui/AW-iu_qNoJQdjXI-GA4iivmLtN5lwXxRS1osmaop7u2vCIwPfXSAMGn6s_cQKSF_BcsOt40W8hT54nRg/spc/q5xjPOZLGDDvVXAWjScLI8PSANyPhauax8PqtbkNNb2qaqi2ZK7fMTLSlXqG/vprv/1/go/1/rqh/5/mt/1768661334/fvip/3/nvgoi/1/short_key/1/ncsapi/1/keepalive/yes/fexp/51552689%2C51565115%2C51565682%2C51580968%2C51626154/dover/13/itag/0/playlist_type/DVR/sparams/expire%2Cei%2Cip%2Cid%2Csource%2Crequiressl%2Cxpc%2Ctx%2Ctxs%2Chfr%2Cdemuxed%2Ctts_caps%2Cmaudio%2Cbui%2Cspc%2Cvprv%2Cgo%2Crqh%2Citag%2Cplaylist_type/sig/AJfQdSswRgIhAP1IGfrLAD1ny_f7MZKjqb9au4lf9S7SEe-kp0Kv-hehAiEA3fmjMEyd2kEds4e-XX--MTy2-v5HtUFC56KETh2IUYc%3D/lsparams/playback_host%2Ccps%2Cmet%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps/lsig/APaTxxMwRAIgO9rMBBphK8HZxJ_jGNrOcrLMcjq8LuSsviSoW0vKJmkCIBSzReYebwud8fMWl9vbKioktN0u-NnAz6p1QK1RKenv/file/index.m3u8'
##    url = "https://manifest.googlevideo.com/api/manifest/hls_playlist/expire/1768683176/ei/SKJrabjoHZTA-coPu8X7wAE/ip/173.206.104.147/id/7430ea0f5fc7821a/itag/234/source/youtube/requiressl/yes/ratebypass/yes/pfa/1/goi/133/sgoap/clen%3D51876949%3Bdur%3D3205.421%3Bgir%3Dyes%3Bitag%3D140%3Blmt%3D1682007076726741/rqh/1/hls_chunk_host/rr3---sn-vgqsknsk.googlevideo.com/xpc/EgVo2aDSNQ%3D%3D/cps/0/met/1768661576,/mh/GA/mm/31,29/mn/sn-vgqsknsk,sn-tt1e7nlz/ms/au,rdu/mv/m/mvi/3/pl/19/rms/au,au/initcwndbps/3723750/bui/AW-iu_qNoJQdjXI-GA4iivmLtN5lwXxRS1osmaop7u2vCIwPfXSAMGn6s_cQKSF_BcsOt40W8hT54nRg/spc/q5xjPOZLGDDvVXAWjScLI8PSANyPhauax8PqtbkNNb2qaqi2ZK7fMTLSlXqG/vprv/1/playlist_type/DVR/dover/13/txp/5432434/mt/1768661334/fvip/3/short_key/1/keepalive/yes/fexp/51552689,51565115,51565682,51580968,51626154/sparams/expire,ei,ip,id,itag,source,requiressl,ratebypass,pfa,goi,sgoap,rqh,xpc,bui,spc,vprv,playlist_type/sig/AJfQdSswRAIgYAmbhMV77zmq7FzAiUSQWtUFQK9_vkKvUGgia8BZrUUCIG6gE3ClluwZzrVltPa4KhcwtkK0pLZ04y-35IFVbYQj/lsparams/hls_chunk_host,cps,met,mh,mm,mn,ms,mv,mvi,pl,rms,initcwndbps/lsig/APaTxxMwRQIgL27mtRhyN_cD5w4qgmBNQCTG7l4bhe-5uNvqWtNiWmkCIQC0PvBfxeV_vOJSah78BPBs0uUywgzSrm6WRnKrZ2HvNg%3D%3D/playlist/index.m3u8"
##    try:
##        import player
##        player.playvid(  url
##
##                          , u'testmusic'
##                          ,description = u'testmusic'
####                          ,download=True
##                          #  ,download=False
##    ##                      ,play_profile='profile_00' #download
##        ##                  ,play_profile='profile_04'
##        ##                  ,playmode_string = C.PLAYMODE_F4MPROXY
##        ##                  ,play_profile=C.DEFAULT_PROFILE_NAME
####                          ,playmode_string = C.PLAYMODE_DIRECT
####                       ,playmode_string = C.PLAYMODE_INPUTSTREAM
####                         ,skip_head=False
##                          )
##    except:
##        traceback.print_exc()    
##    utils.Sleep(500)
##    return
##    
##
##    #test skin settings
####    progress_dialog = utils.Progress_Dialog(title='name', message='name')
##    utils.Sleep(500)
##    return

    import sys
    LogR(sys.version,C.LOGWARNING)
    



    return
    Log(utils.getHtml("https://jav.guru" )[0:500])


    utils.endOfDirectory(succeeded=True)
    return

    url = 'https://www.porntrex.com/get_file/10/3b4f0bfc01cd5012f6dbde1591cf8156a934e71863/2520000/2520015/2520015_1080p.mp4/'
##    url += '|User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A141.0%29+Gecko%2F20100101+Firefox%2F141.0&Accept=text%2Fhtml%2Capplication%2Fxhtml%2Bxml%2Capplication%2Fxml%3Bq%3D0.9%2C%2A%2F%2A%3Bq%3D0.8&Accept-Encoding=gzip%2C+deflate&Accept-Language=en-US%2Cen%3Bq%3D0.5&DNT=1&Sec-GPC=1&Connection=keep-alive&Upgrade-Insecure-Requests=1&Sec-Fetch-Dest=document&Sec-Fetch-Mode=navigate&Sec-Fetch-Site=none&Sec-Fetch-User=%3F1&Priority=u%3D0%2C+i&Referer=https%3A%2F%2Fwww.porntrex.com%2Fvideo%2F2520015%2Ffilthyfamily-molly-mae-and-kylie-rocket-mp4&User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F139.0.0.0+Safari%2F537.36+Edg%2F139.0.0.0&Accept=%2A%2F%2A&Accept-Language=en-US%2Cen%3Bq%3D0.5&Connection=keep-alive&Referer=https%3A%2F%2Fwww.porntrex.com%2F&Cookie=confirmed%3Dtrue'
    headers = {
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:142.0) Gecko/20100101 Firefox/142.0'
    ,'Accept':'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5'
    ,'Accept-Language':'en-US,en;q=0.5'
    ,'DNT':'1'
    ,'Sec-GPC': '1'
    ,'Connection':'keep-alive'
    ,'Referer': url # https://cdn.pcdn.li/d2cbf61/00801/2520000/2520015/2520015.mp4?expires=1756660873&md5=eJamnP0dF49RkV7YUdHp1w
    ,'Sec-Fetch-Dest':'video'
    ,'Sec-Fetch-Mode':'no-cors'
    ,'Sec-Fetch-Site':'same-origin'
    ,'Accept-Encoding':'identity'
    ,'Priority':'u=4'
    }
##    url = 'https://cdn.pcdn.li/d2cbf61/00801/2520000/2520015/2520015.mp4?expires=1756660873&md5=eJamnP0dF49RkV7YUdHp1w|User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A141.0%29+Gecko%2F20100101+Firefox%2F141.0'
    #url = "http://raid/pics/Amy%20Reid/Amy%20Reid%20%20Voyeur%20Vision%202.avi.mp4"

    url += utils.Header2pipestring(headers)
    name = 'Molly Mae, Kylie Rocket - Spying on my Step Sisters'
    dest = 'C:\\temp\\tmpj0nadp82.mp4'
    progress_dialog = utils.Progress_Dialog(title=name, message=name)
    stop_event = threading.Event()
    
    downloader.doDownload(url, dest, progress_dialog, name, stop_event)
    

    utils.endOfDirectory(succeeded=True)
    return


    import six
    from six.moves import urllib_request

    try:
        url = "https://jav.guru"
        req = urllib_request.Request(url)
        LogR(dir(urllib_request))
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0')
        req.add_header('Accept-Encoding', 'gzip')
        response = urllib_request.urlopen(req, timeout=20)
        LogR(response)
    except:
        traceback.print_exc()

    utils.endOfDirectory(succeeded=True)
    return

    import resolveurl
##    reload(downloader)
    links = '  https://gradehgplus.com/e/qpmf0zvvms48   '  

    url = resolveurl.resolve(web_url=links, return_all=True)
    LogR(url)
    C.addon_handle = -1
    import player
    player.playvid(  url

                      ,'Giants vs Steelers'
                      ,description = u'Giants vs Steelers'
                      #,download=True
                        ,download=False
##                      ,play_profile='profile_00' #download
    ##                  ,play_profile='profile_04'
    ##                  ,playmode_string = C.PLAYMODE_F4MPROXY
    ##                  ,play_profile=C.DEFAULT_PROFILE_NAME
##                      ,playmode_string = C.PLAYMODE_DIRECT
                    ,playmode_string = C.PLAYMODE_INPUTSTREAM
                      )
        
    return

##    Log('warning Stella Luxx décide de donner sa belle chatte à ce mec chaud')
##    Log('error d\\u00e9cide')
##    Log('error d\\u00e9cide'.encode('utf8'))
##    Log('error d\\u00e9cide'.encode('utf8').decode('raw_unicode_escape') )
##
##    name = 'décide'
##    name_1 = 'FC2 PPV 3258256 \u3010\u9854\u6652\u3057/\u5bb9\u59ff\u7aef\u9e97\u3011\u30b9\u30ec\u30f3\u30bf\u3099\u30fc\u304f\u3072\u3099\u308cBody\u306e\u7f8e\u5bb9\u5e2b\u3086\u3046\u308a\u3061\u3083\u3093\u3078\u3002\u9023\u7d61\u304b\u3099\u9014\u5207\u308c\u305f\u306e\u3066\u3099\u3001\u9854\u6652\u3057\u306e\u52d5\u753b\u6652\u3057\u307e\u3059\u3002\u9023\u7d61\u5f85\u3063\u3066\u307e\u3059\u3002\u6b63\u5e38\u4f4d\u3068\u80cc\u9762\u9a0e\u4e57\u3066\u30992\u56de\u4e2d\u51fa\u3057\u3057\u305f\u3051\u3068\u3099\u598a\u5a20\u3057\u3066\u307e\u305b\u3093\u304b? [COLOR blue]fhd[/COLOR]'
##    name = name_1
##    liz = xbmcgui.ListItem(label = name)
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##    name = name_1.decode('raw_unicode_escape')
##    liz = xbmcgui.ListItem(label = name)
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##    name = name_1.decode('utf8')
##    liz = xbmcgui.ListItem(label = name)
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##
##    liz = xbmcgui.ListItem(label = u'Chatte Rase\u0301e')
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##    liz = xbmcgui.ListItem(label = 'Chatte Rase\u0301e'.decode('raw_unicode_escape'))
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##
##    liz = xbmcgui.ListItem(label = name)
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##    liz = xbmcgui.ListItem(label = 'error d\u00e9cide')
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##    liz = xbmcgui.ListItem(label = 'error d\\u00e9cide')
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##    liz = xbmcgui.ListItem(label = 'error d\\u00e9cide'.replace("\\","\\\\"))
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##    liz = xbmcgui.ListItem(label = 'décide')
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)
##
##    utils.endOfDirectory(succeeded=True)
##    return
##
##    import resolveurl
##    LogR(utils.Is_Online())
##    return
##
##    progress_dialog = xbmcgui.DialogProgressBG()
##    progress_dialog.create(C.addon_name,C.addon_name[:50])
##    utils.Sleep(1000)
##
##    progress_dialog = utils.Progress_Dialog(C.addon_name,u"stopping '{}'".format('asdasd'))
##    progress_dialog.close()
##    progress_dialog = None
        
    return
##    from openscrapers import sources
    sourceDict = sources()
    for s in sourceDict:
##        Log(repr(dir(s)))
##        Log(repr(s))
##        Log(repr((s[0], s[1])))
##        #tt6263850 #deadpool 3
##        url = s[1].movie('tt6263850', 786892, 'title', 'localtitle', [], '1984')
##        #tt3530232 #john oliver
##        url = s[1].movie('tt3530232', 786892, 'title', 'localtitle', [], '1984')
        #tt6156584 #snowpeircer
##        url = s[1].('tt6156584', 79680, 'title', 'localtitle', [], '1984')
##        url = s[1].tvshow('tt6156584', 79680, 666, 'tvshowtitle', 'localtitle', ['alias1'], '1984', '4') 
##        url = s[1].episode(url, 'tt6156584', 79680, 'tvdb', 'title', '2022-2-2', '4', '2') #snowpeircer
##        url = s[1].episode(url, 1, 94997, 666, 'title', '2022-2-2', '2', '5') #house of the dragon
##        Log(url)
##        return
##        url = 'https://c.trydarius.shop/espn.m3u8'
##        sources = s[1].sources(url, [], [])
##        Log(repr(sources))
##        Log(repr(sources[0]['url']))
##                      #sources[0]['url']

        import resolveurl
    ##    reload(downloader)
        vid = ''
        links = '  https://filemoon.sx/e/og7hq7fra7bk/ '
        links = '  https://hlsflast.com/e/qsjknmraok4a '
        #links = " https://moon-4uemks89-embed.com/ptsd/w0nyfuo8b72i "

        url = resolveurl.resolve(web_url=links, return_all=True)
        Log(repr(url))
        #return
        utils.playvid(  url

                      ,'Giants vs Steelers'
                      ,description = u'Giants vs Steelers'
                      #,download=True
                        ,download=False
##                      ,play_profile='profile_00' #download
    ##                  ,play_profile='profile_04'
    ##                  ,playmode_string = C.PLAYMODE_F4MPROXY
    ##                  ,play_profile=C.DEFAULT_PROFILE_NAME
    ##                  ,playmode_string = C.PLAYMODE_DIRECT
                      )
            
        break

    utils.endOfDirectory(succeeded=True)
    return
    
##    vid = 'xhttps://xxea.v4507fb3559.site/_v2-ewdl/9a701df34ba7e4ae16c25b01dd7fefae271976c44e44c7b8c9c878fe4fcd06741ae3e719f0ef63837c6cf62e8daaecb28d7ff9aa0d734593957b6ac9d00000287bf369936d99f3a87391fa2e8356958407dd68adf3e0d911963b14ace5c3e7a17d63cf9a5ba315ed3073d1/h/list;9d705ee448b4e4e553dc06568f6feda3345b239e1c12c8.m3u8'
##    utils.playvid(vid
##                  ,'maiseltest'
##                  ,description = u'deadpool'
##                  ,download=True
##    )    
##    return
##    import resolveurl
####    reload(downloader)
##    vid = ''
##    links = 'https://ds2play.com/e/x1068ey8rdhj" title="" target="_blank">\n '
##
##    vid = resolveurl.resolve(web_url=links, return_all=True)
##    Log(repr(vid))
##        
##    for web_url in links.split('  '):
##        if not web_url: continue
##        Log(repr(web_url))
##        
##        vid = resolveurl.resolve(web_url=web_url, return_all=False)
##        Log(repr(vid))
##        if vid: break
##
##    utils.endOfDirectory()
##    return
##    utils.playvid(vid
##                  ,'maiseltest'
##                  ,description = u'mail'
####                  ,download=True
####                  ,play_profile='profile_00' #download
####                  ,play_profile='profile_04'
####                  ,playmode_string = C.PLAYMODE_F4MPROXY
####                  ,play_profile=C.DEFAULT_PROFILE_NAME
####                  ,playmode_string = C.PLAYMODE_DIRECT
##                  )
##    utils.endOfDirectory()
##    
##    return vid
####    reload(downloader)
##    import threading
##
##
##    
##    downloader.Background_HLSDownloader(url='https://old.reddit.com/r/Cooking/comments/174zpk2/what_food_is_so_good_you_cant_believe_its_healthy/'
##                                        ,download_path=download_path
##                                        ,name=name
##                                        ,stop_event=threading.Event()
##                                        ,repeat_when_available=False
##                                        ,rowid=0
##                                        )
##                                        
##    return
##
##    server='1.1.1.1'
####    server='192.168.10.49'    
##    port='443'
####    server='localhost'
####    port='1025'
##
##    import socket
##    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
##    s.settimeout(3)
##    try:
##        qq = s.connect_ex((server, int(port)))
##        if not qq == 0: raise Exception(qq)
####        msg = "GET / HTTP/1.0\r\n\r\n"
####        Log(repr(msg.encode('utf-8')))
####        s.sendall(msg.encode('utf-8'))
####        while 1: 
####            Log(" Fourth tr-except block -- waiting to receive data from remote host ")
####            try:
####                Log('d')
####                buf = s.recv(256)
####                Log('3')
####            except socket.error as e: 
####                Log("Error receiving data: %s" % e) 
####                return
####            if not len(buf): 
####                break 
####            # write the received data
####            Log(buf.decode('utf-8'))
##        
##    except socket.error as msg:
##        Log(repr(msg)) ##if msg.errno == 10051: #not reachable
##        return False
##    except:
##        traceback.print_exc()
##    finally:
##        s.close()

##    import resolveurl
##    link = 'https://watchx.top/v/Xu3oWM6VVA0y/'
##    link = 'https://dood.yt/e/lc6n1ifj7b8hj6vqwkep9kr2s61d8rfp'
##    link = 'https://filemoon.sx/e/08duxohvd6bs/citadel_s01e03_1080p_web_h264-cakes'
####    link = (link+'|'+utils.urllib.urlencode({'Referer':'https://netmovies.to/'}))
####    vid = resolveurl.resolve(link)
##    vid = 'https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/1080/index.m3u8,[720]https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/720/index.m3u8,[360]https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/360/index.m3u8,[auto]https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/playlist.m3u8'
##    vid = 'https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/1080/index.m3u8'
##
##    Log(repr(vid))
####    return
##    utils.playvid(vid
##                  ,'maiseltest'
##                  ,description = u'mail'
##                  ,download=True
####                  ,play_profile='profile_00' #download
####                  ,play_profile='profile_04'
####                  ,playmode_string = C.PLAYMODE_F4MPROXY
####                  ,play_profile=C.DEFAULT_PROFILE_NAME
####                  ,playmode_string = C.PLAYMODE_DIRECT
##                  )
##    utils.endOfDirectory()
##    
##    return
##    import xbmcgui
##    progress_dialog = xbmcgui.DialogProgressBG()
##    progress_dialog.create('header','message') #reloading skin will hide existing progress
##    progress_dialog.close()
##    
##    #utils.endOfDirectory() 
##    return
##    import os
##    f1 = u'[\/:*"<>|this  mom?].mp4'
##    f2 = u"c:\\temp\\" + utils.Clean_Filename(f1, include_square_braces=False)
##    Log(repr(f2))
##    os.rename(u"C:\\Temp\\mom.mp4", f2)
####    utils.endOfDirectory()
##    return
##
##    downloader.Stop_Download(u'https://psv143-1.crazycloud.ru/vkvd208.mycdn.me/?expires=1681049954345&srcIp=95.215.205.11&pr=40&srcAg=UNKNOWN&ms=185.226.53.199&type=3&sig=KX33kr3jRZw&ct=0&urls=45.136.21.205&clientType=14&appId=512000384397&zs=43&id=2893745228451&videos=-115615196_456279816&extra_key=M9Iji3AZuCWAd57aXMcfVA&videos=-115615196_456279816|verifypeer=false&Accept-Language=en-US%2Cen%3Bq%3D0.9&Accept-Encoding=gzip%2C+deflate&Accept=%2A%2F%2A&User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A91.0%29+Gecko%2F20100101+Firefox%2F91.0&Referer=https%3A%2F%2Fdaft.sex%2Fwatch%2F-115615196_456279816', u'[TrueAnal] Jazlyn Ray - Jazlyn\u2019s Backdoor Cravings', False, None, None)
##    return
##
##    try:
##
##        import xbmcgui
##     
##        #std::unique_ptr< std::vector< int > > 	multiselect #
##        #(const String &heading
##        #,const std::vector< Alternative< String, const ListItem * > > &options
##        #, int autoclose=0
##        #, const std::vector< int > &preselect=std::vector< int >()
##        #, bool useDetails=false)
##        choices = [] #'all', 'movies', 'musicvideos', 'tvshows']
##
##        for a in range(9):
##            listitem = xbmcgui.ListItem(
##                label = str(a)
##                , path= 'path' + str(a)
##                )
##            listitem.setArt( #setart because other method deprecated
##                    {
##                        "icon" : "DefaultVideo.png"
##                        , "thumb": "DefaultVideo.png"
##                    }
##                )
##            choices.append(listitem)
##    
##        
##        import xbmcgui
####        dd = xbmcgui.Dialog().multiselect('title', choices, useDetails=True)
####        Log(repr(dd))
##
####            - 1 : ShowAndGetFile
####            - 2 : ShowAndGetImage
#### shares from "C:\Program Files (x86)\Kodi\userdata\iOS\sources.xml"
##        files = xbmcgui.Dialog().browseMultiple(type=1, heading='Select files'
##                                                , shares='pictures'
##                                                , useThumbs=True)
##        Log(repr(files))
##    except:
##        traceback.print_exc()
##    
###    service.reboot_required_detection()
##    
####    try:
####        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
####        Log(repr(json.loads(val)['result']['value']))
####
####        #xbmc.executebuiltin('RunScript("C:\\Users\\bob\AppData\\Roaming\\Kodi\\addons\\skin.lyrebird\\scripts\\myscript.py")', True)
####        #xbmc.executebuiltin('RunScript("skin.lyrebird.scripts.myscript")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"scripts.myscript")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"scripts.myscript.py")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"myscript.py")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"myscript")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,myscript.py)', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,myscript)', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"scripts\\myscript.py")', True)
####        #err msg  xbmc.executebuiltin('RunScript(script.toolbox.myscript)')
####        #err msg  xbmc.executebuiltin('RunScript(script.toolbox.myscript.py)')
####        
####        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
####        Log(repr(json.loads(val)['result']['value']))
####    except:
####        traceback.print_exc()
##    
##
#####    Log(xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"audiooutput.audiodevice"},"id":1}'))
####    val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
####    Log(repr(json.loads(val)['result']['value']))
######    Log(repr(val))
######    Log(repr(dir(val)))
######    Log(repr(val['result']['value']))
######    val = val['result']['value']
####    val = (json.loads(val)['result']['value'])
####    result = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy","value":' + str(not(val)).lower() + '}, "id":1}')
####    Log(repr(result))
####    val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
####    Log(repr(json.loads(val)['result']['value']))
##
####    <setting id="network.httpproxypassword" default="true"></setting>
####    <setting id="network.httpproxyport">1025</setting>
####    <setting id="network.httpproxyserver">localhost</setting>
####    <setting id="network.httpproxytype" default="true">0</setting>
####    <setting id="network.httpproxyusername" default="true"></setting>
####    <setting id="network.usehttpproxy" default="true">false</setting>
##    
##    utils.endOfDirectory()
##    return
##
##    Log('pycrypt not available using slow decryption') #, xbmc.LOGNONE)
##    USEDec=3 ## 1==crypto 2==local, local pycrypto
##
##    import array
##    import base64
##    from f4mUtils import python_aes
####    from f4mUtils import openssl_aes
##
##    pass_ph = '5ee595b1c1150a9bb64ab546cc2e4e28' #was hex string; then base64decoded
##    Log(repr(pass_ph))
##    Log(repr(base64.b64encode(pass_ph)))
##    Log(repr(array.array('B',base64.b64encode(pass_ph))))
##
##    iv = (
##        'f8b83c54b42e8f03'
##        )
####            5ee595b1c1150a9bb64ab546cc2e4e28    
######          123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
######          4e57566c4e546b31596a466a4d5445314d474535596d49324e4746694e54513259324d795a54526c4d6a673d
####            4e57566c4e546b31596a466a4d544531
####            4d474535596d49324e4746694e545132
####            59324d795a54526c4d6a673d
##    key  = (
##        '2a265272f02233b6'
##        'f5a6bbc5008bdd5b'
##        )
####    key="NWVlNTk1YjFjMTE1MGE5YmI2NGFiNTQ2Y2MyZTRlMjg="
####    key = base64.b64decode(key)
###    iv = ''
##
##    MODE_CBC = 2
##    BLOCK_SIZE = 16
##    def pad(data):
##        length = BLOCK_SIZE - (len(data) % BLOCK_SIZE)
##        return data + chr(length)*length
##    def unpad(data):
##        return data[:-ord(data[-1])]
##    def encrypt(message, key, IV):
##        #IV = Random.new().read(BLOCK_SIZE)
##        aes = python_aes.new(key, MODE_CBC, IV)
##        return base64.b64encode(IV + aes.encrypt(pad(message)))
##    def decrypt(encrypted, key):
##        encrypted = base64.b64decode(encrypted)
##        IV = encrypted[:BLOCK_SIZE]
##        ivb = array.array('B',IV)
##        aes = python_aes.new(key, MODE_CBC, ivb)
##        tt = aes.decrypt(encrypted[BLOCK_SIZE:])
##        return unpad(tt)
##
##    ivb=array.array('B',iv)
##    keyb= array.array('B',key)
##    Log("python_aes.new(keyb, MODE_CBC, ivb)")
##    Log("keyb={}".format(repr(keyb)))
##    Log("ivb={}".format(repr(ivb)))
##    MODE_CBC = 2
##    enc=python_aes.new(keyb, MODE_CBC, ivb)
####    enc=openssl_aes.new(keyb, 2, ivb)
##
##
##    chunk = "Ygy+6ap2h0PB5sCy3s1OhNpgYsSayyyD7wFLdJ0K4JnNhydK0FTvxxbqwB02DoM423Dgukk4uLh1by60MLi9rSIqj3eg0Yad8PEHIXav82xduDDsjgfTRyqYNN+prdWjfBG+a08SXM2xJM+EjyxPbwbTMmYX7twRfwzcKxLs79uEpH36X3A/kLpew2Ydv8jsHT2oEWdz4LQVhcC971qo+4BBZUbDX+LIdCon26uleK3UpQPKIWuBkcn01Zj/LzMlk3agSq8mHEnIWFUrdnYOMjoqyFsmyTkpbtIhdzLwVPc="
##
####    Log(repr(decrypt(chunk, keyb)))
##
##    #chunk = chunk[BLOCK_SIZE:]
##    chunk = base64.b64decode(chunk)
###    chunk = pass_ph + chunk
###    Log("array")
##    chunkB = array.array('B',chunk)
##    Log("chunkB={}".format(repr(chunkB)))
####    Log("decrypt")
##    chunk = enc.decrypt(chunkB)
####    Log("join")
##    chunk = "".join(map(chr, chunk))
##    #Log('end decrypting chunk, USEDec={}'.format(USEDec))
##    Log(repr(chunk))
####    Log('afterdecrypting' + repr(chunk.encode('utf8')))
##
##
###url = 'https://dood.to/e/4la4btw5nspt'
###import resolveurl
###u = resolveurl.resolve(url)
###Log(repr(u), xbmc.LOGNONE)
###Log(repr(sys.version), xbmc.LOGNONE)
###Log('')
####xx = utils.getHtml("https://www.imdb.com/chart/top" )
####import requests
####xx = requests.get(
####    "https://www.imdb.com/chart/top" 
####    , headers={'User-agent': 'Mozilla/5.0'}
####    , timeout=20)
##    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_INDEX)
def INDEX():

##    name = 'décide'
##    name_1 = 'FC2 PPV 3258256 \u3010\u9854\u6652\u3057/\u5bb9\u59ff\u7aef\u9e97\u3011\u30b9\u30ec\u30f3\u30bf\u3099\u30fc\u304f\u3072\u3099\u308cBody\u306e\u7f8e\u5bb9\u5e2b\u3086\u3046\u308a\u3061\u3083\u3093\u3078\u3002\u9023\u7d61\u304b\u3099\u9014\u5207\u308c\u305f\u306e\u3066\u3099\u3001\u9854\u6652\u3057\u306e\u52d5\u753b\u6652\u3057\u307e\u3059\u3002\u9023\u7d61\u5f85\u3063\u3066\u307e\u3059\u3002\u6b63\u5e38\u4f4d\u3068\u80cc\u9762\u9a0e\u4e57\u3066\u30992\u56de\u4e2d\u51fa\u3057\u3057\u305f\u3051\u3068\u3099\u598a\u5a20\u3057\u3066\u307e\u305b\u3093\u304b? [COLOR blue]fhd[/COLOR]'
##    name = name_1
##    liz = xbmcgui.ListItem(label = name)
##    xbmcplugin.addDirectoryItem(handle=C.addon_handle,url='', listitem=liz, isFolder=False)


    with threading.Lock():

        
        if C.DEBUG:
            utils.addDir(
                name = '[COLOR]Latest DevTest[/COLOR]'.format(C.test_text_color)
                 ,url = C.DO_NOTHING_URL
                 ,mode = "devtest"
                 ,iconimage=C.settings_icon
#                 ,Folder = True
                 ,Folder = False
                )
            utils.addDir(
                name = '[COLOR {}]Test All Sites[/COLOR]'.format(C.test_text_color)
                ,url = C.DO_NOTHING_URL
                ,mode = C.ROOT_TEST_ALL
                ,Folder = True)
            utils.addDir(
                name = '[COLOR {}]Test Favorites[/COLOR]'.format(
                    C.test_text_color
                    )
                ,url = C.DO_NOTHING_URL
                ,mode = C.ROOT_FAVTEST_ALL
                ,Folder = True
                )
            utils.addDir(
                name = '[COLOR {}]Webcam Scan[/COLOR]'.format(C.test_text_color)
                 ,url = C.DO_NOTHING_URL
                 ,mode = C.ROOT_SERVICE_UPDATE
                 ,Folder = False)
            utils.addDir(
                name = "[COLOR {}]Webcam Record ScanStart[/COLOR]".format(
                    C.test_text_color,
                    )
                 ,url = C.DO_NOTHING_URL
                 ,mode = C.ROOT_SERVICE_SCAN_START
                 ,Folder = False)
            utils.addDir(
                name = "[COLOR {}]Refresh Texture Timestamp[/COLOR]".format(
                    C.test_text_color,
                    ),
                 url = C.DO_NOTHING_URL,
                 mode = C.REFRESH_TEXTURE_TIMESTAMP,
                 Folder = False,
                )

##        utils.addDir(
##            name = '[COLOR]Latest DevTest[/COLOR]'.format(C.test_text_color)
##             ,url = C.DO_NOTHING_URL
##             ,mode = "devtest"
##             ,iconimage=C.settings_icon
###                 ,Folder = True
##             ,Folder = False
##            )
        utils.addDir(
            '[COLOR {}]WC[/COLOR] [COLOR {}]Favorites[/COLOR]'.format(
                C.program_text_color
                ,C.highlight_text_color
                )
            , url = C.DO_NOTHING_URL
            , mode = C.ROOT_INDEX_FAVORITES
            , iconimage=C.favorites_icon
            , Folder = True
            )
        
        utils.addDir(
            '[COLOR {}]Search All WC[/COLOR]'.format(C.search_text_color)
            ,''
            ,C.ROOT_SEARCH_ALL
            ,iconimage=C.search_icon
            , end_directory=True
            )
        utils.addDir(
            '[COLOR {}]Front Pages[/COLOR]'.format(C.highlight_text_color)
            ,url = C.DO_NOTHING_URL
            ,mode = C.ROOT_FRONT_PAGE
            ,iconimage=C.search_icon
            ,Folder = True
            )
        utils.addDir(
            '[COLOR {}]WC[/COLOR] Scenes'.format(C.program_text_color)
            ,url = C.DO_NOTHING_URL
            ,mode = C.ROOT_INDEX_SCENES
            ,iconimage=C.scenes_icon
            ,Folder = True
            )
        utils.addDir(
            '[COLOR {}]WC[/COLOR] Movies'.format(C.program_text_color)
            ,url = C.DO_NOTHING_URL
            ,mode = C.ROOT_INDEX_MOVIES
            ,iconimage=C.movies_icon
            ,Folder = True
            )
        utils.addDir(
            '[COLOR {}]WC[/COLOR] Hentai'.format(C.program_text_color)
            , url = C.DO_NOTHING_URL
            , mode = C.ROOT_INDEX_HENTAI
            , iconimage=C.tubes_icon
            , Folder = True
            )
        utils.addDir(
            '[COLOR {}]WC[/COLOR] Tubes'.format(C.program_text_color)
            , url = C.DO_NOTHING_URL
            , mode = C.ROOT_INDEX_TUBES
            , iconimage=C.tubes_icon
            , Folder = True
            )
        utils.addDir(
            '[COLOR {}]WC[/COLOR] Webcams'.format(C.program_text_color)
            , url = C.DO_NOTHING_URL
            , mode = C.ROOT_INDEX_CAMS
            , iconimage=C.webcams_icon
            , Folder = True
            )


        download_path = utils.get_setting('download_path', str)
        if not (download_path and os.path.exists(download_path)):
            downloader.Make_download_path('')
        utils.addDir(
            name = '[COLOR {}]WC[/COLOR] Download Folder'.format(C.program_text_color)
            , url = download_path
            , mode = C.ROOT_INDEX_DOWNLOAD_FOLDER
            , iconimage=C.downloads_icon
             ,Folder = False
            )
            
    ##    if len(downloader.active_downloads()) > 0 or utils.get_setting('debug'):
        utils.addDir(
            name = '[COLOR {}]WC Background Downloads[/COLOR]'.format(C.highlight_text_color)
            , url = C.DO_NOTHING_URL
            , mode = C.ROOT_MANAGE_DOWNLOADS
            , iconimage=C.downloads_icon
            , Folder=True
            )
        utils.addDir(
            name='[COLOR {}]WC Settings[/COLOR]'.format(C.refresh_text_color)
            ,url = C.DO_NOTHING_URL
            ,mode = C.CONFIGURE_THIS_ADDON
            ,iconimage=C.settings_icon
            ,Folder=False
            )

        utils.endOfDirectory(
             succeeded=True,  #when true, a refresh will list this
##           succeeded=False,  #when false, nothing will be shown
            )

    #end with threading.lock()

#__________________________________________________________________________
# display long-scene sites
@C.url_dispatcher.register(C.ROOT_INDEX_SCENES)
def INDEXS():
##    for friendly, root_url, mode, icon_filespec in utils.Get_Sites(C.LIST_AREA_SCENES):
    for module, main_mode_id, sitename in utils.Get_Sites(icon_function=True):

        if not module.LIST_AREA == C.LIST_AREA_SCENES:
            continue
        
        friendly = module.FRIENDLY_NAME
        root_url = module.ROOT_URL
        mode = module.MAIN_MODE
        icon_filespec = os.path.join(C.imgDir, sitename + '.png')

##        LogR(mode,C.LOGERROR)
        
        search_keyword_normalize = module.Search_Keyword_Normalize
        
        contextMenu = []

        u = sys.argv[0]
        u += '?bulk_operation=False'
        u += '&channel=' + str(int(mode)+C.MODE_SEARCH_OFFSET)
        u += '&end_directory=True'
        u += '&keyword='
        u += '&mode=' + C.QWIK_SEARCH
        u += '&page_end=1'
        u += '&page_start=1'
        u += '&section=None'
        u += '&url=None'
        contextMenu.append(
                (
                    "[COLOR {}]Q Search[/COLOR]".format(C.search_text_color)
                    , "ActivateWindow(Videos,{},return)".format(u)
                )
            )

        label = "[COLOR {}]Search for[/COLOR] '{}'".format(
            C.search_text_color
            , C.this_addon.getSetting(id='quick_search_string')
            )
        
        u = sys.argv[0]
        u += '?bulk_operation=False'
        u += '&channel=' + str(int(mode)+C.MODE_SEARCH_OFFSET)
        u += '&end_directory=True'
        u += '&keyword=' + search_keyword_normalize(C.this_addon.getSetting(id='quick_search_string'))
        u += '&mode=' + C.QWIK_SEARCH
        u += '&name='+label
        u += '&page_end=1'
        u += '&page_start=1'
        u += '&section=None'
        u += '&url=None'
        contextMenu.append(
                (
                    label
                    , "ActivateWindow(Videos,{},return)".format(u)
                )
            )
        
        utils.addDir(
            name=friendly
            ,url=root_url
            ,mode=mode
            ,iconimage=icon_filespec
            ,contextMenu=contextMenu
        )
        
    utils.endOfDirectory(
        cacheToDisc=False,
        succeeded=True,
        )
#__________________________________________________________________________
# display full movie sites
@C.url_dispatcher.register(C.ROOT_INDEX_MOVIES)
def INDEXM():
##    for friendly, root_url, mode, icon_filespec in utils.Get_Sites(C.LIST_AREA_MOVIES):

    for module, main_mode_id, sitename in utils.Get_Sites(icon_function=True):

        if not module.LIST_AREA == C.LIST_AREA_MOVIES:
            continue
        
        friendly = module.FRIENDLY_NAME
        root_url = module.ROOT_URL
        mode = module.MAIN_MODE
        icon_filespec = os.path.join(C.imgDir, sitename + '.png')

        if hasattr(module, 'Search_Keyword_Normalize'):
            search_keyword_normalize = module.Search_Keyword_Normalize
        else:
            def search_keyword_normalize(n):
                return n
        
        u = ( sys.argv[0] +
          "?url=" + quote_plus(str(root_url)) +
          "&name=" + quote_plus("[COLOR {}]Search[/COLOR]".format(C.search_text_color)) +    
          "&mode=" + str(int(mode)+C.MODE_SEARCH_OFFSET) +
          "&end_directory=True" +
          "&page_start=1&section=None&channel=None"
        )
        contextMenu = []
        contextMenu.append(
                (
                    "[COLOR {}]Search[/COLOR]".format(C.search_text_color)
                    #below does not work at all because the menu item does not have a 'folder' handle
                    #, "xbmc.RunPlugin({})".format(u)
                    #below will not work well because the 'back' button will return to root of addon, and not where I want
                    , "ActivateWindow(Videos,{},return)".format(u)
                )
            )        

        label = "[COLOR {}]Search for[/COLOR] '{}'".format(
            C.search_text_color
            , C.this_addon.getSetting(id='quick_search_string')
            )
        
        u = sys.argv[0]
        u += '?bulk_operation=False'
        u += '&channel=' + str(int(mode)+C.MODE_SEARCH_OFFSET)
        u += '&end_directory=True'
        u += '&keyword=' + search_keyword_normalize(C.this_addon.getSetting(id='quick_search_string'))
        u += '&mode=' + C.QWIK_SEARCH
        u += '&name='+label
        u += '&page_end=1'
        u += '&page_start=1'
        u += '&section=None'
        u += '&url=None'
        contextMenu.append(
                (
                    label
                    , "ActivateWindow(Videos,{},return)".format(u)
                )
            )
        
        utils.addDir(name=friendly
                     ,url=root_url
                     ,mode=mode
                     ,iconimage=icon_filespec
                     ,contextMenu=contextMenu
                     )
        
    utils.endOfDirectory(
        cacheToDisc=False,
        )
#__________________________________________________________________________
# display short-clip sites
@C.url_dispatcher.register(C.ROOT_INDEX_TUBES)
def INDEXT():
##    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(C.LIST_AREA_TUBES):


    for module, main_mode_id, sitename in utils.Get_Sites(icon_function=True):

        if not module.LIST_AREA == C.LIST_AREA_TUBES:
            continue
        
        friendly = module.FRIENDLY_NAME
        root_url = module.ROOT_URL
        mode = module.MAIN_MODE
        icon_filespec = os.path.join(C.imgDir, sitename + '.png')
        
        if hasattr(module, 'Search_Keyword_Normalize'):
            search_keyword_normalize = module.Search_Keyword_Normalize
        else:
            def search_keyword_normalize(n):
                return n
        
        u = ( sys.argv[0] +
          "?url=" + quote_plus(str(root_url)) +
          "&name=" + quote_plus("[COLOR {}]Search[/COLOR]".format(C.search_text_color)) +    
          "&mode=" + str(int(mode)+C.MODE_SEARCH_OFFSET) +
          "&end_directory=True" +
          "&page_start=1&section=None&channel=None"
        )
        contextMenu = []
        contextMenu.append(
                (
                    "[COLOR {}]Search[/COLOR]".format(C.search_text_color)
                    #below does not work at all because the menu item does not have a 'folder' handle
                    #, "xbmc.RunPlugin({})".format(u)
                    #below will not work well because the 'back' button will return to root of addon, and not where I want
                    , "ActivateWindow(Videos,{},return)".format(u)
                )
            )

        label = "[COLOR {}]Search for[/COLOR] '{}'".format(
            C.search_text_color
            , C.this_addon.getSetting(id='quick_search_string')
            )
        
        u = sys.argv[0]
        u += '?bulk_operation=False'
        u += '&channel=' + str(int(mode)+C.MODE_SEARCH_OFFSET)
        u += '&end_directory=True'
        u += '&keyword=' + search_keyword_normalize(C.this_addon.getSetting(id='quick_search_string'))
        u += '&mode=' + C.QWIK_SEARCH
        u += '&name='+label
        u += '&page_end=1'
        u += '&page_start=1'
        u += '&section=None'
        u += '&url=None'
        contextMenu.append(
                (
                    label
                    , "ActivateWindow(Videos,{},return)".format(u)
                )
            )
        
        utils.addDir(name=friendly
                     ,url=root_url
                     ,mode=mode
                     ,iconimage=icon_filespec
                     ,contextMenu=contextMenu
                     )
##        break

    utils.endOfDirectory(
        cacheToDisc=False,
        succeeded=True,
        )
#__________________________________________________________________________
# display webcam sites
@C.url_dispatcher.register(C.ROOT_INDEX_CAMS)
def INDEXW():
    for friendly, root_url, mode, icon_filespec in utils.Get_Sites(C.LIST_AREA_CAMS):
        utils.addDir(
            name=friendly
            ,url=root_url
            ,mode=mode
            ,iconimage=icon_filespec
            )

    utils.endOfDirectory(
        cacheToDisc=False,
        )
#__________________________________________________________________________
# display hentai sites
@C.url_dispatcher.register(C.ROOT_INDEX_HENTAI)
def INDEXH():
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_HENTAI):
        utils.addDir(
            name=friendly
            ,url=root_url
            ,mode=mode
            ,iconimage=icon_filespec
            )
    utils.endOfDirectory(
        succeeded=True,
        cacheToDisc=False,
        )
#__________________________________________________________________________
# display first page of some sites
@C.url_dispatcher.register(C.ROOT_FRONT_PAGE, [], ['page_start','keyword'])
def Front_Page(page_start=1,keyword=None):
    #temporarilty force only X recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 0

    get_sites = utils.Get_Sites()
    q = Queue.Queue()
    i = 0
    all_method_results = {}
    progress_dialog = None
    progress_dialog = utils.Progress_Dialog(C.addon_name,"front pages...")

    try:
        for sitename, module in get_sites:

##            if i > 2: break #testing
            if module.FRONT_PAGE_CANDIDATE == True:
##                Log(sitename)
                if utils.get_setting(sitename + '_on_front_page'):
##                    Log('3')
##                    i = i + 1 #testing
                    all_method_results[sitename] = None
                    method_to_call = getattr(module, 'List')
                    kwargs = {
                        "url": module.URL_RECENT
                        ,"end_directory": False
                        ,"bulk_operation": True
                        ,"page_start": module.FIRST_PAGE
                        ,"page_end": module.FIRST_PAGE
                        ,"progress_dialog": progress_dialog
                        }
                    q.put((sitename,method_to_call,kwargs))

        for k in range(C.MAX_WEBCRAWLER_THREADS):
            worker = threading.Thread(target=utils.crawl, args=(q,all_method_results))
            worker.daemon = False
            worker.start()
        q.join()
        get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
    except StopIteration:
        pass
    except:
        traceback.print_exc()

    at_least_one = False
    for result in all_method_results:
        if all_method_results[result] in [None, True]:
            at_least_one = True
            break
            
    if not at_least_one:
        utils.addDir(
            name='[COLOR {}]Add Sites to this via Settings[/COLOR]'.format(
                C.refresh_text_color
                )
            ,url=C.DO_NOTHING_URL
            ,iconimage=C.search_icon
            ,mode=C.ROOT_INDEX_INDEX
            ,Folder=False
            )

    if progress_dialog: progress_dialog.close()

    set_default_view = {
        "path": sys.argv[0] + sys.argv[2]
        ,"viewmode"      : C.INITIAL_VIEWMODE 
        }
    utils.endOfDirectory(
        set_default_view=set_default_view,
        succeeded=True,
        updateListing=False,
        cacheToDisc=True,
        )

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_DOWNLOAD_FOLDER, ['url'])
def OpenDownloadFolder(url):
    try:
##        Log(url,C.LOGERROR)
        xbmc.executebuiltin('Dialog.Close(busydialog)')
        xbmc.executebuiltin("ActivateWindow(Videos,{},return)".format(url))
    except:
        #traceback.print_exc()
        raise
#__________________________________________________________________________
# edit settings.xml file as necessary
def Dynamic_Front_Pages_Options():
    try:
        settings_file = os.path.join(C.rootDir, 'resources', "settings.xml")

        tree = ET.ElementTree(file=settings_file)

        font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
        if len(font_pages_element_tree) < 1:
            ET.SubElement(tree.find("."), 'category', {'label':"Front Pages"} )

        font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
        if len(font_pages_element_tree) < 1:
            raise Exception('setting was not found in file')

        for elem in font_pages_element_tree: #there should only be one...but doing loop anyway
            elem.clear() #delete existing items and then rebuild 
            elem.attrib['label'] = "Front Pages" #put back the label
          
            for sitename, module in utils.Get_Sites():
                try:
                    if hasattr(module,"website"):   # experimental; use a class for all websites
                        module = module.website
                except:
                    traceback.print_exc()
                    pass
                if 'FRONT_PAGE_CANDIDATE' in dir(module):
                    if module.FRONT_PAGE_CANDIDATE == True:
                        ET.SubElement(elem, 'setting' , {'id':sitename + '_on_front_page' ,'label':sitename + '_on_front_page' ,'default':'false' ,'type':'bool'})

        if platform.system() == 'Windows':
            free_bytes = ctypes.c_ulonglong(0)
            ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(C.rootDir), None, None, ctypes.pointer(free_bytes))
            get_free_space_mb = free_bytes.value / 1024.0 / 1024.0
        else:
            st = os.statvfs(settings_file)
            get_free_space_mb = st.f_bavail * st.f_frsize / 1024 / 1024

        if get_free_space_mb > 1:
            tree.write(settings_file)
        else:
            Log("Not enough disk space to update settings file '{}'".format(settings_file), C.LOGERROR)
    except:
        traceback.print_exc()
##    raise Exception()

#__________________________________________________________________________
#
def main(argv=None):
    try:
        if sys.argv: argv = sys.argv
        queries = utils.parse_query(sys.argv[2])
##        Log('a',C.LOGWARNING)
        mode = queries.get('mode', C.ROOT_INDEX_INDEX)
##        Log('B',C.LOGWARNING)
        Dynamic_Front_Pages_Options()
##        Log('C',C.LOGWARNING)
        C.url_dispatcher.dispatch(mode, queries)
##        Log('D',C.LOGWARNING)
    except ValueError:
##        LogR(queries, C.LOGERROR)
        utils.notify(
            header=u"Error: unregistered mode '{}'".format(mode)
            ,msg=u"for '{}'".format(queries.get('name'))
            ,duration = 7000
            )
    except:
        traceback.print_exc()
        LogR(locals())
    if C.DEBUG: utils.LogFlush()
#__________________________________________________________________________
#
##xmbc.log('error',C.LOGERROR)
if __name__ == '__main__':
    
    Log("\n\n\n"+repr(sys.argv), C.LOGINFO)
    threading.current_thread().name = "MainThread"
    rc = main()
    #clean up warning messages in kodi_ver22
##    LogR(dir(C.this_addon),C.LOGERROR)
##    LogR(dir(C.dialog),C.LOGERROR)
    
    C.this_addon = None
    C.dialog = None
    utils.monitor = None
    del C.this_addon
    del C.dialog
    del utils.monitor

    sys.exit(rc)
#__________________________________________________________________________
#
