#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from collections import OrderedDict
import mysql.connector as mariadb
import os
import re
import sqlite3
import traceback

import constants as C

import utils
from utils import Log,LogR
from utils import get_setting as GetSetting

###__________________________________________________________________
### allow mysql v1.xx to return dictionary style info
### https://stackoverflow.com/questions/22769873/python-mysql-connector-dictcursor
class MySQLCursorDict(mariadb.cursor.MySQLCursor):

    def _row_to_python(self, rowdata, desc=None):
        row = super(MySQLCursorDict, self)._row_to_python(rowdata, desc)
        if row:
            return dict(zip(self.column_names, row))
        return None

#__________________________________________________________________
#
class generic_favdbconn():

    db_filespec = ""
    #for mysql/mariadb/sqlite3 interop
    server_host = db_filespec 
    server_port = 0
    unread_result = False
    internal_connection = None
    internal_connection_mariadb = None
    internal_connection_sqlite3 = None


#__________________________________________________________________
#    
    def __exit__(self, *args, **kwargs):
        if self.internal_connection:
            self.internal_connection.close()
    def __enter__(self, *args, **kwargs):
##        LogR((self, args, kwargs))
        return self
        pass

#__________________________________________________________________
#    
    def __init__(self, *args, **kwargs):

##        LogR((
##            C.module_name()
##            , str(traceback.extract_stack(limit=2)[0][0])+":"
##              +str(traceback.extract_stack(limit=2)[0][1])
##            , locals()
##            )
##            ,stacklevel=3
##            )

        
        if len(args) == 1:
            kwargs['database'] = args[0]

        if os.sep in kwargs['database']: #sqlite3 requested
            self.db_filespec = kwargs['database']
##            Log(self.db_filespec)
            self.internal_connection = sqlite3.connect(self.db_filespec)
            self.internal_connection.row_factory = sqlite3.Row
##            Log("warning: sqlite3 client version:{}".format(sqlite3.version_info),C.LOGINFO)
            LogR((
                "info: sqlite3 client version:"
                , sqlite3.sqlite_version
                , str(traceback.extract_stack(limit=2)[0][0])+":"
                  +str(traceback.extract_stack(limit=2)[0][1])
                )
##                ,C.LOGINFO
                ,stacklevel=3
                )

            self.internal_connection_mariadb = False
            self.internal_connection_sqlite3 = True

        elif kwargs['database']: #mariadb
            conn_params= {
                "user"      : C.maria_db_userid
                ,"password" : C.maria_db_password
                ,"host"     : C.maria_db_server
                ,"database" : kwargs['database'] #default "kodi_favorites"
                ,"port"     : C.maria_db_port
#          https://dev.mysql.com/doc/refman/8.4/en/server-system-variables.html
                ,"connect_timeout": 10
##                ,"connection_timeout": 120

            };
            LogR(conn_params)
##            self.db_filespec = "{}:{}".format(conn_params['host'],conn_params['port'])
            self.db_filespec = kwargs['database']
            self.internal_connection = mariadb.connect(**conn_params);
##            Log("warning: mariadb client version:{}".format(
##                mariadb.__version_info__),C.LOGINFO)
##            LogR((
##                "info: mariadb client version:"
##                , mariadb.__version_info__
##                , str(traceback.extract_stack(limit=2)[0][0])+":"
##                  +str(traceback.extract_stack(limit=2)[0][1])
##                )
####                ,C.LOGINFO
##                ,stacklevel=3
##                )


    
            if C.PY3:
                temp_cursor = self.internal_connection.cursor(dictionary=True)
            else:
                temp_cursor = self.internal_connection.cursor(
                    cursor_class=MySQLCursorDict
                    )
                
            temp_cursor.execute('SELECT VERSION();')
            Log("info: mariadb server version:{}".format(
                    temp_cursor.fetchone()['VERSION()']
                ),
                C.LOGINFO,
                )
#      https://dev.mysql.com/doc/refman/8.4/en/server-system-variables.html
##            temp_cursor.execute('SET SESSION innodb_lock_wait_timeout = 120;')
##            temp_cursor.execute('SET SESSION lock_wait_timeout = 120;')
##            temp_cursor.execute('SET SESSION wait_timeout = 120;')

            temp_cursor.close()
            temp_cursor = None
            Log('info: max_allowed_packet must be increased on mariadb/mysql server side in order to save large binary bitmaps')
            self.internal_connection_mariadb = True
            self.internal_connection_sqlite3 = False
        else:
##            pass
            raise NotImplementedError(C.module_name(), "invalid/missing paramater value database")

##        if C.PY2: super(my_sqlite3conn, self).__init__(*args, **kwargs)
##        if C.PY3: super().__init__(*args, **kwargs)


#__________________________________________________________________
#
    #insert into table if key does not exist
    #update if key exists
    #return updated column names on update
    #
    #implemented as separate statements to support multiple db types
    def upsert(self
           ,table
           ,key_column
           ,key_value
           ,columns  #tuple
           ,values   #tuple
           ,forced_log = False
           ,prevent_update_on_duplicate = True
           ,columns_not_checked_for_duplicates = (
               u" `lasthashcheck` "
               ,u" `date_modified` "
               ) #tuple
        ):
        #table
        #columns
        #values
        #key_column, key_value

##        LogR(key_value, include_type=True)
##        LogR(key_value, include_type=True)
        key_value = self.sanitize_value_for_sql(key_value)
##        LogR(key_value, include_type=True)
        
        for v in ((table, key_column) + columns):
            v_safe = self.sanitize_value_for_sql(v)
            if  v_safe != v:
                raise Exception(u"invalid table/key ".format(repr(v)))
            if not v.startswith(u" `"):
                raise Exception(u" {} must start with ' `'".format(repr(v)))
            if not v.endswith(u"` "):
                raise Exception(u" {} must   end with '` '".format(repr(v)))
        for v in columns:
            v_safe = self.sanitize_value_for_sql(v)
            if  v_safe != v:
                raise Exception(u"invalid column ".format(repr(v)))
            if not v.startswith(u" `"):
                raise Exception(u" {} must start with ' `'".format(repr(v)))
            if not v.endswith(u"` "):
                raise Exception(u" {} must   end with '` '".format(repr(v)))
            
        for v in (values + (key_column,)):
##            LogR(v_safe, include_type=True)
            v_safe = self.sanitize_value_for_sql(v)
##            LogR(v_safe, include_type=True)
            if  v_safe != v:
                raise Exception(u"invalid value ".format(repr(v)))


        
        query = u"select * from {} where {} = {} "
        query = query.format(table,key_column,key_value)
##        if forced_log: LogR(query, C.LOGNONE)
        result = self.execute(query,forced_log=forced_log).fetchall()



        if len(result) < 1:
            #we need an insert
            existing = {}
            query = u"\n"
            query += u"insert into {} (".format(table)
            for c in columns:
                query += u" {} ,".format(c)
           
            if C.PY3:
                query = query.removesuffix(u",")
            else:
                if query.endswith(u","):
                    query = query[0:-len(u",")]
                            
            query += u") values ("
            for v in values:
                query += u" {} ,".format(v)
##            query = query.removesuffix(u",")
            if C.PY3:
                query = query.removesuffix(u",")
            else:
                if query.endswith(u","):
                    query = query[0:-len(u",")]
            query += u");"
            result = self.execute(query,forced_log=forced_log)
            if key_column not in columns:
                columns += (u"{}".format(key_column),)
            changed_columns = list()
            for c in columns:
                changed_columns.append(c.strip())
            changed_columns = ",".join(changed_columns)

        else:

            #
            # build an update query
            #
            existing = dict(result[0])
            query = u"\n"
            query += u" update {} ".format(table)
            query += u" set "
            i = 0
            for c in columns:
                query += u" {} = {} ,".format(c,values[i])
                i+=1
            if C.PY3:
                query = query.removesuffix(u",")
            else:
                if query.endswith(u","):
                    query = query[0:-len(u",")]            

            #
            # this is how we know what to update
            #
            query += u" where {} = {} ".format(key_column,key_value)


            #
            # prevent updating duplicate information
            #
            columns_checked_for_duplicates = ()
            for c in columns:
##                Log(c)
                if c not in columns_not_checked_for_duplicates:
                    columns_checked_for_duplicates += (c,)
##            LogR(columns_checked_for_duplicates)
            if prevent_update_on_duplicate and len(columns_checked_for_duplicates):
                q  = u" AND NOT EXISTS ( "
                q += u"    SELECT * FROM {} WHERE ".format(table)
                i = 0
                for c in columns:
##                    LogR(c)
                    if c in columns_checked_for_duplicates:
                        q += u" {} = {} AND ".format(c,values[i])
                        i+=1
                q = q.rstrip(u" AND ")
                q += u" ) "
##                LogR(q)
                query += q


            #
            # the actual query happens
            #
##            LogR(query)
##            try:
            result = self.execute(
                query,
                forced_log=forced_log,
                )
##            except Exception as ex:
##                LogR(ex, C.LOGNONE)
##                LogR(traceback.format_exc(),C.LOGWARNING)
##                raise
        

            #
            #find out what has changed via update
            #
            query = u"select * from {} where {} = {} "
            query = query.format(table,key_column,key_value)
            result = self.execute(
                query,
##                forced_log=True,
                ).fetchall()
            try:
                new_values  = dict(result[0])
            except:
                LogR(traceback.format_exc(),C.LOGWARNING)
                LogR(query, C.LOGINFO)
                LogR(result, C.LOGINFO)
                raise
            changed_columns = tuple()
            for c in new_values.keys():
                if new_values[c] != existing[c]:
                    if c == 'binary_image':
                        LogR((c, '<binary_image>' ,'-->', '<binary_image>'))
                    else:
                        LogR((c, existing[c],'-->', new_values[c]))
                    changed_columns += ("`"+c.strip()+"`",)
##            LogR(changed_columns)

##        self.commit()
        return changed_columns

#__________________________________________________________________
#
    #create a new cursor that has executed the query
    #return the cursor
    def executemany(self, query
                , params=None
                , dictionary=True
                , prepared=True
                , stacklevel=3 #line that called this function
                ):
        if not params:
            params = ()
        internal_exception = None
        result = None
        
        query = self.Convert_SQLITE3_MARIADB(query)

        try:
            if self.internal_connection_mariadb:

                if C.PY3:
                    new_cursor = self.internal_connection.cursor(
                        dictionary=dictionary,
                        prepared=prepared,
                        )
                else:
                    new_cursor = self.internal_connection.cursor(
                        cursor_class=MySQLCursorDict,
                        prepared=prepared,
                        )
                
                result = new_cursor.executemany(query, params) 
                result = new_cursor

            if self.internal_connection_sqlite3:
                result = self.internal_connection.executemany(query, params) 

        except Exception as ex:
            internal_exception = ex
            #throw exeption this after logging
        finally:
            pass
        
        

        #try to trim out 'binary_image' data for default log as it is too big
        try:
            logging_data = OrderedDict(params) 
            if 'binary_image' in logging_data:
                logging_data['binary_image']='<replaced for logging>'
##            Log('OrderedDict(params)')
        except:
            try:
                if C.DEBUG:
                    s = query.split(',')
                    binary_image_position = None
                    k = 0
                    for i in s:
                        if "`binary_image`" in i:
                            binary_image_position = k
                            break
                        k = k + 1
                    values_position = None
                    k = 0
                    for i in s:
                        if 'VALUES' in i:
                            values_position = k
                            break
                        k = k + 1
                    if binary_image_position and values_position:
                        params = list(params)
                        params[binary_image_position] = '<binary_image replaced for logging>'
                logging_data = params
##                Log('Ordloop ms)')
            except:
                traceback.print_exc()
                logging_data = params
                raise

##        #see exact query during debugging
##        if type(params) == list:
##            for i in params:
##                Log(query.replace("?", "'{}'").format(
##                    *tuple(i)
##                    )
##                    , stacklevel=stacklevel # =3 get the line that called this
##                    )
##        else:
##            Log(query.replace("?", "'{}'").format(
##                *tuple(logging_data)
##                )
##                , stacklevel=stacklevel # =3 get the line that called this
##                )
            
        if internal_exception:
            if C.PY2:
                if len(internal_exception.args) < 1:
                    internal_exception.args = (internal_exception.msg,internal_exception.msg)
##                    LogR(internal_exception,C.LOGNONE)
            raise internal_exception

        LogR(('changed=',result.rowcount))
        
        return result
    #__________________________________________________________________
    #
    #create a new cursor that has executed the query
    #return the cursor
    #
    def execute(
        self,
        query,
        params=None,
        dictionary=True,
        prepared=True,
        multi=False,
        stacklevel=3, #  3 line that called this function
        forced_log = False,
        ):
        
##        LogR(
##                (
##                C.module_name()
##                , str(traceback.extract_stack(limit=2)[0][0])+":"+str(traceback.extract_stack(limit=2)[0][1])
##                , locals()
##                ),
##                C.LOGWARNING, 
##            )
    
        if not params:
            params = list()
        internal_exception = None
        result = None

        try:
            query = self.Convert_SQLITE3_MARIADB(query)
            
            if self.internal_connection_mariadb:
                if multi:
                    prepared = False   #prepared will not work with multi
                
##                new_cursor = self.internal_connection.cursor(
##                    dictionary=dictionary
##                    , prepared=prepared
##                    )
                if C.PY3:
                    new_cursor = self.internal_connection.cursor(
                        dictionary=dictionary,
                        prepared=prepared,
                        )
                else:
                    #hacks for older mariadb
                    new_cursor = self.internal_connection.cursor(
                        cursor_class=MySQLCursorDict,
                        prepared=prepared,
                        )
                    if type(params) is list:
                        if len(params) == 0:
                            params = None #hack for older mariadb
                    
                    #query = query.replace("?", "%s") #does not allow ? 
                            

##                query = " (SELECT 1 FROM `favorites_meta` WHERE `UUID` LIKE '%'  ) "

                if multi:
                    # https://dev.mysql.com/doc/connector-python/en/connector-python-api-mysqlcursor-execute.html
                    #Before Connector/Python 9.2.0, execute() accepted a multi
                    #  option and returned an iterator if set to True. That
                    #  option was removed in 9.2.0, and Section 9.3,
                    #  “Executing Multiple Statements” was added. 
                    for i in new_cursor.execute(query, params, multi=True):
##                        LogR(i)
                        pass
                else:
                    result = new_cursor.execute(query, params)
                    
                result = new_cursor

            if self.internal_connection_sqlite3:
##                LogR(query)
                if multi:
                    result = self.internal_connection.executescript(query)
                else:
                    new_cursor = self.internal_connection.cursor()
                    result = new_cursor.execute(query, params)

        except Exception as ex:
##            Log('warning:hardcode')
##            traceback.print_exc()
##            LogR(type(ex))
            internal_exception = ex
            #LogR(traceback.format_exc(),C.LOGWARNING)
            #we will throw exeption this after logging
        finally:
##            LogR(result)
            pass

##        forced_log = True; Log('warning hardcode for times when we DO want to see this');
        #avoid this logging by default because it isuallay schema create
        if forced_log: # or multi==False:
            try:
                if params and len(params) > 0:
                    #try to trim out 'binary_image' data for default log as it is too big
                    query_without_binary = query.replace("?", "'{}'").format(*tuple(params))
                    query_without_binary = re.sub( r"(?:'/9j/.+?'|'UklG.+?')" , "<binary_image>", query_without_binary)
                else:                
                    query_without_binary = re.sub( r"(?:'/9j/.+?'|'UklG.+?')" , "<binary_image>", query)
                Log(
                    query_without_binary,
                    stacklevel=stacklevel+1,
                    loglevel=C.LOGINFO,
                    )
            except:
                LogR(
                    (query,params),
                    loglevel=C.LOGWARNING,
                    stacklevel=stacklevel+1,
                    )
                raise
                
        if result:
            if not query.lower().lstrip('\n').lstrip().startswith("select") and \
               not query.lower().lstrip('\n').lstrip().startswith("create") :
                LogR(('changed=',result.rowcount), stacklevel=3)
            
        if internal_exception:
            if C.PY2:
                if len(internal_exception.args) < 1:
                    internal_exception.args = (internal_exception.msg,internal_exception.msg)
##                    LogR(internal_exception,C.LOGNONE)
            raise internal_exception
        
        if multi:
            self.internal_connection.commit()

        return result
    #__________________________________________________________________
    #
    def Convert_SQLITE3_MARIADB(self, q): #, connection=None):
##        Log(q)
        #convert from sqlite3 to mariadb
        if self.internal_connection_mariadb:
            q = q.replace("EXPLAIN QUERY PLAN", "EXPLAIN")
            q = q.replace("BEGIN TRANSACTION", "START TRANSACTION")
            q = q.replace(" AUTOINCREMENT ", " AUTO_INCREMENT ")
            q = q.replace(" random()", " RAND()")  #case sensitive for now
            ##    UTC is returned by  UNIX_TIMESTAMP() unixepoch() and CAST(strftime('%s') as INT)
            q = q.replace(" unixepoch() ", " UNIX_TIMESTAMP() ")
            q = q.replace(" CAST(strftime('%s') as INT) ", " UNIX_TIMESTAMP() ") #older sqlite3
        #convert from mariadb to sqlite3
        if self.internal_connection_sqlite3:
            q = q.replace(" FROM DUAL ", " ")
##            q = q.replace(" UNIX_TIMESTAMP() ", " unixepoch() " )
            q = q.replace(" UNIX_TIMESTAMP() ", " CAST(strftime('%s') as INT) ") #older sqlite3
            q = q.replace(" AUTO_INCREMENT ", " AUTOINCREMENT ")
##        Log(q)    
            
        return q
    #__________________________________________________________________
    #
    def commit(self):
        self.internal_connection.commit()
    #__________________________________________________________________
    #
    def close(self):
        self.internal_connection.close()
    #__________________________________________________________________
    #
    def cursor(self):
        return self.internal_connection.cursor()
    #__________________________________________________________________________
    #
    def sanitize_value_for_sql(self,information):
        #Return True if the string statement appears to contain one or
        #  more complete SQL statements. No syntactic verification or
        #  parsing of any kind is performed, other than checking that
        #  there are no unclosed string literals and the statement is
        #  terminated by a semicolon.

##        if C.PY2:
####            LogR(information, include_type=True)
##            if type(information) is unicode:
####                LogR(information, include_type=True)
##                information = str(information)
####                LogR(information, include_type=True)

        if not C.PY2:
            if information:
                try:
                    if sqlite3.complete_statement(information):
                        raise sqlite3.IntegrityError
                except:
                    LogR(information,include_type=True)
                    raise

##        LogR(information, include_type=True)            
        return information

#__________________________________________________________________
# end of file
