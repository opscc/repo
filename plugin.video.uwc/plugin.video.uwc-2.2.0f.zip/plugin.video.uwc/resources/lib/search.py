#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import mysql.connector as mariadb #needed for error handling
import sqlite3                    #needed for error handling

import os # used to delete old,spearate keyword database file
import threading
import traceback
from uuid import uuid4
import xbmc
#import internal addon libraries
import utils
import constants as C
import queries as Q
#define frequenctly used aliases
from utils import Log,LogR
from constants import Queue
from constants import unquote_plus

from fav_dbconn    import generic_favdbconn

KEYWORD_DB_VERSION_1 = 1
KEYWORD_DB_VERSION_2 = 2
KEYWORD_DB_VERSION_3 = 3
KEYWORD_DB_VERSION_5 = 5
KEYWORD_DB_VERSION_CURRENT = KEYWORD_DB_VERSION_5

#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
##        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ADD_KEYWORD, ['channel'])
def NewSearchKeyword(channel):
    LogR((__name__,locals()))
##    Log("NewSearchKeyword channel='{}'".format( channel))

    Log("NewSearchKeyword channel='{}'".format( channel))
    vq = _get_keyboard(heading="Searching for...")
    if (not vq):
        return False, 0
    keyword = utils.quote_plus(vq)
##    Log('todo, uncomment above',C.LOGWARNING)
##    keyword = 'maya'
    AddKeyword(keyword)
    C.this_addon.setSetting(
        id='quick_search_string',
        value=keyword,
        )

    if channel:
        Quick_Search(
            url=C.DO_NOTHING_URL
            ,channel = channel
            ,keyword=keyword
            ,bulk_operation=False
            )
        utils.endOfDirectory(
            cacheToDisc=True,
            )

    #2025-07 currently endOfDirectory error message because I want folder-like
        # xbmc dir stuff when adding keyword+channel<>null
        # but xbmc item stuff when channel==null

#__________________________________________________________________
#
def Get_DB_PRAGMA_version(db_connection):
    result = None
    try:
        sql_command = Q.GET_DB_USER_VERSION(db_connection)
        params = ()
        db_cursor = db_connection.execute(sql_command,params)
        for a in db_cursor.fetchall():
            result = a['user_version']
    except Exception as ex:
        if 'no such table: favorites_meta' not in repr(ex):
            LogR(traceback.format_exc(),C.LOGWARNING)
        Log('missing GET_DB_USER_VERSION table.  Schema upgrade will be triggered')
        result = KEYWORD_DB_VERSION_2 #KEYWORD_DB_VERSION must trigger upgrade
    return result

#__________________________________________________________________
#
def Get_DB_PRAGMA_filename(db_conn):
    try:
        sql_command = 'SELECT file FROM pragma_database_list;'
        Log("sql_command='{}'".format(sql_command) )
        id_column_count =  db_conn.execute( sql_command )
        for a in id_column_count:
            return a[0]
    except Exception as ex:
        LogR(traceback.format_exc(),C.LOGERROR)
        raise
    
#__________________________________________________________________________
#
def Create_Keyword_Table(db_connection):

    try:
        sql_command = Q.KEYWORD_SCHEMA_STRING(
            KEYWORD_DB_VERSION_CURRENT,
            None,
            )
        params = ()
        db_connection.execute(
            sql_command,
            params,
            prepared=False,
            multi=True
            )
    except mariadb.InternalError as ex:
        utils.Notify(
            header="db error"
            , msg="{} {}".format(
                e.args[0], db_connection.db_filespec)
            , duration=10000
            )
        raise

    except AttributeError as e:
        raise

    except sqlite3.OperationalError as ex:
        utils.Notify(header="db error", msg="{} {}".format(
            ex.args[0], db_connection.db_filespec), duration=10000 )
        raise

    except Exception as ex:
##        LogR(ex,C.LOGERROR)
        LogR(traceback.format_exc(),C.LOGWARNING)
##        traceback.print_exc()
        raise
#__________________________________________________________________________
#
def Validate_Keyword_Table(db_connection):

    try:
        sql_command = Q.LIST_KEYWORD(
            KEYWORD_DB_VERSION_CURRENT,
            )
        params = ()
        db_connection.execute(
            sql_command,
            params,
            prepared=False,
            multi=True
            )
        return True
    except Exception as ex:
        LogR(traceback.format_exc(),C.LOGWARNING)
        raise
##        traceback.print_exc()
##        raise

#__________________________________________________________________________
#
def Upgrade_Keyword_Table(
            new_db_conn,
            new_v,
            old_v,
    ):

    try:
        sql_command = Q.UPGRADE_KEYWORD_TABLE(
            new_v,
            old_v,
            new_db_conn,
            )
        params = ()
        new_db_conn.execute(
            sql_command,
            params,
            prepared=True,
            multi=True,
##            forced_log=True,
            )
        return True
    except Exception as ex:
        LogR(traceback.format_exc(),C.LOGWARNING)
        raise

    
#__________________________________________________________________________
#
def Internal_Upsert(cur_data, new_db_conn):

    q = Q.UPSERT_SEARCHTERM(
            KEYWORD_DB_VERSION_CURRENT
            ,cur_data['keyword']
            ,cur_data['sequence']
            ,cur_data['uuid']
            ,cur_data['date_modified']
            ,cur_data['is_deleted']
        )

##    LogR(q, C.LOGWARNING)
##    Log(q, C.LOGWARNING)

    try:
        list_of_changed_columns = list()
        list_of_changed_columns = new_db_conn.upsert(
             q["table"]
            ,q["key_name"]
            ,q["key_value"]
            ,q["column_tuple"]
            ,q["value_tuple"]
            ,forced_log=True
            )
        LogR(list_of_changed_columns,C.LOGNONE)
        
        return (len(list_of_changed_columns) > 0) ; #total_changes += 1

    except sqlite3.IntegrityError as e:
        if 'duplicate information' in e.args:
            LogR(('no update', cur_data['keyword'],cur_data['uuid']))
##            continue
        if 'UNIQUE constraint failed: keywords.keyword' in e.args:
            LogR(('no update', cur_data['keyword'],cur_data['uuid']))
##            continue
        else:
            raise
    except mariadb.DatabaseError as e:
        if 'duplicate information' in e.args[1] : 
            #  LogR(('no update', cid, cur_data['name'],cur_data['uuid']))
##            continue
            pass
        if 'UNIQUE constraint failed: keywords.keyword' in e.args:
            LogR(('no update', cur_data['keyword'],cur_data['uuid']))
##            continue
        elif 'invalid date_modified' in e.args[1] : 
            # data is different, but older
            LogR(('no update - newer record on target', cid, cur_data['keyword'],cur_data['uuid']))
##            continue
        else:
            LogR(e.args)
        raise
    except Exception as ex:
##        LogR(ex,C.LOGERROR)
        LogR(traceback.format_exc(),C.LOGWARNING)
##        traceback.print_exc()
        raise

    return 0
        

#__________________________________________________________________________
#
def Import_Export(new_db_conn):

    Log('todo:  tombstone old deleted items',C.LOGINFO)

    if os.path.exists(C.keywordsdb):
        old_db_conn = generic_favdbconn(database=C.keywordsdb)
    else:
        old_db_conn = new_db_conn

    # Note: we do this here because we have to move the data in the 
    #   separate database file into the new fle
    
    new_f = Get_DB_PRAGMA_filename(new_db_conn)
    if old_db_conn: old_f = Get_DB_PRAGMA_filename(old_db_conn)
    else: old_f = ''
    new_v = Get_DB_PRAGMA_version(new_db_conn)
    if old_db_conn: old_v = Get_DB_PRAGMA_version(old_db_conn)
    else: old_v = new_v
    
    LogR((new_f,old_f,new_v,old_v,),C.LOGINFO)

    max_rows = 1000

    Create_Keyword_Table(new_db_conn)
    try:
        Validate_Keyword_Table(new_db_conn)
        Log('success Create_Keyword_Table',C.LOGINFO)
    except:
        Upgrade_Keyword_Table(
            new_db_conn,
            new_v,
            old_v,
            )
        Log('success Upgrade_Keyword_Table',C.LOGINFO)
        
        
##    Log('warning',C.LOGINFO)

    #__________________________________________________________________________
    #
    def row_generator(db_connection, db_version):
        
        if not db_connection: return #sometimes there is no 'old' database

        # Note: we do this here because we have to move the data in the 
        #   separate database file into the new fle


        if False: #stub
            pass
        elif db_version in [KEYWORD_DB_VERSION_3, KEYWORD_DB_VERSION_3]:
            query = (
                " select `keyword` "
                " , `sequence`, `uuid`, `date_modified` "
                " , `is_deleted` from `keywords` "
                )
        elif db_version in [KEYWORD_DB_VERSION_2, KEYWORD_DB_VERSION_1]:
            query = (
                " select `keyword`, `sequence`"
                " , '' AS `uuid`, '' as `date_modified` "
                " , 0 as `is_deleted` from `keywords` "
            )
        else:
            raise NotImplementedError(C.module_name(), db_version) 


        params = ()
        try:
            db_cursor = db_connection.execute(
                query
                ,params
                ##,forced_log=True
                )
            for a in db_cursor.fetchmany(size=max_rows):
                yield(a)
        except sqlite3.OperationalError as ex:
            if ex.args[0] == 'no such table: keywords': 
                pass
            else:
                raise
        except Exception as ex:
            LogR(ex,C.LOGERROR)
            raise   
    #__________________________________________________________________________
    #

    total_changes = 0

    try:
        for cur_data in row_generator(old_db_conn, old_v):
            cur_data = dict(cur_data)
            if not cur_data['uuid']:
                cur_data['uuid'] = str(uuid4())
                
            total_changes += Internal_Upsert(cur_data, new_db_conn)

        LogR(('total_changes=', total_changes))
        new_db_conn.commit()

        if old_f:
            Log("deleting separate keyword database file '{}'".format(old_f))
            try:
                old_db_conn.close()
                os.remove(old_f)
            except  FileNotFoundError as ex:
                pass
        
    except Exception as ex:
        LogR(traceback.format_exc())#,C.LOGWARNING)
##        traceback.print_exc() #note: no sense to both raise and print_exc
##        raise   

    Log('Import_Export finished')
    
#__________________________________________________________________________
#
def AddKeyword(
    keyword,
    uuid='',
    ):

    Log("keyword add requested for '{}', '{}'".format(keyword,uuid), C.LOGNONE)

    try:

        favorites_db_conn = generic_favdbconn(database=C.favoritesdb)

        Import_Export(favorites_db_conn) #(new,old)

        cur_data = {}
        cur_data['keyword'] = keyword
        cur_data['sequence'] = 0
        cur_data['uuid'] = str(uuid4())
        cur_data['date_modified'] = None
        cur_data['is_deleted'] = 0

        total_changes = Internal_Upsert(cur_data, favorites_db_conn)
                
        favorites_db_conn.commit()
    
        utils.Notify(
            header=C.addon_name
            , msg="Keyword added '{}'".format(keyword)
            #, duration=10000
            )

    except Exception as ex:
##        LogR(ex,C.LOGERROR)
        LogR(traceback.format_exc(),C.LOGWARNING)
##        traceback.print_exc()
        raise        

#_______________________________________________________________________________
#
@C.url_dispatcher.register(C.DELETE_KEYWORD, ['keyword','uuid'] )
def Delete_Keyword(keyword, uuid):

    Log("keyword delete requested for '{}', '{}'".format(keyword,uuid), C.LOGNONE)

    try:
        keywords_db_conn  = generic_favdbconn(database=C.favoritesdb)

        Import_Export(keywords_db_conn)

        cur_data = {}
        cur_data['keyword'] = keyword
        cur_data['sequence'] = 0
        cur_data['uuid'] = uuid
        cur_data['date_modified'] = None
        cur_data['is_deleted'] = 1

        total_changes = Internal_Upsert(cur_data, keywords_db_conn)

        keywords_db_conn.commit()
        
        utils.Notify(
            header=C.addon_name
            , msg="Keyword deleted '{}'".format(keyword)
            , duration=10000
            )

        xbmc.executebuiltin('Container.Refresh')
        
    except Exception as ex:
##        LogR(ex,C.LOGERROR)
        LogR(traceback.format_exc(),C.LOGWARNING)
        #traceback.print_exc()
        raise

#_______________________________________________________________________________
#
@C.url_dispatcher.register(
    C.QWIK_SEARCH
    , ['url', 'bulk_operation', 'channel']
    , ['end_directory','page_start','page_end','keyword']
    )
def Quick_Search(
    url
    , bulk_operation
    , channel # = C.ROOT_SEARCH_ALL
    , end_directory=False
    , page_start='1'
    , page_end='1'
    , keyword=None
    ):
    LogR(locals())

    if not keyword:
        ##get the search string from user; remember it; pre-populate remembered
        prev_search_string = C.this_addon.getSetting(id='quick_search_string')
        quick_search_string = _get_keyboard(
            heading="Search query"
            ,default=prev_search_string
            )
        if quick_search_string == '' :
            ## if blank or the user cancelled the keyboard, return
            return False, 0  
        C.this_addon.setSetting(
            id='quick_search_string',
            value=quick_search_string,
            )
    else:
        quick_search_string = keyword


    progress_dialog = utils.Progress_Dialog(
        C.addon_name
        ,u"searching '{}'".format(quick_search_string)
        )

    worker_threads = []
    monitor = xbmc.Monitor()

    try:
            
##        if bulk_operation:
##            end_directory = False #this sub will set the directory

        get_sites = utils.Get_Sites()
        i = 0
        MAX_SEARCH_THREADS = 10
        LogR(len(worker_threads))
        for sitename, module in get_sites:
            if (str(channel) in [module.SEARCH_MODE, C.ROOT_SEARCH_ALL]):
##                Log(sitename)
                method_to_call = getattr(module, 'Search')
                kwargs = {
                    "searchUrl": module.SEARCH_URL
                    ,"bulk_operation": bulk_operation
                    ,"keyword": quick_search_string
                    ,"end_directory": False #end_directory
                    ,"page_start": page_start
                    ,"page_end": page_end
                    ,"progress_dialog": progress_dialog
                    }
                worker = threading.Thread(
                   name=sitename
                  ,target=method_to_call
                  ,kwargs=kwargs
                  )
                worker.daemon = True
                worker_threads.append(worker)
        LogR(len(worker_threads))

##        for i in range(0,len(worker_threads)):
##            LogR(worker_threads[i],C.LOGNONE)
##    
        while len(worker_threads) > 0:
##            LogR(len(worker_threads)
##                                         ,C.LOGNONE
##                        )
            
            for i in range(0,min(len(worker_threads),MAX_SEARCH_THREADS))  :
                worker = worker_threads[i]
                if not worker.ident:
                    Log(worker.name
                        ,C.LOGNONE
                        )                        
                    worker.start()
                    
            utils.Sleep(1000)

            for i in range(0,min(len(worker_threads),MAX_SEARCH_THREADS)):
##                LogR(i,C.LOGNONE)
##                LogR(len(worker_threads),C.LOGNONE)
                try:
                    worker = worker_threads[i]
                    still_working = True
                    if worker.is_alive():
                        Log(worker.name + " is alive"
                            ,C.LOGNONE
                            )
                        utils.Sleep(250)
                    elif worker.ident:
                        Log('removing '+ worker.name
                            ,C.LOGNONE
                            )
                        worker_threads.remove(worker)
                    else:
                        Log('no PID '+ worker.name
                            ,C.LOGNONE
                            )
                except IndexError:
                    pass
                        
##            max_time = 240 #seconds_to_wait_for_search
##            cur_time = 0
##            still_working = True
##            while still_working :
##                LogR(len(worker_threads))
##                if progress_dialog.iscanceled():
##                    Log("progress_dialog.iscanceled()", C.LOGWARNING)
##                    break #stop waiting
##
##                if cur_time > max_time:
##                    Log("cur_time > max_time", C.LOGWARNING)
##                    break #stop waiting
##                    
##                progress_dialog.increment_percent()
##                cur_time += 1
##                still_working = False
##                for i in range(0,min(len(worker_threads),5)):
##                    worker = worker_threads[i]
##                    still_working = True
##                    if worker.is_alive():
##                        Log(worker.name + "is alive")
##                        utils.Sleep(250)
##                    else:
##                        Log('removing '+ worker.name)
##                        worker_threads.remove(worker)
                        
##            get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
##                    
##        except StopIteration:
##            Log("StopIteration")
##            pass
##        except GeneratorExit:
##            Log("GeneratorExit")
##            pass
##        except:
##            traceback.print_exc()

    finally:
        try:
            for worker in worker_threads:
                if worker.isAlive():
                    Log("Warning: killed thread {}".format(repr(worker.name)))
                    worker._Thread__stop()
        except Exception as ex:
##            LogR(ex,C.LOGERROR)
            LogR(traceback.format_exc(),C.LOGWARNING)
##            traceback.print_exc()
##            raise   
                    
        if progress_dialog:
            if progress_dialog.iscanceled():
                utils.addDownLink(
                    name=C.STANDARD_MESSAGE_CANCELLED_SEARCH
                    ,url=C.DO_NOTHING_URL
                    ,duration = C.STANDARD_DURATION_REFRESH
                    ,mode=C.ROOT_INDEX_INDEX
                    )
            progress_dialog.close()
            progress_dialog = None
        if monitor:
            monitor = None

    Log("Quick_Search ended")
    utils.endOfDirectory(
        updateListing=False, #2025-07-24 changemind
        end_directory=end_directory,
        cacheToDisc=True,
        )
    Log("after endOfDirectory Quick_Search ended")

#__________________________________________________________________________
#
@C.url_dispatcher.register(
    C.ROOT_SEARCH_ALL
    , ['page_start']
    , ['page_end', 'keyword', 'end_directory']
    )
def Search_All(page_start=1, page_end=1, keyword=None, end_directory=True):

    if not keyword:
        Search_Dir(
            url=C.DO_NOTHING_URL
            , mode=C.ROOT_SEARCH_ALL
            , bulk_operation=True
            , end_directory=True
        )
        return
    
    #temporarilty force only  X   recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 2
    C.MAX_RECURSE_DEPTH = 2

    Quick_Search(
        url=C.DO_NOTHING_URL
        ,channel=C.ROOT_SEARCH_ALL
        ,keyword=keyword
        ,bulk_operation=True
        ,end_directory=False
        )

    utils.endOfDirectory(
        cacheToDisc=True,
        )
#__________________________________________________________________________
#
def Search_Dir(
    url
    , mode
    , bulk_operation
    , page_start='1'
    , page_end=None
    , end_directory=False
    ):

    try:
        label = "{}[COLOR {}]Quick Search[/COLOR]".format(
            C.SPACING_FOR_TOPMOST
            ,C.search_text_color
            ) 
        utils.addDir(
            name=label
            ,url=url
            ,channel=mode
            ,mode=C.QWIK_SEARCH 
            ,iconimage=C.search_icon 
            ,page_start=page_start
            ,page_end=page_end
            ,bulk_operation=bulk_operation
            ,end_directory=True
            )

        utils.addDir(
            "{}[COLOR {}]Add Keyword and Search[/COLOR]".format(
                C.SPACING_FOR_NEXT
                ,C.search_text_color
                )
            , url=''
            , mode=C.ADD_KEYWORD
            , channel=mode #(int(mode)//10*10)#each site is allocated 10 values
            , iconimage=C.search_icon
            )


        # create/upgrade keyword database if necessary
        db_connection = generic_favdbconn(database=C.favoritesdb)
        Import_Export(db_connection) #(new,old)

        try:
            query = Q.LIST_KEYWORD(KEYWORD_DB_VERSION_CURRENT)
            params = []
            db_cursor = db_connection.execute(query,params)
##            Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
            for keyword_info in db_connection.execute(query, params).fetchall():
                if C.PY2: keyword = unicode(keyword_info[0])
                if C.PY3: keyword = keyword_info[0]
                if C.PY2: keyword_uuid = unicode(keyword_info[1])
                if C.PY3: keyword_uuid = keyword_info[1]

                label = "{}[COLOR {}]{}[/COLOR]".format(
                    C.SPACING_FOR_NAMES
                    , C.time_text_color
                    , unquote_plus(keyword)
                    )
                utils.addDir(
                    name=label
                    , url=url 
                    , mode=mode
                    , iconimage=C.search_icon 
                    , page_start=page_start
                    , page_end=page_end
                    , keyword=keyword
                    , end_directory=True
                    , uuid=keyword_uuid
                    )
        except:
            raise
            
    except Exception as ex:
        LogR(traceback.format_exc(),C.LOGWARNING)
##        traceback.print_exc() #note: no sense to both raise and print_exc
        raise   

    utils.endOfDirectory(
        cacheToDisc=True,
        )
#__________________________________________________________________________
#
