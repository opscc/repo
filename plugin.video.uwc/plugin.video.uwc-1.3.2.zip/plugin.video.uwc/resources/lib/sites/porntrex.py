'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
import time

from resources.lib import utils
from random import randint

progress = utils.progress

BASE_SEARCH_URL="https://www.porntrex.com/search/?q={}&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q={}&category_ids=&sort_by=relevance&from_videos={}&from_albums={}&_={}"
START_PAGE = "https://www.porntrex.com/latest-updates/{}/"

@utils.url_dispatcher.register('50')    
def PTMain():
    utils.addDir("  [COLOR {}]Categories[/COLOR]".format(utils.search_text_color),'https://www.porntrex.com/categories/',53,'','')
    #utils.addDir('[COLOR hotpink]Search[/COLOR]','http://www.porntrex.com/search/',54,'','')

#https://www.porntrex.com/search/?q=alana+cruise
#&mode=async&function=get_block&block_id=list_videos_videos_list_search_result
#&q=alana+cruise&category_ids=&sort_by=post_date&from_videos=04&from_albums=04&_=1530472107737

    #PTList('http://www.porntrex.com/latest-updates/1/',1)
    PTList(START_PAGE.format('1'),1)
    
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('51', ['url'], ['page'])
def PTList(url, page=0, onelist=None):
    if onelist:
        url = url.replace('/1/','/'+str(page)+'/')

    utils.addDir("  [COLOR {}]Search[/COLOR]".format(utils.search_text_color),BASE_SEARCH_URL,54,'','')

    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None

    match = re.compile('class="video-item.*?href="([^"]+)" title="([^"]+)".*?original="([^"]+)"(.*?)clock-o"></i>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, name, img, hd, duration in match:
        name = utils.cleantext(name)
        if 'private' in hd:
            continue
        if hd.find('HD') > 0: hd = "[COLOR orange]HD[/COLOR]"
        else: hd = ""
        
        #name = "[COLOR {}]{}[/COLOR] {} {}".format(utils.time_text_color, duration,name,hd)
        name = " {}".format(name)
        if img.startswith('//'): img = 'http:' + img
        
        imgint = randint(1,10)
        newimg = str(imgint) + '.jpg'
        img = img.replace('1.jpg',newimg)
        utils.addDownLink(name, videopage, 52, img, '', duration=duration)


    if not onelist:
        matches = re.compile('<li class="next">', re.DOTALL | re.IGNORECASE).findall(listhtml)
        if matches:
            npage = page + 1
            if '/categories/' in url:
                url = url.replace('from='+str(page),'from='+str(npage))
            else:
                #maybe this was a search page
                matches = re.compile('class="next">.*?data-parameters="q:([^;]+);.*?from_videos\+from_albums:([^"]+)">Next', re.DOTALL | re.IGNORECASE).findall(listhtml)
                for search_criteria,page_num in matches:
                    search_criteria = search_criteria.replace('%20','+')
                    url=BASE_SEARCH_URL.format(search_criteria,search_criteria,page_num,page_num,int(time.time()))
                    utils.kodilog("Searching URL: " + url)

                #maybe this was a non-search page
                matches = re.compile('class="next"><a href="\/latest-updates\/([^\/]+)\/" data-action=', re.DOTALL | re.IGNORECASE).findall(listhtml)
                for page_num in matches:
                    url= START_PAGE.format(page_num)
                    utils.kodilog("Searching URL: " + url)

                utils.addDir("[COLOR {}]Next Page ({})[/COLOR]".format(utils.search_text_color, npage), url, 51, '', npage)

        utils.add_sort_method()
        xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('52', ['url', 'name'], ['download'])
def PTPlayvid(url, name, download=None):

    #progress.create('Play video', 'Searching videofile.')
    #progress.update( 25, "", "Loading video page", "" )

    videopage = utils.getHtml(url, '')

    #utils.Log(videopage)
    
    license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    match_2160 = re.compile("video_alt_url5:xx '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)
    match_1440 = re.compile("video_alt_url4:xx '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)
    match_1080 = re.compile("video_alt_url3: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)
    match_0720 = re.compile("video_alt_url2: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)
    match_0480 = re.compile("video_alt_url: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)
    match_0360 = re.compile("video_url: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)

    if match_2160:
        videourl = match_2160[0]
    elif match_1440:
        videourl = match_1440[0]
    elif match_1080:
        videourl = match_1080[0]
    elif match_0720:
        videourl = match_0720[0]
    elif match_0480:
        videourl = match_0480[0]
    elif match_0360:
        videourl = match_0360[0]
    else:
        utils.Notify("No video file found for {}".format(name))
        return

    utils.Log(videourl)
    
    utils.Log("license_code '{}'".format(license_code) )
    fappy_salt = utils.FaapySalt(license_code, "")
    utils.Log("fappysalt '{}'".format(fappy_salt))
    old_fappy_code =  videourl.split('/')[5]
    utils.Log("old_fappy_code '{}'".format(old_fappy_code))
    new_fappy_code = utils.ConvertFaapyCode( old_fappy_code, fappy_salt)
    utils.Log("new_fappy_code '{}'".format(old_fappy_code))
    #videourl = videourl.replace(old_fappy_code, new_fappy_code)

    #videourl = "{}?rnd=1535550208837".format(videourl, utils.Header2pipestring(), url)
    utils.Log(videourl)
    
    #progress.update( 75, "", "Video found", "" )
    #progress.close()

    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)


@utils.url_dispatcher.register('53', ['url'])
def PTCat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<a class="item" href="([^"]+)" title="([^"]+)".*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name, img in match:
        catpage = catpage + '?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date&from=1'
        utils.addDir(name, catpage, 51, img, 1)
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('54', ['url'], ['keyword'])  
def PTSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 54)
    else:
        title = keyword.replace(' ','+')
        #searchUrl = searchUrl + title + '/'
        #PTList(searchUrl, 1)
        search_url=BASE_SEARCH_URL.format(title,title,"1","1",int(time.time()))
        utils.kodilog("Searching URL: " + search_url)
        PTList(search_url, 1)
