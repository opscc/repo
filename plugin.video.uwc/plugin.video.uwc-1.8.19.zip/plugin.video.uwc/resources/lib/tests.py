#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import datetime
import json
import Queue
import threading
import traceback
#import internal addon libraries
from resources.lib import utils
from resources.lib import constants as C
#define common aliases
from resources.lib.utils import Log

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_TEST_ALL)
def TEST_ALL(quick_search_string=None):

    #one of the tests is searching via keyword...get a keyword
##    quick_search_string = 'sex'
    if not quick_search_string:
        prev_search_string = C.addon.getSetting(id='quick_search_string')
        quick_search_string = utils._get_keyboard( heading="Search query", default=prev_search_string  )
        if  quick_search_string == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=quick_search_string)

    progress_dialog = utils.Progress_Dialog(C.addon_name,u"Testing all sites using '{}' as search term".format(quick_search_string))

    try:
        
        #generate list of potential test sites by listing dir
        get_sites = utils.Get_Sites()
        #add sites to settings.xml [so that we can track which site has been tested today]
        test_list = C.addon.getSetting(id=C.TESTING_LIST_NAME)
##        test_list = "" #dev test only  ... force all tests regarless if they were run today
        if test_list == "": test_list = json.loads("{}")
        else: test_list = json.loads(test_list)
        for sitename, module in get_sites:
    ##        Log("sitename='{}'".format(repr(sitename)))
            if not (sitename in test_list):
                test_list[sitename] = ''
        C.addon.setSetting(id=C.TESTING_LIST_NAME, value=json.dumps(test_list))

        
        #temporarilty force only  X   recurse depth for this feature
        C.DEFAULT_RECURSE_DEPTH = 1
        C.MAX_RECURSE_DEPTH = 2

        #perform tests [if not passed test today]
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        q = Queue.Queue()
        i = 0 #dev test only
        all_method_results = {}
        try:
            get_sites = utils.Get_Sites() #refresh this variable
            for sitename, module in get_sites:
                all_method_results[sitename] = None #assume success
                last_success_date = test_list[sitename]
                if last_success_date < today: #we should test today
                    i = i + 1 #dev test only
                    method_to_call = getattr(module, 'Test')
                    kwargs = {"keyword": quick_search_string, "end_directory": False}
                    q.put( (sitename,method_to_call,kwargs) )
                else:
                    Log("'{}' passed '{}'".format(sitename, last_success_date))
                #if i > 3: break #dev test only
                     
            for k in range(C.MAX_WEBCRAWLER_THREADS):
                worker = threading.Thread(target=utils.crawl
                                          , args=(q,all_method_results))
                worker.daemon = False
                worker.start()
            q.join()

##            get_sites.send(False) #testing #cancel yield operations; will raise StopIteration inside get_sites

        except StopIteration:
            pass
        except:
            traceback.print_exc()

        #analyze test results and save them
        something_failed = False
        for sitename in all_method_results:
            if not(all_method_results[sitename] in [None, True]): #None or True are the success codes
                something_failed = True
                try:
                    Log(repr( sitename ) )
                    Log(repr( all_method_results[sitename] ) )
                    n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(sitename, sitename)
                    try:
                        n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(sitename, all_method_results[sitename].decode("utf8", "ignore"))
                    except:
                        import unicodedata
                        n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(
                            sitename
                            , unicodedata.normalize('NFKD', all_method_results[sitename]).encode("utf8", "ignore")
                            )

                except:
                    traceback.print_exc()
                utils.addDownLink(
                    name=n
                    ,url=C.DO_NOTHING_URL
                    ,mode=C.NO_ACTION_MODE
                    )
            else:
                test_list[sitename] = today
        C.addon.setSetting(id=C.TESTING_LIST_NAME, value=json.dumps(test_list))
        
        #visual indicator of success
        if not something_failed:
            utils.addDownLink(
                    name="[COLOR {}]all tests passed on {}[/COLOR]".format(C.test_passed_text_color,today)
                    ,url=C.DO_NOTHING_URL
                    ,mode=C.NO_ACTION_MODE
                    )

    except:
        traceback.print_exc()
    finally:
        if progress_dialog:
            if progress_dialog.iscanceled():
                utils.addDownLink(
                    name='Test All Cancelled'
                    ,url=C.DO_NOTHING_URL
                    ,duration = C.STANDARD_DURATION_REFRESH
                    ,mode=C.ROOT_INDEX_INDEX
                    )
            progress_dialog.close()

##    Log(repr(add_count))
    Log("TEST_ALL ended")
    utils.endOfDirectory()
#__________________________________________________________________________
#
