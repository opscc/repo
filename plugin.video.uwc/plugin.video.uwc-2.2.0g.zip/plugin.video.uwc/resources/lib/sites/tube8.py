'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils
import resolver

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Tube8[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False

    _ROOT_URL        = "https://www.tube8.com"
    _SEARCH_URL      = _ROOT_URL + '/searches.html/?q={}&page={}'
    _URL_CATEGORIES  = _ROOT_URL + '/categories.html/'
    _URL_RECENT      = _ROOT_URL + '/newest/page/{}/'
    _URL_MOST_VIEWED = _ROOT_URL + '/most-viewed/'
    _MAIN_MODE = C.MAIN_MODE_tube8
    _FIRST_PAGE = 1
    _IGNORE_404 = False #sometimes 404 is ok, sometimes not

    _LIST_REDIRECTED_URL_BECOMES_LISTURL = False

    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "Sorry, we couldn't find any pages containing"
        ]
    

    #where we can find videos on this page [exclude advertisement]
##    _REGEX_video_region = (
##                'class="porntrex-box"'
##                '(.+)'
##                'class="pagination"'
##                    )
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        #2026-03-24
        '<article class="video-box'
        '.+?href="(?P<videourl>.+?)"'
        '.+?data-src="(?P<thumb>[^"]+?)"'
        '.+?alt="(?P<label>[^"]+?)"'
        #'.+?class="video-best-resolution">(?P<hd>[^<]+)<'  #2024-09 no mor resultion
        '(?P<hd>)'
        '.+?class="video-duration.+?<span>(?P<duration>.+?)</span>'
        '(?P<desc>)'
        #2024-09-24
##        '<div class="video-box'
##        '.+?href="(?P<videourl>.+?)"'
##        '.+?data-src="(?P<thumb>[^"]+?)"'
##        '.+?alt="(?P<label>[^"]+?)"'
##        #'.+?class="video-best-resolution">(?P<hd>[^<]+)<'  #2024-09 no mor resultion
##        '(?P<hd>)'
##        '.+?class="video-duration.+?<span>(?P<duration>.+?)</span>'
##        '(?P<desc>)'
##        ?P<videourl>
##        ?P<thumb>
##        ?P<label>
##        ?P<duration>
##        '(?P<hd>)'
##        ?P<desc>
    )                         
    #__________________________________________________________________________
    # add an alternative way to resolve listing
    def List_URL_Normalize(self, url, page):
        if page == 1:
            if url.endswith('&page=1'): #site does not always like this
                url = url[:-len('&page=1')]
        return url
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self._ROOT_URL + videourl        
        return videourl
    #__________________________________________________________________________
    # Change thumb url created by List as neeeded by website; not all params must be used
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        if not thumb.startswith('http'): thumb = "https:" + thumb
        thumb = thumb.replace("&amp;","&")
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL
            thumb = thumb + utils.Header2pipestring(headers)
        return thumb
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
##    _REGEX_next_page_region = (
##        '(.+)'
####        '</nav>'
##        )
    _REGEX_next_page_regex = (
            '<div id="next">'
        )
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        keyword = keyword.replace(' ','+')
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format(keyword,'{}')
        return search_url
    #__________________________________________________________________________
    #where categories can be found
    _REGEX_categories_region = (
        'All porn categories</h2>'
        '(.*)'
        '<div class="title-bar">'
        )
    _REGEX_categories = (
        'a href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"' 
####        ?P<videourl>
####        ?P<thumb>
####        ?P<label>
        )
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = self._ROOT_URL + url
        url = url + "?page={}"
        return url
    #__________________________________________________________________________
    # Change category thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        thumb += utils.Header2pipestring()+"&Referer=" + self._ROOT_URL
        if not thumb.startswith('http'): thumb = 'https' + thumb
        return thumb
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags_region = (
        'id="metaDataPornstarInfo"'
        '(.+)'
        'class="suggest-pornstar'
        )
    _REGEX_tags = (
        'href="/pornstar/.+?<span>(?P<model>[^<]+)<'
        )

    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
##        LogR(locals())
        if not thumb.startswith('http'): thumb = "https:" + thumb
        thumb = thumb.replace("\\/","/")
        thumb = C.unescape(thumb)
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
            headers['Accept'] = 'image/avif,image/webp,image/png,image/svg+xml,image/*;q=0.8,*/*;q=0.5'
            thumb = thumb + utils.Header2pipestring(headers)
##        Log(thumb,C.LOGNONE)
        return thumb            


    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
##        full_html = kargs["full_html"]
        url = kargs["referer"]
        video_url = None

        regex = '"videoUrl":"([^"]+)"'

        video_sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(kargs["full_html"])
        if video_sources: video_sources = video_sources[0].replace('\\/','/')
        else: video_sources = ''
        if video_sources:
            sources_json = utils.getHtml(video_sources, url)
            json_sources = json.loads(sources_json)
            LogR(json_sources)
            for json_source in json_sources:
                if C.PY2:
                    if type(json_source['quality']) in [str, unicode]:
                        alt_results.append( (str(json_source['quality']), json_source['videoUrl']) )
                if C.PY3:
                    if type(json_source['quality']) in [str]:
                        alt_results.append( (str(json_source['quality']), json_source['videoUrl']) )
        return alt_results
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
