'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
from base_website import Base_Website
from utils import Log,LogR
from utils import addDir as addDir

import json, re
import utils

import base64
import jsunpack
            
class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Hentai Haven[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_HENTAI
    _FRONT_PAGE_CANDIDATE = False
    _ROOT_URL        = "https://hentaihaven.co"
    _URL_CATEGORIES  = None #_ROOT_URL + '/videos/category/798?page_id={}'
    #_URL_RECENT      = _ROOT_URL + '/page_loading.php?link1=videos&page=latest&page_id={}'
    #_URL_RECENT      = _ROOT_URL + '/release/2021/page/{}/' #2021-09-12
    _URL_RECENT      = _ROOT_URL + '/page/{}/' #2021-09-12
    _URL_RECENT      = _ROOT_URL + '?page={}' #2025-09-16
#    _SEARCH_URL      = _ROOT_URL + '/search?keyword={}&page_id={}'
    _SEARCH_URL      = _ROOT_URL + '/page/{}/?s={}' #2021-09-12
    _SEARCH_URL      = _ROOT_URL + '/search/?q={}&match=all&sort=recent&page={}' #2025-09-15
#https://hentaihaven.co/search/?q=episode+1&match=all&sort=recent&page=2

    _MAIN_MODE = C.MAIN_MODE_hentaihaven
    _FIRST_PAGE = 1
    _Right_Click_Option = None #C.DEFAULT_PLAYMODE # None to allow all possibilities [e.g. present HLS or MP4 play options]
    _SAVE_COOKIES = False       #if we need to save html cookies
    _ITEMS_NOT_FOUND_INDICATORS = [] #which to strings may indicate that there is nothing to be found

    _LIST_REDIRECTED_URL_BECOMES_LISTURL = False

    #override categor from a basic url to custom function
    def _URL_CATEGORIES(self):
##        #cat_url = self._ROOT_URL + '/videos/category/798?page_id={}'
##        cat_url = self._ROOT_URL + '/genres/uncensored/page/{}/' #2021-09-12
##        addDir(
##            name = '[COLOR {}]Uncensored[/COLOR]'.format(C.search_text_color)
##            ,url = cat_url
##            ,mode = self.LIST_MODE
##            ,page = self._FIRST_PAGE
##            ,iconimage=C.category_icon)
        pass
    def Categories(self, url, end_directory=True):
        return True
        
    #__________________________________________________________________________
    #videos on this page
##    _REGEX_video_region = \(
##        '(?:div id="browse_section"|div class="videolist_results"|id="search_results_block")'
##        '(.+?)'
##        '(?:</videolisting>|id="w_pagination"|class="title_inactive")'
##        )
    _REGEX_video_region = (
##        '(?:id="posts-home"|class="pt-6")(.+)'
        'class="sub_overview"'
        '(.+)'
        'class="main_section"'
    )
    _REGEX_list_items = (
        'class="a_item"'
        '.+?'
        'href="(?P<videourl>[^"]+?)"'
        '.+?'
        'data-src="(?P<thumb>[^"]+?)"'
        '.+?'
        'class="video_title">(?P<label>[^<]+?)<'
        '(?P<duration>)'
        '(?P<desc>)'
        '(?P<hd>)'


##        'class="bg-blacklit'
##        '.+?<a href="(?P<videourl>[^"]+?)"'
##        '.+?src="(?P<thumb>[^"]+?)"'
##        '.+?alt="(?P<label>[^"]+?)"'
##        '(?P<duration>)'
##        '(?P<desc>)'
##        '(?P<hd>)'

        )

        

##    _IGNORE_404 = False
##    _LIST_METHOD = "POST"
##    _LIST_HEADERS = {
##        "User-Agent": C.USER_AGENT
##        , "Accept": "*/*"
##        , "Referer": _ROOT_URL
##        , "X-Requested-With": "XMLHttpRequest"
##        , "Accept-Encoding": "gzip"
##        , "Accept-Language": "en-US,en;q=0.9"
##    }
##    def LIST_DATA(self, **kargs):
##        page = kargs["page"]
##        keyword = kargs["keyword"]
##        return "action=action_ajax_filter&query_vars=null&paged={}&order=latest&search={}".format(page,keyword)

    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
##        Log(repr((thumb,duration,videourl)), C.LOGNONE)
##        thumb = thumb.replace("\\/", "/")
        thumb = self._ROOT_URL + thumb
        Log(repr(thumb), C.LOGNONE)
        return thumb
    
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
##    _REGEX_next_page_region = '<nav class="pagination(.+?)</nav>'
##    #_REGEX_next_page_regex = '(title="Next Page">)' #as long as result is not empty
##    _REGEX_next_page_regex = '( Next )' #as long as result is not empty
    _REGEX_next_page_region = 'class="nav-links">(.+?)</div>'
    #_REGEX_next_page_regex = '(title="Next Page">)' #as long as result is not empty
    _REGEX_next_page_regex = '>Next<' #as long as result is not empty




##    #__________________________________________________________________________
##    _REGEX_categories_region = 
##        (
##        'class="main_category_header"(.+)'
##        )
##    _REGEX_categories = (
##        '<span class="ic-check icr"><span>(?P<label>.+?)<'
##        '.+?<li data-id="(P<videourl>.+?)"'
##        '(?P<thumb>)'
##        )
##    def Category_URL_Normalize(self, url): # Change url found in via regex with structure neeeded by website
##        return self.ROOT_URL + url + '?page={}'

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        keyword = keyword.replace(" ", '+')
        return search_url.format(keyword,'{}')

##    #__________________________________________________________________________
##    #where playable urls live
    _REGEX_playsearch_01 = None #not for this site
##    (
##        ',?"?mediaDefinitions?"?:(?P<json>.+?\]),'  #video data as json
##        'data-hls-src(?P<res>\d+)'                #video data as res+url
##        '="(?P<url>[^"]+)"'
##        )
    #description for the playable url
    _REGEX_tags = None #'<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    _REGEX_tags_region = None #'class="detail-video-block"(.+?)class="comments-wrapper"'

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        Log("_ALTERNATE_playsearch_01(args='{}',kargs='{}'".format(repr(args)[0:250], repr(kargs)[0:250]))

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]


        regex = r'id="play-iframe".+?src="([^"]+)"' #2020-12-14
        regex = r'<iframe src="([^"]+)"' #2021-03-18
        regex = r'<div class="iframe-video">\s+<iframe src="([^"]+)"' #2021-07-09
        regex = r'<iframe src="([^"]+)"' #2021-07-16
        regex = r'<iframe.+?src="(https://htstreaming.com[^"]+)"' #2021-09-12


        next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        Log("next_link={}".format(repr(next_link)))
        if next_link:
            next_link = next_link[0]
        else:
            regex = r'<iframe.+?src="(https://nhplayer.com[^"]+)"' #2022-08-27
            next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
            if next_link:
                next_link = next_link[0]
            Log("next_link={}".format(repr(next_link)))
            if not next_link:     
                Log("no iframe src was found")
                #return alt_results
        if next_link:
            next_html = utils.getHtml(next_link, url)
        else:
            next_html = full_html
            


#2026-09 cloudflare

##        next_link = None
##        regex = r'data-id="/player.php\?vid=([^&]+?)&' #2026-09
##        base_64_info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_html)
##        LogR(base_64_info)
##        if base_64_info:
##            base_64_info = base_64_info[0]
##            if C.PY3: video_url = str(base64.b64decode(base_64_info), 'utf8')
##            LogR(video_url)
##            alt_results.append( ('1', video_url) )
##            LogR(alt_results)
##            return alt_results
##            
##
##        raise Exception        

        next_link = None
        regex = r'data-id="(https://htstreaming.com[^"]+)"' #2022-08-27
        next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_html)
        Log("next_link={}".format(repr(next_link)))
        if next_link:
            next_link = next_link[0]
            next_html = utils.getHtml(next_link, url)
        else:
            regex = r'data-id="/player.php\?u=([^&]+?)&' #2023-04-27
            base_64_info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_html)
            Log("base_64_info={}".format(repr(base_64_info)))
            if base_64_info:
                base_64_info = base_64_info[0]
##                video_url = base64.b64decode( base_64_info )
                if C.PY2: video_url = base64.b64decode( base_64_info )
                if C.PY3: video_url = str(base64.b64decode(base_64_info), 'utf8')

                Log(video_url)
                Log(repr(video_url))
                alt_results.append( ('1', video_url) )
                Log(repr(alt_results))
                return alt_results
            
        
        try:
            unpacked_src = jsunpack.unpack(next_html)
            Log("unpacked_src='{}'".format(unpacked_src))
        except:
            unpacked_src = ''


        try:
            #working 2020-07
            regex = r'sources:(\[.*?\])'
            sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
            Log("sources_list='{}'".format(sources_list))
            sources = json.loads(sources_list[0])
            Log("sources='{}'".format(sources))
            Log("sources[file]='{}'".format(sources[0]['file']))
            video_url = sources[0]['file']
            alt_results.append( ('1', video_url) )
        except:
            #working 2020-08
            regex = r'FirePlayer\(vhash, (.+), false\);'
            sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_html)
            Log("sources_list='{}'".format(sources_list))
            try: 
                if not sources_list:
                    raise Exception('2020-08 method not working')

                if sources_list: sources_list = sources_list[0]
                else: return alt_results
                sources = json.loads(sources_list)
                Log("sources='{}'".format(sources))
                video_url = "https://htstreaming.com{}?s={}&d=".format(
                    sources['videoUrl']
                    ,sources['videoServer']
                    )
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = next_link
                video_url +=  utils.Header2pipestring(headers)
        
                Log("video_url={}".format(video_url.encode()))
                isHLS = sources['videoData']['videoSources'][0]['type'] == u'hls'
                alt_results.append( ('1', video_url) )

            except:
                #working 2021-07
                regex = r'{FirePlayer\("([^"]+)"'
                sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
                Log("sources_list={}".format(repr(sources_list)))
                #https://htstreaming.com/player/index.php?data=f3102064ef90bf7d811c330f976366f7
                if not sources_list:
                    raise Exception('2021-07 method not working')
                sources = sources_list[0]
                Log("sources='{}'".format(sources))
                post_url = "https://htstreaming.com/player/index.php?data={}".format(
                    sources
                    )
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = next_link
                headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
                headers['X-Requested-With'] = 'XMLHttpRequest'
                post_json = utils.getHtml(post_url + '&do=getVideo'
                                          , headers = headers
                                          , method = 'POST'
                                          , sent_data = 'hash=sources'
                                          )
                Log("post_json={}".format(repr(post_json)))
                sources = json.loads(post_json)
                Log("sources={}".format(repr(sources)))

                video_url = sources['videoSource']
                Log("video_url={}".format(video_url.encode()))
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = post_url
                video_url +=  utils.Header2pipestring(headers)
                
                Log("video_url={}".format(video_url.encode()))
                alt_results.append( ('1', video_url) )
                
        return alt_results
    #__________________________________________________________________________
    #

#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid(url
                    , name
                    , icon_URI = icon_URI
                    , download = download
                    , playmode_string = playmode_string
                    , play_profile = play_profile
                    , testmode = testmode
                    )
#__________________________________________________________________________
#
