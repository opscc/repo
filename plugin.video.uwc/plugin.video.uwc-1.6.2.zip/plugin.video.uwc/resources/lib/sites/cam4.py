'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import sqlite3
import urllib

import json

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

from resources.lib.utils import Log


mobileagent = {'User-Agent': 'Mozilla/5.0 (Linux; U; Android 2.2; en-us; Droid Build/FRG22D) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'}
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://www.cam4.com"

RESULTS_PER_PAGE = 60

URL_FEMALES = ROOT_URL + "/directoryCams?directoryJson=true&online=true&url=true&gender=female&broadcastType=female_group&broadcastType=solo&page={}&orderBy=VIDEO_QUALITY&resultsPerPage=" + str(RESULTS_PER_PAGE)
URL_COUPLES = ROOT_URL + "/directoryCams?directoryJson=true&online=true&url=true&broadcastType=female_group&broadcastType=male_female_group&page={}&orderBy=VIDEO_QUALITY&resultsPerPage=" + str(RESULTS_PER_PAGE)

MAIN_MODE          = '280'
LIST_MODE          = '281'
PLAY_MODE          = '282'
REFRESH_MODE       = '284'
CLEANDATABASE_MODE = '283'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(
        name="{}[COLOR {}]Couples[/COLOR]".format(SPACING_FOR_TOPMOST,utils.search_text_color) 
        ,url=URL_COUPLES
        ,page='1'
        ,mode=LIST_MODE
        ,iconimage=utils.category_icon )
    
    List(URL_FEMALES, page='1', end_directory=True, keyword='')
    
##    utils.addDir(
##        name='[COLOR red]Refresh Cam4 images[/COLOR]','',CLEANDATABASE_MODE,'',Folder=False)
##    utils.addDir('[COLOR hotpink]Females[/COLOR]','https://www.cam4.com/female?{}',LIST_MODE,'',1)
##    utils.addDir('[COLOR hotpink]Couples[/COLOR]','https://www.cam4.com/couple/1',LIST_MODE,'',1)
##    utils.addDir('[COLOR hotpink]Males[/COLOR]','https://www.cam4.com/male/1',LIST_MODE,'',1)
##    utils.addDir('[COLOR hotpink]Transsexual[/COLOR]','https://www.cam4.com/shemale/1',LIST_MODE,'',1)
##    xbmcplugin.endOfDirectory(utils.addon_handle)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')


#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page=1, notify=False):

    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    if '{}' in url and page: list_url = url.format(page)
    else: list_url = url
    
    json_html = utils.getHtml(list_url)

    json_items = json.loads(json_html)['users']

    hq_bonus = int(utils.addon.getSetting("hq_bonus").lower())
    
    for json_item in json_items:
        camscore=int(json_item["viewers"])
        hd = json_item["resolution"]
        #Log("resolution='{}'".format(hd))
        hd = str(hd.split(':')[0])
        #Log("resolution='{}'".format(hd))
        if   '4k' in hd :
            camscore=camscore*hq_bonus*100
            hd = "[COLOR {}]uhd[/COLOR]".format(utils.refresh_text_color)
        elif '1920' in hd :
            camscore=camscore*hq_bonus*10
            hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif '1280' in hd :
            camscore=camscore*hq_bonus*1
            hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        elif '1152' in hd :
            camscore=camscore*hq_bonus*1
            hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else:
            hd = ""
        name = json_item["username"]
        #Log("name='{}'".format(name))
        icon_image = json_item["snapshotImageLink"]
        #videourl = json_item["hlsPreviewUrl"]
        video_url = ROOT_URL + '/' + name
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(name), hd)

        json_item['icon_label'] = label
        json_item['icon_image'] = icon_image
        json_item['video_url'] = video_url
        json_item['camscore'] = camscore
        json_item['mode'] = PLAY_MODE
        json_item['description'] = '\n' + ROOT_URL
        json_item['play_method'] = 'f4mproxy'

            
    return json_items
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:    
        utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.refresh_text_color) 
            ,url='' 
            ,mode=REFRESH_MODE 
            ,iconimage=utils.refresh_icon)

    models = GetCamgirlList(url, page)
    
    for model in models:
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            )

    if HasNextPage(url, page):
        np_number = int(page) + 1
        np_url = url
        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
        if end_directory == True:
            utils.addDir(
                name= np_label
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=utils.next_icon 
                ,page=np_number
                ,keyword=keyword )
        

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

def HasNextPage(url, page):

    #POST to get json info
    #page number and item count don't seem to matter, but using them anyway
    cam4_headers = {
                    'User-Agent': utils.USER_AGENT
                    ,'Accept': "application/json, text/plain, */*"
                    ,'Referer': "{}".format(ROOT_URL)
                    }

    if '{}' in url and page:
        url = url.format(page)
    
    url = url.replace("directoryCams", "directoryCounts")
#    url = url.replace("https", "http")

    count_html = utils.postHtml(url, form_data=None, headers=cam4_headers, compression=True)
##    Log("count_html='{}'".format(count_html.encode("utf-8").decode('ascii', 'ignore')))

    import json
    json_items = json.loads(count_html)

    total_count = int(json_items["totalCount"])
    page_window = RESULTS_PER_PAGE * int(page)
    Log("total_count='{}'".format(total_count))
    Log("page_window='{}'".format(page_window))

    has_next_page = (total_count > page_window)
    Log("has_next_page='{}'".format(has_next_page))
    return has_next_page


##    from requests import Request, Session
##    s = Session()
##    headers = {"User-Agent": utils.USER_AGENT
##               , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
##               , "Referer": url
##               }
##    data = ""
##
##    req = Request('POST', url, data=data, headers=headers)
##    prepped = s.prepare_request(req)
##    proxies = {"http": "127.0.0.1:8888"}
##    resp = s.send(prepped , proxies=proxies , verify=False)
##    Log(resp.status_code)
##    Log(resp.content)
##    return
##
##    #proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
##    proxies = {"http": "127.0.0.1:8888"}
##    data=''
##    Log("cam4_headers='{}'".format(cam4_headers))
##    req = Request('POST', data, url, headers=cam4_headers)
##    prepped = s.prepare_request(req)
##    resp = s.send(prepped , proxies=proxies, verify=False)
##
##    count_html = resp.content
##    Log("count_html='{}'".format(count_html))
    


#                      /directoryCams?directoryJson=true&online=true&url=true&broadcastType=female_group&broadcastType=male_female_group&page={}&orderBy=VIDEO_QUALITY&resultsPerPage=" + str(RESULTS_PER_PAGE)
#https://www.cam4.com/directoryCounts?directoryJson=true&online=true&url=true&broadcastType=female_group

##def postHtml(url, form_data={}, headers={}, compression=True, NoCookie=None):
##https://www.cam4.com/directoryCounts?directoryJson=true&online=true&url=true&broadcastType=male_group&broadcastType=female_group&broadcastType=male_female_group&page=1&orderBy=VIDEO_QUALITY&resultsPerPage=60
##                     "/directoryCams?directoryJson=true&online=true&url=true&gender=female&broadcastType=female_group&broadcastType=solo                        &page={}&orderBy=VIDEO_QUALITY&resultsPerPage=" + str(RESULTS_PER_PAGE)
##URL_COUPLES = ROOT_URL + "/directoryCams?directoryJson=true&online=true&url=true&broadcastType=female_group&broadcastType=male_female_group&page={}&orderBy=VIDEO_QUALITY&resultsPerPage=60"


#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download', 'megabitratebonus'])
def Playvid(url, name, playmode_string = '', megabitratebonus=0, download = False):

    Log ("Playvid url='{}', name='{}', playmode_string='{}', megabitratebonus='{}', download='{}'".format(url, name, playmode_string, megabitratebonus, download), xbmc.LOGNONE  )

    cam4_headers = {
        'User-Agent': mobileagent['User-Agent']
        ,'Accept': '*/*'
        ,'Referer': "{}".format(ROOT_URL)
     }

    listhtml = utils.getHtml(url, headers=cam4_headers)

    regex = 'autoplay playsinline src="([^"]+)"'
    video_url = re.compile(regex, re.DOTALL).findall(listhtml)
    if video_url:
        video_url = video_url[0]
    else:
        utils.notify(name,'Couldn\'t find a playable webcam link')
        return
    
##    video_url = url + "?&referer=www.cam4.com"+ "|User-Agent=" + urllib.quote_plus(mobileagent['User-Agent']) + "&Referer=https://www.cam4.com/female/1"
    Log("video_url='{}'".format(video_url)  )

    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    listitem.setContentLookup(False)

    max_bit_rate = (int(utils.addon.getSetting('max_bit_rate')) + 1 + int(megabitratebonus)) * 1000 * 1000
    default_playmode = utils.addon.getSetting('default_playmode').lower()  #allow playmode to be forced by input command, or use default from addon settings

    if playmode_string == 'f4mproxy':
        pass
    elif playmode_string == 'inputstream':
        pass
    else:
        playmode_string = default_playmode
    if download == True:
        Log("f4mproxy video_url - only this mode can capture")
        playmode_string = 'f4mproxy'
    Log("playmode_string='{}'".format(playmode_string)  )

    if playmode_string == '': # direct
        video_url = "{}{}".format(video_url, utils.Header2pipestring(cam4_headers) )
        Log("direct video_url")

    elif playmode_string == 'f4mproxy':
        video_url = "{}{}".format(video_url, utils.Header2pipestring(cam4_headers) )
        Log("f4mproxy video_url")

        if download == True:
            download_path = utils.Make_download_path(name = name, include_date = True, file_extension = '.mp4')
            Log(download_path, xbmc.LOGNONE)
            max_bit_rate = int((int(utils.addon.getSetting('max_bit_rate')) + 0.25 + int(megabitratebonus)) * 1000 * 1000 )
        else:
            download_path = None
            
        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        f4mp.playF4mLink(
            video_url
            , name
            , proxy = None
            , use_proxy_for_chunks = False
            , maxbitrate = max_bit_rate
            , simpleDownloader = False
            , auth = None
            , streamtype = 'HLSREDIR'
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , iconImage = iconimage
            , download_path = download_path
            )
        return
            
    elif playmode_string == 'inputstream':

        video_url = "{}{}".format(video_url, utils.Header2pipestring(cam4_headers) )
        if ".m3u8" in video_url:
            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            listitem.setProperty('inputstream.adaptive.stream_headers'
                                , 'user-agent=' + 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/538.22 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'
                                + "&Referer=".format(ROOT_URL)
                                )
            Log("using inputstream")
    else:
        utils.notify(name,'Unknown playmode for webcam link')

    Log("video_url='{}'".format(video_url)  )

    #xbmc.Player().stop()
    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( video_url, listitem)
    xbmc.Player().play(myPlayList)



#__________________________________________________________________________
#

def Search(searchUrl, keyword=None, end_directory=True, page=0):
    return True

#__________________________________________________________________________
#

def Test(keyword):
    return True
    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CLEANDATABASE_MODE)
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".cam4s.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".cam4s.com")
            if showdialog:
                utils.notify('Finished','Cam4 images cleared')
    except:
        pass

#__________________________________________________________________________
#
