'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import sys

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "http://www.poldertube.nl"

#SEARCH_URL = ROOT_URL + '/pornofilms/zoeken/{}'
SEARCH_URL = ROOT_URL + '/page/{}/?s={}'
#http://www.poldertube.nl/page/2/?s=blonde+toeriste

#URL_RECENT = ROOT_URL + '/pornofilms/nieuw'
URL_RECENT = ROOT_URL + '/page/{}/'
URL_CATEGORIES = ROOT_URL + '/categorieen/'

URL_TOPRATED = ROOT_URL + '/ajax/best_rated/?page=1'

MAIN_MODE       = '100'
LIST_MODE       = '101'
PLAY_MODE       = '102'
CATEGORIES_MODE = '103'
SEARCH_MODE     = '104'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon)
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)
        
    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "but you can check other awesome vid" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
##            regex = '(?:class="pages-nav-border"|id="vidresults")(.+?)(?:class="numlist2"|id="wrapBlocks")'
##            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
            #video_region = listhtml.split('//END Footer links')[0]
            video_region = listhtml.split('class="happy-footer"')[0]
            
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))
            
    #
    # parse out list items
    #
    #regex = '<article([^>]*)>.*?href="([^"]+)".+?src="([^"]+)".*?<h3>([^<]+)<.*?duration">[^\d]+([^\s<]+)(?:\s|<)'
    regex = '<article([^>]*)>.*?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)".+?duration">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #for hd, videourl, thumb, label, duration in info:
    for hd, videourl, thumb, label, duration in info:
        if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        duration = duration.replace(' min','s').replace(':','m ')
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("hd={}".format(hd))
        #Log("videourl={}".format(videourl))
        #Log("label={}".format(label))
        #Log("thumb={}".format(thumb))
        #Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration )
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError

    #
    # next page items
    #
    #next_page_regex ='<a href="([^"]+)" title="volgende '
    #next_page_regex ='<a href=.+/page/(\d+)/.*?">Volgende'
    next_page_regex ='<link rel="next" href=.+?/page/(\d+)/.*?" />'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
##            Log("np_url={}".format(np_url))
##            np_number = np_url.split('/')[3]
##            if not np_number.isdigit(): np_number=np_url.split('/')[4]
##            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            np_number = int(np_url)
            np_url=url
            
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    html = utils.getHtml(url, '')

    #regex = '<div class="category".*?href="([^"]+)".*?<h2>([^<]+)<.*?src="([^"]+)"'
    regex = '<article id=.+?href="([^"]+).+?title="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    Log("info='{}'".format(info))
    for url, label, thumb in info:
        if url.startswith('/'): url = ROOT_URL + url
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        url = url + 'page/{}/'
 ##        Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,page=1
            )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    #keyword = keyword.replace(' ','%20').replace('+','%20')
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    videopage = utils.getHtml(url, '')
    videourl = re.compile('<source src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = videourl[0] + utils.Header2pipestring()
    
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name + '\n' + ROOT_URL, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)

#__________________________________________________________________________
#
