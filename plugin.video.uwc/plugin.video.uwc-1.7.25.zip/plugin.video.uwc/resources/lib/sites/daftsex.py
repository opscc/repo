'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log
from resources.lib.utils import addDir as addDir

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]daftsex[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True
    _ROOT_URL        = "https://daftsex.com"
    _URL_CATEGORIES  = None #_ROOT_URL + '/videos/category/798?page_id={}'
    _URL_RECENT      = _ROOT_URL #2021-09-23
    _SEARCH_URL      = _ROOT_URL + '/video/{}'

    _MAIN_MODE = C.MAIN_MODE_daftsex
    _FIRST_PAGE = '0'
    _Right_Click_Option = None # C.DEFAULT_PLAYMODE # None to allow all possibilities [e.g. present HLS or MP4 play options]
    _SAVE_COOKIES = False       #if we need to save html cookies
    _ITEMS_NOT_FOUND_INDICATORS = [] #which to strings may indicate that there is nothing to be found

##    #override categor from a basic url to custom function
##    def _URL_CATEGORIES(self):
##        cat_url = self._ROOT_URL + '/genres/uncensored/page/{}/' #2021-09-12
##        addDir(
##            name = '[COLOR {}]Uncensored[/COLOR]'.format(C.search_text_color)
##            ,url = cat_url
##            ,mode = self.LIST_MODE
##            ,page = self._FIRST_PAGE
##            ,iconimage=C.category_icon)
##        pass
##    def Categories(self, url, end_directory=True):
##        return True
        
    #__________________________________________________________________________
    #videos on this page
##    _REGEX_video_region = \(
##        '(?:div id="browse_section"|div class="videolist_results"|id="search_results_block")'
##        '(.+?)'
##        '(?:</videolisting>|id="w_pagination"|class="title_inactive")'
##        )
    _REGEX_list_items = (
        '<div class="video-item'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?data-thumb="(?P<thumb>[^"]+)"'
        '.+?<span class="video-time">(?P<duration>[^<]+)<'
        '.+?"setTitle\(this\);">(?P<label>[^<]+)<'
        '(?P<hd>(?:\[[^\]<]+(?:\]|<)|))'
        '(?P<desc>)'
        )
##    _IGNORE_404 = False

    _LIST_METHOD = "POST"
    _LIST_HEADERS = {
        "User-Agent": C.USER_AGENT
        , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        , "Referer": _ROOT_URL
        , "X-Requested-With": "XMLHttpRequest"
        , "Accept-Encoding": "gzip"
        , "Accept-Language": "en-US,en;q=0.9"
    }
    def LIST_DATA(self, **kargs):
        page = kargs["page"]
##        keyword = kargs["keyword"]
        return "page={}".format(page)
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = '<nav class="pagination(.+?)</nav>'
    _REGEX_next_page_regex = '(>Show more<)' #as long as result is not empty

##    #__________________________________________________________________________
##    _REGEX_categories_region = 
##        (
##        'class="main_category_header"(.+)'
##        )
##    _REGEX_categories = (
##        '<span class="ic-check icr"><span>(?P<label>.+?)<'
##        '.+?<li data-id="(P<videourl>.+?)"'
##        '(?P<thumb>)'
##        )
##    def Category_URL_Normalize(self, url): # Change url found in via regex with structure neeeded by website
##        return self.ROOT_URL + url + '?page={}'

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        keyword = keyword.replace('+',' ').replace(' ','%20')
        return search_url.format(keyword)

##    #__________________________________________________________________________
##    #where playable urls live
    _REGEX_playsearch_01 = None #not for this site
##    (
##        ',?"?mediaDefinitions?"?:(?P<json>.+?\]),'  #video data as json
##        'data-hls-src(?P<res>\d+)'                #video data as res+url
##        '="(?P<url>[^"]+)"'
##        )
    #description for the playable url
    _REGEX_tags = None        #'<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    _REGEX_tags_region = None #'class="detail-video-block"(.+?)class="comments-wrapper"'

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url; returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        Log("_ALTERNATE_playsearch_01(args='{}',kargs='{}'".format(repr(args)[0:250], repr(kargs)[0:250]))

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        import base64, json, re
        from resources.lib import utils


        video_url = None
        server = None


        #try and get 1080p version [technically requires an account on vk.com, but sometimes not]
        vk_url = "https://vk.com/al_video.php?act=show_inline&al=1&video="+url.replace("https://daftsex.com/watch/","")
        vk_html = utils.getHtml(vk_url, self._ROOT_URL)
        regex = '"url(?P<res>\d+)":"(?P<url>[^"]+)"'
        vid_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(vk_html)
##        if len(vid_list) > 0:
##            video_url = utils.SortVideos(
##                sources=vid_list
##                ,download=download
##                ,vid_res_column=0
##                ,max_video_resolution=max_video_resolution
##                )
##            video_url = video_url.replace("\/", "/")
##            Log("video_url='{}'".format(video_url))#, xbmc.LOGNONE)
        headers = C.DEFAULT_HEADERS.copy()
        for res, vid in vid_list:
            video_url = vid.replace("\/", "/")
            if '|' not in video_url:
                if url: headers['Referer'] = url
                if server and  server not in video_url:
                    headers['User-Agent'] = "Firefox" #this trick allows older site pages to get 1080 content
                video_url = video_url + utils.Header2pipestring(headers)
            alt_results.append( (res, video_url) )
            Log(repr(alt_results))





        
        if not video_url: #get the max 720p version
            regex = 'window.globEmbedUrl = \'([^\']+)\'.+?hash: "([^"]+)".+?color: "([^"]+)"'   ##2021-04 second file now has data
            url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
            if url2:
                url2 = "{}{}?color={}".format(url2[0][0], url2[0][1], url2[0][2])
                full_html = utils.getHtml(url2, self._ROOT_URL)
            else:
                pass
            
            vid_id = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)    
            token = re.compile('access_token: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
            videos = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
            extra_key = re.compile('extra_key: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
            sig = re.compile('\s(?:sig|credentials):\s*"([^"]+?)",', re.DOTALL | re.IGNORECASE).findall(full_html)
            ckey = re.compile('c_key: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
            thumb = re.compile('thumb: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
            cdn_files = re.compile('cdn_files: {([^}]+)}', re.DOTALL | re.IGNORECASE).findall(full_html)
            server = re.compile('server: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
            partial = re.compile('partial: {"quality":({"[^}]+})', re.DOTALL | re.IGNORECASE).findall(full_html)

            #different versions of web page may not have same data
            try:    token = token[0]
            except: token = None
            try:    videos = videos[0]
            except: videos = None
            try:    ckey = ckey[0]
            except: ckey = None
            try:    extra_key = extra_key[0]
            except: extra_key = None
            try:    cdn_files = cdn_files[0]
            except: cdn_files = None
            try:    thumb = base64.b64decode(thumb[0]).strip("thumb.jpg")
            except: thumb = None
            try:    server = base64.b64decode(server[0][::-1]) #reverse string then decode it
            except: server = None
            try:    sig = sig[0]
            except: sig = None
            try:    vid_id = vid_id[0]
            except: vid_id = None
            try:
                Log("partial={}".format(repr(partial)))
                partial = json.loads(partial[0])
                Log("partial={}".format(repr(partial)))
            except: partial = None


            if cdn_files: #newer style
                regex = '"mp4_(\d+)":"([^"]+)'
                vid_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cdn_files)
##                Log(repr(vid_list))
##                video_url = utils.SortVideos(
##                    sources=vid_list
##                    ,download=download
##                    ,vid_res_column=0
##                    ,max_video_resolution=max_video_resolution
##                    )
                for res, vid in vid_list:
                    baseurl = "https://{}/videos/{}/".format(server, videos.replace("_","/"))
                    video_url = "{}{}".format(baseurl, vid.replace(".",".mp4?extra=") )
                    alt_results.append( (res, video_url) )
                Log(repr(alt_results))

            elif server: #older styple
                base_str = "https://{}/method/video.get/{}?token={}&videos={}&ckey={}&credentials={}"
                intermediate_url = base_str.format(server,vid_id,token,videos,ckey,sig)
                http_referrer = "https://daxab.com/"
                json_html = utils.getHtml(intermediate_url, http_referrer)
                
                json_sources = json.loads(json_html)
                if "error" in json_sources:
                    utils.Notify(json_sources["error"]["error_msg"] + '\n' + self._ROOT_URL)
                    return alt_results

                vid_list = list()
                key_list = list()
                if "response" in json_sources:
                    for json_item in json_sources["response"]["items"]:
                        for vid_src in json_item["files"]:
##                            Log("vid_src={}".format(repr(vid_src)))
                            res = vid_src.split('=')[0].replace('mp4_','')
                            v_url = json_item["files"][vid_src]
##                            Log("res={}".format(repr(res)))
                            vid_list.append( (res, v_url) )
                Log("vid_list={}".format(repr(vid_list)))


                Log(repr(alt_results), C.LOGNONE)
            
##                video_url = utils.SortVideos(
##                    sources=vid_list
##                    ,download=download
##                    ,vid_res_column=0
##                    ,max_video_resolution=max_video_resolution
##                    )

                
                for q,u in vid_list: #this site needs quality info
                    video_proxy_res = None    
                    Log("q={}".format(q))
                    Log("u={}".format(u))
                    Log(repr(partial))
                    video_url = u
                    #if video_url == u:
                    if q in partial:
                        video_proxy_res = q
                        extra_key = partial[q]
                        Log(repr(extra_key))
                        if video_proxy_res:
                            Log(repr(video_proxy_res))
                            video_url = video_url.replace("https://", "https://"+server+"/") #needs this remote proxy
                            video_url  = video_url + "&videos={}&extra_key={}&videos={}".format(vid_id, extra_key, vid_id)
                    else:
                        video_url = u
                    alt_results.append( (q, video_url) )

                Log(repr(alt_results))

                
                    
##                url = None
##                Log("video_url={}".format(video_url))

##                raise Exception("todo")


##        alt_results.append( ('1', video_url) )
                
        return alt_results

    
        return
    
        regex = 'id="play-iframe".+?src="([^"]+)"' #2020-12-14
        regex = '<iframe src="([^"]+)"' #2021-03-18
        regex = '<div class="iframe-video">\s+<iframe src="([^"]+)"' #2021-07-09
        regex = '<iframe src="([^"]+)"' #2021-07-16
        regex = '<iframe.+?src="(https://htstreaming.com[^"]+)"' #2021-09-12

        next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        Log("next_link={}".format(repr(next_link)))
        if next_link:
            next_link = next_link[0]
        else:
            Log("no iframe src was found")
            return alt_results
        next_html = utils.getHtml(next_link, url)

        
        try:
            from resources.lib import jsunpack
            unpacked_src = jsunpack.unpack(next_html)
            Log("unpacked_src='{}'".format(unpacked_src))
        except:
            unpacked_src = ''


        try:
            #working 2020-07
            regex = 'sources:(\[.*?\])'
            sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
            Log("sources_list='{}'".format(sources_list))
            sources = json.loads(sources_list[0])
            Log("sources='{}'".format(sources))
            Log("sources[file]='{}'".format(sources[0]['file']))
            video_url = sources[0]['file']
            alt_results.append( ('1', video_url) )
        except:
            #working 2020-08
            regex = 'FirePlayer\(vhash, (.+), false\);'
            sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_html)
            Log("sources_list='{}'".format(sources_list))
            try: 
                if not sources_list:
                    raise Exception('2020-08 method not working')

                if sources_list: sources_list = sources_list[0]
                else: return alt_results
                sources = json.loads(sources_list)
                Log("sources='{}'".format(sources))
                video_url = "https://htstreaming.com{}?s={}&d=".format(
                    sources['videoUrl']
                    ,sources['videoServer']
                    )
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = next_link
                video_url +=  utils.Header2pipestring(headers)
        
                Log("video_url={}".format(video_url.encode()))
                isHLS = sources['videoData']['videoSources'][0]['type'] == u'hls'
                alt_results.append( ('1', video_url) )

            except:
                #working 2021-07
                regex = '{FirePlayer\("([^"]+)"'
                sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
                Log("sources_list={}".format(repr(sources_list)))
                #https://htstreaming.com/player/index.php?data=f3102064ef90bf7d811c330f976366f7
                if not sources_list:
                    raise Exception('2021-07 method not working')
                sources = sources_list[0]
                Log("sources='{}'".format(sources))
                post_url = "https://htstreaming.com/player/index.php?data={}".format(
                    sources
                    )
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = next_link
                headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
                headers['X-Requested-With'] = 'XMLHttpRequest'
                post_json = utils.getHtml(post_url + '&do=getVideo'
                                          , headers = headers
                                          , method = 'POST'
                                          , sent_data = 'hash=sources'
                                          )
                Log("post_json={}".format(repr(post_json)))
                sources = json.loads(post_json)
                Log("sources={}".format(repr(sources)))

                video_url = sources['videoSource']
                Log("video_url={}".format(video_url.encode()))
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = post_url
                video_url +=  utils.Header2pipestring(headers)
                
                Log("video_url={}".format(video_url.encode()))
                alt_results.append( ('1', video_url) )
                
        return alt_results
    #__________________________________________________________________________
    #

#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    website.Playvid(url, name, download, playmode_string, play_profile=play_profile, testmode=testmode)
#__________________________________________________________________________
#
