# -*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import urllib, urllib2
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://www.xvideospanish.net"

SEARCH_URL = ROOT_URL + '/?s={}'

URL_CATEGORIES = ROOT_URL + '/video-porn-categories/'
URL_RECENT = ROOT_URL
URL_TOPRATED = ROOT_URL + "/top-rated-porn-videos/page/{}/"
URL_MOSTVIEWED = ROOT_URL + "/most-viewed-porn-videos/page/{}/"

MAIN_MODE       = '130'
LIST_MODE       = '131'
PLAY_MODE       = '132'
CATEGORIES_MODE = '133'
SEARCH_MODE     = '134'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))
    
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    if '{}' in url and page: list_url = url.format(page)
    else: list_url = url
    listhtml = utils.getHtml(list_url, ROOT_URL)
    if "looks like nothing was found for this search" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon 
            )
    else: #distinguish between adverts and videos
        video_region = listhtml.split('id="main"')[1].split('<!-- #primary -->')[0]
        

    #
    # main list items
    #
    #sometimes the list of items returned will have a 'duration', sometimes not...
    #to get around this, have two regex, for 'search' results, use non-duration
    if "Search results for" in listhtml:
        is_search = True
        videos_regex = '<article id=.+?<a href=\"([^\"]+)\" title=\"([^\"]+)\".+?(?:img data-src|poster)=\"([^\"]+)\"'
    else:
        is_search = False
        videos_regex = '<article id=.+?<a href=\"([^\"]+)\" title=\"([^\"]+)\".+?(?:img data-src|poster)=\"([^\"]+)\".+?class=\"duration\".+?</i>([^<]+)</span'
    pattern = re.compile(videos_regex, re.DOTALL | re.IGNORECASE)
    for info in re.finditer(pattern, video_region):
        videourl = info.group(1)
        label = info.group(2)
        thumb = info.group(3)
        if info.lastindex > 3:
            duration = info.group(4)
        else:
            duration = ''
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in label: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        thumb = thumb.replace('https://www.xvideos-español.com', ROOT_URL)
        videourl = videourl.replace('https://www.xvideos-español.com', ROOT_URL)
        #Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration)
    if not (re.finditer(pattern, video_region)) and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError  

    #
    # next page items
    #
    try:
        regex = 'class="pagination"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
        
    next_page_regex = 'href="([^"]+)">Next</a>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            np_number = '' #page number can be multiple places depending if search result or not
            if '/' in np_url:
                if not np_number.isdigit(): np_number=np_url.split('/')[4]
                if not np_number.isdigit(): np_number=np_url.split('/')[5]
            np_url = np_url.replace('https://www.xvideos-español.com', ROOT_URL)
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
##    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    Log("url='{}', name='{}', download='{}'".format(url, name, download))

    cathtml = utils.getHtml(url, url)
    #parse out and ... 
    #2019-02-05
    match1 = re.compile('itemprop="embedURL" content="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(cathtml)

    #2019-07-18 style..
    regex = 'itemprop="embedURL".+?content="/player/(\?data=[^"]+)"'
    match = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    if match:
        sources_url = ROOT_URL + "/player/getVideo.php{}".format(match[0])
        Log("sources_url={}".format(sources_url))
        sources_html = utils.getHtml(sources_url)
        import json
        json_sources = json.loads(sources_html)
        Log("json_sources={}".format(json_sources))
        video_url = json_sources["videoUrl"]
        utils.playvid(video_url, name, download)
        return

    #2019-05-17 style..
    match = re.compile('<iframe src=\"https://datoporn\.co/([^"]+)\"', re.DOTALL | re.IGNORECASE).findall(cathtml)
    if match:
        utils.PLAYVIDEO("https://datoporn.co/"+match[0], name, download)
        return
    
    match = re.compile('<iframe src=\"https://(embed\.redtube\.com/\?|datoporn\.co/|www\.pornhub\.com/embed/)([^>]+)\"></iframe>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    if match:
        for hoster, iframestring in match:
            embed_url_string = '<iframe src=\"https://' + hoster + iframestring + "></iframe>"
            Log("embed_url_string='{}'".format(embed_url_string))
            embed_url_string = urllib.quote_plus(embed_url_string)
            Log("embed_url_string='{}'".format(embed_url_string))

            from requests import Request, Session
            s = Session()
            headers = {"User-Agent": utils.USER_AGENT
                       , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                       , "Referer": url
                       }
            data = "action=ctpl_load_player&iframe_index=1&iframe_tag=" + embed_url_string

            req = Request('POST', url, data=data, headers=headers)
            prepped = s.prepare_request(req)
            proxies = {"http": "127.0.0.1:8888"}
            resp = s.send(prepped , proxies=proxies , verify=False)
            Log(resp.status_code)

            Log("resp.content='{}'".format(repr(resp.content)))

            import json
            json_newurl = json.loads(resp.content)['new_content']
            #Log("json_newurl='{}'".format(json_newurl))

            match = None
            match_720 = re.compile('src=\"([^\"]+)\".*?\"720p\"', re.DOTALL | re.IGNORECASE).findall(json_newurl)
            match_480 = re.compile('src=\"([^\"]+)\".*?\"480p\"', re.DOTALL | re.IGNORECASE).findall(json_newurl)
            match_240 = re.compile('src=\"([^\"]+)\".*?\"240p\"', re.DOTALL | re.IGNORECASE).findall(json_newurl)
            match_XXX = re.compile('src=\"([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(json_newurl)
            
            if match_720: match = match_720[0]
            elif match_480: match = match_480[0]
            elif match_240: match = match_240[0]
            elif match_XXX: match = match_XXX[0]
            
            if match:
                utils.playvid(match, name, download)
            else:
                utils.notify('Oh oh','Couldn\'t find a video')
            
                                                                                                                 
        return
    #else:
        #Log(cathtml)
    #    return
    
    if not match1:
        #old style
        #b4 2019-02-05 this was all that was required
        utils.PLAYVIDEO(url, name, download)        
        return
 

    #2019-02-05 style..
    referer = match1[0]
    Log("referer='{}'".format(referer))
    
    match2 = re.compile('itemprop="embedURL" content="([^&]+)&', re.DOTALL | re.IGNORECASE).findall(cathtml)
    Log("match2='{}'".format(match2))
    begin_url = match2[0].split('id=')[0]
    id_url = match2[0].split('id=')[1]

    #Log("match2[0]='{}'".format(match2[0]))

    #... reverse the string
    videourl = begin_url + 'ir=' + id_url[::-1]
    Log("videourl='{}'".format(videourl))

    #add required headers 
    headers = { 'Referer': referer , 'User-Agent': utils.USER_AGENT}
    
    #videourl_with_headers = "{}{}&Referer={}".format(videourl, utils.Header2pipestring(), referrer)
    videourl_with_headers = "{}|{}".format(videourl, urllib.urlencode(headers))
    Log("videourl_with_headers="+videourl_with_headers)

    req = urllib2.Request(videourl)
    req.add_header('Referer', referer)
    req.add_header('User-Agent', utils.USER_AGENT)
    
    response = urllib2.urlopen(req, timeout=60)
    location = response.info().get('Location')
    Log(  repr(response) )
    Log(response.geturl())
    utils.playvideo(response.geturl(), name, download=download, url=videourl)
    


    return

    #b4 2019-02-05 this was all that was required
    utils.PLAYVIDEO(url, name, download)
