'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import re
import sys
import random
import urllib

import inputstreamhelper
import time

try:     import simplejson
except:  import json as simplejson   

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib import websocket

import socket

__user_agent__ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"

import xbmcaddon
ADDON=xbmcaddon.Addon()


MAX_READ_COUNT = 20
CAMGIRLSERVER = None
CAMGIRLCHANID = None
CAMGIRLUID = None
CAMGIRL = None
CXID = None
CTXENC = None
TKX = None
PLATFORM_ID = None

FCUOPT_PLATFORM_MFC = 1
FCUOPT_PLATFORM_CAMYOU = 2
        
def log(msg='', loglevel=xbmc.LOGERROR):
    debug = None
    try:
        debug = (ADDON.getSetting('debug').lower() == "true")
    except Exception,e:
        xbmc.log(str(e) , xbmc.LOGNONE)
        debug = False
        
    if debug == True:
        xbmc.log(msg , xbmc.LOGNONE)
    else:
        xbmc.log(msg)


@utils.url_dispatcher.register('270')
def Main():
    List('https://www.myfreecams.com/mfc2/php/online_models_splash.php')


@utils.url_dispatcher.register('271', ['url'])
def List(url):
    try: listhtml = utils.getHtml2(url)
    except: return None

    match = re.compile("model_detail=(.*?)&.*?img src=(.*?)jpg.*?</div>", re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, img in match:
        url = name
        name = utils.cleantext(name)
        img = img + 'jpg'
        img = img.replace('90x90','300x300')
        utils.addDownLink(name, url, 272, img, '', stream=True, noDownload=True)

##        u = (sys.argv[0] +
##             "?url=" + urllib.quote_plus(url) +
##             "&mode=272" +
##             "&name=" + urllib.quote_plus(name) +
##             "&handle={}".format(sys.argv[1])         )
##        li = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=img)
##        li.setArt({'thumb': img, 'icon': img})
##        li.setArt({'poster': img})
##        li.setProperty("IsPlayable","true")
##        li.setInfo(type="Video", infoLabels={"Title": name})
##        video_streaminfo = {'codec': 'h264'}
##        li.addStreamInfo('video', video_streaminfo)
##
##        contextMenuItems = []
##        contextMenuItems.append(('[COLOR hotpink] favorites[/COLOR]', 'xbmc.RunPlugin(+favorite+)'))
##        contextMenuItems.append(('[COLOR hotpink]Download Video[/COLOR]', 'xbmc.RunPlugin(+dwnld+)'))
##        li.addContextMenuItems(contextMenuItems, replaceItems=False)
##        xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, isFolder=False )

    #log ("List: utils.addon_handle {}".format( int(sys.argv[1]) ))
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

@utils.url_dispatcher.register('272', ['url', 'name'])
def Playvid(url, name):
    log ("Playvid sys.argv='{}'; utils.addon_handle='{}'; ".format( sys.argv[1], utils.addon_handle )  )
    #return
    videourl = myfreecam_start(url)
    if videourl:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")

        listitem = xbmcgui.ListItem(path=videourl)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})

        if  videourl.endswith('.mpd') or ('.m3u8'  in videourl):
            is_helper = inputstreamhelper.Helper('mpd')
            listitem.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            listitem.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+__user_agent__)
            
            if  videourl.endswith('.mpd'):
                listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            else:
##                from F4mProxy import f4mProxyHelper
##                f4mp=f4mProxyHelper()
##                f4mp.playF4mLink(
##                    videourl
##                    , name
##                    , proxy = None
##                    , use_proxy_for_chunks = False
##                    , maxbitrate = 0
##                    , simpleDownloader = False
##                    , auth = None
##                    , streamtype = 'HLSREDIR'
##                    , setResolved = False
##                    , swf = None
##                    , callbackpath = ""
##                    , callbackparam = ""
##                    , iconImage = iconimage )
                ##return
                log ("HLS:'.mpd') or ('.m3u8'")
                listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
                

        log ("Playvid sys.argv='{}'; utils.addon_handle='{}'; ".format( sys.argv[1], utils.addon_handle )  )
        if int(sys.argv[1]) == -1:
            log ("no handle")
            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            pl.clear()
            pl.add(videourl, listitem)
            xbmc.Player().play(pl)
        else:
            log ("yes handle")
            xbmcplugin.setResolvedUrl( utils.addon_handle , True, listitem)
    #else:
        #utils.notify('Oh oh','Couldn\'t find a playable webcam link')
        
        
vs_str={}
vs_str[0]="PUBLIC"
vs_str[2]="AWAY"
vs_str[12]="PVT"
vs_str[13]="GROUP"
vs_str[90]="CAM OFF"
vs_str[127]="OFFLINE"
vs_str[128]="TRUEPVT"

def valid_info():
    if CAMGIRLSERVER < 0 :
        log('valid_info: missing camgirlserver')
        return False
    if CAMGIRLCHANID < 0:
        log('valid_info: missing CAMGIRLCHANID')
        return False
    if CAMGIRLUID < 0:
        log('valid_info: missing CAMGIRLUID')
        return False
    if not CAMGIRL:
        log('valid_info: missing CAMGIRL')
        return False
    if not CXID:
        log('valid_info: missing CXID')
        return False
    if not CTXENC:
        log('valid_info: missing CTXENC')
        return False
    if not TKX:
        log('valid_info: missing TKX')
        return False
    if not PLATFORM_ID:
        log('valid_info: missing PLATFORM_ID')
        return False

    return True
    
def fc_decode_json(m):
    try:
        m = m.replace('\r', '\\r').replace('\n', '\\n')
        return simplejson.loads(m[m.find("{"):].decode("utf-8","ignore"))
    except:
        return simplejson.loads("{\"lv\":0}")

def read_model_data(m, camgirl_to_find):
    global CAMGIRLSERVER
    global CAMGIRLCHANID
    global CAMGIRLUID
    global CAMGIRL
    global CXID
    global CTXENC
    global TKX
    global PLATFORM_ID

    msg = fc_decode_json(m)
    log( "msg:%s" % simplejson.dumps(msg) )

    try:
        if msg['uid'] == 0:
            return # these lines don't have any more useful information    
    except:
        pass

    try:
        CXID = msg['cxid']
        CTXENC = urllib2.unquote(msg['ctxenc'])
        TKX = msg['tkx']
        return # these lines don't have any more useful information
    except:
        pass

    try:
        if camgirl_to_find == msg['nm']:
            CAMGIRL = msg['nm'] #make sure we know who we are talking to:  'nm' can exist multiple places
    except:
        return
    
    if CAMGIRL:

        #vs = visibility status; 0 value means in public chat...don't know how to parse group/private chats
        vs = msg['vs']
        if vs != 0:
            vs_string=vs_str[vs]
            log("visibility status:{} {}".format(vs,vs_string) )

            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            CAMGIRLCHANID = -1
            CAMGIRLUID = -1
    
            return

        CAMGIRLUID    = msg['uid']
        PLATFORM_ID   = msg['pid']
        if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
            CAMGIRLCHANID = msg['uid'] + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
        else:
            CAMGIRLCHANID = msg['uid'] + 100000000  #1e8 means public chat; there is also 2e8 and 4e8

        u_info=msg['u']
        try:
            CAMGIRLSERVER = u_info['camserv']
            if CAMGIRLSERVER >= 1545 and CAMGIRLSERVER <= 1559:
                CAMGIRLSERVER = CAMGIRLSERVER - 1000
            elif CAMGIRLSERVER >= 500:
                CAMGIRLSERVER = CAMGIRLSERVER - 500
        except KeyError:
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            pass
        except Exception, e:
            #log(('parsing msg dictionary for name:%s' % str(e) ), xbmc.LOGERROR)
            pass

def getChatServerWebsocket():
    #internal chat server list
    #acutal list at https://m.myfreecams.com/configproxy.php
    xchat=[
        20, 22, 23, 24, 25, 28, 29,
        30, 31, 32, 33, 34, 35, 36, 39,
        42, 43, 44, 45, 46, 47, 48, 49,
        50, 51, 52, 53, 54, 58, 59, 
        60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
        70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
        80, 81, 83, 84, 85, 86, 87, 88, 89,
        90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
        100, 101, 102, 103, 104, 105, 106, 109,
        111, 112, 113, 114, 115, 116, 118, 119,
        120, 121, 122, 123, 124, 125, 126, 127
      ]

    #connect to one of the chat servers; random since we don't know how to parse page
    #we need to use 8080 because the other choice, https, does not work with websocket

    ws = None
    failed_count = 0
    failed_count_max = 11
    while not ws and (failed_count < failed_count_max):
        try: 
            server_number = str(random.choice(xchat))
            host = "ws://xchat"+server_number+".myfreecams.com:8080/fcsl"
            log("connecting to host '{}'".format(host) )
            ws = None
            ws = websocket.WebSocket()
            ws = websocket.create_connection(host)
            ws.send("hello fcserver\n\0")
            ws.send("1 0 0 20071025 0 guest:guest\n\0")
            return ws
        except Exception, e:
            failed_count += 1
            log("xchat server '{}' could not be opened [{}]".format(repr(e), failed_count))
            ws = None

def getCamgirlInfo(camgirl_to_find):

    log("\n getCamgirlInfo {} \n".format(camgirl_to_find))
    global CAMGIRLCHANID
    global CAMGIRLSERVER
    global CAMGIRLUID
    global CAMGIRL

    CAMGIRLCHANID = None
    CAMGIRLSERVER = None
    CAMGIRLUID = None
    CAMGIRL = None

    rembuf=''
    sock_buf=None
    quitting = 0
    fc_type = None
    fc=None
    readcount = 0

    mfcServerWebsocket = getChatServerWebsocket() #I tried recycling websocket via caller, but inconsistent results
    mfcServerWebsocket.send("10 0 0 0 0 %s\n\0" % camgirl_to_find)

    while quitting == 0:
        
        sock_buf = mfcServerWebsocket.recv()
        rembuf=''
        readcount = readcount+1
        if readcount > MAX_READ_COUNT: break
        while True:
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX
            log(sock_buf)
            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            if bool(hdr) == 0:
                log("recv() again")
                break #recv() again for the response we need

            fc = hdr.group(1)
            mlen   = int(fc[0:4])
            msg=sock_buf[4:4+mlen]
            if len(msg) < mlen:
                log("len(msg) < mlen")
                rembuf=''.join(sock_buf)
                break
            
            read_model_data(urllib.unquote(msg), camgirl_to_find) 

            if CAMGIRL == camgirl_to_find:
                quitting=1
                break

            sock_buf=sock_buf[4+mlen:]
            if len(sock_buf) == 0:
                break

    newServer = (CAMGIRLSERVER >= 545 and CAMGIRLSERVER <= 559) #HLS servers

    if readcount > MAX_READ_COUNT:
        utils.notify(msg= "{} was not found.  Maybe renamed".format(camgirl_to_find), duration=10000, sound=False)

    log("\n getCamgirlInfo RETURN {},{},{},{}\n ".format(camgirl_to_find, CAMGIRLSERVER, CAMGIRLCHANID,newServer))

    try:
        mfcServerWebsocket.close()
    except:
        pass
    
    return CAMGIRLSERVER, CAMGIRLCHANID, newServer


def myfreecam_start(camgirl_to_find):

    log ("utils.addon_handle {}".format( int(sys.argv[1]) ))
    
    ws = getChatServerWebsocket()

    rembuf=""
    quitting = 0
    readcount = 0
    
    ws.send("10 0 0 20 0 %s\n\0" % camgirl_to_find)
    
    while quitting == 0:
        
        readcount = readcount + 1
        if readcount > MAX_READ_COUNT: break

        sock_buf =  ws.recv()
        sock_buf = rembuf + sock_buf
        
        rembuf=""
        while True:
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX

            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            if bool(hdr) == 0:
                log ("bool(hdr) == 0:")
                break #recv() again for the response we need

            fc = hdr.group(1)
            mlen   = int(fc[0:4])
            fc_type = int(fc[4:]) #the fourth byte is the type we need

            msg=sock_buf[4:4+mlen]
            if len(msg) < mlen:
                rembuf=''.join(sock_buf)
                log ("len(msg) < mlen")
                break

            read_model_data( urllib.unquote(msg) , camgirl_to_find) 

##            log("fc_type '{}' was found".format(fc_type))
##            if fc_type == 1:
##                ws.send("10 0 0 20 0 %s\n\0" % camgirl_to_find)
##                log("fc_type 1 was found")
##            elif fc_type == 10:
##                #read_model_data(msg) # ?????we need two read_model_data to capture the ctxenc information
##                #time.sleep(0.1)
##                quitting=1

            if valid_info():
                quitting=1
                break

            if CAMGIRLSERVER == -1:
                quitting=1
                break

            sock_buf=sock_buf[4+mlen:]
            if len(sock_buf) == 0:
                log ("len(sock_buf) == 0:")
                break

    ws.close()

    if readcount > MAX_READ_COUNT:
        utils.notify(msg= "{} was not found.  Maybe renamed".format(camgirl_to_find), duration=10000, sound=False)
        return ''
    
    if not valid_info() or (CAMGIRLSERVER < 1) :
        utils.notify( ("{} is not online".format(camgirl_to_find)))
        return ''

    try:

        head = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"

        #try new servers
        Url="https://video{}.myfreecams.com:8444/x-hls/{}/{}/{}/mfc_a_{}.m3u8".format(
            CAMGIRLSERVER
            , CXID
            , CAMGIRLCHANID
            , CTXENC
            , CAMGIRLCHANID
            ) 
        log('attempt connecting to HLS host {}|User-Agent={}'.format(Url,head))
        req = urllib2.Request(Url)
        req.add_header('User-Agent', head)
        try:
            aa = urllib2.urlopen(req, timeout=3)
            Url = Url +('|user-agent='+head)
            log('returning URL ' + Url)
            utils.notify(msg= "{} is HQ".format(camgirl_to_find), duration=10000, sound=False)
            return Url
        except Exception, e:
            log("exception '{}' opening url '{}' ".format(repr(e),Url))
            #utils.notify( 'Oh oh', ("URL for {} is not responding".format(CAMGIRL)))
            Url = ''


        #mobile site
        Url="http://video"+str(CAMGIRLSERVER)+".myfreecams.com:1935/NxServer/ngrp:mfc_"+str(CAMGIRLCHANID)+".f4v_mobile/playlist.m3u8" 
        if CAMGIRLSERVER == 438 or CAMGIRLSERVER == 439: server439hack = "_a"
        else: server439hack = ""

        if PLATFORM_ID == FCUOPT_PLATFORM_MFC:
            Url="https://video{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8".format(CAMGIRLSERVER,server439hack,CAMGIRLCHANID)
        elif PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
            #    https://video843.camyou.com/NxServer/ngrp:cam_423584950.f4v_desktop/manifest.mpd HTTP/1.1
            #rl 'https://video843.camyou.com/NxServer/ngrp:cam_         .f4v_desktop/manifest.mpd'
            Url="https://video{}.camyou.com/NxServer/ngrp:cam_{}.f4v_desktop/manifest.mpd".format(CAMGIRLSERVER,CAMGIRLCHANID)

        #Url="http://video"+str(CAMGIRLSERVER)+".myfreecams.com:1935/NxServer/ngrp:pvt_"+str(1e8 + CAMGIRLCHANID)+"_1.f4v_mobile/playlist.m3u8" 

        log('attempt connecting to host {}|{}'.format(Url,head))
        req = urllib2.Request(Url)
        req.add_header('User-Agent', head)
        try:
            aa = urllib2.urlopen(req, timeout=2)
            log("aa contents '%s' " % aa.read().encode('UTF-8'))
            return Url
        except Exception, e:
            log("exception '{}' opening url '{}' ".format(repr(e),Url))
            Url = ""

        if Url == '':
            utils.notify( 'Oh oh', ("URL for {} is not responding".format(camgirl_to_find)))
                    
    except Exception, e:
        log(('attempt connecting to err:%s' % str(e) ), xbmc.LOGERROR)
        return ''

    utils.notify( ("{} is not online".format(camgirl_to_find)))
    return Url
