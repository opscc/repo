'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import sqlite3
import xbmc

import threading
import Queue

from resources.lib import utils
from resources.lib.utils import Log as Log
from xbmc import LOGNONE
from resources.lib import constants as C

from sites.chaturbate import ROOT_URL as chaturbate_ROOT_URL
from sites.chaturbate import PLAY_MODE as chaturbate_PLAY_MODE
from sites.chaturbate import clean_database as chaturbate_clean
from sites.chaturbate import GetCamgirlList as chaturbate_getCamgirlList

from sites.cam4 import ROOT_URL as cam4_ROOT_URL
from sites.cam4 import PLAY_MODE as cam4_PLAY_MODE
from sites.cam4 import clean_database as cam4_clean
from sites.cam4 import GetCamgirlList as cam4_GetCamgirlList

from sites.streamate import ROOT_URL as streamate_ROOT_URL
from sites.streamate import PLAY_MODE as streamate_PLAY_MODE
from sites.streamate import clean_database as streamate_clean
from sites.streamate import GetCamgirlList as streamate_GetCamgirlList

from sites.naked import ROOT_URL as naked_ROOT_URL
from sites.naked import PLAY_MODE as naked_PLAY_MODE
from sites.naked import clean_database as naked_clean
from sites.naked import GetCamgirlList as naked_GetCamgirlList

from sites.bongacams import ROOT_URL as bongacams_ROOT_URL
from sites.bongacams import PLAY_MODE as bongacams_PLAY_MODE
from sites.bongacams import clean_database as bongacams_clean
from sites.bongacams import GetCamgirlList as bongacams_GetCamgirlList

from sites.myfreecams import ROOT_URL as mfc_ROOT_URL
from sites.myfreecams import PLAY_MODE as mfc_PLAY_MODE
from sites.myfreecams import getCamgirlList as mfc_getCamgirlList
from sites.myfreecams import getCamgirlInfo as getCamgirlInfo
from sites.myfreecams import clean_database as mfc_clean

import time
import traceback

favoritesdb = C.favoritesdb


#__________________________________________________________________
#
##@utils.url_dispatcher.register(REFRESH_IMAGES_MODE)
def RefreshImages():
    chaturbate_clean(False)
    cam4_clean(False)
    naked_clean(False)
    mfc_clean(False)
    streamate_clean(False)
    bongacams_clean(False)


#__________________________________________________________________
#
@C.url_dispatcher.register(C.REFRESH_CONTAINER_MODE)  
def RefreshContainter():
    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________
#
def threaded(f, daemon=False):
    #import Queue
    #import threading
    def wrapped_f(q, *args, **kwargs):
        ##this function calls the decorated function and puts the result in a queue
        ret = f(*args, **kwargs)
        q.put(ret)
    def wrap(*args, **kwargs):
        ##this is the function returned from the decorator. It fires off
        ##wrapped_f in a new thread and returns the thread object with
        ##the result queue attached
        q = Queue.Queue()
        t = threading.Thread(target=wrapped_f, args=(q,)+args, kwargs=kwargs)
        t.daemon = daemon
        t.start()
        t.result_queue = q        
        return t
    return wrap

@threaded
def internal_bongacams_GetCamgirlList(depth, notify):
    return bongacams_GetCamgirlList(depth=depth, notify=notify)
@threaded
def internal_naked_GetCamgirlList(depth, notify):
    return naked_GetCamgirlList(depth=depth, notify=notify)
@threaded
def internal_streamate_GetCamgirlList(depth, notify):
    return streamate_GetCamgirlList(depth=depth, notify=notify)
@threaded
def internal_cam4_GetCamgirlList(depth, notify):
    return cam4_GetCamgirlList(depth=depth, notify=notify)
@threaded
def internal_chaturbate_GetCamgirlList(depth, notify):
    return chaturbate_getCamgirlList(depth=depth, notify=notify)
@threaded
def internal_mfc_GetCamgirlList(depth, notify):
    return mfc_getCamgirlList(notify=False)


#__________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_FAVORITES)  
def List():

    if C.addon.getSetting("auto_clean_img_database").lower() == "true":
        RefreshImages()

    manually_refresh_favorites = (C.addon.getSetting("manually_refresh_favorites").lower() == "true")
    play_method = str(C.addon.getSetting("default_playmode").lower())

    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    favDB_cursor = conn.cursor()
    try:
        favDB_cursor.executescript("CREATE TABLE IF NOT EXISTS favorites (name, url, mode, image);")
        favDB_cursor.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
    except:
        pass


##    conn = sqlite3.connect(favoritesdb)
##    conn.text_factory = str
##    c = conn.cursor()

    utils.addDir(
        name="{}[COLOR {}]Refresh[/COLOR]".format(C.SPACING_FOR_TOPMOST, C.refresh_text_color)
        ,url='' 
        ,mode=C.REFRESH_CONTAINER_MODE 
        ,iconimage=C.refresh_icon
        ,duration=1 #55*60*60+55*60+55 #duration so that when sorting by duration, refresh shows after active webcams
        ,Folder=False )

    try:

        try:
            bongacams_girls = None #when testing
            t_bongacams = None
            bongacams_girls_favorites = (C.addon.getSetting("bongacams_girls_favorites").lower() == "true")
            if bongacams_girls_favorites:
##                bongacams_girls, online_count = bongacams_GetCamgirlList(depth=2, notify=False)
                t_bongacams = internal_bongacams_GetCamgirlList(depth=2, notify=False)
        except: traceback.print_exc()
        try:
            naked_girls = None
            t_naked = None
            naked_girls_favorites = (C.addon.getSetting("naked_girls_favorites").lower() == "true")
            if naked_girls_favorites:
    ##                naked_girls = naked_GetCamgirlList(depth=2, notify=False)
                t_naked = internal_naked_GetCamgirlList(depth=2, notify=False)
        except: traceback.print_exc()
        try:
            streamate_girls = None
            t_streamate = None
            streamate_girls_favorites = (C.addon.getSetting("streamate_girls_favorites").lower() == "true")
            if streamate_girls_favorites:
##                streamate_girls = streamate_GetCamgirlList(depth=2, notify=False)
                t_streamate = internal_streamate_GetCamgirlList(depth=2, notify=False)
        except: traceback.print_exc()
        try:
            cam4_girls = None
            t_cam4 = None
            cam4_girls_favorites = (C.addon.getSetting("cam4_girls_favorites").lower() == "true")
            if cam4_girls_favorites:
##                cam4_girls = cam4_GetCamgirlList(notify=False)
                t_cam4 = internal_cam4_GetCamgirlList(depth=2, notify=False)
        except: traceback.print_exc()
        try:
            chaturbate_girls = None #when testing
            t_chaturbate = None #when testing
            chaturbate_girls_favorites = (C.addon.getSetting("chaturbate_girls_favorites").lower() == "true")
            if chaturbate_girls_favorites:
##                chaturbate_girls = chaturbate_getCamgirlList(depth=3, notify=False)
                t_chaturbate = internal_chaturbate_GetCamgirlList(depth=3, notify=False)
        except: traceback.print_exc()
        try:
            mfc_girls = None #when testing
            t_mfc = None #when testing
            mfc_girls_favorites = (C.addon.getSetting("mfc_girls_favorites").lower() == "true")
            if mfc_girls_favorites:
##                mfc_girls = mfc_getCamgirlList(notify=True) #note: slower than most
                t_mfc = internal_mfc_GetCamgirlList(depth=None, notify=True)
        except: traceback.print_exc()


        try:        
            if t_bongacams:    (bongacams_girls, online_count) = t_bongacams.result_queue.get(timeout=C.FAVORITE_LISTING_TIMEOUT)
            if t_naked:            naked_girls = t_naked.result_queue.get(timeout=C.FAVORITE_LISTING_TIMEOUT)
            if t_streamate:    streamate_girls = t_streamate.result_queue.get(timeout=C.FAVORITE_LISTING_TIMEOUT)
            if t_cam4:              cam4_girls = t_cam4.result_queue.get(timeout=C.FAVORITE_LISTING_TIMEOUT)
            if t_chaturbate:  chaturbate_girls = t_chaturbate.result_queue.get(timeout=C.FAVORITE_LISTING_TIMEOUT)
            if t_mfc:                mfc_girls = t_mfc.result_queue.get(timeout=C.FAVORITE_LISTING_TIMEOUT)
        except Queue.Empty:
            pass
        except:
            traceback.print_exc()
            
            
        
        favDB_cursor.execute("SELECT * FROM favorites")        
        for (name, url, mode, img) in favDB_cursor.fetchall():
            
            try:

##                Log("name='{}',url='{}',mode='{}',img='{}'".format(name, url, mode, img))
                
                if cam4_girls and str(mode)==cam4_PLAY_MODE :
                    root_url = cam4_ROOT_URL
                    model_found = False
                    for model in cam4_girls:
                        if name == model["username"]:
                            model_found = True
                            break
                    if model_found:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(C.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = C.DEFAULT_PLAYMODE
                        model['description'] = root_url
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        )

                elif bongacams_girls and str(mode)==bongacams_PLAY_MODE :
                    root_url = bongacams_ROOT_URL
                    model_found = False
##                    Log(repr(bongacams_girls))
                    for model in bongacams_girls:
                        if name == model["username"]:
                            model_found = True
                            break
                    if model_found:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(C.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = C.DEFAULT_PLAYMODE
                        model['description'] = root_url
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        )

                elif naked_girls and str(mode)==naked_PLAY_MODE :
                    root_url = naked_ROOT_URL
##                    Log("name='{}',url='{}',mode='{}',img='{}'".format(name, url, mode, img))
####                    model_found = False
##                    for model in naked_girls:
##                        if name == model:
##                            Log("'{}'".format(naked_girls[model]))
##                            model_found = True
##                            Log("name='{}',url='{}',mode='{}',img='{}'".format(name, url, mode, img))
##                            break
####                    if model_found:
                    
                    # trying two ways to do this, not sure which is better
                    # naked_girls as a list [6 lines, used in the other items], or naked_girls as a dictionary [4 lines]
                    model = None
                    if name in naked_girls:
                        model = naked_girls[name]
                        Log("'{}'".format(model))
                    if model:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(C.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = C.DEFAULT_PLAYMODE
                        model['description'] = root_url
                        model['video_host'] = None
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        , hq_stream = model['video_host']
                        )
                    
                elif streamate_girls and str(mode)==streamate_PLAY_MODE :
                    root_url = streamate_ROOT_URL
                    model_found = False
                    for model in streamate_girls:
                        if name == model["username"]:
                            model_found = True
                            break
                    if model_found:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(C.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = C.DEFAULT_PLAYMODE
                        model['description'] = root_url
                        model['username'] = ''
                        
                    utils.addDownLink( 
                        name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        , date = model['username']
                        )
                    


                elif chaturbate_girls and str(mode)==chaturbate_PLAY_MODE :

##                    Log("name='{}',url='{}',mode='{}',img='{}'".format(name, url, mode, img))


                    root_url = chaturbate_ROOT_URL
                    model_found = False
                    for model in chaturbate_girls:
                        if name == model["username"]:
                            model_found = True
                            break
                    if model_found:
                        model['icon_label'] = "[COLOR {}]{}[/COLOR]".format(C.search_text_color,model['username'])
                    else:
                        model = {}
                        model['icon_label'] = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        model['play_method'] = C.DEFAULT_PLAYMODE
                        model['description'] = root_url
                        model['username'] = ''
                        
                    utils.addDownLink( 
                         name = model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = model['play_method']
                        , fav = 'del'
                        , desc = model['description']
                        )

                elif str(mode)==mfc_PLAY_MODE:
                    icon_added = False
                    root_url = mfc_ROOT_URL

                    model_id_via_image = "00000000"
##                        Log("img={}".format(repr(img)), xbmc.LOGNONE)
                    if "/img.mfcimg.com/" in img or "/snap.mfcimg.com/" in img :
                        model_id_via_image = img.split('/')[6]
##                            Log("model_id_via_image={}".format(repr(model_id_via_image)), xbmc.LOGNONE)
                        if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                            model_id_via_image = img.split('/')[5]
                        #the 1 indicates model was in public chat when bookmark created
                        if model_id_via_image.startswith("mfc_a_1"):
                           model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
                        if model_id_via_image.startswith("mfc_1"):
                           model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
                        if model_id_via_image[0] == '0':
                            model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front

                    if mfc_girls:
                               
                        serverNumber, modelID, hq_stream, camscore, icon_img, icon_label, current_model_name = getCamgirlInfo(name, mfc_girls, model_id_via_image)
                        if not camscore: camscore=0 #None values make later code more complex

                        #site allows easy name changes, but no searching via id; 
                        if current_model_name: 
                            if current_model_name != name: #automatically refresh name in fav database
                                Favorites("refresh", mode, current_model_name, current_model_name, img)
                        
##                        Log("name={},serverNumber={},modelID={},hq_stream={},camscore={},icon_img={},icon_label={}".format(name,serverNumber,modelID,hq_stream,camscore, icon_img, icon_label))
                        if serverNumber > 0: #    if model server found; an online/active image can be used
                            utils.addDownLink(
                                name = icon_label
                                , url = url
                                , mode = mode
                                , iconimage = icon_img
                                , fav = 'del'
                                , duration=str(int(camscore))
                                , play_method=C.DEFAULT_PLAYMODE
                                , hq_stream=hq_stream
                                , desc = root_url
                                )
                            icon_added = True
                            
                    if icon_added == False:  #else use default avatar image 
                        img = "https://img.mfcimg.com/photos2/{}/{}/avatar.300x300.jpg".format(model_id_via_image[:3], model_id_via_image)
                        utils.addDownLink(
                            name = name
                            , url = url
                            , mode = mode
                            , iconimage = img
                            , fav = 'del'
                            , duration='0'
                            , desc = root_url
                            )
                else:
##                    Log("name='{}',url='{}',mode='{}',img='{}'".format(name, url, mode, img))
                    utils.addDownLink(
                        name=name.strip()
                        , url=url
                        , mode = mode
                        , iconimage = img
                        , fav ='del'
                        )

            except:
                traceback.print_exc()
        
    except :
        traceback.print_exc()
        utils.notify('No Favorites found')

    if conn: conn.close()
    
    utils.endOfDirectory(cacheToDisc=( manually_refresh_favorites==True) )
#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_MODE, ['fav','favmode','name','url','img'])  
def Favorites(fav,favmode,name,url,img):
##    Log("name='{}',url='{}',img='{}'".format(name, url, img), LOGNONE)
    if fav in ["add","refresh"]:
        delFav(url, img)
        normalized_name = addFav(favmode, name, url, img)
        utils.Notify("{}ed fav:'{}' url:{}".format(fav.capitalize(),normalized_name,url))
    elif fav == "del":
        delFav(url, img)
        utils.Notify("Deleted fav:{} url:{}".format(name,url))
#__________________________________________________________________
#
##def clean_filename(s):
##    if not s:
##        return ''
##    s = re.sub(u'(?is)[^A-Za-z0-9~_\]\[ \/,\'.&]','',s)
##    return s.strip();
#__________________________________________________________________
#
def addFav(mode,name,url,img):
    n_bak = name
    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on

    import downloader
    name = downloader.Clean_Filename(name)
    if name in [None,'']: raise Exception("invalid name '{}'".format(n_bak))
##    Log("name='{}'".format(name))
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    favDB_cursor = conn.cursor()
    favDB_cursor.execute("INSERT INTO favorites VALUES (?,?,?,?)", (name, url, mode, img))
    conn.commit()
    conn.close()
    return name
#__________________________________________________________________
#
def delFav(url, img):
    conn = sqlite3.connect(favoritesdb)
    favDB_cursor = conn.cursor()
    favDB_cursor.execute("DELETE FROM favorites WHERE url = '%s'" % url)
    if not img in (None,'','None','none','%'): #try deleting via image for site where name is easily changable
        if "|" in img: img = img.split("|")[0]
        if "?" in img: img = img.split("?")[0]
        sql_command = "DELETE FROM favorites WHERE image LIKE '{}%'".format(img)
##        Log("sql_command='{}'".format(sql_command), LOGNONE)
        favDB_cursor.execute(sql_command)
    conn.commit()
    conn.close()
#__________________________________________________________________
#
