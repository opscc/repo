'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils
 

@utils.url_dispatcher.register('150')
def HQMAIN():
    utils.addDir('[COLOR hotpink]Categories[/COLOR]','http://hqporner.com/porn-categories.php',153,'','')
    utils.addDir('[COLOR hotpink]Studios[/COLOR]','http://hqporner.com/porn-studios.php',153,'','')
    utils.addDir('[COLOR hotpink]Girls[/COLOR]','http://hqporner.com/porn-actress.php',153,'','')
    utils.addDir('[COLOR hotpink]Search[/COLOR]','http://hqporner.com/?s=',154,'','')
    HQLIST('http://hqporner.com/hdporn/1')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('151', ['url'])
def HQLIST(url):
    try:
        link = utils.getHtml(url, '')
    except:
        return None
    match = re.compile('<a href="([^"]+)" class="image featured non-overlay".*?<img id="[^"]+" src="([^"]+)" alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(link)
    for url, img, name in match:
        name = utils.cleantext(name)    
        videourl = "http://www.hqporner.com" + url
        utils.addDownLink(name, videourl, 152, 'https:' + img, '')
    try:
        nextp=re.compile('<a href="([^"]+)"[^>]+>Next', re.DOTALL | re.IGNORECASE).findall(link)
        nextp = "http://www.hqporner.com" + nextp[0]
        utils.addDir('Next Page', nextp,151,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('153', ['url'])
def HQCAT(url):
    link = utils.getHtml(url, '')
    tags = re.compile('<a href="([^"]+)"[^<]+<img src="([^"]+)" alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(link)
    tags = sorted(tags, key=lambda x: x[2])
    for caturl, catimg, catname in tags:
        caturl = "http://www.hqporner.com" + caturl
        catimg = "http://www.hqporner.com" + catimg        
        utils.addDir(catname,caturl,151,catimg)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('154', ['url'], ['keyword'])
def HQSEARCH(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 154)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        HQLIST(searchUrl)


@utils.url_dispatcher.register('152', ['url', 'name'], ['download'])
def HQPLAY(url, name, download=None):
    print ('LMM HQPLAY ' + str(url))
    videopage = utils.getHtml(url, url)
    iframeurl = re.compile(r"nativeplayer\.php\?i=([^']+)", re.DOTALL | re.IGNORECASE).findall(videopage)
    if not (iframeurl[0].startswith('http')):
        iframeurl = 'https:' + iframeurl[0]
    print ('LMM iframeurl ' +  iframeurl)

    #if re.search('hqporner', iframeurl[0], re.DOTALL | re.IGNORECASE):
    #    videourl = getHQ(iframeurl[0])
    if re.search('bemywife', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)
    elif re.search('mydaddy', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)        
    elif re.search('\/hqwo\.cc\/', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)
    elif re.search('5\.79', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getIP(iframeurl)
    elif re.search('flyflv', iframeurl, re.DOTALL | re.IGNORECASE):
        print ('LMM getFly ' +  iframeurl)
        if (iframeurl.startswith('https:')):
            #apr 2018; https requires authentication for this site, http no
            iframeurl = iframeurl.replace('https://','http://')
            print ('LMM getFly2 ' +  iframeurl)
            
        videourl = getFly(iframeurl)
    else:
        print ('LMM not found' +  iframeurl)
        #print (videopage)
        utils.notify('Oh oh','Couldn\'t find a supported videohost')
        return

    if not videourl:
        print ('LMM not found' +  iframeurl)
        #print (videopage)
        utils.notify('Oh oh','Couldn\'t find a supported videohost')
        return

    if not (videourl.startswith('http')):
        videourl = 'https:' + videourl
        
    utils.playvid(videourl, name, download)


def getBMW(url):
    print ('LMM getbmw ' + str(url))
    videopage = utils.getHtml(url, '')
    #redirecturl = utils.getVideoLink(url, '')
    #videodomain = re.compile("http://([^/]+)/", re.DOTALL | re.IGNORECASE).findall(redirecturl)[0]

    videos = re.compile(r'file: "([^"]+mp4)", label: "\d', re.DOTALL | re.IGNORECASE).findall(videopage)
    try:
        videourl = videos[-2]
    except:
        try:
            videourl = videos[-1]
        except:
            videos = re.compile('src=\'(https\:\S+)\'>', re.DOTALL | re.IGNORECASE).findall(videopage)
            videourl = getIP2(videos[0])
            
    
    return videourl

def getIP2(url):
    print ('LMM getIP2 ' + url)
    videopage = utils.getHtml(url, '')
    videos = re.compile('"file": "(\S+)",', re.DOTALL | re.IGNORECASE).findall(videopage)    
    videourl = videos[-1]
    return videourl


def getIP(url):
    print ('LMM getIP ' + str(url))
    videopage = utils.getHtml(url, '')
    videos = re.compile('file": "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = videos[-1]
    return videourl

def getFly(url):
    print ('LMM getFly ' + str(url))
    videopage = utils.getHtml(url, '')
    print ('LMM getFly gethtml OK')
#    videos = re.compile('fileUrl="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videos = re.compile('src=\'(.*)\' type=', re.IGNORECASE).findall(videopage)

    print ('LMM getFly ' + str(videos))
    videourl = videos[-1]
    print ('LMM getFly ' + str(videourl))

    if not (videourl.startswith('http')):
        videourl = 'http:' + videourl
        
    return videourl
