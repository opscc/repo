'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import json
import re
from resources.lib import utils
from resources.lib import search
from resources.lib.utils import Log as Log
from resources.lib import constants as C
FRIENDLY_NAME = '[COLOR {}]ah-me[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False
ROOT_URL = "https://www.ah-me.com"
##SEARCH_URL = ROOT_URL + '/search/{}/page{}.html'
SEARCH_URL = ROOT_URL + '/search/?q={}&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&category_ids=&sort_by=&from_videos={}'
##URL_CATEGORIES = ROOT_URL + '/channels/'
URL_CATEGORIES = ROOT_URL + '/tags/'
URL_RECENT = ROOT_URL + '/recent/{}/'

MAIN_MODE          = C.MAIN_MODE_ah_me
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1' #default first page
#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url) = utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if "<p>Make sure that all words are spelled correctly.</p>" in listhtml:
        listhtml = ''
        video_region = ''
    else: #distinguish between adverts and videos
        try:
            regex = '(?:class="pages-nav-border"|id="search_results_block")(.+?)(?:class="pages-nav"|id="wrapBlocks")'
            regex = ('<div class=(?:"main-container"|"list-videos")>'
                     '(.+)'
                     'div class="pagination"'
                     )
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
##            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml

    # parse out list items
    regex = 'data-movie.+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)".+?((?:class="icon-hd"|class="to-fav)).+?class="time">([^<]+)<'
    regex = ('a class="item  drclass"'
             '.+?href="([^"]+)"'
             '.+?src="([^"]+)"'
             '.+?alt="([^"]+)"'
             '()'
             '.+?class="duration">([\d\:]+)<'
             
        )
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, hd, duration in info:
        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb = "https:" + thumb
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label={}".format(label))
        utils.addDownLink(name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    
    try:
        regex = 'class="pages-nav">(.+)'
        regex = 'class="pagination-holder(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for
        #'{}'".format(list_url), duration=200) #let user know something is
        #happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = 'href="([^"]+)\.html">Next<'  #site will use display:none if no more pages exist instead of omitting the
                                                    #Next element
    next_page_regex = 'from(?:\_albums|):\d+">Next</a></li>'  #site will use display:none if no more pages exist instead of omitting the
                                                    #Next element

    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else: #for np_url in np_info:
        np_number = int(page) + 1
        np_url = url
        #Log("np_number={}".format(np_number))
        #Log("np_url={}".format(np_url))
        if end_directory == True:
            utils.addDir(name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword)
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log(u"Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page) == C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)
    regex = 'class="thumbs-container"(.+)class="footer'
    regex = (
        'class="list-tags"'
        '(.+)'
        'class="footer-margin"'
             )
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    regex = '<a href="([^"]+)page1\.html".+?src="([^"]+)".+?alt="([^"]+)"'
    regex = ('<a href="([^"]+)"'
             '()'
             '>(.+?)<'
             )
    
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
##        Log(repr((videourl, thumb, label)))
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
##        videourl = videourl + '/page{}.html'
        videourl = videourl + '?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=video_viewed_today&from={}'
###https://www.ah-me.com/tags/anal/?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=video_viewed_today&from=04&_=1702653969167
##        Log("videourl={}".format(videourl))
        utils.addDir(name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb) #C.search_icon)
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile','icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):


    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
##    if playmode_string: max_video_resolution=int(playmode_string)
##    else: max_video_resolution = None
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    download_filespec = ''

    description = name + '\n' + ROOT_URL

    try:
    
        full_html = utils.getHtml(url, ROOT_URL)
        regex = "flashvars.+?license_code:.+?'(?P<lic>[^']+)'"
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
        license_code = sources_list.next().group('lic')
        Log("license_code={}".format(license_code))


    ##    regex = "(?:video_url|video_alt_url.?): '(?P<url>[^']+).+?(?:video_url|video_alt_url.?)_text: '(?P<res>\d+)p'"
        regex = (
            "(?:video_url|video_alXt_url.?): '(?P<url>[^']+)'"
            ".+?(?:video_url_text|video_alt_url.?_text)?: '(?P<res>\d+p?)'")
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
        list_key_value = {}
        for source_list in sources_list:
            if source_list.group('res'):
                list_key_value[source_list.group('res')] = source_list.group('url')
            else:
                list_key_value['240'] = source_list.group('url')
        Log("list_key_value={}".format(list_key_value))

        if len(list_key_value) < 1:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
            return
        
        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
        video_url = utils.SortVideos(
            sources=list_key_value
            ,download=download
            ,vid_res_column=0
            ,max_video_resolution=max_video_resolution
            )

        if video_url.startswith("function/0/"):
            video_url = video_url.split("function/0/")[1]
            Log("video_url={}".format(video_url))

        description = ''
        desc_separator_char = '; '
        regex_tags_region = '"tab_video_info"(.+?)"tab_comments"'
        regex_tags = '/models/.+?title="([^"]+)"'
        region_html = re.compile(regex_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
        if region_html:
            source_tags = re.compile(regex_tags, re.DOTALL | re.IGNORECASE).findall(region_html[0])
            for tag in source_tags:
                if tag.lower() not in description.lower():
                    description = "{}{}{}".format(description,utils.cleantext(tag),desc_separator_char)
        description = description.strip(desc_separator_char)
        if description == '':  description=name + '\n' + ROOT_URL
        else:           description=description + '\n' + ROOT_URL
        Log("description={}".format(description))
        

        from resources.lib import resolver
        fappy_salt = resolver.FaapySalt(license_code, "")
        Log("fappysalt='{}'".format(fappy_salt))
        encoded_fappy_code =  video_url.split('/')[5][0:32]
        Log("encoded_fappy_code='{}'".format(encoded_fappy_code))

        new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
        Log("new_fappy_code='{}'".format(new_fappy_code))
        video_url = video_url.replace(encoded_fappy_code, new_fappy_code)

##        video_url += '?rnd=' + utils.RandomNumber(length=13)
##        #return

##        #video_url += '?rnd=' + utils.RandomNumber(length=13)
##        video_url = video_url + utils.Header2pipestring() + '&Referer=' + url
##        Log("video_url='{}'".format(video_url))

        import time
        video_url += "?rnd={}".format(int(time.time()*1000))

        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        video_url += utils.Header2pipestring(headers)

        Log("video_url='{}'".format(video_url))
        
        utils.playvid(
            video_url
            , name=name
            , download=download
            , description=description
            , playmode_string=playmode_string
            , play_profile=play_profile
##            , download_filespec=download_filespec
            , mode = PLAY_MODE
##            , url_factory = url
            , icon_URI = icon_URI            
            )
        
    except:
        import traceback
        traceback.print_exc()
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        Log("ERROR Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), C.LOGNONE)
        

##    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
##    if playmode_string: max_video_resolution = int(playmode_string)
##    else: max_video_resolution = None
##    description = name + '\n' + ROOT_URL
##    source_html1 = utils.getHtml(url, ROOT_URL)
##    regex = 'data-src="([^"]+\.(?:mp4|flv))"'
##    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
##    Log("sources_list={}".format(sources_list))
##    video_url = sources_list[0]
##    if not video_url:
##        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
##        return
##    headers = C.DEFAULT_HEADERS.copy()
##    headers['Referer'] = url
##    video_url = video_url + utils.Header2pipestring(headers)
##    Log("video_url='{}'".format(video_url))
##    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
