'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import re
import xbmc
from resources.lib import search
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]VIPporns[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.vipporns.com"
SEARCH_URL = ROOT_URL +  "/search/{}/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q={}&category_ids=&sort_by=&from_videos={}"
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + "/latest-updates/?mode=async&function=get_block&block_id=list_videos_latest_videos_list&sort_by=post_date&from={}"
URL_CATEGORIES_PAGE = ROOT_URL + "/categories/{}/?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date&from={}"

MAIN_MODE          = C.MAIN_MODE_vipporns
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE
        ,iconimage=C.category_icon )
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    listhtml = utils.getHtml(list_url, ROOT_URL)
    if "is no data in this list" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('class="porntrex-box"')[1].split('class="pagination"')[0]
        except:
            video_region = listhtml
##        Log(video_region,xbmc.LOGNONE)

    #
    # main list items
    #
    #regex = '<img class=\"cover lazyload\" data-src=\"(?P<thumb>[^\"]+)\".+?class="quality">(?P<quality>[\d]+).+?clock-o\"><\/i>(?P<duration>[^<]+).+?href=\"(?P<url>[^\"]+)\" title=\"(?P<title>[^\"]+)\"'
    regex = ('class="item.+?href="([^"]+)"'
             '.+?title="([^"]+)"'
             '.+?data-original="([^"]+)"'
             '.+?class="duration">([^<]+)<'
             '.+?((?:<span class="is-hd">HD</span>|</div>))'
             ) #worked 2020-10
    regex = (
        'class="item.+?href="([^"]+)"'
         '.+?title="([^"]+)"'
         '.+?data-original="([^"]+)"'
         '.+?((?:<span class="is-hd">HD</span>|</div>))'
         '.+?class="duration">([^<]+)<'
        ) #worked 2021-02
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, hd, duration  in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        hd = utils.Normalize_HD_String(hd)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
                

    # next page items
    try:
        next_page_html = listhtml.split('class="pagination"')[1]
    except:
        next_page_html = listhtml
    next_page_regex = 'class="next"><a href="([^"]+)".+?from(?:_videos\+from_albums|4|):(\d+)'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_number = int(page) + 1
        np_url=url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword.replace('+','-'),keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page) == '-1'))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    html = utils.getHtml(url, ROOT_URL)

    regex = '"list-categories"(.*)class="footer-margin'
    cathtml = re.compile(regex, re.DOTALL).findall(html)[0]
    regex = 'href="([^"]+)" title="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label, thumb in info:
        #label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, C.search_text_color, utils.cleantext(label)) 
        thumb = thumb + utils.Header2pipestring()+"&Referer=" + ROOT_URL
        if not thumb.startswith('http'): thumb = "https" + thumb
        keyword = videourl.split('/categories/')[1].split('/')[0]
##        Log("videourl={}".format(videourl))
        videourl = URL_CATEGORIES_PAGE.format(keyword,'{}')
##        Log("videourl={}".format(videourl))
##        Log("thumb={}".format(thumb))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,page=FIRST_PAGE
            ,keyword=keyword )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))

    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    elif playmode_string == C.PLAYMODE_DIRECT:  max_video_resolution = 99999 #if 'direct' was chosen, use max available resolution
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    source_html = utils.getHtml(url, ROOT_URL)
#    source_html = "var flashvars = {  video_id: '3152648', license_code: '$524530617305183', lrc: '70275956', rnd: '1563642980', video_url: 'function/0/https://www.slutload.com/get_file/1/a238c212f61197c42461a4a5ad39119d73b41c4b98/3152000/3152648/3152648.mp4/', postfix: '.mp4', video_url_text: '480p', video_alt_url: 'function/0/https://www.slutload.com/get_file/1/6204add9dd801544c5b62338e421802c5f57c0187b/3152000/3152648/3152648_720p.mp4/', video_alt_url_text: '720p', video_alt_url_hd: '1', default_slot: '2', preview_url: 'https://i-rnseC.slutload-media.com/kvs/3152000/3152648/preview.jpg', skin: 'youtube.css', logo_position: '0,0', logo_anchor: 'topleft', bt: '5', volume: '1', preload: 'auto', hide_controlbar: '1', autoplay: 'true', related_src: 'https://www.slutload.com/related_videos_html/3152648/', related_on_pause: 'true', disable_preview_resize: 'true', embed: '1'};"
#    regex = "license_code: '(?P<lic>[^']+)'.+?video_url: 'function\/0\/(?P<vid>[^']+).+?(?:video_alt_url_hd: 'function\/0\/(?P<vid2>[^']+)|skin)"

    regex_model = '(?:/models/[^/]+/">)([^<]+)</a>'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).findall(source_html)
    description = ''
    desc_separator_char = '; '
    for model in source_models:
        if model.lower() not in description.lower():
            description = description + utils.cleantext(model) + desc_separator_char
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))

    regex = "flashvars.+?license_code:.+?'(?P<lic>[^']+)'"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(source_html)
    license_code = sources_list.next().group('lic')
    Log("license_code={}".format(license_code))

    list_key_value = {}
    #regex = "(?:video_url|video_alt_url.?): '(?P<url>[^']+).+?(?:video_url|video_alt_url.?)_text: '(?P<res>\d+)p'"
    regex = "(?:video_url|video_alt_url.?):\s+?'(?P<url>[^']+)"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(source_html)
    for source_list in sources_list:
        if 'res' in source_list.groupdict():
            list_key_value[source_list.group('res')] = source_list.group('url')
        else:
            list_key_value['240'] = source_list.group('url')
    Log("list_key_value={}".format(list_key_value))
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return

    if video_url.startswith("function/0/"):
        video_url = video_url.split("function/0/")[1]
        Log("video_url={}".format(video_url))
        
    from resources.lib import resolver
    fappy_salt = resolver.FaapySalt(license_code, "")
    Log("fappysalt='{}'".format(fappy_salt))
    encoded_fappy_code =  video_url.split('/')[5][0:32]
    Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
    new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
    Log("new_fappy_code='{}'".format(new_fappy_code))
    video_url = video_url.replace(encoded_fappy_code, new_fappy_code)
    video_url += '?rnd=' + utils.RandomNumber(length=13)

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return
    utils.playvid(video_url, name=name, download=download, description=description)

#__________________________________________________________________________
#

