"""
Simple HTTP Live Streaming client.

References:
    http://tools.ietf.org/html/draft-pantos-http-live-streaming-08

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

Last updated: July 22, 2012
MODIFIED BY shani to make it work with F4mProxy
"""

import urlparse, urllib2, subprocess, os,traceback,cookielib,re,Queue,threading
import xml.etree.ElementTree as etree
import base64
from struct import unpack, pack
import struct
import sys
import io
import os
import datetime,time
import itertools
import xbmcaddon
import xbmc
import urllib2,urllib
import traceback
import urlparse
import posixpath
import re
import hmac
import hashlib
import binascii 
import zlib
from hashlib import sha256
import cookielib
import array, random, string
import requests


import errno, socket

from f4mUtils.general_tools import Log
from f4mUtils.general_tools import Sleep
from f4mUtils.general_tools import Get_URL as getUrl
from f4mUtils.general_tools import parse_m3u_tag as Parse_M3U_Tag

#from Crypto.Cipher import AES
'''
from crypto.cipher.aes      import AES
from crypto.cipher.cbc      import CBC
from crypto.cipher.base     import padWithPadLen
from crypto.cipher.rijndael import Rijndael
from crypto.cipher.aes_cbc import AES_CBC
'''

gauth=None

callbackDRM=None
##from Cryptodome.Cipher import AES
try:
    from Crypto.Cipher import AES
    USEDec=1 ## 1==crypto 2==local, local pycrypto
except:
    Log('pycrypt not available using slow decryption', xbmc.LOGNONE)
    USEDec=3 ## 1==crypto 2==local, local pycrypto

if USEDec==1:
    #from Crypto.Cipher import AES
    print 'using pycrypto'
elif USEDec==2:
    from decrypter import AESDecrypter
    AES=AESDecrypter()
else:
    from f4mUtils import python_aes
#from decrypter import AESDecrypter

iv=None
key=None
value_unsafe = '%+&;#'
VALUE_SAFE = ''.join(chr(c) for c in range(33, 127)
    if chr(c) not in value_unsafe)
    
SUPPORTED_VERSION=3

g_clientHeader=None

class HLSDownloaderRetry():
    """
    A downloader for f4m manifests or AdobeHDS.
    """

    def __init__(self):
        self.init_done=False

    def init(self
            , url
            , stop_playing_event
            , seek_forward_event
            , maxbitrate=0
            , download_path=None
            , auth=''
            ):
        
        global g_clientHeader
        global gauth

        try:
            self.init_done=False
            self.init_url=url
            g_clientHeader=None

            self.auth=auth

            if self.auth ==None or self.auth =='None' or self.auth=='':
                self.auth=None

            if self.auth: gauth=self.auth
            
            if stop_playing_event: stop_playing_event.clear()
            self.stop_playing_event = stop_playing_event

            if seek_forward_event: seek_forward_event.clear()
            self.seek_forward_event = seek_forward_event
            
            self.maxbitrate = maxbitrate
            
            if '|' in url:
                sp = url.split('|')
                url = sp[0]
                g_clientHeader = sp[1]
                g_clientHeader= urlparse.parse_qsl(g_clientHeader)
                Log ("header recieved now url and headers are '{}'".format(url, g_clientHeader))
            self.url=url

            self.dumpfile = None
            if download_path:
                if download_path <> 'None':
                    #Log ("download_path='{}'".format(download_path))
                    self.dumpfile = open(download_path, "ab")
                                         
            return True
        except: 
            traceback.print_exc()

        return False
        
        
    def keep_sending_video(self
                           ,dest_stream
                           ,segmentToStart=None
                           ,totalSegmentToSend=0
                           ):
        try:
            downloadInternal(
                url = self.url
                , file = dest_stream
                , maxbitrate = self.maxbitrate
                , stopEvent = self.stop_playing_event
                , seek_forward_event = self.seek_forward_event
                , dumpfile = self.dumpfile
                )
        except:
            #traceback.print_exc()
            pass
            


###__________________________________________________________________
###
def Stop_And_Flush(stopEvent, response=None, chunk=None, dumpfile=None):

    if stopEvent: #make sure this exists
        if stopEvent.isSet(): #if it says 'stop' then close everything
            if dumpfile:
                dumpfile.close()
                dumpfile = None
            if response:
                response.close()
        
    if dumpfile: # just save what needs to be saved
        if chunk:
##            Log( 'Stop_And_Flush' + repr(chunk[0:25]).encode('utf8') )
            dumpfile.write(chunk)
        dumpfile.flush()

###__________________________________________________________________
###
def send_back( data, file, stopEvent, dumpfile):
    try:
        file.write(data)
##        Log( 'send_back' + repr(data[0:25]).encode('utf8') )
        Stop_And_Flush(stopEvent=stopEvent, response=None, chunk=data, dumpfile=dumpfile)

    except socket.error as error:
        if error.errno == errno.WSAECONNRESET or error.errno == errno.WSAECONNABORTED:
            pass
        else:
            raise
        
###__________________________________________________________________
###
def download_chunks(URL, stopEvent, chunk_size=4096, encrypted=None, decryptor=None, dumpfile=None ):
##    Log("download_chunks [URL='{}',chunk_size='{}', encrypted='{}',decryptor='{}',dumpfile='{}']".format(
##        URL
##        , chunk_size
##        , encrypted
##        , decryptor
##        , dumpfile
##        ))

    response = getUrl(
        URL
        , client_header = g_clientHeader
        , return_response = True
        , stream = True
        )
    if not response:
        return

    if encrypted and decryptor==1:
        chunk_size *= 1000
    else:
        chunk_size *= 1000
##    Log('chunk_size={}'.format(chunk_size))

    stop_yeilding_signal = None
    import urllib3   
    if isinstance(response, urllib3.response.HTTPResponse):  #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
        for chunk in response.stream(chunk_size):
            Stop_And_Flush(
                stopEvent=stopEvent
                , response=response
                , chunk=None
                , dumpfile=dumpfile
                )
            stop_yeilding_signal = (yield chunk)
            if stop_yeilding_signal is not None: break
        response.release_conn()
    else:
        for chunk in response.iter_content(chunk_size=chunk_size):
            Stop_And_Flush(
                stopEvent=stopEvent
                , response=response
                , chunk=None
                , dumpfile=dumpfile
                )
            stop_yeilding_signal = (yield chunk)
            if stop_yeilding_signal is not None: break
        response.close()
        
###__________________________________________________________________
###
def download_file(URL, stopEvent):
    return ''.join(download_chunks(URL=URL, stopEvent=stopEvent))

###__________________________________________________________________
###
def validate_m3u(conn):
    ''' make sure file is an m3u, and returns the encoding to use. '''
    return 'utf8'
    mime = conn.headers.get('Content-Type', '').split(';')[0].lower()
    if mime == 'application/vnd.apple.mpegurl':
        enc = 'utf8'
    elif mime == 'audio/mpegurl':
        enc = 'iso-8859-1'
    elif conn.url.endswith('.m3u8'):
        enc = 'utf8'
    elif conn.url.endswith('.m3u'):
        enc = 'iso-8859-1'
    else:
        raise Exception("Stream MIME type or file extension not recognized")
    if conn.readline().rstrip('\r\n') != '#EXTM3U':
        raise Exception("Stream is not in M3U format")
    return enc

###__________________________________________________________________
###
def gen_m3u(url, skip_comments=True):

    response, redirected_url = getUrl(
                                      url
                                      , client_header = g_clientHeader
                                      , send_back_redirect = True
                                      )
    if not response:
        yield ''
        raise Exception("No response at url='{}'".format(url))

    if redirected_url:
        text = 'f4mredirect:'+redirected_url
        Log(text)
        yield text

##    file_encoding = validate_m3u(conn)
    #print conn

##    Log(response)
    #for line in response.iter_lines():
    for line in response.split('\n'):
        line = line.rstrip('\r\n') #.decode(file_encoding)
        if not line: # blank line
            continue
        elif line.startswith('#EXT'): # tag
            yield line
        elif line.startswith('#'):    # comment
            if skip_comments:
                continue
            else:
                yield line
        else: # media file
            yield line
            
#####__________________________________________________________________
#####
##def parse_m3u_tag(line):
##    if ':' not in line:
##        return line, []
##    tag, attribstr = line.split(':', 1)
##    attribs = []
##    last = 0
##    quote = False
##    for i,c in enumerate(attribstr+','):
##        if c == '"':
##            quote = not quote
##        if quote:
##            continue
##        if c == ',':
##            attribs.append(attribstr[last:i])
##            last = i+1
##    return tag, attribs

###__________________________________________________________________
###
def parse_kv(attribs, known_keys=None):
    d = {}
    for item in attribs:
        k, v = item.split('=', 1)
        k=k.strip()
        v=v.strip().strip('"')
        if known_keys is not None and k not in known_keys:
            raise ValueError("unknown attribute %s"%k)
        d[k] = v
    return d

###__________________________________________________________________
###
def handle_basic_m3u(url):
    global iv
    global key
    global USEDec
    global gauth
    import urlparse
    global callbackDRM
    
    seq = 1
    enc = None
    nextlen = 5
    duration = 5
    targetduration=5
    aesdone=False
    redirurl=url
    vod=False

##    expire_date_time = datetime.datetime.now() + datetime.timedelta(0,5)
##    Log("expire_date_time={}".format(repr(expire_date_time)))

    for line in gen_m3u(url):
##        Log("line_from_gen_m3u={}".format(repr(line)))
        if line.startswith('f4mredirect:'):
            redirurl=line.split('f4mredirect:')[1]
            continue
        if line.startswith('#EXT'):
            tag, attribs = Parse_M3U_Tag(line)

            if tag == '#EXTINF':
                duration = float(attribs[0])

            elif tag == '#EXT-X-TARGETDURATION':
##                duration = int ( line.split('#EXT-X-TARGETDURATION:')[1] )
##                Log("duration={}".format(repr(duration)))
                assert len(attribs) == 1, "too many attribs in EXT-X-TARGETDURATION"
                targetduration = int(attribs[0])
##                expire_date_time = datetime.datetime.now() + datetime.timedelta(0,targetduration)
##                Log("targetduration={}".format(repr(targetduration)))
##                Log("expire_date_time={}".format(repr(expire_date_time)))
                pass

            elif tag == '#EXT-X-MEDIA-SEQUENCE':
                assert len(attribs) == 1, "too many attribs in EXT-X-MEDIA-SEQUENCE"
                seq = int(attribs[0])

            elif tag == '#EXT-X-KEY':

                attribs = parse_kv(attribs, ('METHOD', 'URI', 'IV'))
                assert 'METHOD' in attribs, 'expected METHOD in EXT-X-KEY'
                if attribs['METHOD'] == 'NONE':
                    assert 'URI' not in attribs, 'EXT-X-KEY: METHOD=NONE, but URI found'
                    assert 'IV' not in attribs, 'EXT-X-KEY: METHOD=NONE, but IV found'
                    enc = Nonee
                elif attribs['METHOD'] == 'AES-128':
                    if not aesdone:
                        #aesdone=False there can be multple aes per file
                        assert 'URI' in attribs, 'EXT-X-KEY: METHOD=AES-128, but no URI found'
                        #from Crypto.Cipher import AES
                        codeurl=attribs['URI'].strip('"')
                        
                        if gauth:
                            currentaesUrl=codeurl
                            codeurl=gauth
                            
                            if codeurl.startswith("LSHex$"):
                                codeurl=codeurl.split('LSHex$')[1].decode("hex")
                                print 'code is ',codeurl.encode("hex")
                            if codeurl.startswith("LSDRMCallBack$"):
                                codeurlpath=codeurl.split('LSDRMCallBack$')[1]
                                codeurl='LSDRMCallBack$'+currentaesUrl
                                
                                if codeurlpath and len(codeurlpath)>0 and callbackDRM==None:
                                    print 'callback',codeurlpath
                                    import importlib, os
                                    foldername=os.path.sep.join(codeurlpath.split(os.path.sep)[:-1])
                                    urlnew=''
                                    if foldername not in sys.path:
                                        sys.path.append(foldername)
                                    try:
                                        callbackfilename= codeurlpath.split(os.path.sep)[-1].split('.')[0]
                                        callbackDRM = importlib.import_module(callbackfilename)
                                        print 'LSDRMCallBack imported'
                                    except:
                                        traceback.print_exc()
                            
                        elif not codeurl.startswith('http'):
                            import urlparse
                            codeurl=urlparse.urljoin(url, codeurl)
                                
                        
                        #key = download_file(codeurl)
                        
                        elif not codeurl.startswith('http'):
                            import urlparse
                            codeurl=urlparse.urljoin(url, codeurl)
                            
                        #assert len(key) == 16, 'EXT-X-KEY: downloaded key file has bad length'
                        if 'IV' in attribs:
                            assert attribs['IV'].lower().startswith('0x'), 'EXT-X-KEY: IV attribute has bad format'
                            iv = attribs['IV'][2:].zfill(32).decode('hex')
                            assert len(iv) == 16, 'EXT-X-KEY: IV attribute has bad length'
                        else:
                            iv = '\0'*8 + struct.pack('>Q', seq)
                        enc=(codeurl,iv)
                        #if not USEDec==3:
                        #    enc = AES.new(key, AES.MODE_CBC, iv)
                        #else:
                        #    ivb=array.array('B',iv)
                        #    keyb= array.array('B',key)
                        #    enc=python_aes.new(keyb, 2, ivb)
                        #enc = AES_CBC(key)
                        #print key
                        #print iv
                        #enc=AESDecrypter.new(key, 2, iv)
                else:
                    assert False, 'EXT-X-KEY: METHOD=%s unknown'%attribs['METHOD']
            elif tag == '#EXT-X-PROGRAM-DATE-TIME':
                assert len(attribs) == 1, "too many attribs in EXT-X-PROGRAM-DATE-TIME"
                # TODO parse attribs[0] as ISO8601 date/time
                pass
            elif tag == '#EXT-X-ALLOW-CACHE':
                # XXX deliberately ignore
                pass
            elif tag == 'EXT-X-PLAYLIST-TYPE:VOD':
                vod=True
                pass                
                #EXT-X-PLAYLIST-TYPE:VOD
            elif tag == '#EXT-X-ENDLIST':
                assert not attribs
                yield None
                return
            elif tag == '#EXT-X-STREAM-INF':
                raise ValueError("don't know how to handle EXT-X-STREAM-INF in basic playlist")
            elif tag == '#EXT-X-DISCONTINUITY':
                assert not attribs
                print "[warn] discontinuity in stream"
            elif tag == '#EXT-X-VERSION':
                assert len(attribs) == 1
                if int(attribs[0]) > SUPPORTED_VERSION:
                    print "[warn] file version %s exceeds supported version %d; some things might be broken"%(attribs[0], SUPPORTED_VERSION)
            #else:
            #    raise ValueError("tag %s not known"%tag)
        else:
            if not line.startswith('http'):
                line=urlparse.urljoin(redirurl, line)
            yield (seq, enc, duration, targetduration, line ,vod )
            seq += 1


###__________________________________________________________________
###
def downloadInternal(url
                     ,file
                     ,maxbitrate
                     ,stopEvent
                     ,seek_forward_event
                     ,dumpfile=None
                     ):

    monitor = xbmc.Monitor()
    if monitor.abortRequested() or stopEvent.isSet():
        Stop_And_Flush(stopEvent=stopEvent, response=None, chunk=None, dumpfile=None)
        return False
    
    #url check if requires redirect
    redirected_url = url
    data_from_url, redirected_url = getUrl( url
                                            , client_header = g_clientHeader
                                            , send_back_redirect = True
                                            )
    if redirected_url:
        Log("redirected_url='{}'".format(redirected_url))
        url = redirected_url
##    Log("data_from_url='{}'".format(data_from_url))

    #extract stream from  the expected application/vnd.apple.mpegurl file
    if not 'EXT-X-STREAM-INF' in data_from_url:
        raise Exception("EXT-X-STREAM-INF was not found in '{}'".format(url))

    from f4mUtils.general_tools import Choose_M3U8_Stream
    url = Choose_M3U8_Stream(url, data_from_url, maxbitrate, dumpfile)

    last_seq = -1

    fails=0
    maxfails=5 #value will be increased after first successful connection

    lastKeyUrl=""
    lastkey=None

    MIN_SLEEP_TIME = 111 # milliseconds
    DEFAULT_SLEEP_TIME = 500

    missed_sequences = 0
    
    #sleep_time =  min(duration, DELAY_GUESS) * 1000.0
    #sleep_time =  duration * 0.5 * 1000.0
    sleep_time =  DEFAULT_SLEEP_TIME  # will be tuned as time goes on within 
    Log("will seep sleep '{:,}' milliseconds after sending each chunk".format(sleep_time))

    original_playing_file = xbmc.Player().getPlayingFile()
    Log("original_playing_file='{}'".format(original_playing_file))
                
    while not monitor.abortRequested() and not stopEvent.isSet():

        try:
            current_playing_file = xbmc.Player().getPlayingFile()
            if not(original_playing_file == current_playing_file ):
                Log("ending thread because '{}'<>'{}'".format(original_playing_file,current_playing_file))
                stopEvent.set()
                return
        except: #often getPlayingFile will return a 'nothing is playing' exception
            stopEvent.set()
            return
            pass

        vod=False

        if fails > maxfails:
            Log('fails > maxfails')
            stopEvent.set()
            return

        medialist = list(handle_basic_m3u(url))
        if len(medialist) < 1:
            Log('empty m3u8')
            stopEvent.set()
            return

        #
        # keep track in case we happen to go through the entire media list without
        # finding a sequence number to play
        #
        found_playable_packet = False

        for media in medialist:
##            Log("media='{}'".format(media))
            if media is None:
                Log("media is None")
                stopEvent.set()
                return

            seq, encobj, duration, targetduration, media_url, vod = media

            #
            # adjust sleep times according to what manually tuned values see to work
            #
            old_missed_sequences = missed_sequences
            if (seq > (last_seq + 1)) and not(last_seq == -1) : # ==-1 part is to prevent missinformation on first packet
                missed_sequences = missed_sequences + ( seq -  (last_seq + 1)   ) # increment by the number of sequences we have missed
##                Log("sleep_time='{:,}' duration='{:,}' ".format(sleep_time, duration))
                sleep_time = max( (sleep_time/1.5) , MIN_SLEEP_TIME)
            else:
                missed_sequences = max(0, missed_sequences - 0.2) #slowly decrement this, making sure it is never negative
                sleep_time = min( (sleep_time*1.5), (duration*850) )
                sleep_time = max( MIN_SLEEP_TIME, sleep_time ) #correct for situation where a sites reports a negative value for duration...
##                Log("sleep_time='{:,}' duration='{:,}' ".format(sleep_time, duration))
            if not (old_missed_sequences == missed_sequences):
                Log("missed_sequences='{:,}'".format(missed_sequences))
                pass
            if missed_sequences > 4: #4 seems to be good number on my device
                missed_sequences = 0
                seek_forward_event.set()
##            Log("sleep_time='{:,}' duration='{:,}' ".format(sleep_time, duration))

            if (seq <= last_seq) : #we have already played this packet
##                Log("already played seq='{}'".format(seq))
                Sleep(MIN_SLEEP_TIME)
                continue #look at the next media sequence
            else:
                found_playable_packet = True

            #
            # prepare encryption key; if any
            #
            enc=None
            if encobj:
                codeurl,iv = encobj
                if codeurl <> lastKeyUrl:
                    Log("new codeurl='{}'    lastKeyUrl='{}' ".format(codeurl, lastKeyUrl))
                    if codeurl.startswith('http'):
                        key = download_file(codeurl, stopEvent)
                    elif codeurl.startswith('LSDRMCallBack$'):
                        key = callbackDRM.DRMCallback(codeurl.split('LSDRMCallBack$')[1],url)
                    else:
                        key = codeurl
                    lastKeyUrl = codeurl
                else:
                    key=lastkey
                if not lastkey==key: Log("new key='{}'".format(repr(key)))
                lastkey = key
                if not USEDec==3:
                    enc = AES.new(key, AES.MODE_CBC, iv)
                else:
                    ivb=array.array('B',iv)
                    keyb= array.array('B',key)
                    enc=python_aes.new(keyb, 2, ivb)
                #enc=AESDecrypter.new(key, 2, iv)

            try:
                chunk = None
                chunk_length = 0
                try:
                    #Log('downloading from {}'.format(urlparse.urljoin(url, media_url)))
                    down_chunks = download_chunks(
                        media_url
                        , stopEvent=stopEvent
                        , dumpfile=dumpfile
                        , encrypted=enc
                        , decryptor=USEDec
                        ) 
                    for chunk in down_chunks:
                        if enc:
                            if not USEDec==3:
                                chunk = enc.decrypt(chunk)
                            else:
                                chunkb = array.array('B',chunk)
                                chunk = enc.decrypt(chunkb)
                                chunk = "".join(map(chr, chunk))
##                                Log('end decrypting chunk, USEDec={}'.format(USEDec))
##                                Log('afterdecrypting' + repr(chunk[0:25]).encode('utf8') )
                        chunk_length = len(chunk)
                        Log('sending {:,} sized chunk of seq {:,}'.format( chunk_length , seq ))
                        send_back(data=chunk, file=file, stopEvent=stopEvent, dumpfile=dumpfile)
                        #down_chunks.send(False) #Stop yeilding data. Generate exception StopIteration

                except StopIteration:
                    pass                      
                except Exception as inst:
                    Log('except Exception as inst:')
                    traceback.print_exc()
                    if 'forcibly closed' in repr(inst): 
                        return False

                if chunk and chunk_length>0: 
                    last_seq = seq
                    fails=0
                    maxfails=20
                else:
                    fails+=1

##                Log("will seep sleep '{}' milliseconds after sending the chunk".format(sleep_time))
##                Sleep(sleep_time)
                break #exit loop " for media in medialist:"   # force a fresh m3u8 file

            except:
                traceback.print_exc()
                fails+=1
                pass



        else: # end of loop " for media in medialist:"
            
            if found_playable_packet == False:
                # we went through the entire media list without
                # finding a sequence number to play
                # sleep before looking for another m3u8
                Log("Sleeping '{:,}' milliseconds because we did not find any new pieces to play".format(sleep_time))
                Sleep(sleep_time)




##        if skipped_packets == False:
##            # m3u8 was processed 'normally', but check to see if stream is stalling
##            # stalled stream is 'corrected' by jumping a few packets
##            #delta_seconds = (now_date_time-expire_date_time).total_seconds()
##            expected_end = (startm3u8_date_time + datetime.timedelta(0,total_duration))
##            actual_end = datetime.datetime.now()
##            delta_seconds = (expected_end-actual_end).total_seconds()
##            Log("delta_seconds='{}' total_duration='{}' expected_end='{}' actual_end='{}'".format(delta_seconds, total_duration, expected_end.isoformat(), actual_end.isoformat()))
##            too_much = DELAY_GUESS #total_duration * 0.666
##            too_little = DELAY_GUESS / 10.0 #total_duration * 0.166
##            Log("too_much='{}' too_little='{}'".format(too_much, too_little))
##            if delta_seconds > too_much : #wait for m3u8 to catch up
##                #sleep_time = (delta_seconds-0.05)*1000
##                sleep_time = (delta_seconds-too_little)*1000
##                Log("We are ahead ... sleeping {} milliseconds".format(sleep_time))
##                Sleep(sleep_time)
##            elif delta_seconds < too_little :
##                # it took too long to show what needed to be shown; skip ahead
##                seek_forward_event.set()
