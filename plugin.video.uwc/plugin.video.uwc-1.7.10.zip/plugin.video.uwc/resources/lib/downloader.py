#-*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

__scriptname__ = "Ultimate Whitecream"
__author__ = "Whitecream"
__credits__ = "Whitecream, Fr33m1nd, anton40, NothingGnome"
__version__ = "1.1.55"

import constants as C
import traceback
from utils import *
import xbmc
import xbmcvfs
import xbmcgui


##C.addon.setSetting(id='background_download', value="true")

#__________________________________________________________________________
#
class StopDownloading(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)

#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True):
    if not s: return ''
    s = s.strip('\r')
    s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(u'(?i)\[\/Color\]','',s))
    if include_square_braces:
        s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_]',' ',s))
    else:
        s = (re.sub(u'(?is)[^A-Za-z0-9~     ,\'.&_]',' ',s))
    while '  ' in s:
        s = s.replace('  ', ' ')
    return s.strip()

#__________________________________________________________________________
#
def Make_download_path(name = '', include_date = False, file_extension = ''):

    Log(u"Make_download_path name='{}'".format(name))
    name = Clean_Filename(name)
   
    download_path = unicode(C.addon.getSetting("download_path").lower())
    Log("Make_download_path download_path='{}'".format(download_path))    
    if download_path == '':
        try:
            download_path = xbmcgui.Dialog().browse(0, "Download Path", 'myprograms', '', False, False)
            C.addon.setSetting(id='download_path', value=download_path)
            if not os.path.exists(download_path): os.mkdir(download_path)
        except:
            raise 
    download_path = download_path + name

    if include_date:
        download_path = download_path + datetime.datetime.now().strftime(".%Y-%m-%d")

    download_path = download_path + file_extension
    
    Log("Make_download_path download_path='{}'".format(download_path))
    return download_path

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_STOP_DOWNLOAD, ['url'])
def Stop_Download(url):
    Log("Stop_Download start '{}'".format(url))
    
    import gc
    has_been_stopped = False
    loop_interruptor = 0
    for obj in gc.get_objects():
        loop_interruptor += 1
        if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS: # pause to allow other stuff
            Sleep(C.GC_SEARCHLOOP_PAUSE) # pause to allow other stuff
            loop_interruptor = 0        
        if '__class__' in repr(dir(obj)) :
            if 'HLSDownloaderRetry.HLSDownloaderRetry' in repr(obj.__class__):
                if obj.stop_playing_event:
                    if obj.url == url:
                        if obj.stop_playing_event.isSet() == False:
                            obj.stop_playing_event.set()
                            has_been_stopped = True
                            break

    if has_been_stopped:
        if obj:
            Notify("Stopped '{}'".format(obj.name))
            obj = None

    Log("Stop_Download end '{}'".format(url))

    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_MANAGE_DOWNLOADS)
def Manage_Downloads():
    Log("Manage_Downloads start")

    for obj in threading.enumerate():
        Log("obj='{}'".format(dir(obj)))
        Log("obj.name='{}'".format(obj.name))
        
    import gc

##
##    has_more = True
##    one_instance_found = False
##    loop_interruptor = 0
##
##
##    try: 
##        for obj in threading.enumerate():
##            Log("obj='{}'".format(dir(obj)))
##            Log("obj.name='{}'".format(obj.name))
##            if obj.name.startswith(C.DOWNLOAD_INDICATOR):
##                if 'HLSDownloaderRetry' in dir(obj) :
##                    one_instance_found = True
##                    if obj.stop_playing_event:
####                                Log("HLSDownloaderRetry object found='{}'".format(obj.name))
##                        if obj.stop_playing_event.isSet() == False:
##                            name = "[COLOR {}]Stop downloading[/COLOR] '{}'".format(
##                                C.search_text_color
##                                , obj.name)
##                            addDownLink(name = name
##                                        , url=obj.url
##                                        , mode=C.ROOT_STOP_DOWNLOAD
##                                        , play_method = C.PLAYMODE_NO_OPTIONS
##                                        , noDownload = True
##                                        )
##    except:
##        traceback.print_exc()
##
##    if one_instance_found == False:
##        addDir(
##            name="Nothing downloading in background"
##            , url=C.DO_NOTHING_URL
##            , mode=C.ROOT_INDEX_INDEX
##            )
####        C.addon.setSetting(id='background_download', value="false")
##    else:
##        C.addon.setSetting(id='background_download', value="true")
##    
##
##    Log("Manage_Downloads end")
##
##
####    endOfDirectory()
####    return

    has_more = True
    one_instance_found = False
    loop_interruptor = 0
    
    try:
        
        while has_more:
            has_more = False
            for obj in gc.get_objects():
                loop_interruptor += 1
                if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS: # pause to allow other stuff
                    Sleep(C.GC_SEARCHLOOP_PAUSE) # pause to allow other stuff
                    loop_interruptor = 0
                try:
##                    Log(repr(dir(obj)))
                    if '__class__' in repr(dir(obj)) : # isInstance does not work; also some objects don't implement __class__
                        if 'HLSDownloaderRetry.HLSDownloaderRetry' in repr(obj.__class__):
                            if obj.stop_playing_event:
##                                Log("HLSDownloaderRetry object found='{}'".format(obj.name))
                                if obj.stop_playing_event.isSet() == False:

                                    

                                    if obj.dumpfile is not None: #only background will have this

                                        one_instance_found = True

                                        name = "[COLOR {}]Stop downloading[/COLOR] '{}'".format(
                                            C.search_text_color
                                            , obj.name)
                                        addDownLink(name = name
                                                    , url=obj.url
                                                    , mode=C.ROOT_STOP_DOWNLOAD
                                                    , play_method = C.PLAYMODE_NO_OPTIONS
                                                    , noDownload = True
                                                    )
                except:
                    raise
            obj = None
                    
    except:
        traceback.print_exc()

    if one_instance_found == False:
        addDir(
            name="Nothing downloading in background"
            , url=C.DO_NOTHING_URL
            , mode=C.ROOT_INDEX_INDEX
            )
        C.addon.setSetting(id='background_download', value="false")
    else:
        C.addon.setSetting(id='background_download', value="true")
    
    endOfDirectory()

    Log("Manage_Downloads end")

#__________________________________________________________________________
#
def Background_HLSDownloader(url, download_path):

    play_profile = 'profile_00' #the download profile
    initial_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "initial"))* 1000 * 1000)
    maximum_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "maximum"))* 1000 * 1000)
    allow_upscale = C.addon.getSetting(play_profile + "_" + "allow_upscale")
    allow_downscale = C.addon.getSetting(play_profile + "_" + "allow_downscale")
    always_refresh_m3u8 = C.addon.getSetting(play_profile + "_" + "always_refresh_m3u8")
    downscale_threshhold = C.addon.getSetting(play_profile + "_" + "downscale_threshhold")
    upscale_threshhold = C.addon.getSetting(play_profile + "_" + "upscale_threshhold")
    upscale_penalty = C.addon.getSetting(play_profile + "_" + "upscale_penalty")
    pre_cache_size_max = int(float(C.addon.getSetting(play_profile + "_" + "pre_cache_size_max"))* 1000 * 1000)

    stop_playing_event = threading.Event()
    seek_forward_event = threading.Event()
    import HLSDownloaderRetry

    Log("Background_HLSDownloader instance")
    downloader = HLSDownloaderRetry.HLSDownloaderRetry()
    downloader.init(
          url = url
        , stop_playing_event = stop_playing_event
        , seek_forward_event = seek_forward_event
        , maxbitrate = maximum_bitrate
        , download_path = download_path
        , initial_bitrate = initial_bitrate
        , allow_upscale = allow_upscale
        , allow_downscale = allow_downscale
        , always_refresh_m3u8 = always_refresh_m3u8
        , downscale_threshhold = downscale_threshhold
        , upscale_threshhold = upscale_threshhold
        , upscale_penalty = upscale_penalty
        , pre_cache_size_max = pre_cache_size_max
        )
    Log("Background_HLSDownloader keep sending start")

    for obj in threading.enumerate():
        Log("obj='{}'".format(dir(obj)))
        Log("obj.name='{}'".format(obj.name))

    downloader.keep_sending_video(None)
    Log("Background_HLSDownloader keep sending finish")

    downloader = None

    ##todo: check if we should turn off below
    ##C.addon.setSetting(id='background_download', value="false")
    
#__________________________________________________________________________
#
def downloadVideo(url, name, download_path=None):

##    def clean_filename(s, include_square_braces=True):
##        if not s: return ''
##
##        s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s)).replace('  ', ' ')
##        s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s)).replace('  ', ' ')
##        s = (re.sub(u'(?i)\[\/Color\]','',s)).replace('  ', ' ')
##        
##        if include_square_braces:
##            s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ \/,\'.&]',' ',s)).replace('  ', ' ')
##        else:
##            s = (re.sub(u'(?is)[^A-Za-z0-9~ ,\'.&]',' ',s)).replace('  ', ' ')
##        return s.strip()
    
    Log(u"DownloadVideo name='{}' url='{}'".format(Clean_Filename(name),url), xbmc.LOGNONE)

    Notify(u"Downloading '{}' in background".format(Clean_Filename(name)))


    if any(x in url for x in ['.m3u8', '/hls/']):

        if download_path is None:   
            download_path = Make_download_path(name, file_extension = '.ts')

        C.addon.setSetting(id='background_download', value="true")
        proxy_thread = threading.Thread(
            name=C.DOWNLOAD_INDICATOR+Clean_Filename(name)
            ,target=Background_HLSDownloader
            ,args=(url, download_path)
            )
        proxy_thread.daemon = True
        proxy_thread.start()


        for obj in threading.enumerate():
            Log("obj='{}'".format(dir(obj)))
            Log("obj.name='{}'".format(obj.name))

        Log("proxy_thread")
        return
    
    def _pbhook(downloaded, filesize, name=None,dp=None):
        try:
            percent = min((downloaded*100)/filesize, 100)
            currently_downloaded = float(downloaded) / (1024 * 1024)
            kbps_speed = int(downloaded / (time.clock() - start))

            if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
            else:           eta = 0

            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            mbs = "[{:20}]".format(name)
            mbs += ' %.00f MB/%.00f MB' % (currently_downloaded, total)
            e = ' %.0fKbps' % kbps_speed
            e += ' ETA:%01d' % (eta // 60)
            dp.update(percent,'',mbs + e)
        except:
            traceback.print_exc()
            percent = 100
            dp.update(percent)
            dp.close()

    def getResponse(url, headers2, size):
        #Log("getResponse:{}".format(url))
        import urllib2
        import ssl
        Request = urllib2.Request
        try:
            if size > 0:
                size = int(size)
                headers2['Range'] = 'bytes=%d-' % size
            req = Request(url, headers=headers2)
            resp = urllib2.urlopen(req, timeout=30, context=ssl._create_unverified_context())
            #Log("getResponse:urlopen:{}".format(url))
            return resp
        except:
            traceback.print_exc()
            return None

    def doDownload(url, dest, dp, name):

        try:
            
            #url may have include headers to be passed during transaction
            try:
                headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
            except:
                #traceback.print_exc()
                headers = dict('')


            #if 'spankbang.com' in url:  url = getVideoLink(url,url)

            url = url.split('|')[0]
            file = dest.rsplit(os.sep, 1)[-1]

#            Log("headers='{}'".format(headers))

            resp = getResponse(url, headers, 0)
            #utils.getHtml(url, headers=headers)
            
            if not resp:
                Notify("Download failed: {}".format(url))
                return False

            try:
                content = int(resp.headers['Content-Length'])
                Log("Expected file size {:,}bytes for '{}'".format(content, name))
            except: content = 0

            try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
            except: resumable = False
            if resumable: Log("Download is resumable: {}".format(url))

            if content < 1:
                Notify("Unknown filesize: {}".format(url))
                content = 1024*1024*1024


            size = 8192
            mb   = content / (1024 * 1024)

            if content < size:
                size = content

            total   = 0
            errors  = 0
            count   = 0
            resume  = 0
            sleep   = 0

            Log('Download File Size : %dMB %s ' % (mb, dest))
            f = xbmcvfs.File(dest, 'w')

            chunk  = None
            chunks = []

            while True:

                # kill the download if kodi monitor tells us to
                monitor = xbmc.Monitor()
                if monitor.abortRequested():
                    if monitor.waitForAbort(1):
                        Log("shutting down '{}' download thread for '{}'".format(addon_id,url), xbmc.LOGNOTICE)
                        return

                downloaded = total
                for c in chunks:
                    downloaded += len(c)
                percent = min(100 * downloaded / content, 100)

                _pbhook(downloaded,content,name,dp)

                chunk = None
                error = False

                try:
                    chunk  = resp.read(size)
                    if not chunk:
                        if percent < 99:
                            error = True
                        else:
                            while len(chunks) > 0:
                                c = chunks.pop(0)
                                f.write(c)
                                del c

                            f.close()
                            Log( '%s download complete' % (dest) )
                            return True

                except Exception as e:
                    traceback.print_exc()
                    error = True
                    sleep = 10
                    errno = 0

                    if hasattr(e, 'errno'):
                        errno = e.errno

                    if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                        pass

                    if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                        errors = 10 #force resume
                        sleep  = 30

                    if errno == 11001: # 'getaddrinfo failed'
                        errors = 10 #force resume
                        sleep  = 30

                if chunk:
                    errors = 0
                    chunks.append(chunk)
                    if len(chunks) > 5:
                        c = chunks.pop(0)
                        f.write(c)
                        total += len(c)
                        del c

                if error:
                    errors += 1
                    count  += 1
                    #Log ('%d Error(s) whilst downloading %s' % (count, dest))
                    #xbmc.sleep(sleep*1000)
                    xbmc.sleep(sleep*1000)

                if (resumable and errors > 0) or errors >= 500:
                    if (not resumable and resume >= 500) or resume >= 500:
                        #Give up!
                        Log ('%s download canceled - too many error whilst downloading' % (dest))
                        f.close()
                        return False

                    resume += 1
                    errors  = 0

                    if resumable:
                        chunks  = []
                        #create new response
                        Log ('Download resumed (%d) %s' % (resume, dest) )
                        resp = getResponse(url, headers, total)
                    else:
                        #use existing response
                        pass

        except:
            traceback.print_exc()

    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on

    name = Clean_Filename(name)

    download_path = Make_download_path() #I want to start with path only
        
    progress_dialog = xbmcgui.DialogProgressBG()
    progress_dialog.create(C.addon_name,name[:50])

    import tempfile
    
    tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
    tmp_file = xbmc.makeLegalFilename(tmp_file)
    start = time.clock()
    downloaded = None
    try:
        Log("url='{}'".format(url))
        downloaded = doDownload(url, tmp_file, progress_dialog, name)
        if downloaded:
            Log("Clean_Filename(name)='{}'".format(Clean_Filename(name,include_square_braces=False)))
            vidfile = xbmc.makeLegalFilename(download_path + Clean_Filename(name, include_square_braces=False) + ".mp4")
            Log("vidfile='{}'".format(vidfile))
            try:
                os.rename(tmp_file, vidfile)
                return vidfile
            except Exception as e:
                try:
                    nfn = vidfile + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S") + '.mp4'
                    Log("vidfile='{}'".format(nfn))
                    os.rename(tmp_file, nfn)
                    return nfn
                except Exception as e2:
                    traceback.print_exc()
                    Notify(msg = "'{}' name:{} tmp:{}".format(e2,vidfile,tmp_file), duration=20000)
                    return tmp_file
        else:
            raise StopDownloading('Stopped Downloading')
    except:
        traceback.print_exc()
        while os.path.exists(tmp_file):
            try:
                os.remove(tmp_file)
                progress_dialog.close()
                break
            except:
                traceback.print_exc()
                break
                pass
    finally:
        if progress_dialog:
            progress_dialog.close()

#__________________________________________________________________________
#
