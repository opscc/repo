'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os.path
import sys
import traceback
import xbmc
import xbmcplugin

from resources.lib import downloader
from resources.lib import favorites
from resources.lib import utils
import service
from resources.lib.sites import * #required for registering modes into dispatcher
from resources.lib.utils import Log
from resources.lib import constants as C

if int(sys.argv[1]) > 0: 
    xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available
       
#__________________________________________________________________________
#
def Dynamic_Front_Pages_Options():
    
    settings_file = os.path.join(C.rootDir, 'resources', "settings.xml")
    import xml.etree.ElementTree as ET
    tree = ET.ElementTree(file=settings_file)

    font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
    if font_pages_element_tree is None:
        ET.SubElement(parent=tree.find("."),tag='category',attrib={'label':"Front Pages"})

    font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
    if font_pages_element_tree is None:
        pass

    for elems in font_pages_element_tree:
        elems.clear()
        elems.attrib['label'] = "Front Pages"
        for sitename, module in utils.Get_Sites():
            try:
                if hasattr(module,"website"):   # experimental; use a class for all websites
                    module = module.website
            except:
                traceback.print_exc()
                pass
            if 'FRONT_PAGE_CANDIDATE' in dir(module):
                if module.FRONT_PAGE_CANDIDATE == True:
                    ET.SubElement(parent=elems,tag='setting',attrib={'id':sitename + '_on_front_page','label':sitename + '_on_front_page','default':'false','type':'bool'})
            
    tree.write(settings_file)
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_INDEX)
def INDEX():

    if C.this_addon.getSetting('debug').lower() == "true" :
        utils.addDir(name = '[COLOR {}]Test All[/COLOR]'.format(C.highlight_text_color)
                     ,url = C.DO_NOTHING_URL
                     ,mode = C.ROOT_TEST_ALL )
        utils.addDir(name = '[COLOR {}]Service Update[/COLOR]'.format(C.highlight_text_color)
                     ,url = C.DO_NOTHING_URL
                     ,mode = C.ROOT_SERVICE_UPDATE
                     ,Folder=False
                     )
        utils.addDir(name = '[COLOR {}]Service ScanStart[/COLOR]'.format(C.highlight_text_color)
                     ,url = C.DO_NOTHING_URL
                     ,mode = C.ROOT_SERVICE_SCAN_START
                     ,Folder=False)

    utils.addDir('[COLOR {}]Search All[/COLOR]'.format(C.search_text_color)            ,'',C.ROOT_SEARCH_ALL     ,iconimage=C.search_icon)
    utils.addDir('[COLOR {}]Front Pages[/COLOR]'.format(C.refresh_text_color) ,'',C.ROOT_FRONT_PAGE     ,iconimage=C.search_icon)
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Scenes'.format(C.program_text_color) ,'',C.ROOT_INDEX_SCENES)
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Movies'.format(C.program_text_color) ,'',C.ROOT_INDEX_MOVIES) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Hentai'.format(C.program_text_color) ,'',C.ROOT_INDEX_HENTAI) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Tubes'.format(C.program_text_color) ,'',C.ROOT_INDEX_TUBES) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Webcams'.format(C.program_text_color) ,'',C.ROOT_INDEX_CAMS) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Favorites'.format(C.program_text_color) ,'',C.ROOT_INDEX_FAVORITES)

    download_path = C.this_addon.getSetting('download_path')
    if download_path != '' and os.path.exists(download_path):
        utils.addDir(
            name = '[COLOR {}]Whitecream[/COLOR] Download Folder'.format(C.program_text_color)
            ,url = download_path
            ,mode = C.ROOT_INDEX_DOWNLOAD_FOLDER
            ,Folder = False)
#    if C.this_addon.getSetting('background_download').lower() == "true" :
    if len(downloader.active_downloads()) > 0 or (C.this_addon.getSetting('debug').lower() == "true"):
        utils.addDir(
            name = '[COLOR {}]Background Downloads[/COLOR]'.format(C.highlight_text_color)
            , url = C.DO_NOTHING_URL
            , mode = C.ROOT_MANAGE_DOWNLOADS
            , Folder=True)
    
    utils.endOfDirectory(cacheToDisc=False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_SCENES)
def INDEXS():
    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(C.LIST_AREA_SCENES):
        #Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)
        
    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_MOVIES)
def INDEXM():
    for friendly, root_url, mode, icon_filespec in utils.Get_Sites(C.LIST_AREA_MOVIES):
        #Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_TUBES)
def INDEXT():
    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(C.LIST_AREA_TUBES):
##        Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_CAMS)
def INDEXW():
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_CAMS):
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_HENTAI)
def INDEXH():
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_HENTAI):
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_FRONT_PAGE, ['page'], ['keyword'])
def Front_Page(page=1,keyword=None):

    #temporarilty force only X recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 0

    import Queue
    import threading

    get_sites = utils.Get_Sites()
    q = Queue.Queue()
    i = 0
    all_method_results = {}
    try:
        for sitename, module in get_sites:
            if module.FRONT_PAGE_CANDIDATE == True:
                if C.this_addon.getSetting(sitename + '_on_front_page').lower() == "true" :
##                    i = i + 1 #testing
                    all_method_results[sitename] = None
                    method_to_call = getattr(module, 'List')
                    kwargs = {
                        "url": module.URL_RECENT
                        ,"end_directory": False
                        ,"page": module.FIRST_PAGE}
                    q.put((sitename,method_to_call,kwargs))
            if i > 2: break #testing
        for k in range(C.MAX_WEBCRAWLER_THREADS):
            worker = threading.Thread(target=utils.crawl, args=(q,all_method_results))
            worker.daemon = False
            worker.start()
        q.join()
        get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
    except StopIteration:
        pass
    except:
        traceback.print_exc()

    at_least_one = False
    for result in all_method_results:
        if all_method_results[result] in [None, True]:
            at_least_one = True
            break
            
    if not at_least_one:
        utils.addDir(name='[COLOR {}]Add Sites to this via Settings[/COLOR]'.format(C.refresh_text_color)
            ,url=C.DO_NOTHING_URL
            ,iconimage=C.search_icon
            ,mode=C.ROOT_INDEX_INDEX
            ,Folder=False)


    utils.endOfDirectory()        
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_DOWNLOAD_FOLDER, ['url'])
def OpenDownloadFolder(url):
    xbmc.executebuiltin("ActivateWindow(Videos, {})".format(url))
#__________________________________________________________________________
#
def change():
    if os.path.isfile(C.uwcchange):
        heading = '[B][COLOR {}]Whitecream[/COLOR] Changelog[/B]'.format(C.program_text_color)
        utils.textBox(heading,C.uwcchange)
        os.remove(C.uwcchange)
#__________________________________________________________________________
#
def main(argv=None):
    if sys.argv: argv = sys.argv
    queries = utils.parse_query(sys.argv[2])
    mode = queries.get('mode', None)
    try:
        mode_via_url = sys.argv[0].split('/')[3]
        mode = str(int(mode_via_url))
    except:
        pass

    Dynamic_Front_Pages_Options()

    try:
        C.url_dispatcher.dispatch(mode, queries)
    except:
##        Log("mode='{}'".format(mode),xbmc.LOGNONE)
        raise
#__________________________________________________________________________
#
if __name__ == '__main__':
    change()
    sys.exit(main())
#__________________________________________________________________________
#
