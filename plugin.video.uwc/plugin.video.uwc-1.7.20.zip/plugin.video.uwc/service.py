import random
import threading
import traceback
import xbmc

from resources.lib import constants as C
from resources.lib import downloader
from resources.lib import thread_cache 
from resources.lib import utils
from resources.lib import webcam_db
from resources.lib.utils import Log as Log
from resources.lib.utils import Sleep as Sleep


#__________________________________________________________________
#
monitor = xbmc.Monitor()
webcams_db = C.favoritesdb
MIN_SLEEP_SECONDS = int(C.addon.getSetting("min_service_interval"))
thread_cache = thread_cache.uwcSimpleCache()
#__________________________________________________________________
#
def recording_service(stop_event):
    ## wait a moment before doing stuff to avoid overwhelming startup
    sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
    sleeptime = 15 #max(sleeptime, 15)
    Log("{} sleeping {} seconds before next action ".format(repr(threading.current_thread().name), sleeptime) )
    if monitor.waitForAbort(int(sleeptime)):
        Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
        return
    while not monitor.abortRequested():
        if stop_event.isSet():
            Log("ending thread {} due to stop_event".format(repr(threading.current_thread().name)))
            break
        enable_recording_service = C.addon.getSetting("enable_recording_service").lower() == "true" ## ... do some work
        if enable_recording_service:
            try:
                downloader.scan_and_start_db()
            except:
                traceback.print_exc()
        else:
            Log("enable_recording_service is false")
            break
        ## sleep then ... do some work
        sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
        Log("sleeptime={}".format(sleeptime))
        sleeptime = max(sleeptime, MIN_SLEEP_SECONDS)
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        if monitor.waitForAbort(sleeptime):
            Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
            break
#__________________________________________________________________
#
def link_crawler(stop_event):

    ## wait a moment before doing stuff to avoid overwhelming startup
    sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
    sleeptime = 5 #max(sleeptime, 5)
    Log("{} sleeping {} seconds before next action ".format(repr(threading.current_thread().name), sleeptime) )
    if monitor.waitForAbort(int(sleeptime)):
        Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
        return
    
    while not monitor.abortRequested():

        if stop_event.isSet():
            Log("ending thread {} due to stop_event".format(repr(threading.current_thread().name)))
            break
        
        enable_link_crawler = C.addon.getSetting("enable_link_crawler").lower() == "true" ## ... do some work
        if enable_link_crawler:
            try:
                webcam_db.clear_webcam_db()
                webcam_db.fill_webcam_db()
            except:
                traceback.print_exc()
        else:
            Log("enable_link_crawler is false")
            break
            
        ## sleep then ... do some work
        sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
        Log("sleeptime={}".format(sleeptime))
        sleeptime = max(sleeptime, MIN_SLEEP_SECONDS)
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        if monitor.waitForAbort(sleeptime):
            Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
            break

#__________________________________________________________________
#
if __name__ == '__main__':


    C.DEBUG = (C.this_addon.getSetting('debug').lower() == "true")
        
    threading.current_thread().name = C.addon_id+".service"

    proxy_thread_recording_service = None
    recording_service_stop_event = None
    proxy_thread_crawler = None
    crawler_stop_event = None

    webcam_db.clear_webcam_db()


##    Log(repr(thread_cache_id))
    Log(repr(thread_cache))

##    import xbmcgui
##    _win = xbmcgui.Window(10000)
##    endpoint = C.addon_id+"thread_cache"
    

##    cachedata = id(monitor)
##    cachedata_str = repr(cachedata).encode("utf-8")
##    _win.setProperty(endpoint.encode("utf-8"), cachedata_str)

    while not monitor.abortRequested():

        # start thread for link_crawler service
        if C.addon.getSetting("enable_link_crawler").lower() == "true":
##            Log("enable_link_crawler is true")
            if not proxy_thread_crawler: # start thread for link_crawler service
                crawler_stop_event = threading.Event()
                proxy_thread_crawler = threading.Thread(
                    target=link_crawler
                    ,args=(crawler_stop_event,)
                    ,name=C.addon_id+".link_crawler"
                    )
                proxy_thread_crawler.daemon = True
                proxy_thread_crawler.start()
            else:
                Log("proxy_thread_crawler already started")
        else:
##            Log("enable_link_crawler is false")
            if proxy_thread_crawler:
                if crawler_stop_event: crawler_stop_event.set()
                proxy_thread_crawler = None
            webcam_db.clear_webcam_db()



        # start thread for enable_recording_service service
        if C.addon.getSetting("enable_recording_service").lower() == "true":
            if (not proxy_thread_recording_service) or (not proxy_thread_recording_service.is_alive()) : # start thread
                recording_service_stop_event = threading.Event()
                proxy_thread_recording_service = threading.Thread(
                    target=recording_service
                    ,args=(recording_service_stop_event,)
                    ,name=C.addon_id+".recording_service"
                    )
                proxy_thread_recording_service.daemon = True
                proxy_thread_recording_service.start()
            else:
                Log("proxy_recording_service already started")
        else:
            if proxy_thread_recording_service:
                if recording_service_stop_event: recording_service_stop_event.set()
                proxy_thread_recording_service = None

                
        ## sleep then ... do some work
        sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
##        Log("sleeptime={}".format(sleeptime))
        sleeptime = max(sleeptime, MIN_SLEEP_SECONDS)
##        sleeptime = 5
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        if monitor.waitForAbort(sleeptime):
            Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
            break

##        Log(repr(thread_cache.show()))

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = (C.this_addon.getSetting('debug').lower() == "true")


    if proxy_thread_crawler:
        if crawler_stop_event: crawler_stop_event.set()
        proxy_thread_crawler = None
    if proxy_thread_recording_service:
        if proxy_thread_recording_service: recording_service_stop_event.set()
        proxy_thread_recording_service = None

##    # start thread for db_maintenance service
##    proxy_thread = threading.Thread(target=db_maintenance, name=utils.addon_id+".db_maintenance")
##    proxy_thread.daemon = True
##    proxy_thread.start()

##    # start thread for link_checker service
##    proxy_thread = threading.Thread(target=link_checker, name=utils.addon_id+".link_checker")
##    proxy_thread.daemon = True
##    proxy_thread.start()

    # add thread to delete dead links for items that are a favourite or in our filter list
    
##    # kill the services if kodi monitor tells us to
##    monitor = xbmc.Monitor()
##    while not monitor.abortRequested():
##        if monitor.waitForAbort(1):
##            Log("shutting down '{}' service".format(C.addon_id), xbmc.LOGNOTICE)
##            break
    
#__________________________________________________________________
#

##
###__________________________________________________________________
###
##def db_maintenance():
##
##    monitor = xbmc.Monitor()
##    ## sleep then ... 
##    sleeptime = int(int(this_addon.getSetting("service_periodic_interval")) * random.random() )
##    Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
##    Sleep(int(sleeptime * 1000))
##    if monitor.waitForAbort(1):
##        Log("ending thread {} due to abort".format(threading.current_thread().name))
##        return
##    
##    while not monitor.abortRequested():
##
##        ## ... do some work
##        try:
##            msq = mysql.MySQL()
##            days_to_keep_links = float(  this_addon.getSetting("days_to_keep_links") )
##            last_date_cleaned = msq.db_get_last_clean_date()
##            if (float(last_date_cleaned) + 60*60*24*days_to_keep_links - 1) < time.time():
##                msq.db_clean_old(days_to_keep_links)
##        except:
##            traceback.print_exc()
##
##        ## sleep then ... 
##        sleeptime = int(this_addon.getSetting("service_periodic_interval")) * 10 
##        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
##        Sleep(sleeptime * 1000)
##        if monitor.waitForAbort(1):
##            Log("ending thread {} due to abort".format(threading.current_thread().name))
##            break
##        
##        #log("last_date_cleaned:{}\nfloat(last_date_cleaned):{}\n60*60*24*days_to_keep_links:{}\ntruefalse:{}\n".format(last_date_cleaned,float(last_date_cleaned),60*60*24*days_to_keep_links,(float(last_date_cleaned) + 60*60*24*days_to_keep_links ) < time.time()))
##        #exit(0)
##
###__________________________________________________________________
###
##def link_checker():
##
##    ## sleep then ... 
##    sleeptime = int(int(this_addon.getSetting("service_periodic_interval")) * 0 * random.random() )
##    Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
##    Sleep(int(sleeptime * 1000))
##    if monitor.waitForAbort(1):
##        Log("ending thread {} due to abort signal".format(threading.current_thread().name))
##        return
##        
##    while not monitor.abortRequested():
##
##        ## ... do some work
##        list_fitered_urls = {}
##        try:
##            enable_link_checker = this_addon.getSetting("enable_link_checker") == "true"
##            if enable_link_checker == True:
##                msq = mysql.MySQL()
##                list_fitered_urls = msq.db_link_getmatchingnames( Get_filters_for_url_validation() )
##        except:
##            traceback.print_exc()
##            
##        for link in list_fitered_urls:
##
##            if monitor.waitForAbort(1):
##                Log("ending thread {} due to abort signal while probing".format(threading.current_thread().name))
##                break
##
##            enable_link_checker = this_addon.getSetting("enable_link_checker") == "true"
##            if enable_link_checker == False:
##                Log("pausing link_checker due to setting.  We will check if we need to restart after {} seconds".format(sleeptime))
##                break
##
##            #Log("service about to probe:{}".format(repr(link))
##            try:
##                url, stream_type, latency = Probe_url(url=link[1],title=link[2])
##                if url:
##                    msq.db_link_update_date_checked(link[1])
##            except:
##                traceback.print_exc()
##
##
##        ## sleep then ... 
##        sleeptime = int(this_addon.getSetting("service_periodic_interval")) / 10
##        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
####        Sleep(sleeptime * 1000)
##        if monitor.waitForAbort(sleeptime):
##            Log("ending thread {} due to abort signal".format(threading.current_thread().name))
##            break


