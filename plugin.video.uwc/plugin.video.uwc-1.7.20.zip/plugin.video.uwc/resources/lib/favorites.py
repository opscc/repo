'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import sqlite3
import xbmc

from resources.lib import webcam_db
from resources.lib import utils
from resources.lib.utils import Log as Log
from xbmc import LOGNONE
from resources.lib import constants as C

from sites.chaturbate import PLAY_MODE as chaturbate_PLAY_MODE
from sites.chaturbate import clean_database as chaturbate_clean
from sites.cam4 import PLAY_MODE as cam4_PLAY_MODE
from sites.cam4 import clean_database as cam4_clean
from sites.streamate import PLAY_MODE as streamate_PLAY_MODE
from sites.streamate import clean_database as streamate_clean
from sites.naked import PLAY_MODE as naked_PLAY_MODE
from sites.naked import clean_database as naked_clean
from sites.bongacams import PLAY_MODE as bongacams_PLAY_MODE
from sites.bongacams import clean_database as bongacams_clean
from sites.myfreecams import PLAY_MODE as mfc_PLAY_MODE
from sites.myfreecams import clean_database as mfc_clean

import time
import traceback

favoritesdb = C.favoritesdb
downloadsdb = C.downloadsdb

#__________________________________________________________________
#
def RefreshImages():
    chaturbate_clean(False)
    cam4_clean(False)
    naked_clean(False)
    mfc_clean(False)
    streamate_clean(False)
    bongacams_clean(False)
#__________________________________________________________________
#
@C.url_dispatcher.register(C.REFRESH_CONTAINER_MODE)  
def RefreshContainter():
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_FAVORITES)  
def List():
    Log("List()")

##    Log("RefreshImages()")
    if C.addon.getSetting("auto_clean_img_database").lower() == "true":
        RefreshImages()

    manually_refresh_favorites = (C.addon.getSetting("manually_refresh_favorites").lower() == "true")
    play_method = str(C.addon.getSetting("default_playmode").lower())


##    utils.endOfDirectory(cacheToDisc=( manually_refresh_favorites==True) )
##    return

    favDB_conn = sqlite3.connect(favoritesdb)
    favDB_conn.text_factory = str
    favDB_cursor = favDB_conn.cursor()
    favDB_cursor.executescript("CREATE TABLE IF NOT EXISTS favorites (name, url, mode, image, description TEXT DEFAULT '');")
    favDB_cursor.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
    try:
        favDB_cursor.executescript("ALTER TABLE favorites ADD COLUMN description  TEXT    DEFAULT '';")
    except:
        pass

##    Log("addDir()")
    utils.addDir(
        name="{}[COLOR {}]Refresh[/COLOR]".format(C.SPACING_FOR_TOPMOST, C.refresh_text_color)
        ,url='' 
        ,mode=C.REFRESH_CONTAINER_MODE 
        ,iconimage=C.refresh_icon
        ,duration=1 #55*60*60+55*60+55 #duration so that when sorting by duration, refresh shows after active webcams
        ,Folder=False )


##    webcam_db.fill_webcam_db()
##    camDB_conn = sqlite3.connect(downloadsdb)
    camDB_conn = webcam_db.fill_webcam_db() #lock so that service can't clear DB during processing
    with camDB_conn:
        try:
            favDB_cursor.execute("SELECT * FROM favorites")
            for (name, url, mode, img, description) in favDB_cursor.fetchall():
                
                try:
    ##                Log("name='{}',url='{}',mode='{}',img='{}'".format(repr(name), repr(url), repr(mode), repr(img)))

                    model_id_via_image = "00000000" # length of 8
                    if str(mode)==mfc_PLAY_MODE:
                        if "/img.mfcimg.com/" in img or "/snap.mfcimg.com/" in img :
                            model_id_via_image = img.split('/')[6]
                            if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                                model_id_via_image = img.split('/')[5]
                            #the 1 indicates model was in public chat when bookmark created
                            if model_id_via_image.startswith("mfc_a_1"):
                               model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
                            if model_id_via_image.startswith("mfc_1"):
                               model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
                            if model_id_via_image[0] == '0':
                                model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
                            img = "https://img.mfcimg.com/photos2/{}/{}/avatar.300x300.jpg".format(model_id_via_image[:3], model_id_via_image)
                            while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
                                model_id_via_image = '0' + model_id_via_image
    ##                    Log("model_id_via_image='{}'".format(repr(model_id_via_image)))

                    camDB_conn.row_factory = sqlite3.Row
                    query = u"select * from camlist where (mode LIKE ?) and ((modelID = ?) or ((icon_image LIKE ?) or (icon_image LIKE ?)) )"#.format(model_id_via_image)
                    try:
                        params = (int(mode),name.decode('utf-8'),u"%/mfc_1{}?%".format(model_id_via_image),u"%/mfc_a_1{}?%".format(model_id_via_image))
                    except:
                        params = (int(mode),name,u"%/mfc_1{}?%".format(model_id_via_image),u"%/mfc_a_1{}?%".format(model_id_via_image))
                        #params = (int(mode),name,u"%{}%".format(model_id_via_image))
##                        Log("name={},url={},mode={},img={}".format(repr(name), repr(url), repr(mode), repr(img)))
                    model = camDB_conn.execute(query,params).fetchone()
                    model_found = (model is not None)
                    
                    if model_found:
                        model = dict(model)
                        Log("query={} params={} ".format(repr(query), repr(params) ))
                        Log("model='{}'".format(repr(model)))
                        Log("name={},url={},mode={},img={}".format(repr(name), repr(url), repr(mode), repr(img)))
                        icon_label = "[COLOR {}]{}[/COLOR]".format(C.search_text_color, name)
                        if str(mode)==mfc_PLAY_MODE:
                            #site allows easy name changes, but no searching via id;
                            current_model_name = model['modelID']
                            if current_model_name != name: #automatically refresh name in fav database
                                Log("new mfc model name '{}' --> '{}'".format(name, current_model_name), xbmc.LOGNOTICE)
                                delFav(
                                    url = name
                                    , img = img
                                    ) #Favorites() was supposed to do the del, but can't because of url value issue
                                Favorites(
                                    fav="refresh"
                                    , favmode=mode
                                    , name=current_model_name
                                    , url = current_model_name
                                    , img = img
                                    , desc = description)


                    else:
                        model = {}
                        icon_label = name
                        model['video_url'] = url
                        model['mode'] = mode
                        model['icon_image'] = img
                        model['camscore'] = 0
                        #model['play_method'] = C.DEFAULT_PLAYMODE
                        if description: model['description'] = description
                        else: model['description'] = ''

                    if 'hq_stream' in model: hq_stream = model['hq_stream']
                    else: hq_stream = 0
                        
                    if 'play_method' in model and model['play_method'] in ('','None','none',None):
                        play_method = None
                    elif 'play_method' in model:
                        play_method = model['play_method']
                    else:
                        play_method = None
    ##                Log("model['play_method']='{}'".format(repr(model['play_method'])))
                    
                    utils.addDownLink( 
                        name = icon_label #model['icon_label'] 
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , duration = model['camscore']
                        , play_method = play_method
                        , fav = 'del'
                        , desc = model['description']
                        , hq_stream = hq_stream
                        )
                    
                except:
                    traceback.print_exc()
            
        except :
            traceback.print_exc()
            utils.notify('No Favorites found')
        finally:
##            if camDB_conn: camDB_conn.close()
            if favDB_conn: favDB_conn.close()
    
    utils.endOfDirectory(cacheToDisc=( manually_refresh_favorites==True) )
#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_MODE, ['fav','favmode','name','url','img'],['desc'])  
def Favorites(fav,favmode,name,url,img,desc=None):
##    Log("name='{}',url='{}',img='{}'".format(name, url, img), LOGNONE)
    if fav in ["add","refresh"]:
        delFav(url, img)
        normalized_name = addFav(favmode, name, url, img, desc)
        utils.Notify("{}ed fav:'{}' url:{}".format(fav.capitalize(),normalized_name,url))
    elif fav == "del":
        delFav(url, img)
        utils.Notify("Deleted fav:{} url:{}".format(name,url))
#__________________________________________________________________
#
def addFav(mode,name,url,img,description):
    n_bak = name
    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = utils.Clean_Filename(name)
    if name in [None,'']: raise Exception("invalid name '{}'".format(n_bak))
##    Log("name='{}'".format(name))
    favDB_conn = sqlite3.connect(favoritesdb)
    favDB_conn.text_factory = str
    favDB_cursor = favDB_conn.cursor()
    favDB_cursor.execute("INSERT INTO favorites VALUES (?,?,?,?,?)", (name, url, mode, img, description))
    favDB_conn.commit()
    favDB_conn.close()
    return name
#__________________________________________________________________
#
def delFav(url, img):
    favDB_conn = sqlite3.connect(favoritesdb)
    favDB_cursor = favDB_conn.cursor()
    favDB_cursor.execute("DELETE FROM favorites WHERE url = '%s'" % url)
    if not img in (None,'','None','none','%'): #try deleting via image for site where name is easily changable
        if "|" in img: img = img.split("|")[0]
        if "?" in img: img = img.split("?")[0]
        sql_command = "DELETE FROM favorites WHERE image LIKE '{}%'".format(img)
##        Log("sql_command='{}'".format(sql_command), LOGNONE)
        favDB_cursor.execute(sql_command)
    favDB_conn.commit()
    favDB_conn.close()
#__________________________________________________________________
#
