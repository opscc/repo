'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]Sextube.nl (Dutch)[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.sextube.nl"
SEARCH_URL = ROOT_URL + '/page/{}/?s={}'
URL_CATEGORIES = ROOT_URL + '/categorieen/'
URL_TOPRATED = ROOT_URL + '/ajax/best_rated/?page=1'
URL_RECENT = ROOT_URL + '/page/{}/?filter=latest'

MAIN_MODE          = C.MAIN_MODE_sextube
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon
        )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(
          end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)


    # read html
    listhtml = utils.getHtml(list_url, ignore404=True)#, ignore404=True , send_back_redirect=True)
    if "Probeer het met een ander zoekwoord" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('class="mobile-pagination"')[0]
        except:
            video_region = listhtml
    #Log("video_region={}".format(video_region))

            

    # parse out list items
    regex = '<article id=".+?href="([^"]+)".+?title="([^"]+)".+?data-src="([^"]+)"(.+?)duration">([^\s<]+)(?:\s|<)'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, hd, duration in info:
        hd = utils.Normalize_HD_String(hd)
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        duration = duration.replace(' min','s').replace(':','m ')
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)        
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , stream = False
            , iconimage = thumb
            , desc = '\n' + ROOT_URL
            , duration = duration)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    #next_page_regex ='<a href="([^"]+)">Volgende<'
    next_page_regex ='class="mobile-pagination".+?/(\d+)[^"]+"><i class=\'fa fa-angle-right\'>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_url = url
        np_number = int(page) + 1
        Log("np_number={}".format(np_number))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number 
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)        
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format('{}', title)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    html = utils.getHtml(url)
    #regex = '<div class="category".*?href="([^"]+)".*?<h2>([^<]+)<.*?src="([^"]+)"'
    regex = '<header class="entry-header".+?href="([^"]+)".+?title="([^"]+)".*?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
##    Log("info='{}'".format(info))
    for url, label, thumb in info:
        if url.startswith('/'): url = ROOT_URL + url
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        url = url + "page/{}/"
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,Folder=True
            ,page=FIRST_PAGE
            )


    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    #2019-10-25 site needs the cookie to return accurate video url
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = ROOT_URL
    headers['Cookie'] = 'pageviews=1; postviews=1'
    
    videopage = utils.getHtml(url, referer='', headers=headers)
    video_url = re.compile('<source src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    if video_url:
        video_url = video_url[0]
    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return

    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
