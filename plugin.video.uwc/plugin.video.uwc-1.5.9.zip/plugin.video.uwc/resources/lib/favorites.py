'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sqlite3

import re

import xbmc, xbmcplugin

from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib.utils import FAVORITES_MODE as FAVORITES_MODE

from sites.chaturbate import clean_database as clean_chaturbate
from sites.chaturbate import camgirl_page as chaturbate_getCamgirlList

from sites.cam4 import clean_database as cleancam4
from sites.naked import clean_database as cleannaked

from sites.myfreecams import getCamgirlList as mfc_getCamgirlList
from sites.myfreecams import getCamgirlInfo as getCamgirlInfo
from sites.myfreecams import clean_database as clean_mfc

import time
import traceback

favoritesdb = utils.favoritesdb

conn = sqlite3.connect(favoritesdb)
c = conn.cursor()
try:
    c.executescript("CREATE TABLE IF NOT EXISTS favorites (name, url, mode, image);")
    c.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
except:
    pass
conn.close()

REFRESH_IMAGES_MODE = '898'
REFRESH_CONTAINER_MODE = '899'
LIST_MODE =  '901'


##@utils.url_dispatcher.register(REFRESH_IMAGES_MODE)
def RefreshImages():
    try:
        #clean_chaturbate(False)
        cleancam4(False)
        cleannaked(False)
        clean_mfc(False)
    except:
        traceback.print_exc()

@utils.url_dispatcher.register(REFRESH_CONTAINER_MODE)  
def RefreshContainter():
    xbmc.executebuiltin('Container.Refresh')

@utils.url_dispatcher.register(LIST_MODE)  
def List():

    if utils.addon.getSetting("auto_clean_img_database").lower() == "true":
        RefreshImages()

    manually_refresh_favorites = (utils.addon.getSetting("manually_refresh_favorites").lower() == "true")
    
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()

    utils.addDir(
        name="{}[COLOR {}]Refresh[/COLOR]".format(utils.SPACING_FOR_TOPMOST, utils.refresh_text_color)
        ,url='' 
        ,mode=REFRESH_CONTAINER_MODE 
        ,iconimage=utils.refresh_icon 
        ,Folder=False )

    
    try:

        chaturbategirls = "" #when testing
        chaturbategirls = chaturbate_getCamgirlList()

        mfcgirls = None #used when testing chaturbate-only
        mfcgirls = mfc_getCamgirlList() #note: slow

        c.execute("SELECT * FROM favorites")        
        for (name, url, mode, img) in c.fetchall():

            try:
                
                if 'chaturbate.com' in url:
                    name = name.split(' [COLOR')[0].strip()
                    regex = 'href="\/{}\/">.+?<img src="([^"]+)".+?"cams".+?,\s+([^v]+)viewers'
                    regex = 'href="\/{}\/".+?img src="([^"]+)".+?class="cams".+?(\d+)\sviewers'
                    
                    match = re.compile(regex.format(name), re.DOTALL | re.IGNORECASE).findall(chaturbategirls)

                    if match:
                        img = match[0][0]
                        camscore=match[0][1]
                        name = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,name)
                        if len(match)> 1:
                            Log("name'{}'score'{}'".format(name,match[1]) )
                        else:
                            Log("name'{}'score'{}'".format(name,0) )

                    else:
                        Log( "'{}' not found in page1".format(name) )
                        camscore=0
                    
                    utils.addDownLink(
                        name = name
                        , url = url
                        , mode = int(mode)
                        , iconimage = img
                        , fav = 'del'
                        , duration=str(int(camscore)*3)
                        , bitrate='fmproxy')
                    #, stream = True #must not be true when using playlist

                elif ('.mfcimg.com' in img) and mfcgirls:
                    #Log("mfc img='{}'".format(name))
                    
                    serverNumber,modelID,hq_stream,camscore, icon_img, icon_label = getCamgirlInfo(name, mfcgirls)
                    if not camscore: camscore=0
                    
                    Log("name={},serverNumber={},modelID={},hq_stream={},camscore={},icon_img={},icon_label={}".format(name,serverNumber,modelID,hq_stream,camscore, icon_img, icon_label))
                    if serverNumber > 0: #    if model server found; an online/active image can be used

                        utils.addDownLink(
                            name = icon_label
                            , url = url
                            , mode = int(mode)
                            , iconimage = icon_img
                            , fav = 'del'
                            , stream = True #must be true to use setResolvedUrl
                            , duration=str(int(camscore))
                            , bitrate='fmproxy'
                            , hq_stream=hq_stream)
                        
                    else:  #else use default
                        if "snap.mfcimg.com/" in img:
                            modelid = img.split('/')[6]
                            #the 1 indicates model was in public chat when bookmark created
                            if modelid.startswith("mfc_a_1"):
                               modelid = modelid[len("mfc_a_1"):] 
                            if modelid.startswith("mfc_1"):
                               modelid = modelid[len("mfc_1"):] 
                            if modelid[0] == '0':
                                modelid = modelid[1:] #trim zero from front
                            
                            img = "https://img.mfcimg.com/photos2/{}/{}/avatar.300x300.jpg".format(modelid[:3], modelid)
                            
                        utils.addDownLink(
                            name = name
                            , url = url
                            , mode = int(mode)
                            , iconimage = img
                            , fav = 'del'
                            , duration=str(int(camscore))
                            )

                elif '.nsimg.net/media' in img:
                    #todo
                    #35548499 is the 'url'
                    #http://m1.nsimg.net/media/snap/35548499.jpg
                    #https://m2.nsimg.net/biopic/320x240/35548499
                    #https://www.streamate.com/search.php?q=annierose
                    #GET www.streamate.com/search.php?q=annierose&sssjson=1 HTTP/1.1
                    #returns json that can be parsed
                    utils.addDownLink(name.strip(), url, int(mode), img, '', '', 'del')
                #not mfc or chaturbate
                else:
                    utils.addDownLink(name.strip(), url, int(mode), img, '', '', 'del')

            except:
                traceback.print_exc()

        
    except Exception,e:
        Log("Exception,e={}".format(str(e)), xbmc.LOGERROR)
        utils.notify('No Favorites','No Favorites found')

    utils.add_sort_method()
    utils.endOfDirectory(cacheToDisc= ( manually_refresh_favorites == True) )

    conn.close()
    return


@utils.url_dispatcher.register(FAVORITES_MODE, ['fav','favmode','name','url','img'])  
def Favorites(fav,favmode,name,url,img):
    if fav == "add":
        delFav(url)
        addFav(favmode, name, url, img)
        utils.notify('Favorite added','Video added to the favorites')
    elif fav == "del":
        delFav(url)
        utils.notify("Deleted fav:{}".format(name)
                     ,"{}".format(url))
        #xbmc.executebuiltin('Container.Refresh')

def clean_filename(s):
    if not s:
        return ''
    s = re.sub(u'(?is)[^A-Za-z0-9~_\]\[ \/,\'.&]','',s)
    return s.strip();

def addFav(mode,name,url,img):

    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = name.strip('\r')
    name = clean_filename(name)
    name = name.strip(' ')
    if "[/COLOR]" in name:
        n1 = name.split("[/COLOR]")
        if n1[1] == '': name = n1[0]
        else: name = n1[1]
        if "[COLOR" in name:
            name = name.split("[COLOR")[0]
        name = name.strip(' ')

    utils.Log("name='{}'".format(name))
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("INSERT INTO favorites VALUES (?,?,?,?)", (name, url, mode, img))
    conn.commit()
    conn.close()

def delFav(url):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM favorites WHERE url = '%s'" % url)
    conn.commit()
    conn.close()
