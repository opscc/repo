'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import urlparse
import json

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT


ROOT_URL = "http://www.porn00.org"

SEARCH_URL = ROOT_URL + "/page/{}/?s={}"

URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/page/{}/'
URL_MOST_VIEWED = ROOT_URL + '/most-viewed/'

MAIN_MODE       = '60'
LIST_MODE       = '61'
PLAY_MODE       = '62'
CATEGORIES_MODE = '63'
SEARCH_MODE     = '64'
STARS_MODE      = '65'
TEST_MODE       = '69'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon)
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')
#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)
        
    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))
    listhtml = utils.getHtml(list_url)
    if "No porn & pornstar were found" in listhtml:
        video_region = ""
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon )
    else: #distinguish between adverts and videos
        #video_region = listhtml.split('id="central"')[1]#.split('id="pagination"')[0]
        video_region = listhtml.split('class="col-md-12"')[1]#.split('id="pagination"')[0]
        
    regex = '<h2>.*?<a title="([^"]+)" href="([^"]+)".*?src="([^"]+)" class="attachment-primary-post-thumbnail'
    regex = '<h2>.*?<a title="([^"]+)" href="([^"]+)".*?src="([^"]+)" class="attachment.+?class="tags"(.+?)</ul>'
    regex = '<h2>.+?title="([^"]+)".+?href="([^"]+)".+?src="([^"]+)" class="attachment.+?class="tags"(.+?)</ul>'
    regex = 'class="post-con".+?title="([^"]+)".+?href="([^"]+)".+?src="([^"]+)" class="attachment.+?class="p5"(.+?)</span>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for label, videourl, thumb, hd in info:
        if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb)


    #
    # next page items
    #
    try:    
        #next_page_html = listhtml.split("class='pagination")[1]

        next_page_regex = "<li class='.+?pagination.+?'>([^<]+)</div>"
        next_page_html = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    
    except:
        next_page_html = listhtml
        
    #next_page_regex = "<span class='current'>([^<]+)<.+?title='Next page' href='([^']+)'"
    next_page_regex = "<li class='active'>([^<]+)</li>"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_number in np_info:
            np_number = int(np_number) + 1
            np_url = url
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, str(np_number))
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

def GetAlternative(url, alternative):
    #progress.update( 70, "", "Loading alternative page", "" )
    if alternative == 1:
        nalternative = 2
        url = url + str(nalternative)
    else:
        nalternative = int(alternative) + 1
        url.replace('/'+str(alternative),'/'+str(nalternative))
    return url, nalternative

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def PPlayvid(url, name, download=None, alternative=1):

    progress = utils.progress
    
    def playvid(videourl, referer):
        progress.close()
        if download == 1:
            utils.downloadVideo(videourl, name)
        else:
            videourl = videourl + "|referer="+ referer
            iconimage = xbmc.getInfoImage("ListItem.Thumb")
            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
            listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
            xbmc.Player().play(videourl, listitem)    
    
    progress.create('Play video', 'Searching videofile.')
    progress.update( 25, "", "Loading video page", "" )
    
    if progress.iscanceled():
        progress.close()
        return
    
    videopage = utils.getHtml(url, '', '', True)
    if re.search('src="https://verystream\.com/e/\S+\.mp4"', videopage, re.DOTALL | re.IGNORECASE):
        progress.close()
        utils.PLAYVIDEO(url, name, download)

    elif re.search('o(?:pen)?load', videopage, re.DOTALL | re.IGNORECASE):
        progress.close()
        utils.PLAYVIDEO(url, name, download)

    elif re.search('video_ext.php\?', videopage, re.DOTALL | re.IGNORECASE):
        match = re.compile('<iframe.*?src="([^"]+video_ext[^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
        progress.update( 30, "", "Opening VK video page", "" )
        videourl = getVK(match[0], progress)
        if not videourl:
            if re.search('id="alternatives"', videopage, re.DOTALL | re.IGNORECASE):
                alturl, nalternative = GetAlternative(url, alternative)
                PPlayvid(alturl, name, download, nalternative)
            else:
                progress.close()
                utils.notify('Oh oh','Couldn\'t find a supported videohost')
        else:
            playvid()

    elif re.search('/\?V=', videopage, re.DOTALL | re.IGNORECASE):
        match = re.compile('<iframe marginheight.*?src="([^"]+player/[^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
        Log("Opening porn00/pornAQ video page")
        iframepage = utils.getHtml(match[0], url)

        videos = re.compile("<source src='.*?(http:[^']+)' title=\"([^\"]+)p\"", re.DOTALL | re.IGNORECASE).findall(iframepage)
        video_url = utils.SortVideos(videos)
        Log("video_url={}".format(video_url))
        video_url = video_url + utils.Header2pipestring() + "&Referer=" + url
        Log("video_url={}".format(video_url))
        utils.playvid(videourl=video_url, name=name, download=download)
        return

    elif re.search('google.com/file', videopage, re.DOTALL | re.IGNORECASE):
        match = re.compile('file/d/([^/]+)/', re.DOTALL | re.IGNORECASE).findall(videopage)
        googleurl = "https://docs.google.com/uc?id="+match[0]+"&export=download"
        progress.update( 50, "", "Opening Google docs video page", "" )
        googlepage = utils.getHtml(googleurl, '')
        video720 = re.compile('"downloadUrl":"([^?]+)', re.DOTALL | re.IGNORECASE).findall(googlepage)
        if not video720:
            if re.search('id="alternatives"', videopage, re.DOTALL | re.IGNORECASE):
                alturl, nalternative = GetAlternative(url, alternative)
                PPlayvid(alturl, name, download, nalternative)
            else:
                progress.close()
                utils.notify('Oh oh','Couldn\'t find a supported videohost')
        else:
            videourl = video720[0]
            playvid()

    elif re.search('id="alternatives"', videopage, re.DOTALL | re.IGNORECASE):
        alturl, nalternative = GetAlternative(url, alternative)
        PPlayvid(alturl, name, download, nalternative)

    else:
        progress.close()
        utils.notify('Oh oh','Couldn\'t find a supported videohost')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format('{}',keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    url = URL_CATEGORIES
    root_url = url.split('/')[0] + '//' + url.split('/')[2]
    html = utils.getHtml(url, '')
    #cathtml = html.split('id="categorias"')[1]
    cathtml = re.compile('class="col-md-12"(.*)', re.DOTALL).findall(html)[0]

    regex = "(?:class=\"cat-item|).+?href=(?:'|\")([^'\"]+)(?:'|\").*?>([^<]+)<"
    regex = 'class="post-con categories".+?title="([^"]+)".+?href="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for label, videourl, thumb  in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        if not videourl.startswith('http'): videourl = root_url + videourl
        videourl = videourl + 'page/{}/'
        #Log("videourl={}".format(videourl))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page=1
            ,iconimage= thumb#utils.search_icon 
            )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#


def getVK(url, progress):

    def __get_private(oid, video_id):
        private_url = 'http://vk.com/al_video.php?act=show_inline&al=1&video=%s_%s' % (oid, video_id)
        html = utils.getHtml(private_url,'')
        html = re.sub(r'[^\x00-\x7F]+', ' ', html)
        match = re.search('var\s+vars\s*=\s*({.+?});', html)
        try: return json.loads(match.group(1))
        except: return {}
        return {}
    
    query = url.split('?', 1)[-1]
    query = urlparse.parse_qs(query)
    api_url = 'http://api.vk.com/method/video.getEmbed?oid=%s&video_id=%s&embed_hash=%s' % (query['oid'][0], query['id'][0], query['hash'][0])
    progress.update( 40, "", "Opening VK video page", "" )
    html = utils.getHtml(api_url,'')
    html = re.sub(r'[^\x00-\x7F]+', ' ', html)
    
    try: result = json.loads(html)['response']
    except: result = __get_private(query['oid'][0], query['id'][0])
    
    quality_list = []
    link_list = []
    best_link = ''
    for quality in ['url240', 'url360', 'url480', 'url540', 'url720']:
        if quality in result:
            quality_list.append(quality[3:])
            link_list.append(result[quality])
            best_link = result[quality]
    
    if quality_list:
        if len(quality_list) > 1:
            result = xbmcgui.Dialog().select('Choose the quality', quality_list)
            if result == -1:
                utils.notify('Oh oh','No video selected')
            else:
                return link_list[result] + '|User-Agent=%s' % (utils.USER_AGENT)
        else:
            return link_list[0] + '|User-Agent=%s' % (utils.USER_AGENT)
    return

