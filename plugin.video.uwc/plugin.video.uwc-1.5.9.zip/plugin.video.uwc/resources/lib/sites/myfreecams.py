'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import re
import sys
import random
import sqlite3
import urllib

import traceback

import inputstreamhelper
import time
import random
import json
import datetime
                
try:     import simplejson
except:  import json as simplejson   

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib import websocket
from resources.lib.utils import Log
from resources.lib.utils import Sleep


import socket
#__user_agent__ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
__USER_AGENT__ = "Mozilla/5.0 (Linux; 5; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebAndroid Kit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36"


import xbmcaddon
ADDON=xbmcaddon.Addon()


MESSAGE_FIELD_LENGTH = None
MAX_READ_COUNT = 100
CAMGIRLSERVER = None
CAMGIRLCHANID = None
CAMGIRLUID = None
CAMGIRL = None
CXID = None
CTXENC = None
TKX = None
SESSION_ID = None
PLATFORM_ID = None

SERV = None
RESPKEY = None
STYPE = None
OPTS = None

serverList = None                

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

FCUOPT_PLATFORM_MFC = 1
FCUOPT_PLATFORM_CAMYOU = 2

vs_str={}
vs_str[0]="PUBLIC"
vs_str[2]="AWAY"
vs_str[12]="PVT"
vs_str[13]="GROUP"
vs_str[14]="GROUP"
vs_str[90]="CAM OFF"
vs_str[127]="OFFLINE"
vs_str[128]="TRUEPVT"

MAIN_MODE    = '270'
LIST_MODE    = '271'
PLAY_MODE    = '272'
REFRESH_MODE = '273'
SEARCH_MODE  = '274'


FCWEXTRESP_URL = None

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    global FCWEXTRESP_URL
    serv, respkey, stype, opts = getRespkey()
    FCWEXTRESP_URL = "https://www.myfreecams.com/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        respkey, stype, opts, serv, random.random(), millitime() ) 
    List( FCWEXTRESP_URL )

#__________________________________________________________________________
#

def arrayPositionForKeyname(array, key):
    i=0
    for val in array:
        if isinstance(val, unicode):
            if val == key:
                return i 
            i += 1
        elif isinstance(val, dict):
            for val2 in val.values():
                if isinstance(val2, (list, dict, tuple)):
                    for val3 in val2:
                        if val3 == key:
                            return i 
                        i += 1
                elif isinstance(val2, unicode):
                    if val2 == key:
                        return i
                    i += 1
    return None

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'])
def List(url):

    utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.refresh_text_color)
        ,url=''
        ,mode=REFRESH_MODE
        ,iconimage=utils.refresh_icon 
        ,Folder=False 
        )
    
    try:
        listhtml = utils.getHtml(url)
    except:
        return None

    json_playlist = json.loads(listhtml)['rdata']

    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ... 
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
    #Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    # ... schema which I don't want [errors during sorting]
    del json_playlist[0] 

    #sort so that top camscore is on top
    entries = sorted(json_playlist, reverse=True, key=lambda camscore: camscore[camscore_index])

    #add list items...
    for playItem in entries:
        if playItem[vs_index] == 0: #only show model in public chat

            serv_number = playItem[camserv_index]
            if Is_new_server(serv_number):
                server439hack = "_a"
                name_hq_prefix = "[COLOR {}]HQ[/COLOR] ".format(utils.time_text_color)
                hq_stream = True
            else:
                server439hack = ""
                name_hq_prefix = ""
                hq_stream = False

            #normalizeServer will return a string such as video1234;
            #I only want to return the 1234 portion
            norm_serv_number = int(filter(str.isdigit,   str(NormalizeServerNumber(serv_number)) )) 

            icon_img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc{}_{}".format( \
                norm_serv_number, \
                server439hack, \
                NormalizeChannelID(playItem[uid_index]))

            Log("icon_img='{}'".format(icon_img))

            camscore = str(int(playItem[camscore_index]))

            model_name = playItem[name_index]
            icon_label = name_hq_prefix + model_name
            Log("icon_label='{}'".format(icon_label))

            alternate_channel = ""
            for altStreamItems in entries:
                if serv_number == altStreamItems[camserv_index]:
                    if altStreamItems[name_index] != model_name:
                        alternate_channel += altStreamItems[name_index] + " "
            
            url = playItem[name_index]
            utils.addDownLink(
                name = icon_label
                , url = url
                , mode = PLAY_MODE
                , iconimage = icon_img
                , duration=str(int(camscore))
                , stream = True #must be true to use setResolvedUrl
                , bitrate='fmproxy'
                , hq_stream = hq_stream
                , desc = alternate_channel
                )

    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

def NormalizeChannelID(uid, platform_id=FCUOPT_PLATFORM_MFC):
    if not isinstance(uid, int):  return 0
    uid = int(uid)
    if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
        return uid + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
    else:
        return uid + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name', 'hq_stream'], ['playmode_string', 'download'])
def Playvid(url, name, hq_stream, playmode_string = '', download = False, ):

    Log ("Playvid url='{}' name='{}' hq_stream='{}' playmode_string='{}' download='{}'".format(url, name, hq_stream, playmode_string, download)  )

    nc_string = str(random.random())
    while len(nc_string) < 17:
        nc_string += str(random.randint(10,99))
                
    #if bool(hq_stream) == False:
    if hq_stream:
        mfc_xchat_host = utils.addon.getSetting(id='mfc_xchat_host')
        Log ("mfc_xchat_host={}".format(mfc_xchat_host))
        websocket_connection = websocket.WebSocket()
        websocket_connection = websocket.create_connection(mfc_xchat_host)
        
        websocket_connection.send("hello fcserver\n\0")
        websocket_connection.send("1 0 0 20071025 0 guest:guest\n\0")
        quitting = 0
        rembuf=""
        while quitting == 0:
            sock_buf = websocket_connection.recv()
            sock_buf = rembuf+sock_buf
            rembuf=""
            while True:
                hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
                if bool(hdr) == 0: break
                fc = hdr.group(1)
                mlen = int(fc[0:4])
                fc_type = int(fc[4:])
                msg=sock_buf[4:4+mlen]
                if len(msg) < mlen:
                    rembuf=''.join(sock_buf)
                    break
                msg=urllib.unquote(msg)
                if fc_type == 1:
                    websocket_connection.send("10 0 0 20 0 %s\n\0" % url)
                elif fc_type == 10:
                    read_model_data(msg, url)
                    quitting = 1
                sock_buf=sock_buf[4+mlen:]
                if len(sock_buf) == 0:
                    break
        websocket_connection.close() 
        if CAMGIRLSERVER > 0:
##            videourl = "http://{}.myfreecams.com:1935/NxServer/ngrp:mfc_{}.f4v_mobile/playlist.m3u8".format( \
##                NormalizeServerNumber(CAMGIRLSERVER), CAMGIRLCHANID)
##https://video762.myfreecams.com    /NxServer/ngrp:mfc_119531282.f4v_mobile/playlist.m3u8?nc=0.5108004147504717



            if Is_new_server(CAMGIRLSERVER):
                server439hack = "_a"
##                hq_stream = True
            else:
                server439hack = ""


            videourl = "https://{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8?nc={}".format( \
                NormalizeServerNumber(CAMGIRLSERVER), server439hack,  CAMGIRLCHANID, nc_string )

            
##            videourl = "http://{}.myfreecams.com:1935/NxServer/ngrp:mfc_{}.f4v_desktop/manifest.mpd".format( \
##                NormalizeServerNumber(CAMGIRLSERVER), CAMGIRLCHANID)
            Log ("videourl={}".format(videourl))
        else:
            Log ("CAMGIRLSERVER={}".format(CAMGIRLSERVER))
            return

##    name = name.strip()
##    Log("name[-len('[/COLOR]')]='{}'".format(name[0:-len('[/COLOR]')]))
##    Log("name[-len('[/COLOR]')]='{}'".format(name[-len('[/COLOR]')]))
##    Log("name[-len('[/COLOR]')]='{}'".format(name[len('[/COLOR]')]))
##    Log("name[-len('[/COLOR]')]='{}'".format(len('[/COLOR]')))
##    
##    if name.endswith('[/COLOR]'):
##        name_regex = "(?:\[color\s*\w*\])\s*([A-Za-z0-9_\-\. ]+)\s*(?:\[\/color\s*\])"
##    else:
##        name_regex = "(?:\[color[^\]]+]HQ\[/color\])*\s*([A-Za-z0-9_\-\. ]+)"
##        
##    name = re.compile(name_regex, re.DOTALL | re.IGNORECASE).findall(name)[0]
##    name = name.strip()
##    download_path = utils.addon.getSetting("download_path").lower()
##    download_path = download_path + name + datetime.datetime.now().strftime(".%Y-%m-%d") + '.mp4'
##    Log("download_path='{}'".format(download_path))
##    return

    else: #hq stream

        videourl = None
        websocket_connection = None
        try:
            videourl, websocket_connection = myfreecam_start(camgirl_to_find=url)
        except:
            traceback.print_exc()
        
        if not videourl or not websocket_connection:
            Log("Could not find a playable webcam link for '{}'".format(name))
            return

    #normServerNumber = NormalizeServerNumber(CAMGIRLSERVER)


    iconimage = xbmc.getInfoImage("ListItem.Thumb")

    listitem = xbmcgui.ListItem(path=videourl)
    #listitem.setInfo('video', {'Title': name})

    #allow playmode to be forced by input command, or use default from addon settings
    if playmode_string == 'fmproxy':
        playmode = 1
    elif playmode_string == 'rtmp':
        playmode = 2
    elif playmode_string == 'inputstream':
        playmode = 3
    else:
        playmode = int(utils.addon.getSetting('chatplay'))
    if download == True:
        playmode = 1 #force this mode to capture

    Log("playmode='{}'".format(playmode))
    
    if playmode == 2: #rtmp
        #2019, the kodi 17,18 rtmp client does not have required options
        utils.Notify("RTMP is not currently supported")
        return

    elif '.mpd' in videourl or playmode == 3: # Inputstream
        Log("videourl has mpd or playmode=3.  Using inputstream.adaptive")
##        listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')

        if  '.mpd' in videourl:
            Log ('setting inputstream type MPD')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            #2019-07-28  Inputstream is bugged...it uses a combination of the property and | trailer to se headers
            mfc_headers = {
                 'Connection': 'keep-alive'
                , 'Origin': 'https://www.myfreecams.com'
                , 'User-Agent': __USER_AGENT__
                , 'DNT': '1'
                , 'Accept': '*/*'
                , 'Referer': 'https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=' + str(int(time.time())) + '&target=main'
                , 'Accept-Encoding': 'gzip, deflate, br'
                , 'Accept-Language': 'en-US,en;q=0.9'
                }
            mfc_headers = {
                    'Accept-Charset': 'UTF-8,*;q=0.8'
                    , 'User-Agent': __USER_AGENT__
                    , 'Accept': '*/*'
                    }

            videourl = videourl + utils.Header2pipestring(mfc_headers)
            listitem.setProperty('inputstream.adaptive.stream_headers', utils.Header2pipestring(mfc_headers)[1:] )
##            listitem.setProperty('inputstream.adaptive.stream_headers', 
##                       'Connection=keep-alive'
##                + '&' +'Origin=https://www.myfreecams.com'
##                + '&' +'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
##                + '&' +'DNT=1'
##                + '&' +'Accept=*/*'
##                + '&' +'Accept-Encoding=gzip, deflate, br'
##                + '&' +'Accept-Language=en-US,en;q=0.9'
##                                 )
            
        else:
            Log ('setting inputstream type HLS')

            mfc_headers = {
                'Connection': 'keep-alive'
                , 'Origin': 'https://m.myfreecams.com'
                , 'User-Agent': __USER_AGENT__
                , 'Referer': 'https://m.myfreecams.com/chats'

            }
    
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
##            if bool(hq_stream) == False:
##                listitem.setProperty('inputstreamaddon', '')
##
##                #'Host':'video629.myfreecams.com'            
##            mfc_headers = {
##                 'Connection':'keep-alive'
##                , 'Origin': 'https://m.myfreecams.com'
##                , 'User-Agent': __USER_AGENT__
##                , 'DNT': '1'
##                , 'Accept': '*/*'
##                , 'Referer': 'https://m.myfreecams.com/chats'
##                , 'Accept-Encoding': 'gzip, deflate, br'
##                , 'Accept-Language': 'en-US,en;q=0.9'
##                , 'Pragma': 'no-cache'
##            }
##            mfc_headers = {
##                    'Accept-Charset': 'UTF-8,*;q=0.8'
##                    , 'Accept': '*/*'
##                    , 'User-Agent': __USER_AGENT__
##                    }
####, 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
####                , 'Sec-Fetch-Site': 'same-site'
####                , 'Sec-Fetch-Mode': 'cors'
##
##            #2019-07-28  Inputstream is bugged...it uses a combination of the property and | trailer to se headers
##            videourl = videourl + utils.Header2pipestring(mfc_headers)
####            listitem.setProperty('inputstream.adaptive.stream_headers'
####                                , 'User-Agent=' + 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
####                                + "&Connection=keep-alive"
####                                + "&Origin=https://m.myfreecams.com"
####                                + "&Accept=*/*"
####                                + "&Referer=https://m.myfreecams.com/chats"
####                                + '&Accept-Encoding=gzip, deflate, br'
####                                + '&Accept-Language=en-US,en;q=0.9'
####                                )
            listitem.setProperty('inputstream.adaptive.stream_headers', utils.Header2pipestring(mfc_headers)[1:] )
    else:
        Log ("not .mpd")

        if playmode == 1: # F4mProxy
            mfc_headers = {
                'User-Agent': __USER_AGENT__
                , 'Accept': '*/*'
                , 'Referer': 'https://m.myfreecams.com/chats'
                , 'Accept-Encoding': 'gzip, deflate, br'
                , 'Accept-Language': 'en-US,en;q=0.9'
                }

            mfc_headers = {
                    'User-Agent': __USER_AGENT__
                    ,'Accept-Charset': 'UTF-8,*;q=0.8'
                    , 'Accept': '*/*'
                    }

##            mfc_headers = {
##                    'Accept-Charset': 'UTF-8,*;q=0.8'
##                    , 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36'
##                    , 'Accept': '*/*'
##                    }

            m3u8stream = "{}?nc={}{}".format(videourl, nc_string, utils.Header2pipestring(mfc_headers))
            m3u8stream = "{}{}".format(videourl, utils.Header2pipestring(mfc_headers))
            Log("fmproxy m3u8stream='{}' {}".format(m3u8stream, int(utils.addon.getSetting('max_bit_rate'))*1000*1000))
            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            if download == True:
                name = name.strip()
                #name_regex = "(?:\[color\s*\w*\]|)([A-Za-z0-9_\-\. ]+)(?:\[\/color\s*\]|)"
                if name.endswith('[/COLOR]'):
                    name_regex = "(?:\[color\s*\w*\])\s*([A-Za-z0-9_\-\. ]+)\s*(?:\[\/color\s*\])"
                else:
                    name_regex = "(?:\[color[^\]]+]HQ\[/color\])*\s*([A-Za-z0-9_\-\. ]+)"
                name = re.compile(name_regex, re.DOTALL | re.IGNORECASE).findall(name)[0]
                name = name.strip()
                download_path = utils.addon.getSetting("download_path").lower()
                download_path = download_path + name + datetime.datetime.now().strftime(".%Y-%m-%d") + '.mp4'
                Log("download_path='{}'".format(download_path))
            else:
                download_path = None

            f4mp.playF4mLink(
                m3u8stream
                , name
                , proxy = None
                , use_proxy_for_chunks = False
                , maxbitrate = int(utils.addon.getSetting('max_bit_rate'))*1000*1000
                , simpleDownloader = False
                , auth = None
                , streamtype = 'HLSRETRY'
                , setResolved = False
                , swf = None
                , callbackpath = ""
                , callbackparam = ""
                , iconImage = iconimage
                , download_path = download_path
                )
##            , streamtype = 'HLSREDIR'
            
            return
        

##
##
##GET https://video762.myfreecams.com/NxServer/ngrp:mfc_119531282.f4v_mobile/playlist.m3u8?nc=0.5108004147504717 HTTP/1.1
##Host: video762.myfreecams.com
##Connection: keep-alive
##Origin: https://m.myfreecams.com
##User-Agent: Mozilla/5.0 (Linux; 5; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebAndroid Kit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36
##DNT: 1
##Accept: */*
##Sec-Fetch-Site: same-site
##Sec-Fetch-Mode: cors
##Referer: https://m.myfreecams.com/chats
##Accept-Encoding: gzip, deflate, br
##Accept-Language: en-US,en;q=0.9
##
##
    mfc_headers = {
        'Connection': 'keep-alive'
        , 'Origin': 'https://m.myfreecams.com'
        , 'User-Agent': __USER_AGENT__
        , 'Referer': 'https://m.myfreecams.com/chats'

    }
##        , 'DNT': '1'
##        , 'Accept': '*/*'
##        , 'Accept-Encoding': 'gzip, deflate, br'
##        , 'Accept-Language': 'en-US,en;q=0.9'
        
##GET https://video710.myfreecams.com/NxServer/ngrp:mfc_105122207.f4v_mobile/playlist.m3u8?nc=0.737523132829 HTTP/1.1
##User-Agent: Mozilla/5.0 (Linux; 5; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebAndroid Kit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36
##Range: bytes=0-
##Host: video710.myfreecams.com
##Icy-MetaData: 1
##Accept: */*
##Accept-Language: en-US,en;q=0.9
##Connection: keep-alive
##DNT: 1
##Origin: https://m.myfreecams.com
##Referer: https://m.myfreecams.com/chats


##    if not playmode == 2 and not ('.mpd' in videourl or playmode == 3) : #rtmp
##    if not '|' in videourl:
    videourl = videourl + utils.Header2pipestring(mfc_headers)

    Log ("videourl={}".format(videourl))

##    websocket_connection.close()
##    return



    if int(sys.argv[1]) == 1:
        Log ("NOT using setResolvedUrl")
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        #pl.add(videourl, listitem)
        #xbmc.Player().play(pl)
        Log ("using play")
        listitem.setPath(videourl)
        xbmc.Player().play(videourl, listitem)
    else:
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        Log ("using setResolvedUrl")

        listitem.setContentLookup(False)
        listitem.setInfo(type="Video", infoLabels={"title": name, "plot": name, "plotoutline": name})
        listitem.addStreamInfo('video', {'codec': 'h264'})
    
        listitem.setPath(videourl)
        xbmcplugin.setResolvedUrl( utils.addon_handle , True, listitem) #False becase I dont want checkbak

##    #start separate thread to keep websocket alive 10:57:49.688 10:58:08.688
##    #0 0 0 0 0 \n\0 #send ping; recv  20-30 msgs; wait 0.5sec
##    try:
##        while True:
##            Sleep(500+random.randint(10,30))
##            getPlayingFile = None
##            if xbmc.Player().isPlaying():
##                getPlayingFile = xbmc.Player().getPlayingFile()
##                Log ("getPlayingFile={}".format(getPlayingFile))
##            if videourl != getPlayingFile:    #otherwise a different player has been started 
##                Log("exiting play infinite loop because a different program is doing the playing now[current_play_item={},getPlayingFile={}]".format(videourl,getPlayingFile), xbmc.LOGNONE)
##                break
##
##            websocket_search_command = "0 0 0 0 0\n\0"
##            websocket_connection.send(websocket_search_command)
##            recv_count = 0
##            max_recv_count = random.randint(10,30)
##            while recv_count > max_recv_count:
##                Sleep(5)
##                sock_buf = websocket_connection.recv()
##                Log("rawsock_buf:%s"%sock_buf)
##                recv_count = recv_count + 1    
##            
##    except:
##        traceback.print_exc()
##        websocket_connection.close()
        
##    manifest_type = listitem.getProperty('inputstream.adaptive.manifest_type')
##    if  manifest_type == 'hls':
##        Log ("exiting because inputstream.adaptive.manifest_type={}".format(manifest_type))
##        return
##    else:
##        Log ("inputstream.adaptive.manifest_type={}".format(manifest_type))
##
##    #start separate thread to keep websocket alive 10:57:49.688 10:58:08.688
##    websocket_connection = None
##    attempts = 0
##    max_attempts = 2
##    try:
##        while True:
##
##            Sleep(30*1000+random.randint(10,30)) #sleep before checking if something is playing because startup takes time
##
##            getPlayingFile = None
##            if xbmc.Player().isPlaying():
##                getPlayingFile = xbmc.Player().getPlayingFile()
##                Log ("getPlayingFile={}".format(getPlayingFile))
##            else:
##                Log ("exiting because nothing is playing")
##                break
##            
##            if videourl != getPlayingFile:    #otherwise a different player has been started 
##                Log("exiting play infinite loop because a different program is doing the playing now[current_play_item={},getPlayingFile={}]".format(videourl,getPlayingFile), xbmc.LOGNONE)
##                break
##
##            websocket_connection = None
##            attempts = 0
##            while (not websocket_connection) and (attempts < max_attempts):
##                websocket_connection = getChatServerWebsocket('20080910') ##message styles are from mfc_mobile
##                Sleep(1)
##                attempts = attempts + 1
##
##            if websocket_connection:
##                websocket_connection.close()
##            
##    except:
##        traceback.print_exc()
##        if websocket_connection:
##            websocket_connection.close()
        

def valid_info():
    if CAMGIRLSERVER < 0 :
        Log('valid_info: missing camgirlserver')
        return False
    if CAMGIRLCHANID < 0:
        Log('valid_info: missing CAMGIRLCHANID')
        return False
    if CAMGIRLUID < 0:
        Log('valid_info: missing CAMGIRLUID')
        return False
    if not CAMGIRL:
        Log('valid_info: missing CAMGIRL')
        return False
    if not CXID:
        Log('valid_info: missing CXID')
        return False
    if not CTXENC:
        Log('valid_info: missing CTXENC')
        return False
    if not TKX:
        Log('valid_info: missing TKX')
        return False
    if not PLATFORM_ID:
        Log('valid_info: missing PLATFORM_ID')
        return False

    return True
    
def fc_decode_json(m):
    try:
        m = m.replace('\r', '\\r').replace('\n', '\\n')
        return simplejson.loads(m[m.find("{"):].decode("utf-8","ignore"))
    except:
        return simplejson.loads("{\"lv\":0}")

def read_model_data(m, camgirl_to_find):
    global CAMGIRLSERVER
    global CAMGIRLCHANID
    global CAMGIRLUID
    global CAMGIRL
    global PLATFORM_ID

    camgirl_to_find = camgirl_to_find.lower() 
    Log("\n read_model_data [msg='<>', camgirl_to_find='{}'] \n".format(camgirl_to_find))

    msg = fc_decode_json(m)
    Log( "msg:%s" % simplejson.dumps(msg) )

    try:
        if msg['uid'] == 0:
            return # these lines don't have any more useful information    
    except:
        pass

    try:
        if msg['uid'] == camgirl_to_find:
            Log( "uid:%s" % camgirl_to_find, xbmc.LOGERROR )
            
    except:
        return
    
    try:
        if camgirl_to_find == msg['nm'].lower():
            CAMGIRL = msg['nm'] #make sure we know who we are talking to:  'nm' can exist multiple places
    except:
        return
    
    if CAMGIRL:

        #vs = visibility status; 0 value means in public chat...don't know how to parse group/private chats
        vs = msg['vs']
        if not (vs == 0):
            vs_string=vs_str[vs]
            utils.notify(msg="{} is {}".format(CAMGIRL, vs_string) )
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            CAMGIRLCHANID = -1
            CAMGIRLUID = -1
            return

        try:
            CAMGIRLUID    = msg['uid']
            PLATFORM_ID   = msg['pid']
            if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
                CAMGIRLCHANID = msg['uid'] + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
            else:
                CAMGIRLCHANID = msg['uid'] + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
        except:
            pass

        u_info=msg['u']
        try:
            CAMGIRLSERVER = u_info['camserv']
        except KeyError:
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            pass
        except Exception, e:
            #Log(('parsing msg dictionary for name:%s' % str(e) ), xbmc.LOGERROR)
            pass

def millitime():
    return int(time.time()) * 1000


def getServerList():
    global serverList

    last_serverlist_refresh = utils.addon.getSetting('last_serverlist_refresh')
##    Log("last_serverlist_refresh='{}'".format((last_serverlist_refresh)))
##    Log("last_serverlist_refresh='{}'".format(type(last_serverlist_refresh)))
    #known bug with strptime
    #last_serverlist_refresh = datetime.strptime(last_serverlist_refresh, "%Y-%m-%d")
    last_serverlist_refresh = datetime.datetime(*(time.strptime(last_serverlist_refresh, "%Y-%m-%d")[0:6]))
##    Log("last_serverlist_refresh='{}'".format((last_serverlist_refresh)))
##    Log("last_serverlist_refresh='{}'".format(type(last_serverlist_refresh)))

    today = datetime.datetime.now().strftime("%Y-%m-%d")
    today = datetime.datetime(*(time.strptime(today, "%Y-%m-%d")[0:6]))
    if not isinstance(last_serverlist_refresh, datetime.date):
        last_serverlist_refresh = datetime.date(1980, 1, 1)

##    Log("last_serverlist_refresh='{}'".format(last_serverlist_refresh))
##    Log("today='{}'".format(today))
##    Log("today='{}'".format( (last_serverlist_refresh >= today) ))
    if last_serverlist_refresh >= today:  # then we can read list from settings
        mfc_serverlist = utils.addon.getSetting('mfc_serverlist')
        Log("using server list from settings")
        serverList = json.loads(mfc_serverlist)

    if serverList:
        return serverList

##    #connect to root to avoid 'unusual' activity detection
##
##    if ADDON.getSetting('use_mobile_stream').lower() == "true":
##        url="https://m.myfreecams.com".format(random.random())
##    else:
##        url="https://www.myfreecams.com".format(random.random())
##
##    url="https://m.myfreecams.com/chats".format(random.random())
##    try:
##        listhtml = utils.getHtml(url)
##    except:
##        traceback.print_exc()
##        return None

    #connect to one of the chat servers; random since we don't know how to parse page
    #we need to use 8080 because the other choice, https, does not work with websocket
    url="https://m.myfreecams.com/configproxy.php".format(random.random())
    #post summer 2019
    #https://www.myfreecams.com/_js/serverconfig.js?_=1574525594465
    url="https://www.myfreecams.com/_js/serverconfig.js?_={}".format(random.random())

    try:
        listhtml = utils.getHtml(url)
    except:
        traceback.print_exc()
        return None

    serverList = simplejson.loads(listhtml)

    utils.addon.setSetting(id='last_serverlist_refresh', value=today.strftime("%Y-%m-%d"))    
    utils.addon.setSetting(id='mfc_serverlist', value=listhtml)

    
    return serverList

def chatserverList():
    return getServerList()['chat_servers']

def h5videoserverList():
    return getServerList()['h5video_servers']

def ngvideoserverList():
    return getServerList()['ngvideo_servers']

def wzvideoserverList():
    return getServerList()['wzobs_servers']



def NormalizeServerNumber(server):
##    Log("\n NormalizeServerNumber [{}] \n".format(server))

    result_server = server
    try:
        result_server = ngvideoserverList()[str(server)]
    except:
        try:
            result_server = h5videoserverList()[str(server)]
        except:
            try:
                result_server = wzvideoserverList()[str(server)]
            except:
                result_server = 'video' + str(server)

##    Log("result_server='{}'".format(result_server))
    return result_server

def getChatServerWebsocket(login_version='20071025'):

    global SESSION_ID
    global CXID
    global CTXENC
    global TKX
    global SERV
    global RESPKEY
    global STYPE
    global OPTS
    global MESSAGE_FIELD_LENGTH
    
    Log("\n getChatServerWebsocket [{}] \n".format(login_version))
    
    xchat = chatserverList()

    #MESSAGE_FIELD_LENGTH = 6 #for 2018 messages

    sock_buf=None
    ws = None
    failed_count = 0
    failed_count_max = 4

    while not ws and (failed_count < failed_count_max):
        try: 
            #server_number = str(random.choice(xchat))
            #host = "ws://xchat"+server_number+".myfreecams.com:8080/fcsl"
            #host = "wss://xchat"+server_number+".myfreecams.com/fcsl"

            FCTYPE_EXTDATA = 81
            FCTYPE_LOGIN = 1
            
##            url="https://api.myfreecams.com/dc?nc={}&site=mobileweb".format(random.random())
##            
##            try:
##                start_time = millitime()
##                listhtml = utils.getHtml(url)
##                stop_time = millitime()
##            except:
##                try:
##                    listhtml = utils.getHtml(url)
##                    stop_time = millitime()
##                except:
##                    raise
##
##            temp_cid = simplejson.loads(listhtml)['result']['cid']
##            temp_key = simplejson.loads(listhtml)['result']['key']
##            temp_time = int(simplejson.loads(listhtml)['result']['time'])

##            socket_message_1 = "{} 0 0 {} 0 ".format(FCTYPE_LOGIN, FCTYPE_EXTDATA)
##            
##            socket_message_2 = '"err":0,"start":{},"stop":{},"a":9841,"time":{},"key":"{}","cid":"{}","pid":{},"site":"mobileweb"'.format( \
##                       start_time, stop_time, temp_time, temp_key, temp_cid, FCUOPT_PLATFORM_MFC)
##            socket_message_2 = '{'+socket_message_2+'}'
##            socket_message_2 = urllib.quote(socket_message_2)
##            socket_message = socket_message_1 + socket_message_2


            ws = None
            while not ws and (failed_count < failed_count_max):
                try:
                    failed_count += 1
                    
                    #host = "wss://{}.myfreecams.com/fcsl".format(random.choice(xchat))
##                    host = "wss://{}.myfreecams.com/fcsl".format( \
##                        random.choice(xchat) \
##                        , '|Sec-WebSocket-Version=13&Sec-WebSocket-Extensions=permessage-deflate; client_max_window_bits'
##                        )
                    
                    host = None
                    while host == None and (failed_count < failed_count_max):
                        host = random.choice(xchat)
##                        Log("connecting to host '{}'".format(host) )
##                        Log("connecting to host '{}'".format(host[0:1]) )
                        if host[0:1] == 'x': #there are some ychat servers
##                            host = "wss://{}.myfreecams.com/fcsl".format( \
##                                host \
##                                , '|Sec-WebSocket-Version=13&Sec-WebSocket-Extensions=permessage-deflate; client_max_window_bits'
##                                )
                            host = "ws://{}.myfreecams.com:8080/fcsl".format( \
                                host )
                            Log(" host[3]={} ".format( host[3]) )
                            if host[3] == ':':
                                MESSAGE_FIELD_LENGTH = 6 #for 2018 messages
                            else:
                                MESSAGE_FIELD_LENGTH = 4 #pre 2018 messages
                        else:
##                            Log("connecting to host '{}'".format(host[0:1]) )
                            failed_count += 1
                            host = None
                            
                    Log("connecting to host '{}'".format(host) )
                    ws = websocket.create_connection(host)

                    utils.addon.setSetting(id='mfc_xchat_host', value=host)
                    
                    ##testing
                    #websocket.enableTrace(True)
                    #ws = websocket.WebSocket()
                    #failed_count = failed_count_max
                    #host = 'ws://demos.kaazing.com/echo'
                    #ws = websocket.create_connection(host)
                    #ws = websocket.create_connection(host, http_proxy_host='127.0.0.1',http_proxy_port=8888)
                    #return
                except:
                    traceback.print_exc()
                    time.sleep(0.1)
                    ws = None

            
            #time.sleep(0.1)

            ws.send("hello fcserver\n\0")
#            ws.send("fcsws_20180422\n\0")
#            ws.send(socket_message + "\n\0")

##            if login_version=='20080910':
##                ws.send('0 0 0 0 0 -' + "\n\0")

            socket_message = "{} 0 0 {} 0 1/guest:guest".format(FCTYPE_LOGIN, login_version)
            ws.send(socket_message + "\n\0" )

            
            sock_buf=None
            sock_buf = ws.recv()
            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            temp_login_id = hdr.group(6)
            SESSION_ID = hdr.group(3)

            sock_buf=None
            quitting = 0
            fc = None
            readcount = 0
            while quitting == 0:
                sock_buf = ws.recv()
                readcount = readcount + 1
                if readcount > 10: break #infinite loop detection
                while len(sock_buf) > 0:
                    hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
                    fc = hdr.group(1)
                    Log("fc={}".format(fc) )
                    #first bytes of fc tells us size of message
                    #rest of bytes in fc is the fc message type
                    msg_type = int(fc[MESSAGE_FIELD_LENGTH:])
                    Log("msg_type={}".format(msg_type) )

                    mlen = int(fc[0:MESSAGE_FIELD_LENGTH])# characters from position 0 (included) to 6 (excluded)
                    msg=sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH+mlen] 
                    if len(msg) < mlen:
                        Log("len(msg) {} < mlen {}".format(len(msg), mlen))

                    FCTYPE_MODELGROUP = 33
                    FCTYPE_TKX = 30
                    FCTYPE_EXTDATA = 81
                    FCTYPE_DETAILS = 5
                    FCTYPE_ADDIGNORE = 7
                    FCTYPE_SESSIONSTATE = 20
                    
                    msg = fc_decode_json(urllib.unquote(msg))

                    if msg_type == FCTYPE_TKX:
                        try:
                            CXID = msg['cxid']
                            CTXENC = urllib2.unquote(msg['ctxenc'])
                            TKX = msg['tkx']
##                            Log( "CxID={}".format(CXID) )
##                            Log( "TKX={}".format(TKX) )
##                            Log( "CTXENC={}".format(CTXENC) )
                            break # these lines don't have any more useful information
                        except:
                            pass

                    if msg_type == FCTYPE_EXTDATA:
                        try:
                            if not SERV: #these variables are sent twice differently - we only need the first
                                SERV = msg['serv'] #the xchatserver we are talking to
                                RESPKEY = msg['respkey'] 
                                STYPE = msg['type']
                                OPTS = msg['opts']
                                break # these lines don't have any more useful information
                            #return serv, respkey, stype, opts
                        except:
                            pass

                    if msg_type == FCTYPE_DETAILS:
                        try:
                            SESSION_ID = msg['sid']
##                            Log( "SESSION_ID={}".format(SESSION_ID) )
##                            uid = int(msg['uid'])
##                            if uid == 0:
##                                SESSION_ID = msg['sid']
##                                Log( "GuestID={}".format(msg['nm']) )
                            break # these lines don't have any more useful information
                        except:
                            traceback.print_exc()
                            pass

                    if msg_type == FCTYPE_SESSIONSTATE:
                        quitting = 1 #all necessary info should be here by now
                        
                    sock_buf=sock_buf[MESSAGE_FIELD_LENGTH+mlen:]


        except Exception, e:
            failed_count += 1
            traceback.print_exc()
            #Log("xchat server '{}' could not be opened [{}]".format(repr(e), failed_count))
            ws = None


    return ws
    
def getRespkey(camgirl_to_find=''):

    if not SERV:
        ws = getChatServerWebsocket()
        if ws:
            ws.close()

    return SERV, RESPKEY, STYPE, OPTS

def getCamgirlList():
    Log("\n mfc getCamgirlList {} \n".format(''))
    #return json-like list of online models
    serv, respkey, stype, opts = getRespkey()

    #https://www.myfreecams.com/php/FcwExtResp.php?respkey=1317370146&type=14&opts=256&serv=74  &nc=0.9482386169606472&_=1574525719448
    #https://www.myfreecams.com/php/FcwExtResp.php?respkey=1823878848&type=14&opts=256&serv=49  &nc=0.5449995113      &_=1574784440.56
    #https://www.myfreecams.com/php/FcwExtResp.php?respkey=1814290054&type=14&opts=256&serv=1488&nc=0.65319852890623  &_=1574784754000
    nc_string = str(random.random())
    while len(nc_string) < 18:
        nc_string += str(random.randint(10,99))
    url = "https://www.myfreecams.com/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        respkey, stype, opts, serv, nc_string, millitime() )

    try:
        listhtml = utils.getHtml(url)
    except:
        return None

    return json.loads(listhtml)['rdata'] 

def getCamgirlInfo(camgirl_to_find, json_playlist):
    #Log("\n getCamgirlInfo [{},{}] \n".format(camgirl_to_find, json_playlist[0]))

    if not json_playlist:
        return None, None, None, None

    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ... 
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
    #Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    #del json_playlist[0] #we may not delte this entry because variable is by reference and future calls may need it
    
    key = camgirl_to_find #'HotAnnelisse'
    for item in json_playlist:
        if item[name_index] == key:
            Log("\n getCamgirlInfo [{},{}] \n".format(camgirl_to_find, repr(item)))
            if item[vs_index] !=0:  #return null if not online
                return None, None, None, None, None, None
            
            camserv = int(item[camserv_index])
            is_new_server  = Is_new_server(camserv)
            modelID = NormalizeChannelID(item[uid_index])

            #normalizeServer will return a string such as video1234; I only want the number
            serverNumber = int(filter(str.isdigit,   str(NormalizeServerNumber(camserv)) )) 

            if is_new_server:
                is_new_server_hack = 'a_'
            else:
                is_new_server_hack = ''

            icon_img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc_{}{}".format(serverNumber,is_new_server_hack,modelID)
            icon_img += "?no-cache="+str(time.time()*100) #add randomization for caching proxies
            Log("icon_img='{}'".format(icon_img))

            icon_label = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color, camgirl_to_find)
            if is_new_server: #add some color for hq streams
                icon_label += " [COLOR {}]HQ[/COLOR]".format(utils.time_text_color)



            camscore = int(item[camscore_index])
            
            #Log("\n getCamgirlInfo returning [{},{},{},{}] \n".format(key, camserv, modelID, is_new_server  ))
            return serverNumber, modelID, is_new_server, camscore, icon_img, icon_label
            break

    return None, None, None, None, None, None

def Is_new_server(camserv):
    #corresponds to "onWzObsVideoServer" json information that we may need to start parsing
    #GET https://www.myfreecams.com/_js/serverconfig.js?_=1583266403437
    try:
        
        server = ngvideoserverList()[str(camserv)]
        #log ("return Is_new_server = true")
        return True
    except:
        try:
            #wzvideoserverList  seems to be webRTC ??? , which is some time of encrypted RTMP
            server = wzvideoserverList()[str(camserv)]
            #log ("return Is_new_server = true")
            return True
        except:
            #log ("return Is_new_server = false")
            return False

    return    (camserv in range(545,559))        \
                        or (camserv in range(437,440))  \
                        or (camserv in range(888,897))  
    

def myfreecam_start(camgirl_to_find):

    camgirl_to_find = camgirl_to_find.lower()

    Log("\n myfreecam_start [{}] \n".format(camgirl_to_find))

    websocket_connection = None
    attempts = 0
    max_attempts = 2
    while (not websocket_connection) and (attempts < max_attempts):
        #websocket_connection = getChatServerWebsocket('20080910') ##message styles are from mfc_desktop
        websocket_connection = getChatServerWebsocket('20071025')  ##message styles are from mfc_mobile
        time.sleep(0.2)
        attempts = attempts + 1
    if not websocket_connection:
        utils.notify( "Failed to get websocket connection.  Check internet connection or try later")
        return '', None


##MESSAGE_FIELD_LENGTH = None
##MAX_READ_COUNT = 100
##CAMGIRLSERVER = None
##CAMGIRLCHANID = None
##CAMGIRLUID = None
##CAMGIRL = None
##CXID = None
##CTXENC = None
##TKX = None
##SESSION_ID = None
##PLATFORM_ID = None
##
##SERV = None
##RESPKEY = None
##STYPE = None
##OPTS = None    

    nc_string = str(random.random())
    while len(nc_string) < 18:
        nc_string += str(random.randint(10,99))
    url = "https://www.myfreecams.com/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        RESPKEY, STYPE, OPTS, SERV, nc_string, millitime() )
    try:
        listhtml = utils.getHtml(url)
    except:
        raise    

    rembuf=""
    quitting = 0
    readcount = 0

    FCTYPE_USERNAMELOOKUP = 10
    FCTYPE_ROOMDATA = 44

    websocket_search_command = "{} {} 0 {} 0 {}".format(FCTYPE_USERNAMELOOKUP, SESSION_ID, int(time.time()), camgirl_to_find)
##    Log("websocket_search_command=" + websocket_search_command)
    websocket_connection.send(websocket_search_command+"\n\0")

    websocket_search_command = "{} {} 0 1 0".format(FCTYPE_ROOMDATA, SESSION_ID)
    Log("websocket_search_command=" + websocket_search_command)
    websocket_connection.send(websocket_search_command+"\n\0")

##    ws.close()
##    return '', None

    #MESSAGE_FIELD_LENGTH = 6 #for 2018 messages
    #MESSAGE_FIELD_LENGTH = 4 #for 2017 messages
    while quitting == 0:
        
        readcount = readcount + 1
        if readcount > MAX_READ_COUNT: # infinite loop check
            break

        sock_buf = websocket_connection.recv()

        while len(sock_buf) > 0: 
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX
    #        Log("rawsock_buf:%s"%sock_buf)

            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            if bool(hdr) == 0:
                #Log ("bool(hdr) == 0:")
                #quitting=1
                break #recv() again for the response we need

            fc = hdr.group(1)
            mlen = int(fc[0:MESSAGE_FIELD_LENGTH]) #sometimes multiple messages are part of same recv
            msg_type = int(fc[MESSAGE_FIELD_LENGTH:])
##            Log("msg_type={}".format(msg_type) )

            if msg_type == FCTYPE_USERNAMELOOKUP:

                FCRESPONSE_ERROR = 1
                if int(hdr.group(5)) == FCRESPONSE_ERROR:
                    utils.Notify(msg="'{}' renamed or deleted".format(camgirl_to_find))
                    quitting=1
                    break

                msg = sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH + mlen]
    ##            if len(msg) < mlen: #check for long msgs that required multiple rcvs
    ##                rembuf=''.join(sock_buf)
    ##                #Log ("len(msg) < mlen")
    ##                break
                read_model_data( urllib.unquote(msg) , camgirl_to_find) 

            #we are definitely done when the information for the camgirl shows up and/or offline
            validInfo = valid_info()
            if validInfo or CAMGIRLSERVER == -1:
                quitting=1
                Log ("valid_info()={} or CAMGIRLSERVER == -1".format(validInfo))
                break

            #otherwise, trim the message we have processed
            sock_buf = sock_buf[MESSAGE_FIELD_LENGTH + mlen:]
            if len(sock_buf) == 0: #there was only one message in this receive
                #log ("len(sock_buf) == 0:")
                break


##    #summer 2019 - we can't close it because web traffic monitor will kick us off(?)
##    websocket_connection.close()
        
    if readcount > MAX_READ_COUNT:
        utils.notify(msg= "{} was not found.  Maybe renamed".format(camgirl_to_find), duration=10000, sound=False)
        #if ws: ws.close()
        return '', None
    
    if not valid_info() or (CAMGIRLSERVER < 1) :
        #utils.notify( msg = ("{} is not online".format(camgirl_to_find)) )
        websocket_connection.close()
        return '', None

    #join the websocket channel to make sure we dont get disconnect(?)
    FCTYPE_JOINCHAN = 51
    FCCHAN_JOIN = 1
    FCCHAN_HISTORY = 8
    FCCHAN_PART = 2
    
##    #51 0 0 121523305 9 #mobleweb
##    #51 702045999 0 121523305 9 #fullsite
##    websocket_command = "{} 0 0 {} {}".format( \
##        FCTYPE_JOINCHAN
##        , CAMGIRLCHANID
##        , FCCHAN_JOIN + FCCHAN_HISTORY)
##    Log("websocket_command=" + websocket_command)
##    websocket_connection.send(websocket_command+"\n\0")


##    #start separate thread to keep websocket alive 10:57:49.688 10:58:08.688
##    #0 0 0 0 0 \n\0 #send ping; recv  20-30 msgs; wait 0.5sec
##    try:
##        while False:
##            Sleep(500+random.randint(10,300))
####            getPlayingFile = None
####            if xbmc.Player().isPlaying():
####                getPlayingFile = xbmc.Player().getPlayingFile()
####                Log ("getPlayingFile={}".format(getPlayingFile))
####            if videourl != getPlayingFile:    #otherwise a different player has been started 
####                Log("exiting play infinite loop because a different program is doing the playing now[current_play_item={},getPlayingFile={}]".format(videourl,getPlayingFile), xbmc.LOGNONE)
####                break
##
##            recv_count = 0
##            max_recv_count = 5000 #random.randint(10,30)
##            Sleep(100)
##
##            while recv_count < max_recv_count:
##
##                sock_buf = websocket_connection.recv()
##                recv_count = recv_count + 1
##
##                send_ping = False
##                while len(sock_buf) > 0:
##
##                    #Log("sock_buf:%s"%sock_buf)
##                    
##                    hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
##                    if bool(hdr) == 0:
##                        #Log ("bool(hdr) == 0:")
##                        #quitting=1
##                        break #recv() again for the response we need
##
##                    fc = hdr.group(1)
##                    try:
##                        mlen = int(fc[0:MESSAGE_FIELD_LENGTH]) #sometimes multiple messages are part of same recv
##                    except:
##                        mlen = 0
##                    msg_type = int(fc[MESSAGE_FIELD_LENGTH:])
##                    #Log("msg_type={}".format(msg_type) )
##
##                    FCTYPE_CMESG = 50
##                    
##                    if msg_type == FCTYPE_CMESG:
##                        msg = sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH + mlen] 
##                        #Log(urllib.unquote(msg) ) 
##                        try: #sometimes will not be any mssages
##                            msg = fc_decode_json(urllib.unquote(msg))
##                            Log(urllib.unquote(msg['msg']))
##                        except:
##                            pass
##
##                    if msg_type == FCTYPE_JOINCHAN:
##                        send_ping = True
##
##                    FCTYPE_TOKENINC = 6
##                    if msg_type == FCTYPE_TOKENINC:
##                        Log("msg_type={}".format(msg_type) )
##                        msg = sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH + mlen] 
##                        #Log(urllib.unquote(msg) ) 
##                        try: #sometimes will not be any mssages
##                            msg = fc_decode_json(urllib.unquote(msg))
##                            Log("{} tipped {} tokens".format(msg['u'][2], msg['tokens']))
##                        except:
##                            #traceback.print_exc()
##                            pass
##                        
##                    sock_buf = sock_buf[MESSAGE_FIELD_LENGTH + mlen:]
##                    
##                Sleep(100)
##                
##                if send_ping == True:
##                    send_ping = False
##                    websocket_command = "0 0 0 0 0 -"
####                  Log("websocket_command=" + websocket_command)
##                    websocket_connection.send(websocket_command+"\n\0")
##
##
##
##            
##    except:
##        traceback.print_exc()
##        websocket_connection.close()
##        

#    head = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
    video_url = None
    if Is_new_server(CAMGIRLSERVER) == "":
        server439hack = "_a"
                
        #try new servers
        video_url="https://{}.myfreecams.com:8444/x-hls/{}/{}/{}/mfc_a_{}.m3u8{}".format(
            NormalizeServerNumber(CAMGIRLSERVER)
            , CXID
            , CAMGIRLCHANID
            , urllib.quote(CTXENC)
            , CAMGIRLCHANID
            , "?nc="+nc_string
            ) 
##        Log('attempt connecting to HLS host {}|User-Agent={}'.format(Url,head))
##        req = urllib2.Request(Url)
##        req.add_header('User-Agent', head)
##        try:
##            aa = urllib2.urlopen(req, timeout=10)
##            Log('returning URL ' + Url)
##            #utils.notify(msg= "{} is HQ".format(camgirl_to_find), duration=10000, sound=False)
##            return Url, ws
##        except Exception, e:
##            Log("exception '{}' opening url '{}' ".format(repr(e),Url))
##            #utils.notify( 'Oh oh', ("URL for {} is not responding".format(CAMGIRL)))
##            Url = ''

    if PLATFORM_ID == FCUOPT_PLATFORM_MFC:
        Log('not new server, not camU')
        server439hack = ""
        if ADDON.getSetting('use_mobile_stream').lower() == "true":
##            #https://video853.myfreecams.com/NxServer/ngrp:mfc_107784644.f4v_mobile/playlist.m3u8?nc=0.8166779891857224
              #https://video644.myfreecams.com/NxServer/ngrp:mfc_117034936.f4v_mobile/playlist.m3u8?nc=0.910087996723461 HTTP/1.1
            video_url = "http://{}.myfreecams.com:1935/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8{}"
        else:
            #https://video467.myfreecams.com/NxServer/ngrp:mfc_115594240.f4v_desktop/manifest.mpd?nc=0.06683933982840984
            video_url = "https://{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_desktop/manifest.mpd{}"
            video_url = "http://{}.myfreecams.com:1935/NxServer/ngrp:mfc{}_{}.f4v_desktop/manifest.mpd{}"

        video_url = "http://{}.myfreecams.com:1935/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8{}"


        video_url = video_url.format( \
                        NormalizeServerNumber(CAMGIRLSERVER)
                        ,server439hack
                        ,CAMGIRLCHANID
                        ,''
                        )
    #"?nc="+nc_string

    elif PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
        video_url="https://{}.camyou.com/NxServer/ngrp:cam_{}.f4v_desktop/manifest.mpd"
        video_url= video_url.format( \
            NormalizeServerNumber(CAMGIRLSERVER)
            ,CAMGIRLCHANID
            )

    Log("video_url={}".format(video_url))


    websocket_connection.close()
##    return '', None
    return video_url, websocket_connection

#__________________________________________________________________________
#

@utils.url_dispatcher.register(REFRESH_MODE)
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try:
                    os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except:
                    pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            if showdialog==True:
                utils.notify('Finished','Images cleared')
    except:
        pass

    if showdialog==True:
        xbmc.executebuiltin('Container.Refresh')


#__________________________________________________________________________
#

def Search(searchUrl, keyword=None, end_directory=True, page=0):
    return True

#__________________________________________________________________________
#

def Test(keyword):

    return True

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#
