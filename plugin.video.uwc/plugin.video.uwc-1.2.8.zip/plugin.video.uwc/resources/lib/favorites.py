'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sqlite3

import xbmc
import xbmcplugin

from resources.lib import utils

from sites.chaturbate import clean_database as cleanchat
from sites.chaturbate import camgirl_page as camgirl_page

from sites.cam4 import clean_database as cleancam4
#from sites.camsoda import clean_database as cleansoda
from sites.naked import clean_database as cleannaked

from sites.myfreecams import getChatServerWebsocket as getChatServerWebsocket
from sites.myfreecams import getCamgirlInfo as getCamgirlInfo
import time

import traceback

log = utils.kodilog

dialog = utils.dialog
favoritesdb = utils.favoritesdb

conn = sqlite3.connect(favoritesdb)
c = conn.cursor()
try:
    c.executescript("CREATE TABLE IF NOT EXISTS favorites (name, url, mode, image);")
    c.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
except:
    pass
conn.close()

@utils.url_dispatcher.register('901')  
def List():
    if utils.addon.getSetting("chaturbate") == "true":
        cleanchat(False)
        cleancam4(False)
        cleannaked(False)
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    try:
        c.execute("SELECT * FROM favorites")

        #get list of online camgirls from front page [we will miss the others]
        #log( "begin query".format() ) 
        chaturbategirls = camgirl_page()
        #log( "end query".format() )
        #log( chaturbategirls )
        
        for (name, url, mode, img) in c.fetchall():

            #xbmc.log( "name:{} url:{} searchstring:{}".format(name,url,'<a href="/{}/">'.format(name) ) , xbmc.LOGNONE)
            
            if 'chaturbate.com' in url:
                name = name.split(' [COLOR')[0]
                if '<a href="/{}/">'.format(name) in chaturbategirls:
                    name = "  [COLOR yellow]{}[/COLOR]".format(name)
                else:
                    log( "'{}' not found in page1".format(name) )
                utils.addDownLink(name, url, int(mode), img, '', '', 'del')

            elif ('img.mfcimg.com' in img):
                try:
                    serverNumber,modelID,newServer=getCamgirlInfo(name)
                    if serverNumber > 0: #    if model server found
                        if newServer == False:
                            img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc_{}?no-cache={}".format(serverNumber,modelID,time.time())
                        else:
                            img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc_a_{}?no-cache={}".format(serverNumber,modelID,time.time())
                        name = "  [COLOR yellow]{}[/COLOR]".format(name)
                        utils.addDownLink(name, url, int(mode), img, '', '', 'del')
                    else:#    else use default
                        utils.addDownLink(name, url, int(mode), img, '', '', 'del')
                except:
                    traceback.print_exc()
                    
            else:
                utils.addDownLink(name, url, int(mode), img, '', '', 'del')

        xbmcplugin.addSortMethod(handle=utils.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE)    
        xbmcplugin.endOfDirectory(utils.addon_handle)
    except Exception,e:
        xbmc.log(str(e) , xbmc.LOGNONE)    
        utils.notify('No Favorites','No Favorites found')

    #cleanup objects
    conn.close()

    return
        

@utils.url_dispatcher.register('900', ['fav','favmode','name','url','img'])  
def Favorites(fav,favmode,name,url,img):
    if fav == "add":
        delFav(url)
        addFav(favmode, name, url, img)
        utils.notify('Favorite added','Video added to the favorites')
    elif fav == "del":
        delFav(url)
        utils.notify('Favorite deleted','Video removed from the list')
        xbmc.executebuiltin('Container.Refresh')


def addFav(mode,name,url,img):
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("INSERT INTO favorites VALUES (?,?,?,?)", (name, url, mode, img))
    conn.commit()
    conn.close()


def delFav(url):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM favorites WHERE url = '%s'" % url)
    conn.commit()
    conn.close()


