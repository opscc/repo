'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils

@utils.url_dispatcher.register('150')
def HQMAIN():
    utils.addDir("  [COLOR {}]Categories[/COLOR]".format(utils.search_text_color),'https://hqporner.com/porn-categories.php',153,'','')
    utils.addDir("  [COLOR {}]Studios[/COLOR]".format(utils.search_text_color),'https://hqporner.com/porn-studios.php',153,'','')
    utils.addDir("  [COLOR {}]Girls[/COLOR]".format(utils.search_text_color),'https://hqporner.com/porn-actress.php',153,'','')
    HQLIST('https://hqporner.com/hdporn/1')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('151', ['url'])
def HQLIST(url):
    try:    link = utils.getHtml(url, '')
    except: return None

    utils.addDir("  [COLOR {}]Search[/COLOR]".format(utils.search_text_color),'https://hqporner.com/?s=',154,'','')
    
    match = re.compile('<a href="([^"]+)" class="image featured non-overlay".*?<img id="[^"]+" src="([^"]+)" alt="([^"]+)".*?fa-clock-o meta-data">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(link)
    for url, img, name, duration in match:
        name = utils.cleantext(name)
        name = " [COLOR {}]{}[/COLOR] {}".format(utils.time_text_color,duration,name)        
        videourl = "https://www.hqporner.com" + url
        utils.addDownLink(name, videourl, 152, 'https:' + img, '')

    try:
        nextp=re.compile('<a href="([^"]+)"[^>]+>Next', re.DOTALL | re.IGNORECASE).findall(link)
        nextp = "https://www.hqporner.com" + nextp[0]
        np_label = "[COLOR {}]Next Page[/COLOR]".format(search_text_color)
        utils.addDir(np_label, nextp,151,'')
    except: pass

    xbmcplugin.addSortMethod(utils.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('153', ['url'])
def HQCAT(url):
    link = utils.getHtml(url, '')
    tags = re.compile('<a href="([^"]+)"[^<]+<img src="([^"]+)" alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(link)
    tags = sorted(tags, key=lambda x: x[2])
    for caturl, catimg, catname in tags:
        caturl = "http://www.hqporner.com" + caturl
        catimg = "http://www.hqporner.com" + catimg        
        utils.addDir(catname,caturl,151,catimg)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('154', ['url'], ['keyword'])
def HQSEARCH(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 154)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        HQLIST(searchUrl)

@utils.url_dispatcher.register('152', ['url', 'name'], ['download'])
def HQPLAY(url, name, download=None):

    videopage = utils.getHtml(url, url)

    iframeurl = re.compile(r"nativeplayer\.php\?i=([^']+)", re.DOTALL | re.IGNORECASE).findall(videopage)
    if not (iframeurl[0].startswith('http')):
        iframeurl = 'https:' + iframeurl[0]

    if re.search('bemywife', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)
    elif re.search('mydaddy', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)        
    elif re.search('\/hqwo\.cc\/', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)
    elif re.search('5\.79', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getIP(iframeurl)
    elif re.search('flyflv', iframeurl, re.DOTALL | re.IGNORECASE):
        if (iframeurl.startswith('https:')):
            #apr 2018; https requires authentication for this site, http no
            iframeurl = iframeurl.replace('https://','http://')
            
        videourl = getFly(iframeurl)
    else:
        #print (videopage)
        utils.notify('Oh oh','Couldn\'t find a supported videohost')
        return

    if not videourl:
        #print (videopage)
        utils.notify('Oh oh','Couldn\'t find a supported videohost')
        return

    if not (videourl.startswith('http')):
        videourl = 'https:' + videourl
        
    utils.playvid(videourl, name, download)


def getBMW(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile(r'file: "([^"]+mp4)", label: "\d', re.DOTALL | re.IGNORECASE).findall(videopage)
    try:
        videourl = videos[-2]
    except:
        try:
            videourl = videos[-1]
        except:
            videos = re.compile('src=\'(https\:\S+)\'>', re.DOTALL | re.IGNORECASE).findall(videopage)
            videourl = getIP2(videos[0])
    
    return videourl

def getIP2(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('"file": "(\S+)",', re.DOTALL | re.IGNORECASE).findall(videopage)    
    videourl = videos[-1]
    return videourl


def getIP(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('file": "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = videos[-1]
    return videourl

def getFly(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('src=\'(.*)\' type=', re.IGNORECASE).findall(videopage)
    videourl = videos[-1]
    if not (videourl.startswith('http')):
        videourl = 'http:' + videourl
        
    return videourl
