'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sqlite3

import re

import xbmc, xbmcplugin

from resources.lib import utils
from resources.lib.utils import Log as Log

from sites.chaturbate import clean_database as clean_chaturbate
from sites.chaturbate import camgirl_page as chaturbate_getCamgirlList

from sites.cam4 import clean_database as cleancam4
from sites.naked import clean_database as cleannaked

from sites.myfreecams import getCamgirlList as mfc_getCamgirlList
from sites.myfreecams import getCamgirlInfo as getCamgirlInfo
from sites.myfreecams import clean_database as clean_mfc

import time
import traceback

log = utils.kodilog

dialog = utils.dialog
favoritesdb = utils.favoritesdb

conn = sqlite3.connect(favoritesdb)
c = conn.cursor()
try:
    c.executescript("CREATE TABLE IF NOT EXISTS favorites (name, url, mode, image);")
    c.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
except:
    pass
conn.close()

@utils.url_dispatcher.register('898')  
def RefreshImages():
    clean_chaturbate(False)
    cleancam4(False)
    cleannaked(False)
    clean_mfc(False)
    #RefreshContainter()

@utils.url_dispatcher.register('899')  
def RefreshContainter():
    xbmc.executebuiltin('Container.Refresh')
    

@utils.url_dispatcher.register('901')  
def List():
    if utils.addon.getSetting("auto_clean_img_database").lower() == "true":
        RefreshImages()

    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()

    utils.addDir(name="[COLOR {}]Refresh[/COLOR]".format( \
        utils.refresh_text_color) \
        ,url='' \
        ,mode=899 \
        ,iconimage=utils.refresh_icon \
        ,Folder=False \
        )

##    utils.addDir(name="[COLOR {}]Images[/COLOR]".format( \
##        utils.refresh_text_color) \
##        ,url='' \
##        ,mode=898 \
##        ,iconimage=utils.refresh_icon \
##        ,Folder=False \
##        )
    
    
    try:
        c.execute("SELECT * FROM favorites")

        chaturbategirls = chaturbate_getCamgirlList()
        #log(chaturbategirls, xbmc.LOGNONE)
        mfcgirls = mfc_getCamgirlList()
        #log(mfcgirls, xbmc.LOGNONE)
        
        for (name, url, mode, img) in c.fetchall():

            try:
                
                if 'chaturbate.com' in url:
                    name = name.split(' [COLOR')[0].strip()
                    #log(name + str(time.time()))
                    
                    #match = re.compile('href="\/{}\/">.+?<img src="([^"]+)"'.format(name), re.DOTALL | re.IGNORECASE).findall(chaturbategirls)
                    match = re.compile('href="\/{}\/">.+?<img src="([^"]+)".+?"cams".+?,\s+([^v]+)viewers'.format(name), re.DOTALL | re.IGNORECASE).findall(chaturbategirls)
                    #searchregex = '<li class="room_list_room".*?<a href="([^"]+)">.*?img src="([^"]+)".*?<div[^>]+>([^<]+)<\/div>.*?href[^>]+> \/{}\/<.*?age[^>]+>([^<]+).*?,\s(\d+)\sviewers'.format(name)
                    #match = re.compile(searchregex, re.DOTALL | re.IGNORECASE).findall(chaturbategirls)
                    #videopage, img, status, name, age, viewers in match:

                    #if '<a href="/{}/">'.format(name) in chaturbategirls:
                    if match:
                        #log( "'{}' found in page1".format(name) )
                        img = match[0][0]
                        camscore=match[0][1]
                        #log("name={},img={},camscore={}".format(name,img,camscore))
                        name = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,name)
                        if len(match)> 1:
                            log("name'{}'score'{}'".format(name,match[1]) )
                        else:
                            log("name'{}'score'{}'".format(name,0) )
                        

                    else:
                        log( "'{}' not found in page1".format(name) )
                        camscore=0
                    
                    utils.addDownLink(name=name, url=url, mode=int(mode), iconimage=img, desc='', stream='', fav='del',duration=str(int(camscore)))

                elif ('.mfcimg.com' in img) and mfcgirls:
                    log(name + str(time.time()))
                    
                    serverNumber,modelID,newServer,camscore = getCamgirlInfo(name, mfcgirls)
                    if not camscore: camscore=0
                    
                    log("name={},serverNumber={},modelID={},newServer={},camscore={}".format(name,serverNumber,modelID,newServer,camscore))
                    if serverNumber > 0: #    if model server found; an online/active image can be used
                        if newServer == False:
                            img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc_{}?no-cache={}".format(serverNumber,modelID,time.time())
                        else:
                            img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc_a_{}?no-cache={}".format(serverNumber,modelID,time.time())

                        name = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,name)
                        utils.addDownLink(name, url, int(mode), img, '', '', 'del', duration=str(int(camscore)))
                    else:  #else use default
                        if "snap.mfcimg.com/" in img:
                            #modelid = img.split('/')[6][5:] #trim first 5 chars - should be mfc_1
                            modelid = img.split('/')[6]
                            #model_t = modelid
                            #the 1 indicates model was in public change when bookmark created
                            if modelid.startswith("mfc_a_1"):
                               modelid = modelid[len("mfc_a_1"):] 
                            #modelid = modelid.lstrip("mfc_a_1") 
                            if modelid.startswith("mfc_1"):
                               modelid = modelid[len("mfc_1"):] 
                            if modelid[0] == '0':
                                modelid = modelid[1:] #trim zero from front

                            #log("name={} model_t={} modelid={}".format(name,model_t,modelid), xbmc.LOGNONE)
                            
                            img = "https://img.mfcimg.com/photos2/{}/{}/avatar.300x300.jpg".format(modelid[:3], modelid)
                            
                        utils.addDownLink(name, url, int(mode), img, '', '', 'del', duration=str(int(camscore)))

                elif '.nsimg.net/media' in img:
                    #todo
                    #35548499 is the 'url'
                    #http://m1.nsimg.net/media/snap/35548499.jpg
                    #https://m2.nsimg.net/biopic/320x240/35548499
                    #https://www.streamate.com/search.php?q=annierose
                    #GET www.streamate.com/search.php?q=annierose&sssjson=1 HTTP/1.1
                    #returns json that can be parsed
                    utils.addDownLink(name.strip(), url, int(mode), img, '', '', 'del')
                #not mfc or chaturbate
                else:
                    utils.addDownLink(name.strip(), url, int(mode), img, '', '', 'del')

            except:
                traceback.print_exc()

        utils.add_sort_method()
        xbmcplugin.endOfDirectory(utils.addon_handle)
        
    except Exception,e:
        xbmc.log(str(e) , xbmc.LOGNONE)    
        utils.notify('No Favorites','No Favorites found')

    #cleanup objects
    conn.close()
    return

@utils.url_dispatcher.register('900', ['fav','favmode','name','url','img'])  
def Favorites(fav,favmode,name,url,img):
    if fav == "add":
        delFav(url)
        addFav(favmode, name, url, img)
        utils.notify('Favorite added','Video added to the favorites')
    elif fav == "del":
        delFav(url)
        utils.notify('Favorite deleted','Video removed from the list')
        xbmc.executebuiltin('Container.Refresh')

def addFav(mode,name,url,img):
    if '[/COLOR]' in name:
        name = name.split('[/COLOR]')[1].strip()
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("INSERT INTO favorites VALUES (?,?,?,?)", (name, url, mode, img))
    conn.commit()
    conn.close()

def delFav(url):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM favorites WHERE url = '%s'" % url)
    conn.commit()
    conn.close()
