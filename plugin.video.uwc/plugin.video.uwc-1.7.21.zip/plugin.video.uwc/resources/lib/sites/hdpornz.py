'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]hdpornz.biz[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = True

ROOT_URL = "https://hdpornz.biz"
SEARCH_URL = ROOT_URL + '/search/{}?page={}'
URL_RECENT = ROOT_URL + '/?page={}'

MAIN_MODE       = C.MAIN_MODE_hdpornz
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1' #default first page

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List [url='{}', page='{}', end_directory='{}', keyword='{}']".format(url,page,end_directory,keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(
          end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)


    # read html
    listhtml = utils.getHtml(list_url)
    if "No media found" in listhtml:
        listhtml = ""
        video_region = ""
    else: #distinguish between adverts and videos
        video_region = re.compile('<div class="panel panel-default"(.*?)<footer>', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]

    #
    # parse out list items
    #
    regex = 'id=\'media-.*?=.*?<a href=\'([^\']+)\' title=\'([^\']+)\'.*?image:url\((.*?)\)\''
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb  in info:
        desc = label
        label = utils.cleantext(label.split(']')[-1]).strip()
        label = "{}{}".format(C.SPACING_FOR_NAMES, label)
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("desc={}".format(desc))
        desc = u"{}".format(desc.decode('utf8'))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc=u"{}\n{}".format(desc,ROOT_URL)
            )
            #, duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode) 
    
        

    # next page items
    next_page_regex = '<a href=".+(\d+)">N.*?chste </a>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
##            Log("np_url={}".format(np_url))
        np_url = url
        np_number=int(page)+1
        if end_directory == True:
            utils.addDir(
                name= C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword
                )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)                    
#__________________________________________________________________________
#

@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace('+','%20').replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}') 
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=page, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    listhtml = utils.getHtml(url, '')
 
    regex = '<a href="([^"]+)"[^<]+<img src="([^"]+)" alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("thumb={}".format(thumb))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            )
        
    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
##    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
        
    video_url = None
    source_html = utils.getHtml(url, ROOT_URL)

    #
    #description information
    #
    regex_model_area = 'Actress:(.+)Studio'
    models_html = re.compile(regex_model_area, re.DOTALL | re.IGNORECASE).findall(source_html)
    if models_html: models_html=models_html[0]
    else: models_html = ''
    regex_model = '/actress/.+?rel="tag">(?P<model>[^<]+)<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(models_html)
    description = ''
    desc_separator_char = '; '
    if source_models:
        for model in source_models:
            description = description + desc_separator_char + model.group('model')
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
##    Log("description={}".format(description))

    #url that needs a resolver to continue
    regex = '"video-player".*?<iframe src=\'(.*?)\''
    video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html)[0]
    needs_resolving_source = utils.getHtml(video_url, url)


    from resources.lib import resolver
    video_url = resolver.resolve_video(videosource=needs_resolving_source, name=name, download=download, url=url)
    Log("video_url={}".format(video_url))
    
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
