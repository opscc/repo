'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C


FRIENDLY_NAME = '[COLOR {}]empflix[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.empflix.com"
SEARCH_URL = ROOT_URL + '/search.php?what={}'
URL_CATEGORIES = ROOT_URL + '/categories'
URL_RECENT = ROOT_URL + '/new/{}'

MAIN_MODE       = C.MAIN_MODE_empflix
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
        
    # read html
    listhtml, redirected_url = utils.getHtml(list_url, send_back_redirect=True)
    if redirected_url: list_url = redirected_url
    if "page that you are looking for does not" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('<div class="ajax_content main"')[1].split('<div class="navigation')[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    # parse out list items
    regex = "data-vid.+?data-name='([^']+)'.+?href='([^']+).+?data-original='([^']+)'.+?'>([\d:]+)(.)"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for label, videourl, thumb, duration, hd in info:
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    #
    # next page items
    #
    try:
        next_page_html = listhtml.split('<div class="navigation')[1]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = 'class="llNav".+?href=".+?([\d]+).*?"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)

    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
##        for np_number in np_info:
            #Log("np_url={}".format(np_url))
##            Log("np_number={}".format(np_number))
            #np_number = ''
##            if not np_number.isdigit(): np_number=np_url.split('/')[-1]
##            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
        np_url=url
        np_number = int(page) + 1
##        Log("np_number={}".format(np_number))
##        Log("np_url={}".format(np_url))
##        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, C.search_text_color, int(np_number))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
##            break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword) + '&page={}'
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)

    regex = 'class="thumb".+?src="([^"]+).+?class="categoryTitle" href="([^"]+)".+?title="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for thumb, videourl, label   in info:
##        label = "{}[COLOR {}]{}[/COLOR]".format(
##            SPACING_FOR_TOPMOST
##            , C.search_text_color
##            , utils.cleantext(label)
##            ) 
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        #https://www.empflix.com/amateur-porn/most-recent/2
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl + '/most-recent/{}'
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb
            ) #C.search_icon)
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    
    source_html1 = utils.getHtml(url, ROOT_URL)
    regex = 'id="VID".+?value="([^"]+)".+?id="vkey".+?value="([^"]+)".+?id="thumb".+?value="([^"]+)".+?id="nkey".+?value="([^"]+)"'
    source_url_vars = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)

    if source_url_vars: #2019 desktop version of page
        #from: https://www.empflix.com/combine/tnaflix.desktop.js,flixplayer.desktop.js,lazyload.desktop.js,thumbplayer.desktop.js,tnaflix.desktop.channels.js,ws.js,suggest.js,dyn.js,textarea-caret-position.js,URL.js,tnaflix.desktop.notifications.js,perfect-scrollbar.js,sortable.js,flex-images.js,masonry.js,3be38.js,imagesloaded.js?1562849301
        Log("source_url_vars={}".format(source_url_vars))
        source_url_vars = source_url_vars[0]
        source_url2 = "https://cdn-fck.empflix.com/empflix/"+source_url_vars[1] 
        source_url2 += "-1.fid?key="+source_url_vars[3] 
        source_url2 += "&VID="+source_url_vars[0]  
        source_url2 += "&nomp4=1&catID=0&rollover=1&startThumb="+source_url_vars[2] 
        source_url2 += "&embed=0&utm_source=0&multiview=0&premium=1&country=0user=0&vip=1&cd=0&ref=0&alpha"

        Log("source_url2={}".format(source_url2))
        source_html2 = utils.getHtml(source_url2, url)
        regex = '<res>([^<]+).+?<videoLink><!\[CDATA\[([^\]]+)'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
        Log("sources_list={}".format(sources_list))
##        video_url = utils.SortVideos(sources_list,download=download,vid_res_column=0)
        video_url = utils.SortVideos(
            sources=sources_list
            ,download=download
            ,vid_res_column=0
            ,max_video_resolution=max_video_resolution
            )        
        video_url = C.html_parser.unescape(video_url)
        Log("video_url={}".format(video_url))

        headers = C.DEFAULT_HEADERS.copy()
        headers['Accept-Encoding'] = 'identity;q=1, *;q=0'
        headers['Referer'] = ROOT_URL + '/'
        headers['Range'] = 'bytes=0-'

        video_url = "https:" + video_url + utils.Header2pipestring(headers)
        
    else: #2018 mobile version  if you use an ipad header, but then you are limited in vid resolution
        regex = '"contentUrl" content="([^"]+)"'
        source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
        source_url2 = source_url2[0]
        video_url = source_url2 + utils.Header2pipestring() + '&Referer=' + url

##        regex = 'flashvars.config = escape."([^ ]+)&VID='
##        source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)[0]
##        source_url2 = source_url2 + utils.Header2pipestring() + '&Referer=' + url
##        #Log("source_url2={}".format(source_url2))
##        source_html2 = utils.getHtml(source_url2, url)
##        regex = '<videoLink>(.+?)</videoLink>'
##        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
##        #Log("sources_list={}".format(sources_list))
##        video_url = sources_list[0]

    if not video_url:
        utils.Notify("No video file found for {}".format(name))
        return
    Log("video_url='{}'".format(video_url))
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
