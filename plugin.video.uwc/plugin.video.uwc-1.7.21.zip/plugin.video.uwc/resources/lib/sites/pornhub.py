'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]pornhub[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.pornhub.com"
SEARCH_URL = ROOT_URL + '/video/search?search={}&page={}'
URL_CATEGORIES = ROOT_URL + '/categories?o=al' # insert &o=mr  for mos recent vids
URL_RECENT = ROOT_URL + '/video?o=cm&page={}'
#https://www.pornhub.com/video?o=cm&page=2

MAIN_MODE          = C.MAIN_MODE_pornhub
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=FIRST_PAGE, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, ignore404=True) #, send_back_redirect=True)
    if "but you can check other awesome vid" in listhtml or "No Search Results" in listhtml:
        video_region = ''
        listhtml = ''
    else:#distinguish between adverts and videos
        try:
            video_region = listhtml.split('"sectionWrapper"')[1]
        except:
            video_region = listhtml
    #Log("video_region={}".format(video_region))
            
    # parse out list items
    regex = 'videoblock.+?href="(/view_video\.php\?viewkey=[^"]+).+?title="([^"]+)".+?data-thumb_url = "([^"]+)".+?"duration">([^<]+)</.+?((?:<span class="hd-thumbnail">HD</span>|</div>))'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, duration, hd in info:
        hd = utils.Normalize_HD_String(hd)
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        duration = duration.replace(' min','s').replace(':','m ')
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc = '\n' + ROOT_URL
            , duration = duration)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
        
    #
    # next page items
    #
    next_page_regex = '<li class="page_next"><a href="(.+?)" class="orangeButton">Next'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url in np_info:
        np_number = int(page) + 1
        np_url = url
##        Log("np_url={}".format(np_url))
##        Log("np_number={}".format(np_number))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(
                    url=np_url
                    , page=np_number
                    , end_directory=end_directory
                    , keyword=keyword
                    )
        break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#

@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(title, '{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    html = utils.getHtml(url)

    regex = '<div class="category-wrapper ">\s*?<a href="([^"]+)"\s*?alt="([^"]+)".*?<img.*?data-thumb_url="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    for url, label, thumb in info:
        if url.startswith('/'): url = ROOT_URL + url
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if '?' in url:
            url = url + "&o=cm&page={}"
        else:
            url = url + "?o=cm&page={}"
##        Log("thumb='{}'".format(thumb))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=url 
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    list_key_value2 = {}

    headers = {"Accept-Language": "en-US,en;q=0.9"
            ,"Accept-Encoding":"gzip, deflate"
            ,"Accept": "*/*"
            ,"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15"
            }

    full_html = utils.getHtml(url, ignore404=True, headers=headers)

    if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
        return

    import json
    regex='var qualityItems_.+?"(.+)\]";'
    mobile_json = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    if mobile_json:
        Log("mobile_json[0]='{}'".format(mobile_json[0]))
        mobile_json = mobile_json[0].replace('\\"', '"').replace("\\\/", "/") +']'
        Log("mobile_json='{}'".format(mobile_json))
        json_sources = json.loads(mobile_json)
        Log("json_sources='{}'".format(repr(json_sources)))
        for json_src in json_sources:
            if json_src['url'] != '':
                list_key_value2[json_src['text']] = json_src['url']

##            if 'videoUrl' in json_src:
##                if json_src['videoUrl'] != '':
##                    Log(repr(type(json_src['quality'])))
##                    if type(json_src['quality']) != list:
##                        list_key_value2.append((json_src['quality'], json_src['videoUrl']))


    if len(list_key_value2) > 0:
        list_key_value = list_key_value2
    else:
        regex='var (ra\w+)="(.+?)";'
        ra_vars = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    ##    Log("ra_vars='{}'".format(ra_vars))
        variables = {}
        for var_name,var_value in ra_vars:
            variables[var_name]=var_value.replace('" + "','')
    ##    Log("variables='{}'".format(variables))        

        regex='format":"((?:mp4|hls))".+?"quality":"(\d+)'
        formats = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        #Log("formats='{}'".format(formats))
    ##    formats = sorted(formats, key=lambda x: int(x[1]), reverse=False)
    ##    formats = sorted(formats, key=lambda x: x[0], reverse=True)
    ##    Log("formats='{}'".format(formats))

        regex='var media_(\d)=(.+?);'
        encoded_vids = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        #Log("encoded_vids='{}'".format(encoded_vids))
    ##    encoded_vids = sorted(encoded_vids, key=lambda x: int(x[0]), reverse=True)
    ##    Log("encoded_vids='{}'".format(encoded_vids))

        
        for match_number, encoded_url in encoded_vids:
            match_number = int(match_number)
            Log("match_number='{}'".format(match_number))
            
            if "/*" in encoded_url:
                encoded_url = re.sub(r"/\*[^/]+/", "", encoded_url).replace("+","")
                linkparts = re.compile(r"(\w+)", re.DOTALL | re.IGNORECASE).findall(encoded_url)
    ##            for part in linkparts:
    ##                partval = re.compile(part+'="(.*?)";', re.DOTALL | re.IGNORECASE).findall(html)[0]
    ##                partval = partval.replace('" + "','')
    ##                encoded_url = encoded_url.replace(part, partval)
                for part in linkparts:
                    encoded_url = encoded_url.replace(part, variables[part])
                    
            decoded_url = encoded_url.replace(" ","")
            Log("decoded_url='{}'".format(decoded_url))

##            if len(formats) > match_number:
##                video_resolution = formats[match_number][0] + formats[match_number][1]
##                list_key_value2[video_resolution] = decoded_url

            mobile_json = utils.getHtml(decoded_url, referer=url)
            json_sources = json.loads(mobile_json)
            Log("json_sources='{}'".format(repr(json_sources)))
            for json_src in json_sources:
                if json_src['videoUrl'] != '':
                    if type(json_src['quality']) != list:
                        list_key_value2[json_src['quality']] = json_src['videoUrl']
            break   

        Log("list_key_value2='{}'".format(list_key_value2))


##    #strip out HLS streams if there is an available MP4
##    list_key_value = {}
##    for item in list_key_value2:
####        Log("item='{}'".format(repr(item)))
##        res = item
##        url = list_key_value2[item]
##        if res.startswith('hls'):
##            mp4found=False
##            stream_type = res[0:3]
####            Log("stream_type='{}'".format(stream_type))
##            stream_res = res[3:]
####            Log("stream_res='{}'".format(stream_res))
##            for lv2 in list_key_value2:
##                stream_type_3 = lv2[0:3]
##                stream_res_3 = lv2[3:]
##                if (stream_res == stream_res_3) and not(stream_type == 'hls'):
##                    mp4found = True
##                    break
##            if mp4found==False:
##                list_key_value[res[3:]] = url
##        else:
##            list_key_value[res[3:]] = url
##    Log("list_key_value='{}'".format(list_key_value))

    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )
##    Log("video_url={}".format(video_url))

    regex_model = 'data-mxptype="Pornstar".+?data-mxptext="(?P<model>[^"]+)"'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(full_html)
    description = ''
    desc_separator_char = '; '
    if source_models:
        for model in source_models:
            description = description + desc_separator_char + model.group('model')
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))
    

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
