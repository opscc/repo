import datetime
import Queue
import threading
import traceback
import xbmc

from resources.lib import utils
from resources.lib import constants as C
from resources.lib.utils import Log as Log
from resources.lib.utils import Sleep as Sleep

#__________________________________________________________________
#
class uwcSimpleCache(object):
    def __init__(self, identifier=None ):
        self._cache = {}
        self._identifier = identifier
        pass
    def show(self):
        Log("self._cache={}".format(repr(self._cache)))
    def get(self, endpoint):
        result = None
        endpoint = endpoint.encode("utf-8")
        cachedata = None
        if endpoint in self._cache:
            cachedata = self._cache[endpoint]
            result = cachedata
        return result
    def set(self, endpoint, data):
        self._cache[endpoint.encode("utf-8")] = data
##    @staticmethod
##    def _get_timestamp(date_time):
##        '''Converts a datetime object to unix timestamp'''
##        return int(time.mktime(date_time.timetuple()))
#__________________________________________________________________
#
def find_obj_in_GC(object_type='resources.lib.thread_cache.uwcSimpleCache'):
##    Log("find_obj_in_GC()")
    import gc
    loop_interruptor = 0
    found_obj = None
    for obj in gc.get_objects():
        loop_interruptor += 1
        if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS: # pause to allow other stuff
            Sleep(C.GC_SEARCHLOOP_PAUSE) # pause to allow other stuff
            loop_interruptor = 0        
        if '__class__' in repr(dir(obj)) :
            if (object_type in repr(obj.__class__)):
                Log("{}_obj='{}'".format(object_type,repr(obj)), xbmc.LOGNONE)
                found_obj = obj
                #break
    return found_obj
#__________________________________________________________________
#
def find_uwcSimpleCache(cache_find_queue, cache_find_results):
##    Log("cache_find_queue='{}'".format(repr(cache_find_queue)))
    while not cache_find_queue.empty():
        work = cache_find_queue.get(timeout=C.WEBCRAWLER_THREAD_TIMEOUT)
        try:
            single_method_result = find_obj_in_GC()
        except Exception as ex:
            single_method_result = ex
        cache_find_results.append(single_method_result)
        cache_find_queue.task_done()
##    Log("end cache_find_queue='{}'".format(repr(cache_find_queue)))
    Log("cache_find_results='{}'".format(repr(cache_find_results)))
    return True
#__________________________________________________________________
#
cache = None
cache_index = C.addon_id+".thread_cache"
cache_find_queue = None #Queue.Queue()
cache_find_results = None #[]
#cache_find_queue.put(())
#__________________________________________________________________
#
def create_cache_search_thread():
    cache_find_thread = threading.Thread(
        name = "cache_find_thread"
        ,target = find_uwcSimpleCache
        ,args   = (cache_find_queue, cache_find_results)
        )
    cache_find_thread.daemon = True
    return cache_find_thread
#__________________________________________________________________
#
cache_find_thread = None #create_cache_search_thread()
#__________________________________________________________________
#
def get_active_thread_info():
    global cache
    global cache_find_thread
    if (cache is None):
        if (cache_find_thread is None) or (not cache_find_thread.is_alive()):
            global cache_find_queue
            global cache_find_results
            cache_find_queue = Queue.Queue()
            cache_find_queue.put(())
            cache_find_results = []
            cache_find_thread = create_cache_search_thread()
            Log("[re]starting cache_find_thread")
            cache_find_thread.start()
##        Log("joining cache_find_thread")
        cache_find_queue.join()
        Log("cache_find_results='{}'".format(repr(cache_find_results)))
##        cache_find_thread = None
    else:
##        Log("cache='{}'".format(repr(cache)))
        pass
    cache = cache_find_results[0]
    info = cache.get(cache_index)
    Log("thread_cache='{}'".format(repr(info)))
    if not info: info = {} #must be new
    return  info
#__________________________________________________________________
#
def append_active_thread(name, thread):
    Log("appending '{}'".format(name))
    info = get_active_thread_info()
    if name in info:
        Log("'{}' has an active thread".format(name))
        return False
    else:
        info[name] = thread
        cache.set(cache_index, info)
        Log("cache.show()='{}'".format(repr(cache._cache)))
        return True
#__________________________________________________________________
#
def del_active_thread(name):
    Log("deleting '{}'".format(name))
    info = get_active_thread_info()
    if not(name in info):
        Log("'{}' is not active".format(name))
        return True
    else:
        info.pop(name)
        cache.set(cache_index, info)
        Log("cache.show()='{}'".format(repr(cache._cache)))
        return True
#__________________________________________________________________
#
