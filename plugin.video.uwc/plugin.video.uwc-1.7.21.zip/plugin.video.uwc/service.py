import random
import threading
import traceback
import xbmc

from resources.lib import constants as C
from resources.lib import downloader
from resources.lib import thread_cache 
from resources.lib import utils
from resources.lib import webcam_db
from resources.lib.utils import Log as Log
from resources.lib.utils import Sleep as Sleep
from resources.lib.utils import get_setting as GetSetting


#__________________________________________________________________
#
monitor = xbmc.Monitor()
#MIN_SLEEP_SECONDS = int(C.addon.getSetting("min_service_interval"))
MIN_SLEEP_SECONDS = GetSetting("min_service_interval", int)
#__________________________________________________________________
#
def recording_service(stop_event):
    ## wait a moment before doing stuff to avoid overwhelming startup
    #sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
    sleeptime = int(GetSetting("service_periodic_interval",int) * (random.random())  )
    sleeptime = 15 #max(sleeptime, 15)
    Log("{} sleeping {} seconds before next action ".format(repr(threading.current_thread().name), sleeptime) )
    if monitor.waitForAbort(int(sleeptime)):
        Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
        return
    while not monitor.abortRequested():
        if stop_event.isSet():
            Log("ending thread {} due to stop_event".format(repr(threading.current_thread().name)))
            break
        #enable_recording_service = C.addon.getSetting("enable_recording_service").lower() == "true" ## ... do some work
        enable_recording_service = GetSetting("enable_recording_service")## ... do some work
        if enable_recording_service:
            try:
                downloader.scan_and_start_db()
            except:
                traceback.print_exc()
        else:
            Log("enable_recording_service is false")
            break
        ## sleep then ... do some work
        #sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
        sleeptime = int(GetSetting("service_periodic_interval",int) * (random.random())  )
        Log("sleeptime={}".format(sleeptime))
        sleeptime = max(sleeptime, MIN_SLEEP_SECONDS)
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        if monitor.waitForAbort(sleeptime):
            Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
            break
#__________________________________________________________________
#
def link_crawler(stop_event):

    ## wait a moment before doing stuff to avoid overwhelming startup
    #sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
    sleeptime = int(GetSetting("service_periodic_interval", int) * (random.random())  )
    sleeptime = 5 #max(sleeptime, 5)
    Log("{} sleeping {} seconds before next action ".format(repr(threading.current_thread().name), sleeptime) )
    if monitor.waitForAbort(int(sleeptime)):
        Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
        return
    
    while not monitor.abortRequested():

        if stop_event.isSet():
            Log("ending thread {} due to stop_event".format(repr(threading.current_thread().name)))
            break
        
        #enable_link_crawler = C.addon.getSetting("enable_link_crawler").lower() == "true" ## ... do some work
        enable_link_crawler = GetSetting("enable_link_crawler") ## ... do some work
        if enable_link_crawler:
            try:
                webcam_db.clear_webcam_db()
                webcam_db.fill_webcam_db()
            except:
                traceback.print_exc()
        else:
            Log("enable_link_crawler is false")
            break
            
        ## sleep then ... do some work
        #sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
        sleeptime = int(GetSetting("service_periodic_interval", int) * (random.random())  )
        Log("sleeptime={}".format(sleeptime))
        sleeptime = max(sleeptime, MIN_SLEEP_SECONDS)
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        if monitor.waitForAbort(sleeptime):
            Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
            break

#__________________________________________________________________
#
if __name__ == '__main__':

    C.DEBUG = GetSetting('debug')
       
    threading.current_thread().name = C.addon_id+".service"

    proxy_thread_recording_service = None
    recording_service_stop_event = None
    proxy_thread_crawler = None
    crawler_stop_event = None

    thread_cache = thread_cache.uwcSimpleCache()
    thread_cache._identifier = '__main__'

##    webcam_db.clear_webcam_db()
##    Log(repr(thread_cache_id))
    Log(repr(thread_cache), xbmc.LOGNONE)

##    import xbmcgui
##    _win = xbmcgui.Window(10000)
##    endpoint = C.addon_id+"thread_cache"
    

##    cachedata = id(monitor)
##    cachedata_str = repr(cachedata).encode("utf-8")
##    _win.setProperty(endpoint.encode("utf-8"), cachedata_str)

    while not monitor.abortRequested():

        # start thread for link_crawler service
        #if C.addon.getSetting("enable_link_crawler").lower() == "true":
        if GetSetting("enable_link_crawler"):
##            Log("enable_link_crawler is true")
            if not proxy_thread_crawler: # start thread for link_crawler service
                crawler_stop_event = threading.Event()
                proxy_thread_crawler = threading.Thread(
                    target=link_crawler
                    ,args=(crawler_stop_event,)
                    ,name=C.addon_id+".link_crawler"
                    )
                proxy_thread_crawler.daemon = True
                proxy_thread_crawler.start()
            else:
                Log("proxy_thread_crawler already started")
        else:
##            Log("enable_link_crawler is false")
            if proxy_thread_crawler:
                if crawler_stop_event: crawler_stop_event.set()
                proxy_thread_crawler = None
##            webcam_db.clear_webcam_db()



        # start thread for enable_recording_service service
        #if C.addon.getSetting("enable_recording_service").lower() == "true":
        if GetSetting("enable_recording_service", bool):
            if (not proxy_thread_recording_service) or (not proxy_thread_recording_service.is_alive()) : # start thread
                recording_service_stop_event = threading.Event()
                proxy_thread_recording_service = threading.Thread(
                    target=recording_service
                    ,args=(recording_service_stop_event,)
                    ,name=C.addon_id+".recording_service"
                    )
                proxy_thread_recording_service.daemon = True
                proxy_thread_recording_service.start()
            else:
                Log("proxy_recording_service already started")
        else:
            if proxy_thread_recording_service:
                if recording_service_stop_event: recording_service_stop_event.set()
                proxy_thread_recording_service = None

                
        ## sleep then ... do some work
        sleeptime = int(GetSetting("service_periodic_interval", int) * (random.random())  )
##        Log("sleeptime={}".format(sleeptime))
        sleeptime = max(sleeptime, MIN_SLEEP_SECONDS)
##        sleeptime = 5
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        if monitor.waitForAbort(sleeptime):
            Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
            break

##        Log(repr(thread_cache.show()))

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = GetSetting('debug')

    if proxy_thread_crawler:
        if crawler_stop_event: crawler_stop_event.set()
        proxy_thread_crawler = None
    if proxy_thread_recording_service:
        if proxy_thread_recording_service: recording_service_stop_event.set()
        proxy_thread_recording_service = None
#__________________________________________________________________
#
