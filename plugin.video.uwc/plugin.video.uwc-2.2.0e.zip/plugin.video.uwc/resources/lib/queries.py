#-*- coding: utf-8 -*-
import constants as C

from utils import Log,LogR,UTC_timestamp
from utils import get_setting as GetSetting

FAV_DB_VERSION_1 = 1
FAV_DB_VERSION_2 = 2
FAV_DB_VERSION_3 = 3
FAV_DB_VERSION_4 = 4
FAV_DB_VERSION_5 = 5

KEYWORD_DB_VERSION_1 = 1
KEYWORD_DB_VERSION_2 = 2
KEYWORD_DB_VERSION_3 = 3
KEYWORD_DB_VERSION_4 = 4
KEYWORD_DB_VERSION_5 = 5

FAV_DB_VERSION_CURRENT = FAV_DB_VERSION_5

Log('warning: todo move queries in webcam.py and downloader.py')
###__________________________________________________________________
###
def CREATE_UUID_STRING(connection):
    if connection.internal_connection_mariadb:
        return (" uuid() ")
    else:
        return (
            " select lower(hex( randomblob(4)) || '-' ||      hex( randomblob(2)) "
            "        || '-' || '4' || substr( hex( randomblob(2)), 2) || '-' "
            "        || substr('AB89', 1 + (abs(random()) % 4) , 1)  "
            "        || substr(hex(randomblob(2)), 2) || '-' || hex(randomblob(6))) "
            )

#__________________________________________________________________
#
def LIST_FAVORITES_NOCAMSITE(
    FAV_DB_VERSION
    ,connection
    ,include_binary_image=False
    ):
    try: default_favorites_order = " ORDER BY " + GetSetting("default_favorites_order", str)  #'ORDER BY RANDOM()'
    except: default_favorites_order = ' ' #random order...optional?
    if 'ORDER BY  ID' in default_favorites_order:
        default_favorites_order = default_favorites_order.replace('ORDER BY  ID','ORDER BY ROWID')
    query = "\n"
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_4, FAV_DB_VERSION_5]:
        query += (
            " SELECT "
            "   `name` "
            " , `rowid` as id"
            " , `url` "
            " , `mode` "
            " , `image` "
            " , COALESCE(description,'') as description  "
            " , '' as `camscore`  "
            " , `camsite` "
            )

##including binary_image in this query
##causes 12s query time for my 3000 entry db (due to
##   the copying of the string buffer because my faster computer is faster)
##I can use the LIMIT option, but then the show-10%-after-limit-reached
##  feature wound not work
        if include_binary_image:
            query += (
                " , `binary_image` "
                )
        else:
            query += (
            " , '' as `binary_image` " #performance
            )
        query += (
            " , uuid"
            " FROM `favorites` "
            " where `is_deleted` =0 "
            " and `camsite` = 0 "
            " {} ".format(default_favorites_order)
            )

    elif FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " SELECT "
            "   name "
            " , rowid as id"
            " , url "
            " , mode "
            " , image "
            " , description "
            " , camsite "
            " , `binary_image` "
            " , uuid"
            " FROM favorites "
            " where is_deleted=0 "
            " and camsite = 0 "
            " {} ".format(default_favorites_order)
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    #return Convert_SQLITE3_MARIADB(query,connection)
    return query
#__________________________________________________________________
#
def LIST_FAVORITES_CAMSITE(
    FAV_DB_VERSION
    , connection
    , include_binary_image = True
    ):
    try: default_favorites_order = " ORDER BY " + GetSetting("default_favorites_order", str)  
    except: default_favorites_order = ' ' 

    #I always want to sort cams this way so that they are easier to find
    default_favorites_order = ' ORDER BY `date_modified` ASC '  
    
    query = "\n"
    if False:
        pass #stub

    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:
        query += (
            " SELECT  "
            "   F.name "
            " , F.rowid as id "
            " , url "
            " , F.mode   "
            " , COALESCE(C.icon_image,F.image,'') as image  "
            " , COALESCE(F.description,'') as description  "
            " , F.camsite   "
            " , CAST(COALESCE(C.camscore,'0') as INT) as camscore  "
            " , F.date_modified   "
            )
        if include_binary_image:
            query += (
                " , `binary_image` "
                )
        else:
            query += (
            " , '' as `binary_image` "
            )
        query += (
            " , F.uuid  "
            " , COALESCE(C.modelID,0) as isonline "
            " , C.modelID "
            " , C.modelDisplayName "
            " FROM favorites as F "
            " left JOIN camlist as C "
            "       on C.modelID = F.modelID  "
            " where  "
            " F.is_deleted=0  "
            " and F.camsite=1 "
            " {} ".format(default_favorites_order)
            )

    elif FAV_DB_VERSION in [FAV_DB_VERSION_4]:
        query += (
            " SELECT  "
            "   F.name "
            " , F.rowid as id "
            " , url "
            " , F.mode   "
            " , COALESCE(C.icon_image,F.image,'') as image  "
            " , COALESCE(F.description,'') as description  "
            " , F.camsite   "
            " , CAST(COALESCE(C.camscore,'0') as INT) as camscore  "
            " , F.date_modified   "
            )

##        Log('warning binary image select is costly...4.2sec vs 0.1sec keep it?')
        if include_binary_image:
            query += (
                " , `binary_image` "
                )
        else:
            query += (
            " , '' as `binary_image` " #performance
            )
        query += (
                    " , F.uuid  "
                    " , COALESCE(C.modelID,0) as isonline "
                    " , modelID "
                    " FROM favorites as F "
                    " left JOIN camlist as C "
                    "       on C.modelID = F.name  "
                    " where  "
                    " F.is_deleted=0  "
                    " and F.camsite=1 "
            )


    elif FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " SELECT "
            "   name "
            " , rowid as id"
            " , url "
            " , mode "
            " , image "
            " , description "
            " , camsite "
            " , `binary_image` "
            " , uuid"
            " FROM favorites "
            " where is_deleted=0 "
##            " and camsite = 1 "
            " {} ".format(default_favorites_order)
            )

    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

##    return Convert_SQLITE3_MARIADB(query,connection)
    return query
#__________________________________________________________________
#
def RENAME_FAV(FAV_DB_VERSION, name, url, uuid, connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = (
            " UPDATE favorites "
            " SET "
            "   name = ? "
            " , url  = ? " #MFC url may be changed due to 
            " , date_modified = CAST(strftime('%s') as INT) "
            #" , date_modified = unixepoch() "  #UNIX_TIMESTAMP()
            " WHERE uuid = ?;"
            )
        if not uuid: raise Exception()
        params = (name,url,uuid)
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return (query,params)

#__________________________________________________________________
#
def UPSERT_FAV(
    FAV_DB_VERSION 
    , name , url, mode                 #1-3
    , image, description, camsite      #4-6
    , binary_image, uuid               #7-8
    , is_deleted = 0                   #9
    , date_modified = None             #10
    , modelID       = None             #11
    ):
    if not uuid: raise Exception()
    if not description: description = ""
    if binary_image in ("",None,"None"): binary_image = ""
    if modelID in ("",None,"None"): raise Exception("modelID = name")
    if camsite in ("",None,"None"): camsite = "0"
    if date_modified in ("",None,"None"): date_modified = " CAST(strftime('%s') as INT) "
    
    if False:
        pass #stub

    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:
        i = {
            "table"        : " `favorites` "
            ,"key_name"    : " `uuid` "
            ,"key_value"   : repr(uuid)
            ,"column_tuple": (
                  " `name` " #1
                , " `url` "
                , " `mode` "    
                , " `image` " #4
                , " `description` "
                , " `camsite` "
                , " `binary_image` "
                , " `uuid` "  #8
                , " `is_deleted` " #9  
                , " `modelID` " #10
                , " `date_modified` " #11
                )
            ,"value_tuple": (
                  u" '{}' ".format(name.replace("'","''").replace("\\","\\\\"))
                , u" '{}' ".format(url.replace("'","''").replace("\\","\\\\"))
                , u" '{}' ".format(mode)
                , u" '{}' ".format(image.replace("'","''").replace("\\","\\\\"))
                , u" '{}' ".format(description.replace("'","''").replace("\\","\\\\"))
                , u" '{}' ".format(camsite)
                , u" '{}' ".format(binary_image)
                , u" '{}' ".format(uuid) 
                , u" '{}' ".format(is_deleted)
                , u" '{}' ".format(modelID.replace("'","''").replace("\\","\\\\")) 
                , str(date_modified)
                  )
            }
        return i
    elif FAV_DB_VERSION in [FAV_DB_VERSION_4]:
        i = {
            "table": " `favorites` "
            ,"key_name": " `uuid` "
            ,"key_value": repr(uuid)
            ,"column_tuple": (
                  " `name` "
                , " `url` "
                , " `mode` "    
                , " `image` " #4
                , " `description` "
                , " `camsite` "
                , " `binary_image` "
                , " `uuid` "  #8
                , " `is_deleted` "  
                , " `date_modified` "
                )
            ,"value_tuple": (
                u"'{}'".format(name.replace("'","''").replace("\\","\\\\"))
                , u"'{}'".format(url.replace("'","''").replace("\\","\\\\"))
                , u"'{}'".format(mode)
                , u"'{}'".format(image.replace("'","''").replace("\\","\\\\"))
                , u"'{}'".format(description.replace("'","''").replace("\\","\\\\"))
                , u"'{}'".format(camsite)
                , u"'{}'".format(binary_image)
                , u"'{}'".format(uuid) 
                , u"'{}'".format(is_deleted)
##                , " CAST(strftime('%s') as INT) "
                , str(date_modified)
                  )
            }
        return i

    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return (query,params)

#
#
#__________________________________________________________________
#
def UPSERT_SEARCHTERM(
    KEYWORD_DB_VERSION 
    , keyword , sequence, uuid #1-3
    , date_modified = None             #4
    , is_deleted = 0                   #5
    ):
    if not uuid: raise Exception()
    if sequence in ("",None,"None"): sequence = 0
    if date_modified in ("",None,"None"): date_modified = " CAST(strftime('%s') as INT) "
    
    if False:
        pass #stub

    elif KEYWORD_DB_VERSION in [FAV_DB_VERSION_5]:
        i = {
            "table"        : " `keywords` "
            ,"key_name"    : " `uuid` "
            ,"key_value"   : repr(uuid)
            ,"column_tuple": (
                  " `keyword` " #1
                , " `sequence` "
                , " `uuid` "  
                , " `is_deleted` " 
                , " `date_modified` " 
                )
            ,"value_tuple": (
                  u" '{}' ".format(keyword.replace("'","''").replace("\\","\\\\"))
                , u" '{}' ".format(sequence)
                , u" '{}' ".format(uuid) 
                , u" '{}' ".format(is_deleted)
                , str(date_modified)
                  )
            }
        return i
    else:
        raise NotImplementedError(C.module_name(),KEYWORD_DB_VERSION)
    return (query,params)


#__________________________________________________________________
#
def REFRESH_FAV2(  #Rebuild_NONCAM_Thumbnails
    FAV_DB_VERSION
    , uuid, image, description
    , binary_image):
    if not uuid: raise Exception()
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_4, FAV_DB_VERSION_5]:
        query = {
            "table": " `favorites` "
            ,"key_name": " `uuid` "
            ,"key_value": repr(uuid)
            ,"column_tuple": (
                  " `image` "
                , " `binary_image` "
                , " `description` "
                , " `date_modified` "
                , " `is_deleted` "
                )
            ,"value_tuple": (
                 u"'{}'".format(image)
                , u"'{}'".format(binary_image)
                , u"'{}'".format(description)
                , " CAST(strftime('%s') as INT) "
                , u" '0' " 
                  )
            }
        return query
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

###__________________________________________________________________
###
##def REFRESH_FAV(
##    FAV_DB_VERSION, uuid, image, description
##    , binary_image):
##    if False:
##        pass #stub
##    elif FAV_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
##        query = (
##            " UPDATE favorites "
##            " SET "
##            " image = ?"
##            " , `binary_image` = ? "
##            " , description = ? "
##            " , date_modified = CAST(strftime('%s') as INT) "
##            #unixepoch() only availble of sqlite 3.38
##            #" , date_modified = unixepoch() "  #UNIX_TIMESTAMP()
##            " WHERE uuid = ?;"
##            )
##        if not uuid: raise Exception()
##        params = (image,binary_image,description,uuid)
##    else:
##        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
##    return (query,params)
#__________________________________________________________________
#
def DELETE_FAV(FAV_DB_VERSION, url, uuid, connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        if uuid:
            query = (
                "\n"
                " UPDATE favorites "
                " SET is_deleted = 1 "
                " , date_modified = CAST(strftime('%s') as INT) "
                " WHERE uuid = ?"
                " and is_deleted != 1 "
                # this last check so that already deleted items are
                #    not counted as a change
                )
            params = (uuid,)
        else:
            query = (
                " UPDATE favorites "
                " SET is_deleted = 1 "
                " , date_modified = CAST(strftime('%s') as INT) "
                # , date_modified = unixepoch() "  #UNIX_TIMESTAMP()
                " WHERE url LIKE ?;"
                )
            params = (url,)
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

##    query = Convert_SQLITE3_MARIADB(query,connection)
    return (query,params)
#__________________________________________________________________
#
def DELETE_TOMBSTONED(FAV_DB_VERSION, connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_3,FAV_DB_VERSION_4,FAV_DB_VERSION_5]:

        #different queries for optimization due to different DB featurse
        if connection.internal_connection_mariadb:
            query = \
                '''
                DELETE f2.* FROM `favorites` as `f2`
                inner join 
                (select `f3`.`rowid` from `favorites` as `f3` where `f3`.`is_deleted` = 1) as `f4`
                on `f2`.`rowid` = `f4`.`rowid`
                WHERE
                (`date_modified` < ( COALESCE( NULLIF(cast(? as int), 0), UNIX_TIMESTAMP() )           - (? * 86400) ) );
                '''
        elif connection.internal_connection_sqlite3:
            query = \
                '''
                DELETE FROM `favorites`
                WHERE
                (`rowid` in (select `f2`.`rowid` from `favorites` as `f2` where `is_deleted` = 1) )
                AND 
                (`date_modified` < ( COALESCE( NULLIF(cast(? as int), 0), CAST(strftime('%s') as INT) ) - (? * 86400) ) );
                '''
        else:
            raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_FAV_VIA_UUID(FAV_DB_VERSION):
    #FAV_DB_VERSION_CURRENT
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_3, FAV_DB_VERSION_4, FAV_DB_VERSION_5]:
        query = (
            " SELECT "
            " * "
            " FROM `favorites` "
            " WHERE "
            " `uuid` = ? "
            " ; "
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_FAV_URL(FAV_DB_VERSION):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5, FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = \
            '''
            SELECT * FROM `favorites` WHERE `url` LIKE ? ;
            '''
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query
###__________________________________________________________________
###  commented out not used
##def INSERT_FAV(FAV_DB_VERSION,connection):
##    if False:
##        pass #stub
##    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:
##        query = (
##           "\n INSERT INTO favorites ("
##             "    `name`          "   #1
##             "  , `url`            "  #2
##             "  , `mode`            " #3
##             "  , `image`     "       #4
##             "  , `description` "     #5
##             "  , `camsite` "         #6
##             "  , `binary_image` "    #7
##             "  , `date_modified`  "  #8
##             "  , `uuid`  "           #9
##             " ) "
##             " VALUES ( "
##             "  ?,?,? "    #1-3
##             " ,?,?,? "    #4-6
##             " ,? "
##             " ,  CAST(strftime('%s') as INT) " #8
##             " ,? " #9
##             " ); "
##            )
##    elif FAV_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
##        query = (
##           "\n INSERT INTO favorites ("
##             "    `name`          "   #1
##             "  , `url`            "  #2
##             "  , `mode`            " #3
##             "  , `image`     "       #4
##             "  , `description` "     #5
##             "  , `camsite` "         #6
##             "  , `binary_image` "    #7
##             "  , `date_modified`  "  #8
##             "  , `uuid`  "           #9
##             " ) "
##             " VALUES ( "
##             "  ?,?,? "
##             " ,?,?,? "
##             " ,? "
##             " ,  CAST(strftime('%s') as INT) " #8
##             " ,? " #9
##             " ); "
##            )
##    else:
##        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
####    query = Convert_SQLITE3_MARIADB(query,connection)
##    return query
#__________________________________________________________________
#
def MAIN_TABLE_STRING(FAV_DB_VERSION, connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:
        query = (
            "  `rowid` integer NOT NULL PRIMARY KEY AUTOINCREMENT "
            " , `name`  varchar(4096)" #varchar so that mysql can create an index
            " , `modelID`  varchar(4096)" #varchar so that mysql can create an index
            " , `url` varchar(4096)" #varchar so that mysql can create an index
            " , `mode` INTEGER"
            " , `image` TEXT"
            " , `description` TEXT DEFAULT ''"
            " , `camsite` INTEGER DEFAULT 0 "
            )
        if connection.internal_connection_mariadb:
            query += " , `binary_image` LONGTEXT DEFAULT ''"
        else:
            query += " , `binary_image` LONGTEXT DEFAULT ''" #sqlite3 supports LONGTEXT keyword
        query += (
            " , `uuid`	     VARCHAR(36) NULL unique "
            " , `date_modified`	REAL NOT NULL"
            " , `is_deleted` INTEGER NOT NULL DEFAULT 0"
            )

    elif FAV_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:

        query = (
            ##" id INTEGER NOT NULL"
            "  `rowid` integer NOT NULL PRIMARY KEY AUTOINCREMENT "
            " , `name`  varchar(4096)" #varchar so that mysql can create an index
            #" , `modelID`  varchar(4096)" #varchar so that mysql can create an index
            " , `url` varchar(4096)" #varchar so that mysql can create an index
            " , `mode` INTEGER"
            " , `image` TEXT"
            " , `description` TEXT DEFAULT ''"
            " , `camsite` INTEGER DEFAULT 0 "
            )
        if connection.internal_connection_mariadb:
            query += " , `binary_image` LONGTEXT DEFAULT ''"
        else:
            query += " , `binary_image` LONGTEXT DEFAULT ''" #sqlite3 supports LONGTEXT keyword
        query += (
            #" , `uuid`	     VARCHAR(36) NOT NULL unique "
            " , `uuid`	     VARCHAR(36) NULL unique "
            " , `date_modified`	REAL NOT NULL"
            " , `is_deleted` INTEGER NOT NULL DEFAULT 0"
            ##" , PRIMARY KEY(\"id\" AUTOINCREMENT)"
            )
    elif FAV_DB_VERSION == FAV_DB_VERSION_1:
        query = (
            " id INTEGER PRIMARY KEY, name, url, mode, image"
            " , description TEXT DEFAULT '' "
            " , camsite INTEGER DEFAULT NULL "
            )
    elif FAV_DB_VERSION == FAV_DB_VERSION_2:
        query = (
            " id INTEGER PRIMARY KEY, name, url, mode, image"
            " , description TEXT DEFAULT ''"
            " , camsite INTEGER DEFAULT NULL"
            " , binary_image TEXT DEFAULT ''"
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

    return query
#__________________________________________________________________
#
def GET_DB_UUID(FAV_DB_VERSION):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_3,FAV_DB_VERSION_4,FAV_DB_VERSION_5]:
        query = '''
select
    uuid
from
    favorites_meta
'''
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_DB_USER_VERSION(connection):
    if False:
        pass #stub
    elif True:
        query = \
            '''
            select `user_version` from `favorites_meta` ;
            '''
        # limit 1;
        
    else:
        raise NotImplementedError(C.module_name(), str(type(connection)))
    return query
#__________________________________________________________________
#
def FAVORITE_ROWCOUNT(FAV_DB_VERSION, connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = \
            '''
            SELECT coalesce(min(`rowid`),-1) as `min_rowid`, coalesce(max(`rowid`),-1) as `max_rowid`, count(*) as `row_count` FROM `favorites`
            '''
##            select count(*) as `count` from `favorites`
##            select count(`rowid`) as `count` from `favorites` where `is_deleted` = 0 ; 
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_MAX_ROWID(FAV_DB_VERSION): #, connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = \
            '''
            select ifnull(max(`rowid`),?) as `max_rowid` from `favorites` ;
            '''
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_MAX_MODIFIED_IN_IDRANGE(FAV_DB_VERSION):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = (
            " SELECT "
            "   COALESCE(MAX(`date_modified`),0) as `max_date_modified` "
            " from `favorites` "
##            " indexed by 'index_favorites_modified-rowid' "
            " WHERE "
            "   `rowid` >= ? "
            " AND "
            "   `rowid` <= ? "
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_RANDOM_NOT_CAM_FAVORITE_ID(FAV_DB_VERSION,connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4]:
        query = '''
                select `rowid`
		from   `favorites`
		where  `camsite` = 0
			AND
			`is_deleted` = 0
		order by random()
		limit 1;
		'''
    elif FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " select rowid "
            " ,* "
            " from favorites  "
            ' indexed by "index_favorites_camsite-isdeleted" '
            " where  camsite = 0 "
            " AND is_deleted = 0 "
            " order by random() "
            " limit 1 ; "
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
##    query = Convert_SQLITE3_MARIADB(query,connection)
    return query
#__________________________________________________________________
#
def GET_RANDOM_NOT_CAM_FAVORITE_INFO(FAV_DB_VERSION,connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5, FAV_DB_VERSION_4]:
        #below works with mariadb and sqlite
        query = '''
            select name,url,mode,image,description 
            from `favorites` as `f` 
            inner join
            (
                    select `rowid`
                    from   `favorites`
                    where  `camsite` = 0
                            AND
                            `is_deleted` = 0
                    order by random()
                    limit 1
            ) as `r`
            on `r`.`rowid` = `f`.`rowid`;
            '''        
    elif FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " select rowid "
            " ,* "
            " from favorites  "
            ' indexed by "index_favorites_camsite-isdeleted" '
            " where  camsite = 0 "
            " AND is_deleted = 0 "
            " order by random() "
            " limit 1 ; "
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
##    query = Convert_SQLITE3_MARIADB(query,connection)
    return query
#__________________________________________________________________
#
def GET_DB_REPL_VECTOR(FAV_DB_VERSION):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = (
            " SELECT "
            "    `Local_db_repl_id_highwater` "
            "   , `local_db_date_modified_highwater` "
            "   , `full_repl` "
            "   , `id_range_start` "
            "   , `id_range_end` "
            " FROM "
            "    `favorites_replication` "
            " WHERE "
            "    `remote_db_uuid` = ? "
            "   AND "
            "    `id_range_start` = ? "
            "   AND "
            "    `id_range_end` = ? "
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def INIT_DB_REPL_VECTOR(FAV_DB_VERSION, connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = (
            " INSERT INTO "
            "    `favorites_replication`  "
            " ( "
            " remote_db_uuid "
            " , `local_db_repl_id_highwater` "
            " , `local_db_date_modified_highwater` "
            " , `full_repl` "
            " , `id_range_start` "
            " , `id_range_end` "
            " , `date_modified` "
            " )  "
            " VALUES ( ?, ?, ?, ?, ?, ? "
            " , CAST(strftime('%s') as INT)  )  "
            " ; "
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
##    query = Convert_SQLITE3_MARIADB(query,connection)
    return query
#__________________________________________________________________
#
def WRITE_DB_REPL_VECTOR(FAV_DB_VERSION,connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = '''
     UPDATE 
        `favorites_replication` 
     SET 
         `local_db_repl_id_highwater` = ? 
       , `local_db_date_modified_highwater` = CAST(? as INT) 
       , `full_repl` = ? 
       , `date_modified` = CAST(strftime('%s') as INT) 
     WHERE 
        `remote_db_uuid` = ? 
       AND 
        `id_range_start` = ? 
       AND 
        `id_range_end` = ? 
      AND NOT EXISTS (
         SELECT * FROM `favorites_replication`
         WHERE  `local_db_repl_id_highwater` = ?
            AND `local_db_date_modified_highwater` = CAST(? as INT)
            AND  `full_repl` = ?
            AND `remote_db_uuid` = ?
            AND     `id_range_start` = ?
            AND     `id_range_end` = ?
        )
        '''
        # the not exists clause is so that I don't update with same info
        #  I could also use a trigger like I do with fav recors
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

    return query
#__________________________________________________________________
#
def GET_DATA_TO_REPLICATE(
    FAV_DB_VERSION
                , id_highwater
                , date_modified_highwater
                , id_range_start
                , id_range_end
              ):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:
        query = (
    ##        " EXPLAIN QUERY PLAN  "
            " SELECT "
            "   `name` "            #1
            " , `url` "             #2
            " , `mode` "            #3
            " , `image` "           #4
            " , `description` "     #5
            " , `camsite` "         #6
            " , `binary_image` "    #7
            " , `is_deleted` "      #8
            " , `date_modified` "   #9
            " , `uuid` "            #10
            " , `rowid` "           #11
            " , `modelID` "         #12
#            " , count(*) as `select_count` "           
#            " , 1 as dummy_for_insert1 "   #12 #extra copy of this so that insert/update input params can be the same
            " FROM `favorites` "
##            ' indexed by "index_favorites_modified-rowid" '
            " WHERE ("
            "    `rowid` >= ? "
            "    AND "
            "    `rowid` >= ? "
            "    AND "
            "    `rowid` <= ? "
            "    AND "
            "    `date_modified` > ? "
##            " AND UUID='91fdeb98-a6dd-4fe8-a601-c491ec432c64'"
            " ) "
##            " limit 10 "
            )
        params = (
              int(id_highwater)
            , int(id_range_start)
            , int(id_range_end)
            , float(date_modified_highwater)
            )
##        LogR(date_modified_highwater)
##        LogR(params)
    elif FAV_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = (
    ##        " EXPLAIN QUERY PLAN  "
            " SELECT "
            "   `name` "            #1
            " , `url` "             #2
            " , `mode` "            #3
            " , `image` "           #4
            " , `description` "     #5
            " , `camsite` "         #6
            " , `binary_image` "    #7
            " , `is_deleted` "      #8
            " , `date_modified` "   #9
            " , `uuid` "            #10
            " , `rowid` "           #11
#            " , count(*) as `select_count` "           #12
#            " , 1 as dummy_for_insert1 "   #12 #extra copy of this so that insert/update input params can be the same
            " FROM `favorites` "
##            ' indexed by "index_favorites_modified-rowid" '
            " WHERE ("
            "    `rowid` >= ? "
            "    AND "
            "    `rowid` >= ? "
            "    AND "
            "    `rowid` <= ? "
            "    AND "
            "    `date_modified` > ? "
##            " AND UUID='91fdeb98-a6dd-4fe8-a601-c491ec432c64'"
            " ) "
##            " limit 10 "
            )
        params = (
            int(id_highwater)
            , int(id_range_start)
            , int(id_range_end)
            , float(date_modified_highwater)
            )
##        LogR(date_modified_highwater)
##        LogR(params)
    elif FAV_DB_VERSION == FAV_DB_VERSION_1:
        query = (
            " SELECT "
            "   name "                   #1
            " , url "                    #2
            " , mode "                   #3
            " , image "                  #4
            " , description "            #5
            " , camsite "                #6
            " , `binary_image` "           #7
            " , 0 as is_deleted "        #8
            " , 0 as date_modified    "  #9
            " , NULL as uuid "           #10
            " , 666 as rowid "           #11
            " , 1 as dummy_for_insert1 " #12
            " FROM favorites "
            " WHERE (rowid >= ?) " #during dev
##            " LIMIT 5 "    #during dev
            )
        params = (int(id_range_start),)
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return (query, params)
#__________________________________________________________________
#
def INSERT_FAVORITES(FAV_DB_VERSION, connection):
    query = ""
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:
        query += (
            "\n"
            " insert into favorites "
            " ( "
            "   name "
            " , modelID "
            " , url "
            " , mode " #3
            " , image"
            " , description "
            " , camsite" #6
            " , `binary_image` " #7
            " , is_deleted " #8
            " , date_modified " #9
            " , uuid " #10
            " ) "
            " select "
            "  ?,?,? "  #1-3
            " , ?,?,? " #4-6
            " , ? "     #bin iamge
            " , ? "     #8
            " , ? "     #9
            #" , CAST(strftime('%s') as INT) " #9
            " , ? "  #10
        )
        if connection.internal_connection_mariadb:
            query += ( " FROM DUAL " ) #mariadb  only - DUAL is a special 'stub' table because WHERE syntax needs it
    elif FAV_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query += (
            "\n"
            " insert into favorites "
            " ( "
            "   name "
            " , url "
            " , mode " #3
            " , image"
            " , description "
            " , camsite" #6
            " , `binary_image` " #7
            " , is_deleted " #8
            " , date_modified " #9
            " , uuid " #10
            " ) "
            " select "
            "  ?,?,? "  #1-3
            " , ?,?,? " #4-6
            " , ? "     #bin iamge
            " , ? "     #8
            " , ? "     #9
            #" , CAST(strftime('%s') as INT) " #9
            " , ? "  #10
        )
        if connection.internal_connection_mariadb:
            query += ( " FROM DUAL " ) #mariadb  only - DUAL is a special 'stub' table because WHERE syntax needs it
##        query += (
##            " where exists (select (? AND ?) ) " #? AND ? are just there to use up ? params so insert and update use same number
##            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return query

#__________________________________________________________________
#
def UPDATE_FAVORITES(FAV_DB_VERSION,connection):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:
        query = (
            "\n"
            " update favorites "
            " set                 "
            "            `name` =? "
            " ,       `modelID` =? "
            " ,           `url` =? "
            " ,          `mode` =? "  #
            " ,         `image` =? "
            " ,   `description` =? "
            " ,       `camsite` =? " #6
            " ,  `binary_image` =? "
            " ,    `is_deleted` =? "
            " , `date_modified` =? " #9
            " where                "
            "    `uuid` = ?        " #10
            )
    elif FAV_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
##        n = C.sys._getframe(0).f_code.co_name
##        Log("{} for version {} not yet implemented".format(
##                n, FAV_DB_VERSION
##                )
##            ,C.LOGWARNING
##            )
        query = (
            "\n"
            " update favorites "
            " set                 "
            "            `name` =? "
            " ,           `url` =? "
            " ,          `mode` =? "  #
            " ,         `image` =? "
            " ,   `description` =? "
            " ,       `camsite` =? " #6
            " ,  `binary_image` =? "
            " ,    `is_deleted` =? "
            " , `date_modified` =? " #9
            " where                "
            "    `uuid` = ?        " #10
##            "    and ( ? and ?) " #? AND ? are just there to use up ? params
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
##    query = Convert_SQLITE3_MARIADB(query,connection)
    return query


#__________________________________________________________________
#
def DB_SCHEMA_indicies(FAV_DB_VERSION, connection):
        return (
            "\nCREATE INDEX if not exists `index_favorites_modified-rowid` ON `favorites` ( "
            " 	`date_modified`	ASC "
            " 	,`rowid`	ASC "
            " ); "

            "\nCREATE INDEX IF NOT EXISTS `index_favorites_modified-isdeleted` ON `favorites` (  "
            "  	`date_modified`	DESC  "
            "   , `is_deleted`	ASC   "
            " ); "

            "\nCREATE INDEX if not exists `index_favorites_uuid` ON `favorites` ( "
            "	`uuid`	ASC "
            " ); "

            "\nCREATE INDEX if not exists `index_favorites_url` ON `favorites` ( "
            "	`url`	ASC "
            " ); "

            "\nCREATE INDEX if not exists `index_favorites_name` ON `favorites` ( "
            "	`name`	ASC "
            " ); "

            "\nCREATE INDEX if not exists `index_favorites_camsite-isdeleted` ON `favorites` ( "
            " 	`camsite`	ASC, "
            " 	`is_deleted`	ASC "
            " ); "

            )
#__________________________________________________________________
#
def DB_SCHEMA_query_favorites_meta(FAV_DB_VERSION, connection):
    
    query_favorites_meta = (
        "\nCREATE TABLE IF NOT EXISTS `favorites_meta` (`uuid` TEXT, `user_version` INT ); "
        "\ninsert into `favorites_meta` (`uuid`, `user_version`) "
        )
    if connection.internal_connection_mariadb:
        query_favorites_meta += ( " SELECT " ) #mariADB
    query_favorites_meta += (
        CREATE_UUID_STRING(connection)
        )
    query_favorites_meta += ( ',0') #default user_version
    if connection.internal_connection_mariadb:
        query_favorites_meta += ( " FROM DUAL " ) #mariadb  only - DUAL is a special 'stub' table because WHERE syntax needs it
    query_favorites_meta += (
        " WHERE NOT EXISTS  (SELECT 1 FROM `favorites_meta` WHERE `UUID` LIKE '%'  )"
        ";"
        )
    return query_favorites_meta

#__________________________________________________________________
#
def DB_SCHEMA_query_favorites_replication(FAV_DB_VERSION, connection):

    return (
        " CREATE TABLE IF NOT EXISTS `favorites_replication` (  "
        "   `rowid`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT "
        " , `remote_db_uuid` TEXT "
        " , `local_db_repl_id_highwater` INT DEFAULT 0 "
        " , `local_db_date_modified_highwater` REAL DEFAULT 0 "
        " , `full_repl` INT DEFAULT 0 "
        " , `id_range_start` INT DEFAULT 0 "
        " , `id_range_end` INT DEFAULT 0  "
        " , `date_modified` REAL DEFAULT 0  "
        " ); "
    )

#__________________________________________________________________
# `make sure UUID has a default value`
def DB_SCHEMA_query_favorites_uuid_create_trigger(FAV_DB_VERSION, connection):
    if connection.internal_connection_mariadb:
        return (
                #" \nDELIMITER // \n" #a reminder that needed only in gui
                " CREATE TRIGGER if not exists `trigger_favorites_INSERT_UUID` "
                " BEFORE INSERT "
                " ON "
                " `favorites` "
                " FOR EACH ROW "
                " BEGIN "
                "   IF (IFNULL(NEW.`uuid`, '') = '') THEN "
                "       set NEW.`uuid` = UUID() ; "
                "   END IF ; "
                " END ; "
##                " // \nDELIMITER ; \n" #a reminder that needed only in gui
            )
    else:
        return ""
##        return Convert_SQLITE3_MARIADB(query,connection)

#__________________________________________________________________
# validate favorite info before update
def DB_SCHEMA_trigger_duplicate_detection(FAV_DB_VERSION, connection):

    if False:
        pass
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:

        query = (
            " \n "
            " CREATE TRIGGER if not exists `trigger_favorites_UPDATE_before` "
            " BEFORE update ON `favorites` "
            " FOR EACH ROW "
            " BEGIN  "
        )

        if connection.internal_connection_mariadb:
            query += (
                " IF IFNULL(NEW.name, '') LIKE '' THEN "
                "    SIGNAL SQLSTATE '45000' "
                "     SET MESSAGE_TEXT= 'new name may not be blank' ; "
                " END IF ; "
            )
        else:
            query += (
                " 	SELECT "
                " 	    RAISE(FAIL, 'new name may not be blank') "
                " 	WHERE "
                " 	    IFNULL(NEW.\"name\",'') == ''; "
            )


        if connection.internal_connection_mariadb:
            query += (
            " IF ( "
            "                               CAST(NEW.`mode` AS INT)  = CAST(OLD.`mode` AS INT) "
            "       AND                                  NEW.`name`  = OLD.`name` "
            "       AND                               NEW.`modelID`  = OLD.`modelID` "
            "       AND                                   NEW.`url`  = OLD.`url` "
            "       AND                                 NEW.`image`  = OLD.`image` "
            "       AND                IFNULL(NEW.`description`,'')  = IFNULL(OLD.`description`,'') "
            "       AND               IFNULL(NEW.`binary_image`,'')  = IFNULL(OLD.`binary_image`,'') "
            "       AND                                  NEW.`uuid`  = OLD.`uuid` "
            "       AND               CAST(NEW.`is_deleted` AS INT)  = CAST(OLD.`is_deleted` AS INT) "
            "       AND        CAST(ifnull(NEW.`camsite`,-1) AS INT) = CAST(ifnull(OLD.`camsite`,-1) AS INT) "
            "       AND CAST(ifnull(NEW.`date_modified`,-1) AS INT)  = CAST(ifnull(OLD.`date_modified`,-1) AS INT) "
            "       ) "
            #
            " THEN       "
                "    SIGNAL SQLSTATE '45000' "
                "     SET MESSAGE_TEXT= 'duplicate information' ; "
                " END IF ; "
            " IF CAST(ifnull(NEW.`date_modified`,-1) AS INT)  <  CAST(ifnull(OLD.`date_modified`,-1) AS INT) THEN"
                "    SIGNAL SQLSTATE '45000' "
                "     SET MESSAGE_TEXT= 'invalid date_modified' ; "
                " END IF ; "
            " END ; "
            )

        if connection.internal_connection_sqlite3:
            #sqlite3 does not use IF ENDIF
            query += (
            " 	SELECT  "
            " 		RAISE(ABORT, 'duplicate information') "
            " 	WHERE EXISTS ( "
            "       SELECT 1 "
            "       WHERE ( "
            '                               CAST(NEW."mode" AS INT) == CAST(OLD."mode" AS INT) '
            '       AND                                  NEW."name" == OLD."name" '
            '       AND                               NEW."modelID" == OLD."modelID" '
            '       AND                                   NEW."url" == OLD."url" '
            '       AND                                 NEW."image" == OLD."image" '
            '       AND              IFNULL(NEW."description",\'\') == IFNULL(OLD."description",\'\') \n'
            '       AND             IFNULL(NEW."binary_image",\'\') == IFNULL(OLD."binary_image",\'\') \n'
            '       AND                                  NEW."uuid" == OLD."uuid" '
            '       AND               CAST(NEW."is_deleted" AS INT) == CAST(OLD."is_deleted" AS INT) '
            '       AND        CAST(ifnull(NEW."camsite",0) AS INT) == CAST(ifnull(OLD."camsite",0) AS INT) '
            '       AND  CAST(ifnull(NEW."date_modified",-1) AS INT) == CAST(ifnull(OLD."date_modified",-1) AS INT) '
             '       ) \n'
            '       OR    CAST(ifnull(NEW.date_modified,-1) AS INT)  <  CAST(ifnull(OLD.date_modified,-1) AS INT) '
            "       ); "
            )

            query += (
             "  UPDATE favorites "
            "   SET date_modified = CAST(strftime('%s') as INT) /*tested to be UTC */ "
            "   WHERE "
            "       NEW.date_modified=date_modified "
            "       AND "
            "       rowid = NEW.rowid "
            "   ;    "
            "END; "
            )
            

    elif FAV_DB_VERSION in [FAV_DB_VERSION_4]:

        query = (
            " \n "
            " CREATE TRIGGER if not exists `trigger_favorites_UPDATE_before` "
            " BEFORE update ON `favorites` "
            " FOR EACH ROW "
            " BEGIN  "
        )

        if connection.internal_connection_mariadb:
            query += (
                " IF IFNULL(NEW.name, '') LIKE '' THEN "
                "    SIGNAL SQLSTATE '45000' "
                "     SET MESSAGE_TEXT= 'new name may not be blank' ; "
                " END IF ; "
            )
        else:
            query += (
                " 	SELECT "
                " 	    RAISE(FAIL, 'new name may not be blank') "
                " 	WHERE "
                " 	    IFNULL(NEW.\"name\",'') == ''; "
            )


        if connection.internal_connection_mariadb:
            query += (
            " IF ( "
            "                               CAST(NEW.`mode` AS INT)  = CAST(OLD.`mode` AS INT) "
            "       AND                                  NEW.`name`  = OLD.`name` "
            "       AND                                   NEW.`url`  = OLD.`url` "
            "       AND                                 NEW.`image`  = OLD.`image` "
            "       AND                IFNULL(NEW.`description`,'')  = IFNULL(OLD.`description`,'') "
            "       AND               IFNULL(NEW.`binary_image`,'')  = IFNULL(OLD.`binary_image`,'') "
            "       AND                                  NEW.`uuid`  = OLD.`uuid` "
            "       AND               CAST(NEW.`is_deleted` AS INT)  = CAST(OLD.`is_deleted` AS INT) "
            "       AND        CAST(ifnull(NEW.`camsite`,-1) AS INT) = CAST(ifnull(OLD.`camsite`,-1) AS INT) "
            "       AND CAST(ifnull(NEW.`date_modified`,-1) AS INT)  = CAST(ifnull(OLD.`date_modified`,-1) AS INT) "
            "       ) "
            #
            " THEN       "
                "    SIGNAL SQLSTATE '45000' "
                "     SET MESSAGE_TEXT= 'duplicate information' ; "
                " END IF ; "
            " IF CAST(ifnull(NEW.`date_modified`,-1) AS INT)  <  CAST(ifnull(OLD.`date_modified`,-1) AS INT) THEN"
                "    SIGNAL SQLSTATE '45000' "
                "     SET MESSAGE_TEXT= 'invalid date_modified' ; "
                " END IF ; "
            " END ; "
            )

        if connection.internal_connection_sqlite3:
            #sqlite3 does not use IF ENDIF
            query += (
            " 	SELECT  "
            " 		RAISE(ABORT, 'duplicate information') "
            " 	WHERE EXISTS ( "
            "       SELECT 1 "
            "       WHERE ( "
            '                               CAST(NEW."mode" AS INT) == CAST(OLD."mode" AS INT) '
            '       AND                                  NEW."name" == OLD."name" '
            '       AND                                   NEW."url" == OLD."url" '
            '       AND                                 NEW."image" == OLD."image" '
            '       AND              IFNULL(NEW."description",\'\') == IFNULL(OLD."description",\'\') \n'
            '       AND             IFNULL(NEW."binary_image",\'\') == IFNULL(OLD."binary_image",\'\') \n'
            '       AND                                  NEW."uuid" == OLD."uuid" '
            '       AND               CAST(NEW."is_deleted" AS INT) == CAST(OLD."is_deleted" AS INT) '
            '       AND        CAST(ifnull(NEW."camsite",0) AS INT) == CAST(ifnull(OLD."camsite",0) AS INT) '
            '       AND  CAST(ifnull(NEW."date_modified",-1) AS INT) == CAST(ifnull(OLD."date_modified",-1) AS INT) '
             '       ) \n'
            '       OR    CAST(ifnull(NEW.date_modified,-1) AS INT)  <  CAST(ifnull(OLD.date_modified,-1) AS INT) '
            "       ); "
            )

            query += (
             "  UPDATE favorites "
            "   SET date_modified = CAST(strftime('%s') as INT) /*tested to be UTC */ "
            "   WHERE "
            "       NEW.date_modified=date_modified "
            "       AND "
            "       rowid = NEW.rowid "
            "   ;    "
            "END; "
            )

    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    
    return query

#__________________________________________________________________
# optional views and triggers to keep track of changes
def DB_SCHEMA_optional_change_tracking(FAV_DB_VERSION, connection):

    if False:
        pass
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:
        query = '''
\nCREATE TABLE
IF NOT EXISTS
`changes` (
	`rowid`	INTEGER,
	`name`	TEXT,
	`old`	LONGTEXT,
	`new`	LONGTEXT,
	`modified`	INTEGER
	,`id` INTEGER PRIMARY KEY AUTOINCREMENT );

CREATE VIEW
IF NOT EXISTS
`view_changes` AS
select
    `f`.`rowid` AS `rowid`
    ,`f`.`name` AS `name`
    ,`c`.`name` AS `column_name`
    ,`c`.`old` AS `old`
    ,`c`.`new` AS `new`
'''

        if connection.internal_connection_sqlite3:
                query += '''
    ,datetime(c.`modified`, 'unixepoch', 'localtime') AS `modified`
'''

        if connection.internal_connection_mariadb:
                query += '''
    ,from_unixtime(`c`.`modified`) AS `modified`
'''
        query += '''
        ,`c`.`id`
from
    (`changes` `c`
join `favorites` `f` on
    (`f`.`rowid` = `c`.`rowid`))
order by
`id` DESC;

CREATE TRIGGER
IF NOT EXISTS
`trigger_favorites_INSERT_after`
AFTER insert ON `favorites`
FOR EACH ROW
BEGIN
-- select 0;
-- SELECT RAISE(ABORT,'trigger_favorites_INSERT_after');
--
insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'description INSERT', NULL, NEW.`description`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
IFNULL(NEW.`description`,'1') != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'mode', NULL, NEW.`mode`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`mode`,1) != IFNULL(NULL,1);

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid, 'name', NULL, NEW.`name`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`name`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid, 'modelID', NULL, NEW.`modelID`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`modelID`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'url', NULL, NEW.`url`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`url`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'image', NULL, NEW.`image`,
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`image`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'binary_image', NULL, NEW.`binary_image`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`binary_image`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'uuid', NULL, NEW.`uuid`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
IFNULL(NEW.`uuid`,1) != IFNULL(NULL,'1');

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'camsite', NULL, NEW.`camsite`,
 UNIX_TIMESTAMP()  FROM DUAL  WHERE
IFNULL(NEW.`camsite`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'is_deleted', NULL, NEW.`is_deleted`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`is_deleted`,2) != IFNULL(NULL,2);

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'date_modified', NULL, NEW.`date_modified`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
IFNULL(NEW.`date_modified`,1) != IFNULL(NULL,1);

END;




CREATE TRIGGER
IF NOT EXISTS
`trigger_favorites_UPDATE_after`
AFTER update ON `favorites`
FOR EACH ROW
BEGIN

Insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'description', OLD.`description`, NEW.`description`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
IFNULL(NEW.`description`,'') != IFNULL(OLD.`description`,'');

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'mode', OLD.`mode`, NEW.`mode`,
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(CAST(NEW.`mode` as int),1) != IFNULL(cast(OLD.`mode` as int),1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'name', OLD.`name`, NEW.`name`,  
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`name`,1) != IFNULL(OLD.`name`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid, 'modelID', OLD.`modelID`, NEW.`modelID`,  
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`modelID`,1) != IFNULL(OLD.`modelID`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'url', OLD.`url`, NEW.`url`,  
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`url`,1) != IFNULL(OLD.`url`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'image', OLD.`image`, NEW.`image`,  
  UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`image`,1) != IFNULL(OLD.`image`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'binary_image', OLD.`binary_image`, NEW.`binary_image`,
 UNIX_TIMESTAMP() FROM DUAL  WHERE
IFNULL(NEW.`binary_image`,1) != IFNULL(OLD.`binary_image`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'uuid', OLD.`uuid`, NEW.`uuid`,  
 UNIX_TIMESTAMP() FROM DUAL  WHERE
IFNULL(NEW.`uuid`,1) != IFNULL(OLD.`uuid`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'is_deleted', OLD.`is_deleted`, NEW.`is_deleted`,
 UNIX_TIMESTAMP()  FROM DUAL  WHERE
IFNULL(NEW.`is_deleted`,1) != IFNULL(OLD.`is_deleted`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'camsite', OLD.`camsite`, NEW.`camsite`,
 UNIX_TIMESTAMP()  FROM DUAL  WHERE
IFNULL(NEW.`camsite`,1) != IFNULL(OLD.`camsite`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'date_modified', OLD.`date_modified`, NEW.`date_modified`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
NEW.`date_modified` != OLD.`date_modified`;

END;

'''

    elif FAV_DB_VERSION in [FAV_DB_VERSION_4]:
        query = '''
\nCREATE TABLE
IF NOT EXISTS
`changes` (
	`rowid`	INTEGER,
	`name`	TEXT,
	`old`	LONGTEXT,
	`new`	LONGTEXT,
	`modified`	INTEGER
	,`id` INTEGER PRIMARY KEY AUTOINCREMENT );

CREATE VIEW
IF NOT EXISTS
`view_changes` AS
select
    `f`.`rowid` AS `rowid`
    ,`f`.`name` AS `name`
    ,`c`.`name` AS `column_name`
    ,`c`.`old` AS `old`
    ,`c`.`new` AS `new`
'''

        if connection.internal_connection_sqlite3:
                query += '''
    ,datetime(c.`modified`, 'unixepoch', 'localtime') AS `modified`
'''

        if connection.internal_connection_mariadb:
                query += '''
    ,from_unixtime(`c`.`modified`) AS `modified`
'''
        query += '''
        ,`c`.`id`
from
    (`changes` `c`
join `favorites` `f` on
    (`f`.`rowid` = `c`.`rowid`))
order by
`id` DESC;

CREATE TRIGGER
IF NOT EXISTS
`trigger_favorites_INSERT_after`
AFTER insert ON `favorites`
FOR EACH ROW
BEGIN
-- select 0;
-- SELECT RAISE(ABORT,'trigger_favorites_INSERT_after');
--
insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'description INSERT', NULL, NEW.`description`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
IFNULL(NEW.`description`,'1') != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'mode', NULL, NEW.`mode`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`mode`,1) != IFNULL(NULL,1);

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid, 'name', NULL, NEW.`name`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`name`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'url', NULL, NEW.`url`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`url`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'image', NULL, NEW.`image`,
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`image`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'binary_image', NULL, NEW.`binary_image`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`binary_image`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'uuid', NULL, NEW.`uuid`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
IFNULL(NEW.`uuid`,1) != IFNULL(NULL,'1');

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'camsite', NULL, NEW.`camsite`,
 UNIX_TIMESTAMP()  FROM DUAL  WHERE
IFNULL(NEW.`camsite`,1) != IFNULL(NULL,'1');

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'is_deleted', NULL, NEW.`is_deleted`,
 UNIX_TIMESTAMP() FROM DUAL where
IFNULL(NEW.`is_deleted`,2) != IFNULL(NULL,2);

insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'date_modified', NULL, NEW.`date_modified`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
IFNULL(NEW.`date_modified`,1) != IFNULL(NULL,1);

END;




CREATE TRIGGER
IF NOT EXISTS
`trigger_favorites_UPDATE_after`
AFTER update ON `favorites`
FOR EACH ROW
BEGIN

Insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'description', OLD.`description`, NEW.`description`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
IFNULL(NEW.`description`,'') != IFNULL(OLD.`description`,'');

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'mode', OLD.`mode`, NEW.`mode`,
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(CAST(NEW.`mode` as int),1) != IFNULL(cast(OLD.`mode` as int),1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'name', OLD.`name`, NEW.`name`,  
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`name`,1) != IFNULL(OLD.`name`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'url', OLD.`url`, NEW.`url`,  
 UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`url`,1) != IFNULL(OLD.`url`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'image', OLD.`image`, NEW.`image`,  
  UNIX_TIMESTAMP() FROM DUAL  where
IFNULL(NEW.`image`,1) != IFNULL(OLD.`image`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'binary_image', OLD.`binary_image`, NEW.`binary_image`,
 UNIX_TIMESTAMP() FROM DUAL  WHERE
IFNULL(NEW.`binary_image`,1) != IFNULL(OLD.`binary_image`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'uuid', OLD.`uuid`, NEW.`uuid`,  
 UNIX_TIMESTAMP() FROM DUAL  WHERE
IFNULL(NEW.`uuid`,1) != IFNULL(OLD.`uuid`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'is_deleted', OLD.`is_deleted`, NEW.`is_deleted`,
 UNIX_TIMESTAMP()  FROM DUAL  WHERE
IFNULL(NEW.`is_deleted`,1) != IFNULL(OLD.`is_deleted`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'camsite', OLD.`camsite`, NEW.`camsite`,
 UNIX_TIMESTAMP()  FROM DUAL  WHERE
IFNULL(NEW.`camsite`,1) != IFNULL(OLD.`camsite`,1);

insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
select new.rowid,'date_modified', OLD.`date_modified`, NEW.`date_modified`,
 UNIX_TIMESTAMP() FROM DUAL WHERE
NEW.`date_modified` != OLD.`date_modified`;

END;

'''

    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    
    return query


#__________________________________________________________________
#
def DB_SCHEMA_STRING(FAV_DB_VERSION, connection):

    if False:
        pass

    elif FAV_DB_VERSION in [FAV_DB_VERSION_5]:

        query = "\nCREATE TABLE IF NOT EXISTS `favorites` ("           
        query += MAIN_TABLE_STRING(FAV_DB_VERSION,connection)
        query += ");\n"

        query += WEBCAM_TABLE_CREATE(FAV_DB_VERSION)

        #indexes below seem to be fastest...so far
        query += DB_SCHEMA_indicies(FAV_DB_VERSION, connection)

        #`favorites_meta`
        query += DB_SCHEMA_query_favorites_meta(FAV_DB_VERSION, connection)

        #`favorites_replication`
        query += DB_SCHEMA_query_favorites_replication(FAV_DB_VERSION, connection)

        #`make sure UUID has a default value`
        query += DB_SCHEMA_query_favorites_uuid_create_trigger(FAV_DB_VERSION, connection)

        # validate favorite info before update
        query += DB_SCHEMA_trigger_duplicate_detection(FAV_DB_VERSION, connection)

        # optional change tracking
        query += DB_SCHEMA_optional_change_tracking(FAV_DB_VERSION, connection)

        query += (
            "\nUPDATE favorites_meta set user_version = {};".format(FAV_DB_VERSION)
            )

    
    elif FAV_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:

        query = ""


        query = (
##            "\nBEGIN TRANSACTION;"
            "\nCREATE TABLE IF NOT EXISTS `favorites` ("
            )
        query += MAIN_TABLE_STRING(FAV_DB_VERSION,connection)
        query += (
            ");\n"
##            " COMMIT;"
            )

##        return Convert_SQLITE3_MARIADB(query,connection)

##        query += (
##            " DROP TRIGGER if exists AutoGenerateGUID	; "
##            " CREATE TRIGGER AutoGenerateGUID "
##            " AFTER INSERT ON favorites "
##            " FOR EACH ROW "
##            " WHEN (NEW.uuid IS NULL) "
##            " BEGIN "
##            "    UPDATE favorites SET uuid = ("
##            )
##        query += CREATE_UUID_STRING
##        query += (
##            ") WHERE rowid = NEW.rowid; "
##            " END; "



##        query += (
##                "\n CREATE TABLE IF NOT EXISTS `camlist` (`serverNumber` TEXT, `modelID` TEXT, `hq_stream` TEXT, `date` TEXT, `video_url` TEXT, `mode` INTEGER DEFAULT NULL, `icon_image` TEXT, `camscore` REAL, `play_method` TEXT, `description` TEXT, `update_date` DATETIME DEFAULT CURRENT_TIMESTAMP); \n"
##            )
        query += WEBCAM_TABLE_CREATE(FAV_DB_VERSION)




##        ## indexes below seem to be fastest...so far
##        query += (
##            "\nCREATE INDEX if not exists `index_favorites_modified-rowid` ON `favorites` ( "
##            " 	`date_modified`	ASC "
##            " 	,`rowid`	ASC "
##            " ); "
##
##            "\nCREATE INDEX IF NOT EXISTS `index_favorites_modified-isdeleted` ON `favorites` (  "
##            "  	`date_modified`	DESC  "
##            "   , `is_deleted`	ASC   "
##            " ); "
##
##            "\nCREATE INDEX if not exists `index_favorites_uuid` ON `favorites` ( "
##            "	`uuid`	ASC "
##            " ); "
##
##            "\nCREATE INDEX if not exists `index_favorites_url` ON `favorites` ( "
##            "	`url`	ASC "
##            " ); "
##
##            "\nCREATE INDEX if not exists `index_favorites_name` ON `favorites` ( "
##            "	`name`	ASC "
##            " ); "
##
##            "\nCREATE INDEX if not exists `index_favorites_camsite-isdeleted` ON `favorites` ( "
##            " 	`camsite`	ASC, "
##            " 	`is_deleted`	ASC "
##            " ); "
##
####            #not available for mysql
####            ' PRAGMA optimize; ' #supposed to do this after creating an inex
####            #not available for mysql in the same way
####            ' ANALYZE; '
##
##            )
        #
        #indexes below seem to be fastest...so far
        #
        query += DB_SCHEMA_indicies(FAV_DB_VERSION, connection)

        
        #
        #`favorites_meta`
        #
##        query_favorites_meta = (
##            "\nCREATE TABLE IF NOT EXISTS `favorites_meta` (`uuid` TEXT, `user_version` INT ); "
##            "\ninsert into `favorites_meta` (`uuid`, `user_version`) "
##            )
####        if 'MySQL' in str(type(connection)):
##        if connection.internal_connection_mariadb:
##            query_favorites_meta += ( " SELECT " ) #mariADB
##        query_favorites_meta += (
##            CREATE_UUID_STRING(connection)
##            )
##        query_favorites_meta += ( ',0') #default user_version
####        if IsMYSQL(connection):
##        if connection.internal_connection_mariadb:
##            query_favorites_meta += ( " FROM DUAL " ) #mariadb  only - DUAL is a special 'stub' table because WHERE syntax needs it
##
##        query_favorites_meta += (
##            " WHERE NOT EXISTS  (SELECT 1 FROM `favorites_meta` WHERE `UUID` LIKE '%'  )"
##            ";"
##            )
##        #append query_favorites_meta query to main query
##        query += query_favorites_meta
        query += DB_SCHEMA_query_favorites_meta(FAV_DB_VERSION, connection)


##        #
##        #`favorites_replication`
##        #
##        query += (
##            " CREATE TABLE IF NOT EXISTS `favorites_replication` (  "
##            "   `rowid`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT "
##            " , `remote_db_uuid` TEXT "
##            " , `local_db_repl_id_highwater` INT DEFAULT 0 "
##            " , `local_db_date_modified_highwater` REAL DEFAULT 0 "
##            " , `full_repl` INT DEFAULT 0 "
##            " , `id_range_start` INT DEFAULT 0 "
##            " , `id_range_end` INT DEFAULT 0  "
##            " , `date_modified` REAL DEFAULT 0  "
##            " ); "
##        )
        #
        #`favorites_replication`
        #
        query += DB_SCHEMA_query_favorites_replication(FAV_DB_VERSION, connection)


##        #
##        #`make sure UUID has a default value`
##        #
##        if connection.internal_connection_mariadb:
##            query += (
##                #" \nDELIMITER // \n" #a reminder that needed only in gui
##                " CREATE TRIGGER if not exists `trigger_favorites_INSERT_UUID` "
##                " BEFORE INSERT "
##                " ON "
##                " `favorites` "
##                " FOR EACH ROW "
##                " BEGIN "
##                "   IF (IFNULL(NEW.`uuid`, '') = '') THEN "
##                "       set NEW.`uuid` = UUID() ; "
##                "   END IF ; "
##                " END ; "
####                " // \nDELIMITER ; \n" #a reminder that needed only in gui
##            )
####        return Convert_SQLITE3_MARIADB(query,connection)
        #
        #`make sure UUID has a default value`
        #
        query += DB_SCHEMA_query_favorites_uuid_create_trigger(FAV_DB_VERSION, connection)
        
##        if connection.internal_connection_mariadb:       
##            temp = '''
##                IF ((
##                        SELECT `DATA_TYPE` FROM INFORMATION_SCHEMA.COLUMNS
##                        WHERE 
##                        `TABLE_SCHEMA` = 'kodi_favorites'
##                        AND `TABLE_NAME` = 'camlist' 
##                        AND `COLUMN_NAME` = 'UPDATE_DATE'
##                        ) != 'double'
##                        )
##                THEN 
##                        delete from `camlist`;  
##                        alter table `kodi_favorites`.`camlist` modify `update_date` double NOT NULL DEFAULT UNIX_TIMESTAMP() ;
##                        #ALTER TABLE `kodi_favorites`.`camlist` modify `update_date` DATETIME NOT NULL DEFAULT current_timestamp();
##                END IF; 
##            '''
##            temp.replace('kodi_favorites', connection.db_filespec)
##            query += temp
            
        #
        # validate favorite info before update
        #
        query += DB_SCHEMA_trigger_duplicate_detection(FAV_DB_VERSION, connection)
        
##        query += (
##            " CREATE TRIGGER if not exists `trigger_favorites_UPDATE_before` "
##            " BEFORE update ON `favorites` "
##            " FOR EACH ROW "
##            " BEGIN  "
##        )
##
##        if connection.internal_connection_mariadb:
##            query += (
##                " IF IFNULL(NEW.name, '') LIKE '' THEN "
##                "    SIGNAL SQLSTATE '45000' "
##                "     SET MESSAGE_TEXT= 'new name may not be blank' ; "
##                " END IF ; "
##            )
##        else:
##            query += (
##                " 	SELECT "
##                " 	    RAISE(FAIL, 'new name may not be blank') "
##                " 	WHERE "
##                " 	    IFNULL(NEW.\"name\",'') == ''; "
##            )
##        if connection.internal_connection_mariadb:
##            query += (
##            " IF ( "
##            "                               CAST(NEW.`mode` AS INT)  = CAST(OLD.`mode` AS INT) "
##            "       AND                                  NEW.`name`  = OLD.`name` "
##            "       AND                                   NEW.`url`  = OLD.`url` "
##            "       AND                                 NEW.`image`  = OLD.`image` "
##            "       AND                IFNULL(NEW.`description`,'')  = IFNULL(OLD.`description`,'') "
##            "       AND               IFNULL(NEW.`binary_image`,'')  = IFNULL(OLD.`binary_image`,'') "
##            "       AND                                  NEW.`uuid`  = OLD.`uuid` "
##            "       AND               CAST(NEW.`is_deleted` AS INT)  = CAST(OLD.`is_deleted` AS INT) "
##            "       AND        CAST(ifnull(NEW.`camsite`,-1) AS INT) = CAST(ifnull(OLD.`camsite`,-1) AS INT) "
##            "       AND CAST(ifnull(NEW.`date_modified`,-1) AS INT)  = CAST(ifnull(OLD.`date_modified`,-1) AS INT) "
##            "       ) "
##            #
##            " THEN       "
##                "    SIGNAL SQLSTATE '45000' "
##                "     SET MESSAGE_TEXT= 'duplicate information' ; "
##                " END IF ; "
##            " IF CAST(ifnull(NEW.`date_modified`,-1) AS INT)  <  CAST(ifnull(OLD.`date_modified`,-1) AS INT) THEN"
##                "    SIGNAL SQLSTATE '45000' "
##                "     SET MESSAGE_TEXT= 'invalid date_modified' ; "
##                " END IF ; "
##            " END ; "
##            )
##
##        if connection.internal_connection_sqlite3:
##            #sqlite3 does not use IF ENDIF
##            query += (
##            " 	SELECT  "
##            " 		RAISE(ABORT, 'duplicate information') "
##            " 	WHERE EXISTS ( "
##            "       SELECT 1 "
##            "       WHERE ( "
##            '                               CAST(NEW."mode" AS INT) == CAST(OLD."mode" AS INT) '
##            '       AND                                  NEW."name" == OLD."name" '
##            '       AND                                   NEW."url" == OLD."url" '
##            '       AND                                 NEW."image" == OLD."image" '
##            '       AND              IFNULL(NEW."description",\'\') == IFNULL(OLD."description",\'\') \n'
##            '       AND             IFNULL(NEW."binary_image",\'\') == IFNULL(OLD."binary_image",\'\') \n'
##            '       AND                                  NEW."uuid" == OLD."uuid" '
##            '       AND               CAST(NEW."is_deleted" AS INT) == CAST(OLD."is_deleted" AS INT) '
##            '       AND        CAST(ifnull(NEW."camsite",0) AS INT) == CAST(ifnull(OLD."camsite",0) AS INT) '
##            '       AND  CAST(ifnull(NEW."date_modified",-1) AS INT) == CAST(ifnull(OLD."date_modified",-1) AS INT) '
##             '       ) \n'
##            '       OR    CAST(ifnull(NEW.date_modified,-1) AS INT)  <  CAST(ifnull(OLD.date_modified,-1) AS INT) '
##            "       ); "
##            )
##
##            query += (
##             "  UPDATE favorites "
##            "   SET date_modified = CAST(strftime('%s') as INT) /*tested to be UTC */ "
##            "   WHERE "
##            "       NEW.date_modified=date_modified "
##            "       AND "
##            "       rowid = NEW.rowid "
##            "   ;    "
##            "END; "
##            )

####
####        optional views and triggers to keep track of changes
####
##        query += '''
##\nCREATE TABLE
##IF NOT EXISTS
##`changes` (
##	`rowid`	INTEGER,
##	`name`	TEXT,
##	`old`	LONGTEXT,
##	`new`	LONGTEXT,
##	`modified`	INTEGER
##	,`id` INTEGER PRIMARY KEY AUTOINCREMENT );
##
##CREATE VIEW
##IF NOT EXISTS
##`view_changes` AS
##select
##    `f`.`rowid` AS `rowid`
##    ,`f`.`name` AS `name`
##    ,`c`.`name` AS `column_name`
##    ,`c`.`old` AS `old`
##    ,`c`.`new` AS `new`
##'''
##        if connection.internal_connection_sqlite3:
##                query += '''
##    ,datetime(c.`modified`, 'unixepoch', 'localtime') AS `modified`
##'''
##        if connection.internal_connection_mariadb:
##                query += '''
##    ,from_unixtime(`c`.`modified`) AS `modified`
##'''
##        query += '''
##        ,`c`.`id`
##from
##    (`changes` `c`
##join `favorites` `f` on
##    (`f`.`rowid` = `c`.`rowid`))
##order by
##`id` DESC;
##
##CREATE TRIGGER
##IF NOT EXISTS
##`trigger_favorites_INSERT_after`
##AFTER insert ON `favorites`
##FOR EACH ROW
##BEGIN
##-- select 0;
##-- SELECT RAISE(ABORT,'trigger_favorites_INSERT_after');
##--
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'description INSERT', NULL, NEW.`description`,
## UNIX_TIMESTAMP() FROM DUAL WHERE
##IFNULL(NEW.`description`,'1') != IFNULL(NULL,'1');
##
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'mode', NULL, NEW.`mode`,
## UNIX_TIMESTAMP() FROM DUAL where
##IFNULL(NEW.`mode`,1) != IFNULL(NULL,1);
##
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'name', NULL, NEW.`name`,
## UNIX_TIMESTAMP() FROM DUAL where
##IFNULL(NEW.`name`,1) != IFNULL(NULL,'1');
##
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'url', NULL, NEW.`url`,
## UNIX_TIMESTAMP() FROM DUAL where
##IFNULL(NEW.`url`,1) != IFNULL(NULL,'1');
##
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'image', NULL, NEW.`image`,
## UNIX_TIMESTAMP() FROM DUAL  where
##IFNULL(NEW.`image`,1) != IFNULL(NULL,'1');
##
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'binary_image', NULL, NEW.`binary_image`,
## UNIX_TIMESTAMP() FROM DUAL where
##IFNULL(NEW.`binary_image`,1) != IFNULL(NULL,'1');
##
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'uuid', NULL, NEW.`uuid`,
## UNIX_TIMESTAMP() FROM DUAL WHERE
##IFNULL(NEW.`uuid`,1) != IFNULL(NULL,'1');
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'camsite', NULL, NEW.`camsite`,
## UNIX_TIMESTAMP()  FROM DUAL  WHERE
##IFNULL(NEW.`camsite`,1) != IFNULL(NULL,'1');
##
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'is_deleted', NULL, NEW.`is_deleted`,
## UNIX_TIMESTAMP() FROM DUAL where
##IFNULL(NEW.`is_deleted`,2) != IFNULL(NULL,2);
##
##insert into `changes` (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'date_modified', NULL, NEW.`date_modified`,
## UNIX_TIMESTAMP() FROM DUAL WHERE
##IFNULL(NEW.`date_modified`,1) != IFNULL(NULL,1);
##
##END;
##
##
##
##
##CREATE TRIGGER
##IF NOT EXISTS
##`trigger_favorites_UPDATE_after`
##AFTER update ON `favorites`
##FOR EACH ROW
##BEGIN
##
##Insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'description', OLD.`description`, NEW.`description`,
## UNIX_TIMESTAMP() FROM DUAL WHERE
##IFNULL(NEW.`description`,'') != IFNULL(OLD.`description`,'');
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'mode', OLD.`mode`, NEW.`mode`,
## UNIX_TIMESTAMP() FROM DUAL  where
##IFNULL(CAST(NEW.`mode` as int),1) != IFNULL(cast(OLD.`mode` as int),1);
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'name', OLD.`name`, NEW.`name`,  
## UNIX_TIMESTAMP() FROM DUAL  where
##IFNULL(NEW.`name`,1) != IFNULL(OLD.`name`,1);
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'url', OLD.`url`, NEW.`url`,  
## UNIX_TIMESTAMP() FROM DUAL  where
##IFNULL(NEW.`url`,1) != IFNULL(OLD.`url`,1);
##
##
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'image', OLD.`image`, NEW.`image`,  
##  UNIX_TIMESTAMP() FROM DUAL  where
##IFNULL(NEW.`image`,1) != IFNULL(OLD.`image`,1);
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'binary_image', OLD.`binary_image`, NEW.`binary_image`,
## UNIX_TIMESTAMP() FROM DUAL  WHERE
##IFNULL(NEW.`binary_image`,1) != IFNULL(OLD.`binary_image`,1);
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'uuid', OLD.`uuid`, NEW.`uuid`,  
## UNIX_TIMESTAMP() FROM DUAL  WHERE
##IFNULL(NEW.`uuid`,1) != IFNULL(OLD.`uuid`,1);
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'is_deleted', OLD.`is_deleted`, NEW.`is_deleted`,
## UNIX_TIMESTAMP()  FROM DUAL  WHERE
##IFNULL(NEW.`is_deleted`,1) != IFNULL(OLD.`is_deleted`,1);
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'camsite', OLD.`camsite`, NEW.`camsite`,
## UNIX_TIMESTAMP()  FROM DUAL  WHERE
##IFNULL(NEW.`camsite`,1) != IFNULL(OLD.`camsite`,1);
##
##insert into changes (`rowid`,`name`, `old`, `new` , `modified`)
##select new.rowid,'date_modified', OLD.`date_modified`, NEW.`date_modified`,
## UNIX_TIMESTAMP() FROM DUAL WHERE
##NEW.`date_modified` != OLD.`date_modified`;
##
##END;
##
##'''

        # optional change tracking
        query += DB_SCHEMA_optional_change_tracking(FAV_DB_VERSION, connection)
        
        query += (
            "\nUPDATE favorites_meta set user_version = {};".format(FAV_DB_VERSION)
            )
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

    #return Convert_SQLITE3_MARIADB(query,connection)
    return query

#__________________________________________________________________
#
def UPGRADE_DB_STRING(NEW_FAV_DB_VERSION, OLD_FAV_DB_VERSION, connection):

    query = "" #default value'

    if False:
        pass #stub

    elif NEW_FAV_DB_VERSION in [FAV_DB_VERSION_5]:
        if not (OLD_FAV_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]):
            Log("{} for old '{}' to new v{} not yet implemented".format(
                        C.module_name()
                        , OLD_FAV_DB_VERSION
                        , repr(NEW_FAV_DB_VERSION)
                       )
                ,C.LOGWARNING
                )
            return query


        query = ""
        
        # force new camlist schema
        # don't need old data; 
        query += (
            " DROP TABLE IF EXISTS camlist;\n " 
            )

        # create new fav table schema
        query += (
            "DROP TABLE IF EXISTS favorites_bak;"
            "DROP TABLE IF EXISTS favorites_new;"
            "DROP VIEW IF EXISTS view_changes; " # conflits...will be recreated
            "DROP TRIGGER IF EXISTS trigger_favorites_UPDATE_after; " # conflits...will be recreated
            "DROP TRIGGER IF EXISTS trigger_favorites_UPDATE_before; " # conflits...will be recreated
            "CREATE TABLE favorites_new ("
            )
        query += MAIN_TABLE_STRING(NEW_FAV_DB_VERSION,connection)
        query += (
            ");"
            )
        # import old fav table data into new one
        #   for this schema migration modelID is changed to be same as name
        #       unless mode is 272 [mfc]
        query += (
            "INSERT INTO favorites_new (name, modelID, url, mode, image, description, camsite, binary_image, uuid, date_modified, is_deleted) "
#            "                    SELECT `name`, CASE WHEN `mode`=272 THEN "" ELSE `name` END as `modelID`  , url, mode, image, description, ifnull(camsite,0), binary_image, uuid, date_modified, is_deleted  FROM favorites;"
'''
select
	`name`
        , ifnull(`model_ID_table`.`modelID`, `name`) as `modelID`
	,`url`
	,`mode`
	,`image`
	,`description`
	, ifnull(`camsite`, 0) as `camsite`
	, binary_image
,
	`favorites`.`uuid`,
	`date_modified`,
	`is_deleted`
FROM
	`favorites`
left join
(
	select
		`uuid`
,
		(case
			when instr(`modelID3`, "|") then substr(`modelID3`, 1, instr(`modelID3`, "|") - length("|"))
			else `modelID3`
		end) as `modelID`
	from
		(
		select
			`name` ,
			`image`,
			`uuid`
,
			(case
				when instr(`modelID2`, '?') then substr(`modelID2`, 1, instr(`modelID2`, '?') - length('?'))
				else `modelID2`
			end) as `modelID3`
		from
			(
			select
				`name` ,
				`image`,
				`uuid` 
,
				case
					when instr(`image`, "mfc_a_1") then substr(`image`, length('mfc_a_1')+ instr(`image`, 'mfc_a_1'))
					when instr(`image`, 'mfc_1') then substr(`image`, length('mfc_1')+ instr(`image`, 'mfc_1'))
					when instr(`image`, '/avatar') then substr(replace(`image`, substr(`image`, instr(`image`, '/avatar')), ''), -8)
					else `name`
				end as `modelID2`
			from
				`favorites`

) as `t0`
) as `t1`
) as `model_ID_table`
on
	`model_ID_table`.`uuid` = `favorites`.`uuid` 

	;

'''
        )
        # rename tables as needed
        query += (
            " CREATE TABLE if not exists `favorites` ( `in case ths is run on a new DB` varchar(25) ) ; " 
            " ALTER TABLE favorites     RENAME TO favorites_bak; "
            " ALTER TABLE favorites_new RENAME TO favorites; "
            )
        
    elif NEW_FAV_DB_VERSION in [FAV_DB_VERSION_4]:
        if not (OLD_FAV_DB_VERSION == FAV_DB_VERSION_3):
            Log("{} for version {} not yet implemented".format(
                C.module_name(), repr(NEW_FAV_DB_VERSION))
                ,C.LOGWARNING
                )
            return query

        query = ""
        query += (
            "\n DROP TABLE IF EXISTS `favorites_meta_bak`;"
            "   DROP TABLE IF EXISTS `favorites_meta_new`; "
            "\n CREATE TABLE IF NOT EXISTS `favorites_meta` (`uuid` TEXT, `user_version` INT ); "
            "\n CREATE TABLE IF NOT EXISTS `favorites_meta_new` (`uuid` TEXT, `user_version` INT ); "
            "\n INSERT INTO  `favorites_meta_new` (`uuid`, `user_version`)"
            )
        query += (
            " SELECT `uuid`, {} from `favorites_meta`;".format(
                NEW_FAV_DB_VERSION
                )
            )
        query += (
            "\nALTER TABLE `favorites_meta`     RENAME TO `favorites_meta_bak`;"
            "\nALTER TABLE `favorites_meta_new` RENAME TO `favorites_meta`;"
        )


#>>> con = sqlite3.connect(r"C:\Users\poq\AppData\Roaming\Kodi\userdata\addon_data\plugin.video.uwc\favorites.db")
#>>> con.execute("select `name`, `type` from pragma_table_info('camlist') where `name` = 'update_date'").fetchall()[0][1]


    elif NEW_FAV_DB_VERSION == FAV_DB_VERSION_3:

        query = ""

        query += (
            "DROP TABLE IF EXISTS favorites_bak;"
            "DROP TABLE IF EXISTS favorites_new;"
            "CREATE TABLE favorites_new ("
            )
        query += MAIN_TABLE_STRING(NEW_FAV_DB_VERSION, connection)

        query += (
            ");"
            )

        if OLD_FAV_DB_VERSION < FAV_DB_VERSION_3:
            #remove this constraints so that AutoGenerateGUID can work
            # sqlite can only re-add a constraint by completly
            #    re-importing the data to a new table
            query = query.replace(
                " , uuid	     TEXT NOT NULL unique "
               ," , uuid	     TEXT          unique "
                )


        #
        # use AutoGenerateGUID  only during data import
        #
        query += (
            " DROP TRIGGER if exists  AutoGenerateGUID ; "
            " CREATE TRIGGER AutoGenerateGUID "
            " AFTER INSERT ON favorites_new "
            " FOR EACH ROW "
            " WHEN (NEW.uuid IS NULL) "
            " BEGIN "
            "    UPDATE favorites_new "
            "        SET uuid = ( "
            )
        query += CREATE_UUID_STRING(connection)
        query += (
            "                   ) "
            "                "
            "    WHERE rowid = NEW.rowid; "
            " END ;"
        )


        #actual import happens here
        if OLD_FAV_DB_VERSION == FAV_DB_VERSION_3:
            query += (
                "INSERT INTO favorites_new (name, url, mode, image, description, camsite, binary_image, uuid, date_modified, is_deleted) "
                "                    SELECT name, url, mode, image, description, ifnull(camsite,0), binary_image, uuid, date_modified, is_deleted  FROM favorites;"
            )
        elif OLD_FAV_DB_VERSION == FAV_DB_VERSION_2: #import available v2 data into a v3 table
            Log('here')
            query += (
                "INSERT INTO favorites_new (name, url, mode, image, description, camsite, binary_image, date_modified    ) "
                "                    SELECT name, url, mode, image, description, ifnull(camsite,0) , binary_image, {}                FROM favorites ; ".format(UTC_timestamp())
            )
            ##
            ##note: a date_modified value is inserted here using format()  !!!
            ##
        elif OLD_FAV_DB_VERSION == 0:
            Log("database does not exist; nothing to import", C.LOGWARNING)
        else:
            raise NotImplementedError(__name__,NEW_FAV_DB_VERSION, OLD_FAV_DB_VERSION)

        if OLD_FAV_DB_VERSION < FAV_DB_VERSION_3:
            #temporarily remove this constraints so that AutoGenerateGUID can work
            query += (
                " PRAGMA ignore_check_constraints=off; "
                )

        query += (
            ' CREATE TABLE if not exists favorites ( name ) ; ' #in case ths is run on a new DB
            " ALTER TABLE favorites     RENAME TO favorites_bak;"
            " ALTER TABLE favorites_new RENAME TO favorites;"
            " DROP TRIGGER if exists  AutoGenerateGUID ; "
            )

        #
        # use AutoGenerateGUID only during data import
        #
##        query += (
##            " CREATE TRIGGER AutoGenerateGUID "
##            " AFTER INSERT ON favorites "
##            " FOR EACH ROW "
##            " WHEN (NEW.uuid IS NULL) "
##            " BEGIN "
##            "    UPDATE favorites SET uuid = ( "
##            )
##        query += CREATE_UUID_STRING
##        query += (
##            ") WHERE rowid = NEW.rowid; "
##            " END ;"
##            )


        query += (
##            ' DROP INDEX if exists "index_favorites_modified"  ;'
##            ' CREATE INDEX "index_favorites_modified" ON "favorites" ('
##            '	"date_modified"	ASC '
##            '); '

            ' DROP INDEX if exists "index_favorites_camsite-isdeleted"  ;'
            ' CREATE INDEX "index_favorites_camsite-isdeleted" ON "favorites" ( '
            ' 	"camsite"	ASC,  '
            ' 	"is_deleted"	ASC '
            ' ); '

            ' DROP INDEX if exists "index_favorites_uuid"  ;'
            ' CREATE INDEX "index_favorites_uuid" ON "favorites" ( '
            '	"uuid"	ASC '
            ' ); '
            )

        query += (
            "PRAGMA user_version = {};".format(NEW_FAV_DB_VERSION)
                ##
                ##note: a value is inserted here using format()  !!!
                ##
            )

    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

    return query

#__________________________________________________________________
#
def LIST_KEYWORD(KEYWORD_DB_VERSION):
    if False:
        pass #stub
    elif KEYWORD_DB_VERSION in [FAV_DB_VERSION_5, FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
##    elif KEYWORD_DB_VERSION in [-1]:
        query = (
            " SELECT "
            "  `keyword` "
            "  , `uuid` "
            " FROM "
            "  `keywords` "
            " WHERE "
            "  `IS_DELETED` = 0 "
            " ORDER BY "
            "  `sequence` ;"
            )
    else:
        raise NotImplementedError(C.module_name(),KEYWORD_DB_VERSION)
    return query
###__________________________________________________________________
###
##def INSERT_KEYWORD(KEYWORD_DB_VERSION):
##    if False:
##        pass #stub
##    elif KEYWORD_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
####        n = C.sys._getframe(0).f_code.co_name
####        Log("{} for version {} not yet implemented".format(
####                n, FAV_DB_VERSION
####                )
####            ,C.LOGWARNING
####            )
##        query = (
##             " INSERT INTO keywords ( "
##             " keyword "           #1
##             " , sequence "        #2
##             " , date_modified  "  #3
##             " , uuid  "           #4
##             " ) "
##             " VALUES (?,?"
##             " , CAST(strftime('%s') as INT) "
##             " ,?) ; "
##            )
##    else:
##        raise NotImplementedError(C.module_name(),KEYWORD_DB_VERSION)
##    return query
#__________________________________________________________________
#
def DELETE_KEYWORD(KEYWORD_DB_VERSION):
    if False:
        pass #stub
    elif KEYWORD_DB_VERSION in [FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
##        n = C.sys._getframe(0).f_code.co_name
##        Log("{} for version {} not yet implemented".format(
##                n, FAV_DB_VERSION
##                )
##            ,C.LOGWARNING
##            )

        query = (
             " DELETE FROM keywords  "
             " WHERE "
             " keyword LIKE ? "
            )
    else:
        raise NotImplementedError(C.module_name(),KEYWORD_DB_VERSION)
    return query
#__________________________________________________________________
#
def KEYWORD_SCHEMA_STRING(KEYWORD_DB_VERSION, OLD_DB_VERSION):
    if KEYWORD_DB_VERSION in [KEYWORD_DB_VERSION_5, KEYWORD_DB_VERSION_3]:
        query = ""

        query += (
##            "DROP TABLE IF EXISTS keywords_bak;"
##            "DROP TABLE IF EXISTS keywords_new;"
##            "CREATE TABLE keywords_new ("
            " CREATE TABLE if not exists keywords ("
            )
        query += (
            "   keyword                   TEXT UNIQUE "
            " , sequence            INTEGER DEFAULT 0 " #enable sorting keywords
            " , uuid	                  TEXT UNIQUE "
            " , date_modified	       REAL DEFAULT 0 "
            " , is_deleted INTEGER NOT NULL DEFAULT 0 "
            )
        query += (
            " ); "
            )

##        query += (
##            ' CREATE TABLE if not exists keywords ( placeholder ) ; ' #in case ths is run on a new DB
##            " ALTER TABLE keywords     RENAME TO keywords_bak;"
##            " ALTER TABLE keywords_new RENAME TO keywords;"
##            )

##        query += (
##            "PRAGMA user_version = {};".format(KEYWORD_DB_VERSION)
##                ##
##                ##note: a value is inserted here using format()  !!!
##                ##
##            )

    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

    return query

#__________________________________________________________________
#
def WEBCAM_TABLE_CREATE(FAV_DB_VERSION=FAV_DB_VERSION_CURRENT):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5, FAV_DB_VERSION_4]:
        query = "\n"
        query += '''
            CREATE TABLE IF NOT EXISTS `camlist` (
            `serverNumber` TEXT
            , `modelID` TEXT
            , `modelDisplayName` TEXT
            , `hq_stream` TEXT
            , `date` TEXT
            , `video_url` TEXT
            , `mode` INTEGER DEFAULT NULL
            , `icon_image` TEXT
            , `camscore` REAL
            , `play_method` TEXT
            , `description` TEXT
            , `update_date` REAL NOT NULL DEFAULT ( CAST(strftime('%s') as INT) )

            );
            '''
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

    return query
#__________________________________________________________________
#
def WEBCAM_TABLE_CLEAR_OLD(FAV_DB_VERSION=FAV_DB_VERSION_CURRENT):
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5, FAV_DB_VERSION_4]:
        query = "\n"
        query += '''
DELETE FROM
    `camlist`
WHERE
    ( COALESCE(`update_date`,0) < ( CAST(strftime('%s') as INT) - ?*60) )
    OR
            (CAST(`update_date` AS double) != `update_date`)
        '''
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)

    return query

#__________________________________________________________________
#
def FAV_FIND_IMAGE(FAV_DB_VERSION, image, connection):
    if not image: raise Exception()
    if False:
        pass #stub
    elif FAV_DB_VERSION in [FAV_DB_VERSION_5,FAV_DB_VERSION_4,FAV_DB_VERSION_3]:
        query = \
            '''
            SELECT `rowid` 
            FROM `favorites`
            WHERE `image` LIKE ?
            '''
        params = (image,)
    else:
        raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    return (query,params)
#__________________________________________________________________
#



