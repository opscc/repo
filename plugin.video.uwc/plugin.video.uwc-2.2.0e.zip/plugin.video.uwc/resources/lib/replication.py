#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


##import base64
##import datetime
import errno as ERROR_NUMERS#used for catching exceptions during file copy
##from collections import OrderedDict
import mysql.connector as mariadb #used for catching exceptions

import os #for file/folder selection box
##import random
##import re
##import tempfile
import sqlite3 #used for catching exceptions
import shutil  #copying debug files on failure
##import string
##import sys
##import time
import traceback
from uuid import uuid4
##import xbmc
import xbmcgui #for file/folder selection box
##import xbmcplugin
import xbmcvfs

from fav_dbconn import generic_favdbconn
from fav_schema import Create_Maintain_FavDB
from fav_textures import Insert_Binary_Image

##import fav_schema


import constants as C
##from constants import urlencode
##from constants import urlparse



import queries as Q

import utils
from utils import Log,LogR
from utils import get_setting as GetSetting


##C.DEBUG = True

today = utils.UTC_timestamp()

MAX_DAYS_WITHOUT_SYNC = 7

BACKUP_COPIES = GetSetting("sqlite_backup_copies", int)
DAYS_BETWEEN_BACKUPS = GetSetting("sqlite_backup_dategap", int)

MIN_TOMBSTONE_DAYS = 30
MAX_ROWS = 400 # this is to performance test and value can be larger
##REPLICATION_PROGRESS_CALLBACKS = 2000 #queries will seem slow if this is too high
FULL_REPL_SUCCESS = 1
REPL_ID_HIGHWATER_INIT = 1
REPLICATION_NOTIFY_DURATION = 10000

mfc_PLAY_MODE = str(int(C.MAIN_MODE_myfreecams) + C.MODE_PLAY_OFFSET)

##FAV_DB_VERSION_1 = Q.FAV_DB_VERSION_1
##FAV_DB_VERSION_2 = Q.FAV_DB_VERSION_2
##FAV_DB_VERSION_3 = Q.FAV_DB_VERSION_3
##FAV_DB_VERSION_4 = Q.FAV_DB_VERSION_4
FAV_DB_VERSION_CURRENT = Q.FAV_DB_VERSION_CURRENT

favoritesdb = C.favoritesdb
                
#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_IMPORT)
def Favorites_Import():

    try:
        favorite_db_filepec = None
##       favorite_db_filepec = "\\\\raid.opscc.net\\web\\tv\\favorites.db"; Log("warning: hardcode")
##        Log("warning: hardcode"); favorite_db_filepec = "c:\\temp\\ff.db"

        #https://romanvm.github.io/Kodistubs/_autosummary/xbmcgui.html#xbmcgui.Dialog
        if not favorite_db_filepec:
            favorite_db_filepec = xbmcgui.Dialog().browse(
                type=1 #show and get file
                , heading = "Specify a location import"
                , shares = '' #list drives and network shares
                , mask = 'favorites.db'
                )
            favorite_db_filepec = utils.Normalize_Filespec(favorite_db_filepec)
        LogR(favorite_db_filepec)

        source_db_conn = generic_favdbconn(favorite_db_filepec)
        Create_Maintain_FavDB(source_db_conn) #do this in case schema changed
        source_cursor = source_db_conn.cursor()

        target_db_conn = generic_favdbconn(C.favoritesdb)
        Create_Maintain_FavDB(target_db_conn) #do this in case schema changed
        target_cursor = target_db_conn

        Log("Warning: importing remote [{}] to local [{}]".format(
                source_db_conn.db_filespec
                ,target_db_conn.db_filespec
                )
            )
        r_to_l = SyncDB(
            source_db_conn
            ,target_db_conn
            ,import_only=True
            ,save_repl_vector=False
        )
        utils.Notify(
            msg=u"{} favorites imported to local db".format(
                r_to_l
                )
            , duration=REPLICATION_NOTIFY_DURATION
            )

        optional_backup = xbmcgui.Dialog().ok(
                heading = u"Favorites Sync"
                , message= u"[CR]{} remote -> local changes".format(r_to_l)
                )

    except:
        traceback.print_exc()
        utils.Notify(
            header= __name__ 
            , msg=u"Favorites replication error occured.[CR]Check logs for more information"
            , duration=REPLICATION_NOTIFY_DURATION
            )
        
#    xbmc.executebuiltin('Container.Refresh') #should I refresh automatically?

#__________________________________________________________________
#
@C.url_dispatcher.register(C.COPY_KODI_LOG,[],['url'])
def Copy_KODI_Log(url=None):

    LogR((
        C.module_name()
        , str(traceback.extract_stack(limit=2)[0][0])+":"+str(traceback.extract_stack(limit=2)[0][1])
        , locals()
        ))
    
    def cccopy(source_log_filepec,target_log_filepec):

        source_log_filepec = utils.Normalize_Filespec(source_log_filepec)
        name = source_log_filepec.split(os.sep)[-1]
        source_folder = source_log_filepec[0: (len(source_log_filepec)-len(name)) ]
        source_folder = source_folder.rstrip(os.sep)
        ext = name.split('.')[-1]
        name = name[0: (len(name)-len(ext)-len('.')) ]

        backup_number = 1
        newer_filespec = '.'.join ((
            (os.sep).join( (target_log_filepec,name ))
            , str(backup_number)
            , '.txt'
            ))
        older_filespec = source_log_filepec

        LogR(newer_filespec)
        LogR(older_filespec)

        Log('-'*2048+'\n\n', C.LOGNONE)


        try:
            shutil.copyfile(older_filespec, newer_filespec)

        except OSError as e: #oserror instead of FileExistsError for PY2 compat
       
            errnum = e.errno
            LogR(errnum)
            
            if False:
                pass
            elif errnum in [ERROR_NUMERS.EEXIST, 183]:  #FileExistsError:

                msg = ("deleted {}".format(
                    repr(newer_filespec)
                    ))
                Log(msg)
                os.remove(newer_filespec) ##delete target
                
                msg = ("renamed {} to {}".format(
                    repr(older_filespec)
                    ,repr(newer_filespec)
                    ))
                pd.update(percent = int(backup_number),message = msg)
                os.rename(older_filespec,newer_filespec)
            else:
                raise
        except:
            raise
        
    try:
        target_log_filepec = url
        if os.name == 'nt':
            source_log_filepec = C.translatePath("special://home/kodi.log")
            source_log_filepec2 = C.translatePath("special://home/plugin.video.uwc.log")
##            target_log_filepec = 'C:\\Temp\\'
        else:
            source_log_filepec = C.translatePath("special://home/temp/kodi.log")
            source_log_filepec2 = C.translatePath("special://home/temp/plugin.video.uwc.log")
        target_log_filepec = GetSetting("download_path").rstrip(os.sep) + os.sep


        try:
            cccopy(source_log_filepec,target_log_filepec)
        except Exception as e:
            traceback.print_exc()
        try:
            cccopy(source_log_filepec2,target_log_filepec)
        except Exception as e:
            traceback.print_exc()
            
    except Exception as e:
        LogR(e,C.LOGNONE)
        xbmcgui.Dialog().ok(
                    heading = u"[COLOR yellow]COPY_KODI_LOG[/COLOR]"
                    , message= u"[COLOR yellow][B]failed copying file[/B][/COLOR]"
                    )
        raise
    
    xbmcgui.Dialog().select(
                heading = u"COPY_KODI_LOG"
                #, message= u"log file copied"
                , list = [u"log file copied"]
                , autoclose = (REPLICATION_NOTIFY_DURATION//2)
                )    

#__________________________________________________________________
#
@C.url_dispatcher.register(
    C.FAVORITES_BACKUP
)
def Favorites_Backup(
      filespec=C.favoritesdb
    , number_of_copies=BACKUP_COPIES
    , url=None
    , force=False #used during dev/testing to ignore user prompt
    ):

    LogR((
        C.module_name()
        , str(traceback.extract_stack(limit=2)[0][0])+":"+str(traceback.extract_stack(limit=2)[0][1])
        , locals()
        ))

##    return

    if not filespec and url:
        filespec = url

    try: 
        favorites_backup_datetime = GetSetting("favorites_backup_datetime", float)
    except:
        favorites_backup_datetime = 0.0
        C.this_addon.setSetting(id='favorites_backup_datetime', value=str(favorites_backup_datetime))

    backup_due_to_schedule = (favorites_backup_datetime + \
                              DAYS_BETWEEN_BACKUPS*C.ONE_DAY_TIMESTAMP) < today 
    LogR((
         ('lastbackup=',favorites_backup_datetime)
         , ('delta=',DAYS_BETWEEN_BACKUPS*C.ONE_DAY_TIMESTAMP/3600/24) #days
         , ('today=',today)
         , (DAYS_BETWEEN_BACKUPS*C.ONE_DAY_TIMESTAMP)
         , (favorites_backup_datetime + DAYS_BETWEEN_BACKUPS*C.ONE_DAY_TIMESTAMP)
         , ('must_backup=',backup_due_to_schedule)
         ))
    optional_backup = False

    if (backup_due_to_schedule==False) and (force==False):
        Log('too early for a AUTOMATIC backup')

        optional_backup = xbmcgui.Dialog().yesno(
                heading = u"Favorites Sync"
                , message= u"Already backedup in the past {} hours[CR][CR]Backup Again?".format(24*DAYS_BETWEEN_BACKUPS)
                , autoclose = REPLICATION_NOTIFY_DURATION//2
                , defaultbutton = xbmcgui.DLG_YESNO_NO_BTN #only in kodi 20+
                )
        
        if optional_backup == False:
            Log('user said no [or timed out] to an optional backup')
            return
        else:
            Log('user said yes to an optional backup')

    Log('backup will begin')

    filespec = utils.Normalize_Filespec(filespec)
    name = filespec.split(os.sep)[-1]
    folder = filespec[0: (len(filespec)-len(name)) ]
    folder = folder.rstrip(os.sep)

    ext = name.split('.')[-1]
    name = name[0: (len(name)-len(ext)-len('.')) ]

    try:

        pd = utils.Progress_Dialog(
            __name__,u"Backup up to {} copies...".format(number_of_copies)
            )

        for backup_number in range(number_of_copies,0,-1):
##            LogR(backup_number)
            newer_filespec = '.'.join ((
                (os.sep).join( (folder,name ))
                , str(backup_number)
                , ext
                ))
            older_filespec = '.'.join ((
                (os.sep).join( (folder,name ))
                , str(backup_number - 1)
                , ext
                ))

            if older_filespec.endswith(".0.db"):
                older_filespec = filespec
                
            try:
                msg = ("renaming {} to {}".format(
                    repr(older_filespec)
                    ,repr(newer_filespec)
                    ))
                pd.update(percent = int(backup_number),message = msg)

##                LogR((older_filespec,newer_filespec),C.LOGNONE)
                LogR((older_filespec,"-->",newer_filespec),C.LOGNONE)

##                #rename does not work on android
##                if os.name == 'nt':
##                    os.rename(older_filespec,newer_filespec)
##                else:
##    ##                xbmcvfs.rename(older_filespec,newer_filespec)
##                    LogR(("delete ",newer_filespec))
##                    xbmcvfs.delete(newer_filespec)
##                    xbmcvfs.copy(older_filespec,newer_filespec)
                if older_filespec == filespec:
                    shutil.copy(older_filespec, newer_filespec)
                else:

##                    LogR((older_filespec,os.stat(older_filespec)))
##                    LogR((newer_filespec,os.stat(newer_filespec)))
##                    LogR(os.path.samestat(os.stat(older_filespec),os.stat(newer_filespec)))
                    shutil.move(older_filespec, newer_filespec)

            except shutil.SameFileError as e:
                #deal with this shutil bug that shows up in Kodi (21.2 (21.2.0) Git:20251026-3f22f00436). Platform: Windows NT x86 64-bit
                # this should be a FileExistsError
                #    e.g. os.stat(src); "\n"; os.stat(dst); "\n"; os.path.samestat(os.stat(src),os.stat(dst));
##                LogR(e)
                msg = ("deleted {}".format(
                    repr(newer_filespec)
                    ))
                LogR(msg)
                pd.update(percent = int(backup_number),message = msg)
                os.remove(newer_filespec) ##delete target
                
                msg = ("renamed {} to {}".format(
                    repr(older_filespec)
                    ,repr(newer_filespec)
                    ))
                LogR(msg)
                pd.update(percent = int(backup_number),message = msg)
                os.rename(older_filespec,newer_filespec)
                    
            except OSError as e: #oserror instead of FileExistsError for PY2 compat

##                LogR((e,dir(e)),C.LOGNONE)
##                LogR((e,ERROR_NUMERS.ENOENT),C.LOGNONE)
##                raise
            
                if C.PY2: errnum = e[0]
                if C.PY3: errnum = e.errno

                if errnum in [ERROR_NUMERS.ENOENT, 2]:  #FileNotFoundError:
                    if backup_number <= 1:
                        msg = ("copied {} to {}".format(
                             repr(filespec)
                            ,repr(newer_filespec)
                            ))
                        Log(msg)
                        pd.update(percent = int(backup_number),message = msg)
                        shutil.copyfile(filespec, newer_filespec)
                        
                    else:
                        Log("can't backup \n{} to \n{} because \n{} does not exist".format(
                            repr(older_filespec)
                            ,repr(newer_filespec)
                            ,repr(older_filespec)
                            ))
                        pass
                elif errnum in [ERROR_NUMERS.EEXIST, 183]:  #FileExistsError:

                    msg = ("deleted {}".format(
                        repr(newer_filespec)
                        ))
                    LogR(msg)
                    pd.update(percent = int(backup_number),message = msg)
                    os.remove(newer_filespec) ##delete target
                    
                    msg = ("renamed {} to {}".format(
                        repr(older_filespec)
                        ,repr(newer_filespec)
                        ))
                    LogR(msg)
                    pd.update(percent = int(backup_number),message = msg)
                    os.rename(older_filespec,newer_filespec)

##                elif errnum in [ERROR_NUMERS.EEXIST, 183]:  #FileExistsError:
##
##                    msg = ("deleted {}".format(
##                        repr(newer_filespec)
##                        ))
##                    Log(msg)
                    
                elif errnum in [shutil.SameFileError]:
                    LogR(older_filespec)
                    raise
                else:
##                    LogR(older_filespec)
##                    LogR(newer_filespec)
                    LogR(os.path.samefile(older_filespec, newer_filespec))
                    LogR((e,dir(e)),C.LOGNONE)
                    LogR((e,ERROR_NUMERS.ENOENT),C.LOGNONE)
                    #raise
            
            except Exception as e:
                LogR(e,C.LOGNONE)
                #raise
        LogR(today)
        C.this_addon.setSetting(id='favorites_backup_datetime', value=str(today))
        
    finally:
        pd = None


#__________________________________________________________________
#
def Tombstone_One(db_conn, favorites_sync_datetime):
    tombstone_days = GetSetting('favorites_sync_tombstone', int)
    tombstone_days = max(tombstone_days, MIN_TOMBSTONE_DAYS)
    query = Q.DELETE_TOMBSTONED(FAV_DB_VERSION_CURRENT ,db_conn )
    params = (int(favorites_sync_datetime), int(tombstone_days))
    result = db_conn.execute(
        query
        , params
##        , forced_log = True
        )
    db_conn.commit()
    Log(u"Tombstoned {} rows from db {}".format(
        result.rowcount
        , repr(db_conn.db_filespec)
        ))
#__________________________________________________________________
# tombstone before replication starts to avoid extra inserts
def Tombstone_All(source_db,target_db,favorites_sync_datetime):
    # reopen these so that total_changes check can work
    source_db_conn = generic_favdbconn(database=source_db)
    pd = utils.Progress_Dialog(
        __name__ #u"Favorites"
        ,u"Tombstoning on local"
        )
    Tombstone_One(source_db_conn,favorites_sync_datetime)
    pd = None; pd = utils.Progress_Dialog(
        __name__ #u"Favorites"
        ,u"Tombstoning on remote"
        )
    target_db_conn = generic_favdbconn(database=target_db)
    Tombstone_One(target_db_conn,favorites_sync_datetime)
    pd = None; pd = utils.Progress_Dialog(
        __name__ #u"Favorites"
        ,u"Tombstoning complete"
        )
    pd = None;
#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_SYNC,[],['keyword'])
def Favorites_Sync(keyword=False):



    force_full_replication=bool(keyword) #using 'keyword' as a param name to avoid other changes
    Log('warning: todo: sync ? move ? keywords to d different database ', C.LOGINFO)
    today = utils.UTC_timestamp()
    Log("for reference: today={} UTC".format(today),C.LOGINFO)

    try:
        remote_favorite_db = C.remote_favorite_db
        if remote_favorite_db in ['','None',u'',u'None',None]:
            remote_favorite_db = xbmcgui.Dialog().browse(
                0
                , "Specify a folder for remote"
                , 'remote_favorite_db_folder'
                , '', False, False)
            remote_favorite_db = utils.Normalize_Filespec(remote_favorite_db)
            if not os.path.exists(remote_favorite_db):
                os.mkdir(remote_favorite_db)
            remote_favorite_db = remote_favorite_db.rstrip(os.sep) + os.sep + 'favorites.db'
            remote_favorite_db = utils.Normalize_Filespec(remote_favorite_db)
            C.addon.setSetting(id='remote_favorite_db', value=remote_favorite_db)
        
        #__________________________________________________________________
        # occasionally backup the local sqlite file
        Favorites_Backup(C.favoritesdb, number_of_copies=BACKUP_COPIES)

        #__________________________________________________________________
        #  confirm an early favorites_sync
        try: 
            favorites_sync_datetime = GetSetting("favorites_sync_datetime", float)
        except:
            favorites_sync_datetime = 0.0
            C.this_addon.setSetting(id='favorites_sync_datetime', value=str(favorites_sync_datetime))

        sync_due_to_schedule = (favorites_sync_datetime + \
                                  C.ONE_DAY_TIMESTAMP) < today
##        Log('warning: hardcode')
        if False or sync_due_to_schedule==False:
            result = xbmcgui.Dialog().yesno(
                    heading = u"Favorites Sync"
                    , message= u"Already synchronized in the past 24 hours[CR][CR]Sync Again?"
                    , autoclose = REPLICATION_NOTIFY_DURATION
##                    , defaultbutton = xbmcgui.DLG_YESNO_NO_BTN #default No
                    , defaultbutton = xbmcgui.DLG_YESNO_YES_BTN #default yes
                    )
##            Log('warning: hardcode above')
            if result == False:
                Log('user said no [or timed out] to an optional sync')
                utils.notify("Cancelling sync")                
                return
            else:
                Log('user said yes to an optional sync')

        #__________________________________________________________________
        #  connect to databases
        remote_db_conn = generic_favdbconn(database=remote_favorite_db)
        Create_Maintain_FavDB(remote_db_conn) #do this in case schema changed
        local_db_conn = generic_favdbconn(database=C.favoritesdb)
        Create_Maintain_FavDB(local_db_conn)  #do this in case schema changed
      
        # tombstone after schema confirmed and before replication starts
        Tombstone_All(
            C.favoritesdb
            , remote_favorite_db
            , favorites_sync_datetime
            )
    
        #__________________________________________________________________
        #  replication starts
##        LogR(C.DEBUG, C.LOGINFO)
        Log(
            'replicating local [{}] to remote [{}]...'.format(
                local_db_conn.db_filespec
                ,remote_db_conn.db_filespec
                )
            , C.LOGINFO)
        l_to_r=r_to_l=0
        l_to_r = SyncDB(
            local_db_conn
            ,remote_db_conn
            ,force_full_replication=force_full_replication
            )
        utils.Notify(
            header=u"{} changes replicated to remote".format(
                l_to_r
                )
            ,  msg=u"{} changes replicated to remote".format(
                l_to_r
                )
            , duration=REPLICATION_NOTIFY_DURATION
            )
    
        Log(
            'replicating remote [{}] to local [{}]...'.format(
                remote_db_conn.db_filespec
                ,local_db_conn.db_filespec
                )
            , C.LOGINFO)
        r_to_l = SyncDB(
            remote_db_conn
            ,local_db_conn
            ,force_full_replication=force_full_replication
            )
        utils.Notify(
            header=u"{} changes replicated to local".format(
                r_to_l
                #, local_db_conn.db_filespec
                )
            ,  msg=u"{} changes [{}]".format(
                r_to_l
                , local_db_conn.db_filespec
                )
            , duration=REPLICATION_NOTIFY_DURATION
            )

##        result = xbmcgui.Dialog().ok(
##                heading = u"Favorites Sync"
##                , message= u"[CR]{} local -> remote changes [CR][CR]{} remote -> local changes".format(l_to_r,r_to_l)
##                )

        xbmcgui.Dialog().yesno(
            heading = u"Favorites Sync"
            , message=u"[CR]{} local -> remote changes [CR][CR]{} remote -> local changes".format(l_to_r,r_to_l)
            , nolabel = ' '
            , yeslabel = 'OK'
            , autoclose = REPLICATION_NOTIFY_DURATION*2
            )

        
        C.this_addon.setSetting(
            id='favorites_sync_datetime'
            , value=str(utils.UTC_timestamp())
            )


        #also encourage a texture `sizes` update to prevent deletion
        Log('if we got this far, reset the count [recycling exception code]',C.LOGINFO)
        utils.set_setting(
            setting_name=C.TIMESTAMP_REFERSH_FULL_SUCCESS,
            setting_value=0.0,
            )
        utils.set_setting(
            setting_name=C.TIMESTAMP_REFERSH_HIGHWATER,
            setting_value=0,
            )



##    except sqlite3.OperationalError as e:
    except StopIteration as e:
        if e.args != ('interrupted',): raise
        utils.Notify(
            header= __name__ 
            , msg=u"replication canceled for {} records".format(loop_number_changed_rows)
            , duration=REPLICATION_NOTIFY_DURATION
            )
    
    except:
        traceback.print_exc()
        utils.Notify(
            header= __name__ 
            , msg=u"Favorites replication error occured.[CR]Check logs for more information"
            , duration=REPLICATION_NOTIFY_DURATION
            )

#__________________________________________________________________
#    
def row_generator(
    db_conn
    , local_db_repl_id_highwater #this value will be between range_start and range_end
    , local_db_date_modified_highwater
    , id_range_start
    , id_range_end
    , max_rows
    , db_version = FAV_DB_VERSION_CURRENT  
):
    (query, params) = Q.GET_DATA_TO_REPLICATE(
            db_version
          , local_db_repl_id_highwater
          , local_db_date_modified_highwater
          , id_range_start
          , id_range_end
          )
    db_cursor = db_conn.execute(query,params
##                                ,forced_log=True
                                )
        
##    Log('fetchmany start')
    for a in db_cursor.fetchmany(size=max_rows):
        ## WARNING !!  list(a) will fill up log if binary_image is included
##        LogR(list(a))  
##        LogR(a['url']) ## performance testing
        yield(a)
##    Log('fetchmany end')
    try:
        db_cursor.close(); db_cursor = None
    except:
        count = 0 
        for bb in db_cursor.fetchall():
            count += 1
            LogR((dict(bb)['name'],dict(bb)['rowid']) )
        LogR(count)
        
        raise

#__________________________________________________________________
#    
def SyncDB(
    local_db_conn
    ,remote_db_conn
    ,import_only=False
    ,save_repl_vector=True
    ,force_full_replication=False
    ):

    LogR((
        C.module_name()
        , str(traceback.extract_stack(limit=2)[0][0])+":"+str(traceback.extract_stack(limit=2)[0][1])
        , locals()
        ))
        
    total_number_changed_rows = 0
    target_db_conn_refers_to_local_disk = (C.profileDir in remote_db_conn.db_filespec)
    LogR((target_db_conn_refers_to_local_disk, C.profileDir, remote_db_conn.db_filespec))

    if save_repl_vector:
        #get db uuids
        query = Q.GET_DB_UUID(FAV_DB_VERSION_CURRENT)
        params = ()
        remote_cursor = remote_db_conn.execute(query, params)
        result = remote_cursor.fetchone()
        remote_db_uuid = result['uuid']
        LogR(("remote_db_uuid=",remote_db_uuid))
        result = None; remote_cursor.close(); remote_cursor = None

        query = Q.GET_DB_UUID(FAV_DB_VERSION_CURRENT)
        params = ()
        local_cursor = local_db_conn.execute(query, params)
        result = local_cursor.fetchone()
        local_db_uuid = result['uuid'] #use ['uuid'] if rowfactory = sqlite3
        LogR(("local_db_uuid=",local_db_uuid))
        result = None; local_cursor.close(); local_cursor = None


    def progress_callback():
        if pd.iscanceled():
            return 1  # Non-zero return aborts the operation
        pd.increment_percent()
        utils.Sleep(5)
        return 0

    if save_repl_vector:
        #get local_db max index to determine how much to subdivide the replication
        query = Q.GET_MAX_ROWID(FAV_DB_VERSION_CURRENT)
        params = (REPL_ID_HIGHWATER_INIT,)
        remote_cursor = remote_db_conn.execute(query, params)
        result = remote_cursor.fetchone()
        max_rowid = int(result['max_rowid'])
##        result = None; remote_cursor.close(); remote_cursor = None
##        LogR(("max_rowid =",max_rowid),include_type=True)
    else:
        max_rowid=0
        local_db_repl_id_highwater = 1
        local_db_date_modified_highwater = 1
        id_range_start = 1
        #id_range_start = 2111 #TESTING
        id_range_end = 99999999999
        full_repl = True


    #warning max_rowid//max_rows does not work properly for mariadb because rowid is not same as sqlite3
    query = Q.FAVORITE_ROWCOUNT(
        FAV_DB_VERSION_CURRENT
        , local_db_conn
        )
    for info in local_db_conn.execute(query).fetchall():
        rows_in_source_table = int(info['row_count'])
        max_rowid = int(info['max_rowid'])


    if import_only:
        # for this feature - local_cursor is the data _source_
        query = Q.FAVORITE_ROWCOUNT(
            FAV_DB_VERSION_CURRENT
            , local_db_conn
            )
        info = local_db_conn.execute(query).fetchone()
        highest_changed_row_id = dict(info)['row_count']
        LogR(highest_changed_row_id)


    #use max(rows_in_source_table,max_rowid) in cases where autoincrement has skewed rowcount
    loops_for_full_repl = (max(rows_in_source_table,max_rowid)//MAX_ROWS) + 2
    LogR(("loops_for_full_repl",loops_for_full_repl -1 ))

    pd = utils.Progress_Dialog(
        title = __name__ #u"Favorites"
        ,message = u"Synchronizing up to {} entries...[CR][CR]{}->{}".format(
                    rows_in_source_table
                    ,local_db_conn.db_filespec
                    ,remote_db_conn.db_filespec
                    ) #format
##        ,u"Synchronizing up to {} entries...".format(rows_in_source_table)
        ) #dialog
    
                                    

    #reuse this connection because Insert_Binary_Image() may reopen it
    #   too often/slowly
    texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
    

    
    
    for i in range(1,loops_for_full_repl):
        row_range_start = ((i-1)*MAX_ROWS) + 1  #add one to avoid row zero
        row_range_end = row_range_start + MAX_ROWS - 1 #subtract one so that we are getting at most MAX_ROWS later on
        loop_number_changed_rows = 0

        local_db_repl_id_highwater=REPL_ID_HIGHWATER_INIT
        local_db_date_modified_highwater=full_repl=0
        id_range_start = row_range_start
        id_range_end = row_range_end

        if remote_db_conn.unread_result: raise Exception('warning unread_result')  #bugsearch

        if save_repl_vector:
            #find out when the remote DB was last synced with this one 
            query = Q.GET_DB_REPL_VECTOR(FAV_DB_VERSION_CURRENT)
            params = (remote_db_uuid, row_range_start, row_range_end)
            try:
                result = local_db_conn.execute(query, params)
                result = result.fetchone()
                if result:
                    full_repl = result['full_repl']
                    if full_repl == FULL_REPL_SUCCESS:
                        #the last full replication was complete
                        # look for new records from begining of our range
                        local_db_repl_id_highwater = REPL_ID_HIGHWATER_INIT
                    else:
                        #replication was incomplete
                        #  avoid previously replicated items by starting with higher ID
                        local_db_repl_id_highwater = result['Local_db_repl_id_highwater']

                    local_db_date_modified_highwater = result['local_db_date_modified_highwater']
                    id_range_start = result['id_range_start']
                    id_range_end = result['id_range_end']
                    if not local_db_date_modified_highwater:
                        local_db_date_modified_highwater = 0
                        
                    
                else: #vector not created yet
                    Log("inserting first replication vector for remote {} in local database {}".format(
                        remote_db_uuid
                        , local_db_uuid
                        ))
                    query = Q.INIT_DB_REPL_VECTOR(
                        FAV_DB_VERSION_CURRENT
                        ,local_db_conn
                        )
                    params = (remote_db_uuid
                              ,REPL_ID_HIGHWATER_INIT
                              ,0
                              ,0
                              ,row_range_start
                              ,row_range_end
                              #,utils.UTC_timestamp()
                              )
                    result = local_db_conn.execute(query, params)
                    local_db_conn.commit
                    local_db_repl_id_highwater=REPL_ID_HIGHWATER_INIT
                    local_db_date_modified_highwater=full_repl=0
                    id_range_start = row_range_start
                    id_range_end = row_range_end            
            except:
                LogR(("exeption querying", query, params))
                raise


##        LogR(
##            (  local_db_repl_id_highwater
##             , local_db_date_modified_highwater
##             , full_repl
##             , id_range_start
##             , id_range_end
##             , local_db_conn.db_filespec
##             )
##            )

        if remote_db_conn.unread_result: raise Exception('warning unread_result')  #bugsearch

        if save_repl_vector:

            #when full replication has complete, we can now replicate using
            if full_repl == FULL_REPL_SUCCESS:
                if not local_db_date_modified_highwater: #then value is zero [first time]
                    local_db_repl_id_highwater = REPL_ID_HIGHWATER_INIT # this will also be zero
                    #we are now replicating all modified values, starting with smallest id
                else:
                    #the stored repl vector values should be ok for use as-is
                    pass

            else:
                #we need to ignore modified timestamp
                # and concentrate on inserting records until a
                #  first-pass complete [aka full_relpl] has happened
                local_db_date_modified_highwater = REPL_ID_HIGHWATER_INIT

        if force_full_replication:
            local_db_date_modified_highwater = REPL_ID_HIGHWATER_INIT
            local_db_repl_id_highwater = REPL_ID_HIGHWATER_INIT
        
        #get max ID for local database and compare with local_db_repl_id_highwater
        # when maxid >= local_db_repl_id_highwater


        highest_changed_row_id = 0
        query = ""        

    

        if remote_db_conn.unread_result: raise Exception('warning unread_result')  #bugsearch

        try:  #sync local to remote

            most_recent_id = local_db_repl_id_highwater
            lowest_date_modified = 0 #local_db_date_modified_highwater

            if not import_only:
                db_version = FAV_DB_VERSION_CURRENT
            else:
                db_version = Q.FAV_DB_VERSION_1


##            if local_db_conn.unread_result: Log('warning unread_result')  #bugsearch
##            i=0
##            for cur_data in \
##                row_generator(
##                    local_db_conn
##                    #local_db_repl_id_highwater is between id_start and id_end
##                    , local_db_repl_id_highwater=local_db_repl_id_highwater 
##                    , local_db_date_modified_highwater=local_db_date_modified_highwater
##                    , id_range_start=id_range_start
##                    , id_range_end=id_range_end
##                    , max_rows=MAX_ROWS
##                    , db_version=db_version
##                    ):
##                i=i+1
####                LogR((cur_data['rowid'],))
##            Log("warning remove the above counting loop")
##            LogR(("rows will be processed=",i)); i = 0;

##            if local_db_conn.unread_result: Log('warning unread_result')  #bugsearch
##            if remote_db_conn.unread_result: Log('warning unread_result')  #bugsearch
        
            for cur_data in \
                row_generator(
                    local_db_conn
                    #local_db_repl_id_highwater is between id_start and id_end
                    , local_db_repl_id_highwater=local_db_repl_id_highwater 
                    , local_db_date_modified_highwater=local_db_date_modified_highwater
                    , id_range_start=id_range_start
                    , id_range_end=id_range_end
                    , max_rows=MAX_ROWS
                    , db_version=db_version
                    ):


                query = ""
                cur_data = dict(cur_data)

                #sqlite performance issues [only using a single index per table] do not let me use ORDER BY
                try:
                    cid = cur_data['rowid']
                    cdm = cur_data['date_modified']
                except:
                    LogR(list(cur_data))
                    raise
                if cid>most_recent_id:  most_recent_id=cid

                if pd.iscanceled():
                    StopIteration
                    raise StopIteration('interrupted')
##                    raise sqlite3.OperationalError('interrupted')

                if len(cur_data['url']) % 4 == 0:
                    progress_callback() #balance performance and feedback
                    pd.update(
                        percent = pd.percent + 0.1
                        ,message = u"Imported/synced {} of {} entries...[CR][CR]{}->{}".format(
                                    total_number_changed_rows
                                    #loop_number_changed_rows
                                    , rows_in_source_table
##                                    , cid #highest_changed_row_id
                                    ,local_db_conn.db_filespec
                                    ,remote_db_conn.db_filespec
                                    
                                    )
                    )




##                Log("warning: import only test")
                # prevent insert if we already have url in database
                #    we may not have unique keys 
                if import_only: 
                    url = cur_data['url']
                    query = Q.GET_FAV_URL(FAV_DB_VERSION_CURRENT)
                    params = ( url.split('|')[0]+'%', )
                    try:
                        result = remote_db_conn.execute(query, params)
                        result = result.fetchall()
                        if result:
                            #then the url exists in DB with some other name
##                            LogR(params)
                            continue
                        else:
##                            LogR(params)
##                            LogR(dict(result))
##                            LogR(dict(cur_data))
                            cur_data['uuid'] = str(uuid4())
                            cur_data['date_modified'] = None
                            
                            
                    except Exception as ex:
                        LogR(ex)
                        traceback.print_exc()
                        return

                if remote_db_conn.unread_result: Log('warning unread_result')  #bugsearch
                if  local_db_conn.unread_result: Log('warning unread_result')  #bugsearch

                q = Q.UPSERT_FAV(
                    Q.FAV_DB_VERSION_CURRENT
                    ,cur_data['name']
                    ,cur_data['url']
                    ,cur_data['mode']
                    ,cur_data['image']
                    ,cur_data['description']
                    ,cur_data['camsite']
                    ,cur_data['binary_image']
                    ,cur_data['uuid']
                    ,cur_data['is_deleted']
                    ,cur_data['date_modified']
                    ,cur_data['modelID']
                )
                try:
                    list_of_changed_columns = list()
                    list_of_changed_columns = remote_db_conn.upsert(
                         q["table"]
                        ,q["key_name"]
                        ,q["key_value"]
                        ,q["column_tuple"]
                        ,q["value_tuple"]
                        ,forced_log=True
                        )
                except sqlite3.IntegrityError as e:
                    if 'duplicate information' in e.args:
                        LogR(('no update', cid, cur_data['name'],cur_data['uuid']))
                        continue
                    else:
                        raise
                except mariadb.DatabaseError as e:
                    if 'duplicate information' in e.args[1] : 
                        #  LogR(('no update', cid, cur_data['name'],cur_data['uuid']))
                        continue
                    elif 'invalid date_modified' in e.args[1] : 
                        # data is different, but older
                        LogR(('no update - newer record on target', cid, cur_data['name'],cur_data['uuid']))
                        continue
                    else:
                        LogR(e.args)
                    raise
                except Exception as e:
                    LogR(e.args)
                    raise

                if len(list_of_changed_columns) > 0:
##                    LogR(list_of_changed_columns)
                    if "`uuid`" not in list_of_changed_columns:
                        LogR(("updated row", cid, cur_data['name'],cur_data['uuid']))
                    else:
                        LogR(("inserted row", cid, cur_data['name'],cur_data['uuid']))
                    loop_number_changed_rows += 1
                    if cid>highest_changed_row_id: highest_changed_row_id=cid
                    if cdm<lowest_date_modified: lowest_date_modified=cdm

##                    LogR(("`image`"        in list_of_changed_columns),)
##                    LogR(("`binary_image`" in list_of_changed_columns),)
##                    LogR(target_db_conn_refers_to_local_disk)
                    if (  "`image`"        in list_of_changed_columns         \
                       or "`binary_image`" in list_of_changed_columns )       \
                       and target_db_conn_refers_to_local_disk :
                        Log('warning should I rewrite icon to thumbnail cache at this point')
                        z = Insert_Binary_Image(
                            cur_data['binary_image'],
                            cur_data['image'],
                            cur_data['name'],
                            force_write_image=True,
                            m_texture_conn = texture_conn ,
                            )
##                        Log(z)

                else:
                    LogR(('no change detected', cid, cur_data['name'],cur_data['uuid']))
                    pass


                if remote_db_conn.unread_result: Log('warning unread_result')  #bugsearch
                if local_db_conn.unread_result: Log('warning unread_result')  #bugsearch

                if full_repl != FULL_REPL_SUCCESS:
                    if loop_number_changed_rows < 1:
                        #dont' save any repl data
                        Log("loop_number_changed_rows < 1:" ,C.LOGWARNING)



        
            
            ##
            # for loop ended
            ##
            total_number_changed_rows += loop_number_changed_rows

            if import_only: 
                remote_db_conn.commit()


            if remote_db_conn.unread_result: Log('warning unread_result')  #bugsearch
            if local_db_conn.unread_result: Log('warning unread_result')  #bugsearch

            if loop_number_changed_rows and not full_repl:
                LogR(("for a partial sync, loop_number_changed_rows=",loop_number_changed_rows))
    
                if save_repl_vector: 
                    #calculate local's HIGHEST possible modified date within our id_range
                    query = Q.GET_MAX_MODIFIED_IN_IDRANGE(FAV_DB_VERSION_CURRENT)
                    params=(highest_changed_row_id, id_range_end)
                    result = local_db_conn.execute(query, params).fetchone()
                    LogR(dict(result))
                    local_db_date_modified_highwater = result['max_date_modified']
                    
                    #save the success
                    query = Q.WRITE_DB_REPL_VECTOR(FAV_DB_VERSION_CURRENT,local_db_conn)
                    params = (
                        most_recent_id + 1 # +1 because we are using [greater than] or [equal to] in query
                        , local_db_date_modified_highwater
                        , full_repl
                        , remote_db_uuid
                        , id_range_start
                        , id_range_end
                        , most_recent_id + 1 # +1 because we are using [greater than] or [equal to] in query
                        , local_db_date_modified_highwater
                        , full_repl
                        , remote_db_uuid
                        , id_range_start
                        , id_range_end
                        )
                    try:
                        Log(query.replace("?", "'{}'").format(*tuple(params)))  #see exact query during debugging
                        result = local_db_conn.execute(query, params)
                    except:
                        LogR(("exeption querying", query, params))
                        raise
                    local_db_conn.commit()
                    
                remote_db_conn.commit()
                local_db_conn.commit()
                Log(u"{} changes replicated".format(loop_number_changed_rows))
                
            elif save_repl_vector:

##                Log('consider this a a full replication for that id_range')
                remote_db_conn.commit()
                local_db_date_modified_highwater = lowest_date_modified
                if local_db_date_modified_highwater<2:
                    #nothing was changed during this pass
                    # avoid a full db search by generating a higher number
                    #calculate local's HIGHEST possible modified date within our id_range
                    query = Q.GET_MAX_MODIFIED_IN_IDRANGE(FAV_DB_VERSION_CURRENT)
                    params=(id_range_start,id_range_end)
                    result = local_db_conn.execute(
                        query
                        , params
##                        , forced_log = True
                        ).fetchone()
                    local_db_date_modified_highwater = result["max_date_modified"]
##                    LogR(local_db_date_modified_highwater)


##suppose we have more than one DB
##dbB is an intermediate replical
##dbA and dbB sync.  The most recently modified record is dbA-mrmr1 with date dbA-mrmr1-dm1
##dbA and dbB can sync by only indexing modified information; records > than dbA-mrmr1-dm1 need to sync
##dbB and dbC then syncs for the first time.  Everything in dbA will be on dbC.
##Except dbC is independent and has its own indpendent most recently dbC-mrmr1-dm1
##There is no guarantee that dbA-mrmr1-dm1 > dbC-mrmr1-dm1  or   dbA-mrmr1-dm1 < dbC-mrmr1-dm1
##To get information the information of dbC-mrmr1, we have to search dbB for the records > dbC-mrmr1-dm1
##This might imply that we dbA needs to scan dbB for values >= dbC-mrmr1-dm1
##But .... worst case is that a full replication is required

##Does using a date_replicated  help? [instead of date modified]
##Thinking it through....

##Does using a is_dirty column help?
##Thinking it through....
##dbA and dbB sync.  Nothing is_dirty
##dbA changes one record.  dbA-mrmr1 is now marked as 'dirty'
##[my comments will stop using quotes from now on]
##dbB scans for all dirty rows and copies them over
##dbB-mrmr1 will _stay_ dirty until it gets copied to dbC
##we would need a table to track tuples
##   ownerReplicaID,replicaID,uuid,dirty
##inserting from dbA should add one row for each replicaID that dbB knows about
##the row for dbA would be not-dirty
##the row for dbC would be dirty
##dbC scans for all dirty rows, not owned by itself, and replicates them
##dbC sets row as not-dirty
##when all rows for that uuid are not-dirty; delete the uuid from the table
##NOTE: table must be locked against read and write to prevent race conditions



                query = Q.WRITE_DB_REPL_VECTOR(
                    FAV_DB_VERSION_CURRENT
                    ,local_db_conn
                    )
                if total_number_changed_rows > 0:
                    params = (
## always use REPL_ID_HIGHWATER_INIT because
##    search_for_stuff will always use local_db_date_modified_highwater
##                        highest_changed_row_id
                        REPL_ID_HIGHWATER_INIT
                        , local_db_date_modified_highwater
                        , FULL_REPL_SUCCESS
                        , remote_db_uuid
                        , id_range_start
                        , id_range_end
                        , REPL_ID_HIGHWATER_INIT
                        , local_db_date_modified_highwater
                        , FULL_REPL_SUCCESS
                        , remote_db_uuid
                        , id_range_start
                        , id_range_end
                        )
                else:                    
                    params = (
## always use REPL_ID_HIGHWATER_INIT because
##    search_for_stuff will always use local_db_date_modified_highwater
                        REPL_ID_HIGHWATER_INIT
                        , local_db_date_modified_highwater
                        , FULL_REPL_SUCCESS
                        , remote_db_uuid
                        , id_range_start
                        , id_range_end
                        , REPL_ID_HIGHWATER_INIT
                        , local_db_date_modified_highwater
                        , FULL_REPL_SUCCESS
                        , remote_db_uuid
                        , id_range_start
                        , id_range_end

                        )          
                try:
##                    LogR(('saving a FULL repl success between local and remote'
##                          ,local_db_conn.db_filespec
##                          ,remote_db_conn.db_filespec
##                         ))
                    result = local_db_conn.execute(
                          query
                        , params
##                        , forced_log = True
                        )
                                                   
                    local_db_conn.commit()

                except:
                    LogR(("exeption querying", query, params))
                    #traceback.print_exc()
                    raise            

##                Log(u"{} changes made to favorites for rowid between {} and {}".format(
##                    loop_number_changed_rows
##                    , row_range_start
##                    , row_range_end 
##                    ))


        
        except StopIteration as e:
            if e.args != ('interrupted',):
                raise
            utils.Notify(
                header= __name__ #u"Favorites"
                , msg=u"replication canceled for {} records".format(loop_number_changed_rows)
                , duration=REPLICATION_NOTIFY_DURATION
                )
            raise
        except:
            try:
                Log("warning: hardcode")
                #Copy_KODI_Log("")
            except:
                pass
            raise

    
    Log(u"{} TOTAL changes replicated".format(total_number_changed_rows)
        , C.LOGWARNING)

    return total_number_changed_rows

#__________________________________________________________________
#
def Add_Sync_Favorites(dir_only=False):

    if C.remote_favorite_db:
        #include a sync icon
        utils.addDir(
            name="[COLOR {}]Favorites_Sync[/COLOR]".format(C.test_text_color)
            ,url=C.DO_NOTHING_URL
            ,mode=C.FAVORITES_SYNC
            #,iconimage=C.category_icon
            #,duration=999999999 # position icon at end when sort by duration; value must be less than 2^32
            ,duration=0 # position icon at end when sort by duration desc; value must be less than 2^32
            ,Folder=False 
            )

    if not C.DEBUG: return
    
    utils.addDir(
        name="[COLOR {}]Favorites_Sync_ForceFull[/COLOR]".format(C.test_text_color)
        ,url=C.DO_NOTHING_URL
        ,mode=C.FAVORITES_SYNC
        #,iconimage=C.category_icon
        ,duration=1
        ,keyword='True' #this is me just reusing a parameter name for this specific function
        ,Folder=False 
        )
    utils.addDir(
        name="[COLOR {}]Favorites_Import[/COLOR]".format(C.test_text_color)
        ,url=C.DO_NOTHING_URL
        ,mode=C.FAVORITES_IMPORT
        #,iconimage=C.category_icon
        ,duration=1
        ,Folder=False 
        )
    utils.addDir(
        name="[COLOR {}]Copy KODI LOG Android Downloads[/COLOR]".format(C.test_text_color)
        ,url="/storage/emulated/0/Download/"
        ,mode=C.COPY_KODI_LOG
        ,duration=1
        ,Folder=False 
        )
    utils.addDir(
        name="[COLOR {}]Favorites_Backup[/COLOR]".format(C.test_text_color)
        ,url=C.DO_NOTHING_URL
        ,mode=C.FAVORITES_BACKUP
        #,iconimage=C.category_icon
        ,duration=1
        ,Folder=False
        )
    utils.addDir(
        name="[COLOR {}]REBUILD_CAM_THUMBS[/COLOR]".format(C.test_text_color)
        ,url=C.DO_NOTHING_URL
        ,mode=C.REBUILD_CAM_THUMBS
        ,duration=1
        ,Folder=False 
        )
    utils.addDir(
        name="[COLOR {}]REBUILD_NONCAM_THUMBS[/COLOR]".format(C.test_text_color)
        ,url=C.DO_NOTHING_URL
        ,mode=C.REBUILD_NONCAM_THUMBS
        ,duration=1
        ,Folder=False 
        )
    
