#-*- coding: utf-8 -*-


import random
from uuid import uuid4

import constants as C
import queries as Q
import utils

from utils import Log,LogR
from fav_dbconn import generic_favdbconn
from fav_schema import Create_Maintain_FavDB

## Note: assert dd['uuid']  # will not work because of a compile time setting

###____Test Helper__________________________________________________________
#perform same action as clicking 'WC Favorites' button
def List_Favorites():
    C.url_dispatcher.dispatch(
        mode = C.ROOT_INDEX_FAVORITES, # 14=list
        queries = utils.parse_query(
            '?bulk_operation=False&channel=None&end_directory=True&keyword&mode=14&name=%5bCOLOR%20hotpink%5dWC%5b%2fCOLOR%5d%20%5bCOLOR%20orange%5dFavorites%5b%2fCOLOR%5d&page_end=1&page_start=1&section=None&url=DO_NOTHING_URL'
            )
        )
##    Log('error',C.LOGWARNING)

###____Test Group__________________________________________________________
def Schema_Tests():

    print('repeat ALL with mysql db connection')    
    fav_databases = [
        r"c:\temp\ss.db"
        , "kodi_favorites_back"
        ]

    for current_local_database in fav_databases:
        C.favoritesdb =  current_local_database

###____Test__________________________________________________________

        ##    #params
        ##    given sqlite db connection
        ##    filespec does not yet exist
        ##    #action
##        List_Favorites()
        ##    #result
        ##    creates a blank fav database with all v4 elements
         
###____Test__________________________________________________________

        ##    #params
        ##    given sqlite db connection
        m_favorites_conn = generic_favdbconn(database=current_local_database)
        ##    with missing favorites_meta table 
        Log('warning test: drop favorites_meta table to grigger full rebuild')
        m_favorites_conn.execute('drop table if exists favorites_meta;')
        m_favorites_conn.commit()
        ##    #action
        Create_Maintain_FavDB(m_favorites_conn)
        ##    result
        ##    database with all v4 elements exists
        ##    includes favorites_meta: 
        ##      new single row db UUID
        ##      latest db version
        dd = dict(m_favorites_conn.execute(
            Q.GET_DB_UUID(Q.FAV_DB_VERSION_CURRENT)
            ).fetchone())
##        dd['uuid'] = None; Log("warning: fake result for testing");
        if not dd['uuid']:
            raise AssertionError

###____Test__________________________________________________________

        
        ##    #params
        ##    given sqlite db connection
        Log('warning test: change favorites_meta table so that it is listed as v3')
        m_favorites_conn.execute('update favorites_meta set user_version=3;')
        dd = dict(m_favorites_conn.execute(
            Q.GET_DB_USER_VERSION(m_favorites_conn)
            ).fetchone())
        LogR(dd)
        old_user_version = dd["user_version"]
        ##    #action
        Create_Maintain_FavDB(m_favorites_conn)
        ##    #result
        ##    database with all v4 elements exists
        ##    includes favorites_meta and new single row db UUID
        dd = m_favorites_conn.execute(
            Q.GET_DB_USER_VERSION(m_favorites_conn)
            ).fetchall()
        if len(dd) != 1: raise AssertionError
        dd=dict(dd[0])
##        dd['user_version'] = old_user_version; Log("warning: fake result for testing");
        if not dd["user_version"] == Q.FAV_DB_VERSION_CURRENT:
            raise AssertionError


###____Test__________________________________________________________
        
        ##    #params
        ##    given sqlite db connection
        ##    #action
        Log('warning test:   use some sort of tool manually insert a record with zero datemodified')
        m_favorites_conn.execute('insert into favorites (      \
                    name     ,  url    , image, uuid  ,date_modified     ) values (      \
                    "name.{}", "url.{}", "{}", "{}" , 0);  '.format(
                        current_local_database[0:-8]  #random.random()
                        ,random.random()
                        ,C.settings_icon
                        ,str(uuid4())
                                ) #format
                ,forced_log = True) #execute
        m_favorites_conn.commit()
    ##    #result
    ##    information should still list
##        List_Favorites()

        Log("Schema_Tests() complete for '{}'".format(C.favoritesdb) ,C.LOGERROR)

    
###____Test Group__________________________________________________________
def List_Tests():

    Log('repeat ALL with mysql db connection')    
    fav_databases = [
          r"c:\temp\ss.db"
##        , r"kodi_favorites_back"
        ]
    remote_databases = [
        #  ""
        #r"c:\temp\ss.db",
         r"kodi_favorites_back"
        ]
    
    for current_local_database in fav_databases:
        C.favoritesdb =  current_local_database

        for remote_favorite_db in  remote_databases:

###____Test__________________________________________________________

            ##    #relevent setup
            ##    REMOTE database is blank
            saved_remote_favorite_db = C.remote_favorite_db
            C.remote_favorite_db = remote_favorite_db # set this temporary
            LogR((C.remote_favorite_db,C.maria_db_userid))
            ##    #action
            ##    launch registered action C.ROOT_INDEX_FAVORITES
            #List_Favorites()  #comment out as necessary
            C.remote_favorite_db = saved_remote_favorite_db #restore change
            ##    #result
            ##    sync button not exists

###____Test__________________________________________________________

            ##    relevent setup
            ##    REMOTE database is NOT blank sqlite
            ##    #action
            ##    launch registered action C.ROOT_INDEX_FAVORITES
##            List_Favorites()
            ##    #result
            ##    sync button exists
            ##    random button exists

###____Test__________________________________________________________

            ##    relevent setup
            ##    REMOTE database is mariadb
            ##    remote mariadb user is NOT blank
            ##    #action
            ##    launch registered action C.ROOT_INDEX_FAVORITES
##            List_Favorites()
            ##    #result
            ##    sync button exists
            ##    random button exists


###____Test__________________________________________________________

            ##    relevent setup
            ##    debug is True
            ##    [if sorted by duration decending]
            ##    #action
            ##    launch registered action C.ROOT_INDEX_FAVORITES
##            List_Favorites()
            ##    #result
            ##    sync button exists at bottom 
            ##    random button exists
            ##    force_full_sync button exists
            ##    favorites_import button exists
            ##    copy_Kodi_log button exists
            ##    favorits_backup button exists


###____Test__________________________________________________________

            ##    relevent setup
            Log(' add an non-cam entry manually or via some other method')
            m_favorites_conn = generic_favdbconn(database=current_local_database)
            m_favorites_conn.execute(
                'insert into favorites (      \
                        name     ,  url    , image, uuid  ,date_modified     ) values (      \
                        "{}", "url.{}", "{}", "{}" , 0);  '.format(
                            current_local_database[:-8] + str(random.random())[0:4]
                            ,random.random()
                            ,C.settings_icon
                            ,str(uuid4())
                                    ) #format
                    ,forced_log = True) #execute
            ##    #action
            m_favorites_conn.commit()
##            List_Favorites()
            ##    #result
            ##    item is listed

###____Test__________________________________________________________
            ##    relevent setup
            Log('    add an online-cam entry manually or via some other method')
            m_favorites_conn = generic_favdbconn(database=current_local_database)
            m_favorites_conn.execute('insert into favorites (      \
                        name     , camsite,  url    , image, uuid  ,date_modified     ) values (      \
                        "{}", 1, "url.{}", "{}", "{}" , 0);  '.format(
                            'NickiFrenchy'
                            ,random.random()
                            ,'https://ahmestatic.fuckandcdn.com/thumbs/320x240/248/588583/1.jpg'
                            ,str(uuid4())
                                    ) #format
                    ,forced_log = True) #execute
            ##    #action
            m_favorites_conn.commit()
##            List_Favorites()
            ##    #result
            ##    item is listed

###____Test__________________________________________________________
            ##    relevent setup
            Log('warning add an offline cam entry manually or via some other method')
            m_favorites_conn = generic_favdbconn(database=current_local_database)
            m_favorites_conn.upsert(
                " `favorites` "
                ," `uuid` "
                ,"'" + str(uuid4()) + "'" 
                ,(" `name` "
                  , " `camsite` "
                  , " `url` "
                  , " `image` "
                  , " `uuid` "
                  ," `date_modified` "
                  )
                ,(  " 'fake cam' "
                    ,str(1)
                    ,str(random.random())
                    ," 'https://ahmestatic.fuckandcdn.com/thumbs/320x240/248/588583/1.jpg' "
                    ,"'" + str(uuid4()) + "'" 
                    ,str(0)
                         )
                ,forced_log = True) #execute
            m_favorites_conn.commit()
            ##    #action
##            List_Favorites()
            ##    #result
            ##    item is listed at bottom
        Log('LIST_Tests() complete for {}'.format(current_local_database),C.LOGERROR)

    List_Favorites()

    Log('LIST_Tests() complete',C.LOGERROR)
    pass

#__________________________________________________________________
#
def Insert_Fav_Tests():
    #inclue insert, delete, refresh, rename

##    #relevent params
##    open a webcam listing
##    #action
##    choose 'add to UWC favorites'
##    goto 'WC favorites'
##    #result
##    new webcam item is listed
        
##    #relevent params
##    open a 'tube' listing
##    #action
##    choose 'add to UWC favorites'
##    goto 'WC favorites'
##    #result
##    new 'tube' item is listed

##    #relevent params
##    #action
##choose and existing 'UWC favorite'
##choose rename and edit the name
##click 'refresh' favorites
##    #result
##    renamed item exists

##    #relevent params
##    #action
##choose and existing 'UWC favorite'
##choose 'remove from favorites'
##click 'refresh' favorites
##    #result
##    item is deleted
##    database is_deleted column for that entry says 1

##    #relevent params
##    choose an existing 'UWC favorite' directly in database
##    delete the img and 'binary_image'
##    commit your change
##    #action
##refresh the Favorites list
##    #result
##picture icon be generic
##    #action
##choose an existing 'UWC favorite' directly in database
##choose 'refresh' for that entry
##refresh the Favorites list    
##    #result
##picture icon be set properly
    
##choose 'remove from favorites'
##click 'refresh' favorites
##    #result
##    item is deleted
##    database is_deleted column for that entry says 1
    
    
    pass    

#__________________________________________________________________
#
def PlayRandom():
##    #relevent params
##    delete all entries in database
##    #action
##   (['plugin://plugin.video.uwc/', '-1', '?bulk_operation=False&channel=None&end_directory=True&keyword&mode=2341234123&name=%5bCOLOR%20orange%5dRandom%20Favorited%20Vid%5b%2fCOLOR%5d&page_end=1&page_start=1&section=None&url=DO_NOTHING_URL', 'resume:false'],)
##    #result
##    error in log 'no rows found'    

##    #relevent params
##    add an entry manually or via some other method
##    #action
##   (['plugin://plugin.video.uwc/', '-1', '?bulk_operation=False&channel=None&end_directory=True&keyword&mode=2341234123&name=%5bCOLOR%20orange%5dRandom%20Favorited%20Vid%5b%2fCOLOR%5d&page_end=1&page_start=1&section=None&url=DO_NOTHING_URL', 'resume:false'],)
##    #result
##    item is played   

    pass    

#__________________________________________________________________
#
def All_Tests():

##    #common results
##    xbmc container displayed
##    no error reported to log
##    no error reported to user
##    refresh button exists
    try:    
        Schema_Tests()
    #    List_Tests()
    #    Insert_Fav_Tests()
    #    PlayRandom()
    except Exception as ex:
        LogR(ex)
        raise

    print('repeat ALL with favdb as mysql_db_connection')
    
