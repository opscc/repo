#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import datetime
import json
import os.path
import random
import re
import requests
import simplecache
import sqlite3
import socket
import sys
import time
import traceback
import threading
import unicodedata
import urllib

import importlib
import operator
import collections
    
import urllib3



from xml.dom import minidom
    
from constants import urllib2
from constants import cookielib
from constants import StringIO
    
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import constants as C

if C.PY2: from htmlentitydefs import name2codepoint
if C.PY3: from html.entities import name2codepoint


from constants import quote
from constants import quote_plus
from constants import urlparse
from constants import urlencode
from constants import HTMLParser
from constants import StringIO

my_http_session = requests.Session()
from urllib3 import ProxyManager, PoolManager
if C.certPath:
    pool_proxy = PoolManager(ca_certs=C.certPath)
else:
    pool_proxy = PoolManager()


### fake cache created to check memory usage
### ... appears to be zero cost.... memory collection?...
### ram seems to be related to number of thumbnails(size) / skin viewtyep / other things?
class FakeCache():
    empty = json.loads("[]")    
    def get(self,endpoint):
        return self.empty
    
    def set(self,endpoint,data,expiration):
        return
##global_cache = FakeCache()
global_cache = simplecache.SimpleCache()
global_cache.enable_mem_cache=False



monitor = xbmc.Monitor()

#__________________________________________________________________________
#
LOGPATH = C.translatePath('special://logpath/')
FILENAME = C.addon_id+'.log'
LOG_FILE = os.path.join(LOGPATH, FILENAME)
DAY_IN_SECONDS = MAX_LOG_SIZE = 86400 #60*60*24 # *1000

####xbmc.log(LOG_FILE, xbmc.LOGNONE)
##try:
##    xbmc.log(repr(os.stat(LOG_FILE)) , xbmc.LOGNONE)
##    cr = int(os.stat(LOG_FILE).st_ctime)
##    mt_current = int(os.stat(LOG_FILE).st_mtime)
##except Exception as ex:
##    xbmc.log(repr(ex) , xbmc.LOGERROR)
##    xbmc.log('int(time.time())' , xbmc.LOGERROR)
##    cr = int(time.time())
try:
    #rename older file
    
    filespec = LOG_FILE
    backup_number = 0
    name = filespec.split(os.sep)[-1]
    folder = filespec[0: (len(filespec)-len(name)) ]
    folder = folder.rstrip(os.sep)
    ext = name.split('.')[-1]
    name = name[0: (len(name)-len(ext)-len('.')) ]
    newer_filespec = '.'.join ((
        (os.sep).join( (folder,name ))
        , str(backup_number)
        , ext
        ))

    #use modified time because Windows may change 'create' without asking
    size_current = 0
    mt_current = sys.maxsize
    try:
        mt_current = int(os.stat(LOG_FILE).st_mtime)
        size_current = int(os.stat(LOG_FILE).st_size)
    except  FileNotFoundError as ex:
        pass
    except Exception as ex:
        xbmc.log(repr(ex) , xbmc.LOGERROR)
    
    try:
        mt_newer_filespec = sys.maxsize
        mt_newer_filespec = int(os.stat(newer_filespec).st_mtime)
    except  FileNotFoundError as ex:
        pass
    except Exception as ex:
        xbmc.log(repr(ex) , xbmc.LOGERROR)


    #newer is infinite [did not exit] = false
    #newer MT is bigger [how?] = false
    #newer MT is same = false
    #newer MT is sightly less = false
##    xbmc.log(repr((mt_current - mt_newer_filespec)) , xbmc.LOGERROR)
    if ((mt_current - mt_newer_filespec) > DAY_IN_SECONDS) \
       or \
       ((mt_newer_filespec == sys.maxsize) and (size_current > MAX_LOG_SIZE)) :

        #use file size when old log does not exist        
        xbmc.log(repr(mt_current) , xbmc.LOGERROR)
        xbmc.log(repr(size_current) , xbmc.LOGERROR)
        xbmc.log(repr(mt_newer_filespec) , xbmc.LOGERROR)

        try:
            os.remove(newer_filespec)
        except  FileNotFoundError as ex:
            pass
        except Exception as ex:
            xbmc.log( 'os.remove(newer_filespec)' , xbmc.LOGNONE)
            xbmc.log(repr(ex) , xbmc.LOGERROR)
            raise
        try:
            os.rename(LOG_FILE, newer_filespec)
            xbmc.log('RENAMED' , xbmc.LOGWARNING)
        except Exception as ex:
            xbmc.log(repr(ex) , xbmc.LOGERROR)
            raise        

except Exception as ex:
    xbmc.log(repr(ex) , xbmc.LOGERROR)
##    raise        

####xbmc.log(repr(int(time.time())) , xbmc.LOGNONE)
####xbmc.log(repr(cr) , xbmc.LOGNONE)
####xbmc.log(repr( int(time.time() - cr) ),  xbmc.LOGNONE)
####xbmc.log(repr( day_in_seconds ),  xbmc.LOGNONE)
####xbmc.log(repr( int(time.time() - cr) > day_in_seconds),  xbmc.LOGNONE)
##if (int(time.time() - cr) > day_in_seconds) :
##    xbmc.log('HERE' , xbmc.LOGERROR)
##    created_time = modification_time = access_time = current_time = int(time.time())
##
####    xbmc.log(repr(newer_filespec) , xbmc.LOGWARNING)
##    try:
##        os.remove(newer_filespec)
##    except  FileNotFoundError as ex:
##        pass
##    except Exception as ex:
##        xbmc.log( 'os.remove(newer_filespec)' , xbmc.LOGNONE)
##        xbmc.log(repr(ex) , xbmc.LOGERROR)
##        raise
##    try:
##        os.rename(LOG_FILE, newer_filespec)
##    except Exception as ex:
##        xbmc.log(repr(ex) , xbmc.LOGERROR)
##        raise
####        import win32file
####        try:
####            from ctypes import WinDLL, byref
####            kernel32 = WinDLL("kernel32", use_last_error=True)
####            handle = kernel32.CreateFileW(
####                newer_filespec
####                , 256 #win32file.GENERIC_WRITE
####                , 0 #win32file.FILE_SHARE_READ | win32file.FILE_SHARE_WRITE
####                , None
####                , 3 #win32file.OPEN_EXISTING
####                , 128 #win32file.FILE_ATTRIBUTE_NORMAL
####                ,None
####                )
######            LogR(handle)
####            xbmc.log(repr(handle) , xbmc.LOGNONE)
####            xbmc.log(repr(created_time) , xbmc.LOGNONE)
####            if handle:
####                kernel32.SetFileTime(
####                    handle
####                    ,created_time
####                    ,None
####                    ,None
####                )
####                handle.close()
####        except Exception as ex:
####            xbmc.log( 'os.rename(LOG_FILE, newer_filespec)' , xbmc.LOGNONE)
####            xbmc.log(repr(ex) , xbmc.LOGERROR)
####            raise
####        #windows may reset create time if a new file appears within 15 seconds
####        os.utime(newer_filespec, (access_time, modification_time) )
##        xbmc.log('RENAMED' , xbmc.LOGWARNING)
##    except Exception as ex:
##        xbmc.log(repr(ex) , xbmc.LOGERROR)
##        raise
##    try:
##        os.remove(LOG_FILE)
##        xbmc.log('REMOVED' , xbmc.LOGWARNING)
##        if C.PY2:
##            f = open(LOG_FILE, 'a')
##        else:
##            f = open(LOG_FILE, 'a', encoding='utf-8-sig')
##            #Set the access and modified times of the file specified by path
##        f.close()
##        os.utime(LOG_FILE, (access_time, modification_time) )
##
##    except FileNotFoundError as ex:
##        pass
##    except Exception as ex:
##        xbmc.log(repr(ex) , xbmc.LOGERROR)
##        raise
##raise Exception()
def Log(msg='', loglevel=None, stacklevel=2):

    try:
        
        if C.PY2:
            f = open(LOG_FILE, 'a')
        else:
            f = open(LOG_FILE, 'a', encoding='utf-8-sig')

        if C.DEBUG and (loglevel is None): loglevel = C.LOGINFO
        if not loglevel: return
        if not msg: msg = u""
        if not isinstance(msg, C.text_type):
            if C.PY3: msg = str(msg,'utf8','ignore')
            if C.PY2: msg = msg.decode('ascii','ignore').encode('utf8')

        n = datetime.datetime.now()
        d =  u"{} T:{:<5}".format(
            n.isoformat(sep=' ')[:-3]
            ,threading.current_thread().ident
            )
        if loglevel in [None,C.LOGNONE,C.LOGNOTICE,C.LOGINFO]: ltype = 'info'
        elif loglevel == C.LOGWARNING: ltype = 'warning'
        elif loglevel == C.LOGERROR: ltype = 'error'
        

        #msg = d + u" {} {}:{} {}".format(
        msg = u" {} {}:{} {}".format(
            ltype
            ,os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0])
                ,traceback.extract_stack(limit=stacklevel)[0][1]
                ,msg
            )
## cmtrace style
##        if loglevel in [C.LOGNONE,C.LOGNOTICE]: ltype = 1
##        elif loglevel == C.LOGWARNING: ltype = 2
##        elif loglevel == C.LOGERROR: ltype = 3
##        msg = u'<![LOG[{}]LOG]!><time="{}" date="{}" component="{}" context="{}" type="{}" thread="{}" file="{}">'.format(
##                msg
##                ,n.strftime('%H:%M:%S.%f')[:-3]+time.strftime('%z')#time
##                ,n.strftime('%m-%d-%Y') #date
##                , C.addon_id #component
##                , 'context' #context
##                ,ltype #type
##                ,threading.currentThread().native_id #thread
##                ,"{}:{}".format(os.path.basename(traceback.extract_stack(limit=stacklevel)[0][0]), traceback.extract_stack(limit=stacklevel)[0][1])#file
##            )

##        xbmc.log(str(type(msg)) , xbmc.LOGNONE)
        if C.PY2:
            try:
                f.write( d + (msg.rstrip(u"\r\n)") + u"\n").encode('utf8',errors='ignore'))
            except:
                pass
        else:
            f.write( d +  msg.rstrip(u"\r\n)") + u"\n")
        if C.PY3: msg = "{}: {}".format(C.addon_id, msg )
        if C.PY2: msg = "{}: {}".format(C.addon_id, msg.encode('utf-8',errors='ignore') )
        if      loglevel: xbmc.log(msg , loglevel)
        elif     C.DEBUG: xbmc.log(msg , xbmc.LOGNONE)
        else            : xbmc.log(msg)


        
    except:
        traceback.print_exc()
        raise
        pass
    finally:
        f.close()

#__________________________________________________________________________
#
def LogR(msg='', loglevel=None, include_type=False, stacklevel=2):
    if include_type: t = (type(msg), msg)
    else: t = (msg,)
    Log(repr(t), loglevel, stacklevel=stacklevel+1)
#__________________________________________________________________________
# routine for PY2/PY3 compatibility
def s_e(s):
    if C.PY2:
        #change unicode to str or bool,float,int to str
        if type(s) in [str]:
            return s
        elif type(s) in [bool,float,int]:
            return str(s)
        elif s is None:
            return s
        else:
            return s.encode('utf8')
    else:
        if type(s) in [bool,float,int]:
            return str(s)
        elif s is None:
            return s
        else:
            return s
def s_d(s):
    if C.PY2:
        #cast str to unicode
        if s and not isinstance(s, C.text_type):
            return s.decode('utf8')
        else:
            return s
    else:
        return s
    
#__________________________________________________________________________
#
def get_setting(setting_name, auto_convert_to_type=bool):
    raw_setting = C.this_addon.getSetting(setting_name)
##    Log(repr(("get_setting", setting_name, raw_setting)))
    if auto_convert_to_type is bool:
        if raw_setting.lower() in ['true','false']:
            return (raw_setting.lower() == 'true')
        if raw_setting.lower() in ['none']:
            return None
        if raw_setting == '':
            return None
    if auto_convert_to_type is int:
        if not raw_setting: raw_setting = 0
        return int(raw_setting)
    if auto_convert_to_type is float:
        if not raw_setting: raw_setting = 0
        return float(raw_setting)
    if auto_convert_to_type is str:
        return str(raw_setting)
    if auto_convert_to_type is list:
        lis = str(raw_setting).split(',')
        if lis is None: lis = ()
##        Log(repr((type(lis),lis)))
        return lis
##    splitted = repr(auto_convert_to_type).split("','")[0].split("'")[1]
##    Log(repr(setting_name), xbmc.LOGNONE)
##    Log("raw:"+splitted, xbmc.LOGNONE)
    return raw_setting
#__________________________________________________________________________
#
def set_setting(setting_name, setting_value):
    #Log(repr(("set_setting", setting_name,setting_value)))
    C.this_addon.setSetting(id=setting_name, value=str(setting_value))
    
#__________________________________________________________________________
#
def playvid(
    video_url
    , name
    , download = None
    , description = u''
    , playmode_string = None
    , play_profile = None
    , download_filespec = None
    , mode = None #30
    , url_factory = None#''
    , icon_URI = None
    , repeat_when_available = False
    , sub_title_url = None
    , mimetype = None #"video/mp2t"
    , skip_head = False #should not request HEAD for some sites
    ):

##    LogR(sys.argv)
    import player
    player.playvid(
            video_url = video_url
            , name = name
            , download = download
            , description = description
            , playmode_string = playmode_string
            , play_profile = play_profile
            , download_filespec = download_filespec
            , mode = mode
            , url_factory = url_factory
            , icon_URI = icon_URI
            , repeat_when_available = repeat_when_available
            , sub_title_url = sub_title_url
            , mimetype = mimetype
            , skip_head = skip_head #should not request HEAD for some sites
        )

#__________________________________________________________________________
# wrapper to allow cookie extraction from urllib3 proxy/socks requests
class FakeRequest(object):
    def __init__(self, full_url, headers):
        self.full_url = full_url
        self._headers = headers.copy()
    @property
    def headers(self):
        return self._headers
    @property
    def url(self):
        return self.full_url
    def get_full_url(self):
        return self.full_url
    def is_unverifiable(self, *args, **kargs):
        return True
    def get_origin_req_host(self, *args, **kargs):
        return self.full_url   
#__________________________________________________________________________
#
def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=False
            , use_cookies=True
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=15 #seconds
            , sucuri_solved=False
            , method="GET"
            , send_back_response=False
            , auto_encode_content=False
##            , cookie_domain=None
            , size=8192*1000
            , start_point=None
            , preload_content=True
            , cache_duration=C.default_GETHTML_cache_duration #seconds
            ):

    LogR(
            (C.module_name(),locals())
##            ,C.LOGWARNING
        )

##    raise Exception()

    socket.setdefaulttimeout(http_timeout)
    response = None
    try:
        if not url:
            if send_back_redirect == True:
                return '', ''
            return ''

        cache_id = C.addon_id+'_gethtml_'+url
        if  (send_back_response == False) and \
            (cache_duration > 0) and \
            method=="GET" :
            cached_value = global_cache.get(cache_id)
            if cached_value:
                Log('value is cached {}'.format(url)
                    ,C.LOGNONE
                    )
                if send_back_redirect:
                    return cached_value, None
                return cached_value             


        if not Is_Online():
##            LogR('Not online',C.LOGWARNING)
            if send_back_redirect == True:
                return '', ''
            return ''


        if use_cookies:
            cj = cookielib.LWPCookieJar(C.cookiePath)
            try:
                cj.load(ignore_discard=True, ignore_expires=True)
                cj._now = int(time.time()) #module does not set this if I use internal functions
            except:
                cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)
                cj._now = int(time.time())
        else:
            cj = None
            
        stream=False
        response = None
        redirected_url = None

        try:

            if '|' in url:
                headers = dict(urlparse.parse_qsl( str(url.split('|')[1])))
                url = url.split('|')[0]


            if headers is None:
    ##            Log("copying default header dictionary")
                getHtml_headers = C.DEFAULT_HEADERS.copy()
                r_c_u_a = C.USER_AGENT #random.choice(C._USER_AGENTS)
        ##        Log("r_c_u_a={}".format(r_c_u_a), xbmc.LOGNONE)
                getHtml_headers['User-Agent'] = r_c_u_a
        ##        Log("rand choice getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
            else:
                getHtml_headers = headers #headers.copy()
    ##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
                
            if len(referer) > 1:
                getHtml_headers['Referer'] = referer

            if sent_data:
                getHtml_headers['Content-Length'] = str(len(sent_data))

            if start_point and int(start_point) > 0:
                getHtml_headers['Range'] = 'bytes={}-'.format(start_point)


            #
            # I don't know how to use cookieJar with SOCKS proxy
            #
            socks_cookies = ''
            if url:
                this_domain = urlparse.urlparse(url).netloc
            
            temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
            if cj and url:
                for cookie in cj:
                    if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                        socks_cookies += "{}={};".format(cookie.name,cookie.value)
                        temp_cookiejar.set_cookie(cookie)
    ##            for cookie in temp_cookiejar: #verification during development 
    ##               #Log("temp_cookiejar_cookie={}".format(repr(cookie)))
    ##                pass
                if 'Cookie' in getHtml_headers:
                    socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
                if not socks_cookies == '':
                    getHtml_headers['Cookie'] = (socks_cookies).strip(';')


        
    ##       #Log("final getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)
    ##        return "" #getHtml_headers testing/dev

            
            bypass_proxy_list = get_setting('bypass_proxy_list')
            if not bypass_proxy_list: bypass_proxy_list=''
    ##        Log(repr(  (bypass_proxy_list)   ))
            should_bypass_proxy = urlparse.urlparse(url).netloc in (bypass_proxy_list.split(','))

##            Log("ping")
            socks_response = None
            socks_proxy_info = Socks_Proxy_Active()
    ##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
            if (socks_proxy_info['uhp'] in (4,5)) and should_bypass_proxy==False:

                #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
                from urllib3.contrib.socks import SOCKSProxyManager
                socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                if C.certPath: 
                    proxy = SOCKSProxyManager(proxy_url=socks_string, ca_certs=C.certPath)
                else:
                    proxy = SOCKSProxyManager(proxy_url=socks_string)
                
                socks_response = proxy.request(
                    method
                    ,url = url
                    ,body = sent_data
                    ,headers = getHtml_headers
                    ,timeout = http_timeout
                    ,preload_content = preload_content
                    )
                #https://requests.readthedocs.io/en/master/api/
                #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
                
                if preload_content:
                    data = socks_response.data

                redirected_url = socks_response.geturl()
                if not url == redirected_url:
                    Log(repr((url,redirected_url)))
                    Log("redirected_url='{}'".format(redirected_url))
                else:
                    redirected_url = None



            elif (socks_proxy_info['uhp'] <= -0) :

                if (socks_proxy_info['ps'] is not None) and should_bypass_proxy==False:
                    proxy_string = "http://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
                    proxy = ProxyManager(proxy_url=proxy_string, ca_certs=C.certPath)
                else:
                    proxy_string = ''
                    #proxy = PoolManager()
                    proxy = pool_proxy

##                    # forcing TLSv1_1 will allow bypassing
##                    # cloudflare for some site calls, but kodi itself will
##                    # ignore this and the icon lookup will fail(unless you pre-download
##                    # and subsitute icons
##                    # also... other sitess need tls1.2+ ...
##                    import ssl
##                    ctx = ssl.create_default_context()
##                    ctx.options |= ssl.OP_NO_TLSv1_3
##                    ctx.options |= ssl.TLSVersion.TLSv1_1
##                    proxy = PoolManager(ca_certs=C.certPath, ssl_maximum_version=ssl.PROTOCOL_TLSv1_1 )

                    #required to bypass cloudflare for some sites
                    import ssl
                    if C.PY3:
                        client_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                        client_context.set_ciphers('ALL:@SECLEVEL=0')
##                        LogR(client_context.get_ciphers())
                    if C.PY2:
                        client_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
##                        client_context.set_ciphers('ALL')
                   
                    proxy = PoolManager(ca_certs=C.certPath, ssl_context=client_context)


    
##                Log("ping")
##                LogR((method,http_timeout,preload_content))
                response = proxy.request(
                    method
                    ,url = url
                    ,body = sent_data
                    ,headers = getHtml_headers
                    ,timeout = http_timeout
                    ,preload_content = preload_content
                    )
                #https://requests.readthedocs.io/en/master/api/
                #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
##                LogR(http_timeout)
                #make urllib3.response more like requests.response by adding cookiejar and status
                temp_jar = cookielib.LWPCookieJar()
                fake_request = FakeRequest(url, response.getheaders() )
                requests.cookies.extract_cookies_to_jar(temp_jar, fake_request, response)
                response.cookies = temp_jar
                response.status_code = response.status
                


            
                if preload_content:
                    data = response.data
    ##            Log(data[:500]) #dev trim the data to minimize logging

                redirected_url = response.geturl()
                if not (url == redirected_url):
                    if redirected_url and not (redirected_url.startswith('http')):
                        if (response.retries is not None):
                            if len(response.retries.history):
                                redirect_location = response.retries.history[-1].redirect_location
                                redirect_url = response.retries.history[-1].url
                                if not (redirected_url.startswith('http')):
                                    if not (redirect_url.startswith('http')):
                                        redir_domain = urlparse.urlparse(url).scheme + '://' + urlparse.urlparse(url).netloc
                                    else:
                                        redir_domain = urlparse.urlparse(redirect_url).scheme + '://' + urlparse.urlparse(redirect_url).netloc
                                redirected_url = redir_domain + redirected_url
                    if redirected_url and not (redirected_url.startswith('http')):
                        redir_domain = urlparse.urlparse(url).scheme + '://' + urlparse.urlparse(url).netloc
                        redirected_url = redir_domain + redirected_url
                    if (url == redirected_url): redirected_url = None
                    else: Log(u"processed redirected_url={}".format(repr(redirected_url)))
                else:
                    redirected_url = None
                    


            if auto_encode_content: 
                if 'Content-Type' in response.headers: #'text/html; charset=UTF-8'
                    content_type = response.headers['Content-Type']
                    if 'charset=' in content_type:
                        ct = content_type.split('charset=')[1]
                        data = data.decode(ct)
            elif not send_back_response:

                try:
                    data = str(data, 'utf8')
                except:
                    pass #leave it as binary; caller will have to deal with any string conversions
                
            if sucuri_solved == False:
                if 'Server' in response.headers:
                    if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                       #Log(repr(response.status_code))
                        import sucuri
                        if sucuri.SCRIPT_HEADER in data:
                            cookie = sucuri.Set_Cookie(data)
                            cj.set_cookie(cookie)
                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
                            return getHtml(url, referer, headers
                                           , save_cookie, sent_data
                                           , ignore404, ignore403
                                           , send_back_redirect
                                           , http_timeout
                                           , sucuri_solved = True
                                           , method=method
                                           )


            if send_back_response == True:
                if send_back_redirect == True:
                    return response, redirected_url
                else:
                    return response


            if not(response.status_code in  (200,301) ):
                LogR(response.status_code,C.LOGWARNING)
##                LogR(data,C.LOGWARNING)

            
                raise urllib2.HTTPError(
                    url=url
                    , code=response.status_code
                    , msg=response.reason
                    , hdrs=response.headers
                    #, fp=str(response.data,'utf8')
                    #, fp=None
                    #, fp=response.data
                    , fp=response
                    )

            if cj and response and save_cookie:
                r = response
                this_domain = urlparse.urlparse(url).netloc

                if r is not None:
                    for cookie in r.cookies:
##                        Log("r.cookie={}".format(repr(cookie)))
                        if save_cookie:
                            Log('#save as this domain even if cookie was not marked so')
                        cookie.domain = this_domain
                        if not(this_domain.endswith(cookie.domain) or cookie.domain.endswith(this_domain)):
                            Log("warning cookie not for domain '{}'".format(this_domain))
                            pass
                        else:
                            if not cookie.domain:
                                Log('warning cookie.name is blank')
                                pass
                            else:
                                LogR(cookie.name)
                                if type(save_cookie) is tuple:
                                    if cookie.name in save_cookie:
                                        LogR(cookie.name)
                                        cj.set_cookie(cookie)
                                    else:
                                        Log("warning not saving '{}' because it is not in tuple {}".format(cookie.name, repr(save_cookie )))
                                        pass
                                else:
                                    cj.set_cookie(cookie)
                    cj.save(C.cookiePath, ignore_expires=True, ignore_discard=True)

                 

            if send_back_response == True:
                if send_back_redirect == True:
                    return response, redirected_url
                else:
                    return response


            if  (send_back_response == False) and \
                (cache_duration > 0):

                if 'Content-Type' in response.headers:
                    ctype = response.headers['Content-Type'].lower().split('charset=utf-8')[0].rstrip(' ;')
                    if ctype and ctype in [
                                                            'application/xml'
                                                            , 'application/json'
                                                            , 'text/html'
                                                            , 'application/javascript'
                                                            , 'application/x-mpegurl'
                                                            ]:
                        global_cache.set(
                            endpoint = cache_id
                            ,data = data
                            ,expiration = datetime.timedelta(seconds=cache_duration)
                            )
                    else:
                        Log("not caching ctype = {}".format(repr(ctype)))
                        pass
                
            if send_back_redirect == True:
                return data, redirected_url

##            if response:
##                response.close()

            return data


        except requests.HTTPError as e:
            Log("repr(e)='{}'".format(repr(e)))
            raise

        except urllib2.HTTPError as e:
##            import traceback;             traceback.print_stack()
            
##            LogR(dir(e))
##            LogR(e) #code + msg
##            LogR(e.msg, include_type=True)
##            LogR(e.code, include_type=True)
##            LogR(e.fp, include_type=True) #data stream
            data = e.fp.data #decode('utf8')
##            LogR(dir(e.fp), include_type=True)
##            LogR(type(data), include_type=True)
##            LogR(type(e.fp), include_type=True)
##            import io
##            e.fp = io.BytesIO()
##            LogR(type(e.fp), include_type=True)
            
##            LogR(ignore404, include_type=True)
##            LogR(e.file, include_type=True)
##            LogR(e.fp, include_type=True)
##            LogR(e.fp.info, include_type=True)

            if e.code == 503 and 'cf-browser-verification' in data:
                import cloudflare
                data = cloudflare.solve(url, cj, USER_AGENT)
                
            elif e.code == 404 and ignore404 == True:
                Log("404_e='{}'".format(url)) #e.read().decode()))
##                LogR(type(e.fp))
##                LogR(type(e.fp.decode('utf8')))
##                LogR(dir(e.fp),include_type=True)
##                LogR(e.fp               ,include_type=True)
##                LogR(e.fp.decode('utf8'),include_type=True)
##                raise Exception()
                if send_back_redirect == True:
                    return data, redirected_url
                else:
                    return data

            elif e.code == 403 and ignore403 == True:
                Log("403_e='{}'".format(url)) #e.read().decode()))
                if send_back_redirect == True:
                    return None, redirected_url
                else:
                    return None

            elif e.code == 410 :
                Log("410_e='{}'".format(url)) #e.read().decode()))
                if send_back_redirect == True:
                    return data, redirected_url
                else:
                    return data
                
            else:
                raise

        except:
##            pass
            raise

        if send_back_redirect == True:
            return None, None
        else:
            return None

    except Exception:
##        traceback.print_exc()
        #log a lot of info unless it seems to be internal timeout
        if http_timeout > 1:
##            LogR(locals())
            raise
        else:
            Log("internal timeout '{}'".format(url),C.LOGWARNING)
    finally:
        if not send_back_response:
##            LogR(type(response))
            if response:
                response.close()
##                pass
                
#__________________________________________________________________________
#
def postHtml(post_url
             , sent_data=None
             , headers=None
             , compression=True
             , NoCookie=True
             , cache_duration=-1
             , http_timeout=10
             ):
    data = getHtml(url=post_url
                   , headers=headers
                   , save_cookie=(not NoCookie)
                   , sent_data=sent_data
                   , method="POST"
                   , http_timeout=http_timeout
                   , cache_duration=-1)
    return data

#__________________________________________________________________________
#
def headHtml(head_url
             , sent_data=None
             , headers=None
             , compression=True
             , NoCookie=True
             , send_back_redirect=False
             , http_timeout=3
             , cache_duration=-1):
    return getHtml(url=head_url
                   , send_back_redirect=send_back_redirect
                   , headers=headers
                   , save_cookie=(not NoCookie)
                   , method="HEAD"
                   , http_timeout=http_timeout
                   , cache_duration=-1 )

#__________________________________________________________________________
#
def parse_query(query):
    toint = ['page_start', 'page_end', 'download', 'favmode', 'section']
    q = {'mode': C.ROOT_INDEX_INDEX  } #set a default action
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    if not('page' in q)  and ('page_start' in q): q['page'] = q['page_start'] #transitional hack
    return q
#__________________________________________________________________________
#
cp1252 = {
    # from http://www.microsoft.com/typography/unicode/1252.htm
    u"\u20AC": u"\x80", # EURO SIGN
    u"\u201A": u"\x82", # SINGLE LOW-9 QUOTATION MARK
    u"\u0192": u"\x83", # LATIN SMALL LETTER F WITH HOOK
    u"\u201E": u"\x84", # DOUBLE LOW-9 QUOTATION MARK
    u"\u2026": u"\x85", # HORIZONTAL ELLIPSIS
    u"\u2020": u"\x86", # DAGGER
    u"\u2021": u"\x87", # DOUBLE DAGGER
    u"\u02C6": u"\x88", # MODIFIER LETTER CIRCUMFLEX ACCENT
    u"\u2030": u"\x89", # PER MILLE SIGN
    u"\u0160": u"\x8A", # LATIN CAPITAL LETTER S WITH CARON
    u"\u2039": u"\x8B", # SINGLE LEFT-POINTING ANGLE QUOTATION MARK
    u"\u0152": u"\x8C", # LATIN CAPITAL LIGATURE OE
    u"\u017D": u"\x8E", # LATIN CAPITAL LETTER Z WITH CARON
    u"\u2018": u"\x91", # LEFT SINGLE QUOTATION MARK
    u"\u2019": u"\x92", # RIGHT SINGLE QUOTATION MARK
##    u"\u2019": "\u2019".encode('utf8'), # RIGHT SINGLE QUOTATION MARK
    u"\u201C": u"\x93", # LEFT DOUBLE QUOTATION MARK
    u"\u201D": u"\x94", # RIGHT DOUBLE QUOTATION MARK
    u"\u2022": u"\x95", # BULLET
    u"\u2013": u"\x96", # EN DASH
    u"\u2014": u"\x97", # EM DASH
    u"\u02DC": u"\x98", # SMALL TILDE
    u"\u2122": u"\x99", # TRADE MARK SIGN
    u"\u0161": u"\x9A", # LATIN SMALL LETTER S WITH CARON
    u"\u203A": u"\x9B", # SINGLE RIGHT-POINTING ANGLE QUOTATION MARK
    u"\u0153": u"\x9C", # LATIN SMALL LIGATURE OE
    u"\u017E": u"\x9E", # LATIN SMALL LETTER Z WITH CARON
    u"\u0178": u"\x9F", # LATIN CAPITAL LETTER Y WITH DIAERESIS
}

def htmlentitydecode(s):
##    LogR(s,C.LOGWARNING)
    s = C.unescape(s)
##    LogR(s,C.LOGWARNING)
    if C.PY2: s = re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: unichr(name2codepoint[m.group(1)]), s)
    if C.PY3: s = re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: chr(name2codepoint[m.group(1)]), s)
##    LogR(s,C.LOGWARNING)
    return s    

def try_decode(text, encoding="utf-8"):
    '''helper to decode a string to unicode'''
    try:
        return text.decode(encoding, "ignore")
    except Exception:
        return text
def cleantext(text):

    '''normalize string, strip all special chars'''
    text = text.replace('\t','')
    text = text.replace('\n','')

    text = text.strip()
    text = text.rstrip('.')

##    LogR(text)

    text = unicodedata.normalize('NFKD', try_decode(text))
##    LogR(text)

    text = C.unescape(text)
##    LogR(text)
    
    text = text.replace('\\u0026','&')
    text = text.replace('&amp;','&')
    text = text.replace('&colon;',':')
    text = text.replace('&comma;',',')
    text = text.replace('&lowbar;','_')
    text = text.replace('&period;','.')
    text = text.replace('&lbrace;','(')
    text = text.replace('&DiacriticalAcute;','`')
    text = text.replace('&lcub;','{')
    text = text.replace('&rcub;','}')
    text = text.replace('&sol;','/')
    text = text.replace('&lpar;','(')
    text = text.replace('&rpar;',')')
    text = text.replace('&quest;','?')
    text = text.replace('&apos;','\'')
    text = text.replace('&percnt;','%')
    text = text.replace('&num;','#')
##    LogR(text)
    
##    text = unicodedata.normalize('NFKD', try_decode(text))
##    LogR(text)

#    LogR(dir(C.html_parser),C.LOGWARNING)
##    text = htmlentitydecode(text)
##    LogR(text)

    for src, dest in cp1252.items():
        text = text.replace(dest, src )
##    LogR(text)
##    raise Exception()
    return text
#__________________________________________________________________________
#
def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext
#__________________________________________________________________________
#
def Parse_Duration(duration):
    duration=str(duration).lower().strip()
    duration_seconds = 0

    #somethimes will have a dot
    if '.' in duration:
        duration = duration.split('.')[1]
        
    #sometimes format will be hh:mm:ss: normalize it to what I want
    timearr= ['s','m','h']
    if ':' in duration:
        duration_arr = duration.split(':')
        duration = ""
        i = 0
        for duration_elem in reversed(duration_arr):
            duration = duration_elem + timearr[i] + duration
            i = i+1

    duration = duration.replace(' h', 'h ').replace('h', 'h ').replace('min', 'm ').replace(' m', 'm ').replace('m', 'm ').replace(' s', 's ').replace('s', 's ').strip()

    #sometimes format will be Xh Ym Zs
    try:
        duration_arr = duration.split(' ')
        for duration_elem in duration_arr:
            duration_elem = duration_elem.strip()
            if 'h' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('h',''))*3600
            elif 'm' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('m',''))*60
            elif 's' in duration_elem:
                duration_seconds = duration_seconds + int(duration_elem.replace('s',''))
            elif duration_elem:
                try:
                    duration_seconds = duration_seconds + int(duration_elem)
                except:
                    pass
    except:
        Log(repr(duration_arr))
        duration_seconds = 600
        #raise

    return duration_seconds

#__________________________________________________________________________
#
def Set_ListItem_Duration(listitem, duration):
    duration_seconds = Parse_Duration(duration)
    if C.PY2: listitem.setInfo(type="Video", infoLabels={"duration": duration_seconds} )
    if C.PY3:
        listitem.getVideoInfoTag().setDuration(duration_seconds)
##        listitem.getVideoInfoTag().setRating(duration_seconds)
#__________________________________________________________________________
#
def addDownLink(
    name, url, mode
    , uuid = ''
    , iconimage=''
    , desc=''
    , stream=None
    , fav='add'
    , noDownload=False
    , duration=None
    , date=None
    , views=None
    , likes=None
    , play_method=None
    , hq_stream=None
    , return_listitem=False
    , icon_url=''
    , actors_xml = ''
    ):

    if   fav == 'add': favtext = "Add to"
    elif fav == 'del': favtext = "Remove from"
    if not date: date = 0
    if not hq_stream: hq_stream = ''
    else:  hq_stream = str(hq_stream)


    url = s_e(url)
##    xbmc.log(repr(type(name)),C.LOGNONE)
##    xbmc.log(repr(name),C.LOGNONE)
##    xbmc.log(repr(name),C.LOGNONE)
##    name=name.decode('raw_unicode_escape')
    name_e = s_e(name)
##    xbmc.log(repr(name_e),C.LOGNONE)
    desc = s_e(desc)
    iconimage = s_e(iconimage)

##    LogR(uuid)

    u = (
        "{}".format(sys.argv[0])
        + "?url={}".format(quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(quote_plus(iconimage) ) 
        + "&name={}".format(quote_plus(name_e))
        + "&uuid={}".format(quote_plus(uuid))
        )
    
    u = (
        "{}".format(sys.argv[0])
        + "?url={}".format(quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(quote_plus(iconimage) ) 
        + "&name={}".format(quote_plus(name_e))
        + "&hq_stream={}".format(quote_plus(hq_stream)) 
        + "&desc={}".format(quote_plus(desc)) 
        + "&playmode_string={}".format(play_method)
        + "&uuid={}".format(quote_plus(uuid))
        )
    download_xbmc_url = (
        "{}".format(sys.argv[0]) 
        + "?url={}".format(quote_plus(url)) 
        + "&mode={}".format(mode) 
        + "&img={}".format(quote_plus(iconimage) ) 
        + "&name={}".format(quote_plus(name_e))
        + "&hq_stream={}".format(quote_plus(hq_stream)) 
        + "&playmode_string={}".format(play_method) 
        + "&download=1"
        + "&icon_URI={}".format(quote_plus(iconimage) )
        + "&uuid={}".format(quote_plus(uuid))
        )
    favorite = (
        "{}".format(sys.argv[0]) 
        + "?url={}".format(quote_plus(url)) 
        + "&mode={}".format(C.FAVORITES_MODE) 
        + "&img={}".format(quote_plus(iconimage) ) 
        + "&name={}".format(quote_plus(name_e))
        + "&hq_stream={}".format(quote_plus(hq_stream)) 
        + "&fav={}".format(fav) 
        + "&favmode={}".format(mode)
        + "&desc={}".format(quote_plus(desc))
        + "&icon_url={}".format(quote_plus(icon_url))
        + "&uuid={}".format(quote_plus(uuid))
        )
    play_with_method = (
        "{}".format(sys.argv[0])
        + "?url={}".format(quote_plus(url))
        + "&mode={}".format(mode)
        + "&img={}".format(quote_plus(iconimage) )
        + "&name={}".format(quote_plus(name_e))
        + "&hq_stream={}".format(quote_plus(hq_stream))
        + "&playmode_string={}"
        + "&play_profile={}"
        + "&uuid={}".format(quote_plus(uuid))
        )

    
    if len(iconimage) < 1:                 iconimage = C.default_icon
    if not '|' in iconimage and 'http' in iconimage: iconimage = "{}{}".format(iconimage, Header2pipestring())

    if C.xbmc_version[0] > 17 :
        liz = xbmcgui.ListItem(
            label = name
            , offscreen=True #kodi 18+
            )
    else:
        liz = xbmcgui.ListItem(
            label = name
##            , offscreen=True #kodi 18+
            )
        
    liz.setArt(
        { 'thumb': iconimage #must include thumb to avoid error log messages
         , 'fanart': iconimage #must include fanart for infowall view
          }
        ) 

    if duration:
        Set_ListItem_Duration(liz, duration) #2021-01 k17.6 setting duration seems to cause page to be reloaded after play stops 
    else:
        Set_ListItem_Duration(liz, 0)
        
    liz.setMimeType('video/mp4')
    liz.setContentLookup(False)           
    #  if 'IsPlayable' true, setResolvedUrl can work along with Playmedia
    #  if 'IsPlayable' true, may trigger a container refresh IF endofdirectory(succeeded=true_
    #  if 'IsPlayable' false, then 'mark as watched' will not work
    liz.setProperty('IsPlayable', 'false') 
##    liz.setProperty('IsPlayable', 'true')
##    
    if stream:
        LogR(stream)
##        liz.setProperty('IsPlayable', 'true') #can't set this and use playlists at same time

    if len(desc) < 1:  desc = ''

    if C.PY2:
        liz.setInfo(
            type="Video"
            , infoLabels={
                "title": name
                ,"plot": desc
                ,"plotoutline": desc
                }
            )
    if C.PY3:
        liz.getVideoInfoTag().setTitle(name)
        liz.getVideoInfoTag().setPlot(name+'[CR][CR]'+desc)
        liz.getVideoInfoTag().setMpaa("R")
        liz.getVideoInfoTag().setMediaType('episode') #required for skin to show 'cast'
        vsd = xbmc.VideoStreamDetail()
        vsd.setCodec('h264')
        liz.getVideoInfoTag().addVideoStream(vsd)
        actors = []
        for actor_info in actors_xml:
            dom = minidom.parseString("<a>"+actor_info+"</a>")
            name = dom.getElementsByTagName('name')[0].lastChild.data
            actors.append(xbmc.Actor(name=name
    ##                                 ,thumbnail=thumbnail
    ##                                 ,role=role
    ##                                 ,order=order
                                     ))
        liz.getVideoInfoTag().setCast(actors)



    contextMenuItems = []

    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
        
        contextMenuItems.append(
            (
            "[COLOR {}]{} favorites[/COLOR]".format(C.refresh_text_color, favtext)
            , "RunPlugin({})".format(favorite)
            )
        )
        if fav == 'del':
            favorite = sys.argv[0]
            favorite += "?url={}".format(quote_plus(url)) 
            favorite += "&mode={}".format(C.FAVORITES_MODE) 
            favorite += "&img={}".format(quote_plus(iconimage) ) 
            favorite += "&name={}".format(quote_plus(name_e)) 
            favorite += "&hq_stream={}".format(quote_plus(hq_stream)) 
            favorite += "&fav={}".format('refresh') 
            favorite += "&favmode={}".format(mode)
            favorite += "&desc={}".format(quote_plus(desc)) 
            favorite += "&icon_url={}".format(quote_plus(icon_url))
            favorite += "&uuid={}".format(quote_plus(uuid))
            contextMenuItems.append(
                (
                "[COLOR {}]{}[/COLOR]".format(C.refresh_text_color, 'Refresh')
                , "RunPlugin({})".format(favorite)
                )
            )
            favorite = (
                "{}".format(sys.argv[0]) 
                + "?url={}".format(quote_plus(url)) 
                + "&mode={}".format(C.FAVORITES_MODE) 
                + "&img={}".format(quote_plus(iconimage) ) 
                + "&name={}".format(quote_plus(name_e)) 
                + "&hq_stream={}".format(quote_plus(hq_stream)) 
                + "&fav={}".format('rename') 
                + "&favmode={}".format(mode)
                + "&desc={}".format(quote_plus(desc)) 
                + "&icon_url={}".format(quote_plus(icon_url))
                )
            favorite += "&uuid={}".format(quote_plus(uuid))
            contextMenuItems.append(
                (
                "[COLOR {}]{}[/COLOR]".format(C.refresh_text_color, 'Rename')
                , "RunPlugin({})".format(favorite)
                )
            )

    max_rez = (C.addon.getSetting("max_rez").lower())
    if not max_rez: max_rez = ('480','720','1080')
    else: max_rez = max_rez.split(',')

    if play_method in {C.PLAYMODE_VARIABLE, None} :
        for rez in max_rez:
            contextMenuItems.append(
                (
                "[COLOR {}]{} {}[/COLOR]".format(C.highlight_text_color, 'Play Max',rez)
                , "PlayMedia({})".format(play_with_method.format(rez, ''))
                )
            )
        
    if play_method in {C.PLAYMODE_INPUTSTREAM, C.PLAYMODE_F4MPROXY, C.PLAYMODE_DIRECT, '', None} :

        contextMenuItems.append(
            (
            "[COLOR {}]{} Direct[/COLOR]".format(C.time_text_color, 'Play')
            , "PlayMedia({})".format(play_with_method.format(C.PLAYMODE_DIRECT, 0))
            )
        )
        contextMenuItems.append(
            (
            "[COLOR {}]{} Inputstream[/COLOR]".format(C.time_text_color, 'Play')
            , "PlayMedia({})".format(play_with_method.format(C.PLAYMODE_INPUTSTREAM, 0))
            
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_01_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_01"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_02_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_02"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_03_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_03"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_04_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_04"))
            )
        )
        contextMenuItems.append( 
            ( 
            "[COLOR {}]Play {}[/COLOR]".format(C.time_text_color, C.addon.getSetting("profile_05_alias"))
            ,"PlayMedia({})".format(play_with_method.format(C.PLAYMODE_F4MPROXY, "profile_05"))
            )
        )        
    if noDownload == False:
        contextMenuItems.append(
            (
                "[COLOR {}]Download[/COLOR]".format(C.search_text_color)
                ,"RunPlugin({})".format(download_xbmc_url)
            )
        )


####    #having trouble keeping items marked as watched because
####        sometimes I am downloading locally first
####        simetimes there are some html headers that are prepended
####    #now I can just use uuid and a database call
##    favorite = sys.argv[0]
##    favorite += "?mode={}".format(C.MARK_AS_WATCHED) 
##    favorite += "&uuid={}".format(quote_plus(uuid))
##    contextMenuItems.append(
##        (
##            "[COLOR {}]Mark as Watched[/COLOR]".format(C.search_text_color)
##            ,"RunPlugin({})".format(favorite)
##        )
##    )


    liz.setProperty('ForceResolvePlugin', 'true') 
    liz.addContextMenuItems(contextMenuItems)
##    if not(play_method in {C.PLAYMODE_NO_OPTIONS}) :
##        
##    else:
##        liz.addContextMenuItems([], replaceItems=True)


##    Log(u"u={}".format(repr(u)))
    if return_listitem:
        return(u, liz, False)
    else:
        xbmcplugin.addDirectoryItem(
            handle=C.addon_handle
            , url=u,
            listitem=liz
            , isFolder=False
            )
#__________________________________________________________________________
#
my_re = re.compile(r'%[0-9A-Z]{2}')  # pattern
def my_quote_plus(s): #used when I want any hex value to be lower case
    return my_re.sub(lambda matchobj: matchobj.group(0).lower()
                     ,quote_plus(s)
                     )
def my_quote(s): #used when I want any hex value to be lower case
    return my_re.sub(lambda matchobj: matchobj.group(0).lower()
                     ,quote(s, safe=')(')
                     )
    
#__________________________________________________________________________
#
def addDir(
      name, url, mode
    , bulk_operation=False
    , channel=None
    , iconimage=None
    , page_start=None
    , page_end = None
    , section=None
    , keyword=None #""
    , Folder=True
    , duration=None
    , title=None
    , possible_recurse_depth=0
    , end_directory=True
    , contextMenu=None
    , contextMenuReplace=True
    , return_listitem=False
    , return_url=False
    , uuid=""
    ):

##    LogR(locals()
##         ,C.LOGWARNING
##         )
    if page_start is None: page_start='1'
    if page_end is None: page_end=page_start

    #normally the order words of u should not matter; but some later code requires me to match the order of kodi
    if keyword: k = "&keyword=" + quote(keyword)
    else:       k = "&keyword"

    u = sys.argv[0]
    u +=  "?bulk_operation=" + str(bulk_operation)
    u +=  "&channel=" + str(channel) 
    u +=   "&end_directory=" + str(end_directory) 
    u +=   k 
    u +=   "&mode=" + str(mode)
    try:
        u +=   "&name=" + my_quote(name)
    except KeyError:
        if C.PY2: #quote can't handle unicode; the return must un-encode
            u +=   "&name=" + my_quote(name.encode('utf8'))
    u +=   "&page_end=" + str(page_end) 
    u +=   "&page_start=" + str(page_start) 
    u +=   "&section=" + str(section) 
    u +=  "&url=" + my_quote_plus(url)

    if return_url:
        return u

    page_end = int(page_end)
    page_start = int(page_start)

    if not(iconimage) or (len(iconimage) < 1) or not(os.path.exists(iconimage)):
        iconimage = C.default_icon

    if not '|' in iconimage and 'http' in iconimage:
        #sometimes a site will accidentally(?) add non-ascii to web urls
        try: 
            iconimage = u"{}{}".format(iconimage, Header2pipestring())
        except UnicodeDecodeError:
            LogR(iconimage)
            LogR(iconimage.decode('ascii','ignore'))
            iconimage = iconimage.decode('ascii','ignore')
            iconimage = u"{}{}".format(iconimage, Header2pipestring())
       

    if C.xbmc_version[0] > 17 :
        liz = xbmcgui.ListItem(
            label = name.encode('utf8')
            , offscreen=True #kodi 18+
            )
    else:
        liz = xbmcgui.ListItem(
            label = name #.encode('utf8')
            )
##    LogR(name)
    
    liz.setProperty('IsPlayable', 'false')

    liz.setArt(
        { 'thumb': iconimage
##          , 'icon': iconimage
##          , 'fanart': iconimage
##          , 'poster': iconimage
          }
        ) #must include thumb to avoid error messages

    if duration:
        Set_ListItem_Duration(liz, duration)
    else:
        Set_ListItem_Duration(liz, 0)

    #setting type = music instead of video means no icon to the right of the label
    if title:
        if C.PY2: liz.setInfo(type="Video", infoLabels={"Title": title})
        if C.PY3: liz.getVideoInfoTag().setTitle(title)

    contextMenuItems = []

    if name.startswith(C.STANDARD_MESSAGE_NEXT_PAGE.format(page_start)):
        jump_sizes = [5,50,100,250,1000]
        for jump_size in jump_sizes:
            u2 = u.replace("&page_start=" + str(page_start), "&page_start=" + str(int(page_start)+jump_size))
            contextMenuItems.append(
                    (
                        "[COLOR {}]Jump {} pages[/COLOR]".format(C.time_text_color, jump_size)
                         , "ActivateWindow(Videos,{},return)".format(u2) #can't go back with activatewindow
                    )
                )

    if keyword and not("next page" in name.lower()):
        keyw = (
            sys.argv[0] +
            "?mode=" + C.DELETE_KEYWORD +
            "&keyword=" + quote_plus(keyword) +
            "&uuid=" + quote_plus(uuid)
            )
        #if not contextMenuItems: contextMenuItems = []
        contextMenuItems.append(
                (
                    "[COLOR {}]Remove keyword[/COLOR]".format(C.time_text_color)
                    , "RunPlugin({})".format(keyw)
                )
            )
        
    if possible_recurse_depth:
        u2 = u.replace(   "&page_start={}&".format(page_start)
##                        , "&page_start={}&".format(page_start-1)  #include the page we are on
                        , "&page_start={}&".format(page_start)  #do NOT include the page we are on
                        )
        u2 = u2.replace(  "&page_end={}&".format(page_end)
                        , "&page_end={}&".format(page_start + possible_recurse_depth - 1)
                        )
        contextMenuItems.append( (
            "[COLOR {}]Recurse to Page {}[/COLOR]".format(C.search_text_color, page_start + possible_recurse_depth - 1)
            , "ActivateWindow(Videos,{},return)".format(u2)
            )  )
        contextMenuReplace=False

    if contextMenu:
        contextMenuItems = contextMenu

    if contextMenuItems:
        liz.addContextMenuItems(contextMenuItems, replaceItems=contextMenuReplace)

    if return_url:
        return u
    elif return_listitem:
        return(u, liz, Folder)
    else:
        xbmcplugin.addDirectoryItem(
            handle=C.addon_handle
            , url=u
            , listitem=liz
            , isFolder=Folder
            )
#__________________________________________________________________________
#
def Get_Sites(filter_category=None, icon_function=None):
    
    
    libDir = os.path.join(C.resDir, 'lib')
    sitesDir = os.path.join(libDir, 'sites')
    files = []
##    for f1 in os.listdir(sitesDir):
    for root,dirs,filelist in os.walk(sitesDir):
        for f1 in filelist:
            if f1.endswith('.py'): # or f1.endswith('.pyc')) :
                if not f1.startswith('_') :
##                    Log(f1)
##                    LogR(root)
##                    f2 = f1[:-(len(f1.split('.')[-1])+1)]
                    files.append( root.replace(libDir+os.sep,'').replace(os.sep,".") +'.'+ f1)
                    #break
    site_list = {}
    for f in files:
        if not f in site_list:
            site_list[f ] = ''

    sorted_site_list = sorted(site_list.items(), key=operator.itemgetter(0))

    sorted_dict = collections.OrderedDict(sorted_site_list)


    aa = None
    for site in sorted_dict:
##        Log(site)
        if aa is None:
            try:
                try:

                    sitename = site.split(os.sep)[-1].removesuffix('.py')
##                    Log(sitename)

                    try:
##                        module = importlib.import_module('sites.'+sitename)
                        module = importlib.import_module(sitename)
                    except SyntaxError:
                        raise
                    except:
##                        traceback.print_exc()
                        raise
                        continue

                    
                    if hasattr(module, "website"):
                        module = module.website

                    sitename = sitename.split('.')[-1]
                    if filter_category:
                        if module.LIST_AREA == filter_category:
                            yield (
                                module.FRIENDLY_NAME
                                ,module.ROOT_URL
                                ,module.MAIN_MODE
                                ,os.path.join(C.imgDir, sitename + '.png')
                                )
                    elif icon_function==True:
                        aa = (
                            yield (
                                module
                                ,module.MAIN_MODE
                                ,sitename
                                )
                              )
                        if aa is not None:
                            break
                    else:
                        aa = (yield (sitename, module))
                        if aa is not None:
                            break
                except StopIteration:
                    pass
                except GeneratorExit:
                    return
                    pass
                except:
                    Log('failed Get_Sites for {}'.format(site), C.LOGWARNING)
##                    traceback.print_exc()
                    raise
            except Exception as ex:
                LogR(ex,C.LOGERROR)
##                traceback.print_exc()
                raise

#__________________________________________________________________________
#
def Notify(header=None, msg='', duration=4000, sound=False, allow_all_thread_names=False):
##    LogR(locals())
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound, allow_all_thread_names=allow_all_thread_names)
def notify(
    header=None
    , msg=''
    , duration=C.DEFAULT_NOTIFY_TIME
    , sound=False
    , allow_all_thread_names=False
    ):
    try:
        debug = (C.this_addon.getSetting('debug').lower() == "true")
        if allow_all_thread_names or \
           (threading.current_thread().name == "MainThread"):
            if header==None or header == '':
                if len(Clean_Filename(msg)) > 29:
                    header = msg[0:29] #header will begin scrolling after 29
                    msg = msg[-29:]
                else:
                    header=msg
            xbmcgui.Dialog().notification(
                header, msg, C.default_icon, duration, sound=False
                )
            LogR( (header,msg), C.LOGNONE)
        elif debug:
            Log( msg, C.LOGWARNING)
    except:
        traceback.print_exec()
#__________________________________________________________________________
#
def Header2pipestring(header = C.DEFAULT_HEADERS):
    if not header or len(header)<1: header = C.DEFAULT_HEADERS
    q = "|{}".format( urlencode(header)  )
    return q
#__________________________________________________________________________
#
def add_sort_method():
    try:
        sort_order = int(C.addon.getSetting('video_sort_by'))
    except:
        sort_order = -1
    if sort_order == 2:
        sort_order = xbmcplugin.SORT_METHOD_DURATION
##        sort_order = xbmcplugin.SORT_METHOD_VIDEO_RATING
    elif sort_order == 1:
        sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
    elif sort_order == 4:
        sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
    elif sort_order == 5:
        sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
    else:
        sort_order = xbmcplugin.SORT_METHOD_UNSORTED


    xbmcplugin.addSortMethod(
        C.addon_handle
        ,sort_order #use preferred method first
        ) 
    xbmcplugin.addSortMethod(C.addon_handle #use the hidden string I insert for sorting
                             ,xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE
                             )
    xbmcplugin.addSortMethod(C.addon_handle
                             ,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
                             )
    xbmcplugin.addSortMethod(C.addon_handle
                             ,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED
                             )
    xbmcplugin.addSortMethod(C.addon_handle
                             ,sortMethod=xbmcplugin.SORT_METHOD_DURATION
##                             ,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING
                             )
    xbmcplugin.addSortMethod(C.addon_handle
                             ,xbmcplugin.SORT_METHOD_SONG_RATING
                             #,labelMask="%T. %H"
##                             ,'%O,%O'
                             )

#__________________________________________________________________________
#
def endOfDirectory(
      cacheToDisc=False
    , succeeded=True  #True may trigger unwanted container refresh for non-folders, but should be try for Folders
    , end_directory=True
    , allow_sorting=True
    , set_default_view=None
    , updateListing=False #controls 'back button'; when false; back will remmeber previous folder
    ):

    try:

        if not end_directory :
            return

        #foce kodi to respect cache cacheToDisc by sleeping
        if cacheToDisc:
            Log('warning end-of-directory cache hack'); Sleep(700)
##        LogR(traceback.extract_stack())


        #one comment says set to cacheToDisc=False would allow that addon can
        #  set the value without a 'sleep'; 2025-04 testing shows this not to be true
        if allow_sorting == True:
            add_sort_method()
            pass

        if sys and sys.argv and len(sys.argv)>1 and sys.argv[1]:
            C.addon_handle = int(sys.argv[1])

            xbmcplugin.endOfDirectory(
                C.addon_handle
                , succeeded=succeeded
                , cacheToDisc=cacheToDisc
                , updateListing=updateListing
                )

##        return
    
        #set default view
        def dbviewDB(path):
            viewDB = sqlite3.connect(C.viewDB)
            query = "SELECT viewMode FROM view WHERE path LIKE ?;"
            params = (path,)
            result = viewDB.execute(query,params)
            r = result.fetchone()
            return r is not None
        def dbwriteDB(path):
            #kodi will not automatically save the view change #2025-05
            #   during the SetViewMode call.  To prevent back-and-forth
            #   I will insert a db entry.  The data may not be correct
            #   the path will be enought to prevent my SetViewMode call
            viewDB = sqlite3.connect(C.viewDB)
            query = "INSERT INTO view (path,window,viewmode,sortmethod,sortorder,sortattributes,skin) values (?,?,?,?,?,?,?);"
            #todo: don't hardcode skin name
            params = (path,10025,131123,9,1,0,'skin.lyrebird')
            params = (path,10025,131123,9,1,0,'skin.mimic.lr')
            LogR((query,params))
            result = viewDB.execute(query,params)
            r = result.fetchone()
##            LogR(r, C.LOGWARNING)
            viewDB.commit()

        #todo: don't check if current skin has setting, instead of any skin
        if set_default_view and ('path' in set_default_view) and set_default_view['path']:
            if dbviewDB(set_default_view['path']):
                Log('view already set')
                pass
            else:
                Log("setting view for path '{}'".format(set_default_view['path']))
                #sleep required for sort changes to work; 50ms may be too slow for some systems
                if 'sleeptime' in set_default_view:
                    s = int(set_default_view['sleeptime'])
                    if not(s in range(50,2000)): s = 500 #make sure not too long
                else: s = 700
##                LogR(('sleep',s))
                xbmc.sleep(s)
                # Note: xbmcplugin.SORT_METHOD_DURATION
                #   and "SortUtils.h".SortByTime values are different
                
##                LogR(xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE, C.LOGERROR)
##                LogR(set_default_view, C.LOGERROR)
                if set_default_view['viewmode'] == '61':
                    set_default_view['sortmethod']=29#xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE
                    del set_default_view['sortdirection']
                LogR(set_default_view, C.LOGWARNING)
                if 'sortmethod' in set_default_view:
##                    Log("#sort by time/duration")
                    xbmc.executebuiltin("Container.setSortMethod(%s)" % set_default_view['sortmethod'])  
                if 'sortdirection' in set_default_view: #can only be called after sortmethod
                    xbmc.executebuiltin('Container.SetSortDirection')           
                if 'viewmode' in set_default_view: #51=infowall, 61=infowide
                    xbmc.executebuiltin("Container.SetViewMode(%s)" % set_default_view['viewmode']) 
                #save changes immediately [or else changes are saved after navigating out]
                dbwriteDB(set_default_view['path'])
##                xbmc.executebuiltin("Container.Update(%s)" % set_default_view['path']) #2025 this forces a refresh
    except:
        raise
    
#__________________________________________________________________________
#
def SortVideos(sources
               , download
               , vid_res_column=1
               , substitute_char='}'
               , substitute_res='720'
               , max_video_resolution = C.maximum_video_resolution
               ):

    LogR(
        (C.module_name(), locals())
        ,C.LOGWARNING
        )
   
##    global maximum_video_resolution
    if max_video_resolution:
        maximum_video_resolution = int(max_video_resolution)
    else:
        maximum_video_resolution = C.maximum_video_resolution
##    LogR(maximum_video_resolution)

    try: 
        #sometimes we can't get accurate resolutions and end up with a characters instead...
        # e.g. "http://video.mp4","}"     instead of   "http://video.mp4","480p"

##        Log("sources='{}', download='{}'".format(sources,download))

##  2026-04 Any download-related rez limits must be done before this
##        if (bool(download) == True):
##            maximum_video_resolution = 99999 # allow max resolution on download
####        Log("maximum_video_resolution='{}'".format(maximum_video_resolution))

        s3840p_string = "3840p"
        s2160p_string = "2160p"
        s1440p_string = "1440p"
        s1080p_string = "1080p"
        s720p_string = "720p"
        s540p_string = "540p"
        s480p_string = "480p"
        s360p_string = "360p"
        s320p_string = "320p"


        #report on what was the maximum resolution available; just for fun
        try:
            videos = sorted(sources
                            , key=lambda tup: int(
                                                     tup[vid_res_column].lower() \
                                                     .replace('p60','p') \
                                                     .replace('720',s720p_string) \
                                                     .replace(substitute_char   ,substitute_res)\
                                                     .replace('720' ,'721')\
                                                     .replace('320' ,'321')\
                                                     .replace('2160',s2160p_string)\
                                                     .replace('multi',s2160p_string)\
                                                     .replace('7p'  ,s2160p_string)\
                                                     .replace('3840',s3840p_string)\
                                                     .replace('20p' ,s3840p_string)\
                                                     .replace('1440',s1440p_string)\
                                                     .replace('2k',  s1440p_string)\
                                                     .replace('uhd 4k'  ,s3840p_string)\
                                                     .replace('4k'  ,s3840p_string)\
                                                     .replace('1080',s1080p_string)\
                                                     .replace('540' ,s540p_string )\
                                                     .replace('480' ,s480p_string )\
                                                     .replace('320' ,s320p_string )\
                                                     .replace('p','')\
                                                     .replace('(','')\
                                                     .replace(')','')\
                                                     .replace('hd','')\
                                                     .replace('@60fs','')
                                                     )
                            , reverse=True)
##            LogR(videos)

            if len(videos) > 1:
                if vid_res_column == 1:
                    max_avail_res = videos[0][1]
                else:
                    max_avail_res = videos[0][0]
            else:
                max_avail_res = 'unknown'
        except:
            traceback.print_exc()
            max_avail_res = 'unknown'
            pass
        
        Log("Best quality for this item is {}".format(max_avail_res))
        Log("Worst quality for this item is {}".format(videos[-1][vid_res_column]  ))

        #change/poison these subst strings so that they can't be matched
        #   poison values must be less than maximum_video_resolution
        #   poison are chosen so that the highest value
        #      
        if maximum_video_resolution < 3840:  s3840p_string = "11" 
        if maximum_video_resolution < 2160:  s2160p_string = "12"
        if maximum_video_resolution < 1440:  s1440p_string = "13"
        if maximum_video_resolution < 1080:  s1080p_string = "14"
        if maximum_video_resolution < 720:    s720p_string = "15"
        if maximum_video_resolution < 540:    s540p_string = "16"
        if maximum_video_resolution < 480:    s480p_string = "17"
        if maximum_video_resolution < 360:    s360p_string = "18"
        LogR((maximum_video_resolution
              , s3840p_string
              , s2160p_string
              , s1440p_string
              , s1080p_string
              , s720p_string
              , s540p_string
              , s480p_string
              , s360p_string
              )
             )

        ## the list of videos is a bunch of urls such as xxx\360.mp4
        ## i use a lambda(just for ?fun?) to split out the numeric
        ##    resolution and the reverse sort it;
        ## the best resolution should end up on top
        ## the 720 is replaced with 721 so that the number ending
        ##    20 does not match other possible strings the site may use to
        ##    define ultra resolutions
        ## the letter p is removed so that we can convert to integer
        ##    and avoid the '720 is better 1080' situation if it were chars
        ## the higher resolutions, when we have been told not to use them,
        ##   are replaced with lower numbered strings 

        try:
            videos = sorted(
                sources
                , key=lambda tup: int(
                     tup[vid_res_column].lower() \
                     .replace('p60'  ,'p') \
                     .replace('720'  ,s720p_string) \
                     .replace(substitute_char   ,substitute_res)\
                     .replace('720'  ,'721')\
                     .replace('320'  ,'321')\
                     .replace('2160' ,s2160p_string)\
                     .replace('multi',s2160p_string)\
                     .replace('7p'  ,s2160p_string)\
                     .replace('3840',s3840p_string)\
                     .replace('20p' ,s3840p_string)\
                     .replace('1440',s1440p_string)\
                     .replace('2k',  s1440p_string)\
                     .replace('uhd 4k'  ,s3840p_string)\
                     .replace('4k'  ,s3840p_string)\
                     .replace('1080',s1080p_string)\
                     .replace('540' ,s540p_string )\
                     .replace('480' ,s480p_string )\
                     .replace('320' ,s320p_string )\
                     .replace('p','')\
                     .replace('(','')\
                     .replace(')','')\
                     .replace('hd','')\
                     .replace('@60fs','')
                     )
                , reverse=True
                )
        except:
            videos = None
            raise

##        Log("videos='{}'".format(videos))
        if len(videos) < 1:
            return None
        if vid_res_column == 1:
            video_url = videos[0][0]
        else:
            video_url = videos[0][1]
        video_url = s_e(video_url)

    except Exception as ex:
        LogR(ex)
        traceback.print_exc()
        video_url = None

    LogR(video_url)
##    raise Exception()
    return video_url
    
#__________________________________________________________________
#
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=10):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
    try:
        while num > 0: #used to include an 'abort requested' check, but but that caused problems
            if monitor.abortRequested():
                Log('sleep abortRequested',stacklevel=3)
                return
            sleep_interval = min(check_interval, num)
            time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
            num = num - check_interval
    except SystemExit: #common when closing app
        pass
    
#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None
    proxy_info = {}

    def Get_Setting_Val(setting):
        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"' +
                                  setting + '"},"id":1}')
        return json.loads(val)['result']['value']
    
    try:
        usehttpproxy = Get_Setting_Val('network.usehttpproxy')
        if usehttpproxy and str(usehttpproxy).lower()=='true':
            httpproxytype = Get_Setting_Val('network.httpproxytype') #= get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = Get_Setting_Val('network.httpproxyserver') #= get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = Get_Setting_Val('network.httpproxyport') #= get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = Get_Setting_Val('network.httpproxyusername') #= get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = Get_Setting_Val('network.httpproxypassword') #= get_gui_setting(guisettings_xml, 'httpproxypassword')

    except:
        traceback.print_exc()
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
    return proxy_info
#__________________________________________________________________
#
def RandomNumber(return_integer=True,length=18):
    nc_string = str(random.random())
    if return_integer:
        nc_string = nc_string.split('.')[1]
    while len(nc_string) < length:
        nc_string += str(random.randint(10,99))
    if len(nc_string) > length:
        nc_string = nc_string[0:length]
    return nc_string
#__________________________________________________________________
#
def Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode):
    #helper function to make code look smaller
    # check for a minimum length; raise error if necessary; add item if not enough
    if len(info) < 1:
        label = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "No more items")
        if not keyword == '':
            label += " for [COLOR {}]{}[/COLOR]".format(C.refresh_text_color,keyword)
        label +=  " on '{}'".format(ROOT_URL)
        addDir(
            name=label
            ,url=C.DO_NOTHING_URL
            ,mode=MAIN_MODE
            ,iconimage=C.not_found_icon
            ,end_directory=False
            ,Folder=False
            )
        if testmode:
            raise OSError    
#__________________________________________________________________
# this is a helper function to make code look smaller
def Initialize_Common_Icons(
      url
    , keyword
    , SEARCH_URL
    , SEARCH_MODE
    , page_start
    , page_end
    , first_page = 1
    , recurse_depth = C.DEFAULT_RECURSE_DEPTH
    , bulk_operation = False
    , end_directory = False  
    ):

##    LogR(locals())

    max_search_depth = C.DEFAULT_RECURSE_DEPTH

    if bulk_operation:
        end_directory = False

    #todo : no distractions! change this after finishing off other stuff  2025-05
    #issue: after 'search or search recursive', there is a Next, but no Search link
    #       because Search() has told List() that (end_directory=False)
    #             because Search is supposted to perform end_directory
    if (not bulk_operation) and end_directory and SEARCH_URL:
        addDir(
            name=C.STANDARD_MESSAGE_SEARCH
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon
            ,page_start=first_page
            ,page_end=first_page
            ,end_directory=False
            ,bulk_operation=bulk_operation
            )
        addDir(
            name=C.STANDARD_MESSAGE_SEARCH_RECURSIVE
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=C.search_icon
            ,page_start=first_page
            ,page_end=first_page + recurse_depth
            ,end_directory=False
            ,bulk_operation=bulk_operation
            )
    else:
        LogR((" Initialize_Common_Icons - no extra search links addded for", end_directory,SEARCH_URL))
        

    if ('{}' in url) and page_start is not None:
        list_url = url.format(page_start)
    else:
        list_url = url


##    LogR(locals())
    return list_url
#__________________________________________________________________
#
def Normalize_HD_String(hd):
    hd = hd.lower()
    if   ('2160'           in hd
          or 'uhd'         in hd
          or '4k'          in hd
          or '2k'          in hd
          or '1440'        in hd): hd = C.STANDARD_MESSAGE_UHD
    elif ('class="fullhd"' in hd
          or 'fullhd'      in hd
          or 'full_hd'     in hd
          or    'fhd'      in hd
          or '1080'        in hd): hd = C.STANDARD_MESSAGE_FHD
    elif (   'class="hd"'  in hd
          or 'hd'          in hd
          or 'icon-hd'     in hd
          or '720'         in hd): hd = C.STANDARD_MESSAGE_HD
    else:
##                                LogR(hd, C.LOGERROR)
                                hd = C.STANDARD_MESSAGE_NOHD

    return hd
#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True, delete_first_color=False):
    if not s: return ''
    s = s.strip('\r')
    if not isinstance(s, C.text_type):
##        Log('not unicode yet')
##        Log(repr(s))
        s = s.decode('utf8')
##        Log(repr(s))
    if delete_first_color:
        s = (re.sub(r'(?i)\[cOLOR \w+?\].+?\[\/Color\]','',s))
    s = (re.sub(r'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(r'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(r'(?i)\[\/Color\]','',s))
    #s = unicodedata.normalize('NFKD', s).encode("utf8", "ignore")
    s = unicodedata.normalize('NFKD', try_decode(s))
##    s = unicode(s.encode("utf8"), 'utf8')
##[\[\] ,\'\.\&\_\-]
## orignally only allow these     s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_\-]',' ',s))
##    s = (re.sub(u'(?is)[\?]',u'Â¿',s)) #this symbol is closest I can think of to subsitute
    s = (re.sub(r'(?is)[\?]',C.QUESTION_MARK_SUBSTITUTE,s)) #this symbol is closest I can think of to subsitute
    if include_square_braces: #permit_square_braces
        s = (re.sub(r'(?is)[    \\\/\:\*\"\<\>\|]',' ',s))
    else:
        s = (re.sub(r'(?is)[\[\]\\\/\:\*\"\<\>\|]',' ',s))
    while '  ' in s:
        s = s.replace('  ', ' ')
    s = s.strip()
    LogR(s, C.LOGINFO)
    return s
#__________________________________________________________________________
#
class Progress_Dialog(object):
    import threading, xbmcgui
    def __init__(
        self
        , title
        , message
        ):
        if threading.current_thread().name != "MainThread":
            self.dialog_progress = None
        self.dialog_progress = xbmcgui.DialogProgress()
        self.dialog_progress.create(title, message)
        self.percent = 0.01
        
    def iscanceled(self):
        if self.dialog_progress:
            return self.dialog_progress.iscanceled()
        else:
            return True
    def close(self):
        if not self.dialog_progress: return
        self.dialog_progress.close()
        self.dialog_progress = None
    def increment_percent(self, val=0.07):
        self.percent += val
        self.percent = min(self.percent,100)
        self.dialog_progress.update(int(self.percent))
        if self.percent == 100:
            self.percent = 75
    def percent(self):
        return self.percent
    def update(self
               ,percent
               ,message=None
               ,line2=None
               ,line3=None
               ):
        if not self.dialog_progress: return

        percent = min(percent,100)
##        Log(repr(percent),xbmc.LOGNONE)
        if not message:
            self.dialog_progress.update(int(percent))
            self.percent = percent
            return
        if line2 is None:
            self.dialog_progress.update(int(percent), message)
            self.percent = percent
            return
        if line3 is None:
            self.dialog_progress.update(int(percent), message, line2)
            self.percent = percent
            return
        
        #self.dialog_progress.update(int(percent), message, line2, line3) #pre kodi 19
        self.dialog_progress.update(int(percent), message+'[CR]'+line2+'[CR]'+line3) #post kodi 18
        self.percent = percent

        if self.percent == 100:
            self.percent = 75
#__________________________________________________________________
#
def Add_Refresh_Item(
    mode
    , name=C.STANDARD_MESSAGE_REFRESH
    , iconimage=C.refresh_icon
    , progress_dialog=None
    , end_directory=False
    , duration=C.STANDARD_DURATION_REFRESH
    ):
##    Kodi 18 needs these options for container.refresh to work
##        ,duration=C.STANDARD_DURATION_REFRESH 
##        ,Folder=False
    Log('warning'); LogR(traceback.extract_stack());

    if progress_dialog:
        if progress_dialog.iscanceled():
            end_directory = False
            addDir(
                name='Refresh this Cancelled Listing'
                ,url=C.DO_NOTHING_URL
                ,mode=mode
                ,iconimage=C.warning_icon
                ,duration=duration
                ,Folder=False 
                )
    if end_directory:
        addDir(
            name=name
            ,url=C.DO_NOTHING_URL
            ,mode=mode
            ,iconimage=iconimage
            ,duration=duration
            ,Folder=False 
            )
#__________________________________________________________________________
#
class ThreadWithStopEvent(threading.Thread):
    _stop_event = None
    def __init__(self, group=None, target=None, name=None
                 , args=(), kwargs=None, stop_event=None):
        super(ThreadWithStopEvent,self).__init__(group=group
                                                 , target=target, name=name
                                                 , args=args, kwargs=kwargs)
        self.args = args
        self.kwargs = kwargs
        self._stop_event = stop_event
#__________________________________________________________________
#
def Is_Online(
    server=C.DEFAULT_IS_ONLINE_SERVER_NAME
    , port=C.DEFAULT_IS_ONLINE_SERVER_PORT
    ):

    #todo: maybe change this to be proxy aware i.e. do a http get to server
    
    #use simplecache to store last time we did a network check
    # ... works like a static var across all threads
    cache_id = C.addon_id+'.Is_Online.'+"last_online_check"
    last_online_check = global_cache.get(cache_id)
    if last_online_check:
        Log("using cached Is_Online() "
##            , C.LOGWARNING
            )
        return True

    ip = None
    try:
        #xbmc function will not reliably report on IP when multiple are defined
        ip = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ip.settimeout(3)
        ip.connect((server,int(port)))
        ip = ip.getsockname()[0]
    except:
        LogR('no ip via getsockname'
##             , C.LOGWARNING
             )
        ip = xbmc.getIPAddress() #in case we don't have IP
    if (not ip) or ip.startswith('169.254') or ip.startswith('172.'):
        Log(u"reported ip is '{}'".format(ip), C.LOGWARNING)
        return False

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(3)
    try:
        qq = s.connect_ex((server, int(port)))
        if not qq == 0:
            raise Exception(qq)
    except:
        if C.DEBUG: traceback.print_exc()
        try:
            Sleep(1000)
            qq = s.connect_ex((server, int(port)))
            if not qq == 0:
                raise Exception(qq)
        except:
            return False
            raise
    finally:
        s.close()

    last_online_check = datetime.datetime.now()
    global_cache.set(
        endpoint = cache_id
        ,data = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ,expiration = datetime.timedelta(seconds=C.default_ISONLINE_cache_duration)
        )
    
    return True
#__________________________________________________________________
#
def crawl(q, all_method_results):
   #Log(repr(q.empty()))
    while not q.empty():
        work = q.get(timeout=C.WEBCRAWLER_THREAD_TIMEOUT)
       #Log(repr(work))
        index_for_result = work[0]
        method_to_call = work[1]
        keyword_arguments_for_method_to_call = work[2]
        import time
        t_start = time.time()
        try:
            single_method_result = method_to_call(**keyword_arguments_for_method_to_call)
        except Exception as ex:
            single_method_result = repr(ex)
        all_method_results[index_for_result] = single_method_result
        t_end = time.time()
        q.task_done()
       #Log("The time spent in thread {} is {}".format(index_for_result, t_end - t_start), C.LOGNONE)
        
    return True
#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
##        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
#__________________________________________________________________
# helper function to select an unused port on the host machine
def select_unused_port():
    import socket
    port = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('localhost', 0))
        addr, port = sock.getsockname()
        #sock.shutdown()
        sock.close()
    except Exception as ex:
        traceback.print_exc()
        port = 8666
    return port
#__________________________________________________________________________
# complicated PY3/PY2 compatible way of getting unix-style timestamp for UTCnow
def UTC_timestamp(asfloat=True):
    n = datetime.datetime.now() # utc is the target, but testing shows that utcnow() is wrong for py2 and py3
    #py3 has millisecond resolution, PY2 not - use a PY2 compatible style
    t = "{:.3f}".format(time.mktime(n.timetuple()) + n.microsecond / 1000000.0)
    if asfloat:
        return float(t)
    else:
        return t
#__________________________________________________________________________
#
def Normalize_Filespec(filespec):
##    LogR(os.name)
    #'posix' is android
    #python can get confused with smb://
##    if True :
    if os.name == 'nt':
        filespec = os.path.normpath(filespec)
        if filespec.startswith("smb:"):
            filespec = filespec[len("smb:"):]
        filespec = os.path.normpath(filespec)
        filespec = filespec.replace("\\\\", "\\")
        if filespec.startswith("\\") and not filespec.startswith("\\\\"):
            filespec = "\\" + filespec
        if filespec.startswith("\\\\") and (':' in filespec):
            #original path contained a port number; remove it for smb:
            filespec = re.sub(r"(\:[^\\]+)","",filespec)
    return filespec


#__________________________________________________________________________
#  dump stuff to xmbc.log so that i can debug
def LogFlush():
    return
##    LogR(sys.argv)
##    traceback.print_stack()
    Log("\nLogflush1", C.LOGNONE)
    if C.PY2: return
    import string
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    Log(string.ascii_letters+string.ascii_letters, C.LOGNONE)
    
    exit(0)
def FlushLog():
    LogFlush()
def Flush():
    LogFlush()
