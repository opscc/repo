#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import sqlite3 #needed for error handling
import mysql.connector as mariadb #needed for error handling

import constants as C
import queries as Q
import utils
from utils import Log,LogR
from utils import get_setting as GetSetting

import fav_dbconn

##FAV_DB_VERSION_1 = Q.FAV_DB_VERSION_1
##FAV_DB_VERSION_2 = Q.FAV_DB_VERSION_2
FAV_DB_VERSION_3 = Q.FAV_DB_VERSION_3
##FAV_DB_VERSION_4 = Q.FAV_DB_VERSION_4
FAV_DB_VERSION_CURRENT = Q.FAV_DB_VERSION_CURRENT

#__________________________________________________________________
#
def TableCreateString(db_version):
    return Q.MAIN_TABLE_STRING(db_version)
#__________________________________________________________________
#
def Create_Table(db_connection):
    try:
        sql_command = Q.DB_SCHEMA_STRING(
            FAV_DB_VERSION_CURRENT
            , db_connection)
        params = ()
        db_connection.execute( sql_command, params, prepared=False, multi=True)
    except mariadb.InternalError as ex:
        utils.Notify(
            header="db error"
            , msg="{} {}".format(
                e.args[0], db_connection.db_filespec)
            , duration=10000
            )
        raise
    except AttributeError as e:
        raise
    except sqlite3.OperationalError as ex:
        utils.Notify(header="db error", msg="{} {}".format(
            ex.args[0], db_connection.db_filespec), duration=10000 )
        raise
    except:
        #traceback.print_exc()
        raise
#__________________________________________________________________
#
def Export_Import(db_connection): #favDB_conn
    DB_PRAGMA_version = Get_DB_PRAGMA_version(db_connection)
    query = Q.UPGRADE_DB_STRING(
        FAV_DB_VERSION_CURRENT
        , DB_PRAGMA_version
        , db_connection
        )
    params = ()
    try:
        db_cursor = db_connection.execute( query, params, multi=True)
    except:
        Log(query.replace("?", "'%s'") )  #see exact query during debugging
        raise
#__________________________________________________________________
#
def Get_DB_PRAGMA_version(db_connection):
    result = None
    try:
        sql_command = Q.GET_DB_USER_VERSION(db_connection)
        params = ()
        db_cursor = db_connection.execute(sql_command,params)
        for a in db_cursor.fetchall():
            result = a['user_version']
    except Exception as ex:
        if 'no such table: favorites_meta' not in repr(ex):
            LogR(ex)
        Log('warning: missing GET_DB_USER_VERSION table.  Schema upgrade will be triggered')
        #version must be able to trigger upgrade
        result = FAV_DB_VERSION_3
    return result
#__________________________________________________________________
#
def Get_DB_PRAGMA_filename(db_connection):
    sql_command = 'SELECT file FROM pragma_database_list;'
    Log("sql_command='{}'".format(sql_command) )
    id_column_count =  db_connection.execute( sql_command )
    for a in id_column_count:
        return a[0]
#__________________________________________________________________
#
def Create_Maintain_FavDB(db_connection):
    DB_PRAGMA_version = Get_DB_PRAGMA_version(db_connection)
    if DB_PRAGMA_version in [0, None]:
        Log("New database detected {} ".format(db_connection.db_filespec))
    elif DB_PRAGMA_version < FAV_DB_VERSION_CURRENT:
        Log('Export_Import()')
        Export_Import(db_connection)
    else:
        Log("Database schema is up to date {} {}".format(
            DB_PRAGMA_version
            , db_connection.db_filespec
            ))
    #rerun this in case Export_Import doe not create tables
    if db_connection.unread_result: raise Exception('warning unread_result')  #bugsearch
    Create_Table(db_connection)
#__________________________________________________________________
#
