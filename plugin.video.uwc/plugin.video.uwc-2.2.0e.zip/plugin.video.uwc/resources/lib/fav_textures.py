#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''



###https://kodi.wiki/view/Artwork/Cache


import base64
import sqlite3
import random
import threading
import traceback
import xbmc
import xbmcvfs


import constants as C
import queries as Q

import utils

from fav_dbconn  import generic_favdbconn
from utils import Log,LogR

#__________________________________________________________________________
#
# private SQL query generator
def _UPSERT_TEXTURE(
    TEXTURE_DB_VERSION            #1
    , uri_image              
    , cachedurl_ending
    , date_modified = None             #11
    ):
    if date_modified in ("",None,"None"): date_modified = " datetime() "
    if False:
        pass #stub
    elif TEXTURE_DB_VERSION in [13,14]:
        i = {
            "table": " `texture` "
            ,"key_name": " `url` "
            ,"key_value": repr(uri_image)
            ,"column_tuple": (
                  " `url` "
                , " `cachedurl` "
                , " `lasthashcheck` "
                )
            ,"value_tuple": (
                  u" '{}' ".format(uri_image.replace("'","''").replace("\\","\\\\"))
                , u" '{}' ".format(cachedurl_ending.replace("'","''").replace("\\","\\\\"))
                , str(date_modified)
                )
            }
        return i        
    else:
        raise NotImplementedError(C.module_name(),TEXTURE_DB_VERSION)

#__________________________________________________________________________
#
# private SQL query generator
def _UPSERT_SIZE(
    TEXTURE_DB_VERSION            #1
    , uri_image              
    , date_modified = None             #11
    ):
    if date_modified in ("",None,"None"): date_modified = " datetime() "
    if False:
        pass #stub
    elif TEXTURE_DB_VERSION in [13,14]:
        i = {
            "table": " `sizes` ",
            "key_name": " `idtexture` ",
##            "key_value": repr(uri_image),
            "key_value":
            u" COALESCE( (SELECT id FROM texture " \
                " WHERE url='{}' LIMIT 1), null ) ".format(
                    uri_image.replace("'","''").replace("\\","\\\\")),
            
            "column_tuple": (
                " `idtexture` ",
                " `size` ",
                " `width` ",
                " `height` ",
                " `usecount` ",
                " `lastusetime` ",
                )
            ,"value_tuple": (
                u" COALESCE( (SELECT id FROM texture " \
                " WHERE url='{}' LIMIT 1), -1 ) ".format(
                    uri_image.replace("'","''").replace("\\","\\\\")),
                str(1),
                str(320),
                str(240),
                str(1 ),
                str(date_modified),
                )
            }
        return i
    else:
        raise NotImplementedError(C.module_name(),TEXTURE_DB_VERSION)


#__________________________________________________________________________
#
# private SQL query generator
def _UPSERT_SIZE_LASTUSETIME(
    TEXTURE_DB_VERSION            #1
    , uri_image              
    , date_modified = None             #11
    ):
##    'TODO
    if date_modified in ("",None,"None"): date_modified = " datetime() "
    if False:
        pass #stub
    elif TEXTURE_DB_VERSION in [13,14]:

        ## ##note###: this query will always(?) connect to sqlite3 database
        ##  and so I don't have to worry about equivalent mariadb keywords
                ##replacement table
                ##-- sizes favorites
                ##-- lastusetime date_modified
                ##-- unixepoch() UNIX_TIMESTAMP
                ##--  datetime() curdate()

        q = \
'''
UPDATE `sizes`
SET  `lastusetime` = datetime() 
WHERE 
    `idtexture` = (SELECT `id` FROM `texture` WHERE `url` = '{}' LIMIT 1) 
    AND
    CAST (
        (unixepoch() - unixepoch(`lastusetime`))/86400.0
	 AS INTEGER
	) > 5
'''
        q = q.format(
#            str(date_modified),
            uri_image.replace("'","''").replace("\\","\\\\"),
#            str(date_modified),
            )
        return q
    
##        i = {
##            "table": " `sizes` ",
##            "key_name": " `idtexture` ",
####            "key_value": repr(uri_image),
##            "key_value":
##            u" COALESCE( (SELECT id FROM texture " \
##                " WHERE url='{}' LIMIT 1), null ) ".format(
##                    uri_image.replace("'","''").replace("\\","\\\\")),
##            
##            "column_tuple": (
##                " `idtexture` ",
##                " `size` ",
##                " `width` ",
##                " `height` ",
##                " `usecount` ",
##                " `lastusetime` ",
##                )
##            ,"value_tuple": (
##                u" COALESCE( (SELECT id FROM texture " \
##                " WHERE url='{}' LIMIT 1), -1 ) ".format(
##                    uri_image.replace("'","''").replace("\\","\\\\")),
##                str(1),
##                str(320),
##                str(240),
##                str(1 ),
##                str(date_modified),
##                )
##            }
##        return i
    else:
        raise NotImplementedError(C.module_name(),TEXTURE_DB_VERSION)
    
#________________________________________________________________________________
#
# insert/write binary to local cache if not already there
def Insert_Binary_Image(
      binary_image
    , uri_image
    , name       # only used for logging 
    , img_raw_type = None
    , force_write_image=False
    , m_texture_conn = None
      ):

    if not binary_image:
        return
    
    #do this for every entrypoint
    if not m_texture_conn: m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)


    if not img_raw_type:
        if binary_image.startswith('UklG'):
            img_raw_type='wbem'
        elif binary_image.startswith('/9j/'):
            img_raw_type='jpg'
        else:
            img_raw_type='jpg'
                    
    texture_filespec = xbmc.getCacheThumbName(uri_image)
    if img_raw_type == 'wbem':
        #.tbn is the only extension that works; kodi will try to open .wbem as a folder
        #.jpg will say 'i don't understand the format'
        texture_filespec = texture_filespec.removesuffix('.tbn').removesuffix('.jpg')+'.tbn'
    else:
        texture_filespec = texture_filespec.removesuffix('.tbn').removesuffix('.jpg')+'.jpg'
                
    cachedurl_start = "special://thumbnails/"
    if texture_filespec:
        cachedurl_ending = "{}/{}".format(texture_filespec[0:1], texture_filespec)
        texture_filespec = C.translatePath(cachedurl_start+cachedurl_ending)
        if (not force_write_image) and xbmcvfs.exists(texture_filespec):
            Log(u"already cached '{}' thumbcache {} ".format(
                name,texture_filespec)
                )
            return texture_filespec
        else:
##            Log(u"not found or forcewrite {} texture_filespec {}".format(name, texture_filespec)
##                ,C.LOGNONE
##                )
            pass
    else:
        Log("'{}' uri_image {} is not getCacheThumbName".format(
            name,uri_image)
            ,C.LOGNONE
            )
        #create a new item for this
        cachedurl_ending = "".join([random.choice(string.ascii_letters[0:7] + string.digits) for x in range(0,8)]).lower()
        cachedurl_ending = "{}/{}".format(cachedurl_ending[0:1], cachedurl_ending)
        if img_raw_type == 'wbem':
            cachedurl_ending = cachedurl_ending +'.tbn'
        else:
            cachedurl_ending = cachedurl_ending +'.jpg'

##    query = '''
##    BEGIN TRANSACTION;
##    INSERT INTO `texture` (
##        url
##        ,cachedurl
##        ,imagehash
##        ,lasthashcheck
##    ) VALUES (
##          '{}'
##        , '{}'
##        ,  ''
##        ,  datetime()
##    );
##    DELETE FROM `texture`
##    WHERE
##        `url` LIKE (select(substr('{}',0,ifnull(nullif(instr('{}','|'),0),9999))||'%')) 
##        AND NOT(`id`=last_insert_rowid());
##    /* note: DELETE FROM `texture` will TRIGGER delete from `sizes` */
##    INSERT INTO `sizes` (
##            `idtexture`
##            ,`size`
##            ,`width`
##            ,`height`
##            ,`usecount`
##            ,`lastusetime`
##    ) VALUES (
##            last_insert_rowid()
##            ,1,320,240,0,datetime()
##    );
##    COMMIT;
##    '''
##    #this is not the 'right' way to use params, but sqlite3 does not
##    #  let me do it the way I want - and I don't want to use separate
##    #  execute statements - I do check of for rogue statements
##    params = ()
##    query = query.format(
##          m_texture_conn.sanitize_value_for_sql(uri_image)
##        , m_texture_conn.sanitize_value_for_sql(cachedurl_ending)
##        , m_texture_conn.sanitize_value_for_sql(uri_image)
##        , m_texture_conn.sanitize_value_for_sql(uri_image)
##        )
##    m_texture_conn.execute( query, params, multi=True)


    try:
        #TEXTURE_DB_VERSION = 13

        #testing shows that we should insert maultiple values for images
        uri_images = (
                uri_image                  #main one we should be using 
                , uri_image.split("|")[0]  #without possible headers
                #, uri_image.split("?")[0] #without possible params
            )

        for uri in uri_images:
            q = _UPSERT_TEXTURE(
                C.TEXTURE_DB_VERSION
                , uri
                , cachedurl_ending
            )
            r = m_texture_conn.upsert(
                 q["table"]
                ,q["key_name"]
                ,q["key_value"]
                ,q["column_tuple"]
                ,q["value_tuple"]
    ##            ,forced_log = True
                )

            if r: #we have most likely inserted
                q = _UPSERT_SIZE(
                    C.TEXTURE_DB_VERSION
                    , uri
                )
                r = m_texture_conn.upsert(
                     q["table"]
                    ,q["key_name"]
                    ,q["key_value"]
                    ,q["column_tuple"]
                    ,q["value_tuple"]
##                    ,forced_log = True
                    )
       
        m_texture_conn.commit()

    except sqlite3.IntegrityError as e:
        if 'duplicate information' in e.args:
            LogR(q["key_value"])
            pass

    thumb_filespec = C.translatePath(cachedurl_start+cachedurl_ending)
##    return thumb_filespec
    
    f = xbmcvfs.File(thumb_filespec, 'w')
    if type(binary_image) == bytes:
        f.write(base64.b64decode(binary_image))
    else:
        f.write(base64.b64decode(binary_image.encode()))
    f.close()
    Log(" '{}' binary written to '{}'".format(name,thumb_filespec))
    m_texture_conn.commit()

    return thumb_filespec

#__________________________________________________________________
#
def find_thumbnail_in_cache(
    url , 
    m_texture_conn = None,
    ):

    #do this for every entrypoint
    if not m_texture_conn: m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)

    #texture must:
    #   1. be in sqlite db
    #   2. file must exist on disk
    #normalized_url = url.split('|')[0].split('?')[0] #discard anti-caching unique timestamp
    normalized_url = url #turns out we can't do this because texture.db will include all these details
    query = "SELECT * FROM `texture` WHERE `url` LIKE ?"
##    params = (  (normalized_url+'%',) ) #wildcard because icon may be cached with a apppended header
    params = (url,)
    texture_cursor = m_texture_conn.execute(query,params)
    result = texture_cursor.fetchone()
    if not result:
        LogR(('not found',normalized_url,url))
        return None
    texture_filespec = "special://thumbnails/" + result['cachedurl']
    texture_filespec = C.translatePath(texture_filespec)
    if not xbmcvfs.exists(texture_filespec):
        result = None
    return result

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CLEAN_TEXTURES)
def Clean_Textures_DB():

    try:    

        Log(__name__)
    
        texture_conn = generic_favdbconn(database=C.texture_DB_filespec)

        progress_dialog_message = "Deleting missing Textures"
        progress_dialog = None
        progress_dialog = utils.Progress_Dialog(C.addon_name, progress_dialog_message)

        texture_cursor = texture_conn.cursor()
        query = "SELECT * FROM texture"
        params = ''
        texture_cursor.execute(query,'')
        cachedurl_index = [idx for idx, col in enumerate(texture_cursor.description) if col[0] == 'cachedurl'][0]
        id_index = [idx for idx, col in enumerate(texture_cursor.description) if col[0] == 'id'][0]
        texture_folder = "special://thumbnails/"
        texture_folder = C.translatePath(texture_folder)

        
        percent = 1
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...scanning...'
            )
            
        for result in texture_cursor.execute(query).fetchall():

            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent(0.01)

            texture_filespec = texture_folder + result[cachedurl_index]
##            Log(texture_filespec)
            
            if not xbmcvfs.exists(texture_filespec):
                Log(texture_filespec)
                query = "DELETE FROM texture WHERE id = ?"
                params = (result[id_index], )
                texture_cursor.execute(query,params)
                
            #return

        texture_conn.commit()
        utils.Notify(msg="TextureDB cache cleaning comlpeted")
    except:
        traceback.print_exc()
    finally:
        if progress_dialog:
            progress_dialog.close()
        progress_dialog = None

#__________________________________________________________________
#
def delete_thumbnail_in_cache(
    uri_image
    , m_texture_conn = None
    ):

    if uri_image in (None,'','None','none','%'):
        return
    #do this for every entrypoint
    if not m_texture_conn: m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
    delete_query = \
    '''
        DELETE FROM `texture`
        WHERE
            `url` LIKE ? ;
    '''
    # note: DELETE FROM `texture` will TRIGGER delete from `sizes`
    select_query = \
    '''
        SELECT `id`, `cachedurl`, `url` FROM `texture`
        WHERE `url` LIKE (select(substr( ? ,0,ifnull(nullif(instr( ? ,'|'),0),9999))||'%')) 
    '''
    params = (
          m_texture_conn.sanitize_value_for_sql(uri_image)
        , m_texture_conn.sanitize_value_for_sql(uri_image)
        )

    select_cursor = m_texture_conn.execute(select_query,params)
    for r in select_cursor.fetchall():
        (texture_id, texture_image_cache, texture_url) = r
        params = (m_texture_conn.sanitize_value_for_sql(uri_image),)
        m_texture_conn.execute( delete_query, params)
        try:
            filespec = "special://thumbnails/" + texture_image_cache
            filespec = C.translatePath(filespec)
            Log(filespec)
            if xbmcvfs.exists(filespec): xbmcvfs.delete(filespec)
            m_texture_conn.commit()
        except:
            LogR(filespec,C.LOGWARNING)
            traceback.print_exc()
            pass



'''
DROP TRIGGER `main`.`trigger_texture_UPDATE_before`;
CREATE TRIGGER trigger_texture_UPDATE_before
BEFORE update ON texture
FOR EACH ROW 
 BEGIN 
  	SELECT  
 		RAISE(ABORT, 'duplicate UPDATE information')
 	WHERE EXISTS (
       SELECT 1
       WHERE (
                               CAST(NEW."url" AS INT) == CAST(OLD."url" AS INT)
       AND                                  NEW."cachedurl" == OLD."cachedurl"
        )

       );
END  );
END;

CREATE TRIGGER trigger_texture_INSERT_before
BEFORE insert ON texture
FOR EACH ROW 
 BEGIN 
  	SELECT  
 		RAISE(ABORT, 'duplicate INSERT information')
 	WHERE EXISTS (
       SELECT url from texture as t where t.url = NEW."url" 
       );
END


'''

#__________________________________________________________________
#
class Exception_Interrupt(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)
    @property
    def msg(self): return self.value
        
#__________________________________________________________________________
# Kodi will delete textures that are too old, but we need to keep them
@C.url_dispatcher.register(C.REFRESH_TEXTURE_TIMESTAMP)
def Refresh_Texture_Timestamp():

    m_favorites_conn = generic_favdbconn(database=C.favoritesdb)


    monitor = xbmc.Monitor() #behaves stragely if kodi closes too soon?

    progress_dialog = None
    if threading.current_thread().name == "MainThread":
        progress_dialog = utils.Progress_Dialog(
            C.addon_name,
            u"Refresing Favorites Textures",
            )
        percent = 1
        progress_dialog.update(
            percent = int(percent),
##            message = progress_dialog_message ,
##            line2 = u' ',
##            line3 = u"...refreshing texture timestamps...",
            )

    try:

        highwater = utils.get_setting(C.TIMESTAMP_REFERSH_HIGHWATER, int)

        query = \
'''
SELECT `rowid` , `image` , `name` , `binary_image`
FROM `favorites`
WHERE `rowid`>? AND `is_deleted`=0
'''
        params = (highwater,)
        favDB_cursor = m_favorites_conn.execute(query,params)
        m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
        for a in favDB_cursor.fetchall():
            a = dict(a)
##            LogR(a,C.LOGINFO)

##            Log('warning  #development slowdown'); utils.Sleep(500)
    
            f =  find_thumbnail_in_cache(
                url = a['image'], 
                m_texture_conn = m_texture_conn,
                )
            if not f:
                Log('thumb is not in database or not on disk')
                LogR(a,C.LOGINFO)

                if a['binary_image']:
                    Insert_Binary_Image(
                        binary_image = a['binary_image'],
                        uri_image = a['image'], 
                        name = a['name'],
                        m_texture_conn = m_texture_conn,
                    )

            
            query = _UPSERT_SIZE_LASTUSETIME(
                C.TEXTURE_DB_VERSION,
                a['image'],
            )
            favDB_cursor = m_texture_conn.execute(
                query = query,
                forced_log = True,
                )
##            LogR(favDB_cursor.rowcount)
            m_texture_conn.commit()






##            LogR(dir(favDB_cursor))
##            m_texture_conn.commit()
##            LogR(favDB_cursor.rowcount)
            
####                
            
##            q = _UPSERT_SIZE(
##                C.TEXTURE_DB_VERSION,
##                a['image'],
##            )
##            r = m_texture_conn.upsert(
##                q["table"],
##                q["key_name"],
##                q["key_value"],
##                q["column_tuple"],
##                q["value_tuple"],

##                )
##            m_texture_conn.commit()
        
            
            if progress_dialog: percent  = progress_dialog.percent + 0.2
            if progress_dialog: progress_dialog.update(
                percent = int(percent),
                message = u"...refreshing texture timestamps...{}...{}".format(
                    a['rowid'],
                    a['name'],
                    ),
                )
            if progress_dialog and progress_dialog.iscanceled(): 
                raise Exception_Interrupt(a['rowid'])
            if monitor.abortRequested():
                raise Exception_Interrupt(a['rowid'])
        else:
            Log('if we got this far, reset the count [recycling exception code]',C.LOGINFO)
##            LogR(utils.UTC_timestamp())
            utils.set_setting(
                setting_name=C.TIMESTAMP_REFERSH_FULL_SUCCESS,
                setting_value=utils.UTC_timestamp(),
                )
            raise Exception_Interrupt(0)
         
    except Exception_Interrupt as ex:
        ##    save our last hight point
##        LogR(dir(ex),C.LOGERROR)
##        LogR(ex,C.LOGERROR)
##        LogR(ex.msg,C.LOGINFO)
        Log("saving highwater '{}' ".format(ex.msg),C.LOGWARNING)
        utils.set_setting(
            setting_name=C.TIMESTAMP_REFERSH_HIGHWATER,
            setting_value=ex.msg,)
    except Exception as ex:
        LogR(ex,C.LOGERROR)
        raise
    finally:
        if progress_dialog: progress_dialog.close()

#__________________________________________________________________________
# end-of-file
#__________________________________________________________________________
