#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]mrsexe[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True
    
    _ROOT_URL        = "https://www.mrsexe.tv"
    _URL_CATEGORIES  = _ROOT_URL
    _URL_RECENT      = _ROOT_URL + '/videos/page{}.html'
    _SEARCH_URL      = _ROOT_URL + "/?search={}"
    _MAIN_MODE = C.MAIN_MODE_mrsexe
    _FIRST_PAGE = 1

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
##    _ITEMS_NOT_FOUND_INDICATORS = [
##        "<p>Make sure that all words are spelled correctly.</p>"
##        , "No videos found for "
##        ]
    #__________________________________________________________________________
    #specific header required for listing
##    _LIST_HEADERS = {
##        "Accept":"application/json, text/plain, */*"
##        ,"DNT":"1"
##        ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"
##        ,"Origin":"https://beeg.com"
##        ,"Referer":"https://beeg.com/"
##        ,"Accept-Encoding":"gzip, deflate"
##        ,"Accept-Language":"en-US,en;q=0.9"
##    }
    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = 'thumb-list xxlarge-block-grid-5(.+)'
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
         '<li class="[^"]*">'
         '.+?<a class="thumbnail" href="(?P<videourl>[^"]+)">'
         '.+?<img  id=".+?" src="(?P<thumb>[^"]+)"'
         '.+?fa-clock-o"></i>(?P<duration>[^<]+)</span>'
         '\n(?P<label>.+?)\n'
         '(?P<hd>)'
        )
    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'pagination(.+)'
    _REGEX_next_page_regex = r'<li class="arrow"><a href="([^\.]+?)\.html">suivant</a></li>'

    #__________________________________________________________________________
    #where categories can be found
    _REGEX_categories_region = r'<option value="/videos/">Cat&eacute;gories</option>(.+)'
    _REGEX_categories = (
        r'value="(?P<videourl>/cat[^"]+)"'
        r'.+?>(?P<label>[^<]+)<'
        r'(?P<thumb>)'
        )
##    #__________________________________________________________________________
##    # Change url found in via regex with structure neeeded by website
##    def Category_URL_Normalize(self, url):
##        url = "https://store.externulls.com/facts/tag?slug={}&".format(url)
##        return url
##    #__________________________________________________________________________
##    #where playable urls live
##    _REGEX_play_region = (
##        '<div class="dloaddivcol">(.+?)</div>'
##        )
##    _REGEX_playsearch_01 = (
##        '<u>(?P<res>\d+)'
##        '.+?href="(?P<url>[^"]+?)"'
##        )
    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by site
    def Video_Source_URL_Normalize(self, url):
        url = "".join((self._ROOT_URL, url))
##        Log(url)
        return url
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags = r'class="vit-pornstar.+?href="/pornstar/.+?>([^<]+)<\/a>'
    _REGEX_tags_region = "(.+)"           #'class="categorieswrapper(.+?)<noscript>'
##    #__________________________________________________________________________
##    # add an alternative way to resolve listing
##    def List_URL_Normalize(self, url, page):
##        LogR(locals())
##        return url
    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
        if not thumb.startswith('http'): thumb = 'http:' + thumb
##        LogR(locals())
        return thumb
    #__________________________________________________________________________
    # add update duration as necessary
    def Normalize_Duration(self, duration):
        duration = duration.strip().replace('h ', ':00').replace(' min', ":00")
##        LogR(locals())
        return duration
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self._ROOT_URL + videourl        
##        LogR(locals())
        return videourl
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = self._ROOT_URL + url + "page{}.html"
##        LogR(locals())
        return url
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        second_url = re.compile(r"src='(/inc/clic\.php\?video=.+?&cat=mrsex.+?)'").findall(full_html)
        html = utils.getHtml('https://www.mrsexe.tv' + second_url[0], '')

        #2019-05-21
        videourls = re.compile(r"HDtoggle\(('[^\)]+)", re.DOTALL).findall(html)
        #site may have multiple sources, but does not tell us the quality very well. First seems best
        if videourls:
            video_url = videourls[0].split(",")[-1].strip("'")
        else:
            videourls = re.compile(r"\.src\(\"([^\"]+)\"", re.DOTALL).findall(html)
            video_url = videourls[0]
        if video_url.startswith('//'): video_url = 'http:' + video_url

        alt_results.append(  ('1', video_url)  )
        
##        LogR(locals())
        return alt_results
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        key = ''
        key2 = keyword.split('+')
        for k in key2:
            if len(k) > 3:
                key = key + '+' + k
        if key:
            keyword = key.lstrip('+')
        keyword = keyword.replace(' ','+')
        #2025-04-25 search was broken on site side
##        LogR(locals())
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format(keyword)
##        LogR(locals())
        return search_url
##    #__________________________________________________________________________
##    # Change LIST to enable max recurse depth
##    def List(self, url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
##        try:
##            org = C.MAX_RECURSE_DEPTH
##            if C.PY3:                       super().List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            if C.PY2: super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            C.MAX_RECURSE_DEPTH = org
##        except:
##            pass
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid(
        url
        , name
        , download=download
        , playmode_string=playmode_string
        , play_profile=play_profile
        , testmode=testmode
        , icon_URI=icon_URI
        )
#__________________________________________________________________________
#
