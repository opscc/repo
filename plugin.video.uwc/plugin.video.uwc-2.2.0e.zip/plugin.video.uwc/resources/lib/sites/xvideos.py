'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils
import resolver

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]xVideos[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False

    _ROOT_URL        = "https://www.xvideos.com"
    _SEARCH_URL      = _ROOT_URL + '/?k={}&p={}'
    _URL_CATEGORIES  = _ROOT_URL
    _URL_RECENT      = _ROOT_URL + '/new/{}/'
    _URL_MOST_VIEWED = _ROOT_URL + '/most-viewed/'
    _MAIN_MODE = C.MAIN_MODE_xvideos
    _FIRST_PAGE = 1

    _IGNORE_404 = False #sometimes 404 is ok, sometimes not

    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "but no results were found"
        ,"(No result)"
        ]
    
    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = (
                'id="main"'
                '(.+)'
                #'<div class="pagination "><ul>'
                '<div id="ad-footer"></div>'
                    )
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        'div id="video_'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?class="duration">(?P<duration>[^<]+)<'
        '(?P<hd>)'
##        ?P<videourl>
##        ?P<thumb>
##        ?P<label>
##        ?P<duration>
##        '(?P<hd>)'
##        ?P<desc>
    )                         
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self._ROOT_URL + videourl        
        return videourl
    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
        if not thumb.startswith('http'): thumb = 'https' + thumb
        return thumb
    #__________________________________________________________________________
    # add update duration as necessary
    def Normalize_Duration(self, duration):
        duration = duration.strip().replace(' min', ":00")
        return duration
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
##    _REGEX_next_page_region = (
##        '(.+)'
####        '</nav>'
##        )
    _REGEX_next_page_regex = (
            r'<li><a href=".+/?(?:(\d+)|.+p=(\d+))/?" class="no-page next-page"><span class="mobile-hide">Next<'
        )

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        keyword = keyword.replace(' ','+')
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format( keyword, '{}')
        return search_url

    #__________________________________________________________________________
    #where categories can be found
    _REGEX_categories_region = (
        r'class="main-cats-title">Categories(.+)class="main-cats-title"'
        )
    _REGEX_categories = (
        r'<a href="(?P<videourl>/c/[^"]+)"'
        r'>(?P<label>.+?)<'
        r'(?P<thumb>)'
####        ?P<videourl>
####        ?P<thumb>
####        ?P<label>
        )
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = self._ROOT_URL + url
        url = url + "/{}/"
        return url
    #__________________________________________________________________________
    # Change category thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        if not thumb.startswith('http'): thumb = self._ROOT_URL + thumb
        return thumb
    
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags_region = (
        'class="video-metadata'
        '(.+)'
        '<div id="content">'
        )
    _REGEX_tags = (
        '<a href="(?:/pornstars/|/model-channels/|/models/).+?<span class="name">(?P<model>[^<]+)<'
        )


    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        url = kargs["referer"]
        video_url = None


        regex = r"html5player\.setVideo(?:UrlLow|UrlHigh|HLS)\('(http[^']+)'"
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(kargs["full_html"])
        Log("HLS sources={}".format(sources))
        sources_list = {}
        guessed_resolution = 0 #last is usually best; site does not provide res information
        for source in sources:
            guessed_resolution = guessed_resolution + 360
            alt_results.append(  (str(guessed_resolution), source )  )

        return alt_results

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #  these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid(
        url
        , name
        , download=download
        , playmode_string=playmode_string
        , play_profile=play_profile
        , testmode=testmode
        , icon_URI=icon_URI
        )
#__________________________________________________________________________
#
