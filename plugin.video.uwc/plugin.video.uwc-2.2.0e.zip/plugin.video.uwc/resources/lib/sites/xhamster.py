'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils
import resolver

##Log("todo: site responcs with wrong thumb header; hack with a new proxy?")

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]xHamster[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False

    _ROOT_URL        = "https://xhamster.com"
    _URL_CATEGORIES  = _ROOT_URL + '/categories'
    _URL_RECENT      = _ROOT_URL + '/newest/{}'
    _SEARCH_URL      = _ROOT_URL + '/search/{}?page={}'
    _URL_MOST_VIEWED = _ROOT_URL + '/most-viewed/'
    _MAIN_MODE = C.MAIN_MODE_xhamster
    _FIRST_PAGE = 1

    _IGNORE_404 = False #sometimes 404 is ok, sometimes not

    #_REGEX_icon_search = r'"thumbnailUrl": ["(.*?)"'
    _REGEX_icon_search = r'<div class="xp-preload-image" style="background-image: url\(\'(.*?)\''
    
    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = C.PLAYMODE_INPUTSTREAM
    #None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #specific header required for listing
##    _LIST_HEADERS = {
##        "Accept":"application/json, text/plain, */*"
##        ,"DNT":"1"
##        ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"
##        ,"Origin":"https://beeg.com"
##        ,"Referer":"https://beeg.com/"
##        ,"Accept-Encoding":"gzip, deflate"
##        ,"Accept-Language":"en-US,en;q=0.9"
##    }

    #where we can find videos on this page [exclude advertisement]
##    _REGEX_video_region = (
##                    'div class="banner-mobile"'
##                     '(.+)'
##                    )
    _REGEX_video_region = (
                    '(?:<div class="item-container">|id="master_cube")'
                    '(.+)' 
                    '(?:<nav class="desktop-pagination|class="pager-section")'
                    #2026-03-16  lotta temporary? garbage added to html
                    )

    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
##        'data-role="thumb-link"'
        r'data-video-id="\d+"'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
##        '.+?(?P<hd>thumb-image-container__icon--uhd|thumb-image-container__icon--hd|'
##            'thumb-image-container__icon|div data-role)'
       '.+?"video-duration">.+?>(?P<duration>[^<]+)<' #2025-01
        '(?P<hd>)'
##        '(?P<duration>)'
        '(?P<desc>)'
    )                         
##    #__________________________________________________________________________
##    # add an alternative way to resolve listing
    def List_URL_Normalize(self, url, page=None):
        if int(page) == 1:
            if url.endswith('/1'):
                url = url[:-len('/1')]

        return url
##    #__________________________________________________________________________
##    # Change LIST to enable max recurse depth
##    def List(self, url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
##        try:
##            org = C.MAX_RECURSE_DEPTH
##            if C.PY3:                       super().List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            if C.PY2: super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            C.MAX_RECURSE_DEPTH = org
##        except:
##            pass
##    #__________________________________________________________________________
##    #which to strings may indicate that there is nothing to be found
##    _ITEMS_NOT_FOUND_INDICATORS = [
##        ]
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self._ROOT_URL + videourl
##        Log(videourl)
        return videourl
##    #__________________________________________________________________________
##    # add an alternative way to resolve a playable thumbnail
##    def Normalize_ThumbURL(self, thumb, duration, videourl):
##        if not thumb.startswith('http'): thumb = 'https:' + thumb
##        LogR(locals())
##        return thumb
##    #__________________________________________________________________________
##    # add update duration as necessary
##    def Normalize_Duration(self, duration):
##        duration = duration.strip().replace('h ', ':00').replace(' min', ":00")
####        LogR(locals())
##        return duration
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = (
        '(.+)'
        )
    _REGEX_next_page_regex = (
        '(?:class="prev-next-list"|"xh-paginator-button)'
        '.+?((?:rel="next">Next</a>|data-page="next" href="))'
        )

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        keyword = keyword.replace(' ','+')
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format(keyword, '{}')
        return search_url
    

    #__________________________________________________________________________
    #where categories can be found
    _REGEX_categories_region = (
        ',"assignable":'
        '(.+?)'
        ',"trending":'
        )
    _REGEX_categories = (
        '"name":"(?P<label>[^"]+)"'
        '.+?"thumb":"(?P<thumb>[^"]+)"'
        '.+?"url":"(?P<videourl>[^"]+)"'
        )
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = self._ROOT_URL + url
        url = url.replace(r"\/","/")
        url = url + '/{}'
##        LogR(locals())
        return url
    #__________________________________________________________________________
    # Change category thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        thumb = thumb.replace(r"\/","/")
        return thumb 
    
##    #__________________________________________________________________________
##    #where playable urls live
##    _REGEX_play_region = (
##        '<div class="dloaddivcol">(.+?)</div>'
##        )
##    _REGEX_playsearch_01 = (
##        '<u>(?P<res>\d+)'
##        '.+?href="(?P<url>[^"]+?)"'
##        )
##    _REGEX_playsearch_01 = C.FLAG_USE_RESOLVER_ONLY #send all the text to resolver module

##    #__________________________________________________________________________
##    # Change playable video url found in via regex with a structure used by site
##    def Video_Source_URL_Normalize(self, url):
##        url = "".join((self._ROOT_URL, url))
####        Log(url)
##        return url
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags_region = (
        'window.Thumb = Thumb;(.+?)"xch"'
        )
    _REGEX_tags = (
        '"xprf":"(.*?)"'
        )

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

## watch the video you need to enable Javascript in your

        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url

        regex = '<link rel="preload" href="(.*?)"'
        preload_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
        alt_results.append(  ('144', preload_url )  )
        return alt_results
    
        try:
            regex = 'window.initials=(.*?);</script>'
            movies_html1 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
##            LogR(movies_html1, C.LOGWARNING)
            json_sources = json.loads(movies_html1)
##            LogR(json_sources, C.LOGWARNING)

            list_key_value = {}
            if 'mp4' in  json_sources:
                source_list = json_sources['mp4']
##            elif ('xplayerSettings' in json_sources) \
##                and ('hls' in json_sources['xplayerSettings']['sources']):
##                source_list = json_sources['xplayerSettings']['sources']['standard']['av1']
####                raise Exception()                                                                                               
            elif ('videoModel'     in json_sources) \
                    and ('sources' in json_sources['videoModel']) \
                    and ('mp4'     in  json_sources['videoModel']['sources']):
                source_list = json_sources['videoModel']['sources']['mp4']
            elif ('xplayerSettings2' in json_sources) \
                 and ('standard' in  json_sources['xplayerSettings2']['sources']):
                source_list = json_sources['xplayerSettings2']['sources']['standard']['h264']
                
            try:
                LogR(source_list,C.LOGERROR)
                for json_source in source_list:
                    q = json_source
                    v = source_list[json_source]                            
                    if not v == "":
                        list_key_value[q] = v
            except:
                Log('error determining quality',C.LOGERROR)
                for json_source in source_list:
                    q = json_source['quality']
                    v = json_source['url']
                    q = re.findall('([0-9]+)', q)
                    if q:
                        list_key_value[q[0]] = v
                    else:
                        list_key_value['144'] = v

            for rez in list_key_value: 
                encoded_url = list_key_value[rez]
                video_url = encoded_url + utils.Header2pipestring(headers)
                if video_url.startswith('http'):
                    #2025-08-20 - site encodes this; don't know decode yet
                    alt_results.append(  (rez, video_url )  )

        except:
            import traceback
##            traceback.print_exc()
            LogR(traceback.format_exc(),C.LOGERROR)
            pass
            
        if len(alt_results) < 1:
            regex = '<link rel="preload" href="(https://.+?.m3u8)"'
            hls_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
            video_url = hls_url + utils.Header2pipestring(headers)
            alt_results.append(  ('100', video_url )  )

        LogR(alt_results,C.LOGNONE)
            
##        return None
        return alt_results

    
##        regex = "flashvars.+?license_code:.+?'(?P<lic>[^']+)'"
##        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
##        if not sources_list:
##            utils.Notify("No license code for {}".format(name))
##            return
##        license_code = sources_list[0]
##        Log("license_code={}".format(license_code))
##        
##
##        regex = (
##            "(?:video_url|video_alt_url.?): '(?P<url>[^']+)'"
##            ".+?(?:video_url_text|video_alt_url.?_text|postfix): '(?P<res>[^']+)'"
##            )
##        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
##        list_key_value = {}
##        for source_list in sources_list:
##            if source_list.group('res'):
##                if source_list.group('res') == 'HQ':
##                    list_key_value['720'] = source_list.group('url')
##                elif source_list.group('res') in ['LQ','.mp4']:
##                    list_key_value['360'] = source_list.group('url')
##                else:
##                    list_key_value[source_list.group('res')] = source_list.group('url')
##            else:
##                list_key_value['240'] = source_list.group('url')
##        Log("list_key_value={}".format(list_key_value))
##
##
##        fappy_salt = resolver.FaapySalt(license_code, "")
##        headers = C.DEFAULT_HEADERS.copy()
##        headers['Referer'] = url
##        
##
##        for rez in list_key_value:
##            LogR((rez, list_key_value[rez]))
##            encoded_url = list_key_value[rez]
##            if encoded_url.startswith("function/0/"):
##                encoded_url = encoded_url.split("function/0/")[1]
##                Log("encoded_url={}".format(encoded_url))
##            encoded_fappy_code =  encoded_url.split('/')[5][0:32]
##            new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
##            video_url = encoded_url.replace(encoded_fappy_code, new_fappy_code)
##            video_url = video_url + utils.Header2pipestring(headers)
##            alt_results.append(  (rez, video_url )  )
##
##
##        LogR(alt_results)
####        return None
##        return alt_results

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.PLAY_MODE
    , ['url', 'name']
    , ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode']
    )
def Playvid(
    url
    , name
    , download=None
    , playmode_string=None
    , play_profile=None
    , testmode=False
    , icon_URI=None
    ):
    return website.Playvid(
        url
        , name
        , download=download
        , playmode_string=playmode_string
        , play_profile=play_profile
        , testmode=testmode
        , icon_URI=icon_URI
        , skip_head = True
#        , mimetype = 'application/vnd.apple.mpegurl'
        )
#__________________________________________________________________________
#
