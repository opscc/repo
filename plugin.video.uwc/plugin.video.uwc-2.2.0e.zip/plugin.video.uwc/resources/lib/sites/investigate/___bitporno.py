'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import utils
import search
from utils import Log,LogR
import constants as C

FRIENDLY_NAME = '[COLOR {}]bitporno[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://bitporno.to"
##SEARCH_URL = ROOT_URL + '/?q={}&or=&cat=&sort=recent&time=someday&length=all&view=0&page={}&user='
SEARCH_URL = ROOT_URL + '/search/{}/sort-recent/time-someday/page-{}'
#https://www.bitporno.com/search/lana+rhoades/sort-recent/time-someday/page-3

URL_CATEGORIES = ROOT_URL + '/?q='
URL_RECENT = ROOT_URL + '/?q=&or=&cat=&sort=recent&time=someday&length=all&view=0&page={}&user='
#URL_RECENT = ROOT_URL + '/search/all/sort-recent/time-someday/page-{}'

MAIN_MODE          = C.MAIN_MODE_bitporno
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = 1

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page_start, page_end, FIRST_PAGE)  

    # read html
    Log(repr(list_url))
    listhtml = utils.getHtml(list_url, ROOT_URL, save_cookie=True)#, ignore404=True , send_back_redirect=True)
    if "Page Not Found" in listhtml:
        video_region = ''
        listhtml = ''
    else:
        try:
            regex = 'id="search_results"(.+)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            video_region = listhtml
        #Log("video_region={}".format(video_region))

    # parse out list items
    regex = '<div class="[^"]*entry[^>]*>.*?((?:<div class="thumbnail-hd">HD</div>|))\s*<a class="[^"]+" href="([^"]+)".*?<img src="([^"]+)".*?</a>\s*<div[^>]*>([^<]+)</div>'
    regex = (
        '<div class="[^"]*entry[^>]*>'
        '\s+(?P<hd>(?:<div class="thumbnail-hd">HD</div>|))'
        '.+?<a class="[^"]+" href="(?P<videourl>[^"]+)"'
        '.+?<img src="(?P<thumb>[^"]+)"'
        '.+?</a>\s*<div[^>]*>(?P<label>[^<]+)</div>'
        '(?P<desc>)'
        )
##    Log(repr(regex))
    
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for hd, videourl, thumb, label, description  in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        label=label.replace('Serakon.com - Download movies porn', '')
        label=label.replace('- VseX.in More videos porn  -', '')
        label=label.replace('- Pornxcity.com', '')
        label=label.replace('- Pornvex.com', '')
        hd = utils.Normalize_HD_String(hd)        
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        thumb = thumb + utils.Header2pipestring() + "Referer=" + ROOT_URL
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , desc = '\n' + ROOT_URL
            , iconimage = thumb )
            #, duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    

    # next page items
    try:
        regex = 'id="search_results"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
    next_page_regex = '<a href="([^"]+)" class="pages">Next</a>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
            np_url = url
            np_number = int(page_start) + 1
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                    List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)
            

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page_start) == '-1'))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)

    regex = '>Categories</span>(.+?)<div id="search_ajax"'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    
    regex = '<a href="([^"]+)">([^<]+)</a>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label   in info:
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = C.unescape(videourl).replace("page-0", "page-{}")
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=C.search_icon)
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True, page_start=1, page_end=1):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download', 'play_profile'])
def Playvid(url, name, playmode_string=None, download=None, play_profile=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None #final playable url
    sources_list = None #intermediate var
    download_filespec = None
    videos_list = list() #hold multiple video_url when possible

    try:        
        source_html1 = utils.getHtml(url, ROOT_URL, save_cookie=True)
    #    source_html1 = 'poster="https://www153.playercdn.net/thumb/1/190716/722G5251PIU4VIFNS3DVD.jpg" style="width:100%; height:600px;">        <source src="https://www179.playercdn.net/86/3/auiZXjjV3FCLyE0SR3F3ww/1563331841/190716/836G529SC862EZB0KSUHS.mp4" type="video/mp4" label="480p" data-res="480" selected="true" /><source src="https://www227.playercdn.net/87/3/24E418Xex8i_P3g2gW0zfQ/1563331841/190716/722G5252RL8LRJJXRFSAY.mp4" type="video/mp4" label="720p" data-res="720" /><source src="https://www50.playercdn.net/88/3/vnk42g1HQgFkLh6hlDm-eA/1563331841/190716/723G5253SIOB3F5L2R6JN.mp4" type="video/mp4" label="1080p" data-res="1080" /></video></div><div class="clear"></div>'
        regex = 'jwplayer.+?file: "([^"]+)"' #works 2020-08
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)

        Log("sources_list={}".format(sources_list))
        if sources_list:
            video_url = sources_list[0]
##            Log("video_url={}".format(video_url))
        else:
            #Log("source_html1={}".format(source_html1),C.LOGNONE)
            pass
        
            

        #2022-01 noticed that the m3u file has split audio and video in two; fmproxy can't play this
        if video_url and not video_url.startswith('http'):
            video_url = ROOT_URL + video_url
            
    ##    if not video_url:
    ##        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
    ##        return
    ##    
    ##    headers = C.DEFAULT_HEADERS.copy()
    ##    headers['Referer'] = url
    ##    video_url = video_url + utils.Header2pipestring(headers)
    ##    Log("video_url='{}'".format(video_url))
    ####    return
    ##    utils.playvid(video_url, name=name, download=download, description=description)

        #what if we fail to get a url??
        if not video_url:
            if testmode:
                raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
            else:
                utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
            return

        #always set referrer so that 'kodi' does not appear to the target server
        if '|' not in video_url:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = url
            video_url = video_url + utils.Header2pipestring(headers)

    ##    from resources.lib import downloader
    ##    download_filespec = downloader.Make_download_path(name = name, include_date = True, file_extension = '.ts')

        Log("video_url='{}'".format(video_url))
        if testmode:
            Log("Would have played video_url; but in test mode")
            return   #during testmode, only ensure that a url can be generated

        utils.playvid(
            video_url
            , name=name
            , download=download
            , description=description
            , playmode_string=playmode_string
            , play_profile=play_profile
            , download_filespec=download_filespec
            )

    except:
        import traceback
        traceback.print_exc()
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        Log("ERROR Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), C.LOGNONE)


#__________________________________________________________________________
#
