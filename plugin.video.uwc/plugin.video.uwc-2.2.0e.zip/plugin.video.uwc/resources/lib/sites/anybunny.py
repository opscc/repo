'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import utils
import resolver
import constants as C
from base_website import Base_Website
from utils import Log,LogR
from constants import urlparse

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]anybunny[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False
    
    _ROOT_URL        = u"https://anybunny.org"
    _URL_CATEGORIES  = _ROOT_URL
    _URL_RECENT      = _ROOT_URL + '/new/?p={}'
    _SEARCH_URL      = _ROOT_URL + '/top/{}?p={}'

    _MAIN_MODE = C.MAIN_MODE_anybunny

    _FIRST_PAGE = 1

    _SAVE_COOKIES = True

    #__________________________________________________________________________
    # add an alternative way to resolve listing
    def List_URL_Normalize(self, url, page):
        bad_list = "?p=1"
        if url.endswith(bad_list): #site does not always like this
            url = url[:-len(bad_list)]
        return url
    
    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = 'class="main"(.+?)class="divrectr"'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "did not match any anybunny porn videos"
        ]


    #videos on this page
    _REGEX_list_items = (
        "class='nuyrfe' href='(?P<videourl>[^']+)'"
        ".+?src='(?P<thumb>[^']+)'"
        ".+?alt='(?P<label>.+?)'/>"
        "(?P<hd>)"
        "(?P<duration>)"
        "(?P<desc>)"
        )

    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #show all options

    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = r'href="([^"]+\d)">Next<'


    #where categories can be found
    #_REGEX_categories_region = "id='categoryList'(.+)"
    _REGEX_categories = (
        r"<a href='(?P<videourl>/top/[^']+)'>"
        r".+?src='(?P<thumb>[^']+)'"
        r".+?alt='(?P<label>[^']+)'"
        )

    #where playable urls live
##    _REGEX_playsearch_01 = (
##        "source src='(?P<url>[^']+?)' type='video/mp4'"
##        ".+?(?P<res>\d+)"
##        )
    _REGEX_playsearch_01 = (
        r"<div id=\"ogg\">.+href=\"(?P<url>[^\"]+?)\">Download Video"
        r".+?(?P<res>\d+)"
        )

    
#"source src='(?P<url>[^']+?)' type='(?:application/x-mpegURL|video/mp4)'"

    #description for the playable url
##    _REGEX_tags = '"pornstar_tag".+?>([^<]+)<'
##    _REGEX_tags_region = 'class="categorieswrapper(.+?)<noscript>'
    _REGEX_tags = '<a class=linkscts href=".+?>([^<]+)<'
    _REGEX_tags_region = 'Tags: (.+?)<center>'


##    #__________________________________________________________________________
##    #
##    _REGEX_icon_search = (
##        '<meta property="og:image" content="([^"]+)"'
##        )
##    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
##        Log(u"Icon_Search url={}, pattern={}, referer={}".format(repr(url),repr(pattern),repr(referer))
####            , C.LOGNONE
##            )
##
##        page_content = utils.getHtml(url, referer)
##        thumb = re.compile(pattern, re.DOTALL | re.IGNORECASE).findall(page_content)
##        thumb = thumb[0]
##        Log(repr(thumb,)
####            , C.LOGNONE
##            )
##        return thumb


    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def ____ALTERNATE_playsearch_01(self, *args, **kargs):

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        
        regex = '<iframe.*?src="([^"]+)"'
        intermediate_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if intermediate_url: intermediate_url = intermediate_url[0]
        else: return alt_results
        
        embed_html = utils.getHtml(intermediate_url, url)
        script_url = re.compile("src='([^']+)", re.DOTALL | re.IGNORECASE).findall(embed_html)[0]
        script_url = "https://" + urlparse.urlparse(intermediate_url).netloc + script_url
        videopage = utils.getHtml(script_url, intermediate_url)

        #https://azblowjobtube.com/kt_player/player.php?id=2806993&s=MhCqUdeCkqOCnPdNPuzxyA&ts=1561758799&ver=x HTTP/1.1
        #2019-06-28 site obfuskates code; i.e need to replace "'+ghbva+'" with "."
        video_url = re.compile('(?:irue842=|video_url:)"?(.*?)(?:;uSS1Comp=|"?,?video_html5_url:)', re.DOTALL | re.IGNORECASE).findall(videopage)[0]
        Log("video_url={}".format(video_url))
        match = re.compile(r'(gh\w\w\w)="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
        for repl, repl2 in match:
            video_url = video_url.replace("'+"+repl+"+'",repl2)
            video_url = video_url.replace('"+'+repl+'+"',repl2)
        Log("video_url={}".format(video_url))

        #try resolver
        resolved_video_url = resolver.resolve_video(
            videosource=video_url
            , name=''
            , url=url
            )
        if resolved_video_url: video_url = resolved_video_url

        alt_results.append( ('1', video_url) )

        return alt_results
    

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        return keyword.replace('+',' ').replace(' ','_')

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format(keyword,'{}')
        
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url + '?p={}'

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )

#__________________________________________________________________________
#
