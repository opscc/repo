'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#2025-04 more and more items cloudflare


#import base libraries
import base64
import json
import re
import time
import traceback
#import internal addon libraries
import utils
from base_website import Base_Website
import constants as C
#define frequenctly used aliases
from utils import Log,LogR


class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]daftsex[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True
    #_ROOT_URL        = "https://biqle.ru"
    #_ROOT_URL        = "https://daft.sex"
    _ROOT_URL        = "https://mat6tube.com"
    _URL_CATEGORIES  = None #_ROOT_URL + '/videos/category/798?page_id={}'
    _URL_RECENT      = _ROOT_URL #2021-09-23
    _URL_RECENT      = _ROOT_URL +'/video/sex?p={}' #2022-08-08 #due to old url takedown
    _URL_RECENT      = _ROOT_URL +'/popular/recent?p={}' #2025-04  #seems to work
    _SEARCH_URL      = _ROOT_URL + '/video/{}?p={}'

    _MAIN_MODE = C.MAIN_MODE_daftsex
    _FIRST_PAGE = 0
    _FIRST_SEARCH_PAGE = 0
    _Right_Click_Option = None # C.DEFAULT_PLAYMODE # None to allow all possibilities [e.g. present HLS or MP4 play options]

##    _SAVE_COOKIES = True       #if we need to save html cookies
##    _SAVE_COOKIES = False       #if we need to save html cookies
    _SAVE_COOKIES = (
        '_cfuvid',
        )
    
    _ITEMS_NOT_FOUND_INDICATORS = [
        'Nothing Found'
        ,'>Sorry, this video has been deleted.</'
        ] #which to strings may indicate that there is nothing to be found

    _MIN_VALID_IMAGE_SIZE = 1500
    _BAD_IMAGE_SIZES = [576,1391]

##    #override categor from a basic url to custom function
##    def _URL_CATEGORIES(self):
##        cat_url = self._ROOT_URL + '/genres/uncensored/page/{}/' #2021-09-12
##        addDir(
##            name = '[COLOR {}]Uncensored[/COLOR]'.format(C.search_text_color)
##            ,url = cat_url
##            ,mode = self.LIST_MODE
##            ,page = self._FIRST_PAGE
##            ,iconimage=C.category_icon)
##        pass
##    def Categories(self, url, end_directory=True):
##        return True

    #__________________________________________________________________________
    # Change label created by List as neeeded by website
    def Normalize_ListLabel(self, label, hd):
##        LogR(label, C.LOGNONE)
        label = re.sub(r'(?i)[^a-z0-9 \&\;,\\\/\:\*\"\<\>\|]',' ',label)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        label = label.replace("\\\"", "'")
        while "  " in label:
            label = label.replace("  ", " ")
        return label

    
    #__________________________________________________________________________
    #videos on this page
    _REGEX_video_region = (
        '(?:div id="browse_section"|div class="videolist_results"|id="search_results_block")'
        '(.+?)'
        '(?:</videolisting>|id="w_pagination"|class="title_inactive")'
        )
    _REGEX_video_region = (
        '(?:div class="list_videos")'
        '(.+?)'
        '<div class="more"'
        )

    _REGEX_list_items = (
        #last daftsex to work before site went down 2023-08
        '<div class="video-item'  
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?data-thumb="(?P<thumb>[^"]+)"'
        '.+?<span class="video-time">(?P<duration>[^<]+)<'
        r'.+?"setTitle\(this\);">(?P<label>[^<]+)<'
        r'(?P<hd>(?:\[[^\]<]+(?:\]|<)|))'
        '(?P<desc>)'
        )

    _REGEX_list_items = (
        #lastest daftsex to work
        '<div class="item'  
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        '.+?(?P<hd>)'
        #(?:<i class="hd_mark">HD</i>|))'
        '.+?<div class="m_time">.+?</use></svg>(?P<duration>[^<]+)<'
        '(?P<desc>)'
        )
    
##    _IGNORE_404 = False

    #_LIST_METHOD = "POST"
    _LIST_HEADERS = {
        "User-Agent": C.USER_AGENT
        , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        , "Referer": _ROOT_URL
        , "X-Requested-With": "XMLHttpRequest"
        , "Accept-Encoding": "gzip"
        , "Accept-Language": "en-US,en;q=0.9"
    }
    def LIST_DATA(self, **kargs):
        page = kargs["page"]
        return "page={}".format(page)
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = '<nav class="pagination(.+?)</nav>'
    _REGEX_next_page_regex = '(>Show more<)' #as long as result is not empty

    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self.ROOT_URL + videourl
##        Log(videourl)
        return videourl
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):

        thumb2 = thumb.split('/i.mycdn.me/')
        if thumb2 and len(thumb2)>1:
            thumb = '//i.mycdn.me/'+thumb2[1]
        thumb2 = re.findall(r'(/[\w\-]+?\.userapi\.com/.+)', thumb)
        if thumb2 and len(thumb2)>0:
            thumb = '/'+thumb2[0]
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        thumb = thumb.replace('&amp;','&')
        headers = None #2022-12 thumbs need referrer
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
        if headers:
            thumb = thumb + utils.Header2pipestring(headers)

##        Log(thumb)
        return thumb
   
##    #__________________________________________________________________________
##    _REGEX_categories_region = 
##        (
##        'class="main_category_header"(.+)'
##        )
##    _REGEX_categories = (
##        '<span class="ic-check icr"><span>(?P<label>.+?)<'
##        '.+?<li data-id="(P<videourl>.+?)"'
##        '(?P<thumb>)'
##        )
##    def Category_URL_Normalize(self, url): # Change url found in via regex with structure neeeded by website
##        return self.ROOT_URL + url + '?page={}'

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        keyword = keyword.replace('+',' ').replace(' ','%20')
        return search_url.format(keyword, '{}')

##    #__________________________________________________________________________
##    #where playable urls live
    _REGEX_playsearch_01 = None #not for this site
##    (
##        ',?"?mediaDefinitions?"?:(?P<json>.+?\]),'  #video data as json
##        'data-hls-src(?P<res>\d+)'                #video data as res+url
##        '="(?P<url>[^"]+)"'
##        )
    #description for the playable url
    _REGEX_tags = None        #'<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    _REGEX_tags_region = None #'class="detail-video-block"(.+?)class="comments-wrapper"'

    #__________________________________________________________________________
    #
    _REGEX_icon_search = (
        '<link rel="preload" as="image" href="([^"]+)"',
        '<meta property="og:image" content="([^"]+)"',
        )
    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
        Log(u"Icon_Search url={}, pattern={}, referer={}".format(repr(url),repr(pattern),repr(referer))
            , C.LOGNONE
            )
        url = url.replace('daftsex.com', 'daft.sex')
        url = url.replace('daft.sex', 'mat6tube.com')

        thumb = None
        page_content = utils.getHtml(url, referer)
        for p in pattern:
            t = re.compile(p, re.DOTALL | re.IGNORECASE).findall(page_content)
            LogR(t)
            if t: thumb = self.Normalize_ThumbURL( t[0] )
            else: continue
            LogR(thumb)
            thumb = C.unescape(thumb)
            #thumb = thumb.replace('&amp;','&')
            LogR(thumb)
            try:
                test_load = utils.getHtml(thumb)
                if len(test_load) < self._MIN_VALID_IMAGE_SIZE:
                    thumb = None
                    Log('image too small to be real')
                if len(test_load) in self._BAD_IMAGE_SIZES:
                    thumb = None
                    Log('known bad image size')

                #good thumb...will save it
                break
            except Exception as ex:
                LogR(ex)
                    
##                raise Exception('image too small to be real')
        if not thumb:
##            traceback.print_exc()

            try: #try the vk url
                _REGEX_icon_search = (
                    ',"jpg":"([^"]+)"'
                    )
                vk_url = "https://m.vk.com/video"+url.replace("https://mat6tube.com/watch/","")
                LogR(vk_url)
                headers = C.DEFAULT_HEADERS.copy()
                headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
                headers['Referer'] = self._ROOT_URL
                headers['Cookie'] = 'remixmdevice=1746/982/1.100000023841858/!!-!!!!!!!!'
##                LogR(vk_url)
                vk_html = utils.getHtml(vk_url, headers=headers)
                for p in pattern:
                    thumb = re.compile(p, re.DOTALL | re.IGNORECASE).findall(vk_html)
                    if thumb: thumb[0] = self.Normalize_ThumbURL( thumb[0] )
                    else: continue
                    LogR(thumb)
                    try:
                        test_load = utils.getHtml(thumb)
                        if len(test_load) < self._MIN_VALID_IMAGE_SIZE:
                            thumb = None
                            Log('image too small to be real')
                        if len(test_load) in self._BAD_IMAGE_SIZES:
                            thumb = None
                            Log('known bad image size')
                        #good thumb...will save it
                        break
                    except Exception as ex:
                        LogR(ex)
                LogR(thumb)
            except Exception as ex:
                LogR(ex)
##                traceback.print_exc()
                thumb = None

        if not thumb:
            Log('not thumb')
            try:
                regex = (
                    r',"image":(\[.+?\])'
                         )
                image_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(vk_html)
                if image_region: image_region = image_region[0]
                else: image_region = ''
##                    LogR(image_region)

                image_list = json.loads(image_region)
##                    LogR(image_list)
                def my(n):
                    return n['width']
                thumb = sorted(image_list, key=my, reverse=True)[0]['url']
                thumb = self.Normalize_ThumbURL(thumb)
##                thumb = thumb.replace('&amp;','&')
                test_load = utils.getHtml(thumb)
                if len(test_load) < self._MIN_VALID_IMAGE_SIZE:
                    thumb = None
                    raise Exception('image too small to be real')                    
            except Exception as ex:
                LogR(ex)
                #traceback.print_exc()
                LogR(url)
                #try this hardcode
                regex = (
                    r'(/-?\d+(?:_|/)\d+)'
                         )
                vid_num = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(url)
                LogR(vid_num)
                vid_num = vid_num[0].replace("_", "/")
                thumb = "https://cdn2.pvvstream.pro/videos/{}/preview_320.jpg".format(vid_num)
                thumb = self.Normalize_ThumbURL(thumb)
                    
                    
        LogR(thumb, C.LOGNONE)
        thumb = self.Normalize_ThumbURL(thumb)
        
        LogR(thumb, C.LOGNONE)
##        exit(0)    
        return thumb

    #__________________________________________________________________________
    # Change LIST to enable max recurse depth
    def List(
        self
        , url
        , page_start=None
        , page_end=None
        , end_directory=True
        , keyword=''
        , testmode=False
        , progress_dialog=None
        , bulk_operation=False
        ):

        LogR(locals())
        org = C.MAX_RECURSE_DEPTH
        C.MAX_RECURSE_DEPTH = 10
        #py3
##        class Foo(Bar):
##    def baz(self, **kwargs):
##        return super().baz(**kwargs
        #python 2
        url = url + '&_=' + str(int(time.time()))
        super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
        C.MAX_RECURSE_DEPTH = org

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url; returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        Log("_ALTERNATE_playsearch_01(args='{}',kargs='{}'".format(repr(args)[0:250], repr(kargs)[0:250]))

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]



        video_url = None
        server = None

        class FinishException(Exception):
            def __init__(self, value):
                self.value = value
                LogR(value, loglevel=C.LOGWARNING, stacklevel=3)
            def __str__(self):
                return repr(self.value)


        try:

            len_alt_results = 0
            try:
##                raise FinishException('testing vk skipped')
            
                #try and get 1080p version [technically requires an account on vk.com, but sometimes not]
                vk_url = "https://vk.com/al_video.php?act=show_inline&al=1&video="+url.replace("https://daftsex.sex/watch/","")
                vk_url = "https://m.vk.com/video"+url.replace("https://daft.sex/watch/","")
                vk_url = "https://m.vk.com/video"+url.replace("https://mat6tube.com/watch/","")
                #important - user agent must match
                headers = C.DEFAULT_HEADERS.copy()
                headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
                headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0"
                headers['Referer'] = self._ROOT_URL
                headers['Cookie'] = 'remixmdevice=1746/982/1.100000023841858/!!-!!!!!!!!'

                vk_html = utils.getHtml(
                    vk_url,
                    headers=headers,
                    save_cookie=self._SAVE_COOKIES,
                    )

                regex = (
                        r'"items":\[\{"files":\{(.+)'
                         )
                file_region = re.compile(
                    regex,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(vk_html)
                if file_region: file_region = file_region[0]
                else: file_region = ''
                
                regex = (
                    r'(?:\{|,)"(?P<res>(?:mp4_\d+?|hls|hls_ondemand))"'
                    r':"(?P<url>[^"]+)"'
                         )
                vid_list = re.compile(
                    regex,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(file_region)

                video_url = None
                for  res,vid in vid_list:
                    vid = vid.replace(r"\/","/")
                    video_url = C.unescape(vid)
                    res = res.replace("mp4_","")
                    if res in ['hls','hls_ondemand']:
                        hls_info = utils.getHtml(video_url, headers=headers)
                        ## add -1 to favor MP4 versions over M3u8
                        if False:
                            pass
                        elif 'RESOLUTION=3840' in hls_info:
                            res = str(3840 - 1)
                        elif 'RESOLUTION=2560' in hls_info:
                            res = str(2560 - 1)
                        elif 'RESOLUTION=1920' in hls_info:
                            res = str(1920 - 1)
                        elif 'RESOLUTION=1440' in hls_info:
                            res = str(1440 - 1)
                        elif 'RESOLUTION=1280' in hls_info:
                            res = str(1280 - 1)
                        elif 'RESOLUTION=1080' in hls_info:
                            res = str(1080 - 1)
                        elif 'RESOLUTION=852' in hls_info:
                            res = str(852 - 1)
                        elif 'RESOLUTION=720' in hls_info:
                            res = str(720 - 1)
                        elif 'RESOLUTION=640' in hls_info:
                            res = str(640 - 1)
                        elif 'RESOLUTION=480' in hls_info:
                            res = str(480 - 1)
                        elif 'RESOLUTION=360' in hls_info:
                            res = str(360 - 1)
                        else:
                            res = str(640 - 1)

##                    LogR((res, video_url))
                    alt_results.append( (res, video_url) )
                raise FinishException('vk complete')

            except FinishException as ex:
##                LogR(ex,C.LOGWARNING)
                pass
            finally:
                if len(alt_results) > len_alt_results:
                    LogR(alt_results)
                    Log('found VK result')
                    len_alt_results = len(alt_results)
                else:
                    Log('NO found VK result')
                


            try:
                regex = (
                    r'<div id="player_box">(.+?)window.ads'
                         )
                url2 = re.compile(
                    regex,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(full_html)
                if not url2: raise FinishException("second url not found via regex:{}".format(regex))

                regex = (
                    r"<script>\s*window.playlistUrl\s*=\s*'(.+?)'"
                         )
                url3 = re.compile(
                    regex,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(url2[0])
                if url3: url3=self._ROOT_URL + url3[0]
                else: raise FinishException

                json_html = utils.getHtml(
                    url3,
                    self._ROOT_URL,
                    )
                try:                    
                    json_sources = json.loads(json_html)
                except:
                    if json_html:
                        Log(repr(json_html)[0:300])

                    json_sources = 'error'

                if "error" in json_sources:
                    raise StopIteration

                vid_list = list()
                key_list = list()
                if "sources" in json_sources:
                    for json_item in json_sources["sources"]:
                        Log("json_item={}".format(repr(json_item)))
                        res = json_item['label']
                        video_url = json_item['file']
##                        if not 'cdn2.pvvstream.pro' in video_url:
##                            alt_results.append( (res, video_url) )
                                
            except FinishException as e:
##                LogR(e)
                pass
            except:
                pass
            finally:
                if len(alt_results) > len_alt_results:
                    Log('found "player_box2" result')
                    len_alt_results += 1


            try: #2025-04  avoid cloudflare by reading html from download page
                regex = (
                    'window.downloadUrl="(.+?)"'
                         )
                download_url = re.compile(
                    regex,
                    re.DOTALL | re.IGNORECASE,
                    ).findall(full_html)
                if not download_url:
                    raise FinishException("not found via regex:" + regex)
                else: download_url = download_url[0]

                full_html = utils.getHtml(
                    self._ROOT_URL + download_url,
                    self._ROOT_URL,
                    save_cookie=self._SAVE_COOKIES,
                    )

                Log('download page successfully read')
            except FinishException as e:
##                LogR(e)
                pass

            try : #try this way
                regex = (
##                    "<script>\s*window.playlist = (.+?)(?:\}\;|,\"trusted\")"
                    r"<script>\s*window.playlist = (.+?\});"
                         )
                json_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
                if json_html: json_html=json_html[0]

                try:                    
                    json_sources = json.loads(json_html)
                except:
                    traceback.print_exc()
                    if full_html: Log(repr(full_html)[0:-1000])
                    if json_html: Log(repr(json_html)[0:500])
                    if json_html: Log(repr(json_html))
                    json_sources = 'error'

                if "error" in json_sources:
                    Log(repr(json_sources))
                    raise FinishException('"error" in json_sources')

                vid_list = list()
                key_list = list()
                headers = C.DEFAULT_HEADERS.copy()
                headers['Accept'] = 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5'
                headers['Referer'] = kargs["referer"]
                if "sources" in json_sources:
                    for json_item in json_sources["sources"]:
##                        Log("json_item={}".format(repr(json_item)))
                        res = json_item['label']
                        video_url = C.unquote_plus(json_item['file'])
                        video_url = video_url #+ '&dl=1'


                        if 'cdn2.pvvstream.pro'in video_url:
                            utils.Notify("A cdn2.pvvstream.pro source detected.  May not work") # due to cloudflare
                            try:
                                #make it less likely to be chosen
                                res = str(int(res) - 1)
                            except:
                                pass

                        if '|' not in video_url:
                            video_url += utils.Header2pipestring(headers)
                            
                        alt_results.append( (res, video_url) )


                            
            except FinishException as e:
##                LogR(e)
                pass
            finally:
                if len(alt_results) > len_alt_results:
                    LogR(alt_results)
                    Log('found "player_box3" result')
                    len_alt_results = len(alt_results)
            
            try :  #get the max 720p version ##2021-04 second file now has data

                regex = 'window.globEmbedUrl = \'([^\']+)\'.+?hash: "([^"]+)".+?color: "([^"]+)"'   ##2021-04 second file now has data
                url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
                if url2:
                    url2 = "{}{}?color={}".format(url2[0][0], url2[0][1], url2[0][2])
                    Log(repr(url2))
                    full_html = utils.getHtml(url2, self._ROOT_URL)
                else:
                    pass
                vid_id = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)    
                token = re.compile('access_token: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
                videos = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
                extra_key = re.compile('extra_key: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
                sig = re.compile(r'\s(?:sig|credentials):\s*"([^"]+?)",', re.DOTALL | re.IGNORECASE).findall(full_html)
                ckey = re.compile('c_key: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
                thumb = re.compile('thumb: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
                cdn_files = re.compile('cdn_files: {([^}]+)}', re.DOTALL | re.IGNORECASE).findall(full_html)
                server = re.compile('server: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
                partial = re.compile('partial: {"quality":({"[^}]+})', re.DOTALL | re.IGNORECASE).findall(full_html)
                #different versions of web page may not have same data
                try:    token = token[0]
                except: token = None
                try:    videos = videos[0]
                except: videos = None
                try:    ckey = ckey[0]
                except: ckey = None
                try: extra_key = extra_key[0]
                except: extra_key = None
                try:    cdn_files = cdn_files[0]
                except: cdn_files = None
                try:    thumb = base64.b64decode(thumb[0]).strip("thumb.jpg")
                except: thumb = None
                try:    server = base64.b64decode(server[0][::-1]) #reverse string then decode it
                except: server = None
                try:    sig = sig[0]
                except: sig = None
                try:    vid_id = vid_id[0]
                except: vid_id = None
                try: partial = json.loads(partial[0])
                except: partial = None
                if cdn_files: #newer style
                    Log('#newer style')
                    regex = r'"mp4_(\d+)":"([^"]+)'
                    vid_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cdn_files)
                    for res, vid in vid_list:
                        baseurl = "https://{}/videos/{}/".format(server, videos.replace("_","/"))
                        video_url = "{}{}".format(baseurl, vid.replace(".",".mp4?extra=") )
                        alt_results.append( (res, video_url) )
                    Log(repr(alt_results), C.LOGNONE)

                elif server: #older styple
                    base_str = "https://{}/method/video.get/{}?token={}&videos={}&ckey={}&credentials={}"
                    intermediate_url = base_str.format(server,vid_id,token,videos,ckey,sig)
                    http_referrer = "https://daxab.com/"

                    headers = C.DEFAULT_HEADERS.copy()
                    headers['Referer'] = self._ROOT_URL
                    headers['User-Agent'] = "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0)"
                    
                    json_html = utils.getHtml(intermediate_url, http_referrer)
                    try:                    
                        json_sources = json.loads(json_html)
                    except:
                        if json_html:
                            Log(repr(json_html)[0:300])
                            pass
                        json_sources = 'error'

                    if "error" in json_sources:
                        Log(repr(json_sources))
                        raise StopIteration

                    vid_list = list()
                    key_list = list()
                    if "response" in json_sources:
                        for json_item in json_sources["response"]["items"]:
                            for vid_src in json_item["files"]:
                                Log("vid_src={}".format(repr(vid_src)))
                                res = vid_src.split('=')[0].replace('mp4_','')
                                v_url = json_item["files"][vid_src]
                                Log("res={}".format(repr(res)))
                                vid_list.append( (res, v_url) )
                    Log("vid_list={}".format(repr(vid_list)))

                    
                    for q,u in vid_list: #this site needs quality info
                        video_proxy_res = None    
                        Log("q={}".format(q))
                        Log("u={}".format(u))
                        Log(repr(partial))
                        video_url = u
                        #if video_url == u:
                        if q in partial:
                            video_proxy_res = q
                            extra_key_hidden = partial[q]
                            if video_proxy_res:
                                video_url = video_url.replace("https://", "https://"+server+"/") #needs this remote proxy
                                video_url = video_url + "&videos={}&extra_key={}&videos={}".format(vid_id, extra_key_hidden, vid_id)
                                video_url += utils.Header2pipestring(headers)
                            
                            
                        else:
                            continue #if no extra_key, then res not available
                        LogR(alt_results)
                        alt_results.append( (q, video_url) )
            except StopIteration:
                pass
            finally:
                if len(alt_results) > len_alt_results:
##                    LogR(alt_results)                    
                    Log('found "access_token" result')
                    len_alt_results = len(alt_results)
                    
        except:
            traceback.print_exc()
            utils.Notify("Unknown error for url {}".format(url))
        finally:
            LogR(alt_results)
                
##        raise Exception()
        return alt_results

#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.REBUILD_ICON, ['url'])
def Rebuild_Icon(url):
    website.Rebuild_Icon(url)
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.PLAY_MODE
    , ['url', 'name']
    , ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode']
    )
def Playvid(
    url
    , name
    , download=None
    , playmode_string=None
    , play_profile=None
    , testmode=False
    , icon_URI=None
    ):

##    import io
##    string_file = io.StringIO(u"")
##    traceback.print_stack(file=string_file)
##    LogR(string_file, C.LOGNONE)

##    LogR(traceback.extract_stack(), C.LOGWARNING)
##    LogR(locals(), C.LOGNONE)
    
    url = url.replace('daftsex.com', 'daft.sex')
    url = url.replace('daft.sex', 'mat6tube.com' )
    u =  website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
    LogR(u)
    return u
#__________________________________________________________________________
#
