'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils
import resolver

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Porn00[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True

    _ROOT_URL        = "https://www.porn00.org"
    _URL_CATEGORIES  = _ROOT_URL + '/category-list/'
    _URL_RECENT      = _ROOT_URL + '/porn-page/{}/'
    _SEARCH_URL      = _ROOT_URL + "/searching/?q={}&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&from_videos={}"
    _SEARCH_URL      = _ROOT_URL + "/searching/{}/?q={}&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&from_videos={}&category_ids=&sort_by="
#https://www.porn00.org/searching/aaliyah   /?q=aaliyah&mode=async&function=get_block&block_id=list_videos_videos_list_search_result&from_videos=2&category_ids=&sort_by=&from_albums=2&_=1764203005425 HTTP/1.1
    _URL_MOST_VIEWED = _ROOT_URL + '/most-viewed/'
    _MAIN_MODE = C.MAIN_MODE_porn00
    _FIRST_PAGE = 1

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "Hmm, nothing to see here"
        , "No videos found for "
        , 'Sorry, this video was deleted per copyright owner request.'
        ]
    #__________________________________________________________________________
    #specific header required for listing
##    _LIST_HEADERS = {
##        "Accept":"application/json, text/plain, */*"
##        ,"DNT":"1"
##        ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"
##        ,"Origin":"https://beeg.com"
##        ,"Referer":"https://beeg.com/"
##        ,"Accept-Encoding":"gzip, deflate"
##        ,"Accept-Language":"en-US,en;q=0.9"
##    }
    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = 'class="list-videos(.+)'
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
            'div class="item' 
             '.+?href="(?P<videourl>[^"]+)"'
             '.+?title="(?P<label>[^"]+)"'
             '.+?data-original="(?P<thumb>[^"]+)"'
             '.+?(?P<hd>(?:<span class="is-hd"></span>|class="title"))'
             '.+?class="duration">(?P<duration>[^<]+)<'
        )
    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = r"<li class='.+?pagination.+?'>([^<]+)</div>"
    _REGEX_next_page_regex =  r'<li class="next">.+?:(\d+)">Next'

    #__________________________________________________________________________
    #where categories can be found
    _REGEX_categories_region = '<div class="list-categories">(.*?)class="footer-margin"'
    _REGEX_categories = (
        r'class="item" href="(?P<videourl>[^"]+)"'
        r'.+?src="(?P<thumb>[^"]+)"'
        r'.+?alt="(?P<label>[^"]+)"'
##        'value="(/cat[^"]+)"'
##        '.+?>([^<]+)<'
##        '()'
        )
##    #__________________________________________________________________________
##    #where playable urls live
##    _REGEX_play_region = (
##        '<div class="dloaddivcol">(.+?)</div>'
##        )
##    _REGEX_playsearch_01 = (
##        '<u>(?P<res>\d+)'
##        '.+?href="(?P<url>[^"]+?)"'
##        )
##    _REGEX_playsearch_01 = C.FLAG_USE_RESOLVER_ONLY #send all the text to resolver module

##    #__________________________________________________________________________
##    # Change video source url found in via regex with a structure used by site
##    def Video_Source_URL_Normalize(self, url):
##        url = "".join((self._ROOT_URL, url))
####        Log(url)
##        return url
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags =        r'class="vit-pornstar.+?href="/pornstar/.+?>([^<]+)<\/a>'
    _REGEX_tags_region = r"(.+)"           #'class="categorieswrapper(.+?)<noscript>'
    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
        if not thumb.startswith('http'): thumb = 'http:' + thumb
##        LogR(locals())
        return thumb
##    #__________________________________________________________________________
##    # add update duration as necessary
##    def Normalize_Duration(self, duration):
##        duration = duration.strip().replace('h ', ':00').replace(' min', ":00")
####        LogR(locals())
##        return duration
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
##        LogR(locals())
        if not videourl.startswith('http'): videourl = self._ROOT_URL + videourl
##        LogR(locals())
        return videourl
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = self._ROOT_URL
        url = url + '{}/'
##        LogR(locals())
        return url
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        SITE_NOT_AVAILABLE_WARNINGS = {
            'Sorry, the website is temporary unavailable.'
            }
        if any(x in full_html for x in SITE_NOT_AVAILABLE_WARNINGS):
            utils.Notify("Website is temporary unavailable {}".format(name))
            Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
            return
            pass
        if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
            Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
            return
            pass

        regex = "license_code: '(?P<lic>[^']+)'"
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if not sources_list:
            utils.Notify("No license code for {}".format(name))
            return
        license_code = sources_list[0]
        Log("license_code={}".format(license_code))

        list_key_value = {}
        regex = r"video_(?:alt_|)url: 'function\/0\/(?P<url>[^']+).+?(?:video_(?:alt_|)url_text: '(?P<res>[^']+)p')"
        regex = ( #2025-12-07
            r"video_(?:alt_|)url: '(?P<url>[^']+)"
            r".+?"
            r"(?:video_(?:alt_|)url_text: '(?P<res>[^']+)p')" 
            )
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
        for source_list in sources_list:
            Log("source_list={}".format(source_list))
            if source_list.group('res'):
                list_key_value[source_list.group('res')] = source_list.group('url')
            else:
                list_key_value['240'] = source_list.group('url')
        Log("list_key_value={}".format(list_key_value))

        if len(list_key_value) < 1: #try this other method
            regex = r"video_url:\s+'function\/0\/(?P<url>[^']+)"
            sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
            Log("sources_list={}".format(sources_list))
            for source_list in sources_list:
                list_key_value['240'] = source_list.group('url')
            Log("list_key_value={}".format(list_key_value))
            

        fappy_salt = resolver.FaapySalt(license_code, "")
##        Log("fappysalt='{}'".format(fappy_salt))
##        encoded_fappy_code =  encoded_url.split('/')[5][0:32]
##        Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
##        new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
##        Log("new_fappy_code='{}'".format(new_fappy_code))
##        video_url = encoded_url.replace(encoded_fappy_code, new_fappy_code)
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
##        video_url = video_url + utils.Header2pipestring(headers)
##        Log("video_url='{}'".format(video_url))
        
        for rez in list_key_value:
            LogR((rez, list_key_value[rez]))
            encoded_url = list_key_value[rez]
            encoded_fappy_code =  encoded_url.split('/')[5][0:32]
            new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
            video_url = encoded_url #2025-12-07 no replace needed
##            video_url = encoded_url.replace(encoded_fappy_code, new_fappy_code)
            video_url = video_url + utils.Header2pipestring(headers)
            alt_results.append(  (rez, video_url )  )

##        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
##        encoded_url = utils.SortVideos(
##            sources=list_key_value
##            ,download=download
##            ,vid_res_column=0
##            ,max_video_resolution=max_video_resolution
##            )

##        if not encoded_url:
####            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
##            return alt_results

        


        
##        LogR(alt_results)
##        return None
        return alt_results
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        keyword = keyword.replace('+','-').replace(' ','-')
##        LogR(locals())
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format(keyword,keyword,'{}')
##        LogR(locals())
        return search_url
##    #__________________________________________________________________________
##    # Change LIST to enable max recurse depth
##    def List(self, url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
##        try:
##            org = C.MAX_RECURSE_DEPTH
##            if C.PY3:                       super().List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            if C.PY2: super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            C.MAX_RECURSE_DEPTH = org
##        except:
##            pass
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
