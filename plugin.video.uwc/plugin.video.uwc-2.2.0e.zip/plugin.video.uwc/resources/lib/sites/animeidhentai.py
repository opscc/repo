'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import base64
from utils import postHtml


import constants as C
from base_website import Base_Website
from utils import Log,LogR

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Animeid Hentai[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_HENTAI
    _FRONT_PAGE_CANDIDATE = False
    _ROOT_URL        = "https://animeidhentai.com"
    _URL_CATEGORIES  = None #no categories for this site
    _URL_RECENT      = _ROOT_URL + '/wp-admin/admin-ajax.php'
    _SEARCH_URL      = _ROOT_URL + '/wp-admin/admin-ajax.php'
    _MAIN_MODE = C.MAIN_MODE_animeidhentai
    _FIRST_PAGE = 1
    _Right_Click_Option = None #C.DEFAULT_PLAYMODE # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _SAVE_COOKIES = True       #if we need to save html cookies
    _ITEMS_NOT_FOUND_INDICATORS = [] #which to strings may indicate that there is nothing to be found

##    #__________________________________________________________________________
    #videos on this page
##    _REGEX_video_region = \(
##        '(?:div id="browse_section"|div class="videolist_results"|id="search_results_block")'
##        '(.+?)'
##        '(?:</videolisting>|id="w_pagination"|class="title_inactive")'
##        )
##    _REGEX_list_items = (
##        '<article class="anime.+?src="(?P<thumb>[^"]+?)"'
##        '.+?alt="(?P<label>[^"]+?)"'
##        '.+?<header class="anime.+?span(?P<hd>.+?)</header>'
##        '.+?href="(?P<videourl>[^"]+?)"'
##        '(?P<duration>)'
##        '(?P<desc>)'
##        ) #2021-10
    _REGEX_list_items = (
        '<article class=\\\\"anime '
        '.+?src=\\\\"(?P<thumb>[^"]+?)\\\\"'
        '.+?class=\\\\"description.+?<p>(?P<desc>[^<]+?)<\\\\/p>'
        '.+?aria-label=\\\\"(?P<label>[^"]+?)\\\\"'
        '.+?href=\\\\"(?P<videourl>[^"]+?)\\\\"'
        '(?P<duration>)'
        '(?P<hd>)'
        ) #2021-12
    
    _IGNORE_404 = False
    _LIST_METHOD = "POST"
    _LIST_HEADERS = {
        "User-Agent": C.USER_AGENT
        , "Content-Type": "application/x-www-form-urlencoded"
        , "Accept": "*/*"
        , "Origin": _ROOT_URL
        , "X-Requested-With": "XMLHttpRequest"
#        , "Referer": _SEARCH_URL.format(keyword)
        , "Accept-Encoding": "gzip"
        , "Accept-Language": "en-US,en;q=0.9"
#        , "X-WP-Nonce": "76cff21f89"  #value can be found in https://animeidhentai.com/?s=
    }

    def LIST_DATA(self, **kargs):
        try:
            page_start = kargs["page"]
            keyword = kargs["keyword"]
    ##        return "action=action_ajax_filter&query_vars=null&paged={}&order=latest&search={}".format(page,keyword) #2021-10
            list_string = 'action=action_results&vars=%7B%22_wpresults%22%3A%2276cff21f89%22%2C%22taxonomy%22%3A%22none%22%2C%22search%22%3A%22{}%22%2C%22term%22%3A%22none%22%2C%22type%22%3A%22episodes%22%2C%22genres%22%3A%5B%5D%2C%22years%22%3A%5B%5D%2C%22sort%22%3A%221%22%2C%22page%22%3A{}%7D'.format(
                keyword
                ,page_start
                )
    ##        u='https://animeidhentai.com/wp-content/plugins/litespeed-cache-1/guest.vary.php'
    ##        postHtml(u,NoCookie=False) #generate a needed cookie
            return list_string
        except:
            LogR(locals(),C.LOGNONE)
            raise
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        thumb = thumb.replace("\\/","/")
        return thumb

    def Normalize_VideoURL(self, videourl):
         return videourl.replace("\\/","/")


##    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="w_pagination"(.+?)class="footer"'
    _REGEX_next_page_regex = '(<article class=\\\\"anime )' #as long as result is not empty

##    #__________________________________________________________________________
##    _REGEX_categories_region = 
##        (
##        'class="main_category_header"(.+)'
##        )
##    _REGEX_categories = (
##        '<span class="ic-check icr"><span>(?P<label>.+?)<'
##        '.+?<li data-id="(P<videourl>.+?)"'
##        '(?P<thumb>)'
##        )
##    def Category_URL_Normalize(self, url): # Change url found in via regex with structure neeeded by website
##        return self.ROOT_URL + url + '?page={}'

##    #__________________________________________________________________________
##    # Change SEARCH_URL to replace spaces with a char that website wants
##    def Search_URL_Normalize(self, search_url, keyword):
##        return search_url.format(keyword,'{}')


##    #__________________________________________________________________________
##    #where playable urls live
    _REGEX_playsearch_01 = None #not for this site
##    (
##        ',?"?mediaDefinitions?"?:(?P<json>.+?\]),'  #video data as json
##        'data-hls-src(?P<res>\d+)'                #video data as res+url
##        '="(?P<url>[^"]+)"'
##        )
    #description for the playable url
    _REGEX_tags = None #'<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    _REGEX_tags_region = None #'class="detail-video-block"(.+?)class="comments-wrapper"'


    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
##        Log("_ALTERNATE_playsearch_01(args='{}',kargs='{}'".format(repr(args), repr(kargs)))

##        C.DEBUG = True
        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        import json, re
        import utils

        regex = r'id="play-iframe".+?src="([^"]+)"' #2020-12-14
        regex = r'<iframe src="([^"]+)"' #2021-03-18
        regex = r'<iframe onload=.+?data-wpfc-original-src="([^"]+)"' #2021-07-09
        regex = r'<iframe src="([^"]+)"' #2021-07-16
        regex = r'<iframe.+?src="(https://htstreaming.com[^"]+)"' #2021-08-17
        regex = r'<iframe.+?(?:data-id|src)="(https://(?:htstreaming|nhplayer).com[^"]+)"' #2022-04-17


        next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        Log("next_link={}".format(repr(next_link)))
        if next_link:
            next_link = next_link[0]
            next_html = utils.getHtml(next_link, url)
        else:
            Log("no iframe src was found")
            return alt_results

        if not 'htstreaming' in next_link:
            regex = r'(?:data-id|src)="(https://(?:htstreaming|nhplayer).com[^"]+)"' #2022-04-17
            next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_html)
            Log("next_link={}".format(repr(next_link)))
            if next_link:
                next_link = next_link[0]
                next_html = utils.getHtml(next_link, url)
            else:


                patterns = [
                      r'data-id="/player.php\?u=([^&]+?)&s=([^&]+?)&'
                    , r'data-id="/player.php\?u=(.+?)&type="(.)'
                    , r'data-id="/player.php\?(vid=a.+?)&type="()'
                    ]
                for regex in patterns:
                    next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_html)
                    if next_link:
##                        next_link = next_link[0]
                        break
                Log("next_link={}".format(repr(next_link)))

                for video_url, subtitles_url in next_link:

                    #sometimes a subtitle is embedded in the first link
                    try:
                        subtitles_url = dict(C.urlparse.parse_qsl(video_url))['s']
                    except:
                        pass
                    #sometimes an image is embedded in the first link
                    try:
                        thumb_url = dict(C.urlparse.parse_qsl(video_url))['i']
                    except:
                        thumb_url = None
                    try:
                        video_url = dict(C.urlparse.parse_qsl(video_url))['vid']
                    except:
                        pass
                    Log(video_url)
                    
                    if C.PY2: video_url = base64.b64decode( video_url )
                    if C.PY3: video_url = str(base64.b64decode(video_url), 'utf8')
                    headers = {
                        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0'
                        ,'Referer':'https://nhplayer.com/'
                        }
                    video_url +=  utils.Header2pipestring(headers)
                    Log("video_url={}".format(repr(video_url)))

                    if subtitles_url:
                        if C.PY2: subtitles_url = base64.b64decode( subtitles_url )
                        if C.PY3: subtitles_url = str(base64.b64decode(subtitles_url), 'utf8')
                        Log("subtitles_url={}".format(repr(subtitles_url)))
                    #return
                    alt_results.append( ('1', video_url) )
                LogR(alt_results)
                return alt_results
        


        import jsunpack
        unpacked_src = jsunpack.unpack(next_html)
        Log("unpacked_src={}".format(repr(unpacked_src)))

##        if len(alt_results) < 1:
##            try:
                

        try:
            
            #working 2020-07
            regex = r'sources:(\[.*?\])'
            sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
            Log("sources_list='{}'".format(sources_list))
            if not sources_list:
                raise Exception('2020-07 method not working')

            sources = json.loads(sources_list[0])
            Log("sources='{}'".format(sources))
            Log("sources[file]='{}'".format(sources[0]['file']))
            video_url = sources[0]['file']
            alt_results.append( ('1', video_url) )
        except:
            #working 2020-08
            regex = r'FirePlayer\(vhash, (.+), false\);'
            sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_html)
            Log("sources_list='{}'".format(sources_list))
            try: 
                if not sources_list:
                    raise Exception('2020-08 method not working')
                
                sources = json.loads(sources_list[0])
                Log("sources='{}'".format(sources))
                video_url = "https://htstreaming.com{}?s={}&d=".format(
                    sources['videoUrl']
                    ,sources['videoServer']
                    )
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = next_link
                video_url +=  utils.Header2pipestring(headers)
        
                Log("video_url={}".format(video_url.encode()))
                isHLS = sources['videoData']['videoSources'][0]['type'] == u'hls'
                alt_results.append( ('1', video_url) )
            except:
                #working 2021-07
                regex = r'{FirePlayer\("([^"]+)"'
                sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
                Log("sources_list={}".format(repr(sources_list)))
                #https://htstreaming.com/player/index.php?data=f3102064ef90bf7d811c330f976366f7
                sources = sources_list[0]
                Log("sources='{}'".format(sources))
                post_url = "https://htstreaming.com/player/index.php?data={}".format(
                    sources
                    )
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = next_link
                headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
                headers['X-Requested-With'] = 'XMLHttpRequest'
                post_json = utils.getHtml(post_url + '&do=getVideo'
                                          , headers = headers
                                          , method = 'POST'
                                          , sent_data = 'hash=sources'
                                          )
                Log("post_json={}".format(repr(post_json)))
                sources = json.loads(post_json)
                Log("sources={}".format(repr(sources)), C.LOGNONE)

                video_url = sources['videoSource']
                Log("video_url={}".format(video_url.encode()))
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = post_url
                del headers['Accept-Encoding']  #remove encoding here -- or make sure player does it at some time

                video_url +=  utils.Header2pipestring(headers)
                
                Log("video_url={}".format(video_url.encode()))

                alt_results.append( ('1', video_url) )
      
##                return list()

                
        

        return alt_results
    #__________________________________________________________________________
    #

#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
