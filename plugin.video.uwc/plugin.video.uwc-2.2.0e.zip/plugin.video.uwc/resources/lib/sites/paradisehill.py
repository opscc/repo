#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils
import resolver

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]paradisehill[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_MOVIES
    _FRONT_PAGE_CANDIDATE = False

    _ROOT_URL        = "https://en.paradisehill.cc"
    _SEARCH_URL      = _ROOT_URL + '/search/?pattern={}&page={}'
    _URL_CATEGORIES  = _ROOT_URL + '/categories/'
    _URL_RECENT      = _ROOT_URL + '/all/?sort=created_at&page={}'
    _URL_MOST_VIEWED = _ROOT_URL + '/most-viewed/'
    _MAIN_MODE = C.MAIN_MODE_paradisehill
    _FIRST_PAGE = 1

    _IGNORE_404 = False #sometimes 404 is ok, sometimes not

    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "No results found"
        ]
    
    #__________________________________________________________________________
    #specific header required for listing
##    _LIST_HEADERS = {
##        "Accept":"application/json, text/plain, */*"
##        ,"DNT":"1"
##        ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"
##        ,"Origin":"https://beeg.com"
##        ,"Referer":"https://beeg.com/"
##        ,"Accept-Encoding":"gzip, deflate"
##        ,"Accept-Language":"en-US,en;q=0.9"
##    }

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = (
                'class="content">'
                '(.+)'
                'class="pagination"'
                    )
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        'list-film-item"'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?itemprop="image" src="(?P<thumb>[^"]+)"'
        '.+?itemprop="name">(?P<label>[^<]+)<'
        '(?P<duration>)'
        '(?P<hd>)'
        #2024-04-09
##        ?P<videourl>
##        ?P<thumb>
##        ?P<label>
##        ?P<duration>
##        '(?P<hd>)'
##        ?P<desc>
    )                         
##    #__________________________________________________________________________
##    # add an alternative way to resolve listing
##    def List_URL_Normalize(self, url, page):
##        if url.endswith("/1/"): #site does not always like this
##            url = url[:-3]
##        return url
##    #__________________________________________________________________________
##    # Change LIST to enable max recurse depth
##    def List(self, url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
##        try:
##            org = C.MAX_RECURSE_DEPTH
##            if C.PY3:                       super().List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            if C.PY2: super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            C.MAX_RECURSE_DEPTH = org
##        except:
##            pass

    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self.ROOT_URL + videourl        
        return videourl
    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
        if not thumb.startswith('http'): thumb = self.ROOT_URL + thumb
        return thumb
##    #__________________________________________________________________________
##    # add update duration as necessary
##    def Normalize_Duration(self, duration):
##        duration = duration.strip().replace(' min', ":00")
##        return duration


    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = (
        'class="pagination">'
        '(.+)'
        '<noindex>'
        )
    _REGEX_next_page_regex = (
            '(">&raquo;<)'
        )

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        keyword = keyword.replace(' ','+')
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format(keyword,'{}')
        return search_url
    

##    #__________________________________________________________________________
##    #where categories can be found
##    _REGEX_categories_region = (
##        'All porn categories</h2>'
##        '(.*)'
##        '<div class="title-bar">'
##        )
    _REGEX_categories = (
        r'schema\.org/Movie'
        r'.+?href="(?P<videourl>[^"]+)"'
        r'.+?itemprop="name"><span>(?P<label>[^<]+)<'
        r'.+?src="(?P<thumb>[^"]+)"'
####        ?P<videourl>
####        ?P<thumb>
####        ?P<label>
        )
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = self._ROOT_URL + url
        url += "&page={}"
    
##        key = url.split('/categories/')[1].split('/')[0]
##        url =  "{}/categories/{}/?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date&from={}".format(
##                self._ROOT_URL, key, '{}'
##                )
        return url
    #__________________________________________________________________________
    # Change category thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        if not thumb.startswith('http'): thumb = self._ROOT_URL + thumb
        return thumb
  

    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags_region = (
        r'class="opisanie"(.+?)<noindex>'
        )
    _REGEX_tags = (
        r'"/actor/.+?>([^<]+)<'
        )


    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        url = kargs["referer"]
        ask_which_file_hoster = kargs["ask_which_file_hoster"]
        video_url = None

        regex = r'(.*)div class="main"'
        video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(kargs["full_html"])[0]
        regex = r"videoList = (\[.+}\]}\]);"
        info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)[0]
        info = info.replace('\\/','/')
        videos = json.loads(info)
    
        videos = [x['sources'][0]['src'] for x in videos]

        if len(videos) > 1:
            i = 1
            videolist = []
            for x in videos:
                videolist.append('Part ' + str(i))
                i += 1
            if ask_which_file_hoster:
                videopart = C.dialog.select('Multiple videos found', videolist)
            else:
                videopart = 0
            if videopart == -1:
                return
            video_url = videos[videopart]
            name = kargs["name"] + ': Part ' + str(videopart+1)
        else:
            video_url = videos[0]

        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        
        video_url = video_url + utils.Header2pipestring(headers)
        Log("video_url='{}'".format(video_url))

        alt_results.append(  ('240', video_url )  )

        return alt_results

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()

#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    LogR('error')
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid(
        url
        , name
        , download=download
        , playmode_string=playmode_string
        , play_profile=play_profile
        , testmode=testmode
        , icon_URI=icon_URI
        )
#__________________________________________________________________________
#
