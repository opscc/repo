'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
from base_website import Base_Website
from utils import Log,LogR

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]perfectgirls[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = False
    
    _ROOT_URL        = "https://www.perfectgirls.xxx"
    _URL_CATEGORIES  = None #_ROOT_URL #2023 don't bother with this
    _URL_RECENT      = _ROOT_URL + '/{}/'
    _SEARCH_URL      = _ROOT_URL + '/search/{}/{}/'
    _MAIN_MODE = C.MAIN_MODE_perfectgirls

    _FIRST_PAGE = 1

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        'nothing found. Use more general words or phrases'
        ]

    #where we can find videos on this page [exclude advertisement]
    
    #videos on this page
    #_REGEX_video_region = 'class="top-videos"(.+?)<!-- /container -->'
    _REGEX_video_region = 'id="custom_list_videos_custom_videos"(.+?)<div class="pagination">'
    _REGEX_list_items = (
        '<div class="thumb thumb-video">'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?data-original="(?P<thumb>[^"]+)"'
        '.+?fa-clock-o"></i> <span>(?P<duration>[^<]+)<'
        '(?P<hd>)'
        )

    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'class="pagination(.+?)class="container"'
    _REGEX_next_page_region = r'class="pagination(.+?)<style>'
    _REGEX_next_page_regex =  r'(href=".+?\d+/">Next<)'

    #if we need to save html cookies
    _SAVE_COOKIES = False

    #where categories can be found
    _REGEX_categories_region = (
        '>Categories<(.+?)>Pornstars<'
        )
    _REGEX_categories = (
        'href="(?P<videourl>[^"]+)"'
        '>(?P<label>[^<]+)<'
        '(?P<thumb>)'
        )

    #where playable urls live
##    _REGEX_play_region = (
##        'class="video__resource"(.+?)class="video__info"'
##        ) #works 2022
    _REGEX_play_region = (
        'class="video-block"(.+?)<div class="video-info">'
        )
    _REGEX_playsearch_01 = None
    
    #description for the playable url
    _REGEX_tags_region = None #'id="video-about"(.+?)id="video-tags"'
    _REGEX_tags = None #'/pornstars/.+?>([^<]+)<'

    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url + '/{}'
##href="/category/5/Amateur__Homemade">
##http://www.perfectgirls.net/category/5/Amateur__Homemade/3

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format(keyword,'{}')

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        return keyword.replace('+',' ').replace(' ','-')

    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by website
    def Video_Source_URL_Normalize(self, url):
        return "https:" + url

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def ALTERNATE_playsearch_01(self, *args, **kargs):
        Log(repr((args,kargs)))
        import base64
        import json
        import re
##        import utils
        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(full_html)
        if license_code:
            license_code = license_code[0]
        else:
            Log("No license_code found for {}".format(url))
#            return alt_results

        regex = (
            r"video(?:_alt)?_url\d?:"
            r".+?'function/0/(?P<url>[^']+)'"
            r".+?video(?:_alt)?_url\d?_text:"
            r".+?'(?P<res>\d+)p.*?'"
                 )
        
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if not sources: sources =[] #fake data so that next code can look simpler

        import resolver
        import utils

        for video_url, res in sources:
            video_url += "?_rnd=" + utils.RandomNumber()
            Log("license_code='{}'".format(license_code) )
            fappy_salt = resolver.FaapySalt(license_code, "")
            Log("fappysalt='{}'".format(fappy_salt))
            old_fappy_code =  video_url.split('/')[5]
            Log("old_fappy_code='{}'".format(old_fappy_code))
            new_fappy_code = resolver.ConvertFaapyCode( old_fappy_code, fappy_salt)
            Log("new_fappy_code='{}'".format(new_fappy_code))

            video_url = video_url.replace(old_fappy_code, new_fappy_code)
            
            alt_results.append(  (res, video_url)  )

        if not alt_results:
            Log("ur123l='{}'".format(url), C.LOGNONE)
            regex = ("let url = '(?P<url>[^']+)';"
                     )
            sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
            if not sources: sources =[] #fake data so that next code can look simpler
            for video_url in sources:
                alt_results.append(  ('240', video_url)  )

        Log("alt_results={}".format(repr(alt_results)))        
        return alt_results
    

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
##@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
##def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
##    website.Playvid(url, name, download, playmode_string, play_profile=play_profile, testmode=testmode, icon_URI=icon_URI)
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
