'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import json
import re
import time
import traceback
import xbmc
import base64

import os
import sqlite3
import random
    
import utils
from utils import Log,LogR
import constants as C
import downloader
    
FRIENDLY_NAME = '[COLOR {}]Naked.com[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.naked.com"
SEARCH_URL = 'stub - make all sites consistent'
URL_FEMALES = ROOT_URL + "/live/girls/"
RESULTS_PER_PAGE = 0

MAIN_MODE          = C.MAIN_MODE_naked 
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
CLEANDATABASE_MODE = str(int(MAIN_MODE) + 5)
TEST_MODE          = str(int(MAIN_MODE) + 6)

FIRST_PAGE= '1'

_MIN_VALID_IMAGE_SIZE = 5000

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():

    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )
        
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_FEMALES, page_start=FIRST_PAGE, page_end=None, end_directory=True, keyword='', progress_dialog=progress_dialog)
#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page=FIRST_PAGE, page_end=None, depth=1, notify=False, progress_dialog=None):
##    Log(repr((progress_dialog,notify)),xbmc.LOGNONE)
    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    if '{}' in url and page: list_url = url.format((int(page)-1)*RESULTS_PER_PAGE)
    else: list_url = url

    json_items = json.loads("[]")
    listhtml = utils.getHtml(list_url
                             , cache_duration=C.default_ISONLINE_cache_duration)
    if listhtml is None: return json_items #in case we don't have IP

    regex = r"'models':\s\[\s+?({.+}),\s+\],\s+'favorites':\s\["
    html_models = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if html_models:
        html_models = html_models[0]
        html_models = '{ "models": [' + html_models + ']}'
    else:
        Log(repr(html_models), xbmc.LOGNONE)
        html_models = '{ "models": []}'


    json_models = json.loads(html_models)    

    for model in json_models["models"]:
            
        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        if not (model['room_status_char'] in ['O','F']):
            continue
##        if model['room_status_char'] in ['O','F']:
##            json_items.append(json_item)


        model_id = model["model_id"]
        seo_name = model["model_seo_name"]
        video_host = model["video_host"]
        icon_image = "https://live-screencaps.vscdns.com/{}-desktop.jpg{}".format(
            model_id
            ,"?_{}".format(utils.RandomNumber()) #random value added to make sure we always have a fresh image
            ) #this site's screencaps are not updated frequently
        video_url = (
            "{}/webservices/chat-room-interface.php?a=login_room&model_id={}".format( \
                   ROOT_URL, model_id)
               )

##        LogR(int(model["power_score_xvc"])/200)
        try:
            camscore = int(model["power_score_xvc"])/200 # num_users power_score_xvc
        except:
            camscore = 1
            Log(repr(model), xbmc.LOGNONE)

        if "video_width" in model: hd = model["video_width"]
        else: hd = ''
        
        if hd:
            hd = str(hd.split('x')[0])
        else:
            hd = ''

        if   '4k' in hd :
            camscore=camscore*4
            hd = " [COLOR {}]uhd[/COLOR]".format(C.refresh_text_color)
        elif '1920' in hd :
            camscore=camscore*3
            hd = " [COLOR {}]fhd[/COLOR]".format(C.refresh_text_color)
        elif '1280' in hd :
            camscore=camscore*2
            hd = " [COLOR {}]hd[/COLOR]".format(C.time_text_color)
        elif '1152' in hd :
            camscore=camscore*1
            hd = " [COLOR {}]hd[/COLOR]".format(C.time_text_color)
        else:
            hd = ""
        icon_label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(seo_name), hd)

        json_item = {}
        json_item['modelID'] = seo_name
        json_item['username'] = seo_name
        json_item['video_url'] = video_url
        json_item['mode'] = PLAY_MODE
        json_item['icon_image'] = icon_image
        json_item['camscore'] = camscore
        json_item['description'] = '\n' + ROOT_URL
        json_item['icon_label'] = icon_label
        json_item['play_method'] = ''
        json_item['video_host'] = video_host

        json_items.append(json_item)

        
    return json_items
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'end_directory', 'testmode'])
def List(url, page_start=None, page_end=None, end_directory=True
         , keyword='', testmode=False, progress_dialog=None, bulk_operation=False):
    Log("List(url={}, page_start='{}', end_directory='{}', keyword='{}')".format(url, page_start, end_directory, keyword))

    utils.Add_Refresh_Item(REFRESH_MODE,end_directory=end_directory)

    models = GetCamgirlList(url, page_start, progress_dialog=progress_dialog)
    for model in models:
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            , hq_stream = model['video_host'] #used to carry this info special to this provider; some links need this for some reason; maybe a dead server on day of programming?
            )
    # check for a minimum during tesing
##    if len(models) < 1 and testmode:
##        utils.addDownLink(
##            name="[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, 'listitems failed {}'.format(ROOT_URL))
##            ,url=list_url
##            ,mode=1
##            )
##        raise OSError
    if (progress_dialog is None) or (progress_dialog and not progress_dialog.iscanceled()):
##        utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
        if (testmode == True) and (len(models) > 1):
            Playvid(model['video_url'], model['icon_label'], icon_URI=model['icon_image'], download=True, playmode_string=None, testmode=testmode)


    # no next page at this time
    if not end_directory: return

    utils.add_sort_method()
    utils.endOfDirectory(
        cacheToDisc=True,
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    clean_database(showdialog=False)
    Log("Container.Refresh")
    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________________
#
def Camgirl_Generic_Image(model_id, url=None, current_icon=None):
    Log("refreshing icon for {}".format(repr(model_id)), C.LOGNONE)
    generated = False

    #site has generic banner whose size is smaller than this
    generic_icon_size = _MIN_VALID_IMAGE_SIZE
    icon_image_url = current_icon

    response = utils.getHtml(
        current_icon
        , send_back_response=True
        )
    LogR(response) #we don't want the generic banner
    if response and (len(response.data) > generic_icon_size): 
        icon_image_url = current_icon
        generated = True
        Log("current_icon was found; image {} ".format(repr(icon_image_url)), C.LOGNONE)
    else:
        #try using the current streaming pic
        icon_image_url = "https://live-screencaps.vscdns.com/{}-desktop.jpg{}".format(
            model_id
            ,"?_{}".format(utils.RandomNumber()) #random value added to make sure we always have a fresh image
            ) 
        response = utils.getHtml(
            icon_image_url
             , send_back_response=True
             )
        if not generated and (len(response.data) > generic_icon_size):
            generated = True
            Log("a current online image was found  {} ".format(repr(icon_image_url)), C.LOGNONE)

    LogR(icon_image_url
        , C.LOGNONE
        )
    return icon_image_url


#__________________________________________________________________________
#
@C.url_dispatcher.register(CLEANDATABASE_MODE)
def clean_database(showdialog=False, specific_texture=None,progress_dialog = None):

    if specific_texture in [None,'']: return #don't clean up entire image database until we figure out how to get images for off-line models
    DEFAULT_IMAGE_DOMAIN = "%.vscdns.com%"
    FAV_ICON_FLAG = '%fav_image=true%'
    texture_connection = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    texture_cursor = texture_connection.cursor()
    try:
        image_domain = DEFAULT_IMAGE_DOMAIN
        if not(specific_texture in [None,'']):
            image_domain = image_domain + specific_texture #+ '%'
        query = "SELECT id, cachedurl, url FROM texture "\
                "WHERE (url LIKE ?) " \
                "AND (cachedurl NOT IN (SELECT cachedurl FROM texture WHERE url LIKE ?) )"
        params = (image_domain, FAV_ICON_FLAG)
        for texture_id, texture_image_cache, texture_url in texture_cursor.execute(query,params):
            if progress_dialog:
                if progress_dialog.iscanceled(): break
                progress_dialog.increment_percent()
            query = "DELETE FROM sizes WHERE idtexture = ?"
            params = (texture_id,)
            texture_cursor.execute(query,params)
            query = "DELETE FROM texture WHERE id = ?"
            texture_cursor.execute(query,params)
            try:
                filespec = "special://thumbnails/" + texture_image_cache
                filespec = xbmc.translatePath(filespec)
                os.remove(filespec)
            except:
                traceback.print_exc()
                pass
            
        if showdialog:
            utils.notify(FRIENDLY_NAME +' images cleared')
    except:
        traceback.print_exc()
        pass
    finally:
        texture_connection.commit()
        texture_connection.close()
#__________________________________________________________________________
#
##@C.url_dispatcher.register(PLAY_MODE, ['url', 'name', 'img'], ['playmode_string', 'download', 'play_profile', 'hq_stream'])
##def Playvid(url, name, icon_URI, download=None, playmode_string=None, play_profile=None, hq_stream=None, testmode=False):
##    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
##    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
##    else: max_video_resolution = None
##    description = name + '\n' + ROOT_URL
##    video_url = None
@C.url_dispatcher.register(
    PLAY_MODE
    , ['url', 'name', 'img']
    , ['playmode_string', 'download', 'play_profile', 'testmode', 'hq_stream']
    )
def Playvid(url, name, icon_URI, download=None, playmode_string=None, play_profile=None, testmode=False, hq_stream=None):
    LogR(locals())
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    name = utils.Clean_Filename(name)
    description = name + '\n' + ROOT_URL
    video_url = None #final playable url
    
    #used to carry this info special to this provider; some links
    #   need this for some reason; maybe a dead server on day of programming?
    data_video_host = hq_stream

    #
    # do stuff to get a playable url
    #
    json_html = utils.getHtml(url=url
                              , referer=ROOT_URL
                              , headers = C.DEFAULT_HEADERS
                              , cache_duration=C.default_ISONLINE_cache_duration
                              )
    json_info = json.loads(json_html)
    if json_info['status'] == 'failed':
        utils.notify(
            header=FRIENDLY_NAME
            ,msg="{} is offline".format(name)
            ,duration=10000
            )
        if download: #create a 'fake' dowload url so that scheduled d/l can happen
            video_url = "fake"
        else:
            return

    if not video_url:
        Log("calculate this good info if model is online")
        if json_info['config']['room']['status'] != 'O':
            utils.Notify("{} is private".format(json_info['config']['performer']['name_seo']))
            if download: #create a 'fake' dowload url so that scheduled d/l can happen
                video_url = "fake"
            else:
                return
        params = json_info['params']
        if C.PY3: params = str(base64.b64decode(params), 'utf8')
        if C.PY2: params = base64.b64decode(params)
        name_seo = json_info['config']['performer']['name_seo']
        model_id = params.split('model_id=')[1].split('&')[0]
        if data_video_host:
            video_host = data_video_host
        else:
            video_host = params.split('video_host=')[1].split('&')[0]
        intermediate_url = (
                "{}/ws/chat/get-stream-urls.php?model_id={}&video_host={}&t={}".format(
                ROOT_URL
                , model_id
                , video_host
                , str(int(time.time()*1000)))
               )
        json_html = utils.getHtml(url=intermediate_url, referer=ROOT_URL)
        json_info = json.loads(json_html)
        use_random_naked_provider = False
        if use_random_naked_provider:
            provider = json_info["data"]["hls"][random.randint(0, 1)]
        else:
            if json_info["data"]["hls"][0]['name'] == u'level3':
                provider = json_info["data"]["hls"][1]  #level3 usually fails for me
            else:
                provider = json_info["data"]["hls"][0]
        video_url = ( "https:" 
                      + provider['url'] 
                      )
        naked_headers = {
                        'User-Agent': C.USER_AGENT
                        ,'Accept': "*/*"
                        ,'Referer': "{}".format(ROOT_URL)
                        ,'Accept-Language': 'en-US,en;q=0.9'
                        }
        video_url = "{}{}".format(video_url, utils.Header2pipestring(naked_headers) )
        Log(video_url)

    #calculate potential download name here because I want to include recording date
    download_filespec = downloader.Make_download_path(
        name = name
        , include_date = True
        , file_extension = '.ts'
        )

    Log("video_url='{}'".format(video_url) , C.LOGNONE)
    if testmode:
        Log("Would have played video_url; but in test mode")
        return video_url  #during testmode, only ensure that a url can be generated   

    return utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI
        , repeat_when_available = True
        )
#__________________________________________________________________________
#
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=1
    , page_end=1
    , progress_dialog=None
    , bulk_operation=False
    ):

    return True
#__________________________________________________________________________
#
##@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
##def Test(keyword=None, end_directory=True, page_start=1, page_end=1):
##    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))

@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=False, page_start=1, page_end=1
                  , progress_dialog=None, bulk_operation=False):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))
    return True

    if not keyword:
        prev_keyword = utils.get_setting('quick_search_string')
        if prev_keyword: keyword = prev_keyword
    if not keyword:
        keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
        if  keyword == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=keyword)

    List(ROOT_URL, page_start=FIRST_PAGE, page_end=None, end_directory=False, keyword='', testmode=True)

    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    
    utils.endOfDirectory(
        end_directory=end_directory,
        cacheToDisc=False,
        )
#__________________________________________________________________________
#
