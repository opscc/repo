'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import random
import re
import sqlite3
import sys
import threading
import traceback
import datetime
import json
import time
import _strptime #because https://www.raspberrypi.org/forums/viewtopic.php?t=166912

import xbmc
import xbmcplugin
import xbmcgui
import xbmcvfs

import socket
import websocket

import utils
from utils import Log,LogR
from utils import Sleep
from utils import urllib2
import constants as C
from constants import unquote
from constants import reload
##reload(utils)
import downloader




FRIENDLY_NAME = '[COLOR {}]MyFreeCams[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.myfreecams.com"
SEARCH_URL = 'stub - make all sites consistent'

MFC_GIRLS_CACHE_STRING = "mfc_girls"
MFC_GIRLS_CACHE_DURATION = 2
MFC_RESPKEY_CACHE_STRING = "mfc_respkey"
MFC_RESPKEY_CACHE_DURATION = 0.1 #1.5 #maybe a future service will keep socket alive

MESSAGE_FIELD_LENGTH = None
MAX_READ_COUNT = 100
CAMGIRLSERVER = None
CAMGIRLCHANID = None
CAMGIRLUID = None
CAMGIRL = None
CXID = None
CTXENC = None
TKX = None
SESSION_ID = None
PLATFORM_ID = None

SERV = None
RESPKEY = None
STYPE = None
OPTS = None

XCHAT_HOST = None

WHEN_SERV_ACQUIRED = None

serverList = None                

FCUOPT_PLATFORM_MFC = 1
FCUOPT_PLATFORM_CAMYOU = 2

vs_str={}
vs_str[0]="PUBLIC"
vs_str[2]="AWAY"
vs_str[12]="PVT"
vs_str[13]="GROUP"
vs_str[14]="GROUP"
vs_str[90]="CAM OFF"
vs_str[127]="OFFLINE"
vs_str[128]="TRUEPVT"

MAIN_MODE          = C.MAIN_MODE_myfreecams
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
REFRESH_MODE       = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FCTYPE_EXTDATA = 81
FCTYPE_LOGIN = 1
FCTYPE_MODELGROUP = 33
FCTYPE_TKX = 30
FCTYPE_EXTDATA = 81
FCTYPE_DETAILS = 5
FCTYPE_ADDIGNORE = 7
FCTYPE_SESSIONSTATE = 20

MAX_BUFFER_READ_ATTEMPTS = 10

MAX_LIST_ITEMS = 1040 #used during debugging; list this many top models [may be less if not public]

FCWEXTRESP_URL = ROOT_URL + "/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}"

#during dev, enable debug only this module by uncommenting/setting in each url_dispatcher.register function
LOCAL_DEBUG = C.DEBUG
##LOCAL_DEBUG = True

_MIN_VALID_IMAGE_SIZE = 10000
_BAD_IMAGE_SIZES = [101985,18250,16028]


#__________________________________________________________________________
#
def Camgirl_JSON_url():
    url = ''
    url = utils.global_cache.get(MFC_RESPKEY_CACHE_STRING+"_FWEXT")
    if url:
##        Log(url)
        return url

    try:
        mfc_respkey = getRespkey()
        url = FCWEXTRESP_URL.format(
            mfc_respkey['respkey']
            , mfc_respkey['stype']
            , mfc_respkey['opts']
            , mfc_respkey['serv']
            , random.random()
            , millitime()
            )
    except:
        raise
##        pass
    utils.global_cache.set(
        endpoint = MFC_RESPKEY_CACHE_STRING+"_FWEXT"
        ,data = url
        ,expiration = datetime.timedelta(minutes=MFC_RESPKEY_CACHE_DURATION)
        )
##    Log(url)
    return url
#__________________________________________________________________________
#
def Camgirl_PLAY_url(norm_serv_number, obs_server_modifier, channel_id):
    video_url = None
##    if PLATFORM_ID == FCUOPT_PLATFORM_MFC:
##        Log('FCUOPT_PLATFORM_MFC')
    #video_url = "http://video{}.myfreecams.com:1935/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8{}" #pre 2021-06
    video_url = "https://video{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8{}" #pre 2024-09-22
    video_url = video_url.format( 
                    norm_serv_number
                    , obs_server_modifier
                    , channel_id
                    ,'?nc={}&v=1.96.4'.format( random.random() )
                )
    video_url = "https://edgevideo.myfreecams.com/hls/NxServer/{}/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8{}" #pre
    video_url = video_url.format( 
                    norm_serv_number
                    , obs_server_modifier
                    , channel_id
                    ,'?nc={}&v=1.97.23'.format( random.random() )
                )
    return video_url
#__________________________________________________________________________
#
def Camgirl_Server_Image(norm_serv_number, obs_server_modifier, channel_id):
    #use a snapshot of 'current action' as the icon
    icon_image = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc{}_{}{}".format(
        norm_serv_number
        , obs_server_modifier
        , channel_id
        , "?no-cache="+str(int(time.time()*2))
        )
    return icon_image
#__________________________________________________________________________
#
def Camgirl_Generic_Image(model_id):
    model_id = str(int(model_id)) #model_id should be am int;  raise exception if not
    icon_image = "https://img.mfcimg.com/photos2/{}/{}/avatar.300x300.jpg".format(model_id[:3], model_id)
##    traceback.print_stack()
##    exit(0)
##    LogR(icon_image,C.LOGERROR)
    return icon_image
#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    List()
#__________________________________________________________________________
#
def arrayPositionForKeyname(array, key):
    i=0
    for val in array:
        if isinstance(val, str) or isinstance(val, C.text_type):
            if val == key:
                return i 
            i += 1
        elif isinstance(val, dict):
            for val2 in val.values():
                if isinstance(val2, (list, dict, tuple)):
                    for val3 in val2:
                        if val3 == key:
                            return i 
                        i += 1
                elif isinstance(val2, str) or isinstance(val2, C.text_type):
                    if val2 == key:
                        return i
                    i += 1
    return None
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'])
def List(url=None, end_directory=True, keyword='', progress_dialog=None, bulk_operation=False):

    if not progress_dialog:
        progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
        
    try:
        items_list = list()    
        for model in getCamgirlList(progress_dialog=progress_dialog):
            items_list.append(
                utils.addDownLink( 
                     name = model['icon_label'] 
                    , url = model['video_url'] 
                    , mode = model['mode'] 
                    , iconimage = model['icon_image']
                    , duration = model['camscore']
                    , play_method = model['play_method']
                    , hq_stream = model['hq_stream']
                    , desc = model['description']
                    , return_listitem = True #allows for bulk appending of list items
                    )
                )
    finally:
        utils.Add_Refresh_Item(
            mode=REFRESH_MODE
            ,progress_dialog=progress_dialog
            ,end_directory=end_directory)
        xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)
       
    set_default_view = {
        "path": sys.argv[0] + sys.argv[2]
        # Note: xbmcplugin.SORT_METHOD_DURATION  and "SortUtils.h".SortByTime values are different
        ,"sortmethod" : C.INITIAL_SORTMETHOD #sort by time/duration
        ,"sortdirection" : True #toggle to descending [because when blank,  default is ascending]
        ,"viewmode"      : C.INITIAL_VIEWMODE
##        ,"sleeptime"     : max(100, int(FAV_LIST_LIMIT*3)) #need more time to set view will large number of items
        }
    LogR(set_default_view)
    utils.endOfDirectory(
        cacheToDisc=True,
        set_default_view=set_default_view,
        updateListing=False,
        )
    
#__________________________________________________________________________
#
def NormalizeChannelID(uid, platform_id=FCUOPT_PLATFORM_MFC):
    if not isinstance(uid, int):  return 0
    uid = int(uid)
    if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
        return uid + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
    else:
        return uid + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name', 'img'], ['playmode_string', 'download', 'play_profile', 'hq_stream', 'testmode'])
def Playvid(url, name, icon_URI, download=None, playmode_string=None, play_profile=None, hq_stream=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{},'hq_stream='{}' )".format(url,name,download,playmode_string,play_profile,hq_stream))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    C.DEBUG = LOCAL_DEBUG

    websocket_connection = None
    try:
        video_url, websocket_connection = myfreecam_start(camgirl_to_find=url)
    except:
        traceback.print_exc()
    
    if not video_url: # or not websocket_connection:
        if download: #create a 'fake' dowload url so that scheduled d/l can happen
            video_url = url
        else:
            Log("Could not find a playable webcam link for '{}'".format(name))
            return

    headers = {
            'User-Agent': C.USER_AGENT
            , 'Accept': '*/*'
            , 'Referer': "https://m.myfreecams.com/"
            , 'Accept-Encoding': 'gzip'
            , 'Accept-Language': 'en-US,en;q=0.9'
            }
    video_url = "{}{}".format(video_url, utils.Header2pipestring(headers) )
##    Log("video_url='{}'".format(video_url)  )

    #calculate potential download name here because I want to include recording date
    download_filespec = downloader.Make_download_path(
        name = name
        , include_date = True
        , file_extension = '.ts'
        )

##    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return  video_url  #during testmode, only ensure that a url can be generated

    return utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI
        , repeat_when_available = True
        )
#__________________________________________________________________________
#
def fc_decode_json(m):
##    Log(repr(m))
    try:
        m = m.replace('\r', '\\r').replace('\n', '\\n')
##        Log(m)
        m = m[m.find("{"):]
##        Log(repr(m))
##        Log(m)
        return json.loads(m) #.decode("utf-8","ignore"))
    except:
##        raise
        return json.loads("{\"lv\":0}") #sometimes there is no json in these messages
#__________________________________________________________________________
#
def millitime():
    return int(time.time()) * 1000
#__________________________________________________________________________
#
def getServerList():

    global serverList #store the list in memory for other frequent callers

    last_serverlist_refresh = C.addon.getSetting('last_serverlist_refresh')
    if last_serverlist_refresh == '':
        last_serverlist_refresh = datetime.date(1980, 1, 1).strftime("%Y-%m-%d")
    last_serverlist_refresh = datetime.datetime(*(time.strptime(last_serverlist_refresh, "%Y-%m-%d")[0:6]))

    today = datetime.datetime.now().strftime("%Y-%m-%d")
    today = datetime.datetime(*(time.strptime(today, "%Y-%m-%d")[0:6]))
    if not isinstance(last_serverlist_refresh, datetime.date):
        last_serverlist_refresh = datetime.date(1980, 1, 1)

    if last_serverlist_refresh >= today:  # then we can read list from settings
        mfc_serverlist = C.addon.getSetting('mfc_serverlist')
        if not mfc_serverlist: mfc_serverlist = "{}"
        Log("using server list from settings")
        serverList = json.loads(mfc_serverlist)
        return #don't need to return a value; will always use value from global

    #nothing in global
    #build and cache a list of MFC video servers

    #connect to one of the chat servers; random since we don't know how to parse page
    #we need to use 8080 because the other choice, https, does not work with websocket
    url="https://m.myfreecams.com/configproxy.php".format(random.random())
##    #post summer 2019
##    url=ROOT_URL + "/_js/serverconfig.js?_={}".format(random.random())
    #post summer 2019
    url="https://assets.mfcimg.com/_js/serverconfig.js?_={}".format(random.random())


    try:
        listhtml = utils.getHtml(url)
    except:
        traceback.print_exc()
        return None

    serverList = json.loads(listhtml)

    #convert the separated server numbers into a single list for storage
    for num in serverList['h5video_servers']:
        serverList[num] = serverList['h5video_servers'][num]
    for num in serverList['ngvideo_servers']:
        serverList[num] = serverList['ngvideo_servers'][num]
    for num in serverList['wzobs_servers']:
        serverList[num] = serverList['wzobs_servers'][num]
        
    C.addon.setSetting(id='last_serverlist_refresh', value=today.strftime("%Y-%m-%d"))    
    C.addon.setSetting(id='mfc_serverlist',          value=json.dumps(serverList) )

    return #don't need to return a value; will always use value from global
#__________________________________________________________________________
#
def chatserverList():
    global serverList
    serverList = None
    if not serverList: getServerList()
    new_list = list()
    for z in serverList['chat_servers']:
        if 'wchat' in z:
            new_list.append(z)
    return new_list

#__________________________________________________________________________
#
def h5videoserverList():
    global serverList
    if not serverList: getServerList()
    return serverList['h5video_servers']
#__________________________________________________________________________
#
def ngvideoserverList():
    global serverList
    if not serverList: getServerList()
    return serverList['ngvideo_servers']
#__________________________________________________________________________
#
def wzvideoserverList():
    global serverList
    if not serverList: getServerList()
    return serverList['wzobs_servers']
#__________________________________________________________________________
#
def NormalizeServerNumber(server):
##    Log("\n NormalizeServerNumber [{}] \n".format(server))
    global serverList
    result_server = server #sometimes the server number can't be normalized
    if not serverList: getServerList()
    if str(server) in serverList: result_server = serverList[str(server)]
##    try:
##        result_server = serverList[str(server)]
##    except:
##        pass
    return result_server
#__________________________________________________________________________
#
def getChatServerWebsocket(login_version='20071025'):

    global SESSION_ID
    global CXID
    global CTXENC
    global TKX
    global SERV
    global RESPKEY
    global STYPE
    global OPTS
    global MESSAGE_FIELD_LENGTH
    global XCHAT_HOST

    global WHEN_SERV_ACQUIRED
    
    Log("getChatServerWebsocket [{}] \n".format(login_version))

    if not utils.Is_Online(): return None
    
    sock_buf=None
    ws = None
    failed_count = 0
    FAILED_COUNT_MAX = 2



    xchat = chatserverList()

    while not ws and (failed_count < FAILED_COUNT_MAX):
        try: 
            ws = None
            mfc_xchat_host = ''
            while not ws and (failed_count < FAILED_COUNT_MAX):
                if utils.monitor.abortRequested():
                    Log("getChatServerWebsocket utils.monitor.abortRequested() \n")
                    return None

                try:
                    failed_count += 1
##                    mfc_xchat_host = C.addon.getSetting(id='mfc_xchat_host')
##                    Log("cached mfc_xchat_host='{}'".format(mfc_xchat_host) )
                    MESSAGE_FIELD_LENGTH = 6 #post 2018 messages
                    while mfc_xchat_host == '' and (failed_count < FAILED_COUNT_MAX):
                        mfc_xchat_host = random.choice(xchat)
                        Log("random mfc_xchat_host='{}'".format(mfc_xchat_host) )
                        if mfc_xchat_host[0:1] in ['x', 'w']: #there are some ychat servers
                            #mfc_xchat_host = "ws://{}.myfreecams.com:8080/fcsl".format( mfc_xchat_host )
                            mfc_xchat_host = "wss://{}.myfreecams.com/fcsl".format( mfc_xchat_host )
                            #mfc_xchat_host = "https://{}.myfreecams.com/fcsl".format( mfc_xchat_host )
                            if mfc_xchat_host[2] == ':'  or mfc_xchat_host[3] == ':' or mfc_xchat_host[6] == ':' :
                                MESSAGE_FIELD_LENGTH = 6 #post 2018 messages
                            else:
                                MESSAGE_FIELD_LENGTH = 4 #pre 2018 messages
                            XCHAT_HOST = mfc_xchat_host
                        else:
                            failed_count += 1
                            mfc_xchat_host = ''
                    if not(mfc_xchat_host == ''):
                        Log("connecting to '{}'".format(mfc_xchat_host))
                        ws = websocket.create_connection(mfc_xchat_host)
##                        C.addon.setSetting(id='mfc_xchat_host', value=mfc_xchat_host)

                except:
                    traceback.print_exc()
                    C.addon.setSetting(id='mfc_xchat_host', value='')                    
                    time.sleep(0.1)
                    ws = None
            
            #time.sleep(0.1)

#            ws.send("hello fcserver\n\0")
            if not ws: #failed? then wait a bit a try again
                time.sleep(0.2)
                break
            
            ws.send("fcsws_20180422\n\0")
#            ws.send(socket_message + "\n\0")

##            if login_version=='20080910':
##                ws.send('0 0 0 0 0 -' + "\n\0")

            socket_message = "{} 0 0 {} 0 1/guest:guest".format(FCTYPE_LOGIN, login_version)
            ws.send(socket_message + "\n\0" )
            
            sock_buf=None
            sock_buf = ws.recv()
            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            #temp_login_id = hdr.group(6)
            SESSION_ID = hdr.group(3)

            sock_buf=None
            quitting = False
            fc = None
            readcount = 0
            while quitting == False:
                sock_buf = ws.recv()
                readcount = readcount + 1
                if (readcount > MAX_BUFFER_READ_ATTEMPTS): quitting = True #infinite loop detection

                while (len(sock_buf) > 0) and (quitting == False):
                    hdr = re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
                    fc = hdr.group(1)
##                    Log("fc={}".format(fc) )
                    #first bytes of fc tells us size of message
                    #rest of bytes in fc is the fc message type
                    try:
                        msg_type = int(fc[MESSAGE_FIELD_LENGTH:])
                    except:
                        msg_type = int(fc)
##                    Log("msg_type={}".format(msg_type) )

                    mlen = int(fc[0:MESSAGE_FIELD_LENGTH])# characters from position 0 (included) to 6 (excluded)
##                    Log( "MESSAGE_FIELD_LENGTH='{}'".format(repr(MESSAGE_FIELD_LENGTH)) )
##                    Log( "mlen='{}'".format(repr(mlen)) )
                    msg = sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH+mlen]
##                    Log( "msg='{}'".format(repr(msg)) )
                    msg = unquote(msg)
##                    Log( "msg='{}'".format(repr(msg)) )
                    msg = fc_decode_json(msg)
##                    Log( "msg='{}'".format(repr(msg)) )
                    
                    try:
                        if msg_type == FCTYPE_TKX:
                            CXID = msg['cxid']
                            CTXENC = unquote(msg['ctxenc'])
                            TKX = msg['tkx']
##                            Log( "CxID={}".format(CXID) )
                            break # these lines don't have any more useful information

                        if msg_type == FCTYPE_EXTDATA:
                            if not SERV: #these variables are sent twice differently - we only need the first
                                SERV = msg['serv'] #the xchatserver we are talking to
##                                Log( "SERV={}".format(SERV) )
                                RESPKEY = msg['respkey'] 
                                STYPE = msg['type']
                                OPTS = msg['opts']
                                WHEN_SERV_ACQUIRED = datetime.datetime.now()
                                break # these lines don't have any more useful information

                        if msg_type == FCTYPE_DETAILS:
                            SESSION_ID = msg['sid']
                            break # these lines don't have any more useful information

                        if msg_type == FCTYPE_SESSIONSTATE:
                            quitting = True 
                            break #all necessary info should be here by now

                    except:
                        traceback.print_exc()
                        pass

                    sock_buf=sock_buf[MESSAGE_FIELD_LENGTH+mlen:]

        except:
            traceback.print_exc()
            failed_count += 1
            ws = None
            WHEN_SERV_ACQUIRED = None

    if ws:
        websocket_keepalive_thread = threading.Thread(
            target=keepRespkeyAlive
            ,args=(ws,)
            ,name=C.addon_id+".websocket_keepalive"
            )
        websocket_keepalive_thread.daemon = True
        websocket_keepalive_thread.start()
                    
    return ws #returning open websocket
#__________________________________________________________________________
#
def keepRespkeyAlive(websocket_connection):
    return
    try:
        MAX_BUFFER_READ_ATTEMPTS = 400
        monitor = xbmc.Monitor()
        sleeptime = 3
        old_mfc_respkey = None
        while monitor.abortRequested() == False :

            Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
            if monitor.waitForAbort(int(sleeptime)):
                Log("{} ending due to abort".format(threading.current_thread().name))
                break

            sleeptime = max(4, sleeptime)
                            
            readcount = 0

            socket_message = "0 0 0 0 0"
            websocket_connection.send(socket_message + "\n\0" )

            while True and (not monitor.waitForAbort(0.01)):

                readcount = readcount + 1
                
                sock_buf=None
                sock_buf = websocket_connection.recv()

##                Log( "sock_buf='{}'".format(repr(sock_buf) ))

                hdr = re.search (r"(\d{8}) (\d+) (\d+) (\d+) (\d+)", sock_buf)
                if hdr is None:
                    Log( "sock_buf='{}'".format(repr(sock_buf) ))
                    continue
                if len(sock_buf) > 25000:
                    Log( 'sockbuf too big')
                    sock_buf = websocket_connection.recv()
                    sock_buf = websocket_connection.recv()
                    sock_buf = websocket_connection.recv()
                    sock_buf = websocket_connection.recv()
                    sock_buf = websocket_connection.recv()
                    sleeptime = 5
                    break
                
                fc = hdr.group(1)
                Log("fc={}".format(fc) )
                msg_type = int(fc[MESSAGE_FIELD_LENGTH:])
##                Log("msg_type={}".format(msg_type) )
                mlen = fc[0:MESSAGE_FIELD_LENGTH]
##                Log("mlen={}".format(mlen) )
                mlen = int(mlen)# characters from position 0 (included) to MESSAGE_FIELD_LENGTH (excluded)

                if (readcount > MAX_BUFFER_READ_ATTEMPTS):
                    Log('readcount max')
                    break #infinite loop detection

                while (len(sock_buf) > 0)  and (not monitor.waitForAbort(0.01)):
                    
                    msg = sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH+mlen] 
                    msg = unquote(msg)
                    Log( "msg='{}'".format(msg) )
                    msg = fc_decode_json(msg)
##                    Log( "msg='{}'".format(repr(msg) ))
                    sock_buf = sock_buf[MESSAGE_FIELD_LENGTH+mlen:]

                else:
                    pass
##                    Log('end sockbuf')
            
            else:
                Log('end while true')

            if readcount < 2: #nothing was received after ping; sleep a bit less next time
                sleeptime -= 1


            #heartbeat connection successful; refresh respkey cache
            mfc_respkey = getRespkey()
            if old_mfc_respkey is not None  and mfc_respkey['CTXENC'] != old_mfc_respkey :
                raise Exception('old key must have been reset in different thread')
            setRespkey(mfc_respkey)
            old_mfc_respkey = mfc_respkey['CTXENC']
            
    except:
        traceback.print_exc()
##        setRespkey(None)
    finally:
        if websocket_connection: websocket_connection.close()

#__________________________________________________________________________
#
def getRespkey():
    mfc_respkey = utils.global_cache.get(MFC_RESPKEY_CACHE_STRING)
    if mfc_respkey:
        pass
    else:
        Log("mfc_respkey is None or Expired")
        resetRespkey()
        ws = getChatServerWebsocket()
##        if ws: ws.close() #close if not using background keep alive thread
        if RESPKEY is None: raise Exception("Null response key. Can't continue")
        mfc_respkey = {}
        mfc_respkey['serv'] = SERV
        mfc_respkey['respkey'] = RESPKEY
        mfc_respkey['stype'] = STYPE
        mfc_respkey['opts'] = OPTS
        mfc_respkey['CXID'] = CXID
        mfc_respkey['CTXENC'] = CTXENC
        mfc_respkey['TKX'] = TKX
        setRespkey(mfc_respkey)

##    Log("mfc_respkey={}".format(repr(mfc_respkey)))
    return mfc_respkey
#__________________________________________________________________________
#
def setRespkey(mfc_respkey):
    Log("set mfc_respkey={}".format(repr(mfc_respkey)))
    utils.global_cache.set(
        endpoint = MFC_RESPKEY_CACHE_STRING
        ,data = mfc_respkey
        ,expiration = datetime.timedelta(minutes=MFC_RESPKEY_CACHE_DURATION)
        )
#__________________________________________________________________________
#    
def resetRespkey():
    global CXID
    global CTXENC
    global TKX
    global SERV
    global RESPKEY
    global STYPE
    global OPTS
    CXID = None
    CTXENC = None
    TKX = None
    SERV = None
    RESPKEY = None
    STYPE = None
    OPTS = None
    setRespkey(None)
#__________________________________________________________________________
#
def getCamgirlList(notify=False, progress_dialog=None):

    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    C.DEBUG = LOCAL_DEBUG
    
    mfc_girls = json.loads("[]")
            
    if progress_dialog and progress_dialog.iscanceled(): return mfc_girls
    MAX_MFC_ATTEMPTS = 2
    try:
        url = Camgirl_JSON_url()
        for attempt_number in range(1,MAX_MFC_ATTEMPTS):
            json_html = utils.getHtml(
                url
                , cache_duration=C.default_ISONLINE_cache_duration
                )
            if len(json_html) < 1:
                resetRespkey()
                url = Camgirl_JSON_url()
                continue
    except:
        traceback.print_exc()        
        return mfc_girls

    json_playlist = json.loads(json_html)['rdata']
    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ...
##    LogR(json_playlist[0])
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
##    Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    # ... schema line which I don't want [errors during sorting]
    del json_playlist[0] 

    #sort so that top camscore is on top
    entries = sorted(json_playlist, reverse=True, key=lambda camscore: camscore[camscore_index])

    #add list items...
    for playItem in entries[:MAX_LIST_ITEMS]:
        
        if not(playItem[vs_index] == 0): continue #only show model in public chat

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
               
        serv_number = playItem[camserv_index]
        if Is_new_server(serv_number):
            server439hack = "_a"
            name_hq_prefix = ""
            hq_stream = True
        else:
            server439hack = ""
            name_hq_prefix = ""
            hq_stream = False

        #normalizeServer will return a string such as video1234;
        #I only want to return the 1234 portion
        norm_serv_number = int("".join( filter(str.isdigit,   str(NormalizeServerNumber(serv_number)) )) )

        #use a snapshot of 'current action' as the icon
        icon_image = Camgirl_Server_Image(
            norm_serv_number = norm_serv_number
            , obs_server_modifier = server439hack
            , channel_id = NormalizeChannelID(playItem[uid_index])
            )

        camscore = int(playItem[camscore_index])
        current_model_name = playItem[name_index]
        model_name = playItem[name_index]
        icon_label = name_hq_prefix + current_model_name

        json_item = {}

        model_id_via_image = icon_image.split('/')[6]
        if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
            model_id_via_image = icon_image.split('/')[5]
        #the 1 indicates model was in public chat when bookmark created
        if model_id_via_image.startswith("mfc_a_1"):
           model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
        if model_id_via_image.startswith("mfc_1"):
           model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
        if model_id_via_image[0] == '0':
            model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
        img = Camgirl_Generic_Image(model_id_via_image)
        while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
            model_id_via_image = '0' + model_id_via_image
##        LogR((model_name, model_id_via_image))
##        raise Exception()
        json_item['modelID'] = model_id_via_image
        json_item['username'] = model_name
        json_item['video_url'] = current_model_name
        json_item['mode'] = PLAY_MODE
        json_item['icon_image'] = icon_image
        json_item['camscore'] = camscore
        json_item['description'] = ROOT_URL
        json_item['icon_label'] = icon_label
        json_item['play_method'] = None
        json_item['hq_stream'] = hq_stream
        json_item['serv_number'] = playItem[camserv_index]
        json_item['norm_serv_number'] = norm_serv_number
        json_item['obs_server_modifier'] = server439hack
        json_item['channel_id'] = NormalizeChannelID(playItem[uid_index])

        
        mfc_girls.append(json_item)            

    return mfc_girls
#__________________________________________________________________________
#
def Is_new_server(camserv):
    #corresponds to "onWzObsVideoServer" json information that we may need to start parsing
    #GET https://www.myfreecams.com/_js/serverconfig.js?_=1583266403437
    if str(camserv) in ngvideoserverList():
        return True
    if str(camserv) in wzvideoserverList():  #wzvideoserverList  seems to be webRTC ??? , which is some time of encrypted RTMP
        return True
    return False #not a OBS server
#__________________________________________________________________________
#
def myfreecam_start(camgirl_to_find):
    Log("myfreecam_start [{}] \n".format(camgirl_to_find))

    mfc_girls = getCamgirlList()

    camgirl = None
    for m in getCamgirlList():
        if m['username'].lower() == camgirl_to_find.lower():
            Log(repr(m))
            camgirl = m
            break
       
    if camgirl is None:
        utils.notify(
            header=FRIENDLY_NAME
            ,msg="{} is offline".format(camgirl_to_find)
            ,duration=10000
            )
##        utils.notify(msg= "{} not online".format(camgirl_to_find), duration=10000, sound=False)
        return '', None

    video_url = Camgirl_PLAY_url(
            norm_serv_number = camgirl['norm_serv_number']
            , obs_server_modifier = camgirl['obs_server_modifier']
            , channel_id = camgirl['channel_id']
            )
    Log("video_url={}".format(repr(video_url)))
    return video_url, None

#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def clean_database(showdialog=True,progress_dialog = None):
    Log('clean_database')

    utils.global_cache.set(
        endpoint = MFC_GIRLS_CACHE_STRING
        ,data = None
        ,expiration = datetime.timedelta(minutes=0)
        )

    if not progress_dialog:
        progress_dialog = utils.Progress_Dialog(C.addon_name, "...clearing images for {}".format(FRIENDLY_NAME))

    
    conn = sqlite3.connect(xbmcvfs.translatePath("special://database/Textures13.db"))
    try:
        raise Exception('')
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            for row in list:

                if progress_dialog:
                    if progress_dialog.iscanceled(): break
                    progress_dialog.increment_percent()

                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try:
                    os.remove(xbmcvfs.translatePath("special://thumbnails/" + row[1]))
                except:
                    pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            if showdialog==True:
                utils.notify('Finished','Images cleared')
    except:
        pass
    if showdialog == True:
        Log("Container.Refresh")
        xbmc.executebuiltin('Container.Refresh')
##    Log('end clean_database')
#__________________________________________________________________________
#
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=0
    , page_end=None
    , progress_dialog=None
    , bulk_operation=False
    ):
    return True
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True, page_start=1, page_end=1
                  , progress_dialog=None, bulk_operation=False):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))

    return True
#__________________________________________________________________________
#
