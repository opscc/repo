'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import datetime
import json
import re
import sys
import traceback
import xbmc
import xbmcvfs
import xbmcplugin

import utils
from utils import Log,LogR
import constants as C
from constants import quote_plus
import downloader

import os
import sqlite3


FRIENDLY_NAME = '[COLOR {}]Chaturbate[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://chaturbate.com"
SEARCH_URL = ROOT_URL + '/?s={}'
#URL_RECENT = ROOT_URL + "/female-cams/?page={}"
URL_RECENT = ROOT_URL + "/api/ts/roomlist/room-list/?enable_recommendations=false&genders=f&limit={}&offset={}"
URL_COUPLES = ROOT_URL + "/api/ts/roomlist/room-list/?enable_recommendations=false&genders=c&limit={}&offset={}"



MAIN_MODE          = C.MAIN_MODE_chaturbate
LIST_MODE          = str(int(MAIN_MODE) + C.MODE_LIST_OFFSET)
PLAY_MODE          = str(int(MAIN_MODE) + C.MODE_PLAY_OFFSET)
CLEANDATABASE_MODE = str(int(MAIN_MODE) + C.MODE_CLEANDATABASE_OFFSET)
REFRESH_MODE       = str(int(MAIN_MODE) + C.MODE_REFRESH_OFFSET)
SEARCH_MODE        = str(int(MAIN_MODE) + C.MODE_SEARCH_OFFSET)
TEST_MODE          = str(int(MAIN_MODE) + C.MODE_TEST_OFFSET)

FIRST_PAGE = 1
KEYWORD = '1'
ITEMS_PER_PAGE = 90
ROOM_DATA_PREFIX = "cached_chaturbate_data_"
ROOM_DATA_CACHE_DURATION = 2

_MIN_VALID_IMAGE_SIZE=8000
_BAD_IMAGE_SIZES = []

CACHE_STRING = "chaturbate_girls"
MOST_RECENT_LIST = "chaturbate_MRL" #needed for REFRESH mode

#__________________________________________________________________________
#
def PLAY_HEADERS():
    _PLAY_HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'
        ,'Accept': '*/*'
        ,'Accept-Language': 'en-US,en;q=0.9'
        ,'Accept-Encoding': 'gzip, deflate, br'
        ,'Referer': 'https://chaturbate.com/'
        ,'Origin': 'https://chaturbate.com'
        ,'DNT': '1'
        ,'Sec-GPC': '1'
        ,'Connection': 'keep-alive'
        ,'Sec-Fetch-Dest': 'empty'
        ,'Sec-Fetch-Mode': 'cors'
        ,'Sec-Fetch-Site': 'cross-site'
        }
    return _PLAY_HEADERS
#__________________________________________________________________________
#
def LIST_HEADERS():
    return PLAY_HEADERS()
#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(
                C.highlight_text_color
                , "Self Test"
                )
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , keyword = 'myra moans'
            )
    utils.addDir(
        name="{}[COLOR {}]Couples[/COLOR]".format(
            C.SPACING_FOR_TOPMOST
            ,C.search_text_color
            ) 
        ,url=URL_COUPLES
        ,page_start=FIRST_PAGE
        ,mode=LIST_MODE
        ,iconimage=C.category_icon
        ,keyword=KEYWORD
        
        )
    List(URL_RECENT, page_start=FIRST_PAGE, page_end=FIRST_PAGE, end_directory=True, keyword=KEYWORD)
#__________________________________________________________________________
#
def GetCamgirlList(url=URL_RECENT, page_start=FIRST_PAGE, page_end=FIRST_PAGE
                   , depth=1, notify=False, progress_dialog=None):
    if notify: utils.Notify("Listing {}".format(ROOT_URL))


####    return json.loads("[]")  #testing
##    json_items = utils.global_cache.get(CACHE_STRING+url+str(page)+str(depth))
####    json_items = None #testing
##    if json_items and (len(json_items) > 0)  :
##        Log("using global_cache chaturbate_girls")
##        return json_items
    LogR(locals())
    
    depth = int(depth)
    page = page_start
    
    json_items = json.loads("[]")
    while depth > 0:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        if '{}' in url and page_start:
            list_url = url.format(ITEMS_PER_PAGE
                                  , max(0,int(page)-1)*ITEMS_PER_PAGE
                                  )
        else: list_url = url

        #recurse depth some more when we need to go deeper than depth=1
        page = int(page) + 1
        depth = depth - 1 #could also add 1 and change the while limit

        headers = C.DEFAULT_HEADERS.copy()
        headers = LIST_HEADERS()
        headers['X-Requested-With'] = 'XMLHttpRequest'
        headers['Accept'] = '*/*'

##        LogR(list_url)

        listhtml = utils.getHtml( list_url
                                 , ROOT_URL
                                 , headers = headers 
                                 , save_cookie=False
                                 , cache_duration=C.default_ISONLINE_cache_duration
                                 )
        if listhtml is None: return json_items #in case we don't have IP
        
        info = json.loads(listhtml)
        for i in info["rooms"]:
##            LogR(i)
            
            if progress_dialog:
                if progress_dialog.iscanceled(): break
                progress_dialog.increment_percent()

            if not (i["current_show"] == "public"):
                continue
            
            json_item = {}
            json_item['modelID'] = i["username"]
            json_item['username'] = i["username"]
            json_item['video_url'] = ROOT_URL + "/" + i["username"] + "/" #"https://chaturbate.com/_milkyway/
            json_item['mode'] = PLAY_MODE
            json_item['icon_image'] = i["img"]
            json_item['camscore'] = i["num_users"]
            json_item['description'] = '\n' + ROOT_URL
            json_item['icon_label'] = i["username"]
            json_item['play_method'] = ''

            json_items.append(json_item)

##            break
##    utils.global_cache.set(
##        endpoint = (CACHE_STRING+url+str(page)+str(depth))
##        ,data = json_items
##        ,expiration = datetime.timedelta(minutes=ROOM_DATA_CACHE_DURATION)
##        )
    
    return json_items
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword'])
def List(url, page_start=FIRST_PAGE, page_end=FIRST_PAGE, end_directory=True, keyword=FIRST_PAGE, progress_dialog=None):
    LogR(locals())

    depth = (page_end - page_start + 1)
    
    utils.global_cache.set(  #see REFRESH_MODE for why/how used
        endpoint = MOST_RECENT_LIST
        ,data = {"url":url, "page":page_start, "keyword": depth}
        )

    if not progress_dialog:
        progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)


    try:
        items_list = list()
        
        models = GetCamgirlList(url, page_start, depth=depth
                                , progress_dialog=progress_dialog)
        for model in models:
            items_list.append(
                utils.addDownLink( 
                    name = model['icon_label'] 
                    , url = model['video_url'] 
                    , mode = model['mode'] 
                    , iconimage = model['icon_image']
                    , duration = model['camscore']
                    , play_method = model['play_method']
                    , desc = model['description']
                    , return_listitem = True #allows for bulk appending of list items
                    )
                )
        del models

        # next page items
        page_start + depth
        page_end = page_end + depth
        np_number = page_start + 1
        
        np_url = url
        
        #add custom menu option to next page item that allows extra recursion/search
        recurse_levels = C.DEFAULT_RECURSE_DEPTH
##        page_end = page_start+recurse_levels #-1
            #"&keyword={}".format(recurse_levels) +
        keyw = (
            "{}".format(sys.argv[0]) +
            "?end_directory=True" +
            "&mode={}".format(LIST_MODE) +
            "&page_end={}".format(quote_plus(str(page_end+recurse_levels-1))) +
            "&page_start={}".format(quote_plus(str(page_start))) +
            "&url={}".format(quote_plus(url))
            )        
        contextMenuItems = []
        #2025-04 broken for now...
##        contextMenuItems.append(
##                (
##                    "{}[COLOR {}]Recurse ({}) more [/COLOR]".format(
##                        C.SPACING_FOR_NEXT
##                        , C.search_text_color
##                        , recurse_levels
##                        )
##                    , "ActivateWindow(Videos,{},return)".format(keyw)
##                )
##            )

        #prepare to bulk-add the video items
        items_list.append(
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page_start=np_number
                ,page_end=page_end
                #,keyword=keyword
                ,contextMenu=contextMenuItems
                ,contextMenuReplace=False
                ,return_listitem = True #allows for bulk appending of list items
                )
            )
    except:
        traceback.print_exc()
        raise
    finally:
        #add refresh and video items
        utils.Add_Refresh_Item(
            mode=REFRESH_MODE
            ,progress_dialog=progress_dialog
            ,end_directory=end_directory)
        xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)
        del items_list

    utils.endOfDirectory(
        end_directory=end_directory,
        cacheToDisc=True,
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    '''
    Because I can't find a generic image for not-online models, I will only refresh
    images that currently online
    The list of online models is cached in the global cache, but that list depends on
    url,page,depth
    I believe the 'Container.Refresh'  item knows those things [how else could a
    refresh happen?] but I can't find documentation on how to extract it
    Therefore I must cache the that data
    Is is very likely that I may miss some icons that should be deleted, particuarly if
    a recursive listing was made, but this entire listing is a best-effort
    '''
    most_recent = utils.global_cache.get(endpoint = MOST_RECENT_LIST)
##    progress_dialog = utils.Progress_Dialog(C.addon_name, '..cleaning cached images' )
##    models = GetCamgirlList(most_recent['url'], most_recent['page'], depth=int(most_recent['keyword']), progress_dialog=progress_dialog)
##    for model in models:
##        progress_dialog.increment_percent()
##        clean_database(showdialog=False, specific_texture=model['username']+'%' )
    Log("Container.Refresh")
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
@C.url_dispatcher.register(CLEANDATABASE_MODE)
def clean_database(showdialog=True, specific_texture=None):
    if specific_texture in [None,'']: return #don't clean up entire image database until we figure out how to get images for off-line models
    DEFAULT_IMAGE_DOMAIN = "%.highwebmedia.com%"
    FAV_ICON_FLAG = '%fav_image=true%'
    texture_connection = sqlite3.connect(C.translatePath("special://database/Textures13.db"))
    texture_cursor = texture_connection.cursor()
    try:
        image_domain = DEFAULT_IMAGE_DOMAIN
        if not(specific_texture in [None,'']):
            image_domain = image_domain + specific_texture #+ '%'
##            query = "SELECT id, cachedurl, url FROM texture WHERE url LIKE '{}';".format(image_domain)
        query = "SELECT id, cachedurl, url FROM texture "\
                "WHERE (url LIKE ?) " \
                "AND (cachedurl NOT IN (SELECT cachedurl FROM texture WHERE url LIKE ?) )"
        params = (image_domain, FAV_ICON_FLAG)
        Log(repr((query,params))) #,xbmc.LOGNONE)
        for texture_id, texture_image_cache, texture_url in texture_cursor.execute(query,params):
##            Log(repr((texture_id, texture_image_cache, texture_url)) ,xbmc.LOGNONE)
            query = "DELETE FROM sizes WHERE idtexture = ?"
            params = (texture_id,)
##            Log(repr((query,params)) ,xbmc.LOGNONE)
            texture_cursor.execute(query,params)
            query = "DELETE FROM texture WHERE id = ?"
##            Log(repr((query,params)) ,xbmc.LOGNONE)
            texture_cursor.execute(query,params)
            try:
                filespec = "special://thumbnails/" + texture_image_cache
                filespec = C.translatePath(filespec)
##                Log(repr(filespec),xbmc.LOGNONE)
                os.remove(filespec)
            except:
                traceback.print_exc()
                pass
            
        if showdialog:
            utils.notify(FRIENDLY_NAME +' images cleared')
    except:
        traceback.print_exc()
        pass
    finally:
        texture_connection.commit()
        texture_connection.close()
#__________________________________________________________________________
#
#def Search(searchUrl, keyword=None, end_directory=True, page_start=0, progress_dialog=None):
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=1
    , page_end=1
    , progress_dialog=None
    , bulk_operation=False
    ):
    return True
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True, page_start=1, page_end=1
                  , progress_dialog=None, bulk_operation=False):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
##    return True

    List(URL_RECENT, page_start=FIRST_PAGE, page_end=FIRST_PAGE+1, end_directory=end_directory, keyword=keyword)

    return True
#__________________________________________________________________________
#
def Camgirl_Generic_Image(model_id, url=None, current_icon=None):

    model_id = utils.Clean_Filename(model_id)
    Log("refreshing icon for {}".format(repr(model_id)), xbmc.LOGNONE)

    generated = False

    #site has generic banner whose size is smaller than this
    generic_icon_size = 5000

    response = utils.getHtml(current_icon
                             , send_back_response=True
                             )
    LogR((current_icon,response))
    if response and (len(response.data) > generic_icon_size): # we don't want the generic banner
        icon_image_url = current_icon
        generated = True
        Log("current_icon was found; image {} ".format(repr(icon_image_url)), xbmc.LOGNONE)
    else:
        #try using the current streaming pic
        #icon_image_url = "https://roomimg.stream.highwebmedia.com/riw/{}.jpg".format(model_id)
        icon_image_url = "https://thumb.live.mmcdn.com/riw/{}.jpg".format(model_id)

        if '|' not in icon_image_url:
            headers = C.DEFAULT_HEADERS.copy()
            headers = LIST_HEADERS()
            headers['Referer'] = url
            headers['Connection'] = 'keep-alive'
            icon_image_url = icon_image_url + utils.Header2pipestring(headers)

        response = utils.getHtml(icon_image_url
                                 , send_back_response=True
                                 )

    if not generated and (len(response.data) > generic_icon_size):
        generated = True
        Log("a current online image was found  {} ".format(repr(icon_image_url)), xbmc.LOGNONE)

    if not generated:
        # a generic banner was found
        # try and find a better image from the biography
        try:
            icon_image = current_icon
            headers = C.DEFAULT_HEADERS.copy()
            headers = LIST_HEADERS()
            headers['X-Requested-With'] = 'XMLHttpRequest'
            headers['Accept'] = '*/*'
            info_url = 'https://chaturbate.com/api/biocontext/{}/'.format(model_id)
            json_html = utils.getHtml(
                info_url
                , headers=headers
                , cache_duration=C.default_ISONLINE_cache_duration
                )
            json_info = json.loads(json_html)
            if 'photo_sets' in json_info:
                if len(json_info['photo_sets']) > 0:
                    icon_image_url = json_info['photo_sets'][0]['cover_url']
                    Log("photo set found in bio", xbmc.LOGNONE)
                else:
                    Log("not online; no album; keping original", xbmc.LOGNONE)
                    icon_image_url = current_icon
        except:
            Log("exception; no changes", xbmc.LOGNONE)
            icon_image_url = current_icon
            traceback.print_exc()

    if '|' not in icon_image_url:
        headers = C.DEFAULT_HEADERS.copy()
        headers = LIST_HEADERS()
        headers['Referer'] = url
        headers['Connection'] = 'keep-alive'
        icon_image_url = icon_image_url + utils.Header2pipestring(headers)
            
    LogR(icon_image_url, C.LOGNONE)
    return icon_image_url
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    PLAY_MODE
    , ['url', 'name', 'img']
    , ['playmode_string', 'download', 'play_profile', 'testmode']
    )
def Playvid(
    url,
    name,
    icon_URI,
    download=None,
    playmode_string=None,
    play_profile=None,
    testmode=False
    ):
    LogR(locals())
    if playmode_string and playmode_string[0].isdigit():
        max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    name = utils.Clean_Filename(name)
    description = name + '\n' + ROOT_URL
    video_url = None #final playable url

    if not playmode_string:
        #2026-03 make this default if not forced - due to site changes
        playmode_string = C.PLAYMODE_INPUTSTREAM 


    response = utils.getHtml(
                             url
                             , referer=ROOT_URL
                             , send_back_response=True
                             , cache_duration=C.default_ISONLINE_cache_duration
                             )

##    LogR(response)
    csrftoken = ''
    for cookie in response.cookies:
##        LogR(cookie)
##        LogR(dir(cookie))
        if cookie.name == 'csrftoken':
            csrftoken = cookie.value
            break
##    LogR(csrftoken)

    #2026-03-20  # a new set of servers and techniques
    referer = ROOT_URL + name + '/'
    headers = PLAY_HEADERS()
    headers['Referer'] = referer
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Content-Type'] = 'multipart/form-data; boundary=----geckoformboundary340807fe1ec4b058c046981f1dfd622c'
    headers['Sec-Fetch-Site'] = 'same-origin'
    sent_data = '''------geckoformboundary340807fe1ec4b058c046981f1dfd622c\r
Content-Disposition: form-data; name="room_slug"\r
\r
{}\r
------geckoformboundary340807fe1ec4b058c046981f1dfd622c\r
Content-Disposition: form-data; name="bandwidth"\r
\r
high\r
------geckoformboundary340807fe1ec4b058c046981f1dfd622c\r
Content-Disposition: form-data; name="current_edge"\r
\r
\r
------geckoformboundary340807fe1ec4b058c046981f1dfd622c\r
Content-Disposition: form-data; name="exclude_edge"\r
\r
\r
------geckoformboundary340807fe1ec4b058c046981f1dfd622c\r
Content-Disposition: form-data; name="csrfmiddlewaretoken"\r
\r
{}\r
------geckoformboundary340807fe1ec4b058c046981f1dfd622c--\r
'''
    url = 'https://chaturbate.com/get_edge_hls_url_ajax/'
    listhtml = utils.getHtml(
                             url
                             , headers=headers
                             , use_cookies = False
                             , sent_data = sent_data.format(name,csrftoken)
                             , method="POST"
                             , cache_duration=C.default_ISONLINE_cache_duration
                             )

    m = json.loads(listhtml)
    if m['room_status'] == 'public':
        video_url = m['url']
    else:
        if not download:
            utils.notify(
                header=FRIENDLY_NAME
                ,msg="{} is offline".format(name)
                ,duration=10000
                )
            return

##        referer = ROOT_URL + name + '/'
##        headers = PLAY_HEADERS()
##        headers['Referer'] = referer
##        headers['X-Requested-With'] = 'XMLHttpRequest'
##        url = 'https://chaturbate.com/api/chatvideocontext/{}/'.format(name)
##        listhtml = utils.getHtml(
##                                 url
##                                 , headers=headers
##                                 
##                                 , cache_duration=C.default_ISONLINE_cache_duration
##                                 )
##        m = json.loads(listhtml)
##        if m['room_status'] == 'public':
##            video_url = m['hls_source']
##        else:
##            if not download:
##                utils.notify(
##                    header=FRIENDLY_NAME
##                    ,msg="{} is offline".format(name)
##                    ,duration=10000
##                    )
##                return

    LogR(('active video url',video_url))
    #return

####    if 'savage' in name:
####        video_url = "https://edge5-ash.live.mmcdn.com/v1/edge/streams/origin.missksavage.01KMB0194MCTX6WSHFVMDP2GEH/llhls.m3u8?token=eyJhbGciOiJSU0EtT0FFUC0yNTYiLCJlbmMiOiJBMjU2R0NNIn0.E4VcSz2X5WpxYyh-0VPRloXch5KmqaycSqg7mlUE3BIhq8X5PAAv0iilpRpmobDKdogHE-8Fyj2bdLeDXbGUDXJyrsWEOI_v8MNH4arNGPPh5FelZG2UKf3L_zoPRvFhbZN9gRFwAN3l4bVzwuTsMBQFyPEHlCoo3Emw3gcGOCUAAdVx63JsedylIzm9tCzmdItUHOp6JDtbbNq9VLpf-hMxk_pgG4vZKZuVxNxqzD0M5x09N2yGEVTTQkQxBXnUEE2B0Qupt2ffUgqVfNUH6ij7_CslgWjCdeJMI7DhemMEUYpB28GuRlFfkv58oi0OOgnbOBLkQdyV9uTJ2v7uRw.TDLOXRpYRL70RfMj.Rk9JfaCT8qmd2bV_WlWagUBsHkIv9bz7LNelc8E-BLgt_zXy6dHoTxeqAEB4iCv82DQpL-fPdeW2xvMF8sWXOu1iLoxfBHl_5Ve0ias90SHMssz-TMbrJ-Nq4vay9_GNH8LVSYJdgt6RngKYRMC8vVt85GC6JGHf3VU35B8Y0fgN-i4XRHtaWz8dBosXulBEldyNOg8znTnGDJDRmeF_Ht_FTho1bgZND-AkrBMLXbzWZNuvqIUrHwqSyoB8N3SqCkstA-GTGfuXS3ehoVnHjQz7AKUkyaX1OwzNGyB4dAE5eCM5kfrPlbDqoB6DthLwlsesf-WGimT0_aibKOlSqJtKzuwcfLiJQGJxVvWlXbpnBACdL-ItPvwr4T6zeFnRubrSOfMqRattADAgYfgx1shXo3cAGKkr06KZiAGby7_iiDO2JVxDGg_dFtARch59O9hGjeyK_wu08EKMIp5qml8zEACi87ZX6tbApVfo38iQHy7lUt8XoYyQVtYqRE6qDuB00xesnFYwSiI.EXZiVeYT_CAxXvxd9dhW3Q"
        

##    #pre March 2026
##
##    # do stuff to get a playable url
##    listhtml = utils.getHtml(
##                             url
##                             , referer=ROOT_URL
##                             , cache_duration=C.default_ISONLINE_cache_duration
##                             )
##    #below may skip a sections because site provides duplicate/incorrect data
##    pattern = r'window.initialRoomDossier = "({.+?})"'
##    m3u8url = re.compile(pattern, re.DOTALL).findall(listhtml)
##    if m3u8url:
##        m3u8url =  m3u8url[0]
##        m3u8url = m3u8url.encode('utf8').decode('unicode_escape')
##        m = json.loads(m3u8url)
##        if m['room_status'] == 'public':
##            video_url = m['hls_source']
##        else:
##            if not download:
##                utils.notify(
##                    header=FRIENDLY_NAME
##                    ,msg="{} is offline".format(name)
##                    ,duration=10000
##                    )
##                return 

    #what if we fail to get a url??
    if not video_url:
        if download: #create a 'fake' dowload url so that scheduled d/l can happen
            video_url = 'scheduledfake.m3u8'
        elif testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
            return

    #always set referrer so that 'kodi' does not appear to the target server
    if '|' not in video_url:
##        headers = C.DEFAULT_HEADERS.copy()
##        headers['Referer'] = url
##        headers['Connection'] = 'keep-alive'
        headers = PLAY_HEADERS()
        video_url = video_url + utils.Header2pipestring(headers)

    #calculate potential download name here because I want to include recording date
    download_filespec = downloader.Make_download_path(
        name = name
        , include_date = True
        , file_extension = '.m4v' #this can work now that split streams?
        )

    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return video_url  #during testmode, only ensure that a url can be generated

    description += '\n' + video_url

    return utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI
        , skip_head = True
        , repeat_when_available = True
        , mimetype = 'application/vnd.apple.mpegurl'
        )
#__________________________________________________________________________
#
