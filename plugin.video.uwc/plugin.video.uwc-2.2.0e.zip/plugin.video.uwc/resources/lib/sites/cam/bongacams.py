'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

### cloudflare 2024-07-11


import datetime
import json
import os
import re
import sqlite3
import sys
import traceback
##import urllib
import xbmc

import utils
from utils import Log,LogR
import constants as C
from constants import quote

import downloader

FRIENDLY_NAME = '[COLOR {}]BongaCams[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://bongacams.com"
URL_FEMALES = ROOT_URL + "/tools/listing_v3.php?livetab=female&online_only=true&offset={}&model_search%5Bbase_sort%5D=popular%5Bgender%5D%5B%5D=female&_online_filter=0"
URL_COUPLES = ROOT_URL + "/tools/listing_v3.php?livetab=couples&online_only=true&offset={}&model_search%5Bbase_sort%5D=popular%5Bgender%5D%5B%5D=couples&_online_filter=0"

SEARCH_URL = 'stub - make all sites consistent'

MAIN_MODE          = C.MAIN_MODE_bongacams
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CLEANDATABASE_MODE = str(int(MAIN_MODE) + 3)
REFRESH_MODE       = str(int(MAIN_MODE) + 4)
SEARCH_MODE        = str(int(MAIN_MODE) + 5)
TEST_MODE          = str(int(MAIN_MODE) + 6)

FIRST_PAGE = 1

RESULTS_PER_PAGE = 200

BONGA_ROOM_DATA_PREFIX = "cached_bonga_data_"
BONGA_ROOM_DATA_CACHE_DURATION = 2
BONGA_GIRLS_CACHE_STRING = "bonga_girls"
BONGA_GIRLS_CACHE_DURATION = 2

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )
    utils.addDir(
        name="{}[COLOR {}]Couples[/COLOR]".format(C.SPACING_FOR_TOPMOST,C.search_text_color) 
        ,url=URL_COUPLES
        ,page_start=FIRST_PAGE
        ,mode=LIST_MODE
        ,iconimage=C.category_icon )
    List(URL_FEMALES, page_start=FIRST_PAGE, page_end=None, end_directory=True, keyword='')
#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page=1, depth=1, notify=False, progress_dialog=None):

##    bonga_girls = utils.global_cache.get(BONGA_GIRLS_CACHE_STRING+url+str(page)+str(depth))
####    bonga_girls = None #testing
##    if bonga_girls and (len(bonga_girls) > 0)  :
##        Log("using global_cache bonga_girls")
##        return bonga_girls

    if notify: utils.Notify("Listing {}".format(ROOT_URL))
        
    if '{}' in url and page: list_url = url.format((int(page)-1)*RESULTS_PER_PAGE*depth)
    else: list_url = url
    #note: max results per page is 130 regardless

    cookie = '{"sorting":"camscore","th_type":"live","limit":' + str(RESULTS_PER_PAGE*depth) + ',"display":"medium","c_limit":8}'
    cookie = quote(cookie)
    bongacam_header = {
                    'User-Agent': C.USER_AGENT
                    ,'Accept': "application/json, text/plain, */*"
                    ,'Referer': "{}".format(ROOT_URL)
                    ,'Accept-Encoding': 'gzip'
                    ,'Cookie': 'ls01=' + cookie
                    ,'X-Requested-With': 'XMLHttpRequest'
                    }
    json_html = utils.getHtml(list_url
                              , headers=bongacam_header
                              , cache_duration=C.default_ISONLINE_cache_duration
                              )
    if not json_html: return bonga_girls
    page_items = json.loads(json_html)

    json_items = json.loads("[]")

    for page_item in page_items['models']:
##        Log("json_item='{}'".format(json_item),C.LOGNONE)

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        if (('room' in page_item) and (page_item['room'] in ['public'])   
            and ('esid' in page_item) and ( len(str(page_item['esid'])) > 4 )):

            try:
                camscore=int(page_item["viewers"])
                hd = page_item["vq"]
                if not hd: hd = ""
                hd = utils.Normalize_HD_String(hd)
                icon_image = "https:" + page_item['thumb_image']
            except:
                Log("page_item='{}'".format(repr(page_item)))
                traceback.print_exc()
                
            name = page_item['username']
            label = "{}{} {}".format(C.SPACING_FOR_NAMES, utils.cleantext(name), hd)
            
            json_item = {}
            json_item["modelID"] = name
            json_item["username"] = name
            json_item['video_url'] = 'https://{}.bcvcdn.com/hls/stream_{}/playlist.m3u8'.format(
                                        page_item["esid"]
                                        , page_item["username"]
                                        )
            json_item['mode'] = PLAY_MODE
            json_item['icon_image'] = icon_image.replace("{ext}", "webp")
            json_item['camscore'] = camscore
            json_item['description'] = '\n' + ROOT_URL
            json_item['icon_label'] = label
            json_item['play_method'] = '' #leave this blank so that default value is used

            json_items.append(json_item)  

    return json_items
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword=''
         , testmode=False, progress_dialog=None, bulk_operation=False):

    LogR(locals())
    
    utils.Add_Refresh_Item(REFRESH_MODE, end_directory=end_directory)

    if not progress_dialog:
        progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)

    models = GetCamgirlList(url, page_start, progress_dialog=progress_dialog)
    videourl = ''
    for model in models:
        videourl = model['video_url'] 
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url']
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            )
    utils.Check_For_Minimum(videourl, keyword, MAIN_MODE, ROOT_URL, testmode)
    if (testmode == True) and (len(videourl) > 1):
        Playvid(model['video_url'] , model['icon_label'] , model['icon_image'], download=True, playmode_string=None, testmode=testmode)
        
    if models:
        has_next_page = True #(len(models) >= page_window)
        if has_next_page: 
            np_number = int(page_start) + 1
            np_url = url
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page_start=np_number
                    ,keyword=keyword )
            
    utils.endOfDirectory(
        end_directory=end_directory,
        cacheToDisc=True,
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    #clean_database(showdialog=False)
    Log("Container.Refresh")
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
def clean_database(showdialog=True):
    return True
####    db_version = {
####        '17':13  # Krypton
####        ,'18':13  # Leia
####        ,'19':13  # Matrix
####        ,'20':13  # nexus
####        ,'21':13  #
####        ,'22':14  #
####    }
####    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures{}.db".format(db_version[C.xbmc_version])))
##    raise Exception('todo validate path per version')
##    try:
##        with conn:
##            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % "bongacams.com")
##            for row in list:
##                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
##                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
##                except: pass
##            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % "bongacams.com")
##            if showdialog:
##                utils.notify('Finished','bongacams.com images cleared')
##    except:
##        pass
#__________________________________________________________________________
#
#def Search(searchUrl, keyword=None, end_directory=True, page_start=0, progress_dialog=None):
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=1
    , page_end=1
    , progress_dialog=None
    , bulk_operation=False
    ):
    return True
#__________________________________________________________________________
#
def getRoomData(model_id):
    endpoint = BONGA_ROOM_DATA_PREFIX + model_id
    room_data = None
##    room_data = utils.global_cache.get(endpoint)
    if room_data:
        Log(endpoint)
        pass
    else:
        Log("room_data for {} is None or Expired".format(repr(endpoint)))
        resetRoomData(endpoint)
        room_data= RoomData(model_id)
        setRoomData(room_data, endpoint)
    Log("room_data={}".format(repr(room_data)))
    return room_data
def setRoomData(room_data, endpoint):
    utils.global_cache.set(
        endpoint = endpoint
        ,data = room_data
        ,expiration = datetime.timedelta(minutes=BONGA_ROOM_DATA_CACHE_DURATION)
        )
def resetRoomData(endpoint):
    setRoomData(None,endpoint)
def RoomData(model_id):
    bongacam_headers = {
                    'User-Agent': C.USER_AGENT
                    ,'Accept': "application/json, text/javascript, */*"
                    ,'Referer': "{}/{}".format(ROOT_URL,model_id)
                    ,'X-ab-Split-Group': '0489906c37c151dade5c42d99af4440121b097b4d80d39233a3e00c06fb408c7ddc8eee2f8274b93'
                    ,'Accept-Encoding': 'gzip'
                    ,'X-Requested-With': 'XMLHttpRequest'
                    ,'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
    try:
        #https://bongacams.com/tools/amf.php?x-country=ca&res=1062342?1590534880043
        #method=getRoomData&args%5B%5D=ivy-8&args%5B%5D=true
        postRequest = {'method' : 'getRoomData', 'args[]' : str(model_id)}
        postRequest = urllib.urlencode(postRequest)
        #postRequest = "method=getRoomData&args[]=" + url + "&args[]=true"
        response = utils.postHtml(ROOT_URL + '/tools/amf.php', sent_data=postRequest, headers=bongacam_headers)
    except:
        response = '{}'
    room_json = json.loads(response)
    Log("room_json={}".format(repr(room_json)))
    return room_json
#__________________________________________________________________________
#
def Camgirl_Generic_Image(model_id, url=None, current_icon=None):
    model_id = utils.Clean_Filename(model_id)
    try:
        headers = C.DEFAULT_HEADERS.copy()
        headers['X-Requested-With'] = 'XMLHttpRequest'
        headers['Accept'] = '*/*'
        info_url = 'https://bongacams.com/profile/{}/get-profile-info'.format(model_id)
        json_html = utils.getHtml(info_url
                                  , headers=headers
                                  , cache_duration=C.default_ISONLINE_cache_duration
                                  )
        Log(repr(json_html))
        json_info = json.loads(json_html)
##        Log(repr(json_info))
        #https://i.bcicdn.com/06e/22d/2fe/1d5d1177ed414ef2c6d09b6fc0967aa3_profile_m.jpg
        icon_image = 'https:' + json_info["result"]['user']["profileImageUrls"]['avatar_120x120']
        icon_image = icon_image.split('_')[0] + '_profile_m.jpg'
    except:
        traceback.print_exc()
        icon_image = current_icon
##    Log(repr(icon_image))
    return icon_image
##
##    room_data = getRoomData(model_id)
##    try:
##        icon_image = 'https://i.bcicdn.com' + room_data['performerData']['avatarUrl']
##        icon_image = icon_image.replace('_avatars.jpg', '_profile_m.jpg')
##    except:
##        traceback.print_exc()
##        icon_image = current_icon
##    return icon_image
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True, page_start=1, page_end=1
                  , progress_dialog=None, bulk_operation=False):
    return True #2025-04 cloudflare
##    List(URL_FEMALES, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
##    return True
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name', 'img'], ['playmode_string', 'download', 'play_profile', 'testmode'])
def Playvid(url, name, icon_URI, download=None, playmode_string=None, play_profile=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
#    name = utils.Clean_Filename(name)
    description = name + '\n' + ROOT_URL
    
    # do stuff to get a playable url
    video_url = url
    Log(repr(video_url))
    if not('http' in video_url): #may be an old favorite...search top page
        for json_item in GetCamgirlList():
            if name in json_item['display_name']:
                video_url = json_item['video_url']
                break
            if name in json_item['username']:
                video_url = json_item['video_url']
                break
        
##    model_id = url
##    amf_json = getRoomData(model_id)
##    if not ('performerData' in amf_json) or not ('localData' in amf_json):
##        utils.Notify("{} is unavailable".format(name))
##        return
##    if amf_json['performerData']['showType'] in ('private','group'):
##        display_name = amf_json['performerData']['displayName']
##        utils.Notify("{} is private".format(display_name))
##        return
##    if not 'videoServerUrl' in amf_json['localData']:
##        display_name = amf_json['performerData']['displayName']
##        utils.Notify("{} is unavailable".format(display_name))
##        return
##    if amf_json['localData']['videoServerUrl'].startswith("//mobile"):
##       video_url = 'https:' + amf_json['localData']['videoServerUrl'] + '/hls/stream_' + model_id + '.m3u8'  
##    else:
##       video_url = 'https:' + amf_json['localData']['videoServerUrl'] + '/hls/stream_' + model_id + '/playlist.m3u8'

    #what if we fail to get a url??
    if not video_url or not('http' in video_url):
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return

    #always set referrer so that 'kodi' does not appear to the target server
    if '|' not in video_url:
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        video_url = video_url + utils.Header2pipestring(headers)

    #calculate potential download name here because I want to include recording date
    download_filespec = downloader.Make_download_path(
        name = name
        , include_date = True
        , file_extension = '.ts'
        )

    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return video_url   #during testmode, only ensure that a url can be generated

    return utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI
        , repeat_when_available = True
        )
#__________________________________________________________________________
#
