'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils
import resolver

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]VIPporns[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = True

    _ROOT_URL        = "https://www.vipporns.com"
    _SEARCH_URL      = _ROOT_URL + "/search/{}/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q={}&category_ids=&sort_by=&from_videos={}"
    _URL_CATEGORIES  = _ROOT_URL + '/categories/'
    _URL_RECENT      = _ROOT_URL + "/new-videos/?mode=async&function=get_block&block_id=list_videos_latest_videos_list&sort_by=post_date&from={}"
    _URL_MOST_VIEWED = _ROOT_URL + '/most-viewed/'
    _MAIN_MODE = C.MAIN_MODE_vipporns
    _FIRST_PAGE = 1

    _IGNORE_404 = False #sometimes 404 is ok, sometimes not

    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "is no data in this list"
        ]

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = (
                'class="porntrex-box"'
                '(.+)'
                'class="pagination"'
                    )
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        'class="item'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?data-original="(?P<thumb>[^"]+)"'
        '.+?(?P<hd>(?:<span class="is-hd">HD</span>|</div>))'
        '.+?class="duration">(?P<duration>[^<]+)<'
        #worked 2021-02
##        ?P<videourl>
##        ?P<thumb>
##        ?P<label>
##        ?P<duration>
##        '(?P<hd>)'
##        ?P<desc>
    )                         
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
##    _REGEX_next_page_region = (
##        '(.+)'
####        '</nav>'
##        )
    _REGEX_next_page_regex = (
            r'class="next"><a href="([^"]+)".+?from(?:_videos\+from_albums|4|):(\d+)'
        )
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        keyword = keyword.replace(' ','+')
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format(keyword.replace('+','-'),keyword,'{}')
        return search_url
    

    #__________________________________________________________________________
    #where categories can be found
    _REGEX_categories_region = (
        '"list-categories"(.*)class="footer-margin'
        )
    _REGEX_categories = (
        'href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
####        ?P<videourl>
####        ?P<thumb>
####        ?P<label>
        )
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = 'https' + + url
        key = url.split('/categories/')[1].split('/')[0]
        url =  "{}/categories/{}/?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date&from={}".format(
                self._ROOT_URL, key, '{}'
                )
        return url
    #__________________________________________________________________________
    # Change category thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        thumb += utils.Header2pipestring()+"&Referer=" + self._ROOT_URL
        if not thumb.startswith('http'): thumb = 'https' + thumb
        return thumb
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags_region = (
        r'<div class="info">.+?Models:'
        r'(.+)'
        r'id="tab_share"'
        )
    _REGEX_tags = (
        r'(?:/models/[^/]+/">|>)([^<]+)</a>'
        )
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        url = kargs["referer"]
        video_url = None

        regex = r"flashvars.+?license_code:.+?'(?P<lic>[^']+)'"
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(kargs["full_html"])
        if not sources_list:
            utils.Notify("No license code for {}".format(kargs["name"]))
            return
        license_code = sources_list[0]
        Log("license_code={}".format(license_code))
        

        regex = r"(?:video_url|video_alt_url.?):\s+?'(?P<url>[^']+)'"
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(kargs["full_html"])
        list_key_value = {}
        i = 0
        for source_list in sources_list:
            LogR(source_list)
            if 'res' in source_list.groupdict():
                list_key_value[source_list.group('res')] = source_list.group('url')
            else:
                i += 1
                list_key_value[str(240+i)] = source_list.group('url')

        fappy_salt = resolver.FaapySalt(license_code, "")
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        

        for rez in list_key_value:
            try:
                encoded_url = list_key_value[rez]
                if encoded_url.startswith("function/0/"):
                    encoded_url = encoded_url.split("function/0/")[1]
                    Log("encoded_url={}".format(encoded_url))
                encoded_fappy_code =  encoded_url.split('/')[5][0:32]
                new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
                video_url = encoded_url.replace(encoded_fappy_code, new_fappy_code)
                video_url = video_url + utils.Header2pipestring(headers)
                alt_results.append(  (rez, video_url )  )
            except:
                Log(list_key_value[rez],C.LOGWARNING)

        return alt_results

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
