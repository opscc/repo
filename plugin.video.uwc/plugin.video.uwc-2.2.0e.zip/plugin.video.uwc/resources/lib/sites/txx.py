'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
from base_website import Base_Website
from utils import Log,LogR

import base64
import json

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Txxx[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False
    
    _ROOT_URL        = u"https://txxx.com"
    _URL_CATEGORIES  = _ROOT_URL + u'/api/json/categories/14400/str.all.json'

    _URL_RECENT      = _ROOT_URL + u'/api/json/videos2/14400/str/latest-updates/60/..{}.all...json'
    _SEARCH_URL      = _ROOT_URL + u'/api/videos2.php?params=259200/str/relevance/60/search..{}.all..&s={}'
    #same as hclips?
    
    _MAIN_MODE = C.MAIN_MODE_txxx

    _FIRST_PAGE = 1

    _size_filter_min = 400 #must be 400 seconds long

    #where we can find videos on this page [exclude advertisement]
##    _REGEX_video_region = ('class="bloc-menu-centre(.+?)<script>')
    #videos on this page
    _REGEX_list_items = (
        r'{"video_id":"(?P<videourl>\d+)"'
        r'.+?"title":"(?P<label>[^"]+?)"'
        r'.+?"duration":"(?P<duration>[^"]+?)"'
        #'.+?"models":"(?P<desc>[^"]*?)"'
        '(?P<desc>)'
        '.+?"scr":"(?P<thumb>[^"]+?)"'
        '.+?"props":(?P<hd>[^,]*?),'
        )

    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #show all options

    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = r',"page":(\d+),'

    #where categories can be found
##    _REGEX_categories_region = (
##        'class="pvicon-categorie"(.+?)>All tags<'
##        )
    _REGEX_categories = (
        r'"title":"(?P<label>[^"]+)"'
        r',"dir":"(?P<videourl>[^"]+)"'
        r'(?P<thumb>)'
        )

    #where playable urls live
    _REGEX_playsearch_01 = (
        r'<source src="(?P<url>[^"]+?)" type='
        r'.+?(?P<res>\d)'
        )

    #description for the playable url
    _REGEX_tags = 'class="link12">(?P<tag>[^<]+)<'
    _REGEX_tags_region = '(.+)'

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def ALTERNATE_playsearch_01(self, *args, **kargs):

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]
        Log(u"url='{}'".format(url))

        items = json.loads(full_html)

        #stolen from current UWC 2021-02-02
        vidurl = items[0]['video_url']
##        Log(u"vidurl='{}'".format(vidurl))
        replacemap = {'M':'\u041c', 'A':'\u0410', 'B':'\u0412', 'C':'\u0421', 'E':'\u0415', '=':'~', '+':'.', '/':','}
        for key in replacemap:
            vidurl = vidurl.replace(replacemap[key], key)
##        Log(u"vidurl='{}'".format(vidurl))
        replacemap2 = {u'M':u'\u041c', u'A':u'\u0410', u'B':u'\u0412', u'C':u'\u0421', u'E':u'\u0415', u'=':u'~', u'+':u'.', u'/':u','}
        for key in replacemap2:
            vidurl = vidurl.replace(replacemap2[key], key)

##        Log(repr(vidurl))
##        if C.PY3: video_url = self.ROOT_URL + u'/' + str(base64.b64decode(vidurl), 'utf8')
##        if C.PY2: video_url = self.ROOT_URL + u'/' + base64.b64decode(vidurl)
        if C.PY3: video_url = str(base64.b64decode(vidurl), 'utf8')
        if C.PY2: video_url = base64.b64decode(vidurl)
        video_url = self.ROOT_URL + u'/' + video_url.lstrip(u'/')
        
        alt_results.append(  ('240', video_url)  )

        Log("alt_results={}".format(repr(alt_results)))        
        return alt_results

    
##    #__________________________________________________________________________
##    # Change list url as neeeded by website
##    def List_URL_Normalize(self, url):
##        return url.replace('page1.html', '')
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        videourl = self.ROOT_URL + u"/api/videofile.php?video_id={}&lifetime=8640000".format( videourl )
##        Log(videourl)
        return videourl
    #__________________________________________________________________________
    # Change thumb url created by List as neeeded by website
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        thumb = thumb.replace("\\/", "/")
##        Log(thumb)
        return thumb
##    #__________________________________________________________________________
##    # Change label created by List as neeeded by website
##    def Normalize_ListLabel(self, label, hd):
##        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, cleantext(label), hd)
##        return label        
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        return keyword.replace('+',' ').replace(' ','_')
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format('{}',keyword)
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        cat_url = self.ROOT_URL + "/api/json/videos2/86400/str/latest-updates/60/categories.{}.{}.all..day.json".format(url, '{}')
##        Log(cat_url)
        return cat_url
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
##@C.url_dispatcher.register(website.TEST_MODE, ['keyword','end_directory'])
##def Test(keyword=None, end_directory=True, page_start=1, page_end=1):
##    website.Test(end_directory=end_directory)
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 

#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
