'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import re
#import internal addon libraries
import utils
from base_website import Base_Website
import constants as C
#define frequenctly used aliases
from utils import Log,LogR

class Specific_Website(Base_Website):
    
    _FRIENDLY_NAME = '[COLOR {}]HQporner[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True

    _ROOT_URL           = "https://hqporner.com"
    _URL_RECENT         = _ROOT_URL + '/hdporn/{}'
    _URL_CATEGORIES     = _ROOT_URL + '/porn-categories.php'
    _URL_CATEGORIES     = _ROOT_URL + '/categories' #2025-04
    _SEARCH_URL         = _ROOT_URL + '/?q={}&p={}'

    _MAIN_MODE = C.MAIN_MODE_hqporner

    _FIRST_PAGE = 1 #Note:site does not support page1.html

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "I can't find porn to your request"
        ,"Sorry, I can't find porn to your request"
        ]

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = (
        'class="box page-content"'
        '(.+)'
        '<ul class="actions pagination">'
        )

    #videos on this page    
    _REGEX_list_items = (
        'var preload_'
        '.+?<a href="(?P<videourl>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        
        '.+?fa-clock-o meta-data">(?P<duration>[^<]+)<'
        '(?P<hd>)'
##        '<section class="box feature">'
##        '.+?src="(?P<thumb>[^"]+)"'
##        '.+?alt="(?P<label>[^"]+)"'
##        '.+?<a href="(?P<videourl>[^"]+)"'
##        '.+?fa-clock-o meta-data">(?P<duration>[^<]+)<'
##        '(?P<hd>)'
        )
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'class="pagination"(.+)'
    _REGEX_next_page_regex =  'class="actions pagination".+?<a href="([^"]+)"[^>]+>Next'


    #where categories can be found
    _REGEX_categories = (
        '<a href="(?P<videourl>[^"]+)"'
        '[^<]+<img src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        )

    #where playable urls live
    _REGEX_playsearch_01 = (
        r"video(?:_alt|)_url\d?: '(?P<url>[^']+)',"
        r".+?video(?:_alt|)_url\d?_text: '(?P<res>\d+)"    
        )

    #description/actors for the playable url
    _REGEX_tags = None #"href='/pornstar/.+?>([^<]+)<"
    _REGEX_tags = r'href="\/actress\/[^"]+".+?>(?P<model>[^<]+)<\/a>'
    _REGEX_tags_region = r'<header>(.+?)</header>'


    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'):
            url = self._ROOT_URL + url
        url = url + '/{}'
        return url

    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        headers = None #2022-12 thumbs need referrer
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
        if headers:
            thumb = thumb + utils.Header2pipestring(headers)
        return thumb
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        headers = None #2022-12 thumbs need referrer
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
        if headers:
            thumb = thumb + utils.Header2pipestring(headers)
        return thumb
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args)>0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args)>1): keyword = args[1]
        elif (args is not None) and (len(args)>0): keyword = args[0]
        else                                     : keyword = ""

        keyword_1 = keyword.replace('+',' ').replace(' ','%20')
        keyword_2 = keyword_1.replace('%20','+')

        return search_url.format(keyword_2, '{}')
    
    _REGEX_icon_search = (
        '.+?poster=\\\\"(?P<thumb>[^\\\\]+)\\\\'
        )
    #__________________________________________________________________________
    #
    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
        Log(u"Icon_Search url={}, pattern={}, referer={}".format(repr(url),repr(pattern),repr(referer))
##            , C.LOGNONE
            )

        page_content = utils.getHtml(url, referer)
        iframeurl = re.compile(r"nativeplayer\.php\?i=([^']+)", re.DOTALL | re.IGNORECASE).findall(page_content)
        if not iframeurl: return None
        if not (iframeurl[0].startswith('http')): iframeurl = 'https:' + iframeurl[0]
        page_content = utils.getHtml(iframeurl, referer)
        info = re.compile(pattern, re.DOTALL | re.IGNORECASE).finditer(page_content)
        for item in info:
            thumb = item.group('thumb')
            if thumb and not thumb.startswith('http'): thumb = 'https:' + thumb
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = referer
            return thumb + utils.Header2pipestring(headers)
        return None

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]
        download = kargs["download"]
        download = kargs["name"]
        max_video_resolution = None
        Log(u"url='{}'".format(url))
        

        iframeurl = re.compile(r"nativeplayer\.php\?i=([^']+)", re.DOTALL | re.IGNORECASE).findall(full_html)
        if not iframeurl:
            Log(repr(url),C.LOGNONE)
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(download, self._ROOT_URL))
            return alt_results
        if not (iframeurl[0].startswith('http')):
            iframeurl = 'https:' + iframeurl[0]
        video_url = None
        try:
            if (not video_url) and re.search('bemywife', iframeurl, re.DOTALL | re.IGNORECASE):
                Log("bemywife{}".format(""))
                video_url = getBMW(iframeurl,url,download)
        except: pass
        Log("video_url={}".format(repr(video_url)))
        try:
            if (not video_url) and re.search('mydaddy', iframeurl, re.DOTALL | re.IGNORECASE):
                Log("mydaddy{}".format(""))
                video_url = getBMW(iframeurl, url, download, max_video_resolution)
        except:
            raise
            pass
##        Log("video_url={}".format(repr(video_url)))
        try:
            if (not video_url) and re.search(r'\/hqwo\.cc\/', iframeurl, re.DOTALL | re.IGNORECASE):
                Log("hqwo{}".format(iframeurl))
                video_url = getBMW(iframeurl, url, download, max_video_resolution)
        except:
            #raise
            pass
##        Log("video_url={}".format(repr(video_url)))
        try:
            if not video_url and re.search(r'5\.79', iframeurl, re.DOTALL | re.IGNORECASE):
                Log("getIP{}".format(""))
                video_url = getIP(iframeurl)
        except: pass
##        Log("video_url={}".format(repr(video_url)))
        try:
            if not video_url and re.search(r'flyflv', iframeurl, re.DOTALL | re.IGNORECASE):
                Log("flyflv{}".format(""))
##                if (iframeurl.startswith('https:')):
##                    #apr 2018; https requires authentication for this site, http no
##                    iframeurl = iframeurl.replace('https://','http://')
                video_url = getFly(iframeurl)
        except: pass
        try:
            if not video_url and re.search('bigcdn', iframeurl, re.DOTALL | re.IGNORECASE):
                Log("bigcdn{}".format(""))
                if (iframeurl.startswith('https:')):
                    #apr 2018; https requires authentication for this site, http no
                    iframeurl = iframeurl.replace('https://','http://')
                video_url = getFly(iframeurl)
        except: pass

        if video_url:
            if type(video_url) == str:
                if not video_url.startswith('http'): video_url = 'https:' + video_url
                alt_results.append(  ('240', video_url)  )
            else:
                alt_results+=video_url
        Log("alt_results={}".format(repr(alt_results)))        
        return alt_results

    

#__________________________________________________________________________
#
website = Specific_Website() #always need this
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.SEARCH_MODE
    , ['url']
    , ['keyword'
       , 'end_directory'
       , 'page_start'
       , 'page_end'
       , 'bulk_operation'
       ]
    )
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=website._FIRST_PAGE
    , page_end=website._FIRST_PAGE
    , progress_dialog=None
    , bulk_operation=False
    ):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.REBUILD_ICON, ['url'])
def Rebuild_Icon(url):
    website.Rebuild_Icon(url)
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.PLAY_MODE
    , ['url', 'name']
    , ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode']
    )
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )

#__________________________________________________________________________
#

def getBMW(url, referer="", download=False, max_video_resolution=None):
    Log("getBMW url='{}', referer='{}'".format(url,referer))
    videopage = utils.getHtml(url, referer)
    intermediate_url = None
    regex = r"src='(https://n\d\.hqwo\.cc/.+?)'"
    re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    if re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage):
        regex = r"<script type='text/javascript'\s+?src='(https://n\d\.hqwo\.cc/.+?)'"
        intermediate_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
        if intermediate_url: intermediate_url = intermediate_url[0]
        Log("intermediate_url='{}'".format(intermediate_url))
        videopage = utils.getHtml(intermediate_url, url)
    regex = r'<source (?:file"?:|src=).+?"(//[^"]+?mp4).+?(?:label"?:|title=).*?"(\d+)'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    if not sources_list:
        regex = r'(?:file"?:|src=).+?"(//[^"]+?mp4).+?(?:label"?:|title=).*?"(\d+)'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    Log("sources_list='{}'".format(sources_list))
    alt_results = list()
    if len(sources_list) < 1:
        return alt_results
    
    for i in range(len(sources_list)):
        q = sources_list[i][1]

        v = sources_list[i][0]
        if q.lower() == '4' and ('2160' in v): q='2160' #hack for non standard wary site is storing info
        if not v.startswith('http'): v = 'https:' + v
        alt_results.append(  (q, v)  )
##    Log(repr(alt_results))
##    return None
    return alt_results

##    list_key_value = {} ##[] #dict()
##    for i in range(len(sources_list)):
##        q = sources_list[i][0]
##        #q = q.split(':')[1].replace('"', '')
##        v = sources_list[i][1]
##        #v = sources_list[i][1].split('url:')[1].replace('"', '')
##        if not v == "":
##            list_key_value[q] = v
##    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
##    Log("list_key_value='{}'".format(list_key_value))
##    video_url = utils.SortVideos(
##        sources=list_key_value
##        ,download=download
##        ,vid_res_column=1
##        ,max_video_resolution=max_video_resolution
##        )
##    Log("video_url={}".format(video_url))
##    return video_url
def getIP2(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile(r'"file": "(\S+)",', re.DOTALL | re.IGNORECASE).findall(videopage)    
    videourl = videos[-1]
    return videourl
def getIP(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('file": "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = videos[-1]
    return videourl
def getFly(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('src=\'(.*)\' type=', re.IGNORECASE).findall(videopage)
    video_url = videos[-1]
    if not (video_url.startswith('http')):
        video_url = 'http:' + video_url
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = 'https://www.flyflv.com'
        video_url = video_url + utils.Header2pipestring(headers)

        
    return video_url
