'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import random
import constants as C
from base_website import Base_Website
from utils import Log,LogR,Sleep

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]peekvids[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True
    
    _ROOT_URL        = "https://www.peekvids.com"
    _URL_CATEGORIES  = _ROOT_URL + '/categories'
    _URL_RECENT      = _ROOT_URL + '/?page={}'
    _SEARCH_URL      = _ROOT_URL + '/videos?qry={}&page={}'

    _MAIN_MODE = C.MAIN_MODE_peekvids

    _FIRST_PAGE = 1
    #if we need to save html cookies
##    _SAVE_COOKIES = False
    _SAVE_COOKIES = True
    _Right_Click_Option = None

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        '<div class="title-delete-info">'
        ]


    #__________________________________________________________________________
    # add an alternative way to resolve listing
    def List_URL_Normalize(self, url, page):
        #site will block if too many requests; try to avoid using this sleep
        t = random.randrange(1000,2000)
        Log('sleeping {} milliseconds'.format(repr(t)))
        Sleep(t)
        return url
    
    #where we can find videos on this page [exclude advertisement]
    #_REGEX_video_region = '(?:data-section_name="day_by_day_section" data-espnode|video_row_main_search"|data-espnode="videolist")(.+?)(?:id="pagination"|<footer>)'
    #videos on this page
    _REGEX_list_items = (
        'video-item-.+?href="(?P<videourl>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        '.+?(?:<span class="hd">|<span)(?P<hd>[^<=]+)(?:<|=)'
        '.+?duration.+?>(?P<duration>[^<]+)<'
        )

    #where we can find info on whether there is a next page
    _REGEX_next_page_regex = r'"next"[\s]+href="([^"]+)"'



    #where categories can be found
    _REGEX_categories_region = 'class="category-list-view"(.+?)/section-wrapper'
    _REGEX_categories = (
        '<a href="(?P<videourl>/category/[^"]+)"'
        '>(?P<label>[^<]+)<'
        '(?P<thumb>)'
        )

    #where playable urls live
    _REGEX_playsearch_01 = (
        r'(?P<res>\d)'
        r'.+?id="player".+?src="(?P<url>[^"]+)"'
        )

    #description for the playable url
    _REGEX_tags = '"/pornstar/.+?>([^<]+)<'
    _REGEX_tags_region = 'class="detail-video-block"(.+?)class="comments-wrapper"'

    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by site
    def xxxVideo_Source_URL_Normalize(self, url):
        return C.urldecode(url)

    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url + '?page={}'


#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=website._FIRST_PAGE
    , page_end=website._FIRST_PAGE
    , progress_dialog=None
    , bulk_operation=False
    ):
    website.Search(
        searchUrl
        , keyword=keyword
        , end_directory=end_directory
        , page_start=page_start
        , page_end=page_end
        , progress_dialog=progress_dialog
        , bulk_operation=bulk_operation
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, ['keyword','end_directory'])
def Test(keyword=None, end_directory=True, page_start=1, page_end=1):
    website.Test(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
