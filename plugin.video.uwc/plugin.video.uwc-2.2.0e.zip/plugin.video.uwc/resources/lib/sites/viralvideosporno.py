'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils
import resolver

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]ViralVideosPorno[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True

    _ROOT_URL        = "https://www.viralvideosporno.com"
    _URL_CATEGORIES  = _ROOT_URL 
    _URL_RECENT      = _ROOT_URL + "/pagina/{}/"
    _SEARCH_URL      = _ROOT_URL + '/buscar_{}_pag-{}.html'
    _URL_MOST_VIEWED = _ROOT_URL + '/most-viewed/'
    _MAIN_MODE = C.MAIN_MODE_viralvideosporno
    _FIRST_PAGE = 1

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "NO SE HAN ENCONTRADO REGISTRO"
        ]
    #__________________________________________________________________________
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        r'(?:class="notice_title"|class="captura")'
        r'.+?title="(?P<label>.+?)"'
        r'.+?href="(?P<videourl>.+?)"'
        r'(?P<hd>)'
        r'.+?src="(?P<thumb>.+?)"'
        r'(?P<duration>)'
        ) #2023-03 ; no more tags for HD; use title
    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = r'<div id="pagination">(.*)'
    _REGEX_next_page_regex = r"(&raquo;</a><)"

    #__________________________________________________________________________
    #where categories can be found
    _REGEX_categories_region = 'class="contenedor_menu"(.*?)id="general_barra"'
    _REGEX_categories = (
        r'href="(?P<videourl>//viralvideosporno.com/.+?)"'
        r'.+?">(?P<label>.+?)<'
        r'(?P<thumb>)'
        )
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags = r'class="vit-pornstar.+?href="/pornstar/.+?>([^<]+)<\/a>'
    _REGEX_tags_region = "(.+)"           #'class="categorieswrapper(.+?)<noscript>'
    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        return thumb
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = 'https:' + videourl        
        return videourl
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        if not url.startswith('http'): url = 'https:' + url
        if '/categoria/' in url:
            url = url + '/{}'
        else:
            url = url + '_{}'
##        LogR(locals())
        return url
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        regex = r'fa-download">(.+?)<div class="saltar">'
        next_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
        regex = r'(https?://.+?)(?:"|\s)'
        next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(next_region)


        #removing possible duplicate
        next_link  = list(dict.fromkeys(next_link))
        
        needs_resolving_source = '  '.join(next_link)
        LogR(needs_resolving_source,C.LOGINFO)

        import resolver
        video_url = resolver.resolve_video(
            videosource=needs_resolving_source
            , name=kargs["name"]
            , download=kargs["download"]
            , url=kargs["referer"]
            , ask_which_file_hoster=kargs["ask_which_file_hoster"]
            )
        Log("video_url={}".format(video_url))

        alt_results.append(  ('240', video_url )  )

##        LogR(alt_results)
##        return None
        return alt_results

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        keyword = keyword.replace(' ','+')
##        LogR(locals())
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format(keyword,'{}')
##        LogR(locals())
        return search_url
##    #__________________________________________________________________________
##    # Change LIST to enable max recurse depth
##    def List(self, url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
##        try:
##            org = C.MAX_RECURSE_DEPTH
##            if C.PY3:                       super().List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            if C.PY2: super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
##            C.MAX_RECURSE_DEPTH = org
##        except:
##            pass
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI', 'testmode'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    return website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
