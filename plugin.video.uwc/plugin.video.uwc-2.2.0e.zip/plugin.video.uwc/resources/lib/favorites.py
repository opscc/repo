#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import base64
import os
import random
import re
import sqlite3
import sys
import time
import traceback
from uuid import uuid4
import xbmc
import xbmcgui
import xbmcplugin

import constants as C
import queries as Q
import utils

from constants import urlencode
from constants import urlparse
from utils import Log,LogR
from utils import get_setting as GetSetting

from fav_dbconn    import generic_favdbconn
from fav_textures  import Insert_Binary_Image
from fav_textures  import find_thumbnail_in_cache
from fav_textures  import delete_thumbnail_in_cache

from fav_schema    import Create_Maintain_FavDB
from replication   import Add_Sync_Favorites,Favorites_Sync

import webcam_db
import downloader

##from sites.cam.chaturbate import clean_database as chaturbate_clean
##from sites.cam.cam4       import clean_database as cam4_clean
##from sites.cam.streamate  import clean_database as streamate_clean
##from sites.cam.naked      import clean_database as naked_clean
##from sites.cam.myfreecams import clean_database as mfc_clean

##C.DEBUG = True

today = utils.UTC_timestamp()
MAX_DAYS_WITHOUT_SYNC = 7
ONE_DAY_TIMESTAMP = 86400.0
MFC_PLAY_MODE = str(int(C.MAIN_MODE_myfreecams) + C.MODE_PLAY_OFFSET)

try:  FAV_LIST_LIMIT = GetSetting("FAV_LIST_LIMIT", int)
except:  FAV_LIST_LIMIT = 200
try: FAV_LIST_FRACTION = GetSetting("FAV_LIST_FRACTION", int)
except:  FAV_LIST_FRACTION = 20 # 1/5th chance of being shown after LIMIT is reached

# m_ denotes my module_level global; value initizlized a dispatcher entrypoint
m_texture_conn   = None
m_favorites_conn = None 

#__________________________________________________________________
#
def RefreshImages():
##    chaturbate_clean(False)
##    cam4_clean(False)
##    naked_clean(False)
##    mfc_clean(False)
##    streamate_clean(False)
##    bongacams_clean(False)
    pass

#__________________________________________________________________
#
@C.url_dispatcher.register(
    C.MARK_AS_WATCHED
   ,['mode','uuid']
   )  
def MarkAsWatched(mode, uuid):
    LogR(locals())
    pass
    #use uuid to get the mode and run 'test download'
    #parse out

#__________________________________________________________________
#
@C.url_dispatcher.register(C.REFRESH_CONTAINER_MODE)  
def RefreshContainter():

    #init m_favorites_connfor every entrypoint
    global m_texture_conn; m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
    global m_favorites_conn; m_favorites_conn = generic_favdbconn(database=C.favoritesdb)
    Create_Maintain_FavDB(m_favorites_conn) 

    #if manually refreshing, latest required, but 1 min should be good enough    
    latest_required = 1
##    Log("warning deve comment"); latest_required = None
    if latest_required: webcam_db.clear_webcam_db( latest_required )
    
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________
#
@C.url_dispatcher.register(C.REBUILD_CAM_THUMBS)  
def Rebuild_CAM_Thumbnails():
    Log(C.module_name())

    # get list of cams; include binary thumb column
    # write out the file
    
    #do this for every entrypoint
    global m_texture_conn; m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
    global m_favorites_conn; m_favorites_conn = generic_favdbconn(database=C.favoritesdb)
    Create_Maintain_FavDB(m_favorites_conn) 

    progress_dialog_message = "Rebuild CAM Thumbnails"
    progress_dialog = utils.Progress_Dialog(
        C.addon_name
        , progress_dialog_message
        )

    closing_message = u"rebuild finished"

    percent = 1
    progress_dialog.update(
        percent = int(percent)
        ,message = progress_dialog_message 
        ,line2 = ' '
        ,line3 = '...rebuilding...'
        )    

    query = Q.LIST_FAVORITES_CAMSITE(
        Q.FAV_DB_VERSION_CURRENT
        , connection = m_favorites_conn
        , include_binary_image = True
        )
    favDB_cursor = m_favorites_conn.execute(query)
    for a in favDB_cursor.fetchall():

        model = dict(a)

        if progress_dialog.iscanceled(): break
        progress_dialog.update(
            percent  = progress_dialog.percent + 0.1
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...{}...'.format(model['name'])
            )

        binary_image = model['binary_image']
        if not binary_image:
            LogR(('skipping because no binary image',model['name']))
            continue
    
        if isinstance(binary_image, bytes):
            binary_image = binary_image.decode('utf8')

        if not '|' in model['image'] and 'http' in model['image']:
            model['image'] = "{}{}".format(model['image'], utils.Header2pipestring())
            q = Q.REFRESH_FAV2(
                Q.FAV_DB_VERSION_CURRENT
                , uuid = model['uuid']
                , image = model['image']
                , description = model['description']
                , binary_image = binary_image
            )
            r = m_favorites_conn.upsert(
                 q["table"]
                ,q["key_name"]
                ,q["key_value"]
                ,q["column_tuple"]
                ,q["value_tuple"]
                )
            m_favorites_conn.commit()
            
        icon_filespec = Insert_Binary_Image(
                binary_image
                ,model['image']
                ,model['name']
                , force_write_image = True
                , m_texture_conn = m_texture_conn
                )
        
##        Log(icon_filespec)



    xbmcgui.Dialog().select(
                heading = u"Rebuild CAM Thumbnails"
                #, message= u"log file copied"
                , list = [closing_message]
                , autoclose = 5000 #(REPLICATION_NOTIFY_DURATION//2)
                ) 

#__________________________________________________________________
#
@C.url_dispatcher.register(C.REBUILD_NONCAM_THUMBS)  
def Rebuild_NONCAM_Thumbnails():
    Log(C.module_name())

    # get list of cams; include binary thumb column
    # write out the file
    
    #do this for every entrypoint
    global m_texture_conn; m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
    global m_favorites_conn; m_favorites_conn = generic_favdbconn(database=C.favoritesdb)
    Create_Maintain_FavDB(m_favorites_conn) 


    progress_dialog_message = "Rebuild NONCAM Thumbnails"
    progress_dialog = utils.Progress_Dialog(C.addon_name, progress_dialog_message)

    percent = 1
    progress_dialog.update(
        percent = int(percent)
        ,message = progress_dialog_message 
        ,line2 = ' '
        ,line3 = '...rebuilding...'
        )    

    query = Q.LIST_FAVORITES_NOCAMSITE(
        Q.FAV_DB_VERSION_CURRENT
        , connection = m_favorites_conn
        , include_binary_image = True
        )

    favDB_cursor = m_favorites_conn.execute(query)

    for a in favDB_cursor.fetchall():

        model = dict(a)
        
        if progress_dialog.iscanceled(): break
        progress_dialog.update(
            percent  = progress_dialog.percent + 0.1
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...{}...'.format(model['name'])
            )


        binary_image = model['binary_image']
        if not binary_image:
            LogR(('skipping MISSING binary_image',model['name']))
            continue
        
        if isinstance(binary_image, bytes):
            binary_image = binary_image.decode('utf8')

        if not '|' in model['image'] and 'http' in model['image']:
            model['image'] = "{}{}".format(model['image'], utils.Header2pipestring())
            q = Q.REFRESH_FAV2(
                Q.FAV_DB_VERSION_CURRENT
                , uuid = model['uuid']
                , image = model['image']
                , description = model['description']
                , binary_image = binary_image
            )
            r = m_favorites_conn.upsert(
                 q["table"]
                ,q["key_name"]
                ,q["key_value"]
                ,q["column_tuple"]
                ,q["value_tuple"]
                )
            m_favorites_conn.commit()
            
        icon_filespec = Insert_Binary_Image(
                binary_image
                ,model['image']
                ,model['name']
                , force_write_image = True
                , m_texture_conn = m_texture_conn
                )
        Log(icon_filespec)



    xbmcgui.Dialog().select(
                heading = u"Rebuild NON CAM Thumbnails"
                #, message= u"log file copied"
                , list = [u"rebuild finished"]
                , autoclose = 5000 #(REPLICATION_NOTIFY_DURATION//2)
                )
    
#__________________________________________________________________
#
@C.url_dispatcher.register(C.PLAY_RANDOM_FAV)  
def Add_Play_Random(dir_only=False):
    Log(C.module_name())
    
    #do this for every entrypoint
    global m_texture_conn; m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
    global m_favorites_conn; m_favorites_conn = generic_favdbconn(database=C.favoritesdb)
    Create_Maintain_FavDB(m_favorites_conn) 
    
    if dir_only:
        utils.addDir(
            name="[COLOR {}]Random Favorited Vid[/COLOR]".format(C.highlight_text_color)
            ,url=C.DO_NOTHING_URL
            ,mode=C.PLAY_RANDOM_FAV
            ,iconimage=C.category_icon
            ,duration=2
            ,Folder=False 
            )
        return

    try:
        model = model_id = None

        params = ()
        query = Q.GET_RANDOM_NOT_CAM_FAVORITE_INFO(
            Q.FAV_DB_VERSION_CURRENT
            ,m_favorites_conn)
        model = m_favorites_conn.execute(query,params)
        model = model.fetchone()

        listitem = utils.addDownLink( 
              name = model['name']  #"Random Vid of the Day" #utils.cleantext(icon_label) #model['icon_label'] 
            , url = model['url']
            , mode = model['mode'] 
            , iconimage = model['image']
            , desc = u"{}\n{}".format(utils.cleantext(model['name']), model['description'])
            , return_listitem = True
            )
        u = listitem[0]

        xbmc.executebuiltin('RunPlugin('+u+')')
    except:
        traceback.print_exc()
        LogR((model,model_id),C.LOGWARNING)
        
#__________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_FAVORITES)
def List():
##        LogR((
##            C.module_name()
##            , str(traceback.extract_stack(limit=2)[0][0])+":"+str(traceback.extract_stack(limit=2)[0][1])
##            , locals()
##            ))
##  C.DEBUG = True

    #do this for every entrypoint
    global m_texture_conn; m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
    global m_favorites_conn; m_favorites_conn = generic_favdbconn(database=C.favoritesdb)
    Create_Maintain_FavDB(m_favorites_conn) 

    items_list = list()
    
    remote_favorite_db = C.remote_favorite_db #GetSetting("remote_favorite_db_folder", str)
    favorites_sync_datetime = GetSetting("favorites_sync_datetime", float)
    if remote_favorite_db and favorites_sync_datetime:
        LogR( ( (today-favorites_sync_datetime)//ONE_DAY_TIMESTAMP ) )
        LogR(('next backup on GMT ', time.ctime((favorites_sync_datetime + MAX_DAYS_WITHOUT_SYNC*ONE_DAY_TIMESTAMP))),C.LOGNONE)
        if today > (favorites_sync_datetime + MAX_DAYS_WITHOUT_SYNC*ONE_DAY_TIMESTAMP):
            days = (today-favorites_sync_datetime)//ONE_DAY_TIMESTAMP
            if C.PY2:
                result = xbmcgui.Dialog().yesno(
                        heading = u"Favorites Sync"
                        , line1 = u"{} days since in favorites sync".format(days)
                        , autoclose = 10000
                        )
            if C.PY3:
                result = xbmcgui.Dialog().yesno(
                        heading = u"Favorites Sync"
                        , message= u"{} days since in favorites sync".format(days)
                        , autoclose = 10000
                        , defaultbutton = xbmcgui.DLG_YESNO_NO_BTN #only in kodi 20+
                        )
            LogR(result)
            if result:
                Favorites_Sync()
                
            
    progress_dialog_message = "Listing Favorites"
    progress_dialog = utils.Progress_Dialog(
        C.addon_name
        , progress_dialog_message
        )

    try: 

        #include some utility icons
        utils.Add_Refresh_Item(
            mode=C.REFRESH_CONTAINER_MODE
            ,progress_dialog=progress_dialog
            ,duration=2 #duration so that when sorting by duration, refresh shows after active webcams when = 1
            ,end_directory=True)

        Add_Play_Random(True)

        if GetSetting("auto_clean_img_database", bool):
            RefreshImages()
        manually_refresh_favorites = GetSetting("manually_refresh_favorites", bool)
        play_method = GetSetting("default_playmode", str)
        
        percent = 1
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...filling/scanning webcam database...'
            )

##        Log('warning dev comment below')
        webcam_db.fill_webcam_db(progress_dialog)  #db will be locked so that service can't clear DB during processing
        percent = 30 #an arbitrary number...
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...matching online cams...'
            )
        i = 0

        model = [] #value should be initialized in case exception        

        try:

            query = Q.LIST_FAVORITES_CAMSITE(
                Q.FAV_DB_VERSION_CURRENT
                , connection = m_favorites_conn
                , include_binary_image = GetSetting("include_binary_image_cams", bool)
                )

##            Log('warning')
##            favDB_cursor = m_favorites_conn.execute(" EXPLAIN QUERY PLAN " + query)
##            for a in favDB_cursor.fetchall():
##                try:
##                    LogR(dict(a),C.LOGNONE)
##                except Exception as e:
##                    LogR(e)
##                    LogR(dir(a))
##                    LogR(a, include_type=True)

            
            favDB_cursor = m_favorites_conn.execute(query)
            for a in favDB_cursor.fetchall():
                
                if progress_dialog.iscanceled(): break

                model = dict(a)
                
                name= a['name']
                modelID= a['modelID']
                url= a['url']
                mode= a['mode']
                img = a['image']
                binary_image = a['binary_image']
                camsite = a['camsite']
                model_currently_online = a['isonline'] not in ['0',0,None]

                icon_label = name

                model['video_url'] = url
                model['icon_url'] = img
                model['icon_binary_filespec'] = img

                #devlopement only - get an idea of where we are
                
                
                #if model_currently_online or str(mode)==mfc_PLAY_MODE:
                if model_currently_online:

                    if i < 5:
                        LogR(model)

                        
                    progress_dialog.update(
                        percent  = progress_dialog.percent + 0.1
                        ,message = progress_dialog_message 
                        ,line2 = ' '
                        ,line3 = '...found {}...'.format(name)
                        )
                    Log('...found {}...'.format(name), C.LOGNONE)
                    
                    icon_label = u"[COLOR {}]{}[/COLOR]".format(
                        C.search_text_color
                        , name
                        )
                    
                    if str(mode) == MFC_PLAY_MODE:
                        
##                        Log("warning #site allows easy name changes, but no searching via id")
                        current_model_name = model['modelDisplayName']
                        if current_model_name and (current_model_name != name):
                            #automatically refresh name in fav database
                            Log("new mfc model name '{}' --> '{}'".format(
                                name
                                , current_model_name
                                ), C.LOGWARNING)
                            #download name also needs changing
                            downloader.rename_download(
                                name = C.DOWNLOAD_INDICATOR+name
                                ,new_name = C.DOWNLOAD_INDICATOR+current_model_name
                                ,mode = mode
                                ,friendly_name = current_model_name
                                ,url_factory = current_model_name
                                )
                            Log('ehre')
                            Rename_Fav(
                                  url=current_model_name
                                , name=current_model_name
                                , uuid=model['uuid']
                                )
                        else:
                            Log(u"mfc '{}' was not renamed".format(current_model_name))

                    model['icon_url'] = img

##                    #test - trying to refresh online cam image
##                    model['icon_url'] = model['icon_binary_filespec']


##                    LogR(model)

                elif not model_currently_online:

                    #force to end of listing when sort by duration
                    model['camscore'] = 0
##                    model['camscore'] = 
                    
                    if binary_image:
                        if C.PY2:
                            if isinstance(binary_image, buffer):
                                binary_image = str(binary_image)
                        if C.PY3:
                            if isinstance(binary_image, bytes):
                                binary_image = binary_image.decode('utf8')
                        # the path to the icon will change from
                        #    http://somthing  specified in 'icon_url'
                        #  to   localfilespec
                        model['icon_binary_filespec'] = Insert_Binary_Image(
                             binary_image
                            , model['icon_url']
                            , model['name']
                            , force_write_image = GetSetting("include_binary_image_cams", bool)
                            , m_texture_conn = m_texture_conn 
                            )

                        
                else:
                    Log('not online or offline')

                i = i+1

                if 'hq_stream' in model: hq_stream = model['hq_stream']
                else: hq_stream = 0
                    
                if 'play_method' in model:
                    if model['play_method'] in ('','None','none',None):
                        play_method = None
                elif 'play_method' in model:
                    play_method = model['play_method']
                else:
                    play_method = None

##                if i < 5: LogR(play_method)
                
                items_list.append(
                    utils.addDownLink( 
                        name = utils.cleantext(icon_label)
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_binary_filespec']
                        , icon_url = model['icon_url']
                        , duration = model['camscore']
                        , play_method = play_method
                        , fav = 'del'
                        , desc = utils.cleantext(model['description'])
                        , hq_stream = hq_stream
                        , return_listitem = True
                        , uuid = model['uuid']
                        )
                    )

            progress_dialog.update(
                percent  = progress_dialog.percent + 0.1
                )
            Log("end models query",C.LOGNONE)

            #permit user interruption
            progress_dialog.update(
                percent = progress_dialog.percent + 0.1
                ,message = progress_dialog_message 
                ,line2 = ' '
                ,line3 = '...listing non cams...'
                )
                
            #non cam favorites
            query = Q.LIST_FAVORITES_NOCAMSITE(
                Q.FAV_DB_VERSION_CURRENT
                , connection = m_favorites_conn
                , include_binary_image = GetSetting("include_binary_image_nocams", bool)
                )

            i = 0
            favDB_cursor = m_favorites_conn.execute(query)
            for a in favDB_cursor.fetchall():

##                Log("warning: skip nocams")
##                break #debugging; skip nocams
##                LogR(a,C.LOGNONE) #debugging

                #permit user interruption
                if progress_dialog and progress_dialog.iscanceled(): break
                progress_dialog.update(
                    percent = progress_dialog.percent + 0.1
                    ,message = progress_dialog_message 
                    ,line2 = ' '
                    ,line3 = '...matching non cams...'
                    )

                if (i>FAV_LIST_LIMIT): #e.g. after limit; 1/5 ~20% chance of including item
##                    LogR((i,FAV_LIST_LIMIT,FAV_LIST_FRACTION),C.LOGNONE)
                    if FAV_LIST_FRACTION>1:
                        if int(random.random()*100) > FAV_LIST_FRACTION:
                            continue
                    else:
                        LogR(('FAV_LIMIT_reached',i,FAV_LIST_LIMIT,FAV_LIST_FRACTION)
                             ,C.LOGWARNING)
                        break

                model = dict(a)
                
                name = a['name']
                url= a['url']
                mode= a['mode']
                img = a['image']
                description = a['description']
                binary_image = a['binary_image']
                camsite = a['camsite']
                model['camscore'] = 1
                icon_label = name
                model['video_url'] = url
                model['icon_binary_filespec'] = img
                model['icon_url'] = img

                #devlopement only - get an idea of where we are
                if i < 5:
                    LogR(model)

                #limit total # of entries
                i = i+1
                    
                if binary_image:
                    if C.PY2:
                        if isinstance(binary_image, buffer):
                            binary_image = str(binary_image)
                    if C.PY3:
                        if isinstance(binary_image, bytes):
                            binary_image = binary_image.decode('utf8')
                    # the path to the icon will change from
                    #    http://somthing  specified in 'icon_url'
                    #  to   localfilespec
                    model['icon_binary_filespec'] = Insert_Binary_Image(
                         binary_image
                        , model['icon_url']
                        , model['name']
                        , force_write_image = GetSetting("include_binary_image_nocams", bool)
                        , m_texture_conn = m_texture_conn  
                        )


                if 'hq_stream' in model: hq_stream = model['hq_stream']
                else: hq_stream = 0
                if 'play_method' in model and model['play_method'] in ('','None','none',None):
                    play_method = None
                elif 'play_method' in model:
                    play_method = model['play_method']
                else:
                    play_method = None

                if i < 5: LogR(play_method)
                
                items_list.append(
                    utils.addDownLink( 
                        name = utils.cleantext(icon_label)
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_binary_filespec']
                        , icon_url = model['icon_url']
                        , duration = model['camscore']
                        , play_method = play_method
                        , fav = 'del'
                        , desc = utils.cleantext(model['description'])
                        , hq_stream = hq_stream
                        , return_listitem = True
                        , uuid = model['uuid']
                        )
                    )

            #end non-cam-favorites query
            
        except :
            LogR(traceback.format_exc(),C.LOGERROR)
            utils.notify('No Favorites found')
            

    except :
        LogR(traceback.format_exc())
        raise

    finally:
        
        #then add all the generated listitems
        xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)

        #this happens here so that items are at bottom when sort_duration
        Add_Sync_Favorites(True)
        
    set_default_view = {
        "path": sys.argv[0] + sys.argv[2]
        # Note: xbmcplugin.SORT_METHOD_DURATION  and "SortUtils.h".SortByTime values are different
        ,"sortmethod" : C.INITIAL_SORTMETHOD #sort by time/duration
        ,"sortdirection" : True #toggle to descending [because when blank,  default is ascending]
        ,"viewmode"      : C.INITIAL_VIEWMODE
        ,"sleeptime"     : max(100, int(FAV_LIST_LIMIT*3)) #need more time to set view will large number of items
        }
    LogR(set_default_view)
    utils.endOfDirectory(
        cacheToDisc= (manually_refresh_favorites==True),
        set_default_view=set_default_view,
        updateListing=False,
    )

#__________________________________________________________________
#
def check_if_camsite(favmode):
    #sometimes we need to know if a favorite cam model
    result = 0 #default 
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_CAMS):
        if (int(mode)+C.MODE_PLAY_OFFSET) == favmode:
            result = 1
            break
    return result

#__________________________________________________________________
#
class Exception_Page_Deleted(Exception):
    pass

#__________________________________________________________________
#
@C.url_dispatcher.register(
    C.FAVORITES_MODE
   ,['fav','favmode','name','url','img']
   ,['desc','camsite','icon_url','uuid','modelID']
   )  
def Favorites(
    fav
    ,favmode
    ,name
    ,url
    ,img
    ,desc=None
    ,camsite=0
    ,icon_url=None
    ,uuid=None
    ,modelID=None
    ):

    LogR((C.module_name(), locals()))

    #do this for every entrypoint
    global m_texture_conn; m_texture_conn = generic_favdbconn(database=C.texture_DB_filespec)
    global m_favorites_conn; m_favorites_conn = generic_favdbconn(database=C.favoritesdb)
    Create_Maintain_FavDB(m_favorites_conn) 
   
    try:

        is_camsite = check_if_camsite(favmode)

        n_bak = name
        url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
        name = utils.Clean_Filename(name)
        if name in [None,'']: raise Exception("invalid name '{}'".format(n_bak))


        if not modelID:

            if not str(favmode)==MFC_PLAY_MODE:
                modelID = name

            else:
                model_id_via_image = "00000000" # length of 8
                try:
                    #todo: remove this dependency
                    from sites.cam.myfreecams import Camgirl_Generic_Image as mfc_generic_image

                    if "/img.mfcimg.com/" in img or "/snap.mfcimg.com/" in img :
                        model_id_via_image = img.split('/')[6]
                        model_id_via_image = model_id_via_image.split('|')[0]
                        if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                            model_id_via_image = img.split('/')[5]
                        #the 1 indicates model was in public chat when bookmark created
                        if model_id_via_image.startswith("mfc_a_1"):
                           model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
                        if model_id_via_image.startswith("mfc_1"):
                           model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
                        if model_id_via_image[0] == '0':
                            model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
                        img = mfc_generic_image(model_id_via_image)
                        while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
                            model_id_via_image = '0' + model_id_via_image
##                        LogR((name, model_id_via_image))
                        modelID = model_id_via_image
                except:
                    traceback.print_exc()
                    raise
                        
        if fav in ["add"]:

            if img.startswith(C.translatePath("special://home/")):
                utils.Notify(u"Can't add/refresh fav when icon points to local file. Find an original source")
                return
##            LogR(type(name), C.LOGINFO)
##            LogR(name, C.LOGINFO, include_type=True)
##            import unicodedata
####            # Normalize characters to Standard Form C (NFC)
##            normalized_name = unicodedata.normalize('NFC', name)
##            LogR(dir(xbmc.Keyboard()), C.LOGINFO)
            keyboard = xbmc.Keyboard(
##                normalized_name,
                name,
                heading = u"Change name before adding?",
                hidden = False,
                )
            keyboard.doModal()
##            LogR(name, C.LOGINFO)
            if keyboard.isConfirmed():
##                LogR(name, C.LOGINFO)
                name = keyboard.getText()
##                LogR(name, C.LOGINFO)
            else:
                LogR((name,'alternate name canceled during modal'),C.LOGNONE)
                #notify user of what we have done
                needs_an_e = '' #'' if fav[-1] == 'e' else 'e'
                utils.Notify(u"skipped {}{}ing fav:'{}' url:{}".format(fav.capitalize(),needs_an_e,name,url))
                return

            # addFav will delete any previous matching url
            normalized_name = addFav(
                favmode
                , name
                , url
                , img
                , desc
                , is_camsite
                , uuid=uuid
                , modelID=modelID
                ) 


        elif fav == "del":
            delFav(url, img, name, icon_url, uuid=uuid)

        elif fav in ["rename"]:
            
            keyboard = xbmc.Keyboard(name, 'Rename', hidden=False)
            keyboard.doModal()
            if keyboard.isConfirmed():
                keyboard_text = keyboard.getText()
            else:
                #notify user of what we have done
                needs_an_e = '' if fav[-1] == 'e' else 'e'
                utils.Notify(u"skipped {}{}ing fav:'{}' url:{}".format(fav.capitalize(),needs_an_e,name,url))
                return
            Rename_Fav(url=url, name=keyboard_text, uuid=uuid)

        
        elif fav in ["refresh"]:
##            Log(fav)
##            Log(uuid)
            if not icon_url:
                icon_url = img
            Refresh_fav_DB(
                display_name = name
                , play_url = url
                , image_url = icon_url
                , model_id = modelID
                , mode = favmode
                , uuid = uuid
                , m_favorites_conn = m_favorites_conn
                )

        
        else:
            raise NotImplementedError('unhandled fav operation '+fav)

        #notify user of what we have done
        needs_an_e = '' if fav[-1] == 'e' else 'e'
        utils.Notify(u"{}{}d fav:'{}' url:{}".format(fav.capitalize(),needs_an_e,name,url))

    except Exception_Page_Deleted as e:
        utils.Notify("Favorite '{}' deleted?. Try playing it.".format(name))

    except Exception as e:
        utils.Notify('unhandled error {}. See Log'.format(repr(e)))
        raise



#__________________________________________________________________
#
def Refresh_fav_DB(
      display_name
    , play_url
    , image_url
    , model_id
    , mode
    , uuid
    , m_favorites_conn
    ):
    
    LogR((C.module_name(), locals()))

    #__________________________________________________________________
    #
    def Validate_base64_image_size(base64_image):
        if base64_image:
            image_length = len(base64.b64decode(base64_image))
            LogR(image_length)
            if image_length < _MIN_VALID_IMAGE_SIZE:
                LogR((
                    'warning: base64_image is too small. Sometimes an empty image is provided'
                    ,display_name
                    ,image_url
                    )
                    ,C.LOGINFO
                    )
                base64_image = '' ; Log('base64_image changed')
            if image_length in _BAD_IMAGE_SIZES: #add another check for known 'bad' images
                LogR((
                    'warning: base64_image size in list of bad sizes'
                    ,display_name
                    ,image_url
                    )
                    ,C.LOGINFO
                    )
                base64_image = '' ; Log('base64_image changed')
        else:
            Log('base64_image is none or blank')
        
        return (base64_image != '')

    #__________________________________________________________________
    #
    def Validate_binary_image_size(binary_image):
        #
        # actually validate the CURRENT favorite image
        #
        if binary_image:
            image_length = len(binary_image)
            LogR(image_length)
            if image_length < _MIN_VALID_IMAGE_SIZE:
                LogR((
                    'warning: binary_image is too small. Sometimes an empty image is provided'
                    ,display_name
                    ,image_url
                    )
                    ,C.LOGINFO
                    )
                binary_image = '' ; Log('binary_image changed')

            if image_length in _BAD_IMAGE_SIZES: #add another check for known 'bad' images
                LogR((
                    'warning: binary_image size in list of bad sizes'
                    ,display_name
                    ,image_url
                    )
                    ,C.LOGINFO
                    )
                binary_image = '' ; Log('binary_image changed')
        else:
            Log('binary_image is none or blank')

        return (binary_image != '')
        
    
    query = Q.GET_FAV_VIA_UUID(Q.FAV_DB_VERSION_CURRENT)
    params = (uuid,) 
    result = m_favorites_conn.execute(query, params)
    result = result.fetchone()
    if result:
        #Note: we use the img_url from caller so that we can
        #      cache latest webcam images
##              img_url = result['image']
        base64_image = result['binary_image']
        description = result['description'] 
    else:
        base64_image = description = ''

    save_folder = "special://home/cache/archive_cache"
    save_folder = C.translatePath(save_folder)
    if save_folder in image_url:
        #then currenly using a value in cache folder
        #  img points to http...somthing
        #check for a http location in order to updat he cached version
        Log('save_folder in img')
        if img_url.startswith(C.translatePath("special://home/")):
            utils.Notify(u"Can't add/refresh fav when icon points to local file. Find an original source")
            return
    else:
        Log("image_url='{}' does not refer to an item in the local file cache".format(image_url))




    #
    # Get information to validate the binary image we have downloaded - as best we can
    #
    _MIN_VALID_IMAGE_SIZE = C.MIN_VALID_IMAGE_SIZE
    _BAD_IMAGE_SIZES = []
    binary_image_length = 0
    site_icon_search_method = None
    camgirl_generic_image_method = None

    get_sites = utils.Get_Sites(icon_function=True)
    for module, main_mode_id, sitename in get_sites:
        module_play_mode_id = int(main_mode_id)+C.MODE_PLAY_OFFSET
        if module_play_mode_id == mode:
##                    Log('found site module')
##                    LogR(dir(module))
            if '_BAD_IMAGE_SIZES' in dir(module): #add another check for known 'bad' images
                _BAD_IMAGE_SIZES = module._BAD_IMAGE_SIZES
                Log('{} _BAD_IMAGE_SIZES is {}'.format(
                    sitename
                    ,repr(_BAD_IMAGE_SIZES)
                    )
                    )
            if '_MIN_VALID_IMAGE_SIZE' in dir(module):
                _MIN_VALID_IMAGE_SIZE = module._MIN_VALID_IMAGE_SIZE
                Log('{} _MIN_VALID_IMAGE_SIZE is {}'.format(
                    sitename
                    ,_MIN_VALID_IMAGE_SIZE
                    )
                    )
            if 'Icon_Search' in dir(module):
                site_icon_search_method = getattr(module, 'Icon_Search')
                Log('Icon_Search found')
                
            if 'Camgirl_Generic_Image' in dir(module):
                camgirl_generic_image_method = getattr(module, 'Camgirl_Generic_Image')
                Log('Camgirl_Generic_Image found')
##                site_icon_search_method = camgirl_generic_image_method

            break #stop searching for sites as we have found it
    else:
        LogR((module.__name__, dir(module))
            ,C.LOGNONE
            )
        utils.Notify(
            u"Site '{} does not have an icon rebuild function".format(
            repr(module.__name__).split('.')[-1]
            )
            )
        #get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
        return True
        pass
    try:
        get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
    except StopIteration:
        pass


    #
    # download the image via url because we are refreshing
    #   we MAY or MAY NOT save the result to local database
    #
    try:
        binary_image = utils.getHtml(image_url)
        Log('binary image downloaded from site using img url')
    except Exception as e:
        binary_image = ''; Log('binary_image blanked')

        
    #
    # validate the currently stored db image
    #     just-in-case some sort of invalid image was stored
    #
    # 
    if not Validate_base64_image_size(base64_image): base64_image = '' 

    if not Validate_binary_image_size(binary_image): binary_image = '' 


    if not binary_image:
        #there is no valid binary_image using current image_url

        rebuilt_icon_url = None

        try:
            if site_icon_search_method:
                Log("get a new binary image from website via '{}'".format(play_url) )
        
                rebuilt_icon_url = site_icon_search_method(play_url)
                if not '|' in rebuilt_icon_url and 'http' in rebuilt_icon_url:
                    rebuilt_icon_url = "{}{}".format(rebuilt_icon_url, utils.Header2pipestring())

                LogR(("rebuilt_icon_url",rebuilt_icon_url))

                binary_image = utils.getHtml(rebuilt_icon_url, ignore404=True) ; Log('binary_image changed')
                if not binary_image: raise Exception_Page_Deleted('Page may have been deleted')
                if not Validate_binary_image_size(binary_image):
                    binary_image = rebuilt_icon_url = '' ; Log('binary_image invalidated')


            elif camgirl_generic_image_method: 

                Log("get a new binary image from website via model_id='{}'".format(model_id) )        
                rebuilt_icon_url = camgirl_generic_image_method(model_id)
                if not '|' in rebuilt_icon_url and rebuilt_icon_url.startswith('http') :
                    rebuilt_icon_url = "{}{}".format(rebuilt_icon_url, utils.Header2pipestring())
                LogR(("rebuilt_icon_url",rebuilt_icon_url))

                binary_image = utils.getHtml(rebuilt_icon_url) ; Log('binary_image changed')
                if not Validate_binary_image_size(binary_image):
                    binary_image = rebuilt_icon_url = '' ; Log('binary_image invalidated')


            if rebuilt_icon_url:
                img_url = rebuilt_icon_url
                LogR(img_url,C.LOGNONE)
                base64_image = base64.b64encode(binary_image).decode('utf8') ; Log('base64_image changed')
          
        except StopIteration:
            pass
        except GeneratorExit:
            pass
        except Exception_Page_Deleted:
            raise
        except Exception as ex:
            LogR(ex)
            binary_image = rebuilt_icon_url = ''

    else: 
        Log('binary_image from website is OK based on size')
        base64_image = '' #zero this; new image can be saved in next steps


    if not '|' in image_url and image_url.startswith('http') :
        image_url = "{}{}".format(image_url, utils.Header2pipestring())


    if not base64_image:
##        LogR(binary_image)
        try:
            base64_image = base64.b64encode(binary_image).decode('utf8') ; Log('base64_image changed')
##            if C.PY3:
##                if isinstance(base64_image, bytes):
##                    base64_image = base64_image.decode('utf8')
##            LogR(base64_image)
        except:
            traceback.print_exc()
            raise
        
    if not base64_image.startswith(('/9j/','UklG')):
        base64_image = ''; Log('base64_image changed')
        Log('warning zeroed out image because it was not JPEG or WEBM', C.LOGINFO)
    else:
        Log('base64 indicates peg or webp')

    #
    # Only because we are here ... try to normalize description
    # description is only changed when it is originally blank
    #
    if not description: 
        description = "{}//{}".format(
            urlparse.urlparse(play_url).scheme
            ,urlparse.urlparse(play_url).netloc
            ) 
    if description == "//": #som urls do not have http ... resulting in // only
        description = "{}://{}".format(
            urlparse.urlparse(image_url).scheme
            ,urlparse.urlparse(image_url).netloc
            )


    #
    # Actually save the data
    #
    q = Q.REFRESH_FAV2(
        Q.FAV_DB_VERSION_CURRENT
        , uuid = uuid
        , image = image_url
        , description = description
        , binary_image = base64_image #column was was created with binary format....
    )
    r = m_favorites_conn.upsert(
         q["table"]
        ,q["key_name"]
        ,q["key_value"]
        ,q["column_tuple"]
        ,q["value_tuple"]
        )

    if True or "binary_image" in r:  #always update kodi's image database
        Insert_Binary_Image(
            base64_image
            , image_url
            , display_name
            , force_write_image=True
            )
        
    m_favorites_conn.commit()
    Log('m_favorites_conn.commit()')
            
#__________________________________________________________________
#
def Insert_fav_DB(
    name
    , url
    , mode
    , image
    , description
    , camsite
    , binary_image
    , uuid
    , is_binary=True
    , modelID = None
    ):

    #binary_image = ""; LogR(locals(),C.LOGNONE);
    #Log('warning develpment setting'); return
    
    if not uuid: uuid = str(uuid4())

    if is_binary:
        binary_image = base64.b64encode(binary_image)

    if C.PY3:
        if isinstance(binary_image, bytes):
            binary_image = binary_image.decode('utf8')

    q = Q.UPSERT_FAV(
        Q.FAV_DB_VERSION_CURRENT
        , name = name
        , url = url
        , mode = mode
        , image = image
        , description = description
        , camsite = camsite
        , binary_image = binary_image
        , uuid = uuid
        , modelID = modelID
    )
    r = m_favorites_conn.upsert(
         q["table"]
        ,q["key_name"]
        ,q["key_value"]
        ,q["column_tuple"]
        ,q["value_tuple"]
        )

    if True or "binary_image" in r:
        Insert_Binary_Image(
            binary_image
            , image
            , name
            , force_write_image=True)
    m_favorites_conn.commit()

#__________________________________________________________________
#
def Clean_Textures_DB():
    raise NotImplementedError(C.module_name(),FAV_DB_VERSION)
    pass

#__________________________________________________________________
#
def addFav(
    mode,
    name,
    url,
    img,
    description,
    camsite,
    uuid,
    modelID
    ):

    LogR(
        (C.module_name(), locals())
        , C.LOGINFO
        )

    if not '|' in img and 'http' in img:
        img = "{}{}".format(img, utils.Header2pipestring())
        
    result = find_thumbnail_in_cache(img)
    if (result is None) and img.startswith('special://'): #maybe mode has a way to generate img
        raise Exception()
                    
    if (result is None):
        msg = u"Can't find image to refresh with. Reload the container and/or check network container"
        Log(msg
            ,C.LOGNONE
            )
        img_content = utils.getHtml(img)
        LogR(img)
        if not img_content:
            if not description.endswith('/'): description+='/'
            header = {"Referer":description}
            if not (urlencode(header) in img):
                img = img + '&' + urlencode(header)
                img = img.replace("|","&_={}|".format(utils.RandomNumber()))
                img_content = utils.getHtml(img)
        Insert_fav_DB(
            name
            , url
            , mode
            , img
            , description
            , camsite
            , img_content
            , uuid=uuid
            , modelID=modelID
            )
        return name
    else:
        LogR(("already in cache", result[1], " as ", result[2]))
        pass

    img_url = result[1]
    if "|" in img_url:
        headers = img_url.split("|")[1]
        img_url = img_url.split("|")[0]
        headers = urlparse.parse_qs(headers.encode('ASCII'))
        h = {}
        for a in headers:
            h[a] = str(headers[a][0])
        headers = h
    else:
        headers = {}
    img_content = utils.getHtml(
        img_url
        , headers=headers
        )

    Insert_fav_DB(
        name
        , url
        , mode
        , img
        , description
        , camsite
        , img_content
        , uuid=uuid
        , modelID=modelID
        )

    return name
#__________________________________________________________________
#
def Rename_Fav(url, name, uuid):
    try:
        (query,params) = Q.RENAME_FAV(
            Q.FAV_DB_VERSION_CURRENT
            , name, url, uuid
            , m_favorites_conn)
        cursor_result = m_favorites_conn.execute(query,params)
        LogR(cursor_result.rowcount)
        m_favorites_conn.commit()
    except:
        LogR((C.module_name(), locals()))
        raise
#__________________________________________________________________
#
# delete favorite from
#    our database,
#    texture database,
#    disk icon cache
def delFav(
    url
    , img
    , name
    , icon_url
    , uuid
    ):

    try:

        #delete from favdb
        (query,params) = Q.DELETE_FAV(
            Q.FAV_DB_VERSION_CURRENT
            , url
            , uuid
            , m_favorites_conn)
        delete_result = m_favorites_conn.execute(query,params)

        (query,params) = Q.FAV_FIND_IMAGE(
            Q.FAV_DB_VERSION_CURRENT
            , icon_url
            , m_favorites_conn)
        
        select_result = m_favorites_conn.execute(query,params).fetchall()
        if len(select_result) > 1:
            Log('uri is used by multiple sources: skipping file delete')
        else:
            delete_thumbnail_in_cache( img, m_texture_conn )
        m_favorites_conn.commit()


    except:
        LogR((C.module_name(), locals()))
        raise

#__________________________________________________________________
#
