#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import sqlite3
import traceback
import xbmc 
import xbmcaddon
import xbmcvfs

#import internal addon libraries
import utils 
import constants as C
#define common aliases
from utils import Log

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CONFIGURE_THIS_ADDON)
def configure_THIS_addon():
    Log("configure_THIS_addon")
    xbmcaddon.Addon(id=C.addon_id).openSettings()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CONFIGURE_INPUTSTREAM)
def configure_inputstream():
    Log("configure_inputstream")
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CONFIGURE_FMPROXY)
def configure_inputstream():
    Log("CONFIGURE_FMPROXY")
    try:
        xbmcaddon.Addon(id='script.video.F4mProxy').openSettings()
    except:
        traceback.print_exc()
        
        
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CLEAN_SIMPLECACHE)
def Clean_SimpleCache_DB():
    Log(C.module_name())
    simplecache_conn = sqlite3.connect(C.translatePath("special://home/userdata/addon_data/script.module.simplecache/simplecache.db")) 
    try:    
        simplecache_cursor = simplecache_conn.cursor()
        query = "DELETE FROM simplecache WHERE id LIKE 'plugin.video.uwc_gethtml_%'"
        params = ''
        Log(repr((query,params))
            ,C.LOGNONE
            )
        simplecache_cursor.execute(query,params)

    except:
        traceback.print_exc()
    finally:
        simplecache_conn.commit()
        
#__________________________________________________________________________
#

