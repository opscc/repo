#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import certifi
import os.path
import random
import sys
import unicodedata
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui

PY3 = sys.version_info >= (3, 0)
PY2 = not PY3

##xbmc.log(repr(sys.path),xbmc.LOGNONE)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
##xbmc.log(repr(sys.path),xbmc.LOGNONE)

if   PY3: from xbmcvfs import translatePath
elif PY2: from xbmc    import translatePath

if   PY3: from xbmcvfs import makeLegalFilename
elif PY2: from xbmc    import makeLegalFilename

if   PY3: from xbmcvfs import validatePath
elif PY2: from xbmc    import validatePath

if PY3: text_type = str  
if PY2: text_type = unicode #this keyword will raise error in PY3

import importlib
if PY2: from imp import reload
if PY3: from importlib import reload

import io
if PY2: import StringIO
if PY3: StringIO = io.StringIO

if PY2: import Queue
if PY3: import queue as Queue

if PY2: import cookielib
if PY3:     import http.cookiejar as cookielib

if PY2: import BaseHTTPServer
if PY3: import http.server as BaseHTTPServer

if PY2: import SocketServer
if PY3: import socketserver as SocketServer

if PY2: from urllib2 import urlparse    
if PY3: from urllib import parse as urlparse

if PY2: from urllib import urlencode
if PY3: from urllib.parse import urlencode

if PY2:
    from urllib2 import unquote
    from urllib2 import unquote as urldecode

if PY3:
    from urllib.parse import unquote
    from urllib.parse import unquote as urldecode

if PY2: from urllib import unquote_plus
if PY3: from urllib.parse import unquote_plus

if PY2: from urllib2 import quote
if PY3: from urllib.parse import quote

if PY2: from urllib import quote_plus
if PY3: from urllib.parse import quote_plus

if PY2: import urllib2
if PY3: import urllib.error as urllib2

if PY2: import SocketServer
if PY3: import socketserver as SocketServer

if PY2: from HTMLParser import HTMLParser
if PY3: from html.parser import HTMLParser

html_parser = HTMLParser()
if PY2:
    def unescape(s):
        return(html_parser.unescape(s))
if PY3: from html import unescape


from url_dispatcher import URL_Dispatcher
url_dispatcher = URL_Dispatcher()

QUESTION_MARK_SUBSTITUTE = unicodedata.lookup('FULLWIDTH QUESTION MARK')

this_addon = xbmcaddon.Addon()
DEBUG = (this_addon.getSetting('debug').lower() == "true")
LOGNONE = xbmc.LOGNONE
if PY2: LOGWARNING = xbmc.LOGWARNING
if PY3: LOGWARNING = xbmc.LOGWARNING
LOGNOTICE = 11
LOGINFO = xbmc.LOGINFO
LOGERROR = xbmc.LOGERROR
IE_USER_AGENT = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko'
FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/{}0101 Firefox/77.0'
##OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.132 Safari/537.36 OPR/67.0.3575.97'
##IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1'
##ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.138 Mobile Safari/537.36'
EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.102 Safari/537.36 Edge/18.18363'
CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.{}.182 Safari/537.36'
#SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15'
_USER_AGENTS = [
    FF_USER_AGENT
##                , OPERA_USER_AGENT
        , EDGE_USER_AGENT
        , CHROME_USER_AGENT
]
rand_ff_version = random.randint(120, 128)
rand_ff_patch = random.randint(0, 1)
##USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{}.{}) Gecko/20100101 Firefox/{}.{}".format(rand_ff_version,rand_ff_patch,rand_ff_version,rand_ff_patch)
##USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:136.0) Gecko/20100101 Firefox/136.0"
##USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0' #2025-06-19
##USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0' #2025-08-07
##USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0'

DEFAULT_HEADERS = {
    'User-Agent': USER_AGENT  
    
    #, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    #, 'Accept': '*.*;text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7'
##    , 'Accept': 'text/html,application/xhtml+xml,application/xml,image/jpeg,*.*;q=0.9'
    , 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' #2025-06-19
##    , 'verifypeer': 'false'
    , 'Accept-Encoding': 'gzip, deflate'
    , 'Accept-Language': 'en-US,en;q=0.5'
    , 'DNT': '1'
    , 'Sec-GPC': '1'
    , 'Connection': 'keep-alive'
    , 'Upgrade-Insecure-Requests': '1'
    , 'Sec-Fetch-Dest': 'document'
    , 'Sec-Fetch-Mode': 'navigate'
    , 'Sec-Fetch-Site': 'none'
    , 'Sec-Fetch-User': '?1'
    , 'Priority': 'u=0, i'
    
    }

if len(sys.argv) > 1: addon_handle = int(sys.argv[1])
else: addon_handle = -1

addon_id = str(this_addon.getAddonInfo('id'))
addon_name = this_addon.getAddonInfo('name')
addon = this_addon
dialog = xbmcgui.Dialog()
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = translatePath(rootDir)
resDir = os.path.join(rootDir, u'resources')
imgDir = os.path.join(resDir, u'images')

default_icon = translatePath(os.path.join(rootDir, 'icon.png'))

profileDir = addon.getAddonInfo('profile')
profileDir = translatePath(profileDir) #.decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')

refresh_text_color = addon.getSetting('refresh_text_color').lower()
search_text_color = addon.getSetting('search_text_color').lower()
time_text_color = addon.getSetting('time_text_color').lower()
highlight_text_color = addon.getSetting('highlight_text_color').lower()
program_text_color = addon.getSetting('program_text_color').lower()
test_text_color = addon.getSetting('test_text_color').lower()

tempory_name_filter = addon.getSetting('tempory_name_filter')

test_passed_text_color = "lightgreen"

icon_set = addon.getSetting('icon_set').lower()

#do this early so that it can be overriden later if necessary
maximum_video_resolution = int(addon.getSetting("maximum_video_resolution"))
minimum_scene_duration = 60*int(addon.getSetting("minimum_scene_duration"))
maximum_scene_duration = 60*int(addon.getSetting("maximum_scene_duration"))

DEFAULT_PLAYMODE = addon.getSetting('default_playmode').lower()  #allow playmode to be forced by input command, or use default from addon settings
PLAYMODE_F4MPROXY = 'f4mproxy'
PLAYMODE_INPUTSTREAM = 'inputstream'
PLAYMODE_DIRECT = '88888888'#'direct'
PLAYMODE_NO_OPTIONS = "NO_OPTIONS"
PLAYMODE_VARIABLE = 'VARIABLE_MAXRES'

PLAYMODE_PROFILE_00 = 'profile_00' #the download profile
PLAYMODE_PROFILE_01 = 'profile_01'
PLAYMODE_PROFILE_02 = 'profile_02'
PLAYMODE_PROFILE_03 = 'profile_03'
PLAYMODE_PROFILE_04 = 'profile_04'
PLAYMODE_PROFILE_05 = 'profile_05'
VALID_PLAYMODE_PROFILES = [PLAYMODE_PROFILE_00,PLAYMODE_PROFILE_01,PLAYMODE_PROFILE_02,PLAYMODE_PROFILE_03,PLAYMODE_PROFILE_04,PLAYMODE_PROFILE_05]

LIST_AREA_HENTAI = 'HENTAI'
LIST_AREA_CAMS = 'CAMS'
LIST_AREA_TUBES = 'TUBES'
LIST_AREA_MOVIES = 'movies'
LIST_AREA_SCENES = 'SCENES'

MAX_RECURSE_DEPTH = 10 #some sites will bann IP if too many requests

DEFAULT_RECURSE_DEPTH = min(MAX_RECURSE_DEPTH, int(addon.getSetting('recursive_search_depth')))
INBAND_RECURSE = 'inband_recurse'

refresh_icon   = os.path.join(imgDir, "library_update_{}.png".format(icon_set) )

category_icon  = os.path.join(imgDir, "category_{}.png".format(icon_set) )
downloads_icon   = os.path.join(imgDir, "downloads_{}.png".format(icon_set) )
favorites_icon   = os.path.join(imgDir, "favorites_{}.png".format(icon_set) )
hentai_icon   = os.path.join(imgDir, "movies_{}.png".format(icon_set) )
movies_icon   = os.path.join(imgDir, "movies_{}.png".format(icon_set) )
next_icon      = os.path.join(imgDir, "next_{}.png".format(icon_set) )
not_found_icon = os.path.join(imgDir, "search_{}.png".format(icon_set) )
scenes_icon   = os.path.join(imgDir, "movies_{}.png".format(icon_set) )
search_icon    = os.path.join(imgDir, "search_{}.png".format(icon_set) )
settings_icon   = os.path.join(imgDir, "settings_{}.png".format(icon_set) )
success_icon   = os.path.join(imgDir, "greeninch.png")
tubes_icon   = os.path.join(imgDir, "movies_{}.png".format(icon_set) )
webcams_icon   = os.path.join(imgDir, "webcams_{}.png".format(icon_set) )
warning_icon   = os.path.join(imgDir, "warning_{}.png".format(icon_set) )

if not os.path.exists(profileDir):
    os.makedirs(profileDir)

#https://kodi.wiki/view/Databases
texture_db_file_version = {
     '17':13  # Krypton
    ,'18':13  # Leia
    ,'19':13  # Matrix
    ,'20':13  # nexus
    ,'21':13  # omega
    ,'22':14  # piers
    ,'23':14  # unknown future version     
}

maria_db_userid = str(addon.getSetting(  "maria_db_userid"))
maria_db_password = str(addon.getSetting("maria_db_password"))
maria_db_server = str(addon.getSetting("maria_db_server"))
maria_db_port = int(addon.getSetting("maria_db_port"))

favoritesdb = os.path.join(profileDir, 'favorites.db')
#favoritesdb = 'kodi_favorites'
##favoritesdb = r"c:\temp\k\favorites.db"
favoritesdb = addon.getSetting("main_favorites_database")
##xbmc.log(favoritesdb,xbmc.LOGINFO)
if "/" in favoritesdb:
    favoritesdb = translatePath(favoritesdb)
    favoritesdb = os.path.join(favoritesdb,addon_id)
    favoritesdb = os.path.join(favoritesdb,"favorites.db")
##xbmc.log(favoritesdb,xbmc.LOGINFO)
##keywordsdb = favoritesdb
keywordsdb = os.path.join(profileDir, 'keywords.db')
downloads_db = favoritesdb
remote_favorite_db = str(addon.getSetting("remote_favorite_db_folder"))


NO_ACTION_MODE              = '0'
ROOT_INDEX_INDEX            = '0'
ROOT_INDEX_SCENES           = '1'
ROOT_INDEX_MOVIES           = '2'
ROOT_INDEX_HENTAI           = '3'
ROOT_INDEX_DOWNLOAD_FOLDER  = '4'
ROOT_TEST_ALL               = '5'
ROOT_INDEX_TUBES            = '6'
ROOT_INDEX_CAMS             = '7'
ROOT_SEARCH_ALL             = '8'
ROOT_SERVICE_UPDATE         = '9'
ROOT_SERVICE_SCAN_START     = '10'
REFRESH_IMAGES_MODE         = '11'
REFRESH_CONTAINER_MODE      = '12'
FAVORITES_MODE              = '13'
ROOT_INDEX_FAVORITES        = '14'
ADD_KEYWORD                 = '15' 
CLEAR_SEARCH                = '16'
DELETE_KEYWORD              = '17'
QWIK_SEARCH                 = '18'
ROOT_FRONT_PAGE             = '19'
ROOT_MANAGE_DOWNLOADS       = '20'
ROOT_STOP_DOWNLOAD          = '21'
ROOT_FAVTEST_ALL            = '22'

COPY_KODI_LOG               = '9114'
MARK_AS_WATCHED             = '9115'
FAVORITES_SYNC              = '9212'
FAVORITES_IMPORT            = '9213'
FAVORITES_BACKUP            = '9214'
REBUILD_NONCAM_THUMBS       = '9215'
REBUILD_CAM_THUMBS          = '9216'
PLAY_RANDOM_FAV             = '9217'


TIMESTAMP_REFERSH_FULL_SUCCESS = 'TIMESTAMP_REFERSH_FULL_SUCCESS'
TIMESTAMP_REFERSH_HIGHWATER = 'TIMESTAMP_REFERSH_HIGHWATER'
TIMESTAMP_REFERSH_SERVICE_ENABLE = 'TIMESTAMP_REFERSH_SERVICE_ENABLE'
REFRESH_TEXTURE_TIMESTAMP   = '9994'
CONFIGURE_FMPROXY           = '9995'
CLEAN_SIMPLECACHE           = '9996'
CLEAN_TEXTURES              = '9997'
CONFIGURE_THIS_ADDON        = '9998'
CONFIGURE_INPUTSTREAM       = '9999'


ONE_DAY_TIMESTAMP = 86400.0

##FLAG_RECURSE_NEXT_PAGES = '-1'
FLAG_USE_RESOLVER_ONLY = 'USE_RESOLVER_ONLY'

DEFAULT_NOTIFY_TIME = 2000

SPACING_FOR_TOPMOST = '' #chr(4)
SPACING_FOR_NAMES =  '' #chr(17)
SPACING_FOR_NEXT = '' #chr(127)

DEFAULT_PROFILE_NAME = 'profile_01'

DOWNLOAD_INDICATOR = addon_id+".downlading."


DO_NOTHING_URL = 'DO_NOTHING_URL' #url is required in the adddir function, but there are moments when I don't want to set it

GC_SEARCHLOOP_ITERATIONS = 2000
GC_SEARCHLOOP_PAUSE = 50


MIN_VALID_IMAGE_SIZE = 12500


STANDARD_MESSAGE_CATEGORY_LABEL = u"{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color, '{}')
STANDARD_MESSAGE_NO_VIDEO_FILE = u"Not found or deleted '{}' {}"
STANDARD_MESSAGE_NO_COUNTRY = u"Page {} is not available in your country"
STANDARD_MESSAGE_FAILED_SEARCH=u"[COLOR {}]failed search[/COLOR] on {} [error: {}]".format(highlight_text_color, '{}', '{}')
STANDARD_MESSAGE_CANCELLED_SEARCH=u"[COLOR {}]Search was Cancelled. Listing may be incompete[/COLOR]".format(highlight_text_color, )
STANDARD_MESSAGE_NEXT_PAGE = u"{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, search_text_color, '{}')
STANDARD_MESSAGE_NP_INFO = u"np_info not found in url='{}'"
STANDARD_MESSAGE_CATEGORIES = u"{}[COLOR {}]Categories[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_SEARCH = u"{}[COLOR {}]Search[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_SEARCH_RECURSIVE = u"{}[COLOR {}]Search Recursive[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color)
STANDARD_MESSAGE_REFRESH = u"{}[COLOR {}]Refresh[/COLOR]".format(SPACING_FOR_TOPMOST, refresh_text_color)
STANDARD_DURATION_REFRESH = 55*60*60+55*60+55  #a cool-looking size for this number

STANDARD_MESSAGE_UHD  = u" [COLOR {}]uhd[/COLOR]".format(search_text_color)
STANDARD_MESSAGE_FHD  = u" [COLOR {}]fhd[/COLOR]".format(refresh_text_color)
STANDARD_MESSAGE_HD   = u" [COLOR {}]hd[/COLOR]".format(time_text_color)
STANDARD_MESSAGE_NOHD = ""

VIDEO_NOT_AVAILABLE_WARNINGS = [
    "This video has been flagged for verification"
    ,"This page is not available in your country."
    ,"Video has been removed at the request of "
    ,"Video has been flagged"
    ,"this video is no longer available"
    ,"This Video Is Private"
    ,"this video is private."
    ,"This video does not exist."
    ,"File has been removed due to copyright owner request"
    ]

channel_text_color = this_addon.getSetting('channel_text_color')
program_text_color = this_addon.getSetting('program_text_color')


FAVORITE_LISTING_TIMEOUT = 20 #seconds #how long to wait to discover if webcam model is online

WEBCRAWLER_THREAD_TIMEOUT = 10
MAX_WEBCRAWLER_THREADS = 60


TYPE_hls = 'hls'
TYPE_mp4 = 'mp4'
DOWNLOAD_TYPES = (TYPE_hls, TYPE_mp4)

    
TESTING_LIST_NAME = 'test_list' #setting.xml key containing which sites we have 'tested' and when they 'tested' successfully
#either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
# https://wiki.mozilla.org/CA/Included_Certificates
##if C.DEBUG: urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
#certPath = os.path.join(os.path.join(os.path.dirname(__file__), "websocket"),"cacert.2020-10-14.pem")
certPath = certifi.where()

### https://kodi.wiki/view/Databases
xbmc_version = xbmc.getInfoLabel('System.BuildVersion').split(' ')[0].split('.')
try:
    x2 = [] #deal with beta versions
    for x in xbmc_version:
        try:
            x2.append(int(x))
        except:
            x2.append(x)
    xbmc_version = x2
    #xbmc_version = [int(x) for x in xbmc_version]
except:
##    raise
    pass

TEXTURE_DB_VERSION = texture_db_file_version[str(xbmc_version[0])]

#todo change - version number may change
viewDB = translatePath("special://database/ViewModes6.db")
texture_DB_filespec = "special://database/Textures{}.db".format(texture_db_file_version[str(xbmc_version[0])])
texture_DB_filespec = translatePath(texture_DB_filespec)

def module_name():
    return sys._getframe(1).f_code.co_name

try: default_GETHTML_cache_duration = int(addon.getSetting("GETHTML_cache_duration"))
except: default_GETHTML_cache_duration = 300 #seconds
try: default_ISONLINE_cache_duration = int(addon.getSetting("ISONLINE_cache_duration"))
except: default_ISONLINE_cache_duration = 77 #seconds

DEFAULT_IS_ONLINE_SERVER_NAME = '8.8.8.8'
DEFAULT_IS_ONLINE_SERVER_PORT = '443'

SERVICE_FIRST_SLEEPTIME = 10 #seconds before service begins; long enough for other stuff to start

FILE_MANIPULATION_ATTEMPTS = 3
TIME_BEFORE_FILE_MANIPULATION = 1000 #milliseconds



# Note: xbmcplugin.SORT_METHOD_DURATION  and "SortUtils.h".SortByTime values are different
VIEW_LIST = 50
VIEW_INFOWALL = 51
VIEW_THUMBNAIL = 52
VIEW_INFOWIDE = 61

try: INITIAL_SORTMETHOD = addon.getSetting("initial_sortmethod")
except: INITIAL_SORTMETHOD = 9 #9=sort by time/duration
if INITIAL_SORTMETHOD == "": INITIAL_SORTMETHOD = 9
try: INITIAL_VIEWMODE = addon.getSetting("initial_viewmode")
except: INITIAL_VIEWMODE = VIEW_THUMBNAIL
if INITIAL_VIEWMODE == "": INITIAL_VIEWMODE = VIEW_INFOWALL


MODE_LIST_OFFSET = 1
MODE_PLAY_OFFSET = 2
MODE_CATEGORY_OFFSET = 3
MODE_SEARCH_OFFSET = 4
MODE_TEST_OFFSET = 5
MODE_ICON_OFFSET = 6
MODE_REFRESH_OFFSET = 7
MODE_CLEANDATABASE_OFFSET = 8

## keep all the MAIN_MODE for all the sites we support so that we know what is in use
# spaced 10 apart because [so far] at most most 5 items needed
MAIN_MODE_base_website     = '40'  #dev testing
MAIN_MODE_porntrex         = '50'
MAIN_MODE_porn00           = '60'
MAIN_MODE_pornhive         = '70'
MAIN_MODE_beeg             = '80'
MAIN_MODE_bubbaporn        = '90'
MAIN_MODE_poldertube       = '100'
MAIN_MODE_sextube          = '110'
MAIN_MODE_hentaidude       = '120'
MAIN_MODE_speedporn        = '130'
MAIN_MODE_perfectgirls     = '140'
MAIN_MODE_hqporner         = '150'
MAIN_MODE_viralvideosporno = '160'
MAIN_MODE_streamxxx        = '170'
MAIN_MODE_cartoonpornvideos= '180'
MAIN_MODE_freeomovie       = '190'
MAIN_MODE_chaturbate       = '220'
MAIN_MODE_myfreecams       = '270'
MAIN_MODE_paradisehill     = '250'
MAIN_MODE_vipporns         = '260'
MAIN_MODE_cam4             = '280'
MAIN_MODE_porndig          = '290'
MAIN_MODE_absoluporn       = '300'
MAIN_MODE_anybunny         = '320'
MAIN_MODE_tubepornclassic  = '360'
MAIN_MODE_hclips           = '380'
MAIN_MODE_pornhub          = '390'
MAIN_MODE_mrsexe           = '400'
MAIN_MODE_xxxstreamsEU     = '410'
MAIN_MODE_xxxstreamsORG    = '420'
MAIN_MODE_spankbang        = '430'
MAIN_MODE_hentaihaven      = '460'
MAIN_MODE_xhamster         = '470'
MAIN_MODE_naked            = '480'
MAIN_MODE_amateurcool      = '490'
MAIN_MODE_pornone          = '500'
MAIN_MODE_tube8            = '510'
MAIN_MODE_xvideos          = '520'
MAIN_MODE_streamate        = '530'
MAIN_MODE_pornhd           = '540'
MAIN_MODE_pornoxo          = '550'
MAIN_MODE_pornmaki         = '560'
MAIN_MODE_pornburst        = '570'
MAIN_MODE_moviefap         = '580'
MAIN_MODE_empflix          = '590'
MAIN_MODE_bongacams        = '600'
MAIN_MODE_daftsex          = '610'
MAIN_MODE_faapy            = '620'
MAIN_MODE_girlfriendvideos = '630'
MAIN_MODE_motherless       = '650'
MAIN_MODE_bitporno         = '660'
MAIN_MODE_redtube          = '670'
MAIN_MODE_sunporno         = '680'
MAIN_MODE_youporn          = '700'
MAIN_MODE_ah_me            = '740'
MAIN_MODE_eporner          = '750'
MAIN_MODE_pornomovies      = '760'
MAIN_MODE_tukif            = '770'
MAIN_MODE_txxx             = '790'
MAIN_MODE_peekvids         = '800'
MAIN_MODE_animeidhentai    = '810'
MAIN_MODE_watchporn        = '820'
MAIN_MODE_fpoxxx           = '950'
MAIN_MODE_javguru          = '960'
MAIN_MODE_hdpornz          = '970'
MAIN_MODE_vjav             = '980'

