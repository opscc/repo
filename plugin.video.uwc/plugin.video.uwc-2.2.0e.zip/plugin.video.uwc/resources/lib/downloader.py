#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import datetime
import json
import os
import tempfile
import threading
import time
import traceback
import sqlite3 #for exception
import sys
import urllib
import xbmc
import xbmcvfs
import xbmcgui
import _strptime #because https://www.raspberrypi.org/forums/viewtopic.php?t=166912

from fav_dbconn import generic_favdbconn

import constants as C
from constants import urlparse

import thread_cache

import utils
from utils import Log,LogR,Sleep
from utils import get_setting as GetSetting
from utils import Normalize_Filespec

monitor = xbmc.Monitor()
       
#downloads_db = "" #works
#downloads_db = ":memory:" #works
#downloads_db = "file::memory:?cache=shared" #fail
##downloads_db = C.favoritesdb
##downloads_conn = sqlite3.connect(downloads_db, check_same_thread=False)    


#__________________________________________________________________________
#
CMD_list ='list'
CMD_cancel = 'cancel'
CMD_download = 'download'
WEB_COMMANDS = (CMD_list,CMD_cancel,CMD_download)

ATTRIB_cmd = "command"
ATTRIB_type = 'type'
ATTRIB_name = 'name'
ATTRIB_mode = 'mode'
ATTRIB_url = 'url'
ATTRIB_url_factory = 'url_factory'
ATTRIB_path = 'download_path'
ATTRIB_repeat = 'repeat_when_available'
ATTRIB_icon_uri = 'icon_URI'
ATTRIB_mimetype = 'mimetype'
ATTRIB_skip_head = 'skip_head'

ATTRIB_return_code = 'rc'
ATTRIB_message = 'message'

SUCCESS = 0
NOT_ACTIVE = 1

DOWNLOAD_ATTRIBUTES = (
    ATTRIB_cmd
    ,ATTRIB_type
    ,ATTRIB_name
    ,ATTRIB_mode
    ,ATTRIB_url
    ,ATTRIB_url_factory
    ,ATTRIB_path
    ,ATTRIB_repeat
    ,ATTRIB_icon_uri
    ,ATTRIB_mimetype
    ,ATTRIB_skip_head
)

#__________________________________________________________________________
#
def downloadVideo(
    url
    , name
    , mode
    , url_factory
    , icon_URI
    , mimetype
    , download_path=''
    , skip_head=False
    , repeat_when_available=False
    ):

    LogR(
        (C.module_name(),locals())
##        ,C.LOGWARNING
        )

    name = utils.Clean_Filename(name)

    if repeat_when_available:
        if GetSetting("enable_download_service", bool):  
            add_download_result = add_download(
                name = name
                , url = url
                , file_spec=download_path
                , expected_size=None
                , friendly_name = name
                , mode = mode
                , url_factory = url_factory
                , icon_URI = icon_URI
                )
        else:
            Log('download directly')
    else:
        Log('not a repeating donload')

    d_type = None
    attempt_count = 0
    max_attempt_count = 2

    try:

##        Log(' warning ')
        while (not d_type) and (attempt_count < max_attempt_count) :
            attempt_count += 1

            if url and ('|' in url):
                h=dict(urlparse.parse_qsl( str(url.split('|')[1])))
                u=str(url.split('|')[0])
            else:
                h={}
                u=url

            LogR(u)
            LogR(h) 
            if not(skip_head) and u and ( u.startswith('https') ):
                Log("not(skip_head) and u and ( u.startswith('https') )")
                resp = redirected_url = None
                try:
                    resp, redirected_url = utils.getHtml(
                        url=u
                        , headers=h
                        , send_back_response=True
                        , send_back_redirect=True
                        , method="HEAD"
                        , cache_duration=-1
                        )
                except:
                    Log('HEAD failed')
                    pass
                if resp:
                    if redirected_url:
                        if not (u == redirected_url):
                            resp, redirected_url = utils.getHtml(url=u, headers=h, send_back_response=True, send_back_redirect=True, method="HEAD", cache_duration=-1)
                            url = redirected_url + utils.Header2pipestring(h)

                    if 'Content-Type' in resp.headers:
                        c_type = resp.headers['Content-Type'].lower()
                        if c_type in [
                            'video/mp4'
                            , 'application/octet-stream'
                            , 'video/mp4, application/octet-stream'
                            , 'binary/octet-stream'
                            ]:
                            
                            d_type = C.TYPE_mp4
                            if not mimetype: mimetype = c_type
                            Log('error 3.1')
                            continue
                        elif c_type in [
                            'application/vnd.apple.mpegurl'
                            ,'application/x-mpegurl'
                            ,'text/plain;charset=utf-8'
                            ,'text/html; charset=utf-8'
                            
                            ]:
                            d_type = C.TYPE_hls
                            if not mimetype: mimetype = c_type
                            continue
                        else:
                            Log("warning: unhandled content type {}".format(repr(c_type)))
            else: ###if not(skip_head) and u and ('http' in u):
                Log(u"Skip HEAD specified  or HTTP not in url".format(
                    repr(name), repr(url))
##                    ,C.LOGWARNING
                    )
                if mimetype in [
                    'video/mp4'
                    , 'application/octet-stream'
                    , 'video/mp4, application/octet-stream'
                    , 'binary/octet-stream'
                    ]:
                    
                    d_type = C.TYPE_mp4
                    if not mimetype: mimetype = c_type
                    Log('error 3.1')
##                    continue
                elif mimetype in [
                    'application/vnd.apple.mpegurl'
                    ,'application/x-mpegurl'
                    ,'text/plain;charset=utf-8'
                    ,'text/html; charset=utf-8'
                    
                    ]:
                    d_type = C.TYPE_hls
                    if not mimetype: mimetype = c_type
##                    continue
                else:
                    Log("warning: unhandled content type {}".format(repr(mimetype)))

##            Log('error 3')
            if d_type:
                Log(d_type)
##                continue

            if url_factory:

                #2025-11-18
                # removed due to an infinite recurstion bug
                #   pontrex failing to return valid headers
                Log(u"find url via mode {} and information url_factory {}".format(
                        repr(mode),repr(url)
                    )
                )
            
                queries = {
                    'url' : url_factory,
                    'name' : name,
                    'download': '1',
                    'img' : icon_URI,
                    'testmode' : True,
                    mimetype : mimetype,
                    skip_head : skip_head,
                    }
                #dispatch to the site-specific code that should then
                #   return a url
                return_code = C.url_dispatcher.dispatch(str(mode), queries)
                Log("urlfactory has a return code\n{}".format(repr(return_code)))
                if return_code and return_code.startswith('http'):
                    url = return_code
                else:
                    url = ''
                raise StopLoop("urlfactory has a return code {}".format(repr(url)))
            
##                attempt_count = max_attempt_count + 1

        if (attempt_count > max_attempt_count):
            Log('too many failed attempts', C.LOGWARNING)
            attempt_count = max_attempt_count + 1

    except StopLoop as ex:
        Log(ex.value, C.LOGINFO)
    except Exception as ex:
        LogR(ex, C.LOGERROR)
        #traceback.print_exc()
        raise

    LogR((d_type,url,mimetype))
    if (not d_type) and url:
        hls_download = any(x in url for x in ['.m3u8', '/hls/', 'hlsA' ])
        if hls_download:
            d_type = C.TYPE_hls
        else:
            d_type = C.TYPE_mp4

    if '/v1/edge/streams/origin' in url:
        ext = '.m4v'
    else:
        ext = '.ts'
            
    if (not download_path) and url_factory:
        Log('#create daily name for likely webcam')
        download_path = Make_download_path(
            name = name
            , include_date = True
            , file_extension = ext
            )
    elif (not download_path):
        if d_type is C.TYPE_hls:
            download_path = Make_download_path(
                name = name
                , file_extension = ext
                )
        elif d_type is C.TYPE_mp4:
            download_path = Make_download_path(
                name = name
                , file_extension = '.mp4'
                )
        else:
            download_path = Make_download_path(
                name = name
                )
            
    LogR((d_type,mimetype,url,))
    if mimetype: skip_head = True
    
    if GetSetting("enable_download_service", bool):
        Log('enable_download_service is True')
        sent_data = json.dumps({
                          ATTRIB_cmd: CMD_download
                           ,ATTRIB_type: d_type
                           ,ATTRIB_name: name
                           ,ATTRIB_url: url
                           ,ATTRIB_path: download_path
                           ,ATTRIB_repeat: repeat_when_available
                           ,ATTRIB_url_factory: url_factory
                           ,ATTRIB_icon_uri: icon_URI
                           ,ATTRIB_mode : mode
                           ,ATTRIB_mimetype : mimetype
                           ,ATTRIB_skip_head : skip_head
                           })
        utils.postHtml(
            "http://localhost:{}/".format(GetSetting("download_server_port_current", int))
            , sent_data=sent_data
            , headers={'Content-Type': 'application/json'}
            , cache_duration=-1
            , http_timeout=1
        )

        utils.Notify(u"Downloading '{}' in background".format(name))
    else:
        Log('enable_download_service is False')
        if d_type is C.TYPE_hls:
            Background_HLSDownloader(
                url = url
                 , download_path = download_path
                 , name = name
                 , stop_event = None
                 , repeat_when_available = repeat_when_available
                 , rowid = None
                 , url_factory = None
                 , mode = None
                )
            utils.Notify(u"Downloading '{}' in foreground".format(name))
        if d_type is C.TYPE_mp4:
            Background_MP4Downloader(
                url = url
                , name = name
                , url_factory = url_factory
                , mode = mode
                , icon_URI = icon_URI
                , download_path = download_path
                , stop_event = threading.Event()
                , rowid = None
                )
            utils.Notify(u"Downloading '{}' in foreground".format(name))

    Log('exiting downloadVideo')
    return True
#_______________________________________________________________________________
#
@C.url_dispatcher.register(
    C.ROOT_STOP_DOWNLOAD,
    ['url','name'],
    ['refresh_container','rowid','desc','hq_stream'],
    )
def Stop_Download(url,name,refresh_container=True,rowid=None,desc=None,hq_stream=None):

    LogR(
        (C.module_name(),locals()),
##        ,C.LOGWARNING
        )

    if desc:
        name = utils.try_decode(desc,'utf8')
    else:
        name = utils.try_decode(name,'utf8')
        name = utils.Clean_Filename(name,delete_first_color=True).strip("'")

    progress_dialog = None
    stop_name = None
    obj = None
    try:
        if refresh_container == True:
            progress_dialog = utils.Progress_Dialog(C.addon_name,u"stopping '{}'".format(name))

        if hq_stream:
            delete_download(url, rowid=hq_stream)
            utils.Notify(u"Stopped scheduled '{}'".format(name))
        else:
            if GetSetting("enable_download_service", bool):
                stop_result = utils.postHtml(
                    "http://localhost:{}/".format(GetSetting("download_server_port_current", int))
                    ,sent_data= json.dumps({
                                ATTRIB_cmd: CMD_cancel
                               ,ATTRIB_name: name
                               })
                           ,headers={
                               'Content-Type': 'application/json'
                               }
                           , cache_duration=-1
                           , http_timeout=1
                           )
                
                try:
                    if not stop_result: stop_result = "[]"
                    stop_result = json.loads(stop_result)
                    if ATTRIB_return_code in stop_result and stop_result[ATTRIB_return_code] == SUCCESS:
                        utils.Notify(stop_result[ATTRIB_message])
                    elif ATTRIB_return_code in stop_result and stop_result[ATTRIB_return_code] == NOT_ACTIVE:
                        pass
                    else:
                        utils.Notify(u"Unknown error stopping '{}'".format(name))
                except Exception as ex:
                    LogR(ex, C.LOGERROR)
                    LogR(stop_result)


    finally:
        if progress_dialog: progress_dialog.close()
    Log("Stop_Download end '{}'".format(url))

    if refresh_container == True:
        Log("Container.Refresh")
        xbmc.executebuiltin("Container.Refresh")
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_MANAGE_DOWNLOADS)
def Manage_Downloads():
    Log("Manage_Downloads start")

    one_instance_found = False
    progress_dialog_message = "Listing background tasks"
    progress_dialog = utils.Progress_Dialog(title=C.addon_name, message=progress_dialog_message)

    try:

        utils.addDir(
            name = '[COLOR {}]Look for Scheduled Downloads to Start[/COLOR]'.format(C.highlight_text_color)
             ,url = C.DO_NOTHING_URL
             ,mode = C.ROOT_SERVICE_SCAN_START
             ,Folder = False)
        
        for scheduled_download in scheduled_downloads():
##            Log(repr(scheduled_download))
##            Log(repr(dir(scheduled_download)))
##            Log(repr(scheduled_download.keys()))
            name = scheduled_download['name']
            url  = scheduled_download[ATTRIB_url]
            rowid = scheduled_download['id']
            icon_URI = scheduled_download[ATTRIB_icon_uri]
            desc = scheduled_download[ATTRIB_name] #pass info here so formatting cleanup not required
            one_instance_found = True

            name = u"[COLOR {}]Stop scheduled[/COLOR] '{}'".format(
                C.search_text_color
                #, name[len(C.DOWNLOAD_INDICATOR):]
                , name.replace(C.DOWNLOAD_INDICATOR,'')
                )
            #using adddir adds error message to log; shows 'busy' indicator
            #using addownlink has right click menu; manually have to show 'busy' indicator        
            utils.addDownLink(
                name = name
                , url = url
                , mode = C.ROOT_STOP_DOWNLOAD
                , play_method = C.PLAYMODE_NO_OPTIONS
                , iconimage = str(icon_URI)
                , desc = desc
                , hq_stream = rowid  #pass info here too lazy to add other fields names
                )
    except:
        traceback.print_exc()
        utils.addDownLink(
            name = "Fatal error listing scheduled downloads"
            , url=C.DO_NOTHING_URL
            , mode = C.NO_ACTION_MODE
            )

    try:
        active_threads = None
        if GetSetting("enable_download_service", bool):    
            active_threads = utils.postHtml("http://localhost:{}/".format(GetSetting("download_server_port_current", int))
                       ,sent_data= json.dumps({
                          ATTRIB_cmd: CMD_list
                           })
                       ,headers={
                           'Content-Type': 'application/json'
                           }
                       , cache_duration=-1
                       , http_timeout=1
                       )
        if not active_threads: active_threads = "[]"
        active_threads = json.loads(active_threads)
        for active_download in active_threads:
            active_download = json.loads(active_download)
            one_instance_found = True
            
            name = u"[COLOR {}]Stop current[/COLOR] '{}'".format(
                C.program_text_color
                , active_download[ATTRIB_name]
                )
            utils.addDownLink(
                name = name
                , url = 'fake'
                , mode = C.ROOT_STOP_DOWNLOAD
                , play_method = C.PLAYMODE_NO_OPTIONS
                , iconimage = str(active_download[ATTRIB_icon_uri])
                , desc = active_download[ATTRIB_name] #pass info here so formatting cleanup not required
                )
    except:
        traceback.print_exc()
        utils.addDownLink(
            name = "Fatal error listing threads"
            , url=C.DO_NOTHING_URL
            , mode = C.NO_ACTION_MODE
            )

    if one_instance_found == False:
        utils.addDir(
            name="Nothing downloading in background"
            , url=C.DO_NOTHING_URL
            , mode=C.ROOT_INDEX_INDEX
            )
    if progress_dialog: progress_dialog.close()

    Log("Manage_Downloads end")
    utils.endOfDirectory(
        cacheToDisc=False,
        )

def active_downloads():
    return Manage_Downloads()
#__________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_SERVICE_SCAN_START)  
def Scan_And_Start_DB():
    LogR(
        (C.module_name(),locals()),
##        C.LOGINFO,
        )
    Log("warning todo move query")
    #only starts if there is a camlist table
    #look at downloads table for records that are marked as persistent dowload
    #scan camlist table on matching mode + modelid
    sql_command = '''
SELECT
    downloads.*
    , camlist.video_url as cur_url
FROM
    downloads
INNER JOIN
    camlist on
        camlist.mode = downloads.mode 
        and
        camlist.modelid = downloads.modelid;
'''
##    Log("sql_command='{}'".format(sql_command))

    active_threads = None
    if GetSetting("enable_download_service", bool):    
        active_threads = utils.postHtml(
            "http://localhost:{}/".format(GetSetting("download_server_port_current", int))
            , sent_data= json.dumps({ATTRIB_cmd: CMD_list})
            , headers={'Content-Type': 'application/json'}
            , cache_duration=-1
            , http_timeout=1
        )
    else:
        Log('enable_download_service is false')
        
    if not active_threads: active_threads = "[]"
    active_threads = json.loads(active_threads)
            
    downloads_conn = generic_favdbconn(C.downloads_db)
    scheduled_downloads = downloads_conn.execute(sql_command)
    
    for scheduled_download in scheduled_downloads.fetchall():

        LogR(dict(scheduled_download))

        active = False
        name = scheduled_download['name']
        modelID = scheduled_download['modelID']
        url_factory  = scheduled_download[ATTRIB_url_factory]
        url  = scheduled_download[ATTRIB_url]
        mode = scheduled_download['mode']
        icon_URI = scheduled_download[ATTRIB_icon_uri]
        mimetype = None #scheduled_download[ATTRIB_mimetype]
        rowid = scheduled_download['id'] #note: sqlite3 ROWID was _not_ used because it seems to be recycled

        for active_download in active_threads:
            active_download = json.loads(active_download)
            active_name = active_download[ATTRIB_name]
            if name == active_name:
                active = True
                Log(u"active thread already exists for {}".format(repr(name)))
                break

        if url_factory:
            downloadVideo(
                url=url
                , name=name
                , mode=mode
                , url_factory=url_factory
                , icon_URI=icon_URI
                , repeat_when_available=False
                , mimetype=mimetype
                )
        else:
            downloadVideo(
                url=url
                , name=name
                , mode=mode
                , url_factory=None
                , icon_URI=icon_URI
                , repeat_when_available=False
                , mimetype=mimetype
                )

    Log("end Scan_And_Start_DB")
    if (threading.current_thread().name == "MainThread"):
        Log("Container.Refresh",C.LOGWARNING)
        xbmc.executebuiltin("Container.Refresh")
#__________________________________________________________________________
#
class StopDownloading(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)

#__________________________________________________________________________
#
class StopLoop(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)


#__________________________________________________________________________
#
def Make_download_path(name = u''
                       , include_date = False
                       , file_extension = u''
                       , folder=None
                       , multiple_per_day=True):
    Log(u"Make_download_path name='{}'".format(name)
##        ,C.LOGNONE
        )
    
    name = utils.Clean_Filename(name)
   
    if folder is None:
        download_folder = GetSetting("download_path")
        if download_folder:
            if not isinstance(download_folder, str):
                download_folder = str(msg,'utf8','ignore')
        Log(u"Make_download_path download_path='{}'".format(repr(download_folder)))
        if download_folder in ['','None',u'',u'None',None]:
            try:
                download_folder = xbmcgui.Dialog().browse(0, "Specify a folder to save Downloads", 'myprograms', '', False, False)
                C.addon.setSetting(id='download_path', value=download_folder)
                if not os.path.exists(download_folder): os.mkdir(download_folder)
            except:
                raise
    else:
        download_folder = folder

    if include_date:
        date_string = datetime.datetime.now().strftime(".%Y-%m-%d")
    else:
        date_string = ""

    download_path = None
    if multiple_per_day and name:
        append = ''
        probe_filespec = download_folder + name + date_string + append + file_extension
        if not os.path.exists(probe_filespec):
            download_path = probe_filespec
        else:
            for append in range(ord('a'),ord('z')):
                append = chr(append)
                probe_filespec = download_folder + name + date_string + append + file_extension
                if not os.path.exists(probe_filespec):
                    download_path = probe_filespec
                    break
        if not download_path: raise Exception(u"can't generate unique name for {}".format(probe_filespec))
    else:
        download_path = download_folder + name + file_extension
    
    Log(u"Make_download_path download_path='{}'".format(download_path)
##        ,C.LOGNONE
        )
##    raise Exception()
    return download_path
#__________________________________________________________________________
#
def _progress_bar_hook(downloaded, filesize, start, name=None, progress_dialog=None):

    try:
        
        if C.PY3: percent = min((downloaded*100)//filesize, 100)
        if C.PY2: percent = min((downloaded*100)/filesize, 100)
        if C.PY2: currently_downloaded = float(downloaded) / (1024 * 1024)
        if C.PY3: currently_downloaded = float(downloaded) // (1024 * 1024)
        kbps_speed = int(downloaded // (time.time() - start))

        if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
        else:               eta = 0


        if C.PY3: kbps_speed = kbps_speed // 1024
        if C.PY2: kbps_speed = kbps_speed / 1024
        if C.PY3: total = float(filesize) // (1024 * 1024)
        if C.PY2: total = float(filesize) / (1024 * 1024)
        mbs = u"[{:20}]".format(name)
        mbs += u' %.00f MB/%.00f MB' % (currently_downloaded, total)
        e = ' %.0fKbps' % kbps_speed
        e += ' ETA:%01d' % (eta // 60)
        Log(repr((percent,'',mbs + e)))
        progress_dialog.update(percent,'',mbs + e)

##        try:
##            update_download(C.DOWNLOAD_INDICATOR+name, 'current_size', str(currently_downloaded))
##            update_download(C.DOWNLOAD_INDICATOR+name, 'current_data_rate', str(kbps_speed))
##            update_download(C.DOWNLOAD_INDICATOR+name, 'expected_end_time',   )
##        except:
##            traceback.print_exc()
##            pass

    except:
        traceback.print_exc()
        percent = 100
        progress_dialog.update(percent)
        progress_dialog.close()


###__________________________________________________________________
###
def Size_Filespec(filespec):
    size = 1
    try:
        size = os.stat(filespec).st_size
##        Log(repr(size))
        size =  os.path.getsize(filespec)
##        Log(repr(size))
    except:
##        traceback.print_exc()
        pass
    return size
###__________________________________________________________________
###
def Delete_File(filespec):
#    traceback.print_stack()
    try:
        Log("deleting filespec='{}'".format(filespec))
        delete_attempt = 0
        while os.path.exists(filespec) and delete_attempt <= C.FILE_MANIPULATION_ATTEMPTS:
            delete_attempt += 1
            Sleep(C.TIME_BEFORE_FILE_MANIPULATION)
            try:
                os.remove(filespec)
            except:
                if delete_attempt == C.FILE_MANIPULATION_ATTEMPTS:
                    traceback.print_exc()
                pass
        else:
            if not os.path.exists(filespec):
                Log("{} deleted".format(repr(filespec).replace('\\\\', '\\')))
                    
    except:
        traceback.print_exc()
#__________________________________________________________________________
#
def doDownload(url, dest, progress_dialog, name, stop_event):

    start = time.time()

    try:
        
        #url may have include headers to be passed during transaction
        headers = dict('')
        try:
            if '|' in url:
                headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
        except:
            traceback.print_exc()

        url = url.split('|')[0]
        file = dest.rsplit(os.sep, 1)[-1]

        resp = utils.getHtml(
            url
            , headers=headers
            , send_back_response=True
            , method="HEAD"
            , size=0
##            , http_timeout = 120
            )
        
        if not resp:
            utils.Notify(u"Download failed: '{}'".format(url))
            return False

        try:
            if 'Content-Length' in resp.headers:
                content = int(resp.headers['Content-Length'])
            else:
                content = 0
            Log(u"Expected file size {:,} bytes for '{}'".format(content, name))
##            update_download(C.DOWNLOAD_INDICATOR+name, 'expected_size', str(content / (1024 * 1024)))
        except:
            content = 0
            traceback.print_exc()

        try:
            resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
        except:
            resumable = False
        if resumable: Log("Download is resumable: {}".format(url))

        if content < 1:
            utils.Notify(u"Unknown filesize: '{}'".format(url))
            content = 1024*1024*1024

        size = 8192*4
        if C.PY3: mb   = content // (1024 * 1024)
        if C.PY2: mb   = content / (1024 * 1024)
        if content < size:
            size = content

        total   = 0
        errors  = 0
        count   = 0
        resume  = 0
        sleep   = 0

        Log(u'Download File Size will be  : %dMB %s %s' % (mb, dest, name))
##        Log(repr(xbmc.makeLegalFilename(dest)))
##        f = xbmcvfs.File(xbmc.makeLegalFilename(dest), 'w')
##        f = xbmcvfs.File(dest, 'w')

        import io
        f = io.open(dest, 'w+b')
        chunk  = None
        chunks = []
        loop_interruptor = 0

        resp = utils.getHtml(
            url
            , headers=headers
            , send_back_response=True
            , preload_content=False
            , start_point=total
            , size=size
##                        , http_timeout = 120
            )
                    
        while True:

            # kill the download if kodi monitor tells us to
            if monitor.waitForAbort(0.1):
                Log("shutting down '{}' download thread for '{}'".format(
                    C.addon_id,url
                    )
                    , C.LOGERROR
                    )
                break

            if stop_event.is_set() == True:
                Log("stop_event.isSet()")
                break
            
            downloaded = total
            for c in chunks:
                downloaded += len(c)
            percent = min(100 * downloaded / content, 100)


            loop_interruptor += 13 #13 x 8192 is aprox 0.1mb
            if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS:
                loop_interruptor = 0
                _progress_bar_hook(downloaded,content,start,name,progress_dialog)

            if progress_dialog and hasattr(progress_dialog, 'progress_dialog') and progress_dialog.iscanceled():
                raise Exception('cancelled')
                
            chunk = None
            error = False

            try:
                chunk  = None
                chunk  = resp.read(size)
##                chunk  = resp.stream(size)
                if chunk:
##                    Log(repr((size,len(chunk))))
                    f.write(chunk)
                    total += len(chunk)
                    chunk  = None
                else:
                    if percent < 99:
                        error = True
                        pass
                    else:
##                        Log(repr(len(chunks)))
##                        while len(chunks) > 0:
##                            c = chunks.pop(0)
##                            f.write(c)
##                            del c

                        f.close()
                        Log( u'download complete'.format(dest))
                        return True

            except Exception as e:
                error = True
                sleep = 3
                errno = 0
                if hasattr(e, 'errno'):
                    errno = e.errno
                LogR((downloaded,size,errno,url), C.LOGERROR)                    
            
                if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                    pass
                if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                    errors = 10 #force resume
                    sleep  = 10
                if errno == 11001: # 'getaddrinfo failed'
                    errors = 10 #force resume
                    sleep  = 10

            if chunk:
                errors = 0
                chunks.append(chunk)
##                LogR(((size,len(chunk))))
                MIN_CHUNKS_TO_FLUSH_WRITE = 5
##                MIN_CHUNKS_TO_FLUSH_WRITE = 0
                if len(chunks) > MIN_CHUNKS_TO_FLUSH_WRITE:
                    c = chunks.pop(0)
                    f.write(c)
                    total += len(c)
                    del c

            if error:
                errors += 1
                count  += 1
                LogR('sleeping {} seconds due to error'.format(sleep))
                utils.Sleep(max(100,sleep)*1000)
                if progress_dialog and hasattr(progress_dialog, 'progress_dialog') and progress_dialog.iscanceled():
                    raise Exception('errors')
            

            if (resumable and (resume > 10)) or (errors >= 50) :
                if (not resumable and (resume > 10)  ) or resume >= 10:
                    #Give up!
                    Log(
                        "'{}' download canceled - too many error while downloading".format(
                        dest
                        )
                        )
                    f.close()
                    return False

                resume += 1
                errors  = 0

                if resumable:
                    chunks  = []
                    #create new response
                    Log ('Download resumed attempt #(%d) %s' % (resume, dest) )
                    resp = utils.getHtml(
                        url
                        , headers=headers
                        , send_back_response=True
                        , preload_content=False
                        , start_point=total
                        , size=size
##                        , http_timeout = 120
                        )
                    Log ('Download 2 resumed (%d) %s' % (resume, dest) )
                else:
                    #use existing response
                    pass

    except:
        traceback.print_exc()
        raise
    finally:
        try:
            if resp:
                resp.release_conn()
                resp.close()
        except:
            pass

#__________________________________________________________________________
#
class MP4Downloader(object):
    def __init__(
        self
        , name
        , stop_playing_event
        , download_path
        , url
        ):
        self.name = name
        self.stop_playing_event = stop_playing_event
        self.download_path = download_path
        self.url = url

    def keep_sending_video( self ) :

        url = self.url
        dest = self.download_path
        name = self.name
        stop_playing_event = self.stop_playing_event

        url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on

        name = utils.Clean_Filename(name)
        bare_path = Make_download_path() #I want to start with download loacation before crating subfolders
            
        folder = self.download_path[0 : len(dest) - len(dest.rsplit(os.sep, 1)[-1]) ]
        download_path = Make_download_path(folder=folder) #now create the rest
        progress_dialog = xbmcgui.DialogProgressBG()
        progress_dialog.create(C.addon_name,name[:50])

        
        tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
        tmp_file = C.makeLegalFilename(tmp_file)
        start = time.time()
        downloaded = None
        vidfile = ""
        try:
            Log("url='{}'".format(url))
            downloaded = doDownload(url, tmp_file, progress_dialog, name, stop_playing_event)
            if downloaded:
                Log(u"Clean_Filename(name)='{}'".format(utils.Clean_Filename(name,include_square_braces=False)))
                vidfile = download_path + utils.Clean_Filename(name, include_square_braces=False)
                if not vidfile.endswith(u".mp4"):
                    vidfile +=u".mp4"
                LogR(vidfile)
                try:
                    os.rename(Normalize_Filespec(tmp_file), Normalize_Filespec(vidfile))
                    return vidfile
                except Exception as e:
                    #todo:   OSError: [Errno 36] File name too long:
                    
                    try:
                        nfn = vidfile + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S") + '.mp4'
                        LogR(nfn)
                        os.rename(Normalize_Filespec(tmp_file), Normalize_Filespec(nfn))
                        return nfn
                    except Exception as e2:
                        traceback.print_exc()
                        utils.Notify(msg = u"Eror downloading '{}".format(name), duration=20000)
                        return tmp_file
            else:
                utils.Notify(msg = u"' name:{} tmp:{}".format(vidfile,tmp_file), duration=20000)
                Log('error downloading {}'.format(repr(locals())), C.LOGERROR)
                raise StopDownloading('Stopped Downloading')
        except StopDownloading:
            try:
                Delete_File(tmp_file)
            except:
##                traceback.print_exc()
                pass
        except:
            traceback.print_exc()
            try:
                Delete_File(tmp_file)
            except:
##                traceback.print_exc()
                pass
        finally:
            if progress_dialog:
                progress_dialog.close()
            progress_dialog = None
#__________________________________________________________________________
#
def Background_MP4Downloader(
    url
    , name
    , mode
    , url_factory
    , icon_URI
    , download_path
    , stop_event
    , rowid
    ):

    LogR(
        locals()
        ,C.LOGNONE
        )

    name = utils.Clean_Filename(name)

    if not stop_event: stop_event = threading.Event()
    
    Log("Background_MP4Downloader instance")
    downloader = MP4Downloader(
          name = name
        , url = url
        , stop_playing_event = stop_event
        , download_path = download_path
        )

    Log("Background_MP4Downloader keep sending start")
    downloader.keep_sending_video()
    Log("Background_MP4Downloader keep sending finish")

    downloader = None

    Stop_Download(
        url=url
        , name=name
        , refresh_container=False
        , rowid=rowid
        , desc=name
        )

#__________________________________________________________________________
#
def Background_HLSDownloader(
    url
     , download_path
     , name
     , stop_event
     , repeat_when_available
     , rowid
     , use_low_latency = False #prefer low latency HLS
     , url_factory = None #information on how to rebuild a new url
     , mode = None #the site entry point that can use url_factory
    ):

##    use_low_latency = True; Log('warning use_low_latency is hardcoded')

    LogR(
        locals()
        ,C.LOGNONE
        )

    seek_forward_event = threading.Event()
    rebuild_url_event = threading.Event()
    try:

        progress_dialog = xbmcgui.DialogProgressBG()
        progress_dialog.create(C.addon_name,name[:50])

        play_profile         = 'profile_00' #the download profile
        initial_bitrate      = int(GetSetting(play_profile + "_" + "initial", float) * 1000 * 1000)
        maximum_bitrate      = int(GetSetting(play_profile + "_" + "maximum", float) * 1000 * 1000)
        allow_upscale        = GetSetting(play_profile     + "_" + "allow_upscale")
        allow_downscale      = GetSetting(play_profile     + "_" + "allow_downscale")
        always_refresh_m3u8  = GetSetting(play_profile     + "_" + "always_refresh_m3u8")
        downscale_threshhold = GetSetting(play_profile     + "_" + "downscale_threshhold", int)
        upscale_threshhold   = GetSetting(play_profile     + "_" + "upscale_threshhold", int)
        upscale_penalty      = GetSetting(play_profile     + "_" + "upscale_penalty", int)
        pre_cache_size_max   = int(GetSetting(play_profile + "_" + "pre_cache_size_max", float)* 1000 * 1000)

        if not stop_event: stop_event = threading.Event()
        stop_playing_event = stop_event
        seek_forward_event = threading.Event()
        rebuild_url_event = threading.Event()

        import HLSDownloaderRetry #import here to reduce starttime recompile

        MAX_REBUILD_ATTEMPTS = 1
        Log('warning MAX_REBUILD_ATTEMPTS = 5')
        
        for i in range(0,MAX_REBUILD_ATTEMPTS):

            Log("Background_HLSDownloader instance")
            downloader = HLSDownloaderRetry.HLSDownloaderRetry()
            downloader.init(
                  url = url
                , stop_playing_event = stop_playing_event
                , seek_forward_event = seek_forward_event
                , maxbitrate = maximum_bitrate
                , download_path = download_path
                , initial_bitrate = initial_bitrate
                , allow_upscale = allow_upscale
                , allow_downscale = allow_downscale
                , always_refresh_m3u8 = always_refresh_m3u8
                , downscale_threshhold = downscale_threshhold
                , upscale_threshhold = upscale_threshhold
                , upscale_penalty = upscale_penalty
                , pre_cache_size_max = pre_cache_size_max
                , use_low_latency = use_low_latency  #use HLS EXT-X-PART information if possible
                , rebuild_url_event = rebuild_url_event #raise if we get HTTP 40x
                )

            Log("Background_HLSDownloader keep sending start")
            downloader.keep_sending_video(
                dest_stream=None
                , progress_dialog=progress_dialog
                )
            Log("Background_HLSDownloader keep sending finish")

            if not rebuild_url_event.is_set():
                break

            if url_factory:
                queries = {
                      'url' : url_factory
                    , 'name' : name
                    , 'download': '1'
                    , 'img' : ''
                    , 'testmode' : True
                    #, mimetype : mimetype #not sure if we need this
                    , skip_head : True
                    }
                #dispatch to the site-specific code that should then
                #   return a url
                url = C.url_dispatcher.dispatch(str(mode), queries)
                if not url:
                    Log('rebuild_url_event is set, urlfactory did not generate a url',C.LOGWARNING)
                    break
            else:
                Log('rebuild_url_event is set, but no urlfactory',C.LOGWARNING)
                break
                
        
        downloader = None

    except:
        raise
        traceback.print_exc()
    finally:
        seek_forward_event = None
        rebuild_url_event = None

        #delete zero byte downloads
        if Size_Filespec(download_path) == 0:
            try:
                worker = threading.Thread(
                    target=Delete_File
                    ,args=(download_path,)
                    ,daemon = True
                    )
                worker.start()
                Log("starting Delete_File:{} download_path".format(
                    worker.ident,download_path
                    ),C.LOGWARNING)
            except:
                traceback.print_exc()
                pass
        progress_dialog.close()
        Stop_Download(url, name, False) #let service know we are finished and active item should be delted
        
    
#__________________________________________________________________
#
def make_downloads_db():

    Log('warning move to queries')
    downloads_conn = generic_favdbconn(C.downloads_db)
    try:
        
        sql_command = '''
            CREATE TABLE IF NOT EXISTS
            `downloads` (
              `id` INTEGER PRIMARY KEY AUTOINCREMENT 
            , `name` text 
            , `url` text 
            , `file_spec` text 
            , `expected_size` int DEFAULT NULL 
            , `start_time` double 
            , `update_time` double 
            , `current_size` int 
            , `current_data_rate` double 
            , `expected_end_time` double 
            , `mode` int  DEFAULT NULL 
            , `modelID` TEXT DEFAULT NULL 
            , `url_factory` varchar(1024) DEFAULT NULL 
            , `icon_URI` TEXT DEFAULT NULL     
            );
        '''
        downloads_conn.execute(sql_command)
        sql_command = '''
            drop INDEX if exists `idx_url_factory`;
            '''
        downloads_conn.execute(sql_command)
        sql_command = '''
            CREATE UNIQUE INDEX
            IF NOT EXISTS
            `index_downloads_name-urlfactory` ON
            `downloads` (
                `name`	ASC,
                `url_factory`	ASC
                            );
            '''
        downloads_conn.execute(sql_command)
        sql_command = '''
        update downloads
        set `modelid` = 
        --select name,
        substr(`icon_URI`, ifnull(nullif(instr(`icon_URI`,'/avatar'),0),instr(`icon_URI`,'?')),-8)
        --from downloads
        where  `mode`=272 ; 
        '''
        downloads_conn.execute(sql_command)
        downloads_conn.commit()
    except:
        raise
        pass
    finally:
        downloads_conn.close()
#__________________________________________________________________
#
def db_date_formatter(date):
    return date.isoformat() #strftime("%Y%m%d.%H%M%S")
#__________________________________________________________________
#
def clean_downloads(days_too_old=1.0):
    Log("clean_downloads(days_too_old={}) start".format(days_too_old))
    return
    raise NotImplementedError('clean_downloads')
##    too_old_day  = db_date_formatter(datetime.datetime.utcnow()-datetime.timedelta(days_too_old))
##    too_old_hour = db_date_formatter(datetime.datetime.utcnow()-datetime.timedelta((days_too_old/24.0)))
##    sql_command =  '''
##        SELECT name, url FROM downloads 
##        WHERE 
##            (start_time  < '{}')
##            OR ( 
##                 (update_time < '{}') 
##                 AND 
##                 ( substr(file_spec,length(file_spec)-(length('.ts')-1)) != '.ts')
##		);
##        '''
##    sql_command = sql_command.format(too_old_day,too_old_hour)
##    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
##    try:
####        downloads_conn = sqlite3.connect(C.downloads_db)
####        downDB_cursor = downloads_conn.cursor()
####        downDB_cursor.execute(sql_command)
##        downloads_conn = generic_favdbconn(C.downloads_db)
##        downDB_cursor = downloads_conn.execute(sql_command)
##        cleanable_items = downDB_cursor.fetchall()
##        for name, url in cleanable_items:
##            Log("cleaning name='{}'".format(name) )
##            proxy_thread = threading.Thread(
##                name="download_cleaner."+utils.Clean_Filename(name)
##                ,target=Stop_Download
##                ,args=(url,name,False)
##                )
##            proxy_thread.daemon = True
##            proxy_thread.start()
##    finally:
##        if downloads_conn: downloads_conn.close()
##        pass
##    Log("clean_downloads end")
##    return True
#__________________________________________________________________
#
def scheduled_downloads():
    make_downloads_db()
    scheduled = None
    sql_command = "SELECT * FROM downloads"
    downloads_conn = generic_favdbconn(C.downloads_db)
    try:
        scheduled = downloads_conn.execute(sql_command).fetchall()
    finally:
        downloads_conn.close()
    LogR(scheduled)
    return scheduled
#__________________________________________________________________
#
def delete_download(url, rowid=None):
    if rowid:
        sql_command = "DELETE FROM downloads WHERE id = ?"
        param = (rowid,)
    else:
        sql_command = "DELETE FROM downloads WHERE url = ?"
        param = (url,)
    Log("sql_command='{}' '{}'".format(sql_command, repr(param)) )#,LOGNONE)
    downloads_conn = generic_favdbconn(C.downloads_db)
    try:
        active = downloads_conn.execute(sql_command, param)
        downloads_conn.commit()
    finally:
        downloads_conn.close()

    return True
#__________________________________________________________________
#
def rename_download(name, new_name, mode, friendly_name, url_factory):
    make_downloads_db()
    query = (
        " UPDATE downloads "
        " SET modelid=?, url_factory=?, name=? "
        " WHERE name=? and mode=?"
    )
    params = (friendly_name, url_factory, new_name, name, mode)
    try:
        downloads_conn = generic_favdbconn(C.downloads_db)
        downDB_cursor = downloads_conn.execute(query, params)
        downloads_conn.commit()
    finally:
        if downloads_conn: downloads_conn.close()
        pass
#__________________________________________________________________
#
def add_download(
    name
    , url
    , file_spec
    , expected_size
    , friendly_name
    , url_factory
    , icon_URI
    , mode
    , modelID = None
##    , start_time = " CAST(strftime('%s') as INT) "
    ):

##    downloads_conn = generic_favdbconn(C.downloads_db)
##    LogR(dir(downloads_conn))
##    downloads_conn.__exit__()
##
##    LogR( locals())
    
    if (not modelID) and (str(mode)== str(int(C.MAIN_MODE_myfreecams) + (C.MODE_PLAY_OFFSET))) :
        
        try:
            
            
            if "/img.mfcimg.com/" in icon_URI or "/snap.mfcimg.com/" in icon_URI :
                model_id_via_image = "00000000" # length of 8
                model_id_via_image = icon_URI.split('/')[6]
                model_id_via_image = model_id_via_image.split('|')[0]
                if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                    model_id_via_image = icon_URI.split('/')[5]
                #the 1 indicates model was in public chat when bookmark created
                if model_id_via_image.startswith("mfc_a_1"):
                   model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
                if model_id_via_image.startswith("mfc_1"):
                   model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
                if model_id_via_image[0] == '0':
                    model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
                while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
                    model_id_via_image = '0' + model_id_via_image
                
            else:
                # the only way I can see this being reached is if
                # the icon is pointing to the local cache
                # however, the modelid should be in camlist or favorites table
                model_id_via_image = None
                with generic_favdbconn(C.favoritesdb) as favorites_conn:
                    if not model_id_via_image:
                        sql_command = \
''' SELECT `modelID` FROM `camlist` where `modelDisplayName` = ? '''
                        params = ( sanitize_sql(name), )
                        Log("sql_command='{}' params={}".format(sql_command, repr(params)) )#,LOGNONE)
                        for m in favorites_conn.execute(sql_command, params).fetchall():
                            LogR(dict(m))
                            model_id_via_image = dict(m)["modelID"]
                            break
                    if not model_id_via_image:
                        sql_command = \
'''
SELECT `modelID` FROM `favorites`
WHERE `name` = ? and `mode` = ?
'''
                        params = ( sanitize_sql(name), sanitize_sql(mode) )
                        Log("sql_command='{}' params={}".format(sql_command, repr(params)) )#,LOGNONE)
                        for m in favorites_conn.execute(sql_command, params).fetchall():
                            LogR(m)
                            model_id_via_image = dict(m)["modelID"]
                            break
                #end with 

            LogR((name, model_id_via_image))
            modelID = model_id_via_image
               
        except Exception as ex:
            LogR(ex, C.LOGERROR)
            #traceback.print_exc()
            raise

    if not modelID:
        modelID = name #default


    make_downloads_db()
    #note: start time is a parameter in order to force consistent formatting
    #record dead if something has not update_time recently
    sql_command = '''
        INSERT INTO `downloads`
        ( `name`
        , `url`
        , `file_spec`

        , `expected_size`
        , `mode`
        , `modelID`

        , `url_factory`
        , `icon_URI`

        , `start_time`
        , `update_time`

        ) VALUES 
        (
        ?,?,?,
        ?,?,?,
        ?,?,
         CAST(strftime('%s') as INT) ,  CAST(strftime('%s') as INT) 
        )
        '''

    params = (
        sanitize_sql(name)
        , sanitize_sql(url)
        , sanitize_sql(file_spec)

        , sanitize_sql(expected_size)
        , mode
##        , sanitize_sql(friendly_name)
        , sanitize_sql(modelID)
        
        , url_factory
        , icon_URI
        )

    Log("sql_command='{}' params={}".format(sql_command, repr(params)) )#,LOGNONE)
    downloads_conn = generic_favdbconn(C.downloads_db)
    try:
        Log('warning todo upsert')
        downloads_conn.execute(sql_command, params) #sqlite3 will auto commit
        downloads_conn.commit()
    except sqlite3.IntegrityError:
        #sqlite3.IntegrityError: UNIQUE constraint failed: downloads.name, downloads.url_factory
        pass
    finally:
        downloads_conn.close()
##    Log('warning used during dev/debug'); raise Exception();

#__________________________________________________________________________
#
def sanitize_sql(information):
    return information
##    if information:
##        Log(repr(information))
##        if sqlite3.complete_statement(information):
##            raise sqlite3.IntegrityError
##    return information 
#__________________________________________________________________________
#
def un_sanitize_sql(information):
    return information
    #return urllib.unquote_plus(information) #todo: unsanitize info to prevent bad sql command
#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True,delete_first_color=False):
    return utils.Clean_Filename(s, include_square_braces=include_square_braces, delete_first_color=delete_first_color)
