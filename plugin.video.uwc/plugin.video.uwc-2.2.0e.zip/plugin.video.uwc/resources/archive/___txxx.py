#-*- coding: utf-8 -*-
'''
  Ultimate Whitecream
  Copyright (C) 2016 Whitecream, hdgdl
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import base64
import json
import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]Txxx[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://txxx.com"
SEARCH_URL = ROOT_URL + '/api/videos.php?params=259200/str/relevance/60/search..{}.all..day&s={}'
URL_RECENT = ROOT_URL + '/api/json/videos/86400/str/latest-updates/60/..{}.all..day.json'
URL_CATEGORIES = ROOT_URL + '/api/json/categories/14400/str.all.json'
URL_CHANNELS = ROOT_URL + '/channels/'

# like txxx
# like hclips
# like tubepornclassic

MAIN_MODE          = C.MAIN_MODE_txxx
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon)
    List(url=URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, referer=ROOT_URL) #, ignore404=True ) #cookie+C.headers
    if '{"error":1,"code":"videos_not_found"}' in listhtml:
        video_region = ""
        next_page_html = ""
        listhtml = ""
    else:
        next_page_html = listhtml
        try:
            video_region = listhtml.split('<div class="videos-page" ref="videos">')[1]
        except:
            video_region = listhtml

    #
    # parse out list items
    #
    #Log("json_urls={}".format(json_urls))
    json_urls = json.loads(listhtml)
    if json_urls:
        if 'videos' in json_urls:
            for viditem in json_urls['videos']:
                label = utils.cleantext(C.html_parser.unescape(viditem['title']))
                hd = ""
                if viditem['props']:
                    #Log("viditem['props']='{}'".format(viditem['props']))
                    if 'hd' in viditem['props']:
                        if viditem['props']['hd']:
                            hd = C.STANDARD_MESSAGE_HD
                label = "{}{}{}".format(C.SPACING_FOR_NAMES, label, hd)

                thumb = viditem['scr']
                duration = viditem['duration']
                description = viditem['models']
    ##            Log("description={}".format(description))
                
                #videourl = ROOT_URL + "/videos/{}/{}/".format( viditem['video_id'], viditem['dir'] )
                #https://txxx.com/videos/15847497/mia-malkova11/
                videourl = ROOT_URL + "/api/videofile.php?video_id={}&lifetime=8640000".format( viditem['video_id'] )
                #https://txxx.com/api/videofile.php?video_id=15847497&lifetime=8640000
                
                utils.addDownLink( 
                    name = label 
                    , url = videourl 
                    , mode = PLAY_MODE 
                    , iconimage = thumb
                    , desc = description + '\n' + ROOT_URL
                    , duration = duration ) 
            utils.Check_For_Minimum(json_urls['videos'], keyword, MAIN_MODE, ROOT_URL, testmode)
    
    if ('params' in json_urls) and (json_urls['params']):
        count = json_urls['params']['count']
        json_page = json_urls['params']['page']
        total_count = json_urls['total_count']
        np_info = None
        if count * json_page < total_count:
            np_info = int(page) + 1
        if not np_info:
            Log(C.STANDARD_MESSAGE_NP_INFO.format(url))
        else:
            Log("np_info='{}'".format(np_info))
            np_number = int(page) + 1
            np_url = url
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number 
                    ,section = C.INBAND_RECURSE
                    ,keyword = keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace('+','%20')    
    searchUrl = SEARCH_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    json_source = utils.getHtml(url, ROOT_URL)
    json_categories = json.loads(json_source)
    for cat_item in json_categories['categories']:
        url = ROOT_URL + "/api/json/videos/86400/str/latest-updates/60/categories.{}.{}.all..day.json".format(cat_item['dir'], '{}')
        label = cat_item['title']
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=url 
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=C.search_icon)

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['desc', 'download', 'playmode_string'])
def Playvid(url, name, desc=None, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    videopage = utils.getHtml(url, ROOT_URL)

    file_code = videopage #post 2019-12-01
    
    #maybe url has enough info to coerce poor original url to one we can use
    regex_video_id_in_url = ROOT_URL+'/videos/(\d+)/'
    video_id_in_url = re.compile(regex_video_id_in_url, re.DOTALL | re.IGNORECASE).findall(url)
##    Log("video_id_in_url='{}'".format(repr(video_id_in_url)))
    
    regex = "pC3:'([^']+)',video_id: (\d+),"
    vid_codes = re.compile(regex, re.DOTALL ).findall(videopage)
    if vid_codes: #pre 2019-12-01 code below
##        Log("vid_codes='{}'".format(repr(vid_codes)))
        for code, vid_id in vid_codes:
            post_code = str(vid_id) + ',' + code
            #Log("post_code={}".format(post_code))
            import urllib
            post_code = 'param=' + urllib.quote(post_code)
            #Log("post_code={}".format(post_code))
        from requests import Request, Session
        s = Session()
        post_url = ROOT_URL+'/sn4diyux.php'
        headers = {"User-Agent": C.USER_AGENT
                   , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                   , "Referer": url
                   }
        data = post_code
        proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
        #proxies = {"http": "127.0.0.1:8888"}
        req = Request('POST', post_url, data=data, headers=headers)
        prepped = s.prepare_request(req)
        resp = s.send(prepped , proxies=proxies, verify=False)
        #Log("resp.status_code='{}'".format(repr(resp.status_code)))
        #Log("resp.content='{}'".format(repr(resp.content)))
        regex = "'([^']+)'"
        file_code = re.compile(regex, re.DOTALL).findall(resp.content) [0]
        #Log("file_code={}".format(file_code))
    elif video_id_in_url: #maybe url has enough info to coerce
        #https://txxx.com/api/videofile.php?video_id=16997373&lifetime=8640000
        coerce_url = ROOT_URL + "/api/videofile.php?video_id={}&lifetime=8640000".format(video_id_in_url[0])
##        Log("coerce_url='{}'".format(repr(coerce_url)))
        file_code = utils.getHtml(coerce_url, ROOT_URL)

##    Log("file_code='{}'".format(repr(file_code)))
    items = json.loads(file_code)

    if desc: description = desc
    else: description = name + '\n' + ROOT_URL
    Log("description='{}'".format(description))

    #stolen from current UWC 2021-02-02
    vidurl = items[0]['video_url']
    Log(u"vidurl='{}'".format(vidurl))
    replacemap = {'M':'\u041c', 'A':'\u0410', 'B':'\u0412', 'C':'\u0421', 'E':'\u0415', '=':'~', '+':'.', '/':','}
    for key in replacemap:
##        Log(key)
##        Log(replacemap[key])
        vidurl = vidurl.replace(replacemap[key], key)
    Log(u"vidurl='{}'".format(vidurl))
    replacemap2 = {u'M':u'\u041c', u'A':u'\u0410', u'B':u'\u0412', u'C':u'\u0421', u'E':u'\u0415', u'=':u'~', u'+':u'.', u'/':u','}
    for key in replacemap2:
##        Log(key)
##        Log(replacemap2[key])
        vidurl = vidurl.replace(replacemap2[key], key)
##    Log(u"vidurl='{}'".format(vidurl))

    video_url = base64.b64decode(vidurl)

#### figured out on my own
##    from resources.lib import resolver
##    video_url= resolver.alltubes_decode(items[0]['video_url'])

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    if not video_url.startswith('http') : video_url = ROOT_URL + video_url
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return
    
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
        
