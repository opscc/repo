'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

#2022-11 removing .... site only redirects to other places for playback
#        e.g. 4kporn.xxx  crazyporn.xxx pornone.com  www.katestube.com www.tubeon.com www.sortporn.com

'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]cartoonpornvideos[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_HENTAI
    _FRONT_PAGE_CANDIDATE = False
    
    _ROOT_URL        = "https://www.cartoonpornvideos.com"
    _URL_CATEGORIES  = _ROOT_URL + '/categories/'
    _URL_RECENT      = _ROOT_URL + '/videos/straight/all-recent-{}.html'#pre 2022-10
    _URL_RECENT      = _ROOT_URL + '/new?page={}'
    _SEARCH_URL      = _ROOT_URL + '/search/video/{}/{}/'#pre 2022-10
    _SEARCH_URL      = _ROOT_URL + '/search/a/{}?page={}'#latest


    _MAIN_MODE = C.MAIN_MODE_cartoonpornvideos

    _FIRST_PAGE = '1'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        'nothing found. Use more general words or phrases'
        ]

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = (
        'class="cards-container"(.+?)class="paging">'
        )
    #videos on this page
    _REGEX_list_items = (
        '<div class="card-container.+?href="(?P<videourl>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        '.+?(?:class="hd-icon"|class)(?P<hd>.+?)' #note: this captures a bit extra because it does not always exist
        'clock"></i>(?P<duration>[^<]+?)<'   #note: the .+? is above
##        'class="item".+?href="(?P<videourl>[^"]+)"'
##        '.+?src="(?P<thumb>[^"]+)"'
##        '.+?alt="(?P<label>[^"]+)"'
##        '.+?(?:class="flag-hd"|class)(?P<hd>.+?)' #note: this captures a bit extra because it does not always exist
##        '"time">(?P<duration>[^<]+?)<'   #note: the .+? is above
        )
    ## Which right click properties to add to icon
    #_Right_Click_Option = C.DEFAULT_PLAYMODE

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = (
        'class="pagination-summary"(.+?)</nav>'
        )
    _REGEX_next_page_regex = '(title="next-page")'

    #if we need to save html cookies
    _SAVE_COOKIES = False

    #where categories can be found
    _REGEX_categories_region = (
        'class="category-group-container"(.+?)div id="popular-categories"'
        )
    _REGEX_categories = (
        '<li class="category".+?href="(?P<videourl>[^"]+)"'
        '>(?P<label>[^<]+)<'
        '(?P<thumb>)'
        )

    #where playable urls live
    _REGEX_play_region = (
        'class="content".+?sources: (.+?)tracks: '
        )
    _REGEX_playsearch_01 = (
##        C.FLAG_USE_RESOLVER_ONLY
        'file: "(?P<url>[^"]+?)"'
        '.+?(?P<res>\d)'
        )
    #description for the playable url
    _REGEX_tags_region = None #'id="video-about"(.+?)id="video-tags"'
    _REGEX_tags = None #'/pornstars/.+?>([^<]+)<'

    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url + '?page={}'
    #https://www.cartoonpornvideos.com/category/yoga?page=2

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format(keyword,'{}') #keyword, then replace for page number
#https://www.cartoonpornvideos.com/search/a/lexi%20lore?page=2
    
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        return keyword.replace('+',' ').replace(' ','%20')

    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by website
    def Video_Source_URL_Normalize(self, url):
        return  url
    

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    return
    website.Test(end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    website.Playvid(url, name, download, playmode_string, play_profile=play_profile, testmode=testmode)
#__________________________________________________________________________
#
