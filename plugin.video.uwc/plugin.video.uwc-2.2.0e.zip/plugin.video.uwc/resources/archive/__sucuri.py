
#
#      Copyright (C) 2015 tknorris (Derived from Mikey1234's & Lambda's)
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with XBMC; see the file COPYING.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
#  This code is a derivative of the YouTube plugin for XBMC and associated works
#  released under the terms of the GNU General Public License as published by
#  the Free Software Foundation; version 3


import re
import urllib2
import urllib
import urlparse

import xbmc


USER_AGENT = "Mozilla/5.0 (compatible, MSIE 11, Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko"

MAX_TRIES = 6
COMPONENT = __name__

SCRIPT_HEADER = "<script>var s={},u,c,U,r,i"

def Log(msg='', loglevel=None):
    debug = True
    if re.compile("\\u\s\s\s\s").findall(msg):
        msg = msg.decode('unicode-escape',errors='ignore').encode('utf-8',errors='ignore')
    msg = "{}: {}".format("sucuri", msg)
    if loglevel: xbmc.log(msg , loglevel)
    elif debug:  xbmc.log(msg , xbmc.LOGNONE)
    else:    xbmc.log(msg)
    
def Set_Cookie(data):
##    Log("data='{}'".format(data))
    text = re.compile("w=String.fromCharCode,sucuri_cloudproxy_js='',S='([^']+)'", re.DOTALL | re.IGNORECASE).findall(data)[0]
##    Log("text='{}'".format(text))
    text_length=len(text)

##    Log("cookie_value0='{}'".format("xu76"[3]))
##    Log("cookie_value1='{}'".format("xu76"[3:0]))
##    Log("cookie_value1='{}'".format("xu76"[3:3+1]  ))
##    Log("cookie_value2='{}'".format(eval('"xu76"[3:1]')))
##    return

    s = {}
    U=0
    r=''
    A='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    import base64
    text = base64.b64decode(text).replace('\n', ' ')
##    Log("text='{}'".format(text))

####    for(u=0;u<64;u++){
####        s[A.charAt(u)]=u;
####    }
##    u=0
##    while u<64:
##        s[A[u]] = u
##        u = u+1 
##    Log("s='{}'".format(s))
##    return

    text=re.compile("=(.+)", re.DOTALL | re.IGNORECASE).findall(text)[0]
##    Log("text='{}'".format(text))

    search_re = "(?:'|\")(;?[^'\"]+)(?:'|\")\.charAt\((\d+)\)"
    subst_re = ' "\\1"[\\2] '
    text = re.sub(search_re,subst_re,text)
##    Log("text='{}'".format(text))

    search_re = "(?:'|\")(;?[^'\"]+)(?:'|\")\.slice\((\d+),(\d+)\)"
    subst_re = ' "\\1"[\\2:\\3] '
    text = re.sub(search_re,subst_re,text)
##    Log("text='{}'".format(text))

    search_re = "(?:'|\")(;?[^'\"]+)(?:'|\")\.substr\((\d+),\s*(\d+)\)"
    subst_re = ' "\\1"[\\2:\\2+\\3] '
    text = re.sub(search_re,subst_re,text)
##    Log("text='{}'".format(text))

    search_re = "String\.fromCharCode\((\w+)\)"
    subst_re = ' chr(\\1) '
    text = re.sub(search_re,subst_re,text)
##    Log("text='{}'".format(text))

    cookie_value = text.split(';document.cookie=')[0]
##    Log("cookie_value='{}'".format(cookie_value))

#    cookie_value = re.sub(u'(?is)[^\w\]\[ \"\':;+\(\)]','',cookie_value)
    cookie_value = re.sub(u'(?is)[^+ ]chr\(','_alert_chr',cookie_value)
##    Log("cookie_value='{}'".format(cookie_value), xbmc.LOGNONE)

    cookie_value = eval(cookie_value)
##    Log("cookie_value='{}'".format(cookie_value), xbmc.LOGNONE)


    cookie_name = re.compile(";document.cookie\s*=\s*(.+?)\s*\+\s*\"\s*=\s*\"", re.DOTALL | re.IGNORECASE).findall(text)[0]
##    Log("cookie_name='{}'".format(cookie_name), xbmc.LOGNONE)
    
##    cookie_name = text.split(';document.cookie=')[1]
##    cookie_name = cookie_name.split('+ "="')[0]


    cookie_name = eval(cookie_name)
##    Log("cookie_name='{}'".format(cookie_name), xbmc.LOGNONE)
    
#    Log("cookie_name='{}'".format(eval(cookie_name)))
                                        #'3548046 05e6b483ea90b077 7897987'
#       'sucuri_cloudproxy_uuid_acd11202e'
#                                         3548046605e6b483ea90b07717897987'
#Cookie: sucuri_cloudproxy_uuid_acd11202e=3548046605e6b483ea90b07717897987    
##    for(u=0;u<64;u++){
##        s[A.charAt(u)]=u;
##    }
    
    #for(i=0;i<L;i++){c=s[S.charAt(i)];U=(U<<6)+c;l+=6;while(l>=8){((a=(U>>>(l-=8))&0xff)||(i<(L-2)))&&(r+=w(a));}}e(r);</script></html>

    import datetime
    expire_date = 2147483647 #max
    expire_date = ( datetime.datetime.utcnow() + datetime.timedelta(minutes=5) )
##    Log(repr(expire_date))
    import time
    expire_date = int(time.mktime(expire_date.timetuple())) # + expire_date.microsecond/1e6
##    Log(repr(expire_date))
    
    import cookielib
    ck = cookielib.Cookie(version=0,
                          name=cookie_name,
                          value=cookie_value,
                          port=None,
                          port_specified=False,
                          domain='.animeidhentai.com',
                          domain_specified=True,
                          domain_initial_dot=True,
                          path="/",
                          path_specified=True,
                          secure=True,
                          expires=expire_date,
                          discard=False,
                          comment=None,
                          comment_url=None,
                          rest={'httponly': 'None'},
                          rfc2109=False)
    Log(repr(ck))
##    cookie_jar.set_cookie(ck)
##    cookie_jar.save()
##    for cookie in cookie_jar:
##        if cookie.domain.endswith(".com"):
##            Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)

    return ck
                      
class NoRedirection(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        xbmc.log('Stopping Redirect')
        return response

    https_response = http_response

def solve_equation(equation):
    try:
        offset = 1 if equation[0] == '+' else 0
        return int(eval(equation.replace('!+[]', '1').replace('!![]', '1').replace('[]', '0').replace('(', 'str(')[offset:]))
    except:
        pass

def solve(url, cj, user_agent=None, wait=True):
    if user_agent is None: user_agent = USER_AGENT
    headers = {'User-Agent': user_agent, 'Referer': url}
    if cj is not None:
        try: cj.load(ignore_discard=True)
        except: pass
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        urllib2.install_opener(opener)

    request = urllib2.Request(url)
    for key in headers: request.add_header(key, headers[key])
    try:
        response = urllib2.urlopen(request)
        html = response.read()
    except urllib2.HTTPError as e:
        html = e.read()
    
    tries = 0
    while tries < MAX_TRIES:
        solver_pattern = 'var (?:s,t,o,p,b,r,e,a,k,i,n,g|t,r,a),f,\s*([^=]+)={"([^"]+)":([^}]+)};.+challenge-form\'\);.*?\n.*?;(.*?);a\.value'
        vc_pattern = 'input type="hidden" name="jschl_vc" value="([^"]+)'
        pass_pattern = 'input type="hidden" name="pass" value="([^"]+)'
        init_match = re.search(solver_pattern, html, re.DOTALL)
        vc_match = re.search(vc_pattern, html)
        pass_match = re.search(pass_pattern, html)
    
        if not init_match or not vc_match or not pass_match:
            xbmc.log("Couldn't find attribute: init: |%s| vc: |%s| pass: |%s| No cloudflare check?" % (init_match, vc_match, pass_match))
            return False
            
        init_dict, init_var, init_equation, equations = init_match.groups()
        vc = vc_match.group(1)
        password = pass_match.group(1)
    
        # log_utils.log("VC is: %s" % (vc), xbmc.LOGDEBUG, COMPONENT)
        varname = (init_dict, init_var)
        result = int(solve_equation(init_equation.rstrip()))
        xbmc.log('Initial value: |%s| Result: |%s|' % (init_equation, result))
        
        for equation in equations.split(';'):
                equation = equation.rstrip()
                if equation[:len('.'.join(varname))] != '.'.join(varname):
                        xbmc.log('Equation does not start with varname |%s|' % (equation))
                else:
                        equation = equation[len('.'.join(varname)):]
    
                expression = equation[2:]
                operator = equation[0]
                if operator not in ['+', '-', '*', '/']:
                    #log_utils.log('Unknown operator: |%s|' % (equation), log_utils.LOGWARNING, COMPONENT)
                    continue
                    
                result = int(str(eval(str(result) + operator + str(solve_equation(expression)))))
                #log_utils.log('intermediate: %s = %s' % (equation, result), log_utils.LOGDEBUG, COMPONENT)
        
        scheme = urlparse.urlparse(url).scheme
        domain = urlparse.urlparse(url).hostname
        result += len(domain)
        #log_utils.log('Final Result: |%s|' % (result), log_utils.LOGDEBUG, COMPONENT)
    
        if wait:
                #log_utils.log('Sleeping for 5 Seconds', log_utils.LOGDEBUG, COMPONENT)
                xbmc.sleep(5000)
                
        url = '%s://%s/cdn-cgi/l/chk_jschl?jschl_vc=%s&jschl_answer=%s&pass=%s' % (scheme, domain, vc, result, urllib.quote(password))
        #log_utils.log('url: %s' % (url), log_utils.LOGDEBUG, COMPONENT)
        request = urllib2.Request(url)
        for key in headers: request.add_header(key, headers[key])
        try:
            opener = urllib2.build_opener(NoRedirection)
            urllib2.install_opener(opener)
            response = urllib2.urlopen(request)
            while response.getcode() in [301, 302, 303, 307]:
                if cj is not None:
                    cj.extract_cookies(response, request)

                redir_url = response.info().getheader('location')
                if not redir_url.startswith('http'):
                    base_url = '%s://%s' % (scheme, domain)
                    redir_url = urlparse.urljoin(base_url, redir_url)
                    
                request = urllib2.Request(redir_url)
                for key in headers: request.add_header(key, headers[key])
                if cj is not None:
                    cj.add_cookie_header(request)
                    
                response = urllib2.urlopen(request)
            final = response.read()
            if 'cf-browser-verification' in final:
                #log_utils.log('CF Failure: html: %s url: %s' % (html, url), log_utils.LOGWARNING, COMPONENT)
                tries += 1
                html = final
            else:
                break
        except urllib2.HTTPError as e:
            #log_utils.log('CloudFlare HTTP Error: %s on url: %s' % (e.code, url), log_utils.LOGWARNING, COMPONENT)
            return False
        except urllib2.URLError as e:
            #log_utils.log('CloudFlare URLError Error: %s on url: %s' % (e, url), log_utils.LOGWARNING, COMPONENT)
            return False

    if cj is not None:
        cj.save()
        
    return final
