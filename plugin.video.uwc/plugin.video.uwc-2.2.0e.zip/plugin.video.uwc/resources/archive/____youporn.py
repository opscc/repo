'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]youporn[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.youporn.com"
SEARCH_URL = ROOT_URL + '/search/?query={}&page={}'
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/browse/time/?page={}'

MAIN_MODE       = C.MAIN_MODE_youporn
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

##
##name=C.STANDARD_MESSAGE_CATEGORIES
##
##(inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(
##      end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
##
##hd = utils.Normalize_HD_String(hd)
##
##Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
##
##C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
##
##utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
##
##utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
##
##C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
##
##utils.endOfDirectory(end_directory=end_directory)
##
##utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    redirected_url = None
    listhtml = utils.getHtml(list_url, ignore404=True)# , send_back_redirect=True)
    if redirected_url: list_url = redirected_url
    if "<p>Make sure that all words are spelled correctly.</p>" in listhtml or "No videos found for " in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            regex = '(?:data-section_name="day_by_day_section" data-espnode|video_row_main_search"|data-espnode="videolist")(.+?)(?:id="pagination"|<footer>)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            video_region = listhtml

    # parse out list items
    regex = 'data-video-id.+?href="([^"]+)".+?alt=\'([^"]+)\'.+?data-thumbnail="([^"]+)".+?"video-duration">([\d:]+)<.*?((?:class="icon icon-hd-text"></i>|</div>))'
    regex = ('data-video-id="\d.+?href="(?P<url>[^"]+)"'
             '.+?data-thumbnail="(?P<thumb>[^"]+)"'
             '.+?title="(?P<label>[^"]+)"'
             '.+?"video-best-resolution">(?P<res>\d+)'
             '.+?"video-duration">(?P<duration>[\d:]+)<'
            )
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, hd, duration in info:
        #Log("hd={}".format(hd))
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        duration = duration.replace(' ','')
##        Log("thumb={}".format(thumb))
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    # next page items
    try:
        regex = 'id="pagination"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
##    Log("next_page_html={}".format(next_page_html))
    next_page_regex = 'id="next".+?href="([^"]+)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_url = C.html_parser.unescape(np_url)
            np_number = ''
##            if '/' in np_url: np_url = np_url.strip('/').split('/')[-1]
##            Log("np_url={}".format(np_url))
##            if '?page=' in np_url: np_number = np_url.split('?page=')[1]
##            if '&page=' in np_url: np_number = np_url.split('&page=')[1]
##            if 'page' in np_url and not np_number.isdigit(): np_number = np_url.split('page')[1]
##            if '&p=' in np_url: np_number = np_url.split('&p=')[1]
##            if '?p=' in np_url: np_number = np_url.split('?p=')[1]
            np_number = int(page) + 1
            np_url = url
            Log("np_number={}".format(np_number))
            Log("np_url={}".format(np_url))
##            if not np_number == '':
##                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, C.search_text_color, int(np_number))
##            else:
##                np_label = None
##            if not np_label:
##                Log("np_info not found in url='{}'".format(list_url))
##            else:
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth): #search some more, but not forever
                    utils.Notify(msg=np_url.format(np_number))
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    listhtml = utils.getHtml(url)
    regex = "id='categoryList'(.+)"
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    regex = '<a href="([^"]+)".+?data-original="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = videourl + '?page={}'
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb) #C.search_icon)

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    full_html = utils.getHtml(url, ROOT_URL)

    if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
        return

    regex = 'mediaDefinition:\s+?(\[[^\]]+\]),'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    if sources_list: sources_list=sources_list[0]
    else: sources_list = ''
##        Log("sources_list={}".format(sources_list))
    json_sources = json.loads(sources_list)

    list_key_value = {} ##[] #dict()
    for json_src in json_sources:
        if 'videoUrl' in json_src:
##            Log("json_src={}".format(json_src['videoUrl']))
            if json_src['videoUrl'] != '':
                list_key_value[json_src['quality']] = json_src['videoUrl']
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )
    
    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return

    description = ''
    desc_separator_char = '; '
    regex_tags_region = 'class="categorieswrapper(.+?)<noscript>'
    regex_tags = '"pornstar_tag".+?>([^<]+)<'
    region_html = re.compile(regex_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
    if region_html:
        source_tags = re.compile(regex_tags, re.DOTALL | re.IGNORECASE).findall(region_html[0])
        for tag in source_tags:
            if tag.lower() not in description.lower():
                description = "{}{}{}".format(description,utils.cleantext(tag),desc_separator_char)
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
##    Log("description={}".format(description))
    
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
