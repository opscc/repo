'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]perfectgirls[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = False
    
    _ROOT_URL        = "https://www.perfectgirls.net"
    _URL_CATEGORIES  = _ROOT_URL 
    _URL_RECENT      = _ROOT_URL + '/p/{}'
    _SEARCH_URL      = _ROOT_URL + '/search/{}/{}'

    _MAIN_MODE = C.MAIN_MODE_perfectgirls

    _FIRST_PAGE = '1'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        'nothing found. Use more general words or phrases'
        ]

    #where we can find videos on this page [exclude advertisement]
    
    #videos on this page
    _REGEX_video_region = 'class="top-videos"(.+?)<!-- /container -->'
    _REGEX_list_items = (
        'class="list__item_link".+?href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?data-original="(?P<thumb>[^"]+)"'
        '.+?<time>(?P<duration>[^<]+)<'
        '.+?(?:class="hd"|</a)(?P<hd>[^<]+?)<'
        )

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'class="pagination(.+?)class="container"'
    _REGEX_next_page_regex = '(href="(?:/p/)?\d+">Next<)'

    #if we need to save html cookies
    _SAVE_COOKIES = False

    #where categories can be found
    _REGEX_categories_region = (
        '>Categories<(.+?)>Pornstars<'
        )
    _REGEX_categories = (
        'href="(?P<videourl>[^"]+)"'
        '>(?P<label>[^<]+)<'
        '(?P<thumb>)'
        )

    #where playable urls live
    _REGEX_play_region = (
        'class="video__resource"(.+?)class="video__info"'
        )
    _REGEX_playsearch_01 = (
##        C.FLAG_USE_RESOLVER_ONLY
        'source src="(?P<url>[^"]+)"'
        '.+?res="(?P<res>\d+)"'
        )
    #description for the playable url
    _REGEX_tags_region = None #'id="video-about"(.+?)id="video-tags"'
    _REGEX_tags = None #'/pornstars/.+?>([^<]+)<'

    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url + '/{}'
##href="/category/5/Amateur__Homemade">
##http://www.perfectgirls.net/category/5/Amateur__Homemade/3

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format(keyword,'{}')

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        return keyword.replace('+',' ').replace(' ','%20')

    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by website
    def Video_Source_URL_Normalize(self, url):
        return "https:" + url
    

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None, testmode=False):
    website.Playvid(url, name, download, playmode_string, testmode=testmode)
#__________________________________________________________________________
#
