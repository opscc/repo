'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream, hdgdl
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import os
import re
import sys

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://daftsex.com"

SEARCH_URL = ROOT_URL + '/video/'
URL_RECENT = ROOT_URL + '/hot'

MAIN_MODE       = '610'
LIST_MODE       = '611'
PLAY_MODE       = '612'
CATEGORIES_MODE = '613'
SEARCH_MODE     = '614'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    List(URL_RECENT, page='0', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=0, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)        
        
    try:
        postRequest = {'page' : str(page)}
        response = utils.postHtml(url, form_data=postRequest,headers={},compression=False)
    except:
        return None

    np_url = None #will be changed later on if items found


    #
    # parse out list items
    #
    regex_string = '<div class="video-item">.*?Video\.show.*?\'([^\']+)\'.*?<img src="([^"]+)".*?alt="([^"]+)".*?<span class="video-time">([^<]+)<'
    match = re.compile(regex_string, re.DOTALL | re.IGNORECASE).findall(response)
    for videourl, thumb, label, duration in match:
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in label: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label='{}'".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb 
            , duration = duration )

    #
    # next page items
    #
    if len(match) > 0: # show a 'next page' if items were found
        np_url = url
    else:
        np_url = None
    if not np_url:
        Log("np_info not found in url='{}'".format(url))
    else:    
        np_number = int(page) + 1
        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format( \
                SPACING_FOR_NEXT, utils.search_text_color, np_number + 1)
        #Log("np_label='{}'".format(np_label))
        #Log("np_url='{}'".format(np_url))
        if end_directory == True:
            utils.addDir(
                name=np_label
                ,url = np_url
                ,mode=LIST_MODE 
                ,iconimage=utils.next_icon
                ,page=np_number
                ,section = utils.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                #msg param for notify is modified for this site because page# is not normally part of url
                utils.Notify(msg=np_url+'/page='+str(np_number), duration=200)  #let user know something is happening
                List(np_url, page=np_number, end_directory=end_directory, keyword=keyword)
    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace(' ','_')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    Log("url='{}'".format(url))
    videourl = None
    response = utils.getHtml(url, "https://daftsex.com/watch/")
    #Log("response='{}'".format(response))
    

    vid_id = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)    
    token = re.compile('access_token: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)
    videos = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)
    extra_key = re.compile('sig: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)
    sig = re.compile('"sig":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(response)
    ckey = re.compile('c_key: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(response)
    thumb = re.compile('thumb: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(response)
    cdn_files = re.compile('cdn_files: {([^}]+)}', re.DOTALL | re.IGNORECASE).findall(response)
    server = re.compile('server: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(response)
    partial = re.compile('partial: {"quality":{"([^}]+)}', re.DOTALL | re.IGNORECASE).findall(response)

    #different versions of web pagemay not have same data
    try:    token = token[0]
    except: token = None
    try:    videos = videos[0]
    except: videos = None
    try:    ckey = ckey[0]
    except: ckey = None
    try:    extra_key = extra_key[0]
    except: extra_key = None
    try:    cdn_files = cdn_files[0]
    except: cdn_files = None
    import base64
    try:    thumb = base64.b64decode(thumb[0]).strip("thumb.jpg")
    except: thumb = None
    try:    server = base64.b64decode(server[0][::-1]) #reverse string then decode it
    except: server = None
    try:    sig = sig[0]
    except: sig = None
    try:    vid_id = vid_id[0]
    except: vid_id = None
    try:    partial = partial[0]
    except: partial = None
    
    
    #Log("access_token={}".format(token))
    Log("videos={}".format(videos))
    Log("extra_key={}".format(extra_key))
    Log("ckey={}".format(ckey))
    Log("thumb={}".format(thumb))
    Log("cdn_files={}".format(cdn_files))
    Log("server={}".format(server))
    Log("sig={}".format(sig))
    Log("vid_id={}".format(vid_id))
    #Log("partial={}".format(partial))
    
    if cdn_files: #newer style

        match_240 = re.compile('"mp4_240":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        match_360 = re.compile('"mp4_360":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        match_480 = re.compile('"mp4_480":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        match_720 = re.compile('"mp4_720":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        match_1080 = re.compile('"mp4_1080":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        baseurl = "https://{}/videos/{}/".format(server,videos.replace("_","/"))
        if match_240:  videourl = "{}{}".format(baseurl, match_240[0].replace(".",".mp4?extra=") )
        if match_360:  videourl = "{}{}".format(baseurl, match_360[0].replace(".",".mp4?extra=") )
        if match_480:  videourl = "{}{}".format(baseurl, match_480[0].replace(".",".mp4?extra=") )
        if match_720:  videourl = "{}{}".format(baseurl, match_720[0].replace(".",".mp4?extra=") )
        if match_1080: videourl = "{}{}".format(baseurl, match_1080[0].replace(".",".mp4?extra=") )
    
    else: #older styple
        
        import time
        base_str = "https://{}/method/video.sig?callback=jQuery31105973447211193958_1530417119721"
        base_str = "https://{}/method/video.sig?callback=jQuery311"
        
        base_str = base_str + "&token={}&videos={}&extra_key={}&ckey={}&sig={}&_={}"
        intermediate_url = base_str.format(server,token,videos,extra_key,ckey,sig,int(time.time()))
        #utils.kodilog(intermediate_url)
        http_referrer = url #encode this in http command
        response = utils.getHtml ( intermediate_url, http_referrer)
        utils.kodilog(response)

        match_240 =  re.compile('"mp4_240":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
        match_360 =  re.compile('"mp4_360":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
        match_480 =  re.compile('"mp4_480":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
        match_720 =  re.compile('"mp4_720":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
        #2019-06-06 site says it has 1080, but requires special addon....yeah...right
        match_1080 = re.compile('"mp4_1080":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)

        if match_240:
            try:    extra_key = re.compile('"240":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            except: pass
            videourl = "https://{}/{}&extra_key={}&videos={}".format(server, match_240[0].replace("\/","/").strip("https://"), extra_key, vid_id )
        if match_360:
            extra_key = re.compile('"360":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            videourl = "https://{}/{}&extra_key={}&videos={}".format(server, match_360[0].replace("\/","/").strip("https://"), extra_key, vid_id )
        if match_480:
            extra_key = re.compile('"480":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            videourl = "https://{}/{}&extra_key={}&videos={}".format(server, match_480[0].replace("\/","/").strip("https://"), extra_key, vid_id )
        if match_720:
            extra_key = re.compile('"720":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            videourl = "https://{}/{}&extra_key={}&videos={}".format(server, match_720[0].replace("\/","/").strip("https://"), extra_key, vid_id )
        if match_1080:
            try:
                extra_key = re.compile('"1080":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
                videourl = "https://{}/{}&extra_key={}&videos={}".format(server, match_1080[0].replace("\/","/").strip("https://"), extra_key, vid_id )
            except:pass

    if videourl:
        Log("videourl={}".format(videourl))
        utils.playvid(videourl, name, download)
    else:
        utils.notify('Oh oh','Couldn\'t find a video')

#__________________________________________________________________________
#

