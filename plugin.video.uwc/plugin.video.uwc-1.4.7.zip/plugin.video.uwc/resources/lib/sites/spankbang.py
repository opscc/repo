'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 NothingGnome

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = 'https://spankbang.com'

SEARCH_URL = ROOT_URL + '/s/'

URL_CATEGORIES = ROOT_URL + '/categories/' 
URL_RECENT = ROOT_URL + '/new_videos/{}/'

MAIN_MODE       = '440'
LIST_MODE       = '441'
PLAY_MODE       = '442'
CATEGORIES_MODE = '443'
SEARCH_MODE     = '444'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color)
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon  )

    List(URL_RECENT, page='1', end_directory=True, keyword='')
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))
    
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon )
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "Page Not Found" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}'".format(keyword)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            regex = '<div class="results(.+)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))
            


    regex = 'div class="video-item".+?<a href="([^"]+)".+?data-src="([^"]+)".alt="([^"]+)".+?((?:class="i-hd">[^<]+<|class="i-len")).+?fa fa-clock-o"></i>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, hd, duration in info:
        if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not thumb.startswith('http'): thumb = "https:" + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration + 'm'
            , noDownload=False)


    np_info=re.compile('<a href="([^"]+)">&raquo;', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            np_url = np_url.replace(" ", "+") #website does not doe this properly for search pages...
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            #Log("np_url='{}'".format(np_url))

            np_number=np_url.split('/')[2]
            if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            #Log("np_number='{}'".format(np_number))

            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title + '/'
    Log("searchUrl='{}'".format(searchUrl))    
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):
    
    cathtml = utils.getHtml(url, '')

    regex = '<a href="(/category/[^"]+)"><img src="([^"]+)"><span>([^<]+)</span>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, thumb, label in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
        utils.addDir(name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb )
        
    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

##    content = '{"cover_image":"//cdnthumb3.spankbang.com/0/5/6/5698662-t6.jpg","stream_raw_id":5698662,"stream_sheet":"//cdnthumb3.spankbang.com/0/5/6/5698662-t9999.jpg","stream_u_id":6507187,"stream_url_1080p":["https://vcdn103.spankbang.com/5/6/5698662-1080p.mp4?st=lLjkWznjxmiIr1M1uST8NQ&e=1563509849"],"stream_url_240p":["https://vcdn103.spankbang.com/5/6/5698662-240p.mp4?st=dGMkyKrAIk9o32TGVmwvEA&e=1563509849"],"stream_url_320p":"","stream_url_480p":["https://vcdn103.spankbang.com/5/6/5698662-480p.mp4?st=AB3zD3WDp8xA-iODImWR9Q&e=1563509849"],"stream_url_4k":"","stream_url_720p":["https://vcdn103.spankbang.com/5/6/5698662-720p.mp4?st=_8tVuigmCOUeVn38DOnN6Q&e=1563509849"],"thumbnail":"//cdnthumb3.spankbang.com/250/5/6/5698662-t6.jpg"}\n'
##    #content = content.replace('stream_url_', '')
##    json_urls = json.loads(content)
##    Log("json_urls={}".format(json_urls))
##
##    match = None
##    match_4k = json_urls["stream_url_4k"]
##    match_1080 = json_urls["stream_url_1080p"]
##    match_720 = json_urls["stream_url_720p"]
##    match_480 = json_urls["stream_url_480p"]
##    match_320 = json_urls["stream_url_320p"]
##    match_240 = json_urls["stream_url_240p"]
##
##    if match_4k and utils.addon.getSetting("allow_super_high_resolution").lower() == "true": match = match_4k
##    elif match_1080: match = match_1080
##    elif match_720: match = match_720
##    elif match_480: match = match_480
##    elif match_320: match = match_320
##    elif match_240: match = match_240
##
##    Log("match={}".format(match))
##    Log("match={}".format(type(match)))
##    if type(match) == list:
##        match = match[0]
##        Log("match={}".format(match))
##        Log("match={}".format(type(match)))
##
##    return
##    
    html = utils.getHtml(url, '')
    stream_key = re.compile("data-streamkey=\"([^\"]+)\"").findall(html)[0]
    #Log(stream_key)
    from requests import Request, Session
    s = Session()
    url = ROOT_URL + "/api/videos/stream"
    headers = {"User-Agent": utils.USER_AGENT
               , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
               , "Referer": url
               }
    data = "id={}&data=0".format(stream_key)
    #Log(data)
    req = Request('POST', url, data=data, headers=headers)
    prepped = s.prepare_request(req)
    resp = s.send(prepped , verify=False)
    Log("resp.content='{}'".format(repr(resp.content)))

    json_urls = json.loads(resp.content)
    Log("json_urls={}".format(json_urls))

    match = None
    match_4k = json_urls["stream_url_4k"]
    match_1080 = json_urls["stream_url_1080p"]
    match_720 = json_urls["stream_url_720p"]
    match_480 = json_urls["stream_url_480p"]
    match_320 = json_urls["stream_url_320p"]
    match_240 = json_urls["stream_url_240p"]

    if match_4k and utils.addon.getSetting("allow_super_high_resolution").lower() == "true": match = match_4k
    elif match_1080: match = match_1080
    elif match_720: match = match_720
    elif match_480: match = match_480
    elif match_320: match = match_320
    elif match_240: match = match_240

##    Log("match={}".format(match))
##    Log("match={}".format(type(match)))
    if type(match) == list:
        match = match[0]
##        Log("match={}".format(match))
##        Log("match={}".format(type(match)))
        
    
    #Log(match)
    if match:
        utils.playvid(match, name, download)
    else:
        utils.notify('Oh oh','Couldn\'t find a video')

