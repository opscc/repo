'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://www.freeomovie.com"

SEARCH_URL = ROOT_URL + '/?s='

URL_RECENT = ROOT_URL + '/page/{}/'

URL_CATEGORIES = ROOT_URL

MAIN_MODE       = '370'
LIST_MODE       = '371'
PLAY_MODE       = '372'
CATEGORIES_MODE = '373'
SEARCH_MODE     = '374'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon )

    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))         
    listhtml = utils.getHtml(list_url)

    regex = '<h2><a href="([^"]+)".*?title="([^"]+)">.+?<img src="([^"]+)".+? width="'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for url, label, thumb in info:
        label = utils.cleantext(label)
        #Log("label={}".format(label))
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = url 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , noDownload=False)
        


    next_page_regex = "class=\"nextpostslink\".+?href=\"([^\"]+)\""
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        #Log("np_info={}".format(np_info))
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            np_number = '' #page number can be multiple places depending if search result or not
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if not np_number.isdigit(): np_number=np_url.split('/')[6]
            if not np_number.isdigit(): np_number=np_url.split('/')[7]
            
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):
    html = utils.getHtml(url, '')

    regex = "\"cat-item.+?href=\"([^\"]+)\".+?>([^<]+)<"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    Log("info='{}'".format(info))
    for url, label in info:
        #if url.startswith('/'): url = ROOT_URL + url
        #if thumb.startswith('/'): thumb = ROOT_URL + thumb
        #Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon )

    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])   
def Playvid(url, name, download=None):

    utils.PLAYVIDEO(url, name, download)
    return

    html_src = utils.getHtml(url, ROOT_URL)

    regex = "\(p,a,c,k,e,d\).+?}\('(.*?),(\d+),(\d+),'(.*?)'"
    packed_src = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html_src)
    if not packed_src:
        return
    else:
        packed_src = packed_src[0]

    temp_esc_char = "@@@"
    packed_src = packed_src.replace("\\'", temp_esc_char)

    regex = "'([^\\']+)',(\d+),(\d+),'([^\\']+)'"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(packed_src)    
##    Log("info='{}'".format(info))
    for p, a, c, k in info:
        p = p.replace(temp_esc_char,"\'")
        k = k.split("|")
##        Log("p='{}'".format(p))
##        Log("a='{}'".format(a))
##        Log("c='{}'".format(c))
##        Log("k='{}'".format(k))
        source_js = utils.dePacked(p,a,c,k,None,None)
##        Log("source_js='{}'".format(source_js))
        regex = '{sources:\["([^"]+)"'
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_js)
        video_url = sources[0]
        Log("video_url='{}'".format(video_url))

        utils.playvid(video_url, name, download)
