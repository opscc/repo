'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import re
import sys
import random
import urllib


import inputstreamhelper
import time

try:
    import simplejson
except:
    import json as simplejson   

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib import websocket


import socket

__user_agent__ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"

CAMGIRLSERVER = None
CAMGIRLCHANID = None
CAMGIRLUID = None
CAMGIRL = None
CXID = None
CTXENC = None
TKX = None

def log(msg='', loglevel=xbmc.LOGERROR):
    debug = None
    try:
        debug = (addon.getSetting('debug').lower() == "true")
    except:
        debug = False
        
    if debug == True:
        xbmc.log(msg , xbmc.LOGNONE)
    else:
        xbmc.log(msg)


@utils.url_dispatcher.register('270')
def Main():
    List('https://www.myfreecams.com/mfc2/php/online_models_splash.php')


@utils.url_dispatcher.register('271', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml2(url)
    except:
        
        return None
    match = re.compile("model_detail=(.*?)&.*?img src=(.*?)jpg.*?</div>", re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, img in match:
        url = name
        name = utils.cleantext(name)
        img = img + 'jpg'
        #url = img[32:-17]
        img = img.replace('90x90','300x300')
        #if len(url) == 7:
        #    url = '10' + url
        #else:
        #    url = '1' + url
        utils.addDownLink(name, url, 272, img, '', noDownload=True)
    xbmcplugin.endOfDirectory(utils.addon_handle)
    



@utils.url_dispatcher.register('272', ['url', 'name'])
def Playvid(url, name):
    videourl = myfreecam_start(url)
    if videourl:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")

##        if  videourl.endswith('.m3u8'):
##            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
##            listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
##            listitem.setProperty("IsPlayable","true")
##            listitem.setPath(str(videourl))

        listitem = xbmcgui.ListItem(path=videourl)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})

        if  videourl.endswith('.mpd') or ('.m3u8'  in videourl):
            is_helper = inputstreamhelper.Helper('mpd')
            listitem.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            listitem.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            listitem.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+__user_agent__)
            
            if  videourl.endswith('.mpd'):
                listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            else:
                listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            listitem.setProperty("IsPlayable","true")


        if int(sys.argv[1]) == -1:
            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            pl.clear()
            pl.add(videourl, listitem)
            xbmc.Player().play(pl)
        else:
            xbmcplugin.setResolvedUrl(utils.addon_handle, True, listitem)

    #else:
        #utils.notify('Oh oh','Couldn\'t find a playable webcam link')
        
        
vs_str={}
vs_str[0]="PUBLIC"
vs_str[2]="AWAY"
vs_str[12]="PVT"
vs_str[13]="GROUP"
vs_str[90]="CAM OFF"
vs_str[127]="OFFLINE"
vs_str[128]="TRUEPVT"

def valid_info():
    return ( (CAMGIRLSERVER > 0)
             and CAMGIRLCHANID
             and CAMGIRLUID
             and CAMGIRL
             and CXID
             and CTXENC
             and TKX )
    
def fc_decode_json(m):
    try:
        m = m.replace('\r', '\\r').replace('\n', '\\n')
        return simplejson.loads(m[m.find("{"):].decode("utf-8","ignore"))
    except:
        return simplejson.loads("{\"lv\":0}")

def read_model_data(m, camgirl_to_find):
    global CAMGIRLSERVER
    global CAMGIRLCHANID
    global CAMGIRLUID
    global CAMGIRL
    global CXID
    global CTXENC
    global TKX

    msg = fc_decode_json(m)
    log( "msg:%s" % simplejson.dumps(msg) )

    try:
        if msg['uid'] == 0:
            return # these lines don't have any more useful information    
    except:
        pass

    try:
        CXID = msg['cxid']
        CTXENC = urllib2.unquote(msg['ctxenc'])
        TKX = msg['tkx']
        return # these lines don't have any more useful information
    except:
        pass

    if CAMGIRL:
        log("camgirl already found" )
        return
    
    try:
        CAMGIRLUID    = msg['uid']
        CAMGIRLCHANID = msg['uid'] + 100000000  #1e8 means public chat; ther is also 2e8 and 4e8

        if camgirl_to_find == msg['nm']:
            CAMGIRL = msg['nm'] #make sure we know who we are talking to:  'nm' can exist multiple places
            CAMGIRLSERVER = -1

        #vs = visibility status; 0 value means in public chat...don't know how to parse group/private chats
        vs = msg['vs']
        if vs != 0:
            vs_string=vs_str[vs]
            log("visibility status:{} {}".format(vs,vs_string) )
            return

        u_info=msg['u']
        try:
            if camgirl_to_find == msg['nm']:
                CAMGIRLSERVER = u_info['camserv']
                if CAMGIRLSERVER >= 1545 and CAMGIRLSERVER <= 1559:
                    CAMGIRLSERVER = CAMGIRLSERVER - 1000
                elif CAMGIRLSERVER >= 500:
                    CAMGIRLSERVER = CAMGIRLSERVER - 500

        except KeyError:
            CAMGIRLSERVER=-1
    
    except Exception, e:
        #log(('parsing msg dictionary for name:%s' % str(e) ), xbmc.LOGERROR)
        pass

def getChatServerWebsocket():
    #internal chat server list
    #acutal list at https://m.myfreecams.com/configproxy.php
    xchat=[
        20, 22, 23, 24, 25, 28, 29,
        30, 31, 32, 33, 34, 35, 36, 39,
        40, 41, 42, 43, 44, 45, 46, 47, 48, 49,
        56, 57, 58, 59, 60,
        60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
        70, 71, 72, 73, 74, 75, 76, 77,
        83, 84, 85, 86, 87, 88, 89,
        96, 97, 98, 99,
        100, 101, 102, 103, 104, 105, 106,
        120, 121, 122, 123, 124, 125, 126, 127
      ]

    #connect to one of the chat servers; random since we don't know how to parse page
    #we need to use 8080 because the other choice, https, does not work with websocket
    server_number = str(random.choice(xchat))

    host = "ws://xchat"+server_number+".myfreecams.com:8080/fcsl"
    try:
        log('attempt connecting to host ' + str(host))
        ws = websocket.WebSocket()
        ws = websocket.create_connection(host)
        ws.send("hello fcserver\n\0")
        #ws.send("1 0 0 20071025 0 guest:guest\n\0")
        ws.send("1 0 0 20071026 0 guest:guest\n\0")
        return ws
    except:
        utils.notify('Oh oh','xchat server {} could not be opened. Try again'.format(server_number))
        return None

def getCamgirlInfo(camgirl_to_find, mfcServerWebsocket):

    global CAMGIRLCHANID
    global CAMGIRLSERVER
    global CAMGIRLUID
    global CAMGIRL

    CAMGIRLCHANID = None
    CAMGIRLSERVER = None
    CAMGIRLUID = None
    CAMGIRL = None

    rembuf=''
    sock_buf=None
    quitting = 0
    fc_type = None
    fc=None

    #log("sending search query for %s" % camgirl_to_find )
    mfcServerWebsocket.send("10 0 0 20 0 %s\n\0" % camgirl_to_find)
    
    while quitting == 0:
        
        sock_buf = mfcServerWebsocket.recv()
        sock_buf = rembuf+sock_buf
        rembuf=''

        while True:
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX

            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            if bool(hdr) == 0:
                log("recv() again")
                break #recv() again for the response we need

            fc = hdr.group(1)
            mlen   = int(fc[0:4])
            fc_type = int(fc[4:]) #the fourth byte is the type we need
            msg=sock_buf[4:4+mlen]
            if len(msg) < mlen:
                log("len(msg) < mlen")
                rembuf=''.join(sock_buf)
                break
            
            read_model_data(urllib.unquote(msg), camgirl_to_find) 

            if CAMGIRL == camgirl_to_find:
                #log("CAMGIRL == camgirl_to_find:")
                quitting=1
                break
                
            #log("fc_type {} was found".format(fc_type))
            #if fc_type == 1:
                #mfcServerWebsocket.send("10 0 0 20 0 %s\n\0" % camgirl_to_find)
            #elif fc_type == 10:
                #time.sleep(0.1)
            #    log("fc_type == 10")
            #    quitting=1
            #    break

            sock_buf=sock_buf[4+mlen:]
            if len(sock_buf) == 0:
                break

    newServer = (CAMGIRLSERVER >= 545 and CAMGIRLSERVER <= 559) #HLS servers
    return CAMGIRLSERVER, CAMGIRLCHANID, newServer


def myfreecam_start(camgirl_to_find):

##    Url='http://leaderpro.pt:25461/live/asdf/asdf/285.ts' #TLC
##    Url='http://leaderpro.pt:25461/live/asdf/asdf/365.ts'
##    Url='http://leaderpro.pt:25461/live/asdf/asdf/397.ts'#tvfatima
##    Url='http://leaderpro.pt:25461/live/asdf/asdf/9736.ts'#fox
##    Url='http://leaderpro.pt:25461/live/asdf/asdf/16781.ts'#fox
##    Url='http://leaderpro.pt:25461/live/asdf/asdf/420.ts'#cnn
##    Url='http://leaderpro.pt:25461/live/asdf/asdf/438.ts'#tvi24
##    Url='http://leaderpro.pt:25461/live/asdf/asdf/15016.ts'#hbo1
##    Url='http://leaderpro.pt:25461/live/asdf/asdf/14873.ts'#history
##    #Url='http://leaderpro.pt:25461/live/asdf/asdf/397.ts'#tvfatima
##
##    from F4mProxy import f4mProxyHelper
##    f4mp=f4mProxyHelper()
##    f4mp.playF4mLink(
##             Url
##             ,'channel name'
##             ,proxy=None
##             ,use_proxy_for_chunks=False
##             ,maxbitrate=0
##             ,simpleDownloader=False
##             ,auth=None
##             ,streamtype='TSDOWNLOADER'
##             ,setResolved=False
##             ,swf=None
##             ,callbackpath=''
##             ,callbackparam=''
##             ,iconImage=''
##             )
##    return ''


    #global CAMGIRLSERVER
    #global CAMGIRLUID
    #global CAMGIRLCHANID
    #global CAMGIRL

    #url = 'MissDivinna'
    #log("LMM:" + url)

##    #log into the chat/security server as a guest; these are the server names bsed on try and error
##    #acutal list at https://m.myfreecams.com/configproxy.php
##    
##    xchat=[
##            20, 22, 23, 24, 25, 28, 29,
##            30, 31, 32, 33, 34, 35, 36, 39,
##            40, 41, 42, 43, 44, 45, 46, 47, 48, 49,
##            56, 57, 58, 59, 60,
##            60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
##            70, 71, 72, 73, 74, 75, 76, 77,
##            83, 84, 85, 86, 87, 88, 89,
##            96, 97, 98, 99,
##            100, 101, 102, 103, 104, 105, 106,
##            120, 121, 122, 123, 124, 125, 126, 127
##          ]
##
##    #connect to one of the chat servers; random since we don't know how to parse page
##    #we need to use 8080 because the other choice, https, does not work with websocket
##    server_number = str(random.choice(xchat))
##    host = "ws://xchat"+server_number+".myfreecams.com:8080/fcsl"
##    try:
##        log('attempt connecting to host ' + str(host))
##        ws = websocket.WebSocket()
##        ws = websocket.create_connection(host)
##        ws.send("hello fcserver\n\0")
##        #ws.send("1 0 0 20071025 0 guest:guest\n\0")
##        ws.send("1 0 0 20071026 0 guest:guest\n\0")
##    except:
##        #e = sys.exc_info()[0]
##        utils.notify('Oh oh','xchat server {} could not be opened. Try again'.format(server_number))
##        #utils.notify('Oh oh', str(e))
##        time.sleep(3)
##        return ''
##
##    #log("CAMGIRLSERVER after fcsl" + str(CAMGIRLSERVER))

    ws = getChatServerWebsocket()

    rembuf=""
    quitting = 0
    while quitting == 0:
        
        sock_buf =  ws.recv()
        sock_buf=rembuf+sock_buf
        
        rembuf=""
        while True:
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX

            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            if bool(hdr) == 0:
                break #recv() again for the response we need

            fc = hdr.group(1)

            mlen   = int(fc[0:4])
            fc_type = int(fc[4:]) #the fourth byte is the type we need

            msg=sock_buf[4:4+mlen]

            if len(msg) < mlen:
                rembuf=''.join(sock_buf)
                break

            #log("LMM: sockbuf:%s" % sock_buf )
            
            msg=urllib.unquote(msg)

            read_model_data(msg, camgirl_to_find) 

            if fc_type == 1:
                ws.send("10 0 0 20 0 %s\n\0" % camgirl_to_find)
                log("fc_type 1 was found")
            elif fc_type == 10:
                #read_model_data(msg) # ?????we need two read_model_data to capture the ctxenc information
                time.sleep(0.1)
                quitting=1

            sock_buf=sock_buf[4+mlen:]

            if len(sock_buf) == 0:
                break

            if valid_info():
                quitting=1
                break

    ws.close()


    if not valid_info():
        utils.notify( ("{} is not online".format(camgirl_to_find)))
        return ''

    #sometimes the websockets will return informatino from other camgirls...make sure we get the one we want
    #log("CAMGIRL:'{}'url:'{}'".format(CAMGIRL, url)) 
    #if CAMGIRL != url:
    #    utils.notify( ("{} is not online".format(url)))
    #    return ''
    
    #mobile site
    Url="http://video"+str(CAMGIRLSERVER)+".myfreecams.com:1935/NxServer/ngrp:mfc_"+str(CAMGIRLCHANID)+".f4v_mobile/playlist.m3u8" 
    #Url="http://video"+str(CAMGIRLSERVER)+".myfreecams.com:1935/NxServer/ngrp:pvt_"+str(1e8 + CAMGIRLCHANID)+"_1.f4v_mobile/playlist.m3u8" 

    try:
        head = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
        log('attempt connecting to host {}|{}'.format(Url,head))
        #socket.setdefaulttimeout(3)
        req = urllib2.Request(Url)
        req.add_header('User-Agent', head)
        try:
            aa = urllib2.urlopen(req, timeout=2)
            log("aa contents '%s' " % aa.read().encode('UTF-8'))

##            from F4mProxy import f4mProxyHelper
##            f4mp=f4mProxyHelper()
##            f4mp.playF4mLink(
##                        Url
##                        ,'channel name'
##                        ,proxy=None
##                        ,use_proxy_for_chunks=False
##                        ,maxbitrate=0
##                        ,simpleDownloader=False
##                        ,auth=None
##                         ,streamtype='HLS'
##                         ,setResolved=False
##                         ,swf=None
##                         ,callbackpath=''
##                         ,callbackparam=''
##                         ,iconImage=''
##                         )
##            return ''
            
            #comment out to try ther other x-hls format
            return Url
        except:
            log("unable to open Url %s" % Url)
            #utils.notify( ("{} is not online".format(camgirl_to_find)))
            
            
        #try new servers
            #
        Url="https://video{}.myfreecams.com:8444/x-hls/{}/{}/{}/mfc_a_{}.m3u8".format(
            CAMGIRLSERVER
            , CXID
            , CAMGIRLCHANID
            , CTXENC
            , CAMGIRLCHANID
            ) 
        log('attempt connecting to HLS host {}|User-Agent={}'.format(Url,head))
        req = urllib2.Request(Url)
        req.add_header('User-Agent', head)
        try:
            aa = urllib2.urlopen(req, timeout=2)
            Url = Url +('|user-agent='+head)
            log('returning URL ' + Url)
            return Url
        except:
            log("exception open Url %s" % Url)
            #utils.notify( 'Oh oh', ("URL for {} is not responding".format(CAMGIRL)))
            Url = ''


        if Url == '':
            utils.notify( 'Oh oh', ("URL for {} is not responding".format(camgirl_to_find)))

                    
    except Exception, e:
        log(('attempt connecting to err:%s' % str(e) ), xbmc.LOGERROR)
        return ''
                            

    #desktop site
    #Url="https://video"+str(CAMGIRLSERVER)+".myfreecams.com/NxServer/ngrp:mfc_"+str(CAMGIRLCHANID)+".f4v_desktop/manifest.mpd"

    utils.notify( ("{} is not online".format(camgirl_to_find)))
    return Url

