'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import os
import os.path
import sys
import traceback
import xbmc
import xbmcplugin

from resources.lib import downloader
from resources.lib import favorites
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C
#required for registering modes into dispatcher
from resources.lib import configure 
from resources.lib import search 
from resources.lib import tests 
from resources.lib.sites import * 

if int(sys.argv[1]) > 0: 
    xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available

#__________________________________________________________________________
# random dev stuff
@C.url_dispatcher.register("devtest")
def TempDevTest():

##    reload(downloader)
    import threading

    name = 'test name.htls.ts'
    download_path = 'c:\\temp\\thetemp 2\\season 3\\test name.htls.ts'
    if download_path is None:
        download_path = downloader.Make_download_path(name, file_extension = '.ts')                    

    
    downloader.Background_HLSDownloader(url='https://old.reddit.com/r/Cooking/comments/174zpk2/what_food_is_so_good_you_cant_believe_its_healthy/'
                                        ,download_path=download_path
                                        ,name=name
                                        ,stop_event=threading.Event()
                                        ,repeat_when_available=False
                                        ,rowid=0
                                        )
                                        
    return

##    server='1.1.1.1'
####    server='192.168.10.49'    
##    port='443'
####    server='127.0.0.1'
####    port='1025'
##
##    import socket
##    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
##    s.settimeout(3)
##    try:
##        qq = s.connect_ex((server, int(port)))
##        if not qq == 0: raise Exception(qq)
####        msg = "GET / HTTP/1.0\r\n\r\n"
####        Log(repr(msg.encode('utf-8')))
####        s.sendall(msg.encode('utf-8'))
####        while 1: 
####            Log(" Fourth tr-except block -- waiting to receive data from remote host ")
####            try:
####                Log('d')
####                buf = s.recv(256)
####                Log('3')
####            except socket.error as e: 
####                Log("Error receiving data: %s" % e) 
####                return
####            if not len(buf): 
####                break 
####            # write the received data
####            Log(buf.decode('utf-8'))
##        
##    except socket.error as msg:
##        Log(repr(msg)) ##if msg.errno == 10051: #not reachable
##        return False
##    except:
##        traceback.print_exc()
##    finally:
##        s.close()

    import resolveurl
    link = 'https://watchx.top/v/Xu3oWM6VVA0y/'
    link = 'https://dood.yt/e/lc6n1ifj7b8hj6vqwkep9kr2s61d8rfp'
    link = 'https://filemoon.sx/e/08duxohvd6bs/citadel_s01e03_1080p_web_h264-cakes'
##    link = (link+'|'+utils.urllib.urlencode({'Referer':'https://netmovies.to/'}))
##    vid = resolveurl.resolve(link)
    vid = 'https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/1080/index.m3u8,[720]https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/720/index.m3u8,[360]https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/360/index.m3u8,[auto]https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/playlist.m3u8'
    vid = 'https://rouf.magnewscontent.org/_v10/a5a6c0270c4ca786d12ee89e024df4d4754e581a0709cc645a98b763b4a400cd76a390106e30052b6cfa7835661bbfe6b3103114f7e1aba1e587e5cb9c42d7caac1a5532bef1f1b91d11b4e980f949f9c0805fe61348a3bac4a9ff70bde4e05bafb33ea5909a6a05ce3b2d248326830d3fc43b1a86d5f39e3e498bb0f48dbfd5/1080/index.m3u8'

    Log(repr(vid))
##    return
    utils.playvid(vid
                  ,'maiseltest'
                  ,description = u'mail'
                  ,download=True
##                  ,play_profile='profile_00' #download
##                  ,play_profile='profile_04'
##                  ,playmode_string = C.PLAYMODE_F4MPROXY
##                  ,play_profile=C.DEFAULT_PROFILE_NAME
##                  ,playmode_string = C.PLAYMODE_DIRECT
                  )
    utils.endOfDirectory()
    
    return
##    import xbmcgui
##    progress_dialog = xbmcgui.DialogProgressBG()
##    progress_dialog.create('header','message') #reloading skin will hide existing progress
##    progress_dialog.close()
##    
##    #utils.endOfDirectory() 
##    return
##    import os
##    f1 = u'[\/:*"<>|this  mom?].mp4'
##    f2 = u"c:\\temp\\" + utils.Clean_Filename(f1, include_square_braces=False)
##    Log(repr(f2))
##    os.rename(u"C:\\Temp\\mom.mp4", f2)
####    utils.endOfDirectory()
##    return
##
##    downloader.Stop_Download(u'https://psv143-1.crazycloud.ru/vkvd208.mycdn.me/?expires=1681049954345&srcIp=95.215.205.11&pr=40&srcAg=UNKNOWN&ms=185.226.53.199&type=3&sig=KX33kr3jRZw&ct=0&urls=45.136.21.205&clientType=14&appId=512000384397&zs=43&id=2893745228451&videos=-115615196_456279816&extra_key=M9Iji3AZuCWAd57aXMcfVA&videos=-115615196_456279816|verifypeer=false&Accept-Language=en-US%2Cen%3Bq%3D0.9&Accept-Encoding=gzip%2C+deflate&Accept=%2A%2F%2A&User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A91.0%29+Gecko%2F20100101+Firefox%2F91.0&Referer=https%3A%2F%2Fdaft.sex%2Fwatch%2F-115615196_456279816', u'[TrueAnal] Jazlyn Ray - Jazlyn\u2019s Backdoor Cravings', False, None, None)
##    return
##
##    try:
##
##        import xbmcgui
##     
##        #std::unique_ptr< std::vector< int > > 	multiselect #
##        #(const String &heading
##        #,const std::vector< Alternative< String, const ListItem * > > &options
##        #, int autoclose=0
##        #, const std::vector< int > &preselect=std::vector< int >()
##        #, bool useDetails=false)
##        choices = [] #'all', 'movies', 'musicvideos', 'tvshows']
##
##        for a in range(9):
##            listitem = xbmcgui.ListItem(
##                label = str(a)
##                , path= 'path' + str(a)
##                )
##            listitem.setArt( #setart because other method deprecated
##                    {
##                        "icon" : "DefaultVideo.png"
##                        , "thumb": "DefaultVideo.png"
##                    }
##                )
##            choices.append(listitem)
##    
##        
##        import xbmcgui
####        dd = xbmcgui.Dialog().multiselect('title', choices, useDetails=True)
####        Log(repr(dd))
##
####            - 1 : ShowAndGetFile
####            - 2 : ShowAndGetImage
#### shares from "C:\Program Files (x86)\Kodi\userdata\iOS\sources.xml"
##        files = xbmcgui.Dialog().browseMultiple(type=1, heading='Select files'
##                                                , shares='pictures'
##                                                , useThumbs=True)
##        Log(repr(files))
##    except:
##        traceback.print_exc()
##    
###    service.reboot_required_detection()
##    
####    try:
####        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
####        Log(repr(json.loads(val)['result']['value']))
####
####        #xbmc.executebuiltin('RunScript("C:\\Users\\bob\AppData\\Roaming\\Kodi\\addons\\skin.lyrebird\\scripts\\myscript.py")', True)
####        #xbmc.executebuiltin('RunScript("skin.lyrebird.scripts.myscript")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"scripts.myscript")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"scripts.myscript.py")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"myscript.py")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"myscript")', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,myscript.py)', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,myscript)', True)
####        xbmc.executebuiltin('RunScript(script.toolbox,"scripts\\myscript.py")', True)
####        #err msg  xbmc.executebuiltin('RunScript(script.toolbox.myscript)')
####        #err msg  xbmc.executebuiltin('RunScript(script.toolbox.myscript.py)')
####        
####        val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
####        Log(repr(json.loads(val)['result']['value']))
####    except:
####        traceback.print_exc()
##    
##
#####    Log(xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"audiooutput.audiodevice"},"id":1}'))
####    val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
####    Log(repr(json.loads(val)['result']['value']))
######    Log(repr(val))
######    Log(repr(dir(val)))
######    Log(repr(val['result']['value']))
######    val = val['result']['value']
####    val = (json.loads(val)['result']['value'])
####    result = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy","value":' + str(not(val)).lower() + '}, "id":1}')
####    Log(repr(result))
####    val = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"},"id":1}')
####    Log(repr(json.loads(val)['result']['value']))
##
####    <setting id="network.httpproxypassword" default="true"></setting>
####    <setting id="network.httpproxyport">1025</setting>
####    <setting id="network.httpproxyserver">127.0.0.1</setting>
####    <setting id="network.httpproxytype" default="true">0</setting>
####    <setting id="network.httpproxyusername" default="true"></setting>
####    <setting id="network.usehttpproxy" default="true">false</setting>
##    
##    utils.endOfDirectory()
##    return
##
##    Log('pycrypt not available using slow decryption') #, xbmc.LOGNONE)
##    USEDec=3 ## 1==crypto 2==local, local pycrypto
##
##    import array
##    import base64
##    from f4mUtils import python_aes
####    from f4mUtils import openssl_aes
##
##    pass_ph = '5ee595b1c1150a9bb64ab546cc2e4e28' #was hex string; then base64decoded
##    Log(repr(pass_ph))
##    Log(repr(base64.b64encode(pass_ph)))
##    Log(repr(array.array('B',base64.b64encode(pass_ph))))
##
##    iv = (
##        'f8b83c54b42e8f03'
##        )
####            5ee595b1c1150a9bb64ab546cc2e4e28    
######          123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
######          4e57566c4e546b31596a466a4d5445314d474535596d49324e4746694e54513259324d795a54526c4d6a673d
####            4e57566c4e546b31596a466a4d544531
####            4d474535596d49324e4746694e545132
####            59324d795a54526c4d6a673d
##    key  = (
##        '2a265272f02233b6'
##        'f5a6bbc5008bdd5b'
##        )
####    key="NWVlNTk1YjFjMTE1MGE5YmI2NGFiNTQ2Y2MyZTRlMjg="
####    key = base64.b64decode(key)
###    iv = ''
##
##    MODE_CBC = 2
##    BLOCK_SIZE = 16
##    def pad(data):
##        length = BLOCK_SIZE - (len(data) % BLOCK_SIZE)
##        return data + chr(length)*length
##    def unpad(data):
##        return data[:-ord(data[-1])]
##    def encrypt(message, key, IV):
##        #IV = Random.new().read(BLOCK_SIZE)
##        aes = python_aes.new(key, MODE_CBC, IV)
##        return base64.b64encode(IV + aes.encrypt(pad(message)))
##    def decrypt(encrypted, key):
##        encrypted = base64.b64decode(encrypted)
##        IV = encrypted[:BLOCK_SIZE]
##        ivb = array.array('B',IV)
##        aes = python_aes.new(key, MODE_CBC, ivb)
##        tt = aes.decrypt(encrypted[BLOCK_SIZE:])
##        return unpad(tt)
##
##    ivb=array.array('B',iv)
##    keyb= array.array('B',key)
##    Log("python_aes.new(keyb, MODE_CBC, ivb)")
##    Log("keyb={}".format(repr(keyb)))
##    Log("ivb={}".format(repr(ivb)))
##    MODE_CBC = 2
##    enc=python_aes.new(keyb, MODE_CBC, ivb)
####    enc=openssl_aes.new(keyb, 2, ivb)
##
##
##    chunk = "Ygy+6ap2h0PB5sCy3s1OhNpgYsSayyyD7wFLdJ0K4JnNhydK0FTvxxbqwB02DoM423Dgukk4uLh1by60MLi9rSIqj3eg0Yad8PEHIXav82xduDDsjgfTRyqYNN+prdWjfBG+a08SXM2xJM+EjyxPbwbTMmYX7twRfwzcKxLs79uEpH36X3A/kLpew2Ydv8jsHT2oEWdz4LQVhcC971qo+4BBZUbDX+LIdCon26uleK3UpQPKIWuBkcn01Zj/LzMlk3agSq8mHEnIWFUrdnYOMjoqyFsmyTkpbtIhdzLwVPc="
##
####    Log(repr(decrypt(chunk, keyb)))
##
##    #chunk = chunk[BLOCK_SIZE:]
##    chunk = base64.b64decode(chunk)
###    chunk = pass_ph + chunk
###    Log("array")
##    chunkB = array.array('B',chunk)
##    Log("chunkB={}".format(repr(chunkB)))
####    Log("decrypt")
##    chunk = enc.decrypt(chunkB)
####    Log("join")
##    chunk = "".join(map(chr, chunk))
##    #Log('end decrypting chunk, USEDec={}'.format(USEDec))
##    Log(repr(chunk))
####    Log('afterdecrypting' + repr(chunk.encode('utf8')))
##
##
###url = 'https://dood.to/e/4la4btw5nspt'
###import resolveurl
###u = resolveurl.resolve(url)
###Log(repr(u), xbmc.LOGNONE)
###Log(repr(sys.version), xbmc.LOGNONE)
###Log('')
####xx = utils.getHtml("https://www.imdb.com/chart/top" )
####import requests
####xx = requests.get(
####    "https://www.imdb.com/chart/top" 
####    , headers={'User-agent': 'Mozilla/5.0'}
####    , timeout=20)
##    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_INDEX)
def INDEX():
    if C.DEBUG:
        utils.addDir(
            name = '[COLOR {}]Test All[/COLOR]'.format(C.test_text_color)
            ,url = C.DO_NOTHING_URL
            ,mode = C.ROOT_TEST_ALL
            ,Folder = True)
        utils.addDir(
            name = '[COLOR {}]Webcam Scan[/COLOR]'.format(C.test_text_color)
             ,url = C.DO_NOTHING_URL
             ,mode = C.ROOT_SERVICE_UPDATE
             ,Folder = False)
        utils.addDir(
            name = '[COLOR {}]Webcam Record ScanStart[/COLOR]'.format(C.test_text_color)
             ,url = C.DO_NOTHING_URL
             ,mode = C.ROOT_SERVICE_SCAN_START
             ,Folder = False)
        utils.addDir(
            name = '[COLOR {}]Latest DevTest[/COLOR]'.format(C.test_text_color)
             ,url = C.DO_NOTHING_URL
             ,mode = "devtest"
             ,Folder = False
            )

    utils.addDir('[COLOR {}]Search All[/COLOR]'.format(C.search_text_color)            ,'',C.ROOT_SEARCH_ALL   ,iconimage=C.search_icon) #, contextMenu=test_all_context_menu)
    utils.addDir('[COLOR {}]Front Pages[/COLOR]'.format(C.refresh_text_color)          ,'',C.ROOT_FRONT_PAGE   ,iconimage=C.search_icon)
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Scenes'.format(C.program_text_color)    ,'',C.ROOT_INDEX_SCENES)
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Movies'.format(C.program_text_color)    ,'',C.ROOT_INDEX_MOVIES) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Hentai'.format(C.program_text_color)    ,'',C.ROOT_INDEX_HENTAI) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Tubes'.format(C.program_text_color)     ,'',C.ROOT_INDEX_TUBES) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Webcams'.format(C.program_text_color)   ,'',C.ROOT_INDEX_CAMS) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Favorites'.format(C.program_text_color) ,'',C.ROOT_INDEX_FAVORITES)

    download_path = utils.get_setting('download_path', str)
    if not (download_path and os.path.exists(download_path)):
        downloader.Make_download_path('')
    utils.addDir(
        name = '[COLOR {}]Whitecream[/COLOR] Download Folder'.format(C.program_text_color)
        ,url = download_path
        ,mode = C.ROOT_INDEX_DOWNLOAD_FOLDER
        ,Folder = False)
        
##    if len(downloader.active_downloads()) > 0 or utils.get_setting('debug'):
    utils.addDir(
        name = '[COLOR {}]Background Downloads[/COLOR]'.format(C.highlight_text_color)
        , url = C.DO_NOTHING_URL
        , mode = C.ROOT_MANAGE_DOWNLOADS
        , Folder=True)
    utils.addDir(
        name='[COLOR {}]Settings[/COLOR]'.format(C.refresh_text_color)
        ,url = C.DO_NOTHING_URL
        ,mode = C.CONFIGURE_THIS_ADDON
        ,Folder=False)

    utils.endOfDirectory(cacheToDisc=False)
#__________________________________________________________________________
# display long-scene sites
@C.url_dispatcher.register(C.ROOT_INDEX_SCENES)
def INDEXS():
    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(C.LIST_AREA_SCENES):
        utils.addDir(friendly,root_url,mode,icon_filespec)
        
    utils.endOfDirectory()
#__________________________________________________________________________
# display full movie sites
@C.url_dispatcher.register(C.ROOT_INDEX_MOVIES)
def INDEXM():
    for friendly, root_url, mode, icon_filespec in utils.Get_Sites(C.LIST_AREA_MOVIES):
        #Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
# display short-clip sites
@C.url_dispatcher.register(C.ROOT_INDEX_TUBES)
def INDEXT():
    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(C.LIST_AREA_TUBES):
##        Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
# display webcam sites
@C.url_dispatcher.register(C.ROOT_INDEX_CAMS)
def INDEXW():
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_CAMS):
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
# display hentai sites
@C.url_dispatcher.register(C.ROOT_INDEX_HENTAI)
def INDEXH():
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_HENTAI):
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
# display first page of some sites
@C.url_dispatcher.register(C.ROOT_FRONT_PAGE, ['page'], ['keyword'])
def Front_Page(page=1,keyword=None):
    #temporarilty force only X recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 0

    import Queue
    import threading

    get_sites = utils.Get_Sites()
    q = Queue.Queue()
    i = 0
    all_method_results = {}
    progress_dialog = None
    progress_dialog = utils.Progress_Dialog(C.addon_name,"front pages...")

    try:
        for sitename, module in get_sites:
##            if i > 2: break #testing

            if module.FRONT_PAGE_CANDIDATE == True:
                if utils.get_setting(sitename + '_on_front_page'):
##                    i = i + 1 #testing
                    all_method_results[sitename] = None
                    method_to_call = getattr(module, 'List')
                    kwargs = {
                        "url": module.URL_RECENT
                        ,"end_directory": False
                        ,"page": module.FIRST_PAGE
                        ,"progress_dialog": progress_dialog
                        }
                    q.put((sitename,method_to_call,kwargs))

        for k in range(C.MAX_WEBCRAWLER_THREADS):
            worker = threading.Thread(target=utils.crawl, args=(q,all_method_results))
            worker.daemon = False
            worker.start()
        q.join()
        get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
    except StopIteration:
        pass
    except:
        traceback.print_exc()

    at_least_one = False
    for result in all_method_results:
        if all_method_results[result] in [None, True]:
            at_least_one = True
            break
            
    if not at_least_one:
        utils.addDir(name='[COLOR {}]Add Sites to this via Settings[/COLOR]'.format(C.refresh_text_color)
            ,url=C.DO_NOTHING_URL
            ,iconimage=C.search_icon
            ,mode=C.ROOT_INDEX_INDEX
            ,Folder=False)

    if progress_dialog: progress_dialog.close()
        
    utils.endOfDirectory()        
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_DOWNLOAD_FOLDER, ['url'])
def OpenDownloadFolder(url):
    xbmc.executebuiltin("ActivateWindow(Videos, {})".format(url))
#__________________________________________________________________________
#
def change():
    if os.path.isfile(C.uwcchange):
        heading = '[B][COLOR {}]Whitecream[/COLOR] Changelog[/B]'.format(C.program_text_color)
        utils.textBox(heading,C.uwcchange)
        os.remove(C.uwcchange)
#__________________________________________________________________________
# edit settings.xml file as necessary
def Dynamic_Front_Pages_Options():
    
    settings_file = os.path.join(C.rootDir, 'resources', "settings.xml")
    import xml.etree.ElementTree as ET
    tree = ET.ElementTree(file=settings_file)

    font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
    if font_pages_element_tree is None:
        ET.SubElement(parent=tree.find("."),tag='category',attrib={'label':"Front Pages"})

    font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
    if font_pages_element_tree is None:
        pass

    for elems in font_pages_element_tree:
        elems.clear()
        elems.attrib['label'] = "Front Pages"
        for sitename, module in utils.Get_Sites():
            try:
                if hasattr(module,"website"):   # experimental; use a class for all websites
                    module = module.website
            except:
                traceback.print_exc()
                pass
            if 'FRONT_PAGE_CANDIDATE' in dir(module):
                if module.FRONT_PAGE_CANDIDATE == True:
                    ET.SubElement(parent=elems,tag='setting',attrib={'id':sitename + '_on_front_page','label':sitename + '_on_front_page','default':'false','type':'bool'})


    import ctypes
    import platform
    import sys
    if platform.system() == 'Windows':
        free_bytes = ctypes.c_ulonglong(0)
        ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(C.rootDir), None, None, ctypes.pointer(free_bytes))
##        Log(repr(free_bytes.value),C.LOGNONE)
        get_free_space_mb = free_bytes.value / 1024.0 / 1024.0
    else:
        st = os.statvfs(settings_file)
        get_free_space_mb = st.f_bavail * st.f_frsize / 1024 / 1024
##    statvfs = os.statvfs(settings_file)
##    Log(repr(get_free_space_mb),C.LOGNONE)
    if get_free_space_mb > 1:
        tree.write(settings_file)
    else:
        Log("Not enough disk space to update settings file '{}'".format(settings_file), C.LOGERROR)
        
#__________________________________________________________________________
#
def main(argv=None):
    if sys.argv: argv = sys.argv
    queries = utils.parse_query(sys.argv[2])
    mode = queries.get('mode', None)
    try:
        mode_via_url = sys.argv[0].split('/')[3]
        mode = str(int(mode_via_url))
    except:
        pass

##    Log(repr((mode, mode_via_url,queries)))
##    Log(repr(__name__))
    Dynamic_Front_Pages_Options()
    try:
        C.url_dispatcher.dispatch(mode, queries)
    except:
##        Log("mode='{}'".format(mode),xbmc.LOGNONE)
        raise
##    try:
##        import service
##        reload(service)
##    except:
##        pass
        
#__________________________________________________________________________
#
if __name__ == '__main__':
##    change()
    sys.exit(main())
#__________________________________________________________________________
#
