'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]pornoxo[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.pornoxo.com"
SEARCH_URL = ROOT_URL + '/search/{}/?sort=re&page={}'
URL_CATEGORIES = ROOT_URL + '/tags/json/'
URL_RECENT = ROOT_URL + '/videos/best-recent/{}/'
URL_TOPRATED = ROOT_URL + "/channels.php"

MAIN_MODE          = C.MAIN_MODE_pornoxo
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon )
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={})".format(repr(url), repr(page), repr(end_directory), repr(keyword)))
    
    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)       

    # read html
    listhtml, redirected_url = utils.getHtml(list_url, send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "Sorry, no videos found" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('id="maincolumn"')[1].split('class="pagination')[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    #
    # parse out list items
    #
    regex = ('(?is)viditem'
            '.+?<a href="(/videos/[^"]+)"'
             '.+?img.+?src="([^"]+)" alt="([^"]+)"'
             '.+?viddata.+?(?:<span class="membership-block private-only"><i class="fa fa-lock"></i></span>|<span).+?((?:class="text-active bold">'
             '.+?</span>|\s))'
             '.+?(\d+:\d+)\s'
             )
    regex = ('(?is)viditem'
            '.+?<a href="(/videos/[^"]+)"'
             '.+?img.+?src="([^"]+)" alt="([^"]+)"'
             #'.+?media-item__info-item--resolution.+?>(.+?)<'
             '()'
             '.+?<span class="media-item__info-item">\s*(\d+:\d+)\s'
             )
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, hd, duration in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    # next page items
    try:
        next_page_html = listhtml.split('class="pagination')[1]
    except:
        next_page_html = listhtml
    next_page_regex = '"([^"]+)">Next</a>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_url = url
        np_number = int(page) + 1
##    for np_url in np_info:
##        np_number = ''
##        if not np_number.isdigit(): np_number=np_url.split('/')[3]
##        if not np_number.isdigit(): np_number=np_url.split('/')[4]
##        if not np_number.isdigit(): np_number=np_url.split('/')[5]
##        if not np_url.startswith('http'): np_url = ROOT_URL + np_url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth): #search some more, but not forever
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)

        
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    #keyword = keyword.replace('+',' ').replace(' ','%20')
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword, '{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    json_html = utils.getHtml(url, ROOT_URL)
    json_items = json.loads(json_html)
    for item in json_items:
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(item['name']))
            ,url=ROOT_URL+item['link']+'{}/'
            ,mode=LIST_MODE
            ,iconimage=item['image']
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))
    
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
##@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
##def Playvid(url, name, download=None, playmode_string=None):
##    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
##    if playmode_string: max_video_resolution=int(playmode_string)
##    else: max_video_resolution = None
##    description = name + '\n' + ROOT_URL
##    video_url = None
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile','icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    videopage = utils.getHtml(url, ROOT_URL)
##    videopage = 'sources: [{"src": "https:\/\/cdn.pornoxo.com\/key=IVU3oblQyV6MJG98-WHL2w,end=1563041646,ip=216.154.65.37\/ip=216.154.65.37\/speed=514178\/buffer=3.0\/2019-06\/hq_43934117335285d42dab7b076fcb225e.mp4", "desc": "720p" ,"active":"true"}, {"src": "https:\/\/cdn.pornoxo.com\/key=2BAi1iE-vFSNcxrVYIpShg,end=1563041646,ip=216.154.65.37\/ip=216.154.65.37\/speed=312550\/buffer=3.0\/2019-06\/43934117335285d42dab7b076fcb225e.mp4", "desc": "480p" ,"active":""},{"src": "https:\/\/cdn.pornoxo.com\/key=dddFvPvYGKaZRsgNBXCqfA,end=1563041646,ip=216.154.65.37\/ip=216.154.65.37\/speed=151364\/buffer=3.0\/2019-06\/m_43934117335285d42dab7b076fcb225e.mp4", "desc": "360p","active":""}],'
##    Log("videopage={}".format(videopage))

    regex = 'sources: \[({"src":[^]]+})\],'
    regex = 'var player = new VideoPlayer(.+?)player.init'
    sources_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    if sources_html:
        sources_html = sources_html[0]
        sources_html = sources_html.replace('\/','/')
        regex = '"src":.*?"([^"]+)".*?"desc":.*?"([^"]+)"'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(sources_html)
##        video_url = utils.SortVideos(sources_list,download=download,vid_res_column=1)
        video_url = utils.SortVideos(
            sources=sources_list
            ,download=download
            ,vid_res_column=1
            ,max_video_resolution=max_video_resolution
            )
    else: #try another method
        regex = '<video.+?src="([^"]+)" type='
        sources_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
        if sources_html:
            video_url = sources_html[0]

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
    
##    utils.playvid(video_url, name=name, download=download, description=description)
    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
    ##            , download_filespec=download_filespec
        , mode = PLAY_MODE
    ##            , url_factory = url
        , icon_URI = icon_URI            
        )      
#__________________________________________________________________________
#
