'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import base64
import os
import random
import re
import tempfile
import sqlite3
import urllib
import urlparse
import xbmc
import xbmcplugin
import xbmcvfs



from resources.lib import webcam_db
from resources.lib import utils
from resources.lib import downloader
from resources.lib.utils import Log as Log
from resources.lib.utils import get_setting as GetSetting

from xbmc import LOGNONE
from resources.lib import constants as C

from sites.chaturbate import clean_database as chaturbate_clean
from sites.cam4 import clean_database as cam4_clean
from sites.streamate import clean_database as streamate_clean
from sites.naked import clean_database as naked_clean
from sites.bongacams import PLAY_MODE as bongacams_PLAY_MODE
from sites.bongacams import clean_database as bongacams_clean
mfc_PLAY_MODE = str(int(C.MAIN_MODE_myfreecams) + C.MODE_PLAY_OFFSET)
from sites.myfreecams import clean_database as mfc_clean
from sites.myfreecams import Camgirl_Generic_Image as mfc_generic_image

import time
import traceback

FAV_DB_VERSION_1 = 1
FAV_DB_VERSION_2 = 2
FAV_DB_VERSION_3 = 3
FAV_DB_VERSION_CURRENT = 2

favoritesdb = C.favoritesdb
downloadsdb = C.downloadsdb

try:  FAV_LIST_LIMIT = GetSetting("FAV_LIST_LIMIT", int)
except:  FAV_LIST_LIMIT = 200
#try:  FAV_LIST_FRACTION = int(100/GetSetting("FAV_LIST_FRACTION", int))
try:  FAV_LIST_FRACTION = GetSetting("FAV_LIST_FRACTION", int)
except:  FAV_LIST_FRACTION = 20 # 1/5th chance of being shown after LIMIT is reached

##Log(repr(FAV_LIST_FRACTION),C.LOGNONE)

##texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db")) #13 is a constant that may need to be recalculated https://kodi.wiki/view/Databases
####    texture_conn.text_factory = sqlite3.Row #note; wild cards not work with sqlite3.Row factory
##texture_cursor = texture_conn.cursor()

favDB_conn = sqlite3.connect(favoritesdb)
favDB_conn.text_factory = str  #= sqlite3.Row #note: wild cards not work with sqlite3.Row factory
favDB_cursor = favDB_conn.cursor()


#__________________________________________________________________
#
def RefreshImages():
    chaturbate_clean(False)
    cam4_clean(False)
    naked_clean(False)
    mfc_clean(False)
    streamate_clean(False)
    bongacams_clean(False)
#__________________________________________________________________
#
@C.url_dispatcher.register(C.REFRESH_CONTAINER_MODE)  
def RefreshContainter():
    webcam_db.clear_webcam_db( 1 ) # if manually refreshing, latest required, but 1 min should be good enough
    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________
#
@C.url_dispatcher.register("2341234123")  
def Add_Play_Random(dir_only=False):

    if dir_only:
        utils.addDir(
            name="[COLOR {}]Random Favorited Vid[/COLOR]".format(C.highlight_text_color)
            ,url=C.DO_NOTHING_URL
            ,mode="2341234123"
            ,iconimage=C.category_icon
            ,duration=1
            ,Folder=False 
            )
        return

    try:

        model = model_id = None
        
        sql_command = "SELECT * FROM favorites WHERE camsite is NULL"
##        Log("sql_command='{}'".format(sql_command)
##            ,LOGNONE
##            )
        playable_items = favDB_cursor.execute(sql_command).fetchall()
        model_id = random.choice(playable_items)[0]


        favDB_cursor.row_factory = sqlite3.Row
        model = favDB_cursor.execute("SELECT * FROM favorites WHERE id = {}".format(model_id) ).fetchone()
        model = dict(model)
            
        if 'play_method' in model and model['play_method'] in ('','None','none',None):
            play_method = None
        elif 'play_method' in model:
            play_method = model['play_method']
        else:
            play_method = None

        if 'hq_stream' in model: hq_stream = model['hq_stream']
        else: hq_stream = 0
                            
        listitem = utils.addDownLink( 
            name = model['name'] #"Random Vid of the Day" #utils.cleantext(icon_label) #model['icon_label'] 
            , url = model['url']  #model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['image']
            #, duration = model['camscore']
            , play_method = play_method
            #, fav = 'del'
            , desc = u"{}\n{}".format(utils.cleantext(model['name']), model['description'])
            , hq_stream = hq_stream
            , return_listitem = True
            )
##        Log(repr(listitem))
        u = listitem[0]

##        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')

        Log(repr(u)
            , C.LOGNONE
            )
        xbmc.executebuiltin('RunPlugin('+u+')')
##        Log('sleep 5'
##            , C.LOGNONE
##            )
        utils.Sleep(1000)
##        Log('end sleep 5'
##            , C.LOGNONE
##            )
    except:
        traceback.print_exc()
        Log(repr((model,model_id))
            ,C.LOGNONE
            )
        
#__________________________________________________________________
#
def TableCreateString(db_version):
    if db_version == FAV_DB_VERSION_1:
        return (
            " id INTEGER PRIMARY KEY, name, url, mode, image"
            " , description TEXT DEFAULT '' "
            " , camsite INTEGER DEFAULT NULL "
            )
    elif db_version == FAV_DB_VERSION_2:
        return (
            " id INTEGER PRIMARY KEY, name, url, mode, image"
            " , description TEXT DEFAULT ''"
            " , camsite INTEGER DEFAULT NULL"
            " , binary_image TEXT DEFAULT ''"
            )
    elif db_version == FAV_DB_VERSION_3:
        return (
            " id INTEGER PRIMARY KEY, name, url, mode, image"
            " , fake_test_column TEXT DEFAULT ''"
            " , description TEXT DEFAULT ''"
            " , camsite INTEGER DEFAULT NULL"
            " , binary_image TEXT DEFAULT ''"
            )

#__________________________________________________________________
#
def Create_Table():
    sql_command = (
        "BEGIN TRANSACTION;"
        "CREATE TABLE IF NOT EXISTS favorites ("
        )
    sql_command += TableCreateString(FAV_DB_VERSION_CURRENT)
    sql_command += (
        ");"
        "COMMIT;"
        "PRAGMA user_version = {};".format(FAV_DB_VERSION_CURRENT)
        )
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    favDB_conn.executescript( sql_command )
    favDB_conn.commit()
        
#__________________________________________________________________
#
def Export_Import():
    try: #update schema with this column
        favDB_conn.executescript("ALTER TABLE favorites ADD COLUMN binary_image TEXT DEFAULT '' ")
    except sqlite3.OperationalError as ex:
        if not ex.message.startswith('duplicate column name'):  #not sure if english text will always be same
           raise

    sql_command = (
        "DROP TABLE IF EXISTS favorites_bak;"
        "DROP TABLE IF EXISTS favorites_new;"
        "CREATE TABLE favorites_new ("
        )
    sql_command += TableCreateString(FAV_DB_VERSION_CURRENT)
    sql_command += (
        ");"
        "INSERT INTO favorites_new (name, url, mode, image, description, camsite, binary_image) "
        "   SELECT name, url, mode, image, description, camsite, binary_image FROM favorites;"
        "ALTER TABLE favorites     RENAME TO favorites_bak;"
        "ALTER TABLE favorites_new RENAME TO favorites;"
        "PRAGMA user_version = {};".format(FAV_DB_VERSION_CURRENT)
        )
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    favDB_conn.executescript( sql_command ) #self_commits
##    favDB_conn.commit() 
#__________________________________________________________________
#
def Create_Maintain_FavDB():
    sql_command = "PRAGMA user_version"
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    id_column_count =  favDB_conn.execute( sql_command )
    for a in id_column_count:
#        Log(repr(a[0]))
        if a[0] < FAV_DB_VERSION_CURRENT:
            Log('Export_Import()')
            Export_Import()
        else:
            Log('Database user_version is up to date')
            Create_Table()
    
#__________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_FAVORITES)
def List():
    Log("List()")
    items_list = list()

    progress_dialog_message = "Listing Favorites"
    progress_dialog = utils.Progress_Dialog(C.addon_name, progress_dialog_message)

    try: 
        if GetSetting("auto_clean_img_database", bool):
            RefreshImages()
        manually_refresh_favorites = GetSetting("manually_refresh_favorites", bool)
        play_method = GetSetting("default_playmode", str)

##        Log(repr(manually_refresh_favorites),C.LOGNONE)

        Create_Maintain_FavDB()

        Add_Play_Random(True)

        percent = 1
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...filling/scanning webcam database...'
            )        
        camDB_conn = webcam_db.fill_webcam_db(progress_dialog) #locked so that service can't clear DB during processing
        percent = 50 #an arbitrary number...
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...matching online cams...'
            )
        i = 0
        
        with camDB_conn:
            
            try:
                try: default_favorites_order = " ORDER BY " + GetSetting("default_favorites_order", str)  #'ORDER BY RANDOM()'
                except: default_favorites_order = ' ' #random order...optional?
##                Log(default_favorites_order,C.LOGNONE)
                favDB_cursor.execute("SELECT * FROM favorites " + default_favorites_order ) 
                
                for (fav_id, name, url, mode, img, description, camsite, binary_image) in favDB_cursor.fetchall():

                    if progress_dialog.iscanceled(): break
                    
                    try:
##                        if camsite:                             Log("name='{}',url='{}',mode='{}',img='{}'".format(repr(name), repr(url), repr(mode), repr(img)), xbmc.LOGNONE)
                        model_id_via_image = "00000000" # length of 8
                        if str(mode)==mfc_PLAY_MODE:
                            if "/img.mfcimg.com/" in img or "/snap.mfcimg.com/" in img :
                                model_id_via_image = img.split('/')[6]
                                if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                                    model_id_via_image = img.split('/')[5]
                                #the 1 indicates model was in public chat when bookmark created
                                if model_id_via_image.startswith("mfc_a_1"):
                                   model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
                                if model_id_via_image.startswith("mfc_1"):
                                   model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
                                if model_id_via_image[0] == '0':
                                    model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
                                img = mfc_generic_image(model_id_via_image)
                                while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
                                    model_id_via_image = '0' + model_id_via_image

                        camDB_conn.row_factory = sqlite3.Row
                        query = (u"select * from camlist where (mode = ?)"
                                 " and ( (modelID LIKE ? ESCAPE '\\') or "
                                 "       ( (icon_image LIKE ? ESCAPE '\\') or "
                                 "         (icon_image LIKE ? ESCAPE '\\')"
                                 "       ) "
                                 "     )  ;"
                                 )
                        try:
                            params = ( int(mode)
                                      ,name.decode('utf-8').replace('_', '\_')
                                      ,u"%/mfc\_1{}?%".format(model_id_via_image)
                                      ,u"%/mfc\_a\_1{}?%".format(model_id_via_image)
                                      )
                        except:
                            Log("name='{}',url='{}',mode='{}',img='{}'".format(repr(name), repr(url), repr(mode), repr(img)), xbmc.LOGNONE)
                            params = ( int(mode)
                                      ,name.replace('_', '\_')
                                      ,u"%/mfc\_1{}?%".format(model_id_via_image)
                                      ,u"%/mfc\_a\_1{}?%".format(model_id_via_image)
                                      )

                        model = camDB_conn.execute(query,params).fetchone()
                        model_found = (model is not None)
                        
                        if model_found:

                            progress_dialog.update(
                                percent  = progress_dialog.percent + 0.1
                                ,message = progress_dialog_message 
                                ,line2 = ' '
                                ,line3 = '...found {}...'.format(name)
                                )
                            Log('...found {}...'.format(name), C.LOGNONE)
                            
                            model = dict(model)
                            icon_label = "[COLOR {}]{}[/COLOR]".format(C.search_text_color, name)
                            if str(mode)==mfc_PLAY_MODE:
                                #site allows easy name changes, but no searching via id;
                                current_model_name = model['modelID']
                                if current_model_name != name: #automatically refresh name in fav database
                                    Log("new mfc model name '{}' --> '{}'".format(name, current_model_name), xbmc.LOGNOTICE)
                                    #download name also needs changing
                                    downloader.rename_download(
                                        name = C.DOWNLOAD_INDICATOR+name
                                        ,new_name = C.DOWNLOAD_INDICATOR+current_model_name
                                        ,mode = mode
                                        ,friendly_name = current_model_name
                                        ,url_factory = current_model_name
                                        )
                                                               
                                    delFav(
                                        url = name
                                        , img = img
                                        , name = name
                                        , icon_url= img
                                        ) #Favorites() was supposed to do the del, but can't because of url value issue
                                    Favorites(
                                        fav="refresh"
                                        , favmode = mode
                                        , name = current_model_name
                                        , url = current_model_name
                                        , img = img
                                        , desc = description)


                            model['icon_url'] = img

##                            thumbcache = xbmc.getCacheThumbName(img).replace(".tbn", ".jpg")
##                            thumbcache = "special://thumbnails/%s/%s" % (thumbcache[0], thumbcache)
##                            if not xbmcvfs.exists(thumbcache):
##                                if binary_image:
##                                    Log('written ' + thumbcache, C.LOGNONE)
##                                    #xbmcvfs.copy(image, thumbcache)
##                                    f = xbmcvfs.File(xbmc.translatePath(thumbcache), 'w')
##                                    f.write(base64.b64decode(binary_image))
##                                    f.close()
##                            else:
##                                Log("thumbcache '{}'does not exist".format(thumbcache), C.LOGNONE)
##                                pass



##                            #result = find_thumbnail_in_cache(img)
##                            result = None
##                            if not result:
##                                if binary_image:
##                                        Log("writing temp image for '{}'".format(utils.cleantext(icon_label)),C.LOGNONE)
##                                        import base64
##                                        img_raw = base64.b64decode(binary_image)
##                                        model['icon_image'] = image_to_local_cache(img_raw)
##                                else:
####                                  Log("no image stored in favorites DB entry",C.LOGNONE)
##                                    pass
####                                Log("can't find cached result for '{}' '{}'".format(utils.cleantext(icon_label), repr(img)),C.LOGNONE)
##                                #else:
##                                    img_raw = None
##                                    try:
##                                        img_raw = utils.getHtml(img)
##                                    except:
##                                        pass
##                                    
##                                    if not img_raw:
##    ##                                    Log("cant find direct result either",C.LOGNONE)
##                                        pass
##
##                                    else:
##    ##                                    Log("direct result online",C.LOGNONE)
##                                        pass
##                                #else:
##        ##                                Log("thumbnail cache entry '{}'found".format(result),C.LOGNONE)
##                                    pass
                                    
                                        
    
                        elif not model_found:



                            i = i+1
                            if i > FAV_LIST_LIMIT: #after limit; 1/5 ~20% chance of including item
##                                break
##                                if random.randint(1,FAV_LIST_FRACTION) > 1:
                                if int(random.random()*100) > FAV_LIST_FRACTION:
                                    continue
                        
##                            thumbcache = xbmc.getCacheThumbName(img)
##                            if thumbcache:
##                                if ".tbn"  in thumbcache:  thumbcache = thumbcache.replace(".tbn", ".jpg")
##                                if ".webp" in img:  thumbcache2 = thumbcache.replace(".jpg", ".webp")
##                                thumbcache = "special://thumbnails/%s/%s" % (thumbcache[0], thumbcache)
##                                #if thumbcache and not xbmcvfs.exists(xbmc.translatePath(thumbcache)):
##                                if xbmcvfs.exists(thumbcache):
##                                    img = thumbcache
##                                else:
####                                    Log(u"thumbcache {} does not exist for {}".format(thumbcache, repr(name)))
##                                    if binary_image:
##                                        Log('written  ing ' + thumbcache, C.LOGNONE)
##                                        #xbmcvfs.copy(image, thumbcache)
##                                        f = xbmcvfs.File(xbmc.translatePath(thumbcache), 'w')
##                                        f.write(base64.b64decode(binary_image))
##                                        f.close()
##                                        img = thumbcache
##                                    pass
                            
                            model = {}
                            icon_label = name
                            model['video_url'] = url
                            model['mode'] = mode
                            model['icon_image'] = img
                            model['camscore'] = 0
                            if description: model['description'] = description
                            else: model['description'] = ''

                            model['icon_url'] = img

                            if camsite:
                                if binary_image:
                                    Log(u"writing temp image for '{}'".format(utils.cleantext(icon_label))
                                        ,C.LOGNONE
                                        )
                                    img_raw = base64.b64decode(binary_image)
                                    model['icon_image'] = image_to_local_cache(img_raw,file_type=binary_image[0:4])

                                
##                            #result = find_thumbnail_in_cache(img)
##                            result = None
##                            if not result:
##                                #Log("cant find cached result for '{}' '{}'".format(utils.cleantext(icon_label), repr(img)),C.LOGNONE)
##                                if binary_image:
##                                    Log("writing temp image for '{}'".format(utils.cleantext(icon_label)),C.LOGNONE)
##                                    import base64
##                                    img_raw = base64.b64decode(binary_image)
##                                    model['icon_image'] = image_to_local_cache(img_raw)
##                            thumbcache = xbmc.getCacheThumbName(img).replace(".tbn", ".jpg")
##                            thumbcache = "special://thumbnails/%s/%s" % (thumbcache[0], thumbcache)
####                            Log(repr(thumbcache), C.LOGNONE)
##                            if not xbmcvfs.exists(thumbcache):
##                                if binary_image:
##                                    Log('written ' + thumbcache, C.LOGNONE)
##                                    #xbmcvfs.copy(image, thumbcache)
##                                    f = xbmcvfs.File(xbmc.translatePath(thumbcache), 'w')
##                                    f.write(base64.b64decode(binary_image))
##                                    f.close()
##                            else:
##                                Log('does not exist ' + thumbcache, C.LOGNONE)



                        if 'hq_stream' in model: hq_stream = model['hq_stream']
                        else: hq_stream = 0
                            
                        if 'play_method' in model and model['play_method'] in ('','None','none',None):
                            play_method = None
                        elif 'play_method' in model:
                            play_method = model['play_method']
                        else:
                            play_method = None

##                        if 'fav_image=true' in model['icon_image']: # never send this internal artifact to remote server
##                            model['icon_image'] = model['icon_image'].replace('&'+'fav_image=true','').replace('?'+'fav_image=true','')


                        if camsite and model_found: Log(repr(model))
                        items_list.append(
                            utils.addDownLink( 
                                name = utils.cleantext(icon_label) #model['icon_label'] 
                                , url = model['video_url'] 
                                , mode = model['mode'] 
                                , iconimage = model['icon_image']
                                , icon_url = model['icon_url']
                                , duration = model['camscore']
                                , play_method = play_method
                                , fav = 'del'
                                , desc = utils.cleantext(model['description'])
                                , hq_stream = hq_stream
                                , return_listitem = True
                                )
                            )


                    except:
                        traceback.print_exc()
                
            except :
                traceback.print_exc()
                utils.notify('No Favorites found')
            finally:
                if favDB_conn: favDB_conn.close()

    finally:

        #include a refesh icon
        utils.Add_Refresh_Item(
            mode=C.REFRESH_CONTAINER_MODE
            ,progress_dialog=progress_dialog
            ,duration=1 #duration so that when sorting by duration, refresh shows after active webcams when = 1
            ,end_directory=True)

        #add all the generated listitems
        xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)
        del items_list

    utils.endOfDirectory(cacheToDisc=( manually_refresh_favorites==True) )

#__________________________________________________________________
#
def check_if_camsite(favmode):
    #sometimes we need to know if a favorite cam model
    result = False #default 
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_CAMS):
        Log(repr((root_url, mode, favmode)))
        if (int(mode)+2) == favmode:
            result = True
    return result
    
#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_MODE, ['fav','favmode','name','url','img'],['desc','camsite','icon_url'])  
def Favorites(fav,favmode,name,url,img,desc=None,camsite=None,icon_url=None):
    Log("Favorites " +repr((fav,favmode,name,url,img,desc,camsite,icon_url)), C.LOGNONE)

    is_camsite = check_if_camsite(favmode)

    n_bak = name
    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = utils.Clean_Filename(name)
    if name in [None,'']: raise Exception("invalid name '{}'".format(n_bak))

    if fav in ["add"]:

        if str(favmode) == str(int(C.MAIN_MODE_bongacams) + C.MODE_PLAY_OFFSET): #site needs special handling
            url = '%stream_{}/playlist.m3u8'.format(name)

        if img.startswith(xbmc.translatePath("special://home/")):
            utils.Notify(u"Can't add/refresh fav when icon points to local file. Find an original source")
            return

##        delFav(url, img, name, icon_url) 
        normalized_name = addFav(favmode, name, url, img, desc, is_camsite) # addFav will delete any previous fav

        utils.Notify(u"{}ed fav:'{}' url:{}".format(fav.capitalize(),normalized_name,url))

    elif fav == "del":
        
        if str(favmode) == str(int(C.MAIN_MODE_bongacams) + C.MODE_PLAY_OFFSET): #site needs special handling
            url = '%stream_{}/playlist.m3u8'.format(name)
        delFav(url, img, name, icon_url)
        utils.Notify(u"Deleted fav:{} url:{}".format(name,url))

    elif fav in ["rename"]:
        keyboard = xbmc.Keyboard(name, 'Rename', hidden=False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            keyboard_text = unicode(keyboard.getText(), "utf-8")
        else:
            keyboard_text = None
        Log(repr(keyboard_text), C.LOGNONE)
        if keyboard_text:
            Rename_Fav(url, keyboard_text)
    
    elif fav in ["rebuildXX","refresh"]:

        save_folder = "special://home/cache/archive_cache"
        save_folder = xbmc.translatePath(save_folder)
    
        if save_folder in img: #temp susbsitute found; look for http version in database
            Log('save_folder in img')
            query = (
                ' SELECT '
                '   image'
                ' FROM '
                '   favorites '
                ' WHERE '
                '   (mode LIKE ?) '
                '   and (url LIKE ?) '
                )
            params = (  str(favmode), url ) #wildcard because icon may be cached with a appended header
            Log(repr((params, query))
                ,C.LOGNONE
                )
            img = favDB_cursor.execute(query, params).fetchone()[0]
            Log(repr(img))

            if img.startswith(xbmc.translatePath("special://home/")):
                img = None
                utils.Notify(u"Can't add/refresh fav when icon points to local file. Find an original source")
                return
        else:
            Log('save_folder NOT in img' + img)


        try:
            binary_image = base64.b64encode(utils.getHtml(img))
            Log(repr(len(binary_image)))
            
        except:
            binary_image =''
            Log("either we will have the original image from database, or we get new one from http")
            #pass

        MIN_VALID_IMAGE_SIZE = 13000
        if binary_image and (len(binary_image)>MIN_VALID_IMAGE_SIZE) :
            #a valid img was found;
            # no need to run generic search
            rebuilt_icon_url = img

            query = (
                    ' SELECT '
                    '    description'
                    ' FROM '
                    '     favorites '
                    ' WHERE '
                    '        (mode LIKE ?) '
                    '        and (url LIKE ?) '
                    )
            params = (  str(favmode), url ) #wildcard because icon may be cached with a apppended header
            Log(repr((params, query))
                ,C.LOGNONE
                )
            try:
                (description,) = favDB_cursor.execute(query, params).fetchone()
                Log(repr((type(description),description)))
            except:
                description = ''
                traceback.print_exc()                

                
        else:
            Log(repr(img))
            rebuilt_icon_url = None
            try:
                get_sites = utils.Get_Sites(icon_function=True)
                for module, main_mode_id in get_sites:
                    module_play_mode_id = int(main_mode_id)+C.MODE_PLAY_OFFSET

                    

                    if module_play_mode_id == favmode:

                        


                        if 'Icon_Search' in dir(module):
                            method = getattr(module, 'Icon_Search')
                            rebuilt_icon_url = module.Icon_Search(url)
                            Log(repr(rebuilt_icon_url))
                            if rebuilt_icon_url:
                                img = rebuilt_icon_url
                        elif 'Camgirl_Generic_Image' in dir(module):
                            method = getattr(module, 'Camgirl_Generic_Image')

                            
                            current_http_image_size = len(utils.getHtml(img))
                            Log(repr((img+'qq',current_http_image_size)))

                            if (current_http_image_size>MIN_VALID_IMAGE_SIZE): #fav is online; save the online img
                                pass
                            else:
                                if str(favmode)==mfc_PLAY_MODE :
        ##                            Log(repr((img)))
                                    if ("/img.mfcimg.com/" in img) or ("/snap.mfcimg.com/" in img)  :
                                        model_id_via_image = img.split('/')[6]
                                        Log(repr(model_id_via_image))
                                        if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                                            model_id_via_image = img.split('/')[5]
##                                        Log(repr(model_id_via_image))
                                        #the 1 indicates model was in public chat when bookmark created
                                        if model_id_via_image.startswith("mfc_a_1"):
                                           model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
##                                        Log(repr(model_id_via_image))
                                        if model_id_via_image.startswith("mfc_1"):
                                           model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
##                                        Log(repr(model_id_via_image))
                                        if model_id_via_image[0] == '0':
                                            model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
        ##                                img = mfc_generic_image(model_id_via_image)
                                        while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
                                            model_id_via_image = '0' + model_id_via_image
                                    rebuilt_icon_url = module.Camgirl_Generic_Image(model_id_via_image)
        ##                            raise Exception(repr((model_id_via_image,rebuilt_icon_url)))
                                else:
                                    rebuilt_icon_url = module.Camgirl_Generic_Image(name)
                                    
                                Log(repr(rebuilt_icon_url)
                                    ,C.LOGNONE
                                    )
                                if rebuilt_icon_url:
                                    img = rebuilt_icon_url
                        else:
                            Log(repr((module.__name__, dir(module)))
                                ,C.LOGNONE
                                )
                            utils.Notify(u"Site '{} does not have an icon rebuild function".format(repr(module.__name__).split('.')[-1]))
                            #get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
                            return True
                            pass
                        get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
                    
            except StopIteration,GeneratorExit:
                pass
            except:
                traceback.print_exc()
                raise 
            
    ##        raise Exception(repr((rebuilt_icon_url,)))

            query = (
                'SELECT '
                '   description'
                '   , binary_image '
                'FROM '
                '   favorites '
                'WHERE '
                '   (mode LIKE ?) '
                '   and (url LIKE ?) '
                '   and not(nullif(binary_image,"") is NULL)'
                )
            params = (  str(favmode), url ) #wildcard because icon may be cached with a appended header
            Log(repr((params, query))
                ,C.LOGNONE
                )
            kk = favDB_cursor.execute(query, params).fetchone()
            Log(repr(kk)
                ,C.LOGNONE
                )


            if (kk is None) and (not rebuilt_icon_url):
                utils.Notify(u"Can't rebuild binary because image for '{}'. Not in favdb and Iconsearch can't find new one".format(name))
                return

            if is_camsite:
                Log(repr(img))
                assert img.startswith('http')
            
            query = (
                'SELECT '
                '    description'
                '    , binary_image '
                'FROM '
                '     favorites '
                'WHERE '
                '        (mode LIKE ?) '
                '        and (url LIKE ?) '
                )

            if str(favmode) == str(int(C.MAIN_MODE_bongacams) + C.MODE_PLAY_OFFSET): #site needs special handling
                url = '%stream_{}/playlist.m3u8'.format(name)

            params = (  str(favmode), url ) #wildcard because icon may be cached with a apppended header
            Log(repr((params, query))
                ,C.LOGNONE
                )
            (description, binary_image) = favDB_cursor.execute(query, params).fetchone()
            try:
                binary_image = base64.b64encode(utils.getHtml(img))
            except:
                #either we will have the original image from database, or new one from http
                pass

            thumbcache = xbmc.getCacheThumbName(img).replace(".tbn", ".jpg")
            if thumbcache:
                thumb_filespec = "special://thumbnails/%s/%s" % (thumbcache[0], thumbcache)
                thumb_filespec = xbmc.translatePath(thumb_filespec)
                f = xbmcvfs.File(thumb_filespec, 'w')
                f.write(base64.b64decode(binary_image))
                f.close()
                Log("binary image written to '{}'".format(thumb_filespec)
                    , C.LOGNONE
                    )
            else:
                Log(u"thumbcache '{}' is not cached".format(thumbcache)
                    , C.LOGNONE
                    )
                raise Exception(u"thumbcache '{}' is not cached".format(thumbcache))
                pass


        Insert_fav_DB(name, url, favmode, img, description, is_camsite, binary_image, False)

    else:
        Log('unhandled fav operation'+fav)

    needs_an_e = '' if fav[-1] == 'e' else 'e'
    utils.Notify(u"{}{}d fav:'{}' url:{}".format(fav.capitalize(),needs_an_e,name,url))

#__________________________________________________________________
#
def Insert_fav_DB(name, url, mode, image, description, camsite, binary_image, is_binary=True):
    Log(u'Insert_fav_DB ' + repr((name, url, mode, image, description, camsite, binary_image))
        ,C.LOGNONE
        )

    #delete and add in one transaction
    query = "DELETE FROM favorites WHERE url LIKE ?;"
    params = (url,)
    Log(repr((query, params))
        ,C.LOGNONE
        )
    favDB_cursor.execute(query, params)

    query = ("INSERT INTO favorites ("
             "  name "
             "  , url"
             "  , mode"
             "  , image"
             "  , description"
             "  , camsite"
             "  , binary_image"
             " ) "
             "VALUES (?,?,?,?,?,?,?)"
             )
    if is_binary:
        params = (name, url, mode, image, description, camsite, base64.b64encode(binary_image))
    else:
        params = (name, url, mode, image, description, camsite, binary_image)
    Log(repr((query, params))
        ,C.LOGNONE
        )
    favDB_cursor.execute(query, params)

##    raise Exception()
    favDB_conn.commit()

#__________________________________________________________________
#
def image_to_local_cache(binary_image, file_type):

    save_folder = "special://home/cache/archive_cache"
    save_folder = xbmc.translatePath(save_folder)

    if file_type == '/9j/':
        suffix = '.jpg'
    elif file_type == 'UklG':
        suffix = '.webp'
    else :
        suffix = '.jpg'
        
    save_dest = tempfile.mktemp(dir=save_folder, suffix=suffix)
    save_dest = xbmc.makeLegalFilename(save_dest)

    Log(save_dest
        , C.LOGNONE
        )
    
    f = xbmcvfs.File(save_dest, 'w')
    f.write(binary_image)
    f.close()

    return save_dest

#__________________________________________________________________
#
def find_thumbnail_in_cache(url):

    texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db")) #13 is a constant that may need to be recalculated https://kodi.wiki/view/Databases
    ##    texture_conn.text_factory = sqlite3.Row #note: wild cards not work with sqlite3.Row factory
##    texture_conn.text_factory = sqlite3.Row # sqlite3.Row or str #note: wild cards not work with sqlite3.Row factory
    texture_cursor = texture_conn.cursor()

##    #find the image that is currently showing; it will be copied as a new record
##    #query = "SELECT * FROM texture WHERE (url LIKE ? ) AND NOT (url LIKE ?)"
##    #params = (  url+'%', '%' + 'fav_image=true'+'%' )
##    query = "SELECT * FROM texture WHERE (url LIKE ? )"
##    params = (  (url+'%',) )
    
    normalized_url = url.split('|')[0].split('?')[0] #discard anti-caching unique timestamp
    query = "SELECT * FROM texture WHERE url LIKE ?"
    params = (  (normalized_url+'%',) ) #wildcard because icon may be cached with a apppended header
    Log(repr((query,params))
        ,C.LOGNONE
        )
    result = texture_cursor.execute(query, params)
    result = result.fetchone()
    Log("search for '{}' found ".format(url)
        ,C.LOGNONE
        )
    Log("                 result '{}'".format(result)
        ,C.LOGNONE
        )
    Log("                 result '{}'".format(repr(result))
        ,C.LOGNONE
        )


    if not result:
#        Log(repr((query,params)),C.LOGNONE)
#        Log("search for '{}' found result '{}'".format(url, result),C.LOGNONE)
        return None
        pass

    #texture_filespec = "special://thumbnails/" + result["cachedurl"] #todo
    cachedurl_index = [idx for idx, col in enumerate(texture_cursor.description) if col[0] == 'cachedurl'][0]
    
    texture_filespec = "special://thumbnails/" + result[cachedurl_index]
    
    texture_filespec = xbmc.translatePath(texture_filespec)
    Log(repr(texture_filespec)
        , xbmc.LOGNONE
        )
    if not xbmcvfs.exists(texture_filespec):
        result = None
        
    
    return result


#__________________________________________________________________
#
def Clean_Textures_DB():
    pass
            

#__________________________________________________________________
#
def addFav(mode,name,url,img,description,camsite):

    Log("addFav {}".format(repr((mode,name,url,img,description,camsite))), xbmc.LOGNONE)

##    import uuid
##    import xbmcvfs
##
##    #get image
##    #image can be in texture folder, or we can download latest
##    img_content = utils.getHtml(img)
##    #C:\Users\x\AppData\Roaming\Kodi\cache\archive_cache
##    #save image to our cache
##    save_folder = "special://userdata/addon_data/"+C.addon_id+'/cache/' + uuid.uuid4().hex + "." + name + '.jpg'
##    save_folder = "special://userdata/addon_data/"+C.addon_id+'/cache/' + name + "." + str(mode) + '.jpg'
##    save_dest = xbmc.translatePath(save_folder)
##    Log(save_dest, C.LOGNONE)
##    
##    f = xbmcvfs.File(save_dest, 'w')
##    f.write(img_content)
##    f.close()
##
##    Insert_fav_DB(name, url, mode, save_dest, description, camsite)
##
##    return name


##    texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db")) #13 is a constant that may need to be recalculated https://kodi.wiki/view/Databases
####    texture_conn.text_factory = sqlite3.Row #note; wild cards not work with sqlite3.Row factory
##    texture_cursor = texture_conn.cursor()

##    #find the image that is currently showing; it will be copied as a new record
##    query = "SELECT * FROM texture WHERE (url LIKE ? ) AND NOT (url LIKE ?)"
##    params = (  img+'%', '%' + 'fav_image=true'+'%' )
##    #Log(repr((query,params)),C.LOGNONE)
##    result = texture_cursor.execute(query, params).fetchone()
    result = find_thumbnail_in_cache(img)
    if (result is None) and img.startswith('special://'): #maybe mode has a way to generate img
        raise Exception()
##        module = importlib.import_module('resources.lib.sites.'+sitename)
##        if hasattr(module, "website"):
##            module = module.website

##    filespec = "special://thumbnails/" + texture_image_cache
##    filespec = xbmc.translatePath(filespec)
##    Log(repr(filespec)
##        ,
##        xbmc.LOGNONE)
##    if xbmcvfs.exists(filespec):
                    
    if (result is None):
        msg = "Can't find image to refresh with. Reload the container and/or check network container"
        Log(msg
            ,C.LOGNONE
            )
        img_content = utils.getHtml(img)
        if not img_content:
            if not description.endswith('/'): description+='/'
            header = {"Referer":description}
            if not (urllib.urlencode(header) in img):
                img = img + '&' + urllib.urlencode(header)
                img = img.replace("|","&_={}|".format(utils.RandomNumber()))
                img_content = utils.getHtml(img)
        Insert_fav_DB(name, url, mode, img, description, camsite, img_content)
        return name
    else:
        Log("icon already in kodi cache '{}'".format(repr(result)),C.LOGNONE)
        pass

##    #add our new, artificially generated fav icon                    
##    #keep track of this for later
##    texture_size_to_copy_id = result[0]
##    #make img different so that it will not be accidentally deleted during database clean operations
##    new_image = result[1]
##    if ("|" in new_image) and ("?" in new_image) :
##        new_image = new_image.replace("|", '&' + 'fav_image=true' + "|")
##    elif ("|" in new_image):
##        new_image = new_image.replace("|", '?' + 'fav_image=true' + "|")
##    else:
##        new_image = new_image + '?' + 'fav_image=true'
##    query = "INSERT INTO texture(url,cachedurl,imagehash,lasthashcheck) VALUES (?,?,?,?)"
##    params = (new_image, result[2], result[3],'')
##    texture_cursor.execute(query, params)
##    inserted_row_id = texture_cursor.lastrowid
##    query = "SELECT * FROM sizes WHERE (idtexture = ? ) "
##    params = (  texture_size_to_copy_id, )
##    size_to_copy = texture_cursor.execute(query, params).fetchone()
##    query = "INSERT INTO sizes(idtexture,size,width,height,usecount,lastusetime) VALUES (?,?,?,?,?,?)"
##    params = (inserted_row_id, size_to_copy[1], size_to_copy[2], size_to_copy[3], size_to_copy[4], size_to_copy[5])
##    Log(repr((query,params)),C.LOGNONE)
##    exec_result = texture_cursor.execute(query, params)
##    texture_conn.commit()
##    texture_conn.close()

    #img_url = img.split("|")[0] #remove these extra kodi headers which can cause problems
    #img_content = utils.getHtml(img.split("|")[0])
    img_url = result[1]
    Log(repr(img_url),C.LOGNONE)
    if "|" in img_url:
##        Log(repr(urlparse.urlparse(img_url)),C.LOGNONE)
        headers = img_url.split("|")[1]
        img_url = img_url.split("|")[0]

##        Log(headers,C.LOGNONE)
        #stream_headers = urllib.unquote_plus( video_url.split('|')[1])
        #headers = urllib.unquote_plus(headers)
        headers = urlparse.parse_qs(headers.encode('ASCII'))
##        Log(repr(headers),C.LOGNONE)
        h = {}
        
        for a in headers:
##            Log(repr(a),C.LOGNONE)
##            Log(repr(str(headers[a])),C.LOGNONE)
##            Log(repr(str(headers[a][0])),C.LOGNONE)
            h[a] = str(headers[a][0])
##        Log(repr(h),C.LOGNONE)
        headers = h
        #Log(repr(urllib.unquote_plus(headers)),C.LOGNONE)
        #return
    img_content = utils.getHtml(img_url,headers=headers)
    Insert_fav_DB(name, url, mode, img, description, camsite, img_content)

    return name
#__________________________________________________________________
#
def Rename_Fav(url, name):
    Log("Rename_Fav {}".format(repr((url, name)))
        , C.LOGNONE
        )

    try:
        query = "UPDATE favorites SET name = ? WHERE url LIKE ?;"
        params = (name,url)
        Log(repr((query,params))
            ,C.LOGNONE
            )
        cursor_result = favDB_cursor.execute(query,params)
        Log(repr(cursor_result.rowcount)
            ,C.LOGNONE
            )
    except:
        traceback.print_exc()
    finally:
        favDB_conn.commit()
        pass

#__________________________________________________________________
#
def delFav(url, img, name, icon_url):
    Log("delFav {}".format(repr((url,img, name, icon_url))), xbmc.LOGNONE)

    #delete fav and fav_image if it exists
    try:

##        favDB_conn = sqlite3.connect(favoritesdb)
##        favDB_cursor = favDB_conn.cursor()
        query = "DELETE FROM favorites WHERE url LIKE ?;"
        params = (url,)
        Log(repr((query,params))
            ,xbmc.LOGNONE
            )
        cursor_result = favDB_cursor.execute(query,params)
##        Log(repr(cursor_result.rowcount),xbmc.LOGNONE)

        if not img in (None,'','None','none','%'): #try deleting via image for site where name is easily changable
            if "|" in img: img = img.split("|")[0]
            if "?" in img:
                if "?id=" in img:
                    pass
                else:
                    img = img.split("?")[0]
            sql_command = "DELETE FROM favorites WHERE image LIKE '{}%{}%'".format(img, 'fav_image=true')
            Log("sql_command='{}'".format(sql_command), LOGNONE)
            favDB_cursor.execute(sql_command)

        texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db")) #13 is a constant that may need to be recalculated https://kodi.wiki/view/Databases
        ##    texture_conn.text_factory = sqlite3.Row #note: wild cards not work with sqlite3.Row factory
        texture_cursor = texture_conn.cursor()

        query = "SELECT id, cachedurl, url FROM texture WHERE (url LIKE ? ) and (url LIKE ?) "
        params = (
            img+'%'
            , '%' + 'fav_image=true'+'%')
        #Log(repr((query,params)),C.LOGNONE)
        for  texture_id, texture_image_cache, texture_url in texture_cursor.execute(query,params):
            Log(repr((texture_id, texture_image_cache, texture_url)) ,xbmc.LOGNONE)            
            query = "DELETE FROM sizes WHERE idtexture = ?;"
            params = (texture_id,)
            Log(repr((query,params)) ,xbmc.LOGNONE)
            texture_cursor.execute(query,params)
            query = "DELETE FROM texture WHERE id = ? ;"
            params = (texture_id,)
            Log(repr((query,params)) ,xbmc.LOGNONE)
            texture_cursor.execute(query,params)
            try:
                filespec = "special://thumbnails/" + texture_image_cache
                filespec = xbmc.translatePath(filespec)
                Log(repr(filespec),xbmc.LOGNONE)
                if xbmcvfs.exists(filespec):
                    os.remove(filespec)
            except:
                traceback.print_exc()
                pass

    except:
        traceback.print_exc()
    finally:
        favDB_conn.commit()

##    texture_conn.commit()
##    texture_conn.close()
##    favDB_conn.commit()
##    favDB_conn.close()
#__________________________________________________________________
#
