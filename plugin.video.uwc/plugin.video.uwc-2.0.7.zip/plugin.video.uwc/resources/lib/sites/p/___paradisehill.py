'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc

import constants as C
import search
import utils
from utils import Log, LogR


FRIENDLY_NAME = '[COLOR {}]paradisehill[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_MOVIES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://en.paradisehill.cc"
SEARCH_URL = ROOT_URL + '/search/?pattern={}&page={}'
URL_RECENT = ROOT_URL + '/all/?sort=created_at&page={}'
URL_CATEGORIES = ROOT_URL + '/categories/'

MAIN_MODE          = C.MAIN_MODE_paradisehill
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = 1

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page_start=FIRST_PAGE, page_end=None, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    LogR(locals())

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page_start, page_end, FIRST_PAGE)  

    if not progress_dialog: progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)

    Log(__name__)
    # read html
    Log(list_url)
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if "Page Not Found" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            regex = 'id="w0"(.+)class="pagination">'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    # parse out list items
##    regex = 'list-film-item.+?href="([^"]+)".+?itemprop="name">([^<]+)<.+?itemprop="image" src=\"([^\"]+)\"' #2020-12-09

    regex = ( #2024-04-09
        'list-film-item"'
        '.+?href="([^"]+)"'
        '.+?itemprop="image" src=\"([^\"]+)\"'
        '.+?itemprop="name">([^<]+)<'
        )
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for link, thumb, label in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        label = C.SPACING_FOR_NAMES + utils.cleantext(label)
        if link.startswith('/'): link = ROOT_URL + link
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        utils.addDownLink(
            name=label
            ,url=link 
            ,mode=PLAY_MODE
            ,desc='\n' + ROOT_URL
            ,iconimage=thumb )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

##    Log(__name__)
    
    # next page items
    regex = '(?:<ul class="pagination">|</body>)(.*)'
    np_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if np_region: np_region =  np_region[0]
    LogR(np_region)
##    next_page_regex = "<li class=\"next\".+?href=\"([^\"]+)\""
    next_page_regex = '<li class="next".+?href="(.+?)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(np_region)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    if np_info:
        np_number = int(page_start) + 1
        np_url = url
        ##page number can be multiple places depending if search result or not
        if end_directory == True:
##            LogR(np_url)
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page_start=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword
                )
        else:
            LogR(np_url)
            if int(np_number) <= max_search_depth: #search some more, but not forever
                utils.Notify(msg=np_url.format(np_number))
                List(  url=np_url
                     , page_start=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , testmode=testmode
                     , progress_dialog=progress_dialog)


##    Log(__name__)
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)

#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True, page_start=FIRST_PAGE, page_end=FIRST_PAGE):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))

    if not keyword:
        prev_keyword = utils.get_setting('quick_search_string')
        if prev_keyword: keyword = prev_keyword
    if not keyword:
        keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
        if  keyword == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=keyword)
        
    List(URL_RECENT, page_start=FIRST_PAGE, page_end=page_end, end_directory=False, keyword=keyword, testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page_start=FIRST_PAGE, page_end=page_end)
    Categories(URL_CATEGORIES, False)
    
    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=0, progress_dialog=None):
    LogR(locals())

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page_start=page_start, page_end=page_end, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))

    List( url=searchUrl
        , page_start=FIRST_PAGE, page_end=page_end
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page_start)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    html = utils.getHtml(url, ROOT_URL)

    regex = "schema\.org/Movie.+?href=\"([^\"]+)\".+?itemprop=\"name\"><span>([^<]+)<.+?src=\"([^\"]+)\""
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    for url, label, thumb in info:
        if url.startswith('/'): url = ROOT_URL + url
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        thumb = utils.cleantext(thumb)
        url += "&page={}"
        if C.PY2:
            label = label.decode('ascii','ignore').decode('utf8','ignore')
            thumb = thumb.encode('ascii','ignore').decode('utf8','ignore')
        if C.PY3:
            label = label
            thumb = thumb
            
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,page_start=FIRST_PAGE
            )

    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    elif playmode_string == C.PLAYMODE_DIRECT:  max_video_resolution = 99999 #if 'direct' was chosen, use max available resolution
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None


    play_all_videos = (C.addon.getSetting("paradisehill") == "true")
    

    full_html = utils.getHtml(url, ROOT_URL)

    #distinguish between adverts and videos
    #video_region = video_region.split('<div class="imagpreloader-pause">')[0]
##    video_region = full_html.split('<div class="fp-playlist">')[1].split('<div class="imagpreloader-pause">')[0]
    regex = '(.*)div class="main"'
    video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
##    Log(repr(video_region))
    
##    regex = "href=\"([^\"]+)\""
    regex = "videoList = (\[.+}\]}\]);"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)[0]
##    LogR(info)
    info = info.replace('\\/','/')
##    LogR(info)

    videos = json.loads(info)
##    LogR(videos)

    videos = [x['sources'][0]['src'] for x in videos]
##    LogR(videos)

##    if not play_all_videos:
    if len(videos) > 1:
        i = 1
        videolist = []
        for x in videos:
            videolist.append('Part ' + str(i))
            i += 1
        videopart = C.dialog.select('Multiple videos found', videolist)
        if videopart == -1:
            return
        video_url = videos[videopart]
        name = name + ': Part ' + str(videopart+1)
    else:
        video_url = videos[0]
##        video_url = video_url.replace('\/','/')
    video_url = video_url + "|referer="+ url
    Log("video_url='{}'".format(video_url))
##    else:
##        #todo; create playslist?

    description = u''
    desc_separator_char = u'; '
    regex_region = 'class="opisanie"(.+?)<noindex>'
    region_html = re.compile(regex_region, re.DOTALL | re.IGNORECASE).findall(full_html)
    if region_html:
        regex = '"/actor/.+?>([^<]+)<'
        source_models = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(region_html[0])
        for model in source_models:
            if model.lower() not in description.lower():
                description = description + utils.cleantext(C.html_parser.unescape(model)) + desc_separator_char
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    if C.PY2: Log(u"description={}".format(description.decode("utf8")))
    if C.PY3: Log(u"description={}".format(description))


    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    

    Log("video_url='{}'".format(video_url))

##    utils.LogFlush()
##    utils.playvid(video_url, name=name, download=download, description=description)
    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
    ##            , download_filespec=download_filespec
        , mode = PLAY_MODE
    ##            , url_factory = url
        , icon_URI = icon_URI            
        )    
#__________________________________________________________________________
#  
