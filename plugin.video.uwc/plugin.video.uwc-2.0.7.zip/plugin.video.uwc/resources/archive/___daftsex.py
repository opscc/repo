#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib

import base64
import json
import traceback
import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]daftsex[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_SCENES
FRONT_PAGE_CANDIDATE = True

ROOT_URL = "https://daftsex.com"

SEARCH_URL = ROOT_URL + '/video/{}'
URL_RECENT = ROOT_URL + '/hot'


MAIN_MODE       = C.MAIN_MODE_daftsex
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)
TEST_MODE       = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '0' #default first page
#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , keyword = 'sex'
            )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=FIRST_PAGE, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={})".format(repr(url), repr(page), repr(end_directory), repr(keyword)))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
        
    try:
        postRequest = {'page' : str(page)}
        postRequest = urllib.urlencode(postRequest)
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = ROOT_URL
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        headers['X-Requested-With'] = 'XMLHttpRequest'
        response = utils.postHtml(url, sent_data=postRequest, headers=headers, compression=False)
    except:
        raise

    list_url = ''
    np_url = None #will be changed later on if items found
##    Log("response='{}'".format(response))

    # parse out list items
##    regex_string = (
##        '<div class="video-item'
##        '.+?href="(?P<videourl>[^"]+)"'
##        '.+?background-image: url\(\'(?P<thumb>[^\']+)\''
##        '.+?<span class="video-time">(?P<duration>[^<]+)<'
##        '.+?"setTitle\(this\);">(?P<label>.[^<\[]+)'
##        '(?P<hd>(?:\[[^\]<]+(?:\]|<)|))'
##        '(?P<desc>)'
##        )
    regex_string = (
        '<div class="video-item'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?data-thumb="(?P<thumb>[^"]+)"'
        '.+?<span class="video-time">(?P<duration>[^<]+)<'
        '.+?"setTitle\(this\);">(?P<label>[^<]+)<'
        '(?P<hd>(?:\[[^\]<]+(?:\]|<)|))'
        '(?P<desc>)'
        )

    info = re.compile(regex_string, re.DOTALL | re.IGNORECASE).finditer(response)
##    for videourl, thumb, label, duration, hd in info:
    label = ""
    videourl = ""
    for item in info:
##            Log("item={}".format(repr(item)))
##            Log("item={}".format(repr(dir(item))))
        videourl=item.group('videourl')
        thumb=item.group('thumb')
        label=item.group('label')
        hd=item.group('hd')
        duration=item.group('duration')
        desc=item.group('desc')
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label='{}'".format(label))        
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc = desc + '\n' + ROOT_URL
            , duration = duration )
    utils.Check_For_Minimum(label, keyword, MAIN_MODE, ROOT_URL, testmode)
    if (testmode == True) and (len(videourl) > 1):
        Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)


    #
    # next page items
    #
    if len(label) > 0: # show a 'next page' if items were found
        np_url = url
    else:
        np_url = None
        
    if not np_url:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:    
        np_number = int(page) + 1
        #Log("np_url='{}'".format(np_url))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number + 1)
                ,url = np_url
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth:
                utils.Notify(msg=np_url+'/page='+str(np_number))  #let user know something is happening
                List(np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace('+',' ').replace(' ','%20')
    searchUrl = SEARCH_URL.format(title)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword=keyword, testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    #    Categories(URL_CATEGORIES, False)
    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    #try and get 1080p version [technically requires an account on vk.com, but sometimes not]
    vk_url = "https://vk.com/al_video.php?act=show_inline&al=1&video="+url.replace("https://daftsex.com/watch/","")
    vk_html = utils.getHtml(vk_url, ROOT_URL)
    regex = '"url(?P<res>\d+)":"(?P<url>[^"]+)"'
    vid_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(vk_html)
    if len(vid_list) > 0:
        video_url = utils.SortVideos(
            sources=vid_list
            ,download=download
            ,vid_res_column=0
            ,max_video_resolution=max_video_resolution
            )
        video_url = video_url.replace("\/", "/")
        Log("video_url='{}'".format(video_url), xbmc.LOGNONE)

    server = None

    if not video_url: #get the max 720p version
        
        full_html = utils.getHtml(url, ROOT_URL)
##        Log(u"full_html='{}'".format(full_html.decode('utf-8')))
        
        #regex = '<iframe preventhide="0".+?src="([^"]+)"'  ##2020-09 second file now has data
        #regex = '<iframe id="[^"]+" preventhide="0".+?src="([^"]+)"'   ##2021-02 second file now has data
        regex = 'window.globEmbedUrl = \'([^\']+)\'.+?hash: "([^"]+)".+?color: "([^"]+)"'   ##2021-04 second file now has data
        url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if url2:
            url2 = "{}{}?color={}".format(url2[0][0], url2[0][1], url2[0][2])
##            Log("url2='{}'".format(url2), xbmc.LOGNONE)
##            return
            full_html = utils.getHtml(url2, ROOT_URL)
        else:
            pass
    ##    Log("response='{}'".format(response), xbmc.LOGNONE)
        
        vid_id = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)    
        token = re.compile('access_token: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
        videos = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
        extra_key = re.compile('extra_key: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(full_html)
        sig = re.compile('\s(?:sig|credentials):\s*"([^"]+?)",', re.DOTALL | re.IGNORECASE).findall(full_html)
        ckey = re.compile('c_key: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
        thumb = re.compile('thumb: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
        cdn_files = re.compile('cdn_files: {([^}]+)}', re.DOTALL | re.IGNORECASE).findall(full_html)
        server = re.compile('server: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(full_html)
        partial = re.compile('partial: {"quality":({"[^}]+})', re.DOTALL | re.IGNORECASE).findall(full_html)

        #different versions of web page may not have same data
        try:    token = token[0]
        except: token = None
        try:    videos = videos[0]
        except: videos = None
        try:    ckey = ckey[0]
        except: ckey = None
        try:    extra_key = extra_key[0]
        except: extra_key = None
        try:    cdn_files = cdn_files[0]
        except: cdn_files = None
        try:    thumb = base64.b64decode(thumb[0]).strip("thumb.jpg")
        except: thumb = None
        try:    server = base64.b64decode(server[0][::-1]) #reverse string then decode it
        except: server = None
        try:    sig = sig[0]
        except: sig = None
        try:    vid_id = vid_id[0]
        except: vid_id = None
        try:
            Log("partial={}".format(repr(partial)))
            partial = json.loads(partial[0])
            Log("partial={}".format(repr(partial)))
        except: partial = None

##        Log("token={}".format(repr(token)))
##        Log("videos={}".format(videos))
##        Log("extra_key={}".format(extra_key))
##        Log("ckey={}".format(ckey))
##        Log("thumb={}".format(thumb))
##        Log("cdn_files={}".format(cdn_files))
##        Log("server={}".format(server))
##        Log("sig={}".format(sig))
##        Log("vid_id={}".format(vid_id))
##        Log("partial={}".format(repr(partial)))

        if cdn_files: #newer style
            regex = '"mp4_(\d+)":"([^"]+)'
            vid_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cdn_files)
            video_url = utils.SortVideos(
                sources=vid_list
                ,download=download
                ,vid_res_column=0
                ,max_video_resolution=max_video_resolution
                )
            baseurl = "https://{}/videos/{}/".format(server,videos.replace("_","/"))
            video_url = "{}{}".format(baseurl, video_url.replace(".",".mp4?extra=") )
    ##        Log("video_url={}".format(video_url))

        elif server: #older styple


            #https://psv84-2.daxab.com/method/video.get/-101039094_456241743?token=dbBO64qVWOWabHqNafKLtI_GOlVbD_ZvIRS&videos=-101039094_456241743&ckey=e2613699b9f8acbc
            #https://psv66-1.daxab.com/method/video.get/-101039094_456241743&token=dbBO64qVWOWabHqNafKLtI_GOlVbEfIZbZx&videos=-101039094_456241743&ckey=e2613699b9f8acbc
            #&credentials=2z6v8hntZwUIQV6Lug9k_nTW-ChFF047WoWJ4DWITVI6i70i02Aqfeodbr3knPyJtIsbqkGlXJShEoO3oQ3eE8ft2T6zp3Y4cwjIjyC26yexCtW_x5TtvwaYO4ykuM6Qzzf7F7m4g_RXq7vQlgOwPJQU4jb
            #&credentials=5zAlb5cxHHiXkN0iT2MbPrT3Fg1Q8FvTRrljmuNDCfAak1_hX9lU-2xFP9JMqhSuLjrAQgg26MpfiGdVmhRH9qdM6nh6Br7zuvTSc9uB-9V3N-wQ6n4SsohDWuF5_pLTeTJvCH_bnRLF_ZmKvP8F4HzdU2n
            base_str = "https://{}/method/video.get/{}?token={}&videos={}&ckey={}&credentials={}"
            intermediate_url = base_str.format(server,vid_id,token,videos,ckey,sig)
##            Log("intermediate_url={}".format(intermediate_url))
            http_referrer = "https://daxab.com/"
            json_html = utils.getHtml(intermediate_url, http_referrer)
            
            json_sources = json.loads(json_html)
##            Log("json_sources={}".format(repr(json_sources)))

            if "error" in json_sources:
                utils.Notify(json_sources["error"]["error_msg"] + '\n' + ROOT_URL)
                return

            vid_list = list()
            key_list = list()
            if "response" in json_sources:
                for json_item in json_sources["response"]["items"]:
                    for vid_src in json_item["files"]:
                        Log("vid_src={}".format(repr(vid_src)))
                        res = vid_src.split('=')[0].replace('mp4_','')
                        v_url = json_item["files"][vid_src]
                        Log("res={}".format(repr(res)))
                        vid_list.append( (res, v_url) )
            Log("vid_list={}".format(repr(vid_list)))

            video_url = utils.SortVideos(
                sources=vid_list
                ,download=download
                ,vid_res_column=0
                ,max_video_resolution=max_video_resolution
                )
            video_proxy_res = None
            for q,u in vid_list: #this site needs quality info
                Log("q={}".format(q))
                Log("u={}".format(u))
                if video_url == u:
                    if q in partial:
                        video_proxy_res = q
                        extra_key = partial[q]
                    break
            if video_proxy_res:
                video_url = video_url.replace("https://", "https://"+server+"/") #needs this remote proxy
                video_url = video_url + "&videos={}&extra_key={}&videos={}".format(vid_id, extra_key, vid_id)
                
          #mp4_720=https://pvv4.vkuservideo.net/c611801/12/e06Nj8zPjs0OzU5/videos/b5dd2d9bbb.720.mp4?extra=2HpvlSmMOXhmIpUBwDBFavdt6a7hcXNAdsyHKP9uAApObY_91JOABtmsY6Y9vURTa2aWUAHmltolHjjFNg7MTKFMumTm00goEdr-s-qi3WAbs7bFnZqo6X-_QyHN_TCdjLYv98Loc9_F5JNPFrwC5YM
#https://psv99-1.daxab.com/pvv4.vkuservideo.net/c611801/12/e06Nj8zPjs0OzU5/videos/b5dd2d9bbb.720.mp4?extra=2HpvlSmMOXhmIpUBwDBFavdt6a7hcXNAdsyHKP9uAApObY_91JOABtmsY6Y9vURTa2aWUAHmltolHjjFNg7MTKFMumTm00goEdr-s-qi3WAbs7bFnZqo6X-_QyHN_TCdjLYv98Loc9_F5JNPFrwC5YM
#https://psv64-1.daxab.com/pvv4.vkuservideo.net/c611801/12/e65MDc6MDc7MDM3/videos/931ccc602e.720.mp4?extra=wv48weS5jXuL31w2sk1hLbTD0iVTTl4TLWX49iwlcW3XwZcXRujZR4bGqcrOCg8_0MYSoLbhO4g3gw6p3u5hOwyLpvrpkur5S_BA3G0vxASJtObqhni4Wl6Ce_1IpuoWvwPcQL1LmvJ8FOQyqxPtt2iCTSRS
            #&c_uniq_tag=VtMDj9T7SLywOxZzCcmcC4L3p3yxKYvTOrI8PKoAmz0
            #&c_uniq_tag=VtMDj9T7SLywOxZzCcmcC4L3p3yxKYvTOrI8PKoAmz0
            #&c_uniq_tag=VtMDj9T7SLywOxZzCcmcC4L3p3yxKYvTOrI8PKoAmz0
            #&videos=-101039094_456241743&extra_key=WurrSTHwvP8avhRBEnk08Q&videos=-101039094_456241743
            #&videos=-101039094_456241743&extra_key=WurrSTHwvP8avhRBEnk08Q&videos=-101039094_456241743
            url = None
            Log("video_url={}".format(video_url))
##            return
        
##            import time
##            base_str = "https://{}/method/video.sig?callback=jQuery31105973447211193958_1530417119721"
##            base_str = "https://{}/method/video.sig?callback=jQuery311"
##            
##            base_str = base_str + "&token={}&videos={}&extra_key={}&ckey={}&sig={}&_={}"
##            intermediate_url = base_str.format(server,token,videos,extra_key,ckey,sig,int(time.time()))
##            http_referrer = url #encode this in http command
##            response = utils.getHtml ( intermediate_url, http_referrer)
##
##            match_240 =  re.compile('"mp4_240":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
##            match_360 =  re.compile('"mp4_360":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
##            match_480 =  re.compile('"mp4_480":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
##            match_720 =  re.compile('"mp4_720":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
##            #2019-06-06 site says it has 1080, but requires special addon....yeah...right
##            match_1080 = re.compile('"mp4_1080":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)
##
##            if match_240:
##                try:    extra_key = re.compile('"240":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
##                except: pass
##                video_url = "https://{}/{}&extra_key={}&videos={}".format(server, match_240[0].replace("\/","/").strip("https://"), extra_key, vid_id )
##            if match_360:
##                extra_key = re.compile('"360":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
##                video_url = "https://{}/{}&extra_key={}&videos={}".format(server, match_360[0].replace("\/","/").strip("https://"), extra_key, vid_id )
##            if match_480:
##                extra_key = re.compile('"480":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
##                video_url = "https://{}/{}&extra_key={}&videos={}".format(server, match_480[0].replace("\/","/").strip("https://"), extra_key, vid_id )
##            if match_720:
##                extra_key = re.compile('"720":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
##                video_url = "https://{}/{}&extra_key={}&videos={}".format(server, match_720[0].replace("\/","/").strip("https://"), extra_key, vid_id )
##            if match_1080:
##                try:
##                    extra_key = re.compile('"1080":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
##                    video_url = "https://{}/{}&extra_key={}&videos={}".format(server, match_1080[0].replace("\/","/").strip("https://"), extra_key, vid_id )
##                except:pass




    #always set referrer so that 'kodi' does not appear on the target server
    if '|' not in video_url:
        headers = C.DEFAULT_HEADERS.copy()
        if url: headers['Referer'] = url
        if server and  server not in video_url:
            headers['User-Agent'] = "Firefox" #this trick allows older site pages to get 1080 content
            
        video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    #we should have a url by now...
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(url, ROOT_URL))
        return
    
    #during testmode, only ensure that a url can be generated
    if testmode:
        Log("Would have played video_url; but in test mode")
        return   

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile)
#__________________________________________________________________________
#
