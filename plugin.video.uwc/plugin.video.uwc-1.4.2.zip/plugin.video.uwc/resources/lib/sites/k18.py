'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import sys
import xbmc, xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES = ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 20
ROOT_URL = "https://k18.co"
SEARCH_URL = ROOT_URL + '/?s='

MAIN_MODE = '230'
LIST_MODE =  '231'
PLAY_MODE = '232'
CATEGORIES_MODE = '233'
SEARCH_MODE = '234'


@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( \
        SPACING_FOR_TOPMOST, utils.search_text_color) \
        ,url=ROOT_URL + '/categories/'
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True 
        )
    List(ROOT_URL+'/page/1/?filter=latest', end_directory=True)

@utils.url_dispatcher.register(str(LIST_MODE), ['url'], ['end_directory'])
def List(url, end_directory=True):

    Log("url='{}'".format(url))
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None
    #cookieString = getCookiesString()

    if end_directory == True:
        utils.addDir(name="[COLOR {}]Search[/COLOR]".format( \
            utils.search_text_color) \
            ,url=SEARCH_URL \
            ,mode=SEARCH_MODE \
            ,iconimage=utils.search_icon \
            ,Folder=True \
            )

    #distinguish between adverts and videos    
    #video_region = re.compile('class=\"widget-title\">(.+?)<h2 class=\"widget-title\">', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    video_region = listhtml.split('class="widget-title"')[1]
    #Log("video_region='{}'".format(video_region), xbmc.LOGNONE)
    
    #match = re.compile(r'class="content-list-thumb">\s+<a href="([^"]+)" title="([^"]+)">.*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    #match = re.compile('class="content-list-thumb">\s*<a href="([^"]+)" title="([^"]+)".*?data-lazy-src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)

    if 'duration\"' in video_region: #need this test because regex will go forever if info is not found
        match = re.compile('<article id=\".+?href=\"([^\"]+)\".+?title=\"([^\"]+)\".+?(?:data-src|poster)=\"([^\"]+)\".+?duration\">([^<]+)<', re.DOTALL).findall(video_region)
    else:
        match = None
    #Log("match='{}'".format(match), xbmc.LOGNONE)
    if match:
        #Log("match='{}'".format(match), xbmc.LOGNONE)
        for videopage, name, img, duration in match:
            name = SPACING_FOR_NAMES + utils.cleantext(name)
            utils.addDownLink( \
                name = name \
                , url = videopage \
                , mode = PLAY_MODE \
                , iconimage = img \
                , duration=duration \
                , stream = False )
    else: #searched items don't include duration
        #Log("match='{}'".format(match), xbmc.LOGNONE)
        match = re.compile('<article id=\".+?href=\"([^\"]+).+?data-src=\"([^\"]+).+?alt=\"([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(video_region)
        #Log("match='{}'".format(match), xbmc.LOGNONE)
        for videopage, img, name in match:
            #Log("url22='{}'".format(url), xbmc.LOGNONE)
            name = SPACING_FOR_NAMES + utils.cleantext(name)
            utils.addDownLink( \
                name = name \
                , url = videopage \
                , mode = PLAY_MODE \
                , iconimage = img \
                , stream = False )
        
    #Log("match='{}'".format(match), xbmc.LOGNONE)
    nextp=re.compile("\"pagination\".+?class=\"current\".+?href=(?:\"|')([^\"']+)(?:\"|') class=\"inactive\"", re.DOTALL | re.IGNORECASE).findall(listhtml)
    Log("nextp='{}'".format(nextp), xbmc.LOGNONE)
    if nextp:
        np_url = nextp[0]
        np_number=np_url.split('/')[4]
        Log("np_url='{}'".format(nextp), xbmc.LOGNONE)
        Log("np_number='{}'".format(nextp), xbmc.LOGNONE)
        if not np_number.isdigit(): np_number=np_url.split('/')[5]
        if not np_number.isdigit(): np_number=np_url.split('/')[6]

        utils.addDir(name="{}[COLOR {}]Next Page ({})[/COLOR]".format( \
            SPACING_FOR_NEXT, utils.search_text_color, np_number) \
            ,url=np_url \
            ,mode=LIST_MODE \
            ,iconimage=utils.next_icon \
            ,page=np_number \
            ,Folder=True \
            )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()


def getCookiesString():
    cookieString=""
    import cookielib
    try:
        cookieJar = cookielib.LWPCookieJar()
        cookieJar.load(utils.cookiePath,ignore_discard=True)
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except:
        import sys,traceback
        traceback.print_exc(file=sys.stdout)
    return cookieString


@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("Search: " + searchUrl)
    List(searchUrl)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Cat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<article id=\".+?href=\"([^\"]+)\".+?src=\"([^\"]+)\".+?\"cat-title\">([^<]+)<', re.DOTALL).findall(cathtml)
    for catpage, thumb, name in match:
        #utils.addDir(name, catpage, LIST_MODE, '')
        utils.addDir(name=name
            ,url = catpage
            ,mode=LIST_MODE 
            ,iconimage=thumb
            )

    np_url=re.compile("<li class='pagination-nav'><a href=\"(.+?)\"", re.DOTALL).findall(cathtml)
    if np_url:
        np_url = np_url[0]
        Log("np_url='{}'".format(np_url))
        try:
            np_number = np_url.split('page/')[1]
            np_number = int(np_number.split('/')[0])
        except:
            Log("unkown page location")
#        utils.Notify(msg=np_url, duration=2000)  #let user know something is happening
        if int(np_number) < MAX_SEARCH_DEPTH: #search some more, but not forever
            Cat(np_url)
    else:
        Log("np_url not found")

    utils.add_sort_method()
    utils.endOfDirectory()

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    videopage = utils.getHtml(url, referer=url)
    
    match = re.compile('content=\"https://www.pornhub.com/embed/([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videopage)
    if match: # this is a redirect; use that site's play code
        from resources.lib.sites import pornhub
        pornhub_url = "https://www.pornhub.com/view_video.php?viewkey="+match[0]
        pornhub.Playvid(pornhub_url, name=name, download=download)
        return

    match = re.compile('itemprop="embedURL" content=\"(https://www.youporn.com/embed/[^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videopage)
    if match: # this is a redirect; use that site's play code
        match= match[0] + '/'
        Log("match='{}'".format(match))
        videopage = utils.getHtml(match, referer=url)



    #match = re.compile('<iframe src=\"([^\"]+)\" frameborder=0', re.DOTALL | re.IGNORECASE).findall(videopage)
    #videopage = utils.getHtml(match[0], referer=url)
    utils.playvideo(videopage, name, download, url)
