'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES = ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 10
ROOT_URL = "https://www.vporn.com"
SEARCH_URL = ROOT_URL + '/search?q='

MAIN_MODE = '500'
LIST_MODE =  '501'
PLAY_MODE = '502'
CAT_MODE = '503'
SEARCH_MODE = '504'


@utils.url_dispatcher.register('500')
def Main():
    utils.addDir('[COLOR {}]Categories[/COLOR]'.format(utils.search_text_color),ROOT_URL+'/newest/',CAT_MODE,'','')
    List(ROOT_URL+'/newest/')
    utils.add_sort_method()
    utils.endOfDirectory()

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    Log("url='{}'".format(url))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( \
            SPACING_FOR_TOPMOST, utils.search_text_color) \
            ,url=SEARCH_URL \
            ,mode=SEARCH_MODE \
            ,iconimage=utils.search_icon \
            ,Folder=True \
            )
        
    try: listhtml = utils.getHtml(url, '')
    except: return None

    #match = re.compile(r'class="thumb"><img src="([^"]+)".*?<span class="time">(.*?)(\d+:[^\s]+).*?href="([^"]+)" title="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    #for img, hd, duration, videopage, name in match:
    match = re.compile('class="video".+?href="([^"]+?)".+?<span class="time">([^<]+?)<.+?img src="([^"]+?)" alt="([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, duration, img, name in match:
        name = utils.cleantext(name)
        utils.addDownLink(name, videopage, PLAY_MODE, img \
                ,'', stream=False, duration=duration)

    try:
        spacing_for_next = ""
        nextp = re.compile('<a class=\"next link(?:s|age)\" title=\"Next Page\" href=\"(.+?)\"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(spacing_for_next, utils.search_text_color, nextp[0].split('/')[4])
        if end_directory == True:
            utils.addDir(np_label, nextp[0], LIST_MODE , '', Folder=True)
        else:
            return nextp[0]
    except:
        pass

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    page = utils.getHtml(url, '')
    #match = re.compile(r'videoUrlMedium = "(.+?)"', re.DOTALL | re.IGNORECASE).findall(page)
    match = None
    match_480 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="480p"', re.DOTALL | re.IGNORECASE).findall(page)
    match_720 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="720p HD"', re.DOTALL | re.IGNORECASE).findall(page)
    match_1080 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="1080p"', re.DOTALL | re.IGNORECASE).findall(page)
    if match_1080 and not match : match = match_1080
    if match_720 and not match : match = match_720
    if match_480 and not match : match = match_480
    if not match:
        #try older style web page
        #match = re.compile(r'<video id="vporn-video-player".*? src="([^"]+)" type="video/mp4" label="1080p"', re.DOTALL | re.IGNORECASE).findall(page)
        #<video id="vporn-video-player
        Log("no match found at url='{}', name=''".format(url,name), xbmc.LOGNONE)

    videourl = match[0]+utils.Header2pipestring()+"&Referer=https://www.vporn.com"
    utils.playvid(videourl, name, download)

##    if download == 1:
##        utils.downloadVideo(match[0]+utils.Header2pipestring()+"&Referer=https://www.vporn.com", name)
##    else:
##        iconimage = xbmc.getInfoImage("ListItem.Thumb")
##        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
##        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
##        xbmc.Player().play(match[0], listitem)

@utils.url_dispatcher.register(CAT_MODE)
def Categories():
    cathtml = utils.getHtml(ROOT_URL)
    match = re.compile('<li><a href="/cat/(.+?)"><img .*>(.+?)</a></li>').findall(cathtml)
    for catid, name in match[1:]:
        catpage = ROOT_URL+"/cat/"+ catid
        utils.addDir(name, catpage, LIST_MODE, '')
    utils.add_sort_method()
    utils.endOfDirectory()
    
@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    if keyword == '': keyword = None
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    title = keyword.replace(' ','_')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(searchUrl, end_directory)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
