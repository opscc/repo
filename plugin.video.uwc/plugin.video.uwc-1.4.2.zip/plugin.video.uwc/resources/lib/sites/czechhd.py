'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc, xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES = ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 10
ROOT_URL = "http://czechhd.net"
SEARCH_URL = ROOT_URL + 'search-'

MAIN_MODE = '310'
LIST_MODE =  '311'
PLAY_MODE = '312'
CATEGORIES_MODE = '313'
SEARCH_MODE = '314'

    
@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    List(ROOT_URL)

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    Log("url='{}'".format(url))
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None

    if end_directory == True:
        utils.addDir(name="[COLOR {}]Search[/COLOR]".format(utils.search_text_color), url=ROOT_URL+"?s=", mode=314, iconimage='')
    
    #match = re.compile('<div id="main">(.*?)<div id="sidebar', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    #match1 = re.compile('data-id="\d+" title="([^"]+)" href="([^"]+)".*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(match)
    #match = re.compile('#navigation-wrapper -->.*<div class="container">(.*?)class="container"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match = re.compile('<!--end #breadcrumbs-->(.*?)<!-- #content -->', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not match: Log(listhtml, xbmc.LOGERROR)

    #match1 = re.compile('title="([^"]+)" href="([^"]+)".*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(match[0])
    #for name, videopage, img in match1:
    match1 = re.compile('id="post.+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(match[0])
    if not match1: Log(listhtml, xbmc.LOGERROR)
    for videopage, img, name in match1:
        name = utils.cleantext(name)
        utils.addDownLink(name, videopage, PLAY_MODE, img, '')

    #match2 is the formatting for 'searched' items
    match2 = re.compile('img width.*?src="([^"]+)".*?<h3><a href="([^"]+)">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(match[0])
    for img, videopage, name in match2:
        name = utils.cleantext(name)
        utils.addDownLink(name, videopage, PLAY_MODE, img, '')

    try:
        nextp = re.compile('href="([^"]+)">Next', re.DOTALL | re.IGNORECASE).findall(match)
        utils.addDir("[COLOR {}]Next Page[/COLOR]".format(utils.search_text_color), nextp[0], 311, '')
    except: pass

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()


@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<a href="(http://czechhd.net/category/[^"]+)" >([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        utils.addDir(name, catpage, LIST_MODE, '')    
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        List(searchUrl)

