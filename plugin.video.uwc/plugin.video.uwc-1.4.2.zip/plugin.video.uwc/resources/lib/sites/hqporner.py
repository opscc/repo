'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin,xbmc
from resources.lib import utils
from resources.lib.utils import Log

URL_SUFFIX_PAGE1 = '/hdporn/1'
URL_SUFFIX_GIRLS = "/porn-actress.php"
URL_SUFFIX_STUDIOS = "/porn-studios.php"
URL_SUFFIX_CATAGORIES = "/porn-categories.php"

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES = ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 10
ROOT_URL = "https://hqporner.com"
SEARCH_URL = ROOT_URL + '/?q='

MAIN_MODE = '150'
LIST_MODE =  '151'
PLAY_MODE = '152'
CATEGORIES_MODE = '153'
SEARCH_MODE = '154'

@utils.url_dispatcher.register(MAIN_MODE)
def HQMAIN():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( \
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = ROOT_URL + URL_SUFFIX_CATAGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.search_icon \
                ,Folder=True \
                )
    utils.addDir("{}[COLOR {}]Studios[/COLOR]   ".format(SPACING_FOR_TOPMOST, utils.search_text_color)
                ,url = ROOT_URL + URL_SUFFIX_STUDIOS
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.search_icon \
                ,Folder=True \
                )
    utils.addDir("{}[COLOR {}]Girls[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color)
                ,url = ROOT_URL + URL_SUFFIX_GIRLS
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.search_icon 
                ,Folder=True 
                )

    List( ROOT_URL + URL_SUFFIX_PAGE1 )
    
    utils.endOfDirectory()


@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( \
            SPACING_FOR_TOPMOST, utils.search_text_color) \
            ,url=SEARCH_URL \
            ,mode=SEARCH_MODE \
            ,iconimage=utils.search_icon \
            ,Folder=True \
            )
    
    try:    listhtml = utils.getHtml(url, '')
    except: return None


    #distinguish between adverts and videos
    video_region = listhtml.split('<ul class="actions pagination">')[0] # re.compile('(.+)<a href="([^"]+)"[^>]+>Next', re.DOTALL | re.IGNORECASE).findall(listhtml)[0][0]

    #2018-12-03
    #match = re.compile('<a href="([^"]+)" class="image featured non-overlay".*?<img id="[^"]+" src="([^"]+)" alt="([^"]+)".*?fa-clock-o meta-data">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(link)
    #2018-12-04
    match = re.compile('src="([^"]+)" alt="([^"]+)".*?<a href="([^"]+)".*?fa-clock-o meta-data">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(video_region)
    #Log(listhtml, xbmc.LOGERROR)

    for img, name, url, duration in match:
        name = utils.cleantext(name).strip()
        name = SPACING_FOR_NAMES + name
        #videourl = URL_ROOT.format(url)
        videourl = ROOT_URL + url
        utils.addDownLink(name, videourl, PLAY_MODE, 'https:' + img, '', duration=duration)

    nextp=re.compile('<a href="([^"]+)"[^>]+>Next', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if nextp:
        #np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(
        #    spacing_for_next,utils.search_text_color, nextp[0].split('/')[2])
        #utils.addDir(np_label, nextp, LIST_MODE, '', Folder=True)
        #Log("nextp={}".format(nextp))
        np_url = nextp[0]
        Log("np_url={}".format(np_url))
        #np_url = ROOT_URL + nextp[0]
        if np_url.startswith('/'): np_url = ROOT_URL + np_url
        Log("np_url={}".format(np_url))
        try:
            np_number=nextp[0].split('/')[2]
        except:
            np_number=nextp[0].split('&p=')[1]

        utils.addDir(name="{}[COLOR {}]Next Page ({})[/COLOR]".format( \
            SPACING_FOR_NEXT, utils.search_text_color, np_number) \
            ,url=np_url \
            ,mode=LIST_MODE \
            ,iconimage=utils.next_icon \
            ,page=np_number \
            ,Folder=True \
            )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
   
@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def HQCAT(url):
    link = utils.getHtml(url, '')
    tags = re.compile('<a href="([^"]+)"[^<]+<img src="([^"]+)" alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(link)
    tags = sorted(tags, key=lambda x: x[2])
    for caturl, catimg, catname in tags:
        caturl = "https://www.hqporner.com" + caturl
        catimg = "https://www.hqporner.com" + catimg        
        utils.addDir(catname,caturl,151,catimg)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('154', ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("Search: " + searchUrl)
    
    List(searchUrl, end_directory)
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def HQPLAY(url, name, download=None):

    videopage = utils.getHtml(url, url)

    iframeurl = re.compile(r"nativeplayer\.php\?i=([^']+)", re.DOTALL | re.IGNORECASE).findall(videopage)
    if not (iframeurl[0].startswith('http')):
        iframeurl = 'https:' + iframeurl[0]

    if re.search('bemywife', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)
    elif re.search('mydaddy', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)        
    elif re.search('\/hqwo\.cc\/', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getBMW(iframeurl)
    elif re.search('5\.79', iframeurl, re.DOTALL | re.IGNORECASE):
        videourl = getIP(iframeurl)
    elif re.search('flyflv', iframeurl, re.DOTALL | re.IGNORECASE):
        if (iframeurl.startswith('https:')):
            #apr 2018; https requires authentication for this site, http no
            iframeurl = iframeurl.replace('https://','http://')
            
        videourl = getFly(iframeurl)
    else:
        #print (videopage)
        utils.notify('Oh oh','Couldn\'t find a supported videohost')
        return

    if not videourl:
        #print (videopage)
        utils.notify('Oh oh','Couldn\'t find a supported videohost')
        return

    if not (videourl.startswith('http')):
        videourl = 'https:' + videourl
        
    utils.playvid(videourl, name, download)


def getBMW(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile(r'file: "([^"]+mp4)", label: "\d', re.DOTALL | re.IGNORECASE).findall(videopage)
    try:
        videourl = videos[-2]
    except:
        try:
            videourl = videos[-1]
        except:
            videos = re.compile('src=\'(https\:\S+)\'>', re.DOTALL | re.IGNORECASE).findall(videopage)
            videourl = getIP2(videos[0])
    
    return videourl

def getIP2(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('"file": "(\S+)",', re.DOTALL | re.IGNORECASE).findall(videopage)    
    videourl = videos[-1]
    return videourl


def getIP(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('file": "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = videos[-1]
    return videourl

def getFly(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('src=\'(.*)\' type=', re.IGNORECASE).findall(videopage)
    videourl = videos[-1]
    if not (videourl.startswith('http')):
        videourl = 'http:' + videourl
        
    return videourl
