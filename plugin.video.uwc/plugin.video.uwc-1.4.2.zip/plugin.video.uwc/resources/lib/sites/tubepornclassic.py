'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = 10

ROOT_URL = "https://tubepornclassic.com"
SEARCH_URL = ROOT_URL + '/search/{}/1'
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_TOPRATED = ROOT_URL + '/ajax/best_rated/?page=1'

MAIN_MODE = '360'
LIST_MODE =  '361'
PLAY_MODE = '362'
CAT_MODE = '363'
SEARCH_MODE = '364'


@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CAT_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True
        )
    
    List(ROOT_URL + '/latest-updates/')
    

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )

    listhtml = utils.getHtml(url, '')

    video_region = listhtml.split('class="pagination"')[0]

    regex = 'class="item  ">.*?href="([^"]+)".*?src="([^"]+)".*?class="title">([^<]+)<.*?duration">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, duration in info:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        duration = duration.replace(' min','s').replace(':','m ')
        #Log("hd={}".format(hd))
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration
            , noDownload=False)
        

    next_page_regex ='class="next">.*?<a href="([^"]+)".*?data-query="page:([^"]+)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url, np_number in np_info:
            #Log("np_url={}".format(np_url))
            if np_url == '#search':
                np_url = url
                old_np_number=np_url.split('/')[5]
                np_url = np_url.replace('/'+old_np_number, '/'+np_number)
            else:
                np_number = np_url.split('/')[2]
            if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
            else:
                utils.Notify(msg=np_url, duration=500)  #let user know something is happening
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    List(np_url, end_directory)
                else:
                    utils.add_sort_method()
                    utils.endOfDirectory()    
                    

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()



@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):

    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    end_directory=False #used when testing multipagesearch
    
    title = keyword.replace(' ','%20').replace('+','%20')
    searchUrl = searchUrl.format(title)
    Log("searchUrl='{}'".format(searchUrl))
    List(searchUrl, end_directory)

    end_directory=True #used when testing multipagesearch
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

        

@utils.url_dispatcher.register(CAT_MODE, ['url'])
def Categories(url):

    html = utils.getHtml(url, '')

    regex = '<a class="item".href="([^"]+)".*?class="thumb".src="([^"]+)".*?class="title">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    #Log("info='{}'".format(info))
    for url, thumb, label in info:
        if url.startswith('/'): url = ROOT_URL + url
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        #Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,Folder=True 
            )

    utils.add_sort_method()
    utils.endOfDirectory()
    


@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    
    videopage = utils.getHtml(url, '')
    regex = "pC3:'([^']+)',.+?\"video_id\": (\d+),"
    vid_codes = re.compile(regex, re.DOTALL ).findall(videopage)
    for code, vid_id in vid_codes:
        post_code = str(vid_id) + ',' + code
        Log("post_code={}".format(post_code))
        import urllib
        post_code = 'param=' + urllib.quote(post_code)
        Log("post_code={}".format(post_code))


    from requests import Request, Session
    s = Session()
    post_url = 'http://member.tubepornclassic.com/sn4diyux.php'
    headers = {"User-Agent": utils.USER_AGENT
               , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
               , "Referer": url
               }
    data = post_code

    proxies = {}
    #proxies = {"http": "127.0.0.1:8888"}

    req = Request('POST', post_url, data=data, headers=headers)
    prepped = s.prepare_request(req)
    resp = s.send(prepped , proxies=proxies, verify=False)
    #Log(resp.status_code)
    #Log("resp.content='{}'".format(repr(resp.content)))


    regex = "'([^']+)'"
    file_code = re.compile(regex, re.DOTALL ).findall(resp.content) [0]
    #Log("file_code={}".format(file_code))
    import json
    items = json.loads(file_code)
    #Log("video_url={}".format(items[0]['video_url']))
    videourl= utils.alltubes_decode(items[0]['video_url'])
    #Log("videourl={}".format(videourl.encode()))

##    return
##    videourl = re.compile("'file': '([^']+)", re.DOTALL | re.IGNORECASE).findall(videopage)[-1]
##    videourl = utils.getVideoLink(videourl, url)
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:    
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)
