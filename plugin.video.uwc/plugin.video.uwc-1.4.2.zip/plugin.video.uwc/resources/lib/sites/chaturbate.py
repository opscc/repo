'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import sqlite3
import urllib

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

import urllib2
import gzip
import StringIO

addon = utils.addon

HTTP_HEADERS_IPAD = 'Mozilla/5.0 (iPad; CPU OS 8_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B410 Safari/600.1.4'
cbheaders = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Accept': '*/*',
        'Referer': 'https://chaturbate.com/',
        'Accept-Encoding': 'gzip'
             }

@utils.url_dispatcher.register('220')
def Main():
    List('https://chaturbate.com/female-cams/?page=1')

@utils.url_dispatcher.register('221', ['url'], ['page'])
def List(url, page=1):

    #utils.addDir("[COLOR {}]Refresh [/COLOR]".format(utils.refresh_text_color),'',224,'',Folder=False)
    utils.addDir(name="[COLOR {}]Refresh[/COLOR]".format( \
        utils.refresh_text_color) \
        ,url='' \
        ,mode=224 \
        ,iconimage=utils.refresh_icon \
        ,Folder=True \
        )


    
    #try:      listhtml = utils.getHtml2(url)
    try:      listhtml = utils.getHtml(url)
    except:   return None

    #match = re.compile(r'<li>\s+<a href="([^"]+)".*?src="([^"]+)".*?<div[^>]+>([^<]+)</div>.*?href[^>]+>([^<]+)<.*?age[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match = re.compile('<li class="room_list_room".*?<a href="([^"]+)">.*?img src="([^"]+)".*?<div[^>]+>([^<]+)<\/div>.*?href[^>]+> ([^<]+)<.*?age[^>]+>([^<]+).*?,\s(\d+)\sviewers', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, status, name, age, viewers in match:
        name = utils.cleantext(name.strip())
        status = status.replace("\n","").strip()
        name = "{}".format(name)
        videopage = "https://chaturbate.com" + videopage
        utils.addDownLink(name, videopage, 222, img, '', noDownload=True, duration=viewers)
    if len(match) == 0:
        utils.Log("Can't find any matches:. Html here:\n'{}'".format(listhtml), xbmc.LOGNONE)

    try:
        page = page + 1
        nextp=re.compile('<a href="([^"]+)" class="next', re.DOTALL | re.IGNORECASE).findall(listhtml)
        next_url = "https://chaturbate.com" + nextp[0]
        #utils.addDir("[COLOR {}]Next Page ({})[/COLOR]".format(utils.search_text_color, page)
        #, next_url, 221,'', page)
        utils.addDir(name=" [COLOR {}]Next Page ({})[/COLOR]".format( \
            utils.search_text_color, page) \
            ,url=next_url \
            ,mode=221 \
            ,iconimage=utils.next_icon \
            ,page=page \
            ,Folder=True \
            )


        
    except: pass

    utils.add_sort_method()
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('224')
def refresh_page():
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')
    
@utils.url_dispatcher.register('223')
def clean_database(showdialog=True):
    return #don't clean up image database until we figure out how to get images for off-line models
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".highwebmedia.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".highwebmedia.com")
            if showdialog:
                utils.notify('Finished','Chaturbate images cleared')
    except:
        pass

@utils.url_dispatcher.register('222', ['url', 'name'])
def Playvid(url, name):

    playmode = int(addon.getSetting('chatplay'))
    listhtml = utils.getHtml(url, hdr=cbheaders)
    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    
    m3u8url = re.compile(r"jsplayer, '([^']+)", re.DOTALL | re.IGNORECASE).findall(listhtml)
    if m3u8url:
        m3u8stream = m3u8url[0]
        m3u8stream = m3u8stream.replace('_fast','')
    else:
        m3u8stream = False


    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    listitem.setProperty("IsPlayable","true")
    
    
    if playmode == 0: # direct

        m3u8stream = "{}{}".format(m3u8stream, utils.Header2pipestring(cbheaders) )
        utils.Log("direct m3u8stream='{}'".format(m3u8stream), xbmc.LOGNONE)

        if m3u8stream:
            videourl = m3u8stream
        else:
            utils.notify('Oh oh','Couldn\'t find a playable webcam link')
            return
        
    elif playmode == 1: # F4mProxy

        if m3u8stream:

            m3u8stream = "{}{}".format(m3u8stream, utils.Header2pipestring(cbheaders) )
            utils.Log("fmproxy m3u8stream='{}'".format(m3u8stream), xbmc.LOGNONE)
        
            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            f4mp.playF4mLink(
                m3u8stream
                , name
                , proxy = None
                , use_proxy_for_chunks = False
                , maxbitrate = int(addon.getSetting('max_bit_rate'))
                , simpleDownloader = False
                , auth = None
                , streamtype = 'HLSREDIR'
                , setResolved = False
                , swf = None
                , callbackpath = ""
                , callbackparam = ""
                , iconImage = iconimage
                
                )
            #, download_path='c:\\temp\\Swish Swish (Ft. Nicki Minaj) - Katy Perry.ts'
            return
        
        else:
            utils.notify('Oh oh','Couldn\'t find a playable webcam link')
            return        
    
    elif playmode == 2:  # RTMP
        #utils.Log(listhtml, xbmc.LOGNONE)
        flv_info = []
        embed = re.compile(r"EmbedViewerSwf\(*(.+?)\);", re.DOTALL).findall(listhtml)[0]
        for line in embed.split("\n"):
            #data = re.search("""\s+["']([^"']+)["'],""", line)
            data = re.search('["\']([^"\']+)["\'],*', line)
            if data:
                flv_info.append(data.group(1))
        
        streamserver = "rtmp://%s/live-edge"%(flv_info[2])
        modelname = flv_info[1]
        username = flv_info[8]
        password = urllib.unquote(flv_info[12].replace('\u0022', '"'))
        unknown = flv_info[13]
        swfurl = "https://chaturbate.com/static/flash/CBV_2p690.swf"
        swfurl = "https://chaturbate.com" + flv_info[0]

        
        videourl = "{} app=live-edge swfUrl={} tcUrl={}"\
                   .format( streamserver, swfurl, streamserver )
        videourl += " pageUrl=https://chaturbate.com/{}/ conn=S:AnonymousUser"\
                    .format(modelname)
        videourl += " conn=S:{} conn=S:2.690 conn=S:{}"\
                    .format(modelname ,username)
        videourl += " conn=S:{} playpath=mp4".format(password)
        utils.Log(videourl)

    elif playmode == 3: #inputstream

        m3u8stream = "{}{}".format(m3u8stream, utils.Header2pipestring(cbheaders) )
        videourl = m3u8stream
        if ".m3u8" in videourl:
            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            #liz.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+__user_agent__)
            #listitem.setProperty('inputstream.adaptive.stream_headers', utils.Header2pipestring().replace("|", '') + "&Accept-Encoding=gzip, deflate, br"  )
            #listitem.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+HTTP_HEADERS_IPAD  )
            
            xbmc.log("using inputstream for URL: " + videourl, xbmc.LOGNONE  )
        else:
            utils.notify('Oh oh','Couldn\'t find a playable webcam link')
            return



    xbmc.Player().play(videourl, listitem)

def camgirl_page():
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
    contents = ""
    
    url = 'https://chaturbate.com/female-cams/?page=1'
    myrequest= urllib2.Request(url)
    myrequest.add_header('User-Agent', user_agent)
    myrequest.add_header('Accept-Encoding', 'gzip')
    myrequest.add_header('Referer', 'https://chaturbate.com/')
    myrequest.add_header('Accept-Language', 'en-US,en;q=0.9')
    myrequest.add_header('Connection', 'keep-alive')
    try:
        response = urllib2.urlopen(myrequest, timeout=5)
        if response.info().get('Content-Encoding') == 'gzip':
            buf = StringIO.StringIO( response.read())
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = response.read()
        contents=contents+data
    except Exception, e:
        utils.Log("attempt connecting to err:'{}'".format(str(e)), xbmc.LOGERROR)

    url = 'https://chaturbate.com/female-cams/?page=2'
    myrequest= urllib2.Request(url)
    myrequest.add_header('User-Agent', user_agent)
    myrequest.add_header('Accept-Encoding', 'gzip')
    myrequest.add_header('Referer', 'https://chaturbate.com/')
    myrequest.add_header('Accept-Language', 'en-US,en;q=0.9')
    myrequest.add_header('Connection', 'keep-alive')
    try:
        response = urllib2.urlopen(myrequest, timeout=5)
        if response.info().get('Content-Encoding') == 'gzip':
            buf = StringIO.StringIO( response.read())
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = response.read()
        contents=contents+data
    except Exception, e:
        utils.Log("attempt connecting to err:'{}'".format(str(e)), xbmc.LOGERROR)


    url = 'https://chaturbate.com/female-cams/?page=3'
    myrequest= urllib2.Request(url)
    myrequest.add_header('User-Agent', user_agent)
    myrequest.add_header('Accept-Encoding', 'gzip')
    myrequest.add_header('Referer', 'https://chaturbate.com/')
    myrequest.add_header('Accept-Language', 'en-US,en;q=0.9')
    myrequest.add_header('Connection', 'keep-alive')
    try:
        response = urllib2.urlopen(myrequest, timeout=5)
        if response.info().get('Content-Encoding') == 'gzip':
            buf = StringIO.StringIO( response.read())
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = response.read()
        contents=contents+data
    except Exception, e:
        utils.Log("attempt connecting to err:'{}'".format(str(e)), xbmc.LOGERROR)

    return contents
