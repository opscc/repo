'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES = ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 10
ROOT_URL = "https://streamxxx.tv"
SEARCH_URL = ROOT_URL + '/?s='

#URL_SUFFIX_PAGE1 = '/en/page/'
URL_CATEGORIES = ROOT_URL + '/top-tags/'
URL_CLIPS = ROOT_URL + '/category/clips/'

MAIN_MODE = '175'
LIST_MODE =  '171'
PLAY_MODE = '172'
CAT_MODE = '173'
SEARCH_MODE = '174'


@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CAT_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True 
        )
       
    List(ROOT_URL)


@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    listhtml = utils.getHtml(url, url)


    videos_regex = "(?:<article id=|class=\"quadrato\").*?<a href=\"([^\"]+)\".*?title=\"([^\"]+)\".*?src=\"([^\"]+)\""
    videos_info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, name, img in videos_info:
        name = utils.cleantext(name)
        img = img.replace(".pixhost.org/", ".pixhost.to/")
        if videopage.startswith('/'):
            videopage = ROOT_URL + videopage
        utils.addDownLink( 
            name = name 
            , url = videopage 
            , mode = PLAY_MODE 
            , iconimage = img
            , noDownload=False)


    next_page_regex ='page-numbers" href="([^"]+)">Next<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_number = '' #page number can be multiple places depending if search result or not
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if not np_number.isdigit(): np_number=np_url.split('/')[6]
            if not np_number.isdigit(): np_number=np_url.split('/')[7]
            
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
                utils.add_sort_method()
                utils.endOfDirectory()
            else:
                utils.Notify(msg=np_url, duration=500)  #let user know something is happening
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    List(np_url, end_directory)
                    

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):

    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    #end_directory=False #used when testing multipagesearch
    
    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(searchUrl, end_directory)

    #end_directory=True #used when testing multipagesearch
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        

@utils.url_dispatcher.register(CAT_MODE, ['url'])
def Categories(url):
    html = utils.getHtml(url, '')

    clips_regex = 'FILMS(.+)TOP TAGS'
    clips_html = re.compile(clips_regex, re.DOTALL).findall(html)[0]
    #Log("clips_html='{}'".format(clips_html))
    clips_regex = 'li id="menu-item.+?href="([^"]+)">([^<]+)<'
    info = re.compile(clips_regex, re.DOTALL | re.IGNORECASE).findall(clips_html)
    #Log("info='{}'".format(info))
    for url, label in info:
        if url.startswith('/'): url = ROOT_URL + url
        #Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    regex = 'a id="tag.+?href="([^"]+)" rel="tag">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    Log("info='{}'".format(info))
    for url, label in info:
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )

    clips_regex = 'VIDEOS(.+)FILMS'
    clips_html = re.compile(clips_regex, re.DOTALL).findall(html)[0]
    regex = 'li id="menu-item.+?href="([^"]+)".*?>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(clips_html)
    Log("info='{}'".format(info))
    for url, label in info:
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
                        
    utils.add_sort_method()
    utils.endOfDirectory()


@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)
