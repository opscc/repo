'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import base64,re,urllib
import xbmc,xbmcgui,xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES = ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 10
ROOT_URL = "http://www.pornhive.tv"
SEARCH_URL = ROOT_URL + '/en/search?keyword='

URL_SUFFIX_PAGE1 = '/en/page/'
URL_SUFFIX_CATEGORIES = '/en/categories'

MAIN_MODE = '70'
LIST_MODE =  '71'
PLAY_MODE = '72'
CAT_MODE = '73'
SEARCH_MODE = '74'

@utils.url_dispatcher.register(MAIN_MODE)
def PHMain():
    #utils.addDir('[COLOR hotpink]Categories[/COLOR]',ROOT_URL+URL_SUFFIX_CATEGORIES,CAT_MODE,'','')
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=ROOT_URL+URL_SUFFIX_CATEGORIES 
        ,mode=CAT_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True 
        )

    List(ROOT_URL+URL_SUFFIX_PAGE1)
    xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    listhtml = utils.getHtml(url, '')

    videos_regex = 'anel-img">\s+<a href="([^"]+)">\s+<img.*?data-src="([^"]+)".*?alt="([^"]+)'
    videos_info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in videos_info:
        name = utils.cleantext(name)
        #utils.addDownLink(name, videopage, PLAY_MODE, img, '')
        utils.addDownLink( 
            name = name 
            , url = videopage 
            , mode = PLAY_MODE 
            , iconimage = img
            , noDownload=False)
        
    next_page_regex = "\"pagination\".+?<a href=\"([^\"]+)\" data-ci-pagination-page=\"([^\"]+)\" rel=\"next\">Next &rsaquo;"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url, np_number in np_info:
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number)/32)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
                utils.add_sort_method()
                utils.endOfDirectory()
            else:
                utils.Notify(msg=np_url, duration=500)  #let user know something is happening
                if int(np_number) < (MAX_SEARCH_DEPTH * 32):    #search some more, but not forever  #32 exists for this website only
                    List(np_url, end_directory)
        
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):

    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    #end_directory=False #used when testing multipagesearch
    
    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(searchUrl, end_directory)

    #end_directory=True #used when testing multipagesearch
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
@utils.url_dispatcher.register(CAT_MODE, ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
##    match = re.compile(r'panel-img">\s+<A href="([^"]+)".*?alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(cathtml)
##    for catpage, name in match:
##        utils.addDir(name, catpage, LIST_MODE, '')
##    xbmcplugin.endOfDirectory(utils.addon_handle)   

    cathtml = utils.getHtml(url)
    cat_page_regex = 'panel-img">\s+<a href="([^"]+)".*?alt="([^"]+)"'
    cat_page_info = re.compile(cat_page_regex, re.DOTALL).findall(cathtml)
    for np_url, np_label in cat_page_info:
        #2019-06-19: this website uses a separate call to get images; I am not going to bother looking them up
        np_label="{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, np_label)
        utils.addDir(
            name= np_label
            ,url=np_url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )

    utils.add_sort_method()
    utils.endOfDirectory()
    
@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Play(url, name, download=None):
    videopage = utils.getHtml(url, '')
    if 'extra_urls' in videopage:
        baseurls = re.compile("'(aHr[^']+)", re.DOTALL | re.IGNORECASE).findall(videopage)
        #send all the decoded URLs as part of the html source; will be further parsed by util library
        for base in baseurls:
            videopage = "\"" + base64.b64decode(base) + "\" " + videopage

    utils.playvideo(videopage, name, download, url=url)
