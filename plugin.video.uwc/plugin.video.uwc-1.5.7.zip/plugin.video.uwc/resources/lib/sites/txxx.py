#-*- coding: utf-8 -*-
'''
  Ultimate Whitecream
  Copyright (C) 2016 Whitecream, hdgdl
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib2
import os
import re
import sys
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

import json

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://txxx.com"

#SEARCH_URL = ROOT_URL + '/search/{}/?s={}'
SEARCH_URL = ROOT_URL + '/api/videos.php?params=86400/str/relevance/60/search..{}.all..day&s={}'
#https://txxx.com/api/videos.php?params=86400/str/relevance/60/search..1.all..day&s=natasha%20nice

#URL_RECENT = ROOT_URL + '/latest-updates/{}/'
URL_RECENT = ROOT_URL + '/api/json/videos/86400/str/latest-updates/60/..{}.all..day.json'
#https://txxx.com/api/json/videos/86400/str/latest-updates/30/..6.all..day.json
#timeout 86400, 30 items, page 6

#URL_CATEGORIES = ROOT_URL + '/categories/'
URL_CATEGORIES = ROOT_URL + '/api/json/categories/14400/str.all.json'

URL_CHANNELS = ROOT_URL + '/channels/'

# similary to hclips

MAIN_MODE       = '790'
LIST_MODE       = '791'
PLAY_MODE       = '792'
CATEGORIES_MODE = '793'
SEARCH_MODE     = '794'

SITE_HEADERS = {
    'User-Agent': utils.USER_AGENT
    ,'Referer': ROOT_URL
   }

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color)
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon)

    #start from page 2 because using /1/ for first page does not have 'next' information
    List(url=URL_RECENT, page='1', end_directory=True, keyword='')
    

def merge_two_dicts(x, y):
    z = x.copy()   # start with x's keys and values
    z.update(y)    # modifies z with y's keys and values & returns None
    return z

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))


    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
        
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    listhtml = utils.getHtml(list_url, referer=ROOT_URL) #, ignore404=True ) #cookie+utils.headers
    if 'class="result-count">0</span>' in listhtml:
        video_region = ""
        next_page_html = ""
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon )
    else:
        next_page_html = listhtml
        try:
            video_region = listhtml.split('<div class="videos-page" ref="videos">')[1]
        except:
##            Log("Ill-defined video region for '{}'".format(list_url), xbmc.LOGWARNING)
            video_region = listhtml

    #
    # parse out list items
    #
    #Log("json_urls={}".format(json_urls))
    json_urls = json.loads(listhtml)
    if json_urls:
        for viditem in json_urls['videos']:
            label = utils.cleantext(utils.html_parser.unescape(viditem['title']))
            hd = ""
            if viditem['props']:
                if viditem['props']['hd']:
                    hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
            label = "{}{} {}".format(SPACING_FOR_NAMES, label, hd)

            thumb = viditem['scr']
            duration = viditem['duration']
            description = viditem['models']
            Log("description={}".format(description))
            
            #videourl = ROOT_URL + "/videos/{}/{}/".format( viditem['video_id'], viditem['dir'] )
            #https://txxx.com/videos/15847497/mia-malkova11/
            videourl = ROOT_URL + "/api/videofile.php?video_id={}&lifetime=8640000".format( viditem['video_id'] )
            #https://txxx.com/api/videofile.php?video_id=15847497&lifetime=8640000
            
            utils.addDownLink( 
                name = label 
                , url = videourl 
                , mode = PLAY_MODE 
                , iconimage = thumb
                , desc = description
                , duration = duration ) 
            
##    #
##    # parse out list items
##    #
##    regex = 'thumb-image-container" href="([^"]+)".+?(thumb-image-container__icon--uhd"|thumb-image-container__icon--hd"|thumb-image-container__icon").+?src="([^"]+)" .+?alt="([^"\n]+)">.+?>([^<]+)<'
##    regex = "div class=\"thumb__aspect\".+?background-image:url\('([^']+)'" \
##    + '.+?' \
##    + '((?:class="thumb__hd">HD</span>|))' \
##    + '<span class="thumb__duration">([^<]+)<' \
##    + '.+?' \
##    + 'href="([^"]+)"' \
##    + '>([^<]+)</a'
##    Log("regex={}".format(regex))
##    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
##    for thumb, hd, duration, videourl, label in info:
##        if '--uhd' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
##        elif '--fhd' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
##        elif '>HD<' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
##        else: hd = ""
##        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.html_parser.unescape(utils.cleantext(label)), hd)
##        if thumb.startswith('/'): thumb = ROOT_URL + thumb
##        if videourl.startswith('/'): videourl = ROOT_URL + videourl
####        Log("duration={}".format(duration))
##        utils.addDownLink( 
##            name = label 
##            , url = videourl 
##            , mode = PLAY_MODE 
##            , iconimage = thumb
##            , duration = duration ) 

    if json_urls['params']:
        count = json_urls['params']['count']
        json_page = json_urls['params']['page']
        total_count = json_urls['total_count']
        np_info = None
        if count * json_page < total_count:  np_info = int(page) + 1

        if not np_info:
            Log("np_info not found in url='{}'".format(url))
        else:
            Log("np_info='{}'".format(np_info))
            np_number = int(page) + 1
            np_url = url
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number) 
            Log("np_url='{}'".format(np_url))
            Log("np_label='{}'".format(np_label))

            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,section = utils.INBAND_RECURSE
                    ,keyword = keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            

##    #
##    # next page items
##    #
##    next_page_regex = 'parameters=".+?from:(\d+)"><span class="">Next</span>'
##    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
##    if not np_info:
##        Log("np_info not found in url='{}'".format(url))
##    else:
##        Log("np_info='{}'".format(np_info))
##        for np_number in np_info:
##            np_number = int(np_number)
##            np_url = url                
##            if keyword:
##                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
##            else:
##                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number -1) #np_number is -1 just for show because we skip page 1
##
##            Log("np_url='{}'".format(np_url))
##            Log("np_label='{}'".format(np_label))
##            
##            if end_directory == True:
##                utils.addDir(name= np_label
##                    ,url=np_url 
##                    ,mode=LIST_MODE 
##                    ,iconimage=utils.next_icon 
##                    ,page=np_number 
##                    ,section = utils.INBAND_RECURSE
##                    ,keyword = keyword )
##            else:
##                if int(np_number) <= (max_search_depth):
##                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
##                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
##            break # in case there are multiple pagination
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'desc'])
def Playvid(url, name, download=None, desc=None):
    Log("Playvid url='{}' name='{}' download='{}' desc='{}'".format(url, name, download, desc))
    
    videopage = utils.getHtml(url, ROOT_URL)
    
    regex = "pC3:'([^']+)',video_id: (\d+),"
    vid_codes = re.compile(regex, re.DOTALL ).findall(videopage)
    if vid_codes: #pre 2019-12-01 code below
        for code, vid_id in vid_codes:
            post_code = str(vid_id) + ',' + code
            #Log("post_code={}".format(post_code))
            import urllib
            post_code = 'param=' + urllib.quote(post_code)
            #Log("post_code={}".format(post_code))
        from requests import Request, Session
        s = Session()
        post_url = ROOT_URL+'/sn4diyux.php'
        headers = {"User-Agent": utils.USER_AGENT
                   , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                   , "Referer": url
                   }
        data = post_code
        proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
        #proxies = {"http": "127.0.0.1:8888"}
        req = Request('POST', post_url, data=data, headers=headers)
        prepped = s.prepare_request(req)
        resp = s.send(prepped , proxies=proxies, verify=False)
        #Log("resp.status_code='{}'".format(repr(resp.status_code)))
        #Log("resp.content='{}'".format(repr(resp.content)))
        regex = "'([^']+)'"
        file_code = re.compile(regex, re.DOTALL ).findall(resp.content) [0]
        #Log("file_code={}".format(file_code))
        items = json.loads(file_code)
    else: #post 2019-12-01 code below
        items = json.loads(videopage)
    

    videourl= utils.alltubes_decode(items[0]['video_url'])
    headers = { 'User-Agent': utils.USER_AGENT,'Referer': url }
    videourl = videourl + utils.Header2pipestring(headers) 
    if not videourl.startswith('http') : videourl = ROOT_URL + videourl
    

    Log("videourl={}".format(videourl.encode()))
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:    
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name)
        listitem.setInfo(type="Video", infoLabels={"Title": desc})
        xbmc.Player().play(item=videourl, listitem=listitem)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

##https://txxx.com/api/json/categories/14400/str.all.json
    json_source = utils.getHtml(url, ROOT_URL)
    json_categories = json.loads(json_source)
#https://txxx.com/api/json/videos/86400/str/latest-updates/60/categories.voyeur.1.all..day.json

    for cat_item in json_categories['categories']:
        url = ROOT_URL + "/api/json/videos/86400/str/latest-updates/60/categories.{}.{}.all..day.json".format(cat_item['dir'], '{}')
        label = cat_item['title']
#https://txxx.com/api/json/videos/86400/str/latest-updates/60/categories.voyeur.1.all..day.json
##        Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE
            ,page="1"
            ,iconimage=utils.search_icon)
        
##    regex = '"categories-list__link" href="([^"]+)".+?.+?data-title="([^"]+)"'
##    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
##    Log("info='{}'".format(info))
##    for url, label in info:
##        if url.startswith('/'): url = ROOT_URL + url
##        #if thumb.startswith('/'): thumb = ROOT_URL + thumb
##        #Log("url='{}'".format(url))
##        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
##            SPACING_FOR_TOPMOST, utils.search_text_color, label)
##            ,url=url 
##            ,mode=LIST_MODE
##            ,page="1"
##            ,iconimage=utils.search_icon)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

##SEARCH_URL = ROOT_URL + '/api/videos.php?params=86400/str/relevance/60/search..{}.all..day&s={}'
###https://txxx.com/api/videos.php?params=86400/str/relevance/60/search..1.all..day&s=natasha%20nice
##    keyword = keyword.replace(' ','+')
    keyword = keyword.replace('+','%20')    
    searchUrl = SEARCH_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#
def Test(keyword):

    List(URL_RECENT, page='2', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=1)
    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#
        
