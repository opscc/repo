'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Beeg[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = True
    
    _ROOT_URL        = "https://beeg.com"
    _URL_CATEGORIES  = "https://store.externulls.com/tag/facts/tags?get_original=true&slug=index"#2021-09-12
    _URL_RECENT      = "https://store.externulls.com/facts/tag?id=27173&"  #2021-09-12
    _SEARCH_URL      = "https://store.externulls.com/facts/tag?slug={}&get_original=true&" 
    _MAIN_MODE = C.MAIN_MODE_beeg
    _FIRST_PAGE = '1'

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
##    _ITEMS_NOT_FOUND_INDICATORS = [
##        "<p>Make sure that all words are spelled correctly.</p>"
##        , "No videos found for "
##        ]
    #__________________________________________________________________________
    #specific header required for listing
    _LIST_HEADERS = {
        "Accept":"application/json, text/plain, */*"
        ,"DNT":"1"
        ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36"
        ,"Origin":"https://beeg.com"
        ,"Referer":"https://beeg.com/"
        ,"Accept-Encoding":"gzip, deflate"
        ,"Accept-Language":"en-US,en;q=0.9"
    }
    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = None #'class="main"(.+?)class="divrectr"'
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        '"fc_facts":'
        '.+?"fc_file_id": (?P<videourl>\d+),'
        '.+?"fl_duration": (?P<duration>\d+),'
        '.+?"fl_height": (?P<hd>\d+),'
        '.+?"(?:set_id|stuff)": (?P<thumb>[^,]+),'
        '.+?(?:sf_name|tg_name|sf_duration)":\s(?:"|\[)(?P<label>[^"{]+)"?{?'
        "(?P<desc>)"
        )
    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options

    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = "(.)" #'href="([^"]+)">Next '

    #__________________________________________________________________________
    #where categories can be found
    #_REGEX_categories_region = "id='categoryList'(.+)"
    _REGEX_categories = (
        '"tg_name": "(?P<label>[^"{]+)",'
        '.+?"tg_slug": "(?P<videourl>[^"{]+)"'
        '(?P<thumb>)'
        )
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        url = "https://store.externulls.com/facts/tag?slug={}&".format(url)
        return url
    #__________________________________________________________________________
    #where playable urls live
    _REGEX_playsearch_01 = (
        'fl_cdn_(?P<res>\d+)'
        '.+?"(?P<url>key=[^"]+?)"'
        )
    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by site
    def Video_Source_URL_Normalize(self, url):
        url = "https://video.beeg.com/{}".format(url)
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = "https://beeg.com/" 
        from resources.lib.utils import Header2pipestring as Header2pipestring
        url = url + Header2pipestring(headers)
        return url
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags = '"tg_name": "([^"]+)"'    #'"pornstar_tag".+?>([^<]+)<'
    _REGEX_tags_region = "(.+)"           #'class="categorieswrapper(.+?)<noscript>'
    #__________________________________________________________________________
    # add an alternative way to resolve listing
    def List_URL_Normalize(self, url, page):
        url = url + "limit=48&offset={}"
        url = url.format(48*(int(page)-1))
        return url
    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
        from resources.lib.utils import RandomNumber as RandomNumber
        thumb_url = "https://thumbs-015.externulls.com/"
        try: #sometimes there is a 'set' of images; sometime not
            int(thumb)
            thumb_url = thumb_url + "sets/{}/thumbs/{}-{}.jpg?size=320x180"
            thumb = "{:>05d}".format(int(thumb))
            thumb = thumb_url.format(thumb, thumb, '{}')
            frame = "{:>04d}".format( (int(duration)/10) + (int(RandomNumber(length=1))) )  #Site allows global frame grabs...10% into vid seems ok...but the official list is ordered in such a way to make regex capture too hard
        except:
            thumb = thumb_url + "videos/{}/{}.jpg?size=320x180".format(videourl, '{}')
            frame = "{}".format( (int(duration)/10) + (int(RandomNumber(length=1))) )  #Site allows global frame grabs...10% into vid seems ok...but the official list is ordered in such a way to make regex capture too hard
        thumb = thumb.format(frame)        
        return thumb
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        videourl = "https://store.externulls.com/facts/file/{}".format(videourl)
        return videourl
##    #__________________________________________________________________________
##    # add an alternative way to resolve a playable video url
##    # returned items must be a list of (res, url) items
##    def _ALTERNATE_playsearch_01(self, *args, **kargs):
##        alt_results = list()
##        full_html = kargs["full_html"]
##        url = kargs["referer"]
##        return alt_results
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        #note: site actually uses websockets to generate a 'slug' value for some searches
        # but I don't want to worry for this low quality site
        keyword = keyword.replace("'", "")
        return keyword.replace('+',' ').replace(' ','')
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        #note: site actually uses websockets to generate a 'slug' value for some searches
        # but I don't want to worry for this low quality site

        search_url = search_url.format(keyword)
        return search_url

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    website.Playvid(url, name, download, playmode_string, play_profile=play_profile, testmode=testmode)
#__________________________________________________________________________
#
