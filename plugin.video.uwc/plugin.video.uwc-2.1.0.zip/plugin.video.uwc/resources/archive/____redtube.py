'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]redtube[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.redtube.com"
SEARCH_URL = ROOT_URL + '/?search={}&page={}'
URL_CATEGORIES = ROOT_URL + '/categories'
URL_RECENT = ROOT_URL + '/?page={}'

MAIN_MODE          = C.MAIN_MODE_redtube 
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, ignore404=True)# , send_back_redirect=True)
    if "Page Not Found" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            regex = '(?:id="browse_section"|id="search_results_block")(.+)(?:id="w_pagination"|class="title_inactive")'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            #utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))

    # parse out list items
    regex = 'alt="([^"]+)".+?data-src="([^"]+)".+?"duration">\s+((?:<span class="hd-video-text">HD</span>|))\s+(\d+:\d+).+?href="(/[^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for label, thumb, hd, duration, videourl in info:
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)


    # next page items
    try:
        regex = 'id="w_pagination"(.+?)class="footer"'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
    next_page_regex = 'id="wp_navNext".+?href="([^"]+=)(\d+)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url, np_number in np_info:
        np_url=url
        np_number=int(page)+1
        np_url=url.lower() #site will redirect if mixed case
##        Log("np_url={}".format(np_url))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth:
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
        break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)

    regex = 'class="main_category_header"(.+)'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##    Log("listhtml={}".format(listhtml))
    
    regex = 'class="category_item_wrapper.+?href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = videourl + '?page={}'
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb) #C.search_icon)
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    full_html = utils.getHtml(url, ROOT_URL)
#    source_html1 = ',"mediaDefinitions":[{"defaultQuality":true,"format":"","quality":"720","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/720P_1500K_18335131.mp4?0idsYiD-jh4q8NCS0v6iC1R4SAvv9m-WqnqgA6QzCKeNUJDGO0ciQkPcv4LJoOhew2wWEAC9YYOXyjV9PcTKi3ORzGohLfp1w3G8b_JlOHa10127jyitWfiJ5v8yjGiLVtt2SaTCU0Lsm4k70rkKP5Gy9YFytRi6xQRA4Wabo9WmcJ_P_1Fx0jDk0ou7LTiqlJ5LMLnZw0rQEEJ1"},{"defaultQuality":false,"format":"","quality":"480","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/480P_600K_18335131.mp4?tkV8JplE8wnw9uFa8936-HctKRAu0uOgmukr-_x2SZ6-pa3CHzujAQaO8hXeUfnqK9VpiEKx88u4-MWns7sAIkg8I3XB1NeLT2PXLYf4ugY_-9wTqm-uh0dQD94l4cNzuL1d7o2IQ-PxweNWVKv9hGOQcevk7BnGAxJ7dSla2jXUjfQt0BSbTpxxyrTBtBZmBRoEE8hB5HXhIw"},{"defaultQuality":false,"format":"","quality":"240","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/240P_400K_18335131.mp4?STGBmiZrtxfV2QjInJOYcX1LyZEQmXVjos6jS4pRDHosxZXN3JvlNrY0f_96RbC94YLDrkRiyLidn7MpRlLqIzOScqQtx9aU5ruyvBOx0PnpZmtNHiDljbyOaY_sDvBugfGT21tHRqs-Js9Alb9V8AqkCoDcuo1nFVB0qZu8qpvJzczAvXvwVPVR1GB3ypqczItFjAaCAFLdtg"}],'
#    Log("source_html1={}".format(source_html1))

    if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
        return

    regex = ',?"?mediaDefinitions?"?:(.+?\]),'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    Log("sources_list={}".format(sources_list))
    if sources_list:
        sources_list = sources_list[0]
    else:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return
    
    json_sources = json.loads(sources_list)

    list_key_value = {} ##[] #dict()
    for i in range(len(json_sources)):
        dict_source = dict(json_sources[i])
        q = str(dict_source['quality'])
        v = str(dict_source['videoUrl'])
        if not (".m3u8?" in v): ## skip HLS for now
            if not v == "":
                list_key_value[q] = v
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    Log("list_key_value={}".format(list_key_value))
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )   


    regex_model = '<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).findall(full_html)
    description = ''
    desc_separator_char = '; '
    for model in source_models:
        if model.lower() not in description.lower():
            description = description + utils.cleantext(C.html_parser.unescape(model)) + desc_separator_char
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
##    Log("description={}".format(description))

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
