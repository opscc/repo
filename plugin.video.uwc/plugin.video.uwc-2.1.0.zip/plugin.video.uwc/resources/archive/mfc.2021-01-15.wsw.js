var WSWorker = function() {
    this.ws = null;
    this.receiveBuffer = "";
    this.serverConnected = !1;
    this.lastDisconnectReason = "";
    this.lastDisconnectCode = 0;
    this.mfcVersion = "";
    this.loginTimer = this.pingTimer = null;
    this.Init()
};
WSWorker.prototype.Init = function() {
    this.Up("init")
}
;
WSWorker.prototype.Connect = function(a, b, c) {
    this.ws && (this.ws.close(),
    this.ws = null);
    this.clearLoginTimer();
    this.mfcVersion = b;
    this.receiveBuffer = "";
    this.serverConnected = !1;
    this.ws = c ? new WebSocket(a,"fcsl") : new WebSocket(a);
    this.ws.onopen = CreateDelegate(this, this.onConnect);
    this.ws.onerror = CreateDelegate(this, this.onClose);
    this.ws.onclose = CreateDelegate(this, this.onClose);
    this.ws.onmessage = CreateDelegate(this, this.RxData)
}
;
WSWorker.prototype.Post = function(a) {
    this.ws && this.ws.send && this.ws.send(a)
}
;
WSWorker.prototype.Close = function() {
    this.ws && this.ws.close();
    this.ws = null;
    this.receiveBuffer = "";
    this.serverConnected = !1
}
;
WSWorker.prototype.onConnect = function() {
    var a = this;
    this.Up("onConnect");
    this.clearLoginTimer();
    this.loginTimer = setTimeout(function() {
        a.Login()
    }, 0)
}
;
WSWorker.prototype.Login = function() {
    this.ws && (this.receiveBuffer = "",
    this.serverConnected = !0,
    this.Up("onLogin"),
    this.pingTimer && clearInterval(this.pingTimer),
    this.pingTimer = setInterval(this.Ping, 4E3),
    this.ws.send("fcsws_" + this.mfcVersion + "\n\x00"))
}
;
WSWorker.prototype.clearLoginTimer = function() {
    this.loginTimer && (clearTimeout(this.loginTimer),
    this.loginTimer = null)
}
;
WSWorker.prototype.onClose = function(a) {
    this.clearLoginTimer();
    this.lastDisconnectReason = a.reason;
    this.lastDisconnectCode = a.code;
    void 0 == this.lastDisconnectReason && (this.lastDisconnectReason = "");
    void 0 == this.lastDisconnectCode && (this.lastDisconnectCode = 0);
    this.ws && (this.ws.close(),
    this.ws = null);
    clearInterval(this.pingTimer);
    this.pingTimer = null;
    this.serverConnected = !1;
    this.Up("onClose", [this.lastDisconnectReason, this.lastDisconnectCode])
}
;
WSWorker.prototype.RxData = function(a) {
    if (a && a.data && a.data.length)
        for (this.receiveBuffer += a.data; !(6 > this.receiveBuffer.length); ) {
            a = parseInt(this.receiveBuffer.substr(0, 6), 10);
            if (0 == a) {
                console.log("Desynced from server: " + this.receiveBuffer.length + " / " + this.receiveBuffer.substr(0, 6));
                break
            }
            if (this.receiveBuffer.length < a + 6)
                break;
            this.receiveBuffer = this.receiveBuffer.substr(6);
            var b = this.receiveBuffer.substr(0, a);
            this.receiveBuffer = this.receiveBuffer.substr(a);
            this.Up("onPacket", b)
        }
}
;
WSWorker.prototype.Ping = function() {
    WS.ws && WS.ws.send && WS.ws.send("0 0 0 0 0 -\n\x00")
}
;
WSWorker.prototype.Up = function(a, b) {
    postMessage(JSON.stringify([a, b]))
}
;
var WS = new WSWorker;
self.onmessage = function(a) {
    var b = JSON.parse(a.data);
    a = b[0];
    b = b[1];
    "Connect" == a ? WS.Connect(b[0], b[1], !1) : "AltConnect" == a ? WS.Connect(b[0], b[1], !0) : "Post" == a ? WS.Post(b) : "Close" == a && WS.Close()
}
;
function CreateDelegate(a, b) {
    return function() {
        b.apply(a, arguments)
    }
}
;