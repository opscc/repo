'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
from base_website import Base_Website
from utils import Log,LogR,Sleep

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]redtube[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False
    _ROOT_URL        = "https://www.redtube.com"
    _URL_CATEGORIES  = _ROOT_URL + '/categories'
    _URL_RECENT      = _ROOT_URL + '/?page={}'
    _SEARCH_URL      = _ROOT_URL + '/?search={}&page={}'
    _MAIN_MODE = C.MAIN_MODE_redtube
    _FIRST_PAGE = 1

    _LIST_REDIRECTED_URL_BECOMES_LISTURL = False
    
    #where we can find videos on this page [exclude advertisement]
    #_REGEX_video_region = '(?:data-section_name="day_by_day_section" data-espnode|video_row_main_search"|data-espnode="videolist")(.+?)(?:id="pagination"|<footer>)'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "Page Not Found"
        ]
    #videos on this page
    _REGEX_video_region = (
        '(?:div id="browse_section"|div class="videolist_results"|id="search_results_block")'
        '(.+)'
        #'id="w_pagination"'
        '(?:</videolisting>|id="w_pagination"|class="title_inactive")'
        )
    _REGEX_list_items = (
        'data-video-id="\d+"'
        '.+?alt="(?P<label>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?tm_video_duration">(?P<duration>\d+:\d+)'
        '.+?href="(?P<videourl>/[^"]+)"'
        '(?P<desc>)'
        '(?P<hd>)'
#stopped working on/before 2025-04
##        'alt="(?P<label>[^"]+)"'
##        '.+?data-src="(?P<thumb>[^"]+)"'
##        '.+?"duration">\s+(?P<hd>(?:<span class="video_quality">.+?</span>|))' #excludes 'premium' vids
##        '.+?"tm_video_duration">\s+(?P<duration>\d+:\d+)'
##        '.+?href="(?P<videourl>/[^"]+)"'
##        '(?P<desc>)'
        )
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'id="w_pagination"(.+?)class="footer"'
    _REGEX_next_page_regex = 'id="wp_navNext".+?href="([^"]+=)(\d+)"'
    _SAVE_COOKIES = False       #if we need to save html cookies
    _REGEX_categories_region = 'class="main_category_header"(.+)'
    _REGEX_categories = (
        'class="category_item_wrapper.+?href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        )
    #where playable urls live
    _REGEX_playsearch_01 = None #(
##        ',?"?mediaDefinitions?"?:(?P<json>.+?\]),'  #video data as json
####        'data-hls-src(?P<res>\d+)'                #video data as res+url
####        '="(?P<url>[^"]+)"'
##        )
    #description for the playable url
    _REGEX_tags = '<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    _REGEX_tags_region = 'class="video-infobox-label">(.+)'

    #__________________________________________________________________________
    # hack url to remove page=1 - site behaves weird during search
    def List_URL_Normalize(self, url, page=None):
        if int(page) == 1:
            if url.endswith('?page=1'):
                url = url[:-len('?page=1')]
            if url.endswith('&page=1'):
                url = url[:-len('&page=1')]

##        Sleep(2000) # seems to prevent duplicates/ maybe a slightly smaller number would be better
        return url
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url + '?page={}'
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format(keyword.lower(),'{}')
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        #2021-06 site moved data to separate page
        REGEX_playsearch_01 = 'mediaDefinitions":(?P<json>\[[^\]]+\]),'
        source_html = kargs['full_html']
        referer = kargs['referer']
        videos_list = list() #hold multiple video_url when possible

        import re
        import json
        from utils import getHtml as getHtml
        
        sources_list = re.compile(REGEX_playsearch_01, re.DOTALL | re.IGNORECASE).finditer(source_html)
        for source in sources_list:
            sources_list = source.group('json')
            json_sources_1 = json.loads(sources_list)
            Log("json_sources_1='{}'".format(repr(json_sources_1)))
            for json_src in json_sources_1:
                if 'videoUrl' in json_src:
                    if json_src['videoUrl'] != '':
                        url_2 = json_src['videoUrl']
                        if not url_2.startswith('http'): url_2 = self._ROOT_URL +  json_src['videoUrl']
                        json_html = getHtml( url_2 , referer)
                        json_sources_2 = json.loads(json_html)
                        Log("json_sources_2='{}'".format(repr(json_sources_2)))
                        for json_src_2 in json_sources_2:
                            if json_src_2['videoUrl'] != '':
                                if type(json_src_2['quality']) != list: #list type entries are usually HLS, but I don't want to handle those at this time
                                    videos_list.append((json_src_2['quality'], json_src_2['videoUrl']))
                            
                break

        Log("videos_list={}".format(repr(videos_list)))        
        return videos_list
##
##    #__________________________________________________________________________
##    # Override here so that any potential self.* reference happens
##    def Playvid2(self, url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
##        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
##
##        description = name + '\n' + self.ROOT_URL
##        
##        import utils
##        import re
##        import json
##        import urllib
##        html = utils.getHtml(url, website.ROOT_URL)
##        headers = C.DEFAULT_HEADERS.copy()
##        headers['Accept'] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
##        headers['Content-Type'] = 'application/x-www-form-urlencoded'
##        match = re.compile("action: 'msv-get-sources'.+?id: '(.+?)'.+?nonce: '(.+?)'", re.DOTALL | re.IGNORECASE).findall(html)[0]
##        payload = {'action':'msv-get-sources', 'id':match[0], 'nonce':match[1]}
##        payload = "{}".format( urllib.urlencode(payload) )
##        sources = utils.postHtml(
##            'https://hentaidude.com/wp-admin/admin-ajax.php'
##            , sent_data=payload
##            , headers=headers
##            #, compression=False
##            #, NoCookie=None
##            )
##        Log("sources='{}'".format(repr(sources)))
##        if not sources:
##            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,website.ROOT_URL))
##            return
##        sJson = json.loads(sources)
##        Log("sJson='{}'".format(repr(sJson)))
##        if not sJson['success']:
##            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,website.ROOT_URL))
##            return
##        video_url = sJson['sources']['video-source-0']
##        Log("video_url='{}'".format(video_url))
##
##        headers = C.DEFAULT_HEADERS.copy()
##        headers['Referer'] = website.ROOT_URL
##        video_url = video_url + utils.Header2pipestring(headers)
##        Log("video_url='{}'".format(video_url))
##        if testmode:
##            Log("Would have played video_url; but in test mode")
##            return   #during testmode, only ensure that a url can be generated
##
##        utils.playvid(video_url, name=name, download=download, description=description)
##    #__________________________________________________________________________
##    #

#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )

#__________________________________________________________________________
#
