'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import search
import traceback
import utils
from utils import Log,LogR
import constants as C

FRIENDLY_NAME = '[COLOR {}]sunporno[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.sunporno.com"
SEARCH_URL = ROOT_URL + '/search/{}/page{}.html'
SEARCH_URL = ROOT_URL + '/s/{}/page{}.html'
SEARCH_URL = ROOT_URL + '/s/{}/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&category_ids=&sort_by=&from_videos={}'

#https://www.sunporno.com/s/love/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=love&category_ids=&sort_by=&from_videos=4&from_albums=4&_=1735301820809 
#https://www.sunporno.com/search/lexi+belle/page2.html
URL_CATEGORIES = ROOT_URL + '/channels/'
URL_RECENT = ROOT_URL + '/page{}.html'
URL_RECENT = ROOT_URL + '/most-recent/?mix=true&pageId={}'
URL_RECENT = ROOT_URL + '/?mode=async&function=get_block&block_id=list_videos_most_recent_videos&sort_by=video_viewed_today&from={}'
#https://www.sunporno.com/most-recent/?mix=true&pageId=2&_=1654963728067
#https://www.sunporno.com/?mode=async&function=get_block&block_id=list_videos_most_recent_videos&sort_by=video_viewed_today&from=4&_=1735300596754


MAIN_MODE          = C.MAIN_MODE_sunporno
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = 1
#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )  
##    utils.addDir(
##        name=C.STANDARD_MESSAGE_CATEGORIES
##        ,url = URL_CATEGORIES
##        ,mode = CATEGORIES_MODE
##        ,iconimage=C.category_icon
##        )
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT
         , page_start=FIRST_PAGE
         , page_end=FIRST_PAGE
         , end_directory=True
         , keyword=''
         , progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
##    LogR(locals())
    LogR(locals())

    page_start = int(page_start)
    if not page_end: page_end = page_start
    else:  page_end = int(page_end)
            
##    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(
##          end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
    (inband_recurse
     ,end_directory
     ,max_search_depth
     ,list_url)=utils.Initialize_Common_Icons( end_directory =  end_directory
                                               , keyword = keyword
                                               , SEARCH_URL = SEARCH_URL
                                               , SEARCH_MODE = SEARCH_MODE
                                               , url = url
                                               , page_start = page_start
                                               , page_end = page_end
                                               )

    # read html
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if "<p>Make sure that all words are spelled correctly.</p>" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            regex = '(?:|id="search_results_block")(.+?)(?:id="pagination"|id="wrapBlocks")'
            regex = '(?:class="page-content main"|class="search-headers")(.+?(?:>Show More</a>|id="wrapBlocks"))'
            regex = (
                'class="main-content"'
                '(.+)'
                'class="footer"'
                )
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
##            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    # parse out list items
    regex = 'class="btime">([^<]+)<.+?href="([^"]+)".+?((?:<span class="icon-hd">HD</span>|<img)).+?src="([^"]+)".+?title="([^"]+)"'
    regex = 'class="pp".+?href="([^"]+)".+?class="btime tm">([^<]+)<.+?img data-src="([^"]+)".+?alt="([^"]+)()"'
    regex = (
        'class="item'
        '.+?href="([^"]+?)"'
        '.+?src="(.+?)"'
        '.+?alt="(.+?)"'
        '.+?class="duration">(.+?)<'
        '()'
        )

    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #for duration, videourl, hd, thumb, label in info:
    #for videourl, duration, thumb, label, hd in info:
    for videourl, thumb, label, duration,  hd in info:
        
        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    # next page items
    try:
        regex = '<div class="pagination"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
    next_page_regex = '(<li class="next">)'
    
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
        np_number = page_start + 1
    else:
        np_number = int(page_start) + 1
        np_url = url
        Log("np_number={}".format(np_number))
        Log("np_url={}".format(np_url))
        if end_directory == True:
            if (np_number > page_end): #todo fix end_dir
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page_start=np_number
                    ,page_end=page_end
                    ,section = None #C.INBAND_RECURSE
                    ,keyword=keyword )

##            if int(np_number) <= (max_search_depth):
        LogR(((np_number, page_end)))
        if  (np_number <= page_end) :
            utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
            List(url=np_url
                 , page_start=np_number
                 , page_end=page_end
                 , end_directory=end_directory
                 , keyword=keyword
                 , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
##@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end'])
##def Search(searchUrl, keyword=None, end_directory=True, page_start=FIRST_PAGE, page_end=None, progress_dialog=None):
##    LogR(locals())
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end'])
def Search(searchUrl
           , keyword=None
           , end_directory=True
           , page_start=FIRST_PAGE
           , page_end=None
           , progress_dialog=None):
    LogR(locals())
##    LogR(locals())


    if not keyword:
        search.searchDir(   url=searchUrl
                         , mode=SEARCH_MODE
                         , page_start=page_start
                         , page_end=page_end
                         , end_directory=end_directory
                            )
        return

    keyword = keyword.replace(' ','-') #.replace(' ','%20')
    keyword = keyword.replace('+','-') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page_start=page_start
        , page_end=page_end
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    LogR(end_directory)
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page_start)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    listhtml = utils.getHtml(url)
    regex = 'class="thumbs-container"(.+)id="goupBlock"'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##    Log("listhtml={}".format(listhtml))
    regex = '<a href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        videourl = videourl + 'page{}.html'
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page_start=FIRST_PAGE
            ,iconimage=thumb) #C.search_icon)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True, page_start=1, page_end=1):
##    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))
##
##    List(URL_RECENT, page_start=FIRST_PAGE, page_end=None, end_directory=False, keyword='', testmode=True)
##    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page_start=FIRST_PAGE, page_end=page_end)
####    Categories(URL_CATEGORIES, False)
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
    try:
        if not keyword:
            prev_keyword = utils.get_setting('quick_search_string')
            keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
            if  keyword == '' :
                return False, 0  ## if blank or the user cancelled the keyboard, return
            C.addon.setSetting(id='quick_search_string', value=keyword)
            
        List(URL_RECENT
             , page_start=FIRST_PAGE
             , page_end=FIRST_PAGE
             , end_directory=False
             , testmode=True
             )
        Search(    searchUrl=SEARCH_URL
                 , keyword=keyword
                 , end_directory=False
                 , page_start=FIRST_PAGE
                 , page_end=int(FIRST_PAGE)+C.DEFAULT_RECURSE_DEPTH
                   )
##        Categories(URL_CATEGORIES,  end_directory=False)

        if end_directory:
            utils.addDir(
                name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
                ,url=C.DO_NOTHING_URL
                ,mode=C.NO_ACTION_MODE)
    except:
        traceback.print_exc()
        raise
    
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile','icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))

    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    download_filespec = ''
    description = name + '\n' + ROOT_URL
    video_url = None

    source_html = utils.getHtml(url, ROOT_URL)

    regex = "license_code: '(?P<lic>[^']+)'"
    license_code = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html)
    if not license_code:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    else:
        license_code = license_code[0]
##    Log(license_code)

    list_key_value = {}
    regex = "(?:video_url|video_alt_url.?):\s+?'(?P<url>[^']+)"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(source_html)
    for source_list in sources_list:
        if 'res' in source_list.groupdict():
            list_key_value[source_list.group('res')] = source_list.group('url')
        else:
            list_key_value['240'] = source_list.group('url')
    Log("list_key_value={}".format(list_key_value))
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return

    if video_url.startswith("function/0/"):
        video_url = video_url.split("function/0/")[1]
        Log("video_url={}".format(video_url))
        
    import resolver
    fappy_salt = resolver.FaapySalt(license_code, "")
    Log("fappysalt='{}'".format(fappy_salt))
    encoded_fappy_code =  video_url.split('/')[5][0:32]
    Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
    new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
    Log("new_fappy_code='{}'".format(new_fappy_code))
    video_url = video_url.replace(encoded_fappy_code, new_fappy_code)
    video_url += '?rnd=' + utils.RandomNumber(length=13)

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return
    utils.playvid(video_url, name=name, download=download, description=description)


    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mode = PLAY_MODE
        , icon_URI = icon_URI            
        )
    

    return
##    regex = 'data-src="([^"]+\.(?:mp4|flv))"'
##    regex = "flashvars.video_url = '(.+?)'"
    regex = '<source src="(.+?)"'
    
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
    Log("sources_list={}".format(sources_list))
    video_url = sources_list[-1]

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
