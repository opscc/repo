'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import re
import json
#import internal addon libraries
import utils
from base_website import Base_Website
import constants as C
#define frequenctly used aliases
from utils import Log,LogR

class Specific_Website(Base_Website):
    
    _FRIENDLY_NAME = '[COLOR {}]jav.guru[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_MOVIES
    _FRONT_PAGE_CANDIDATE = False

    _MAIN_MODE = C.MAIN_MODE_javguru
    
    _ROOT_URL           = "https://jav.guru"
    _URL_RECENT         = _ROOT_URL + '/page/{}/'
    _SEARCH_URL         = _ROOT_URL + '/page/{}/?s={}'

    _LIST_REDIRECTED_URL_BECOMES_LISTURL = False

    _FIRST_PAGE = 1 #Note:site does not support page1.html

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = '(?:id=main|id="main"|class="search-submit")(.*)(?:</main></div>|class="paging-navigation"|class="footer)'

    _REGEX_icon_search = r'large-screenimg".+?src="(.*?)"'
##    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "Sorry, nothing good matched"
        ]



    #__________________________________________________________________________
    # add an alternative way to resolve listing
    def List_URL_Normalize(self, url, page):
        if url.endswith("/page/1/"): #site does not always like this
            url = url[:-len("/page/1/")]
        return url
    
    #videos on this page    
    _REGEX_list_items = (
        '(?:class="inside-article"|class=inside-article)'
        '.+?href="(?P<videourl>.+?)"'
        '.+?src="(?P<thumb>.*?)"'
        '.+?alt="(?P<label>.+?)"'
        '(?P<duration>)'
        '(?P<hd>)'
        )
    #where we can find info on whether there is a next page
##    _REGEX_next_page_region = 'class="pagination"(.+)'
    _REGEX_next_page_regex =  (
        'class="paging-navigation"'
        '.+?class="next page-numbers" href=".*?/page/(\d+)/'
        )
    #where playable urls live
    _REGEX_playsearch_01 = (
        "video(?:_alt|)_url\d?: '(?P<url>[^']+)',"
        ".+?"
        "(?:class='|video(?:_alt|)_url\d?_text: ')(?P<res>\d+)"    
       )
    #description for the playable url
    _REGEX_tags = None #"href='/pornstar/.+?>([^<]+)<"
    _REGEX_tags_region = None#'<div id="data-video">(.+?)<div class="clear">'
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args)>0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args)>1): keyword = args[1]
        elif (args is not None) and (len(args)>0): keyword = args[0]
        else                                     : keyword = ""
        keyword_1 = keyword.replace(' ','+')
        return search_url.format('{}', keyword_1)


    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        source_html = kargs['full_html']
        referer = kargs['referer']
        name = kargs['name']
        videos_list = list() #hold multiple video_url when possible

        from utils import getHtml as getHtml

        regex_model_area = 'Actress:(.+)Studio'
        models_html = re.compile(regex_model_area, re.DOTALL | re.IGNORECASE).findall(source_html)
        if models_html: models_html=models_html[0]
        else: models_html = ''
        regex_model = '/actress/.+?rel="tag">(?P<model>[^<]+)<'
        source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(models_html)
        description = ''
        desc_separator_char = '; '
        if source_models:
            for model in source_models:
                description = description + desc_separator_char + model.group('model')
        description = description.strip(desc_separator_char)
        if description == '':  description=name + '\n' + self._ROOT_URL
        else:           description=description + '\n' + self._ROOT_URL
        Log(u"description={}".format(description))

        headers = C.DEFAULT_HEADERS.copy()
        headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
        
        regex_vid_sources = '","iframe_url":"([^"]+)"'
        vid_sources = re.compile(regex_vid_sources, re.DOTALL | re.IGNORECASE).findall(source_html)
        source_html = ''
        lockers = []
        LogR(vid_sources)

        dev_only = False
        if dev_only:
            locker_url = resolve_vid_source(vid_sources[0], headers, lockers)
            source_html = source_html + locker_url + "  "
        else:
            threads = []
            import threading 
            append = threads.append

            for vid_source in vid_sources:
                append(
                    threading.Thread(
                        name = "resolve_vid_source_thread"
                        ,target = resolve_vid_source
                        ,args   = (vid_source, headers, lockers)
                    )
                )
            LogR(threads)
            [i.start() for i in threads]
            
            alive = [x for x in threads if x.is_alive() is True]
            thread_time = 0.0
            max_thread_time = 600
            while alive and (thread_time < max_thread_time):
                alive = [x for x in threads if x.is_alive() is True]
                utils.Sleep(100)
                thread_time += 0.1

            LogR(threads)
            LogR(alive)


        source_html = "  ".join(lockers)
        LogR(source_html)

        import resolver
        video_url = resolver.resolve_video(
            videosource=source_html
           , name=name
           , download=kargs['download']
           , url=kargs['referer']
           , ask_which_file_hoster = kargs['ask_which_file_hoster']
           )
        Log("video_url={}".format(video_url))
        videos_list.append(('240', video_url))

        
        return videos_list

        
#__________________________________________________________________________
#
website = Specific_Website() #always need this
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class

    utils.addDir(
        name="{}[COLOR {}]English Subbed[/COLOR]".format( 
                    C.SPACING_FOR_TOPMOST
                    , C.search_text_color
                ) 
        ,url = website._SEARCH_URL
        ,mode = website.SEARCH_MODE
        ,keyword="English Subbed"
        ,page_start=website.FIRST_PAGE 
        ,iconimage=C.search_icon
        )
    utils.addDir(name="{}[COLOR {}]Uncensored[/COLOR]".format( 
                C.SPACING_FOR_TOPMOST, C.search_text_color) 
                ,url = 'https://jav.guru/category/jav-uncensored/page/{}/'
                ,mode = website.LIST_MODE
                ,page_start=website.FIRST_PAGE 
                ,iconimage=C.search_icon )
    utils.addDir(name="{}[COLOR {}]Carib[/COLOR]".format( 
                C.SPACING_FOR_TOPMOST, C.search_text_color) 
                ,url = website._SEARCH_URL
                ,mode = website.SEARCH_MODE
                ,keyword="Carib"
                ,page_start=website.FIRST_PAGE 
                ,iconimage=C.search_icon )

    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.LIST_MODE
    , ['url']
    , ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation']
    )
def List(
    url
    , page_start=None
    , page_end=None
    , end_directory=True
    , keyword=''
    , testmode=False
    , bulk_operation=False
    ):
##    LogR(locals())
    website.List(
        url
        , page_start=page_start
        , page_end=page_end
        , end_directory=end_directory
        , keyword=keyword
        , testmode=testmode
        , bulk_operation=bulk_operation
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.SEARCH_MODE
    , ['url']
    , ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation']
    )
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=website._FIRST_PAGE
    , page_end=website._FIRST_PAGE
    , progress_dialog=None
    , bulk_operation=False
    ):
    website.Search(
        searchUrl
        , keyword=keyword
        , end_directory=end_directory
        , page_start=page_start
        , page_end=page_end
        , progress_dialog=progress_dialog
        , bulk_operation=bulk_operation
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid(
        url
        , name
        , download=download
        , playmode_string=playmode_string
        , play_profile=play_profile
        , testmode=testmode
        , icon_URI=icon_URI
        )
#__________________________________________________________________________
#

#__________________________________________________________________________
#
def resolve_vid_source(vid_source, headers, lockers):

    import base64

##    Log("resolve_vid_source={}".format(vid_source))
    if C.PY3: src = str(base64.b64decode(vid_source),'utf8').split('&bg=')[0]
    if C.PY2: src = base64.b64decode(vid_source).split('&bg=')[0]
    if 'd=' in src:
        src_forward = src.split('d=')[1]
        src_reverse = src.split('d=')[0] + 'r=' + src_forward[::-1]
    else:
        if '?bg=' in src:
            src_reverse = src.split('?bg=')[0]
    headers['Referer'] = src
    n_url = src_reverse
    url = src_reverse

    Log("{}  {}".format(url, vid_source))

    locker_html, locker_url = utils.getHtml(n_url, headers=headers, send_back_redirect=True, cache_duration=0 )
            
    if not locker_url:
        locker_url = url

    lockers.append(locker_url)

    Log("{} {} {} ".format(locker_url, url, vid_source))
    return locker_url
    return


    Log('get_sources')
    Log(repr((url,)))
    try:

        vid_url = self.base_link + url
        vid_url = vid_url.replace('/link/','/site/')
        Log(repr(vid_url))

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0"
            ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
            ,"Accept-Encoding":"gzip"
            ,"Referer":self.base_link
            }
        hoster_url = client.request(
            vid_url
            , output = 'geturl'
            #, post='' #we POST instead of GET to avoid cloudflare - will time-out a lot
            , headers=self.headers
            , timeout='30'
            )
        if not hoster_url: hoster_url = vid_url

        hoster_name = urlparse(vid_url).netloc.split("//")[-1].split("/")[0]
        Log(repr((vid_url, hoster_name, hoster_url)))

        if hoster_name in ['voe','voe.sx']:
            valid, hoster = (True,'voe')
        else:
            valid, hoster = source_utils.is_host_valid(hoster_url, hostDict)
##            Log(repr((valid,hoster)))
        if valid:
            pass
        else:
            Log(u"skipping {}".format((hoster_url,vid_url)))
            return


        link = hoster_url + Header2pipestring(headers)
        
        self.sources.append(
                        {
                        'source': hoster
                        , 'quality': 'SD'
                        , 'info': ''
                        , 'language': 'en'
                        , 'url': link
                        , 'direct': True
                        , 'debridonly': False
                        }
                       )

    except:
        traceback.print_exc()
        source_utils.scraper_error(self.provder_name)
#__________________________________________________________________________
#        
