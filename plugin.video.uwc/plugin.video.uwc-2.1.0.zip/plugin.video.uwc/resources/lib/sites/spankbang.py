'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
##
##   2025-05 cloudflare
##

import json
import re
import xbmc
import xbmcgui
import search

import utils
from utils import Log,LogR
import constants as C
    
FRIENDLY_NAME = '[COLOR {}]spankbang[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = 'https://spankbang.com'
SEARCH_URL = ROOT_URL + '/s/'
SEARCH_URL = ROOT_URL + '/s/{}/{}/'
URL_CATEGORIES = ROOT_URL + '/categories' 
URL_RECENT = ROOT_URL + '/new_videos/{}/'

MAIN_MODE          = C.MAIN_MODE_spankbang
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
FIRST_PAGE = 1

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon  )
    List(URL_RECENT, page_start=FIRST_PAGE, page_end=None, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):

##    raise Exception('2025-05 cf')

    LogR(locals())

    list_url=utils.Initialize_Common_Icons(  url = url
                                           , keyword=keyword
                                           , SEARCH_URL=SEARCH_URL
                                           , SEARCH_MODE=SEARCH_MODE
                                           , page_start=page_start
                                             , page_end=page_end
                                             )  
    
    # read html
    Log("list_url={}".format(list_url))    

    headers = {}
##    headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0"
##    headers['Accept-Encoding'] = 'gzip'
##    headers['Accept'] = '*/*'

    listhtml = utils.getHtml(list_url)#, , headers=headers, ignore404=True , send_back_redirect=True)
    if "Page Not Found" in listhtml:
        video_region = ''
    else: #distinguish between adverts and videos
        try:
            regex = '<div class="main_results(.+)<footer>'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
            Log("video region found via regex".format())
        except:
            video_region = listhtml

    regex = 'div class="video-item" data-id=.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="l">([^<]+)<.+?class="(?:h|n)">([^<]+)<'  #2020-10-17
    regex = 'div class="video-item." data-id=.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="l">([^<]+)<.+?class="(?:h|n)">([^<]+)<'  #2020-11-21

    regex = ( 
        'div class="video-item"'
        '.+?data-id=.+?'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        #'.+?class="video-badge h">(?P<hd>[^<]+?)<'
        '(?P<hd>)'  #hd badge is not reliable; skip it
        '.+?class="video-badge l">(?P<duration>\d+)'
    )#2025-01-08
    
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, hd, duration in info:
    #for videourl, thumb, label, duration, hd in info:
        hd = utils.Normalize_HD_String(hd)
        if not thumb.startswith('http'): thumb = "https:" + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log(u"   label={}".format(label))
        duration = int(duration)*60 #assume minutes for now
##        Log(u"duration={}".format(duration))

        if int(duration) < C.minimum_scene_duration: continue

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration
            , noDownload=False)
##    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    if (progress_dialog is None) or (progress_dialog and not progress_dialog.iscanceled()):
        utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
        if (testmode == True) and (len(videourl) > 1):
            Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)
    

    regex = (
        'class="pagination".+?(class="next"><a href)'
        )
    np_info=re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for np_url in np_info:
        np_number = int(page)+1
        np_url = url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page_start=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth:
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page_start=np_number
                     , end_directory=end_directory
                     , keyword=keyword)
        break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
##@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end'])
##def Search(searchUrl, keyword=None, end_directory=True, page_start=FIRST_PAGE, page_end=None, progress_dialog=None):
@C.url_dispatcher.register(
    SEARCH_MODE
    , ['url']
    , ['keyword'
       , 'end_directory'
       , 'page_start'
       , 'page_end'
       , 'bulk_operation'
       ]
    )
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=1
    , page_end=1
    , progress_dialog=None
    , bulk_operation=False
    ):
    
    LogR(locals())

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page_start=page_start, page_end=page_end, end_directory=end_directory)
        return
    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(title,'{}')
    Log("searchUrl='{}'".format(searchUrl))    
    List( url=searchUrl
        , page_start=FIRST_PAGE, page_end=page_end
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)
    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page_start)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url)

    regex = '<a href="(/category/[^"]+)"><img src="([^"]+)"><span>([^<]+)</span>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, thumb, label in info:
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        videourl = videourl.split('?')[0] + '{}/?period=all'
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page_start=FIRST_PAGE
            ,iconimage=thumb
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True
         , page_start=FIRST_PAGE, page_end=FIRST_PAGE
         ,progress_dialog=None, bulk_operation=False
        ):
    raise Exception('2025-05 cf')

    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))

    if not keyword:
        prev_keyword = utils.get_setting('quick_search_string')
        if prev_keyword: keyword = prev_keyword
    if not keyword:
        keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
        if  keyword == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=keyword)

    List(URL_RECENT, page_start=FIRST_PAGE, page_end=None, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page_start=FIRST_PAGE, page_end=page_end)
##    Categories(URL_CATEGORIES, False)

    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    
    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
##@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
##def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
##    name = utils.cleantext(name)
##    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
##    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
##    else: max_video_resolution = None
##    description = name + '\n' + ROOT_URL
##    video_url = None
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))

    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    elif playmode_string == C.PLAYMODE_DIRECT:  max_video_resolution = 99999 #if 'direct' was chosen, use max available resolution
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
##    progress_dialog = None
    
    try:
        progress_dialog = xbmcgui.DialogProgressBG()
        progress_dialog.create(u"Playing "+name)

        full_html = utils.getHtml(url, ROOT_URL)

        if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
            Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
            return
        
    ##    stream_key = re.compile("data-streamkey=\"([^\"]+)\"").findall(html)
    ##    if stream_key:
    ##        stream_key = stream_key[0]
    ##    else:
    ##        if "this video is no longer available" in html:
    ##            utils.Notify("Video '{}' has been deleted".format(name))
    ##        elif "This Video Is Private" in html:
    ##            utils.Notify("Video '{}' Is Private".format(name))
    ##        else:
    ##            utils.Notify("Update required for {}".format(ROOT_URL))
    ##        return
    ##    #Log(stream_key)

        description_regex = 'section class="details"(.+?)section class="user_uploads"'
        description_html = re.compile(description_regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if description_html: description_html=description_html[0]
        else: description_html=''
        description = ''
        desc_separator_char = '; '
        pornstar_regex = 'href="(?:/pornstar/|/tag/).+?>([^<]+?)<'
        pornstars = re.compile(pornstar_regex, re.DOTALL | re.IGNORECASE).findall(description_html)
        for pornstar in pornstars:
            if pornstar.lower() not in description.lower():
                description = description + utils.cleantext(pornstar) + desc_separator_char
        description = description.strip(desc_separator_char)
        if description == '':  description=name + '\n' + ROOT_URL
        else:           description=description + '\n' + ROOT_URL
    ##    Log(u"description={}".format(description.decode("utf8")))



        links_regex = 'var stream_data = (.+?\]})'
        links_json_html = re.compile(links_regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if links_json_html: links_json_html=links_json_html[0]
        else: links_json_html='{}'
    ##    Log("links_json_html={}".format(links_json_html))
        links_json_html = links_json_html.replace('\'','"')
        json_urls = json.loads(str(links_json_html))
    ##    Log("json_urls={}".format(repr(json_urls)))

        list_key_value = {} 
        for json_url in json_urls:
            q = json_url
            v = json_urls[json_url]
            if (q.endswith('0p') and not q.startswith('m3u8')) or q == '4k':
                if len(v) > 0:
                    v = v[0]
                    list_key_value[q] = v
        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function            
        video_url = utils.SortVideos(
            sources=list_key_value
            ,download=download
            ,vid_res_column=0
            ,max_video_resolution=max_video_resolution
            )


        #we should have a url by now...
        if not video_url:
            if testmode:
                raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
            else:
                utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(url, ROOT_URL))
            return

        #always set referrer so that 'kodi' does not appear on the target server
        if '|' not in video_url:
            headers = C.DEFAULT_HEADERS.copy()
            if url: headers['Referer'] = url

        Log("video_url='{}'".format(video_url))

        #during testmode, only ensure that a url can be generated
        if testmode:
            Log("Would have played video_url; but in test mode")
            return
        
##        utils.playvid(video_url
##                    , name=name, download=download
##                    , description=description, playmode_string=playmode_string
##                    , play_profile=play_profile)
        utils.playvid(
            video_url
            , name=name
            , download=download
            , description=description
            , playmode_string=playmode_string
            , play_profile=play_profile
    ##        , download_filespec=download_filespec
            , mode = PLAY_MODE
    ##        , url_factory = url
    ##        , icon_URI = icon_URI            
            )
##        utils.playvid(video_url, name=name, download=download, description=description)
    finally:
##        pass
        if progress_dialog: progress_dialog.close()
        progress_dialog = None
        
#__________________________________________________________________________
#
