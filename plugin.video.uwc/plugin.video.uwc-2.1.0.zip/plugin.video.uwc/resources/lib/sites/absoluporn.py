'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
from base_website import Base_Website
from utils import Log,LogR

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]absoluporn[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False
    
    _ROOT_URL        = u"http://www.absoluporn.com"
    _URL_CATEGORIES  = _ROOT_URL + '/en'
    _URL_RECENT      = _ROOT_URL + '/en/wall-date-{}.html'
    _SEARCH_URL      = _ROOT_URL + '/en/search-{}-{}.html'

    _MAIN_MODE = C.MAIN_MODE_absoluporn

    _FIRST_PAGE = 1

    _LIST_REDIRECTED_URL_BECOMES_LISTURL = False

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = 'class="bloc-menu-centre(.+?)<script>'

    #which to strings may indicate that there is nothing to be found
##    _ITEMS_NOT_FOUND_INDICATORS = [
##        "<p>Make sure that all words are spelled correctly.</p>"
##        , "No videos found for "
##        ]

    #videos on this page
    _REGEX_list_items = (
        'thumb-main-titre"><a href="..(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
        '.+?<div class="thumb-info">(?P<hd>'
        '.+?)time">(?P<duration>[^<]+)<'
        "(?P<desc>)"
        )

    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #show all options

    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = '<span class="text16">.+?href="..([^"]+)".+?>([^<]+)<'

    #where categories can be found
    _REGEX_categories_region = (
        'class="pvicon-categorie"(.+?)>All tags<'
        )
    _REGEX_categories = (
        'href="..(?P<videourl>[^"]+)"'
        '.+?>(?P<label>[^<]+)<'
        '(?P<thumb>)'
        )

    #where playable urls live
    _REGEX_playsearch_01 = (
        '<source src="(?P<url>[^"]+?)" type='
        '.+?(?P<res>\d)'
        )
#<source src="http://51.255.119.252/new3/56ea912c4df934c216c352fa8d623af3/588711290.mp4" type="video/mp4">

    #description for the playable url
    _REGEX_tags = 'class="link12">(?P<tag>[^<]+)<'
    _REGEX_tags_region = '(.+)'

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def xx_ALTERNATE_playsearch_01(self, *args, **kargs):

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        import re
        import utils
        import resolver
        
        regex = '<iframe.*?src="([^"]+)"'
        intermediate_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if intermediate_url: intermediate_url = intermediate_url[0]
        else: return alt_results
    
##    #__________________________________________________________________________
##    # Change list url as neeeded by website
##    def List_URL_Normalize(self, url):
##        return url.replace('page1.html', '')
    
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        return keyword.replace('+',' ').replace(' ','_')

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format(keyword,'{}')
        
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url.replace('1.html', '{}.html')

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.LIST_MODE
    , ['url']
    , ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation']
    )
def List(
    url
    , page_start=None
    , page_end=None
    , end_directory=True
    , keyword=''
    , testmode=False
    , bulk_operation=False
    ):
    website.List(
        url
        , page_start=page_start
        , page_end=page_end
        , end_directory=end_directory
        , keyword=keyword
        , testmode=testmode
        , bulk_operation=bulk_operation
        )
    LogR(locals())
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
