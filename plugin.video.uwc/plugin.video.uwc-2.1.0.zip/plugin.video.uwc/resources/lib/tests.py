#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

'''
first page; listing, single next page prompt, single search prompt
next page; listing, single next page prompt, single search prompt

recurse, first page;  listing, single next page prompt
recurse, next page, listing

search, first page; listing, single next page prompt, single search prompt
search, next page; listing, single next page prompt, single search prompt

recurse search, first page; listing, single next page prompt, single search prompt
recurse search, next page, listing
'''

#import base libraries
import datetime
import json
import threading
import traceback
import unicodedata
#import internal addon libraries
import utils
import constants as C
#define common aliases
from utils import Log,LogR
from constants import Queue

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_TEST_ALL)
def TEST_ALL(quick_search_string=None):

    #one of the tests is searching via keyword...get a keyword
##    quick_search_string = 'sex'
    if not quick_search_string:
        prev_search_string = C.addon.getSetting(id='quick_search_string')
        quick_search_string = utils._get_keyboard( heading="Search query", default=prev_search_string  )
        if  quick_search_string == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=quick_search_string)

    progress_dialog = utils.Progress_Dialog(
        C.addon_name
        ,u"Testing all sites using '{}' as search term".format(
            quick_search_string
            )
        )

    org_C_MAX_RECURSE_DEPTH = C.MAX_RECURSE_DEPTH
    try:
        
        #generate list of potential test sites by listing dir
        get_sites = utils.Get_Sites()
        #add sites to settings.xml [so that we can track which site has been tested today]
        test_list = C.addon.getSetting(id=C.TESTING_LIST_NAME)
##        test_list = "" #dev test only  ... force all tests regarless if they were run today
        if test_list == "": test_list = json.loads("{}")
        else: test_list = json.loads(test_list)
        for sitename, module in get_sites:
            if not (sitename in test_list):
                test_list[sitename] = ''
        C.addon.setSetting(id=C.TESTING_LIST_NAME, value=json.dumps(test_list))

        
        #temporarilty force only  X   recurse depth for this feature
        C.DEFAULT_RECURSE_DEPTH = 2
        C.MAX_RECURSE_DEPTH = 3

        #perform tests [if not passed test today]
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        q = Queue.Queue()
        i = 0 #dev test only
        all_method_results = {}
        try:
            get_sites = utils.Get_Sites() #refresh this variable
            for sitename, module in get_sites:
                all_method_results[sitename] = None #assume success
                last_success_date = test_list[sitename]
                if last_success_date < today: #we should test today
                    i = i + 1 #dev test only
                    method_to_call = getattr(module, 'Test')
                    kwargs = {  "keyword": quick_search_string
                              , "end_directory": False
                              , "page_start": 1
                              , "page_end": 1+C.DEFAULT_RECURSE_DEPTH
                              , "bulk_operation": True
                              , "progress_dialog": progress_dialog
                              }
                    q.put( (sitename,method_to_call,kwargs) )
                else:
                    Log(u"'{}' passed '{}'".format(sitename, last_success_date))
                #if i > 3: break #dev test only
                     
            for k in range(C.MAX_WEBCRAWLER_THREADS):
                worker = threading.Thread(target=utils.crawl
                                          , args=(q,all_method_results))
                worker.daemon = False
                worker.start()
            q.join()

##            get_sites.send(False) #testing #cancel yield operations; will raise StopIteration inside get_sites

        except StopIteration:
            pass
        except:
            traceback.print_exc()

        #analyze test results and save them
        something_failed = False
        for sitename in all_method_results:
            if not(all_method_results[sitename] in [None, True]): #None or True are the success codes
                something_failed = True
                try:
                    LogR( sitename )
                    LogR( ('allmethodresults', all_method_results[sitename]))
                    n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(sitename, sitename)
                    try:
                        n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(
                            sitename
                            , all_method_results[sitename]
                            )
                        if C.PY2: n = n.decode("utf8", "ignore")
                    except:
                        traceback.print_exc()
                        n = C.STANDARD_MESSAGE_FAILED_SEARCH.format(
                            sitename
                            , unicodedata.normalize('NFKD'
                                                    , all_method_results[sitename]
                                                    )
                            )
                        if C.PY2: n = n.decode("utf8", "ignore")

                except:
                    traceback.print_exc()
                utils.addDownLink(
                    name=n
                    ,url=C.DO_NOTHING_URL
                    ,mode=C.NO_ACTION_MODE
                    ,iconimage=C.warning_icon
                    )
            else:
                test_list[sitename] = today
        C.addon.setSetting(id=C.TESTING_LIST_NAME, value=json.dumps(test_list))
        
        #visual indicator of success
        if not something_failed:
            utils.addDownLink(
                    name=u"[COLOR {}]all tests passed on {}[/COLOR]".format(C.test_passed_text_color,today)
                    ,url=C.DO_NOTHING_URL
                    ,mode=C.NO_ACTION_MODE
                    ,iconimage=C.success_icon
                    )

    except:
        traceback.print_exc()
    finally:
        C.MAX_RECURSE_DEPTH = org_C_MAX_RECURSE_DEPTH
        if progress_dialog:
            if progress_dialog.iscanceled():
                utils.addDownLink(
                    name='Test All Cancelled'
                    ,url=C.DO_NOTHING_URL
                    ,duration = C.STANDARD_DURATION_REFRESH
                    ,mode=C.ROOT_INDEX_INDEX
                    ,iconimage=C.warning_icon
                    )
            progress_dialog.close()

##    Log(repr(add_count))
    Log("TEST_ALL ended")
    utils.endOfDirectory()
#__________________________________________________________________________
#
