'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 NothingGnome

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = 'https://spankbang.com'

SEARCH_URL = ROOT_URL + '/s/'
SEARCH_URL = ROOT_URL + '/s/{}/{}/'

URL_CATEGORIES = ROOT_URL + '/categories' 
URL_RECENT = ROOT_URL + '/new_videos/{}/'
#https://spankbang.com/new_videos/2/

MAIN_MODE       = '440'
LIST_MODE       = '441'
PLAY_MODE       = '442'
CATEGORIES_MODE = '443'
SEARCH_MODE     = '444'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color)
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon  )

    List(URL_RECENT, page='1', end_directory=True, keyword='')
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH    
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon )
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "Page Not Found" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            regex = '<div class="results(.+)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
            Log("video region found via regex".format())
        except:
##            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))
            


    regex = 'div class="video-item".+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?((?:class="i-hd">[^<]+<|class="i-len")).+?fa fa-clock-o"></i>([^<]+)<'
    regex = 'div class="video-item".+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="i-len">([^<]+)<.+?(?:class="i-hd">([^<]+)<|/p)'
    regex = 'div class="video-item.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="i-len">([^<]+)<.+?(?:class="i-hd">([^<]+)<|/p)'    #2020-07-03
    regex = 'div class="video-item" data-id=.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="l">([^<]+)<.+?class="(?:h|n)">([^<]+)<'  #2020-10-17
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #for videourl, thumb, label, hd, duration in info:
    for videourl, thumb, label, duration, hd in info:
##        Log("label={}".format(label))
##        Log("hd={}".format(hd))        
        hd=hd.lower()
        #if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        if   '4k' in hd or '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not thumb.startswith('http'): thumb = "https:" + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("videourl={}".format(videourl))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration + 'm'
            , noDownload=False)
    #
    # check for a minimum during tesing
    #
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError
    

    #np_info=re.compile('<a href="([^"]+)">&raquo;', re.DOTALL | re.IGNORECASE).findall(listhtml)
    regex = '<a href=".+?(\d+)/">&raquo;'
    regex = 'href=".+?(\d+)/\??[^"]*">&raquo;'
    np_info=re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_number = np_url
            np_url = url
            #np_url = np_url.replace(" ", "+") #website does not doe this properly for search pages...
            #if np_url.startswith('/'): np_url = ROOT_URL + np_url
            Log("np_url='{}'".format(np_url))
            Log("np_number='{}'".format(np_number))

            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword)
            break # in case there are multiple pagination
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(title,'{}')
    Log("searchUrl='{}'".format(searchUrl))    
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url)

    regex = '<a href="(/category/[^"]+)"><img src="([^"]+)"><span>([^<]+)</span>'
    #regex = '<a href="(/category/[^"]+)".+?>.*?data-src="([^"]+)" alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, thumb, label in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
## https://spankbang.com/category/vr/?order=trending
## https://spankbang.com/category/cam/2/?period=all
        ## order=trending&
        videourl = videourl.split('?')[0] + '{}/?period=all'
        
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
        utils.addDir(name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page='1'
            ,iconimage=thumb )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None, desc=None):
    Log("Playvid url='{}' name='{}' download='{}' desc='{}'".format(url, name, download, desc))

    html = utils.getHtml(url, ROOT_URL)
    stream_key = re.compile("data-streamkey=\"([^\"]+)\"").findall(html)
    if stream_key:
        stream_key = stream_key[0]
    else:
        if "this video is no longer available" in html:
            utils.Notify("Video '{}' has been deleted".format(name))
        else:
            utils.Notify("Update required for {}".format(ROOT_URL))
        return
    #Log(stream_key)

    description = ''
    pornstar_regex = 'Pornstar:.+?href.+?>([^<]+?)<'
    pornstars = re.compile(pornstar_regex, re.DOTALL | re.IGNORECASE).findall(html)
    for pornstar in pornstars:
        description = pornstar + '; ' + description
    Log("description={}".format(description))

    tag_text = ''
    tags_regex = 'Tags:.+?href.+?>([^<]+?)<'
    tags= re.compile(tags_regex, re.DOTALL | re.IGNORECASE).findall(html)
    for tag in tags:
        tag_text = tag + '; ' + tag_text
    Log("tag_text={}".format(tag_text))

    description = tag_text + '; ' + description
    
    from requests import Request, Session
    s = Session()
    url = ROOT_URL + "/api/videos/stream"
    headers = {"User-Agent": utils.USER_AGENT
               , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
               , "Referer": url
               }
    data = "id={}&data=0".format(stream_key)
    req = Request('POST', url, data=data, headers=headers)
    prepped = s.prepare_request(req)
    resp = s.send(prepped , verify=False)
    Log("resp.content='{}'".format(repr(resp.content)))

    json_urls = json.loads(resp.content)
    Log("json_urls={}".format(json_urls))

    match = None

    match_4k = json_urls["4k"]
    match_1080 = json_urls["1080p"]
    match_720 = json_urls["720p"]
    match_480 = json_urls["480p"]
    match_320 = json_urls["320p"]
    match_240 = json_urls["240p"]

    match_m3u8_4k = json_urls["m3u8_4k"]
    match_m3u8_1080 = json_urls["m3u8_1080p"]
    match_m3u8_720 = json_urls["m3u8_720p"]
    match_m3u8_480 = json_urls["m3u8_480p"]
    match_m3u8_320 = json_urls["m3u8_320p"]
    match_m3u8_240 = json_urls["m3u8_240p"]

    maximum_video_resolution = int(utils.addon.getSetting("maximum_video_resolution"))

    if match_4k and maximum_video_resolution >= 1440:
        match = match_4k
    elif match_1080 and maximum_video_resolution >= 1080:
        match = match_1080
    elif match_m3u8_1080 and maximum_video_resolution >= 1080:
        match = match_m3u8_1080
    elif match_720 and maximum_video_resolution >= 720:
        match = match_720
    elif match_m3u8_720 and maximum_video_resolution >= 720:
        match = match_m3u8_720
    elif match_480: match = match_480
    elif match_320: match = match_320
    elif match_240: match = match_240

##    if match_4k and utils.addon.getSetting("allow_suXXper_high_resolution").lower() == "true": match = match_4k
##    elif match_1080: match = match_1080
##    elif match_m3u8_1080: match = match_m3u8_1080
##    elif match_720: match = match_720
##    elif match_m3u8_720: match = match_m3u8_720
##    elif match_480: match = match_480
##    elif match_320: match = match_320
##    elif match_240: match = match_240


    Log("match={}".format(match))
    if type(match) == list:
        #match = match[0]
        import random
        match = random.choice(match)
##        Log("match={}".format(match))
##        Log("match={}".format(type(match)))
        
    
    #Log(match)
    if match:
        utils.playvid(videourl=match, name=name, download=download, description=description + '\n' + ROOT_URL )
    else:
        utils.notify('Oh oh','Couldn\'t find a video')

