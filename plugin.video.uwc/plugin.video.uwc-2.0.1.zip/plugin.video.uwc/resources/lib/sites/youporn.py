'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
from base_website import Base_Website
from utils import Log,LogR,RandomNumber,Sleep

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Youporn[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = True
    
    _ROOT_URL        = "https://www.youporn.com"
    _URL_CATEGORIES  = _ROOT_URL + '/categories/'
    _URL_RECENT      = _ROOT_URL + '/browse/time/?page={}'
    _SEARCH_URL      = _ROOT_URL + '/search/?query={}&page={}'
#             https://www.youporn.com/search/?query=autumn+falls&page=3
    _MAIN_MODE = C.MAIN_MODE_youporn

    _FIRST_PAGE = 1

    _SAVE_COOKIES = True

    #where we can find videos on this page [exclude advertisement]
#    _REGEX_video_region = '(?:data-section_name="day_by_day_section" data-espnode|video_row_main_search"|data-espnode="videolist")(.+?)(?:id="pagination"|<footer>)'
# 2024-09 python regex fails.  The page data does not allow ending  (?:id="pagination"|<footer>)
    _REGEX_video_region = 'id="adblock_close_button"(.+)'
    
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "<p>Make sure that all words are spelled correctly.</p>"
        , "No videos found for "
        ]

    #videos on this page
    _REGEX_list_items = (
        'data-video-id="\d.+?href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        #'.+?"video-best-resolution">(?P<hd>\d+)' ##2024-09 no more resulotin
        '(?P<hd>)'
        '.+?class="video-duration.+?>\s+?(?P<duration>[\d:]+)\s<'
        )
##    Log(_REGEX_list_items, C.LOGNONE)

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = 'id="next".+?href="([^"]+)"'


    #where categories can be found
    _REGEX_categories_region = 'id="mainContent">(.+)'
    _REGEX_categories = (
        '<a href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        )

    #where playable urls live
    _REGEX_playsearch_01 = None #'mediaDefinition:\s+?(?P<json>\[[^\]]+\]),'

    #description for the playable url
##    _REGEX_tags = '"pornstar_tag".+?>([^<]+)<'
##    _REGEX_tags_region = 'class="categorieswrapper(.+?)<noscript>'
    _REGEX_tags = 'href="/(?:pornstar|porntags)/.+?>([^<]+)<'
    _REGEX_tags_region = 'class="pornstarRow(.+?)<script>'


    #__________________________________________________________________________
    # hack url to remove page=1 - site behaves weird during search
    def List_URL_Normalize(self, url, page=None):
        if int(page) == 1:
            if url.endswith('&page=1'):
                url = url[:-len('&page=1')]
##                url = url + '&page=2'
##                url = url[:-len('&page=1')]
        Sleep(2000) # seems to prevent duplicates/ maybe a slightly smaller number would be better
        return url
##        return url #+ '&=_' + RandomNumber()


    
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants
    def Search_Keyword_Normalize(self, *args, **kargs):
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args) > 0): keyword = args[0]
        else                                     : keyword = ""
##        Log("keyword='{}'".format(repr(keyword)))
        keyword = keyword.replace(' ','+').replace('_','+')
##        Log("keyword='{}'".format(repr(keyword)))
        return keyword
    
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        #2021-06 site moved data to separate page
        REGEX_playsearch_01 = 'mediaDefinitions":(?P<json>\[[^\]]+\]),'
        source_html = kargs['full_html']
        referer = kargs['referer']
        videos_list = list() #hold multiple video_url when possible

        import re
        import json
        from utils import getHtml as getHtml
        
        sources_list = re.compile(REGEX_playsearch_01, re.DOTALL | re.IGNORECASE).finditer(source_html)
        for source in sources_list:
            sources_list = source.group('json')
            json_sources_1 = json.loads(sources_list)
            for json_src in json_sources_1:
                if 'videoUrl' in json_src:
                    if json_src['videoUrl'] != '':
                        url_2 = json_src['videoUrl']
                        if not url_2.startswith('http'): url_2 = self._ROOT_URL +  json_src['videoUrl']
                        json_html = getHtml( url_2 , referer)
                        json_sources_2 = json.loads(json_html)
                        for json_src_2 in json_sources_2:
                            if json_src_2['videoUrl'] != '' and not isinstance(json_src_2['quality'], list):
                                videos_list.append((json_src_2['quality'], json_src_2['videoUrl']))
                            
                break

        Log("videos_list={}".format(repr(videos_list)))        
        return videos_list
    
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url + '?page={}'

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url
         , page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE
         , end_directory=True, keyword='', testmode=False
         , bulk_operation=False ):
    website.List(url, page_start=page_start, page_end=page_end
                 , end_directory=end_directory, keyword=keyword
                 , testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True, page_start=1, page_end=1):
    website.Test(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )

#__________________________________________________________________________
#
