'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
from base_website import Base_Website
from utils import Log,LogR

class Specific_Website(Base_Website):
    
    _FRIENDLY_NAME = '[COLOR {}]pornburst[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False

    _ROOT_URL           = "https://www.pornburst.xxx"
    _URL_RECENT         = _ROOT_URL + '/ajax/homepage/?page={}'
    _URL_CATEGORIES     = _ROOT_URL + '/categories/'
    _SEARCH_URL         = _ROOT_URL + '/ajax/new_search/?q={}&page={}'

    _MAIN_MODE = C.MAIN_MODE_pornburst

    _FIRST_PAGE = 1 #Note:site does not support page1.html

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = '(.+)'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        ]

    #videos on this page    
    _REGEX_list_items = (
        'class="box-link-productora".+?href=\"(?P<videourl>[^\"]+)\"'
        '.+?data-src=\"(?P<thumb>[^\"]+)\"'
        '.+?alt=\"(?P<label>[^\"]+)\"'
        '.+?title="Length"></span>(?P<duration>[^<]+)'
        '(?P<hd>[\d]+)'
        )

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = '(.)'
    _REGEX_next_page_regex =  '(.)'

    #where categories can be found
    _REGEX_categories_region = '(.*)'
    _REGEX_categories = (
        '-categoria" href="(?P<videourl>/porn-videos[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        )
    #where playable urls live
    _REGEX_playsearch_01 = (
        'source src="(?P<url>[^"]+)'
        '.+(?P<res>\d)'
        )

    #description for the playable url
    _REGEX_tags = None #"href='/pornstar/.+?>([^<]+)<"
    _REGEX_tags_region = None#'<div id="data-video">(.+?)<div class="clear">'

    _MAX_RECURSE_DEPTH = 2
    
    #__________________________________________________________________________
    # Change list url as neeeded by website
    def List_URL_Normalize(self, url, page_start=None):
        return url.replace('page1.html', '') #this site does not like page1
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
       return self.ROOT_URL + url + 'page{}.html'
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        return thumb
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        return thumb
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args)>0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args)>1): keyword = args[1]
        elif (args is not None) and (len(args)>0): keyword = args[0]
        else                                     : keyword = ""

        keyword_1 = keyword.replace('+',' ').replace(' ','%20')
        keyword_2 = keyword_1.replace('%20','+')

        return search_url.format(keyword_1, '{}', keyword_2)

##    #__________________________________________________________________________
##    # add an alternative way to resolve a playable video url
##    # returned items must be a list of (res, url) items
##    def xxALTERNATE_playsearch_01(self, *args, **kargs):
##        Log(repr((args,kargs)))
##        import base64
##        import json
##        import re
####        import utils
##        alt_results = list()
##        full_html = kargs["full_html"]
##        url = kargs["referer"]
##
####        license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(full_html)
####        if license_code:
####            license_code = license_code[0]
####        else:
####            Log("url='{}'".format(url), xbmc.LOGNONE)
####            Log("No license_code found for {}".format(name))
####            return alt_results
##
##        regex = "video(?:_alt|)_url\d?: '([^']+)',.+?video(?:_alt|)_url\d?_text: '(\d+)"
##        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
##        if not sources: sources =[] #fake data so that next code can look simpler
##
####        import resolver
##        import utils
##
##        for video_url, res in sources:
##            
##            video_url += "?_rnd=" + utils.RandomNumber()
####            Log("license_code='{}'".format(license_code) )
####            fappy_salt = resolver.FaapySalt(license_code, "")
####            Log("fappysalt='{}'".format(fappy_salt))
####            old_fappy_code =  video_url.split('/')[5]
####            Log("old_fappy_code='{}'".format(old_fappy_code))
####            new_fappy_code = resolver.ConvertFaapyCode( old_fappy_code, fappy_salt)
####            Log("new_fappy_code='{}'".format(new_fappy_code))
##
##            alt_results.append(  (res, video_url)  )
####        video_url = utils.SortVideos(
####            sources=sources
####            ,download=download
####            ,vid_res_column=1
####            ,max_video_resolution=max_video_resolution
####            )
####        if not video_url:
####            return alt_results
##        
##
##        #videourl = videourl.replace(old_fappy_code, new_fappy_code)
##
####        headers = C.DEFAULT_HEADERS.copy()
####        headers['Referer'] = ROOT_URL #url
####        headers['Accept-Encoding'] = 'identity;q=1, *;q=0'
####        headers['Connection'] = 'keep-alive'
####        headers['Accept-Charset'] = '*'
####
####        video_url = video_url + utils.Header2pipestring(headers)
####        Log("video_url='{}'".format(video_url))
####
####        alt_results.append(  ('240', video_url)  )
##
##        Log("alt_results={}".format(repr(alt_results)))        
##        return alt_results
    
#__________________________________________________________________________
#




#__________________________________________________________________________
#
website = Specific_Website() #always need this
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
