'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#2025-04  cloudflare

import base64
import re
import xbmc
import time
import traceback

import utils
from utils import Log,LogR
import search
import constants as C
import resolver

FRIENDLY_NAME = '[COLOR {}]jav.guru[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_MOVIES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://jav.guru"
SEARCH_URL = ROOT_URL + '/page/{}/?s={}'
URL_RECENT = ROOT_URL + '/page/{}/'

MAIN_MODE          = C.MAIN_MODE_javguru
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = 1 #default first page

#__________________________________________________________________________
#

@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )
    utils.addDir(name="{}[COLOR {}]English Subbed[/COLOR]".format( 
                C.SPACING_FOR_TOPMOST, C.search_text_color) 
                ,url = SEARCH_URL
                ,mode = SEARCH_MODE
                ,keyword="English Subbed"
                ,page_start=FIRST_PAGE 
                ,iconimage=C.search_icon )
    utils.addDir(name="{}[COLOR {}]Uncensored[/COLOR]".format( 
                C.SPACING_FOR_TOPMOST, C.search_text_color) 
                ,url = 'https://jav.guru/category/jav-uncensored/page/{}/'
                ,mode = LIST_MODE
                ,page_start=FIRST_PAGE 
                ,iconimage=C.search_icon )
    utils.addDir(name="{}[COLOR {}]Carib[/COLOR]".format( 
                C.SPACING_FOR_TOPMOST, C.search_text_color) 
                ,url = SEARCH_URL
                ,mode = SEARCH_MODE
                ,keyword="Carib"
                ,page_start=FIRST_PAGE 
                ,iconimage=C.search_icon )

    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page_start=FIRST_PAGE, page_end=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List [url='{}', page_start='{}', end_directory='{}', keyword='{}']".format(url,page_start,end_directory,keyword))

    if not progress_dialog: progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    
    list_url=utils.Initialize_Common_Icons(  url = url
                                       , keyword=keyword
                                       , SEARCH_URL=SEARCH_URL
                                       , SEARCH_MODE=SEARCH_MODE
                                       , page_start=page_start
                                         , page_end=page_end
                                         )  

    #
    # read html
    #
    listhtml = utils.getHtml(list_url, auto_encode_content=True)
    if any(x in listhtml for x in ["I can't find porn to your request", "Sorry, nothing good matched"]) :
        listhtml = ""
        video_region = ""
    else:    #distinguish between adverts and videos
        regex = '(?:id=main|id="main"|class="search-submit")(.*)(?:</main></div>|class="paging-navigation"|class="footer)'
        video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
        if video_region:
            video_region=video_region[0]
        else:
            video_region=listhtml
##        Log("len(video_region)='{}'".format(len(video_region)))

    #
    # parse out list items
    #
    regex = (
        '(?:class="inside-article"|class=inside-article)'
        '.+?href=(.+?)\s'
        '.*?src=(.*?)\s'
        'alt="(.+?)"'
        )
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        desc = utils.cleantext(label)
        name = desc
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        utils.addDownLink( 
            name = name 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc = u"{}\n{}".format(desc, ROOT_URL)
            )
    if (progress_dialog is None) or (progress_dialog and not progress_dialog.iscanceled()):
        utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
        if (testmode == True) and (len(videourl) > 1):
            Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)

    #
    # next page items
    #
    #next_page_regex = "class=(?:'pages'|\"pagination\").+?class=(?:'|\")current(?:'|\")>(\d+)<"
##    next_page_regex = (
##        "class=(?:'pages'|\"pagination\"|\"paging)"
##        ".+?class=(?:'|\")current(?:'|\")>(\d+)<")
    next_page_regex = (
        "class=page-numbers"
        '.+?class="next page-numbers" href="?/page/(\d+)/'
        )
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(listhtml)
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url in np_info:
        np_url = url
        np_number=int(page)+1
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page_start=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page_start=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    SEARCH_MODE
    , ['url']
    , ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation']
    )
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=FIRST_PAGE
    , page_end=None
    , progress_dialog=None
    , bulk_operation=False
    ):
    LogR(locals())

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page_start=page_start, page_end=page_end, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format('{}',keyword) 
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page_start=FIRST_PAGE, page_end=page_end
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page_start)==C.FLAG_RECURSE_NEXT_PAGES))        
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory', 'page_start', 'page_end'])
def Test(keyword=None, end_directory=True
         , page_start=FIRST_PAGE, page_end=FIRST_PAGE
         ,progress_dialog=None, bulk_operation=False
         ):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))
    return
    if not keyword:
        prev_keyword = utils.get_setting('quick_search_string')
        if prev_keyword: keyword = prev_keyword
    if not keyword:
        keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
        if  keyword == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=keyword)
        
    List(URL_RECENT, page_start=FIRST_PAGE, page_end=None
         , end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False
           , page_start=FIRST_PAGE, page_end=page_end)

    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
##@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
##def Playvid(url, name, download=None, playmode_string=None):
##    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
##    if playmode_string: max_video_resolution=int(playmode_string)
##    else: max_video_resolution = None
##    description = name + '\n' + ROOT_URL
##    video_url = None
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    try:    
        source_html = utils.getHtml(url, ROOT_URL
                                    , auto_encode_content=True
                                    , cache_duration=0 #sit does not like this
                                    )

        regex_model_area = 'Actress:(.+)Studio'
        models_html = re.compile(regex_model_area, re.DOTALL | re.IGNORECASE).findall(source_html)
        if models_html: models_html=models_html[0]
        else: models_html = ''
        regex_model = '/actress/.+?rel="tag">(?P<model>[^<]+)<'
        source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(models_html)
        description = ''
        desc_separator_char = '; '
        if source_models:
            for model in source_models:
                description = description + desc_separator_char + model.group('model')
        description = description.strip(desc_separator_char)
        if description == '':  description=name + '\n' + ROOT_URL
        else:           description=description + '\n' + ROOT_URL
        Log(u"description={}".format(description))

        headers = C.DEFAULT_HEADERS.copy()
        headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
        
        regex_vid_sources = '","iframe_url":"([^"]+)"'
        vid_sources = re.compile(regex_vid_sources, re.DOTALL | re.IGNORECASE).findall(source_html)
        source_html = ''
        lockers = []
        LogR(vid_sources)

        dev_only = False
        if dev_only:
            locker_url = resolve_vid_source(vid_sources[0], headers, lockers)
            source_html = source_html + locker_url + "  "
        else:
            threads = []
            import threading 
            append = threads.append

            for vid_source in vid_sources:
                append(
                    threading.Thread(
                        name = "resolve_vid_source_thread"
                        ,target = resolve_vid_source
                        ,args   = (vid_source, headers, lockers)
                    )
                )
            LogR(threads)
            [i.start() for i in threads]
            
            alive = [x for x in threads if x.is_alive() is True]
            thread_time = 0.0
            max_thread_time = 600
            while alive and (thread_time < max_thread_time):
                alive = [x for x in threads if x.is_alive() is True]
                time.sleep(0.1)
                thread_time += 0.1

            LogR(threads)
            LogR(alive)
##        for vid_source in vid_sources:
##            Log("vid_source={}".format(vid_source))
##            if C.PY3: src = str(base64.b64decode(vid_source),'utf8').split('&bg=')[0]
##            if C.PY2: src = base64.b64decode(vid_source).split('&bg=')[0]
##            if 'd=' in src:
##                src_forward = src.split('d=')[1]
##                src_reverse = src.split('d=')[0] + 'r=' + src_forward[::-1]
##            else:
##                if '?bg=' in src:
##                    src_reverse = src.split('?bg=')[0]
##            headers['Referer'] = src
##            n_url = src_reverse
##            url = src_reverse
##
##            locker_html, locker_url = utils.getHtml(n_url, headers=headers, send_back_redirect=True, cache_duration=0 )
##                    
##            if not locker_url:
##                locker_url = url
##            source_html = source_html + locker_url + "  "

        source_html = "  ".join(lockers)
        LogR(source_html)

##        utils.LogFlush()
##        return



        if source_html == '':
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
            return

 

        video_url = resolver.resolve_video(videosource=source_html
                                           , name=name
                                           , download=download
                                           , url=url
                                           , ask_which_file_hoster = (testmode==False) )
        Log("video_url={}".format(video_url))
        if not video_url:
            utils.Notify(u"No video file found for {}".format(name))
            return

        if testmode:
            Log("video_url not played due to test mode")
            return
        
        utils.playvid(
            video_url
            , name=name
            , download=download
            , description=description
            , playmode_string=playmode_string
            , play_profile=play_profile
    ##        , download_filespec=download_filespec
            , mode = PLAY_MODE
    ##        , url_factory = url
    ##        , icon_URI = icon_URI            
            )
    except:
        traceback.print_exc()
        raise
    finally:
##        xbmc.executebuiltin('Dialog.Close(busydialog)')
        pass
#__________________________________________________________________________
#
def resolve_vid_source(vid_source, headers, lockers):

    Log("resolve_vid_source={}".format(vid_source))
    if C.PY3: src = str(base64.b64decode(vid_source),'utf8').split('&bg=')[0]
    if C.PY2: src = base64.b64decode(vid_source).split('&bg=')[0]
    if 'd=' in src:
        src_forward = src.split('d=')[1]
        src_reverse = src.split('d=')[0] + 'r=' + src_forward[::-1]
    else:
        if '?bg=' in src:
            src_reverse = src.split('?bg=')[0]
    headers['Referer'] = src
    n_url = src_reverse
    url = src_reverse

    locker_html, locker_url = utils.getHtml(n_url, headers=headers, send_back_redirect=True, cache_duration=0 )
            
    if not locker_url:
        locker_url = url

    lockers.append(locker_url)
    return locker_url
    return


    Log('get_sources')
    Log(repr((url,)))
    try:

        vid_url = self.base_link + url
        vid_url = vid_url.replace('/link/','/site/')
        Log(repr(vid_url))

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0"
            ,"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
            ,"Accept-Encoding":"gzip"
            ,"Referer":self.base_link
            }
        hoster_url = client.request(
            vid_url
            , output = 'geturl'
            #, post='' #we POST instead of GET to avoid cloudflare - will time-out a lot
            , headers=self.headers
            , timeout='30'
            )
        if not hoster_url: hoster_url = vid_url

        hoster_name = urlparse(vid_url).netloc.split("//")[-1].split("/")[0]
        Log(repr((vid_url, hoster_name, hoster_url)))

        if hoster_name in ['voe','voe.sx']:
            valid, hoster = (True,'voe')
        else:
            valid, hoster = source_utils.is_host_valid(hoster_url, hostDict)
##            Log(repr((valid,hoster)))
        if valid:
            pass
        else:
            Log(u"skipping {}".format((hoster_url,vid_url)))
            return


        link = hoster_url + Header2pipestring(headers)
        
        self.sources.append(
                        {
                        'source': hoster
                        , 'quality': 'SD'
                        , 'info': ''
                        , 'language': 'en'
                        , 'url': link
                        , 'direct': True
                        , 'debridonly': False
                        }
                       )

    except:
        traceback.print_exc()
        source_utils.scraper_error(self.provder_name)
            
