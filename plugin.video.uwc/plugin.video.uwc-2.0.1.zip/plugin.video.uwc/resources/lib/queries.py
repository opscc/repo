#-*- coding: utf-8 -*-


import constants as C

from utils import Log,LogR,UTC_timestamp
from utils import get_setting as GetSetting


FAV_DB_VERSION_1 = 1
FAV_DB_VERSION_2 = 2
FAV_DB_VERSION_3 = 3
FAV_DB_VERSION_4 = 4

KEYWORD_DB_VERSION_1 = 1
KEYWORD_DB_VERSION_2 = 2
KEYWORD_DB_VERSION_3 = 3
KEYWORD_DB_VERSION_4 = 4

CREATE_UUID_STRING = (
    "select lower(hex( randomblob(4)) || '-' ||      hex( randomblob(2)) "
    "        || '-' || '4' || substr( hex( randomblob(2)), 2) || '-' "
    "        || substr('AB89', 1 + (abs(random()) % 4) , 1)  "
    "        || substr(hex(randomblob(2)), 2) || '-' || hex(randomblob(6)))"
)


#__________________________________________________________________
#
def LIST_FAVORITES(FAV_DB_VERSION):
    try: default_favorites_order = " ORDER BY " + GetSetting("default_favorites_order", str)  #'ORDER BY RANDOM()'
    except: default_favorites_order = ' ' #random order...optional?
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " SELECT "
            "   name "
            " , rowid as id"
            " , url "
            " , mode "
            " , image "
            " , description "
            " , camsite "
            " , binary_image "
            " , uuid"
            " FROM favorites "
            " where is_deleted=0 {}".format(default_favorites_order)
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def RENAME_FAV(FAV_DB_VERSION, name, url, uuid):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " UPDATE favorites "
            " SET "
            " name = ? "
            " , url = ? " #url is changed due to MFC 
            " , date_modified = CAST(strftime('%s') as INT) "
            " WHERE uuid = ?;"
            )
        if not uuid: raise Exception()
        params = (name,url,uuid)
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return (query,params)
#__________________________________________________________________
#
def REFRESH_FAV(FAV_DB_VERSION, uuid, image, description, binary_image):
    if FAV_DB_VERSION >= FAV_DB_VERSION_3:
        query = (
            " UPDATE favorites "
            " SET "
            " image = ?"
            " , binary_image = ? "
            " , description = ? "
            " , date_modified = CAST(strftime('%s') as INT) "
            " WHERE uuid = ?;"
            )
        if not uuid: raise Exception()
        params = (image,binary_image,description,uuid)
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return (query,params)
#__________________________________________________________________
#
def DELETE_FAV(FAV_DB_VERSION, url, uuid):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        if uuid: 
            query = (
                " UPDATE favorites "
                " SET is_deleted = 1 "
                " , date_modified = CAST(strftime('%s') as INT) "
                " WHERE uuid = ?;"
                )
            params = (uuid,)
        else:
            query = (
                " UPDATE favorites "
                " SET is_deleted = 1 "
                " , date_modified = CAST(strftime('%s') as INT) "
                " WHERE url LIKE ?;"
                )
            params = (url,)
##    else:
##        query = (
##            " DELETE FROM favorites "
##            " WHERE url LIKE ?;"
##            )
##        params = (url,)
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return (query,params)
#__________________________________________________________________
#
def DELETE_TOMBSTONED(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            ' DELETE FROM favorites '
            ' WHERE '
            ' date_modified < ? '
            ' and '
            ' is_deleted = 1 '
            ' ; '
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
#db_conn.execute("select CAST(strftime('%s') as INT)").fetchall()
def GET_FAV_UUID(FAV_DB_VERSION):
    #FAV_DB_VERSION_CURRENT
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " SELECT "
            " * "
            " FROM favorites "
            " WHERE "
            " uuid = ? "
            " ; "
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_FAV_URL(FAV_DB_VERSION):
    #FAV_DB_VERSION_CURRENT
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " SELECT "
            " * "
            " FROM favorites "
            " WHERE url LIKE ?;"
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def INSERT_FAV(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:       
        query = (
            "INSERT INTO favorites ("
             "  name "   #1
             "  , url "  #2
             "  , mode " #3
             "  , image "       #4
             "  , description " #5
             "  , camsite "     #6
             "  , binary_image "    #7
             "  , date_modified  "  #8
             "  , uuid  "           #9
             " ) "
             "VALUES (?,?,? ,?,?,? ,?,?,?)"
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query

#__________________________________________________________________
#
def MAIN_TABLE_STRING(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            ##" id INTEGER NOT NULL"
            " name "
            ", url, mode, image"
            " , description TEXT DEFAULT ''"
            " , camsite INTEGER DEFAULT 0 "
            " , binary_image TEXT DEFAULT ''"
            " , uuid	     TEXT NOT NULL unique "
            " , date_modified	REAL NOT NULL"
            " , is_deleted INTEGER NOT NULL DEFAULT 0"
            ##" , PRIMARY KEY(\"id\" AUTOINCREMENT)"
            )
    elif FAV_DB_VERSION == FAV_DB_VERSION_1:
        query = (
            " id INTEGER PRIMARY KEY, name, url, mode, image"
            " , description TEXT DEFAULT '' "
            " , camsite INTEGER DEFAULT NULL "
            )
    elif FAV_DB_VERSION == FAV_DB_VERSION_2:
        query = (
            " id INTEGER PRIMARY KEY, name, url, mode, image"
            " , description TEXT DEFAULT ''"
            " , camsite INTEGER DEFAULT NULL"
            " , binary_image TEXT DEFAULT ''"
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_DB_UUID(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = "select uuid from favorites_meta"
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_MAX_ROWID(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = "select ifnull(max(rowid),?) as max_rowid from favorites"
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_MAX_MODIFIED_IN_IDRANGE(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " SELECT "
            "   max(date_modified) "
            " from favorites "
            " indexed by 'index_favorites_modified-rowid' "
            " WHERE "
            "   rowid >= ? "
            " AND "
            "   rowid <= ? "
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def GET_RANDOM_NOT_CAM_FAVORITE(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " select rowid "
            " ,* "
            " from favorites  "
            ' indexed by "index_favorites_camsite-isdeleted" '
            " where  camsite = 0 "
            " AND is_deleted = 0 "
            " order by random() "
            " limit 1 ; "
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query

#__________________________________________________________________
#
def GET_DB_REPL_VECTOR(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " SELECT "
            "    Local_db_repl_id_highwater "
            "   , local_db_date_modified_highwater "
            "   , full_repl "
            "   , id_range_start "
            "   , id_range_end "
            " FROM "
            "    favorites_replication "
            " WHERE "
            "    remote_db_uuid = ? "
            "   AND "
            "    id_range_start = ? "
            "   AND "
            "    id_range_end = ? "
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query        
#__________________________________________________________________
#
def INIT_DB_REPL_VECTOR(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " INSERT INTO "
            "    favorites_replication  "
            " ( "
            " remote_db_uuid " 
            " , local_db_repl_id_highwater "
            " , local_db_date_modified_highwater "
            " , full_repl "
            " , id_range_start "
            " , id_range_end "
            " , date_modified "
            " )  "
            " VALUES ( ?, ?, ?, ?, ?, ?, CAST(strftime('%s') as INT)  )  "
            " ; "
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query  
#__________________________________________________________________
#
def WRITE_DB_REPL_VECTOR(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
        " UPDATE "
        "    favorites_replication "
        " SET "
        "   local_db_repl_id_highwater = ? "
        "   , local_db_date_modified_highwater = ? "
        "   , full_repl = ? "       
        "   , date_modified = CAST(strftime('%s') as INT) "
        " WHERE "
        "    remote_db_uuid = ? "
        "   AND "
        "    id_range_start = ? "
        "   AND "
        "    id_range_end = ? "
        )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query  
#__________________________________________________________________
#
def GET_DATA_TO_REPLICATE(FAV_DB_VERSION
                            , id_highwater
                            , date_modified_highwater
                            , id_range_start
                            , id_range_end
                          ):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
    ##        " EXPLAIN QUERY PLAN  "
            " SELECT "
            "   name "            #1
            " , url "             #2 
            " , mode "            #3
            " , image "           #4
            " , description "     #5
            " , camsite "         #6
            " , binary_image "    #7
            " , is_deleted "      #8
            " , date_modified "   #9
            " , uuid "            #10
            " , rowid "           #11
            " , 1 as dummy_for_insert1 "   #12 #extra copy of this so that insert/update input params can be the same
            " FROM favorites "
            ' indexed by "index_favorites_modified-rowid" '
            " WHERE ("
            "    rowid >= ? "
            "    AND "
            "    rowid >= ? "
            "    AND "
            "    rowid <= ? "
            "    AND "
            "    date_modified > ? "
##            " AND UUID='91fdeb98-a6dd-4fe8-a601-c491ec432c64'"
            " ) "
##            " limit 10 "
            )
        params = (
            int(id_highwater)
            ,
            int(id_range_start)
            ,
            int(id_range_end)
            ,
            float(date_modified_highwater)
            ,
            )
    elif FAV_DB_VERSION == FAV_DB_VERSION_1:
        query = (
            " SELECT "
            "   name "                   #1
            " , url "                    #2
            " , mode "                   #3
            " , image "                  #4  
            " , description "            #5
            " , camsite "                #6
            " , binary_image "           #7
            " , 0 as is_deleted "        #8
            " , NULL as date_modified "  #9
            " , NULL as uuid "           #10
            " , 666 as rowid "           #11
            " , 1 as dummy_for_insert1 " #12
            " FROM favorites "
##            " LIMIT 5 "    #during dev
            )
        params = []
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return (query, params)
#__________________________________________________________________
#
def INSERT_FAVORITES(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " insert into favorites " 
            " ( "
            " name, url , mode "
            " , image, description , camsite"

            " , binary_image "

            " , is_deleted "
            " , date_modified"
            " , uuid "
            " ) "
            " select "
            "  ?,?,? "  #1-3
            " ,?,?,? "  #4-6
            " ,? "    #bin iamge
            " , ? " 
            ",?,? "  #8-10
            " where exists(select (? AND ?) ) " #? AND ? are just there to use up ? params
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query
#__________________________________________________________________
#
def UPDATE_FAVORITES(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            " update favorites " 
            " set name=? "
            " ,    url=? "
            " ,    mode=? "
            " ,    image=? "
            " ,    description=? "
            " ,    camsite=? "
            " ,    binary_image=? "
            " ,    is_deleted=? "
            " ,    date_modified=? "
            " where "
            "    uuid = ?        "
            "    and ( ? and ?) " #? AND ? are just there to use up ? params
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)
    return query            
#__________________________________________________________________
#
def DB_SCHEMA_STRING(FAV_DB_VERSION):
    if FAV_DB_VERSION == FAV_DB_VERSION_3:
        query = (
            "BEGIN TRANSACTION;"
            "CREATE TABLE IF NOT EXISTS favorites ("
            )
        query += MAIN_TABLE_STRING(FAV_DB_VERSION)
        query += (
            ");"
            " COMMIT;"
            )

##        query += (
##            " DROP TRIGGER if exists AutoGenerateGUID	; "
##            " CREATE TRIGGER AutoGenerateGUID "
##            " AFTER INSERT ON favorites "
##            " FOR EACH ROW "
##            " WHEN (NEW.uuid IS NULL) "
##            " BEGIN "
##            "    UPDATE favorites SET uuid = ("
##            )
##        query += CREATE_UUID_STRING 
##        query += (
##            ") WHERE rowid = NEW.rowid; "
##            " END; "

        ## indexes below seem to be fastest...so far            
        query += (
##            ' CREATE INDEX if not exists "index_favorites_modified" ON "favorites" ('
##            '	"date_modified"	ASC '
##            ' ); '

            ' CREATE INDEX if not exists "index_favorites_modified-rowid" ON "favorites" ( '
            ' 	"date_modified"	ASC '
            ' 	,"rowid"	ASC '
            ' ); '

            ' CREATE INDEX if not exists "index_favorites_uuid" ON "favorites" ( '
            '	"uuid"	ASC '
            ' ); '

            ' CREATE INDEX if not exists "index_favorites_camsite-isdeleted" ON "favorites" ( '
            ' 	"camsite"	ASC,  '
            ' 	"is_deleted"	ASC '
            ' ); '
            
            ' PRAGMA optimize; ' #supposed to do this after creating an inex

            ' ANALYZE; '
            
##            ' ANALYZE sqlite_schema; ' #supposed to do this after creating an inex
            
            )

        query += (
            " CREATE TABLE IF NOT EXISTS favorites_meta (	uuid TEXT ); "
            " insert into favorites_meta (uuid) "
            )
        query += (
            CREATE_UUID_STRING
            )
        query += (
            " WHERE NOT EXISTS  (SELECT 1 FROM favorites_meta WHERE  UUID LIKE '%'  )"
            ";"
            )

        query += (
            ' CREATE INDEX IF NOT EXISTS '
            ' "index_favorites_modified-isdeleted" '
            ' ON "favorites" ( '
            '  	"date_modified"	DESC '
            '   , "is_deleted"	ASC  '
            ' ) '
            ' ; '
            )

        query += (
            " CREATE TABLE IF NOT EXISTS favorites_replication ("
            "   remote_db_uuid TEXT"
            " , local_db_repl_id_highwater INT DEFAULT 0"
            " , local_db_date_modified_highwater REAL DEFAULT 0"
            " , full_repl INT DEFAULT 0"
            " , id_range_start INT DEFAULT 0"
            " , id_range_end INT DEFAULT 0 "
            " , date_modified REAL DEFAULT 0 "
            " );"
        )

        query += (
            ' DROP TRIGGER IF EXISTS "main"."trigger_favorites_UPDATE_before"; '
            " CREATE TRIGGER if not exists trigger_favorites_UPDATE_before "
            " BEFORE update ON favorites "
            " FOR EACH ROW "
            " BEGIN  "
            " 	SELECT "
            " 	    RAISE(FAIL, 'new name may not be blank') "
            " 	WHERE "
            " 	    IFNULL(NEW.\"name\",'') == ''; "
            " 	SELECT  "
##            " 		RAISE(IGNORE) /*null must not be below or else IGNORE fails */  "
            " 		RAISE(ABORT, 'duplicate information') "
##            ' --RAISE(ABORT, (select cast(NEW."mode" as str ) + cast(old."mode" as str )         ) ) -- not avail on current release of db browser '
            " 	WHERE EXISTS ( " 
            "       SELECT 1 "
            "       WHERE ( "
            '                               CAST(NEW."mode" AS INT) == CAST(OLD."mode" AS INT) '
            '       AND                                  NEW."name" == OLD."name" '
            '       AND                                   NEW."url" == OLD."url" '
            '       AND                                 NEW."image" == OLD."image" '
            '       AND              IFNULL(NEW."description",\'\') == IFNULL(OLD."description",\'\') \n'
            '       AND             IFNULL(NEW."binary_image",\'\') == IFNULL(OLD."binary_image",\'\') \n'
            '       AND                                  NEW."uuid" == OLD."uuid" '
            '       AND               CAST(NEW."is_deleted" AS INT) == CAST(OLD."is_deleted" AS INT) '
            '       AND        CAST(ifnull(NEW."camsite",0) AS INT) == CAST(ifnull(OLD."camsite",0) AS INT) '
            '       ) \n'
            '       OR    CAST(ifnull(NEW.date_modified,0) AS INT)  <  CAST(ifnull(OLD.date_modified,0) AS INT) '
            "       ); "
##            "   UPDATE favorites "
##            "   SET date_modified = CAST(strftime('%s') as INT) /*tested to be UTC */ "
##            "       WHERE rowid = NEW.rowid; "
            "END; "
            )

        query += (
            " DROP TRIGGER IF EXISTS \"main\".\"trigger_favorites_INSERT_before\"; "
            " CREATE TRIGGER trigger_favorites_INSERT_before "
            " BEFORE INSERT ON favorites "
            " FOR EACH ROW "
            " BEGIN  "
            "	SELECT  "
            "		/*RAISE(IGNORE) */ "
            "		RAISE(ABORT,'UNIQUE constraint failed: favorites.uuid') "
            "	WHERE EXISTS (  "
            "		SELECT  "
            "			1 "
            "		FROM  "
            "			favorites as f  "
            "		WHERE "
            "			NEW.\"uuid\" == f.\"uuid\"  "
            "	        ); "
            " END; "
            )
##        query += (
##            " CREATE TRIGGER trigger_favorites_UPDATE_after "
##            " AFTER update ON favorites "
##            " FOR EACH ROW "
##            " --WHEN (NEW.date_modified IS NULL) "
##            " BEGIN  "
##            " 	insert into repl_table "
##            " 	(  "
##            " 		record_uuid "
##            " 		, owner_uuid "
##            " 		, replica_uuid "
##            " 		, date_modified "
##            " 	) "
##            " 		select  "
##            " 			NEW.uuid --as record_uuid "
##            " 			, fm.uuid --as owner_uuid "
##            " 			, fr.remote_db_uuid --as replica_uuid "
##            " 			, CAST(strftime('%s') as INT) "
##            " --		from favorites as f "
##            " --		left join favorites_meta as fm "
##            " 		from favorites_meta as fm "
##            " 		left join favorites_replication as fr "
##            " 		where not exists ( select  "
##            " 			NEW.uuid --as record_uuid "
##            " 			, fm.uuid --as owner_uuid "
##            " 			, fr.remote_db_uuid --as replica_uuid "
##            " 			from repl_table "
##            " 			where repl_table.dirty = 1 "
##            " 			AND repl_table.record_uuid = NEW.uuid "
##            " 			AND repl_table.owner_uuid = fm.uuid "
##            " 			AND repl_table.replica_uuid = fr.remote_db_uuid "
##            " 			); END; "
##        )
        
        query += (
            "PRAGMA user_version = {};".format(FAV_DB_VERSION)
            )
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)

    return query
    
#__________________________________________________________________
#
def UPGRADE_DB_STRING(NEW_FAV_DB_VERSION, OLD_FAV_DB_VERSION):
    
    if NEW_FAV_DB_VERSION == FAV_DB_VERSION_3:

        query = ""

        query += (
            "DROP TABLE IF EXISTS favorites_bak;"
            "DROP TABLE IF EXISTS favorites_new;"
            "CREATE TABLE favorites_new ("
            )
        query += MAIN_TABLE_STRING(NEW_FAV_DB_VERSION)
        
        query += (
            ");"
            )

        if OLD_FAV_DB_VERSION < FAV_DB_VERSION_3:
            #remove this constraints so that AutoGenerateGUID can work
            # sqlite can only re-add a constraint by completly
            #    re-importing the data to a new table
            query = query.replace(
                " , uuid	     TEXT NOT NULL unique "
               ," , uuid	     TEXT          unique "
                )


        #
        # use AutoGenerateGUID  only during data import
        #
        query += (
            " DROP TRIGGER if exists  AutoGenerateGUID ; "
            " CREATE TRIGGER AutoGenerateGUID "
            " AFTER INSERT ON favorites_new "
            " FOR EACH ROW "
            " WHEN (NEW.uuid IS NULL) "
            " BEGIN "
            "    UPDATE favorites_new "
            "        SET uuid = ( "
            )
        query += CREATE_UUID_STRING 
        query += (
            "                   ) "
            "                "
            "    WHERE rowid = NEW.rowid; "
            " END ;"
        )


        #actual import happens here
        if OLD_FAV_DB_VERSION == FAV_DB_VERSION_3:
            query += (
                "INSERT INTO favorites_new (name, url, mode, image, description, camsite, binary_image, uuid, date_modified, is_deleted) "
                "                    SELECT name, url, mode, image, description, ifnull(camsite,0), binary_image, uuid, date_modified, is_deleted  FROM favorites;"
            )
        elif OLD_FAV_DB_VERSION == FAV_DB_VERSION_2: #import available v2 data into a v3 table
            Log('here')
            query += (
                "INSERT INTO favorites_new (name, url, mode, image, description, camsite, binary_image, date_modified    ) "
                "                    SELECT name, url, mode, image, description, ifnull(camsite,0) , binary_image, {}                FROM favorites ; ".format(UTC_timestamp())
            )
            ##
            ##note: a date_modified value is inserted here using format()  !!!
            ##
        elif OLD_FAV_DB_VERSION == 0:
            Log("database does not exist; nothing to import", C.LOGWARNING)
        else:
            raise NotImplementedError(__name__,NEW_FAV_DB_VERSION, OLD_FAV_DB_VERSION)

        if OLD_FAV_DB_VERSION < FAV_DB_VERSION_3:
            #temporarily remove this constraints so that AutoGenerateGUID can work
            query += (
                " PRAGMA ignore_check_constraints=off; "
                )
            
        query += (
            ' CREATE TABLE if not exists favorites ( name ) ; ' #in case ths is run on a new DB
            " ALTER TABLE favorites     RENAME TO favorites_bak;"
            " ALTER TABLE favorites_new RENAME TO favorites;"
            " DROP TRIGGER if exists  AutoGenerateGUID ; "
            )

        #
        # use AutoGenerateGUID  only during data import
        #        
##        query += (
##            " CREATE TRIGGER AutoGenerateGUID "
##            " AFTER INSERT ON favorites "
##            " FOR EACH ROW "
##            " WHEN (NEW.uuid IS NULL) "
##            " BEGIN "
##            "    UPDATE favorites SET uuid = ( "
##            )
##        query += CREATE_UUID_STRING 
##        query += (
##            ") WHERE rowid = NEW.rowid; "
##            " END ;"
##            )
        

        query += (
##            ' DROP INDEX if exists "index_favorites_modified"  ;'
##            ' CREATE INDEX "index_favorites_modified" ON "favorites" ('
##            '	"date_modified"	ASC '
##            '); '

            ' DROP INDEX if exists "index_favorites_camsite-isdeleted"  ;'
            ' CREATE INDEX "index_favorites_camsite-isdeleted" ON "favorites" ( '
            ' 	"camsite"	ASC,  '
            ' 	"is_deleted"	ASC '
            ' ); '
            
            ' DROP INDEX if exists "index_favorites_uuid"  ;'
            ' CREATE INDEX "index_favorites_uuid" ON "favorites" ( '
            '	"uuid"	ASC '
            ' ); '
            )

        query += (
            "PRAGMA user_version = {};".format(NEW_FAV_DB_VERSION)
                ##
                ##note: a value is inserted here using format()  !!!
                ##
            )

    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)

    return query

#__________________________________________________________________
#
def LIST_KEYWORD(KEYWORD_DB_VERSION):
    if KEYWORD_DB_VERSION == KEYWORD_DB_VERSION_3:       
        query = (
            " SELECT "
            " keyword "
            " FROM "
            " keywords "
            " ORDER BY "
            " sequence ;"
            )
    else:
        raise NotImplementedError(__name__,KEYWORD_DB_VERSION)
    return query
#__________________________________________________________________
#
def INSERT_KEYWORD(KEYWORD_DB_VERSION):
    if KEYWORD_DB_VERSION == KEYWORD_DB_VERSION_3:       
        query = (
             " INSERT INTO keywords ( "
             " keyword "           #1
             " , sequence "         #2
             " , date_modified  "  #
             " , uuid  "           #
             " ) "
             " VALUES (?,?,?,?) ; "
            )
    else:
        raise NotImplementedError(__name__,KEYWORD_DB_VERSION)
    return query
#__________________________________________________________________
#
def KEYWORD_SCHEMA_STRING(KEYWORD_DB_VERSION, OLD_DB_VERSION):
    if KEYWORD_DB_VERSION == KEYWORD_DB_VERSION_3:
        query = ""

        query += (
##            "DROP TABLE IF EXISTS keywords_bak;"
##            "DROP TABLE IF EXISTS keywords_new;"
##            "CREATE TABLE keywords_new ("
            "CREATE TABLE if not exists keywords ("
            )
        query += (
            "   keyword                   TEXT UNIQUE"
            " , sequence            INTEGER DEFAULT 0"
            " , uuid	                  TEXT UNIQUE"
            " , date_modified	       REAL DEFAULT 0"
            " , is_deleted INTEGER NOT NULL DEFAULT 0"
            )
        query += (
            ");"
            )

##        query += (
##            ' CREATE TABLE if not exists keywords ( placeholder ) ; ' #in case ths is run on a new DB
##            " ALTER TABLE keywords     RENAME TO keywords_bak;"
##            " ALTER TABLE keywords_new RENAME TO keywords;"
##            )
        
        query += (
            "PRAGMA user_version = {};".format(KEYWORD_DB_VERSION)
                ##
                ##note: a value is inserted here using format()  !!!
                ##
            )
        
    else:
        raise NotImplementedError(__name__,FAV_DB_VERSION)

    return query
    
#__________________________________________________________________
#

