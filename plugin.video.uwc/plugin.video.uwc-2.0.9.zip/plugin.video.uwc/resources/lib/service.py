import json
import random
import threading
import traceback
import xbmc

import constants as C
from constants import reload

import downloader
import utils
import webcam_db
import reboot_detection
from utils import Log,LogR,Sleep
from utils import get_setting as GetSetting

import downloadServer
    
monitor = xbmc.Monitor() #behaves stragely if kodi closes too soon?


#__________________________________________________________________
#
def Sleep_Start(sleep_time):
##    xbmc.log("Begin {}s sleep for {}:{}".format(
##            sleep_time
##            , threading.current_thread().name
##            , threading.current_thread().ident
##            )
##            ,xbmc.LOGINFO)
    Log("Begin {}s sleep for {}:{}".format(
            sleep_time
            , threading.current_thread().name
            , threading.current_thread().ident
            )
        ,stacklevel=3
        )
#__________________________________________________________________
#
def Sleep_End(sleep_time):
##    xbmc.log("End {}s sleep for {}:{}".format(
##            sleep_time
##            , threading.current_thread().name
##            , threading.current_thread().ident
##            )
##            ,xbmc.LOGINFO)
    Log("End {}s sleep for {}:{}".format(
            sleep_time
            , threading.current_thread().name
            , threading.current_thread().ident
            )
        ,stacklevel=3
        )
#__________________________________________________________________________
#
class EndingException(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)
#__________________________________________________________________
#
def recording_service(stop_event):
    try:
        while True:
            sleep_time = max(300,min(1, GetSetting("min_service_interval", int)))
            Sleep_Start(sleep_time)
##            Sleep(sleep_time*1000)
            monitor.waitForAbort(sleep_time) 
            Sleep_End(sleep_time)
            if monitor.abortRequested():
                raise EndingException("{} ending due to abort".format(
                                threading.current_thread().name
                                )
                            )
            if stop_event.is_set():
                raise EndingException("{} ending due to stop_event".format(
                    threading.current_thread().name))
            if GetSetting("enable_recording_service", bool):
                downloader.scan_and_start_db()
        Log('abortrequested')
    except EndingException as ex:
        Log(ex.value)
    except:
        traceback.print_exc()
    finally:
        stop_event.set()

#__________________________________________________________________
#
def download_service(stop_event):

    try:
        download_proxy = None
        monitor.waitForAbort(1) 
        while not monitor.abortRequested():
            if stop_event.is_set():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_download_service", bool):
                if not download_proxy:
                    Log("starting download_proxy", C.LOGNONE)
##                    Log("reloading downloadServer during dev", C.LOGERROR)
##                    reload(downloadServer) #reload during development so that I dont have to restart program
                    download_proxy = downloadServer.StartListening()
                else:
                    if download_proxy._BaseServer__shutdown_request:
                        Log('internal download_proxy forcestop')
##                        download_proxy.server_close()
                        Log('internal download_proxy server_close')
##                        download_proxy.socket.close()
                        Log('internal download_proxy close',C.LOGWARNING)
                        download_proxy = None
##                    if GetSetting("keepalive_download_service", bool):
##                        active_threads = utils.postHtml("http://localhost:{}/".format(GetSetting("download_server_port_current", int))
##                                   ,sent_data= json.dumps({
##                                      downloader.ATTRIB_cmd: downloader.CMD_list
##                                       })
##                                   ,headers={
##                                       'Content-Type': 'application/json'
##                                       }
##                                   )
##                        Log(repr(active_threads))
                        
                    pass
            else:
                Log('download_proxy will be stopped if it has been started')
                if download_proxy or download_proxy._BaseServer__shutdown_request:
##                    download_proxy.shutdown()
##                    download_proxy.server_close()
##                    download_proxy.socket.close()
##                    download_proxy = None
##                    del download_proxy
                    Log('download_proxy stopped',C.LOGWARNING)
            sleep_time = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
            if sleep_time < 1: sleep_time = 1
            Sleep_Start(sleep_time)
##            Sleep(sleep_time*1000)
            monitor.waitForAbort(sleep_time) 
            Sleep_End(sleep_time)

        Log('abortrequested')
    except EndingException as ex:
        Log(ex.value,C.LOGINFO)
    except SystemExit as ex:
        Log('SystemExit',C.LOGERROR)
        traceback.print_exc()
    except:
        traceback.print_exc()
    finally:
        if download_proxy:
            Log('Finally download_proxy stoppING')
            download_proxy.shutdown()
            download_proxy.socket.close()
            download_proxy = None
        Log('Finally download_proxy stopped')
        stop_event.set()

#__________________________________________________________________
#
def link_crawler(stop_event):
    sleep_time = int(GetSetting("min_service_interval", int)/2)
    try:
        Sleep_Start(sleep_time)
##        Sleep(sleep_time*1000)
        monitor.waitForAbort(2) 
        Sleep_End(sleep_time)
        while True:
            if stop_event.is_set():
                raise EndingException("{} ending due to stop_event".format(
                                        threading.current_thread().name
                                        )
                                      )
            if monitor.abortRequested():
                raise EndingException("{} ending due to abortRequested".format(
                                        threading.current_thread().ident
                                        )
                                      )
            if GetSetting("enable_link_crawler", bool):
                webcam_db.clear_webcam_db()
                webcam_db.fill_webcam_db()

            min_service_interval = GetSetting("min_service_interval", int)
            service_periodic_interval = GetSetting("service_periodic_interval", int)
            sleeptime1 = service_periodic_interval * random.random() * 2
            sleep_time = int(max(min_service_interval,sleeptime1))
            Sleep_Start(sleep_time)
##            Sleep(sleep_time*1000)
            monitor.waitForAbort(sleep_time) 
            Sleep_End(sleep_time)

        Log('abortrequested')
    except SystemExit as ex: 
        Log('SystemExit',C.LOGWARNING)
        traceback.print_exc()
    except EndingException as ex:
        Log(ex.value)
    except:
        traceback.print_exc()
    finally:
        stop_event.set()
#__________________________________________________________________
#
try:
# Because of unresolved issue:
#   https://github.com/xbmc/xbmc/issues/18191
# Kodi will not return accurate value for abortRequested
#   
##    LogR(monitor)
##    LogR(dir(monitor))
##    LogR(monitor.abortRequested())
##    LogR(monitor.abortRequested)

##    Log(__name__)
    if __name__ != '__main__':
##        xbmc.log(repr(__name__),xbmc.LOGERROR)
        traceback.print_stack()
        exit(0)

##    xbmc.log("a",xbmc.LOGERROR)    
    C.DEBUG = GetSetting('debug')
    threading.current_thread().name = C.addon_id+".service"
##    LogR(threading.current_thread().ident,xbmc.LOGERROR)
    LogR(threading.current_thread().ident)
##    xbmc.log("a",xbmc.LOGERROR)
    proxy_thread_recording_service = None
    recording_service_stop_event = threading.Event()

    proxy_thread_download_service = None    
    download_service_stop_event = threading.Event()

    proxy_thread_crawler = None
    crawler_stop_event = threading.Event()

    proxy_reboot_required_detection = None
    reboot_required_detection_stop_event = threading.Event()

    while not monitor.abortRequested():

##        LogR(Get_Setting_Val('network.usehttpproxy'))

        # start thread for enable_download_service service
        if GetSetting("enable_download_service", bool):
            try:
                if not proxy_thread_download_service: # start thread
                    download_service_stop_event.clear()
                    proxy_thread_download_service = threading.Thread(
                        target=download_service
                        ,args=(download_service_stop_event,)
                        ,name=C.addon_id+".download_service"
                        )
##                    proxy_thread_download_service.daemon = True
                    proxy_thread_download_service.start()

                    Log("proxy_thread_download_service starting id {}".format(
                            proxy_thread_download_service.ident)
                             )
                else:
                    pass
            except:
                traceback.print_exc()
        else:
            Log("proxy_thread_download_service=false. Will turn off if active")
            if proxy_thread_download_service:
                download_service_stop_event.set()
                proxy_thread_download_service = None

                
        # start thread for link_crawler service
        if GetSetting("enable_link_crawler", bool):
            if not proxy_thread_crawler: 
                crawler_stop_event.clear()
                proxy_thread_crawler = threading.Thread(
                    target=link_crawler
                    ,args=(crawler_stop_event,)
                    ,name=C.addon_id+".link_crawler"
                    )
##                proxy_thread_crawler.daemon = True
                proxy_thread_crawler.start()
                Log("enable_link_crawler starting id {}".format(
                            proxy_thread_crawler.ident
                        )
                    )
            else:
                Log("enable_link_crawler is already alive")
                pass
        else:
            Log("enable_link_crawler=false. Will turn off if active")
            if proxy_thread_crawler:
                crawler_stop_event.set()
                proxy_thread_crawler = None


        # start thread for reboot_required_detection
        if GetSetting("reboot_required_detection", bool):
            try:        
                if not proxy_reboot_required_detection: 
                    reboot_required_detection_stop_event.clear()
                    proxy_reboot_required_detection = threading.Thread(
                        target=network_is_online
                        ,args=(reboot_required_detection_stop_event,)
                        ,name=C.addon_id+".reboot_required_detection"
                        )
##                    proxy_reboot_required_detection.daemon = True
                    proxy_reboot_required_detection.start()
                    LogR(proxy_reboot_required_detection.ident)
                else:
                    pass
            except:
                traceback.print_exc()
        else:
            if proxy_reboot_required_detection:
                reboot_required_detection_stop_event.set()
                proxy_reboot_required_detection = None
                

        # start thread for enable_recording_service service
        if GetSetting("enable_recording_service", bool): # and GetSetting("enable_link_crawler", bool):
            try:
                if not proxy_thread_recording_service:
                    recording_service_stop_event.clear()
                    proxy_thread_recording_service = threading.Thread(
                        target=recording_service
                        ,args=(recording_service_stop_event,)
                        ,name=C.addon_id+".recording_service"
                        )
##                    proxy_thread_recording_service.daemon = True
                    proxy_thread_recording_service.start()
                    LogR(proxy_thread_recording_service.ident)
                else:
                    pass
            except:
                traceback.print_exc()
        else:
            if proxy_thread_recording_service:
                recording_service_stop_event.set()
                proxy_thread_recording_service = None


        ## sleep then ... do some work
        sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
        sleep_time = max(1,sleeptime,300)
##        Sleep_Start(sleep_time)
        monitor.waitForAbort(sleep_time) 
##        Sleep_End(sleep_time)

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = GetSetting('debug')

    utils.global_cache.close()
    Log('abortrequested')
##    exit(0)
except:
    traceback.print_exc()
finally:
    Log("service finally")
    if proxy_thread_crawler and crawler_stop_event:
        crawler_stop_event.set()
        proxy_thread_crawler.join()
        Log('proxy_thread_crawler joined')
    if proxy_thread_recording_service and recording_service_stop_event:
        recording_service_stop_event.set()
        proxy_thread_recording_service.join()
        Log('proxy_thread_recording_service joined')
    if proxy_reboot_required_detection and reboot_required_detection_stop_event:
        reboot_required_detection_stop_event.set()
        proxy_reboot_required_detection.join()
        Log('proxy_reboot_required_detection joined')
    if proxy_thread_download_service and download_service_stop_event:
        Log("proxy_thread_download_service")
        download_service_stop_event.set()
        proxy_thread_download_service.join()
        Log('proxy_thread_download_service joined')
    Log("service should be stopped",C.LOGERROR)        
    del monitor
    
##    import gc
##    gc.collect()
##    loop_interruptor = 0
##    found_obj = None
##    object_type = 'thread'
##    for obj in gc.get_objects():
##        loop_interruptor += 1
##        if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS: # pause to allow other stuff
##            Sleep(C.GC_SEARCHLOOP_PAUSE) # pause to allow other stuff
##            loop_interruptor = 0        
##        if '__class__' in repr(dir(obj)) :
##            pass
##            Log("{}_obj='{}'".format('',repr(obj)), C.LOGNONE)
            
##            if (object_type in repr(obj.__class__)):
##                Log("{}_obj='{}'".format(object_type,repr(obj)), C.LOGNONE)
##
##                if ('playF4mLink' in repr(obj) ):
##                    Log("{}_obj='{}'".format(object_type,repr(obj)), C.LOGNONE)
##                    LogR(gc.get_referents(obj))
##                
##            if ('server' in repr(obj.__class__)):
##                Log("{}_obj='{}'".format(object_type,repr(obj)), C.LOGNONE)
##                found_obj = obj
##            if ('http' in repr(obj.__class__)):
##                Log("{}_obj='{}'".format(object_type,repr(obj)), C.LOGNONE)
##                found_obj = obj
##    LogR(gc.garbage)
    
##                break
##    return found_obj


#__________________________________________________________________
#
