#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import base64
import datetime
import errno
from collections import OrderedDict
import os
import random
import re
import tempfile
import sqlite3
import sys
import time
import traceback
from uuid import uuid4
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import constants as C
from constants import urlencode
from constants import urlparse

import queries as Q

import utils
from utils import Log,LogR
from utils import get_setting as GetSetting

import webcam_db
import downloader

from sites.chaturbate import clean_database as chaturbate_clean
from sites.cam4 import clean_database as cam4_clean
from sites.streamate import clean_database as streamate_clean
from sites.naked import clean_database as naked_clean
from sites.myfreecams import clean_database as mfc_clean
from sites.myfreecams import Camgirl_Generic_Image as mfc_generic_image

mfc_PLAY_MODE = str(int(C.MAIN_MODE_myfreecams) + C.MODE_PLAY_OFFSET)

FAV_DB_VERSION_1 = Q.FAV_DB_VERSION_1
FAV_DB_VERSION_2 = Q.FAV_DB_VERSION_2
FAV_DB_VERSION_3 = Q.FAV_DB_VERSION_3
FAV_DB_VERSION_4 = Q.FAV_DB_VERSION_4
FAV_DB_VERSION_CURRENT = Q.FAV_DB_VERSION_4

favoritesdb = C.favoritesdb

try:  FAV_LIST_LIMIT = GetSetting("FAV_LIST_LIMIT", int)
except:  FAV_LIST_LIMIT = 200
try: FAV_LIST_FRACTION = GetSetting("FAV_LIST_FRACTION", int)
except:  FAV_LIST_FRACTION = 20 # 1/5th chance of being shown after LIMIT is reached


#extend connection to track database filespec
class my_conn(sqlite3.Connection):
    db_filespec = ""
    def __init__(self, *args, **kwargs):
        if len(args) == 1:
            self.db_filespec = args[0]
        elif len(kwargs) > 1:
            self.db_filespec = kwargs['database']
        if C.PY2:
##            LogR((args, kwargs),C.LOGNONE)
            super(my_conn, self).__init__(*args, **kwargs)
        if C.PY3: super().__init__(*args, **kwargs)


favDB_conn = sqlite3.connect(favoritesdb, factory=my_conn)
favDB_conn.text_factory = str  #= sqlite3.Row #note: wild cards not work with sqlite3.Row factory
favDB_conn.row_factory = sqlite3.Row #note: wild cards not work with sqlite3.Row factory
##import mysql.connector as mariadb
##conn_params= {
##    "user" : "torrent",
##    "password" : "sK1()5@!Me",
##    "host" : "raid",
##    "database" : "kodi_favorites",
##    "port": 3307
##}; favDB_conn= mariadb.connect(**conn_params);
##favDB_cursor = favDB_conn.cursor()

#todo: add as configuration
BACKUP_COPIES = 5
DAYS_BETWEEN_BACKUPS = 7
ONE_DAY_TIMESTAMP = 86400.0
MIN_TOMBSTONE_DAYS = 30
ONE_DAY_TIMESTAMP = 86400.0
REPLICATION_NOTIFY_DURATION = 6000
MAX_ROWS = 22222
REPLICATION_PROGRESS_CALLBACKS = 2000 #queries will seem slow if this is too high
FULL_REPL_SUCCESS = 1
REPL_ID_HIGHWATER_INIT = 1

        
#__________________________________________________________________
#
def RefreshImages():
    chaturbate_clean(False)
    cam4_clean(False)
    naked_clean(False)
    mfc_clean(False)
    streamate_clean(False)
##    bongacams_clean(False)
#__________________________________________________________________
#
@C.url_dispatcher.register(C.REFRESH_CONTAINER_MODE)  
def RefreshContainter():
    webcam_db.clear_webcam_db( 1 ) # if manually refreshing, latest required, but 1 min should be good enough
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_IMPORT)
def Favorites_Import():

##    favorite_db_filepec = "\\\\raid.opscc.net\\web\\favorites.db"
#https://romanvm.github.io/Kodistubs/_autosummary/xbmcgui.html#xbmcgui.Dialog
    favorite_db_filepec = xbmcgui.Dialog().browse(
        type=1 #show and get file
        , heading = "Specify a file to import"
        , shares = '' #list drives and network shares
        , mask = 'favorites.db'
        )
    favorite_db_filepec = utils.Normalize_Filespec(favorite_db_filepec)
    LogR(favorite_db_filepec)
    
    remote_db_conn = sqlite3.connect(favorite_db_filepec, factory=my_conn)
    remote_db_conn.row_factory = sqlite3.Row # sqlite3.Row or None(tuple)-  Row 
    remote_cursor = remote_db_conn.cursor()

    local_db_conn = sqlite3.connect( C.favoritesdb , factory=my_conn)
    local_db_conn.row_factory = sqlite3.Row # sqlite3.Row or None(tuple)-  Row 
    local_cursor = local_db_conn.cursor()
    Create_Maintain_FavDB(local_db_conn) #do this in case schema changed

    Log('repl remote to local')
    r_to_l = SyncDB(remote_db_conn
                    ,remote_cursor
                    ,local_db_conn
                    ,local_cursor
                    ,import_only=True
                    ,save_repl_vector=False
                    )
    REPLICATION_NOTIFY_DURATION = 10000
    utils.Notify(
        msg=u"{} favorites imported to local db".format(
            r_to_l
            )
        , duration=REPLICATION_NOTIFY_DURATION
        )
    
#__________________________________________________________________
#
@C.url_dispatcher.register(
    C.FAVORITES_BACKUP
    ,['url']
)
def Favorites_Backup(filespec=None, number_of_copies=None, url=None):
    LogR(locals())
    import shutil
##    return

    if not filespec and url:
        filespec = url

##    import xbmcvfs
##    LogR((filespec,)
####         ,C.LOGNONE
##         )
##    if C.PY3:
##        LogR((xbmcvfs.makeLegalFilename(filespec),)
####             ,C.LOGNONE
##             )
##        LogR((xbmcvfs.translatePath(filespec),)
####             ,C.LOGNONE
##             )
##        LogR((xbmcvfs.validatePath(filespec),)
####             ,C.LOGNONE
##             )
##    if C.PY2:
##        LogR((xbmc.makeLegalFilename(filespec),)
####             ,C.LOGNONE
##             )
##        LogR((xbmc.translatePath(filespec),)
####             ,C.LOGNONE
##             )
##        LogR((xbmc.validatePath(filespec),)
####             ,C.LOGNONE
##             )
                
    filespec = utils.Normalize_Filespec(filespec)
    name = filespec.split(os.sep)[-1]
    folder = filespec[0: (len(filespec)-len(name)) ]
    folder = folder.rstrip(os.sep)

##    LogR((xbmcvfs.listdir(folder),),C.LOGNONE)
    LogR((folder,),C.LOGNONE)

    ext = name.split('.')[-1]
    name = name[0: (len(name)-len(ext)-len('.')) ]
    LogR((name,),C.LOGNONE)

    #delte works
    #xbmcvfs.delete('smb://torrent:password@192.168.10.49/web/tv/kodi.log') ##delete target
    
    pd = utils.Progress_Dialog(
        __name__,u"Backup up to {} copies...".format(number_of_copies)
        )
    try:

        for backup_number in range(number_of_copies,0,-1):
##            LogR(backup_number)
            newer_filespec = '.'.join ((
                (os.sep).join( (folder,name ))
                , str(backup_number)
                , ext
                ))
            older_filespec = '.'.join ((
                (os.sep).join( (folder,name ))
                , str(backup_number - 1)
                , ext
                ))

            try:
                msg = ("renaming {} to {}".format(
                    repr(older_filespec)
                    ,repr(newer_filespec)
                    ))
                pd.update(percent = int(backup_number),message = msg)

                LogR((older_filespec,newer_filespec),C.LOGNONE)

                #rename does not work on android
                if os.name == 'nt':
                    os.rename(older_filespec,newer_filespec)
                else:
    ##                xbmcvfs.rename(older_filespec,newer_filespec)
                    xbmcvfs.copy(older_filespec,newer_filespec)
                    xbmcvfs.delete(older_filespec)

            except OSError as e: #oserror instead of FileExistsError for PY2 compat

                LogR((e,errno.ENOENT),C.LOGNONE)
##                raise
            
                if C.PY2: errnum = e[0]
                if C.PY3:
                    errnum = e.errno
                    
                if errnum == errno.ENOENT:  #FileNotFoundError:
                    if backup_number <= 1:
                        msg = ("copied {} to {}".format(
                            repr(filespec)
                            ,repr(newer_filespec)
                            ))
                        Log(msg)
                        pd.update(percent = int(backup_number),message = msg)
                        shutil.copyfile(filespec, newer_filespec)
                        
                    else:
                        Log("can't backup {} to {} because {} does not exist".format(
                            repr(older_filespec)
                            ,repr(newer_filespec)
                            ,repr(older_filespec)
                            ))
                        pass
                elif errnum in [errno.EEXIST, 183]:  #FileExistsError:

                    msg = ("deleted {}".format(
                        repr(newer_filespec)
                        ))
                    Log(msg)
                    pd.update(percent = int(backup_number),message = msg)
                    os.remove(newer_filespec) ##delete target
                    
                    msg = ("renamed {} to {}".format(
                        repr(older_filespec)
                        ,repr(newer_filespec)
                        ))
                    Log(msg)
                    pd.update(percent = int(backup_number),message = msg)
                    os.rename(older_filespec,newer_filespec)

                else:
                    raise
            except Exception as e:
                LogR(e,C.LOGNONE)
                raise
    finally:
        pd = None

#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_SYNC,[],['keyword'])
def Favorites_Sync(keyword=False):
    force_full_replication=bool(keyword) #using 'keyword' as a param name to avoid other changes

    Log('todo sync ? move ? keywords to d different database ', C.LOGERROR)

##    C.DEBUG=True

    try:

        today = utils.UTC_timestamp()
        LogR(("for reference: today=", today)
    ##         ,C.LOGWARNING
             )
        LogR(("for reference: sqlite3.version_info:",sqlite3.version_info))
        
        remote_favorite_db_folder = GetSetting("remote_favorite_db_folder", str)
        if not remote_favorite_db_folder:
            if remote_favorite_db_folder in ['','None',u'',u'None',None]:
                try:
                    remote_favorite_db_folder = xbmcgui.Dialog().browse(0, "Specify a folder for remote", 'remote_favorite_db_folder', '', False, False)
                    C.addon.setSetting(id='remote_favorite_db_folder', value=remote_favorite_db_folder)
                    remote_favorite_db_folder = utils.Normalize_Filespec(remote_favorite_db_folder)
                    if not os.path.exists(remote_favorite_db_folder):
                        os.mkdir(remote_favorite_db_folder)
                except:
                    raise
        remote_favorite_db = remote_favorite_db_folder.rstrip(os.sep) + os.sep + 'favorites.db'
        remote_favorite_db = utils.Normalize_Filespec(remote_favorite_db)


##      favorites_backup
        try: 
            favorites_backup_datetime = GetSetting("favorites_backup_datetime", float)
        except:
            favorites_backup_datetime = 0.0
            C.this_addon.setSetting(id='favorites_backup_datetime', value=str(favorites_backup_datetime))
        option_backup = (favorites_backup_datetime + DAYS_BETWEEN_BACKUPS*ONE_DAY_TIMESTAMP) > today 
        force_backup = False
        if ( option_backup ):
                if C.PY2:
                    force_backup = xbmcgui.Dialog().yesno(
                            heading = u"Favorites Sync"
                            , line1 = u"Already backedup in the past 24 hours[CR][CR]Backup Again?"
                            , autoclose = REPLICATION_NOTIFY_DURATION//2
                            )
                if C.PY3:
                    force_backup = xbmcgui.Dialog().yesno(
                            heading = u"Favorites Sync"
                            , message= u"Already backedup in the past {} hours[CR][CR]Backup Again?".format(24*DAYS_BETWEEN_BACKUPS)
                            , autoclose = REPLICATION_NOTIFY_DURATION//2
                            , defaultbutton = xbmcgui.DLG_YESNO_NO_BTN #only in kodi 20+
                            )
                LogR(force_backup)
        if not(option_backup) or force_backup: #backup before anything
#don't backup remote any more 2025-09-03
##            Favorites_Backup(remote_favorite_db, number_of_copies=BACKUP_COPIES)

            Favorites_Backup(C.favoritesdb, number_of_copies=BACKUP_COPIES)
            C.this_addon.setSetting(id='favorites_backup_datetime', value=str(today))



##      favorites_sync
        try: 
            favorites_sync_datetime = GetSetting("favorites_sync_datetime", float)
        except:
            favorites_sync_datetime = 0.0
            C.this_addon.setSetting(id='favorites_sync_datetime', value=str(favorites_sync_datetime))

        if ( not C.DEBUG and (favorites_sync_datetime + ONE_DAY_TIMESTAMP) > today  ):
                if C.PY2:
                    result = xbmcgui.Dialog().yesno(
                            heading = u"Favorites Sync"
                            , line1 = u"Already synchronized in the past 24 hours[CR][CR]Sync Again?"
                            , autoclose = REPLICATION_NOTIFY_DURATION
                            )
                if C.PY3:
                    result = xbmcgui.Dialog().yesno(
                            heading = u"Favorites Sync"
                            , message= u"Already synchronized in the past 24 hours[CR][CR]Sync Again?"
                            , autoclose = REPLICATION_NOTIFY_DURATION
                            , defaultbutton = xbmcgui.DLG_YESNO_NO_BTN #only in kodi 20+
                            )
                if not result:
                    utils.notify("Cancelling sync")
                    return

        
        remote_db_conn = sqlite3.connect(remote_favorite_db , factory=my_conn)
        remote_db_conn.row_factory = sqlite3.Row # sqlite3.Row or None(tuple)-  Row 
    ##    remote_db_conn.text_factory = str # str does not do wildcards https://zetcode.com/python/sqlite3-connection-text-factory/
        remote_cursor = remote_db_conn.cursor()
        Create_Maintain_FavDB(remote_db_conn)

        local_db_conn = sqlite3.connect( C.favoritesdb , factory=my_conn)
        local_db_conn.row_factory = sqlite3.Row # sqlite3.Row or None(tuple)-  Row 
        local_cursor = local_db_conn.cursor()
        Create_Maintain_FavDB(local_db_conn) #do this in case schema changed

#__________________________________________________________________
# tombstone before replication to avoid extra inserts
        def TombStone(db_conn):
            tombstone_days = GetSetting('favorites_sync_tombstone', int)
            tombstone_days = max(tombstone_days, MIN_TOMBSTONE_DAYS)
            query = Q.DELETE_TOMBSTONED(FAV_DB_VERSION_CURRENT)
            params = ( (favorites_sync_datetime - (tombstone_days*ONE_DAY_TIMESTAMP)) ,  )
            Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
            result = db_conn.execute(query, params)
            Log(u"Tombstoned {} rows from db {}".format(
                db_conn.total_changes
                , repr(db_conn.db_filespec)
                )
    ##            , C.LOGWARNING
            )
            #db_conn.commit()
        #reopen these so that total_changes check can work
        f = local_db_conn.db_filespec 
        local_db_conn.close(); local_db_conn = sqlite3.connect(f, factory=my_conn)
        f = remote_db_conn.db_filespec
        remote_db_conn.close(); remote_db_conn = sqlite3.connect(f, factory=my_conn)
        #the actual tombstone
        TombStone(local_db_conn)
        TombStone(remote_db_conn)
        #reopen these so that total_changes check can work
        f = local_db_conn.db_filespec;
        local_db_conn.close();
        local_db_conn = sqlite3.connect(f, factory=my_conn);
        local_db_conn.row_factory = sqlite3.Row 
        local_cursor = local_db_conn.cursor()
        f = remote_db_conn.db_filespec;
        remote_db_conn.close();
        remote_db_conn = sqlite3.connect(f, factory=my_conn);
        remote_db_conn.row_factory = sqlite3.Row # sqlite3.Row or None(tuple)-  Row 
        remote_cursor = remote_db_conn.cursor()        
#__________________________________________________________________
#  replication starts
        Log('replicating local DB to remote...', C.LOGWARNING)
        l_to_r=r_to_l=0
        l_to_r = SyncDB(local_db_conn,local_cursor,remote_db_conn,remote_cursor,force_full_replication=force_full_replication)
        Log('repl remote to local')
        r_to_l = SyncDB(remote_db_conn,remote_cursor,local_db_conn,local_cursor,force_full_replication=force_full_replication)
        utils.Notify(
            header=u"{} changes replicated to remote".format(
                l_to_r
                )
            ,  msg=u"{} changes replicated to local".format(
                r_to_l
                )
            , duration=REPLICATION_NOTIFY_DURATION
            )
        C.this_addon.setSetting(id='favorites_sync_datetime', value=str(utils.UTC_timestamp()))
        Log("we get this far...we have synced successfully today", C.LOGWARNING)



    except:
        traceback.print_exc()
        utils.Notify(
            header= __name__ 
            , msg=u"Favorites replication error occured.[CR]Check logs for more information"
            , duration=REPLICATION_NOTIFY_DURATION
            )

#__________________________________________________________________
#    
def row_generator(
    local_cursor
    , local_db_repl_id_highwater #this value will be between range_start and range_end
    , local_db_date_modified_highwater
    , id_range_start
    , id_range_end
    , max_rows
    , db_version = FAV_DB_VERSION_CURRENT  
):
##        LogR(locals())
    (query, params) = Q.GET_DATA_TO_REPLICATE(
        db_version
          , local_db_repl_id_highwater
          , local_db_date_modified_highwater
          , id_range_start
          , id_range_end
          )
    Log(query.replace("?", "'%s'") % params, C.LOGNONE)  #see exact query during debugging
    local_cursor.row_factory = sqlite3.Row
    try: 
        local_cursor.execute(query, params)
    except:
        LogR(("exeption querying", query, params))    
        raise
    for a in local_cursor.fetchmany(size=max_rows):
##            LogR(list(a))
        yield(a)
#__________________________________________________________________
#    
def SyncDB(
    local_db_conn
    ,local_cursor
    ,remote_db_conn
    ,remote_cursor
    ,import_only=False
    ,save_repl_vector=True
    ,force_full_replication=False
    ):

    
    total_number_changed_rows = 0
    
    if save_repl_vector:
        #get db uuids
        query = Q.GET_DB_UUID(FAV_DB_VERSION_CURRENT)
        params = ()
        result = remote_cursor.execute(query, params).fetchone()
        remote_db_uuid = result['uuid'] #use ['uuid'] if rowfactory = sqlite3
        LogR(("remote_db_uuid=",remote_db_uuid, local_db_conn.db_filespec))
        query = Q.GET_DB_UUID(FAV_DB_VERSION_CURRENT)
        params = ()
        result = local_cursor.execute(query, params).fetchone()
        local_db_uuid = result[0]
        LogR(("local_db_uuid=",local_db_uuid, remote_db_conn.db_filespec))


    def progress_callback():
        if pd.iscanceled():
            return 1  # Non-zero return aborts the operation
        pd.increment_percent()
        utils.Sleep(50)
        return 0
    local_db_conn.set_progress_handler(progress_callback, REPLICATION_PROGRESS_CALLBACKS)
    




    if save_repl_vector:
        #get local_db max index to determine how much to subdivide the replication
        query = Q.GET_MAX_ROWID(FAV_DB_VERSION_CURRENT)
        params = (REPL_ID_HIGHWATER_INIT,)
        result = remote_cursor.execute(query, params).fetchone()
        max_rowid = result['max_rowid'] #use format ['uuid'] if rowfactory = sqlite3
    else:
        max_rowid=0
        local_db_repl_id_highwater = 1
        local_db_date_modified_highwater = 1
        id_range_start = 1
        id_range_end = 99999999999
        full_repl = True
        #create a new cursor with NONE row_factory so that we can use wildcards
##        local_db_conn.text_factory = str
        remote_db_conn.row_factory = None
        remote_cursor_str = remote_db_conn.cursor()
        remote_db_conn.row_factory = sqlite3.Row  
    
    loops_for_full_repl = (max_rowid//MAX_ROWS) + 2
    LogR(("loops_for_full_repl",loops_for_full_repl -1 ))

    pd = utils.Progress_Dialog(
        __name__ #u"Favorites"
        ,u"Synchronizing up to {} entries...".format(max_rowid)
        )

    for i in range(1,loops_for_full_repl):
        row_range_start = ((i-1)*MAX_ROWS) + 1
        row_range_end = row_range_start + MAX_ROWS
##        LogR((i, row_range_start, row_range_end),C.LOGERROR)
        loop_number_changed_rows = 0

        if save_repl_vector:
            #find out when the remote DB was last synced with this one 
            query = Q.GET_DB_REPL_VECTOR(FAV_DB_VERSION_CURRENT)
            params = (remote_db_uuid, row_range_start, row_range_end)
            Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
            try:
                result = local_db_conn.execute(query, params).fetchone()
                
                if result:
##                    LogR(list(result))
                    (local_db_repl_id_highwater
                     , local_db_date_modified_highwater
                     , full_repl
                     , id_range_start
                     , id_range_end
                     ) = result
                else: #vector not created yet
                    Log("inserting first replication vector for remote {} in local database {}".format(
                        remote_db_uuid
                        , local_db_uuid
                        ))
                    query = Q.INIT_DB_REPL_VECTOR(FAV_DB_VERSION_CURRENT)
                    params = (remote_db_uuid
                              ,REPL_ID_HIGHWATER_INIT
                              ,0
                              ,0
                              ,row_range_start
                              ,row_range_end
                              #,utils.UTC_timestamp()
                              )
                    result = local_db_conn.execute(query, params)
                    local_db_conn.commit
                    local_db_repl_id_highwater=REPL_ID_HIGHWATER_INIT
                    local_db_date_modified_highwater=full_repl=0
                    id_range_start = row_range_start
                    id_range_end = row_range_end            
            except:
                LogR(("exeption querying", query, params))
                raise


##        LogR(
##            (  local_db_repl_id_highwater
##             , local_db_date_modified_highwater
##             , full_repl
##             , id_range_start
##             , id_range_end
##             , local_db_conn.db_filespec
##             )
##            , C.LOGNONE
##            )
                    
        if save_repl_vector:
            #when full replication has complete, we can now replicate using
            if full_repl == FULL_REPL_SUCCESS:
                if not local_db_date_modified_highwater: #then value is zero [first time]
                    local_db_repl_id_highwater = REPL_ID_HIGHWATER_INIT # this will also be zero
                    
                    #we are now replicating all modified values, starting with smallest id
                else:
                    #the stored repl vector values should be ok for use as-is
                    pass

            else:
                #we need to ignore modified records
                # and concentrate on inserting records until a
                #  first-pass complete [aka full_relpl] has happened
                local_db_date_modified_highwater = REPL_ID_HIGHWATER_INIT

##        LogR(
##            (  local_db_repl_id_highwater
##             , local_db_date_modified_highwater
##             , full_repl
##             , id_range_start
##             , id_range_end
##             , local_db_conn.db_filespec
##             )
##            , C.LOGNONE
##            )

        if force_full_replication:
            local_db_date_modified_highwater = REPL_ID_HIGHWATER_INIT
            local_db_repl_id_highwater = REPL_ID_HIGHWATER_INIT
        
        #get max ID for local database and compare with local_db_repl_id_highwater
        # when maxid >= local_db_repl_id_highwater
        

        loop_number_changed_rows = 0
        highest_changed_row_id = 0

        try:  #sync local to remote

            most_recent_id = local_db_repl_id_highwater
            lowest_date_modified = local_db_date_modified_highwater

            if not import_only:
                db_version = FAV_DB_VERSION_CURRENT
            else:
                db_version = FAV_DB_VERSION_1

            for cur_data in \
                row_generator(
                    local_cursor
                    , local_db_repl_id_highwater=local_db_repl_id_highwater #this value is between id_start and id_end
                    , local_db_date_modified_highwater=local_db_date_modified_highwater
                    , id_range_start=id_range_start
                    , id_range_end=id_range_end
                    , max_rows=MAX_ROWS
                    , db_version=db_version
                    ):


##                LogR(list(cur_data))
##                continue

                #sqlite performance issues [only using a single index per table] do not let me use ORDER BY
                try:
                    cid = cur_data['rowid']
                    cdm = cur_data['date_modified']
                except:
                    LogR(list(cur_data))
                    raise
                if cid>most_recent_id:  most_recent_id=cid


                if cur_data['name']=='becky_baker':
                    cur_data2 = OrderedDict(cur_data)
                    cur_data2['binary_image']='<replaced for logging>'
                    LogR(cur_data2.values(),C.LOGWARNING)

                if pd.iscanceled():
                    raise sqlite3.OperationalError('interrupted')

                if not import_only:
                    
                    try:
                        query = Q.UPDATE_FAVORITES(FAV_DB_VERSION_CURRENT)
##                        Log(query.replace("?", "'%s'") % tuple(cur_data))  #see exact query during debugging

                        result = remote_cursor.execute(query, cur_data)
                        if result.rowcount > 0:
##                            LogR(tuple(cur_data))
##                            LogR(("updated rows", result.rowcount))
                            cur_data = OrderedDict(cur_data)
                            cur_data['binary_image']='<replaced for logging>'
                            Log(query.replace("?", "'%s'") % tuple(cur_data.values()))  #see exact query during debugging
                            loop_number_changed_rows += result.rowcount
                            if cid>highest_changed_row_id: highest_changed_row_id=cid
                            if cdm<lowest_date_modified: lowest_date_modified=cdm
                            continue
                        else:
##                            LogR(('no update', cid, cur_data['name']))
##                            raise Exception("why not?")
                            pass
                    except sqlite3.IntegrityError as e:
                        if e.args != ('duplicate information',):
                            LogR(e.args)
                            Log(query.replace("?", "'{}'").format( *cur_data.values() ) )  #see exact query during debugging
                            raise

                    except Exception as e:
                        LogR(e.args)
                        Log(query.replace("?", "%s") % tuple(cur_data))  #see exact query during debugging
                        traceback.print_exc()
                        raise


                if import_only: #short circuit if we already have item in our db
                    url = cur_data['url']
                    query = Q.GET_FAV_URL(FAV_DB_VERSION_CURRENT)
                    params = ( url.split('|')[0]+'%', )
##                    Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
                    result = remote_cursor_str.execute(query, params).fetchone()
                    if result:
                        LogR((url,' already in db'))
                        continue

                try:
                    query = Q.INSERT_FAVORITES(FAV_DB_VERSION_CURRENT)

                    cur_data = OrderedDict(cur_data)
                    if not cur_data['uuid']: cur_data['uuid'] = str(uuid4() )
                    if not cur_data['date_modified']: cur_data['date_modified'] = utils.UTC_timestamp()
##                    Log(query.replace("?", "'{}'").format( *cur_data.values() ) )  #see exact query during debugging
                    #todo: maybe use tuple for py2?
                    if C.PY2: result = remote_cursor.execute(query, cur_data.values())
                    if C.PY3: result = remote_cursor.execute(query, tuple(cur_data.values()))
                    if result.rowcount > 0:
                        LogR(("inserted rows", result.rowcount))
                        cur_data['binary_image']='<replaced for logging>'
                        LogR(cur_data.values())
                        loop_number_changed_rows += result.rowcount
                        if cid>highest_changed_row_id: highest_changed_row_id=cid
                        if cdm<lowest_date_modified: lowest_date_modified=cdm
                except sqlite3.IntegrityError as e:
                    if e.args != ('UNIQUE constraint failed: favorites.uuid',):
                        LogR(e.args)
                        Log(query.replace("?", "'{}'").format( *cur_data.values() ) )  #see exact query during debugging
                        raise
                except:
                    Log(query)
                    LogR(cur_data, include_type=True)
                    LogR(cur_data.values(), include_type=True)
##                    LogR(len(cur_data.values()))
                    LogR(list(cur_data) , include_type=True)
                    Log(query.replace("?", "'{}'").format( *cur_data.values() ) )  #see exact query during debugging
                    raise


                if full_repl != FULL_REPL_SUCCESS:
                    if loop_number_changed_rows < 1:
                        #dont' save any repl data
##                        raise Exception()
                        Log("loop_number_changed_rows < 1:" ,C.LOGWARNING)


            total_number_changed_rows += loop_number_changed_rows
                
            ##
            #end for loop
            ##
            if loop_number_changed_rows and not full_repl:
                LogR(("for a partial sync, loop_number_changed_rows=",loop_number_changed_rows))
    
                if save_repl_vector: 
                    #calculate local's HIGHEST possible modified date within our id_range
                    query = Q.GET_MAX_MODIFIED_IN_IDRANGE(FAV_DB_VERSION_CURRENT)
                    params=(highest_changed_row_id, id_range_end)
                    Log(query.replace("?", "'%s'") % params)  #see exact query during debugging
                    result = local_db_conn.execute(query, params).fetchone()
                    local_db_date_modified_highwater = result[0]
                    
                    #save the success
                    query = Q.WRITE_DB_REPL_VECTOR(FAV_DB_VERSION_CURRENT)
                    params = (
                        most_recent_id + 1 # +1 because we are using [greater than] or [equal to] in query
                        , local_db_date_modified_highwater
                        , full_repl
                        #, utils.UTC_timestamp()
                        , remote_db_uuid
                        , id_range_start
                        , id_range_end
                        )
                    try:
    ##                    LogR(("saved the success",params))
                        Log(query.replace("?", "'{}'").format(*tuple(params)))  #see exact query during debugging
                        local_db_conn.execute(query, params)                
                        
                    except:
                        LogR(("exeption querying", query, params))
                        raise
                    local_db_conn.commit()
                    
                remote_db_conn.commit()
                
                Log(u"{} changes replicated".format(loop_number_changed_rows))
                
            elif save_repl_vector:  #consider this a a full replication for that id_range

                remote_db_conn.commit()
               
                local_db_date_modified_highwater = lowest_date_modified
                if local_db_date_modified_highwater<2:
                    #nothing was changed during this pass
                    # avoid a full db search by generating a higher number
                    #calculate local's HIGHEST possible modified date within our id_range
                    query = Q.GET_MAX_MODIFIED_IN_IDRANGE(FAV_DB_VERSION_CURRENT)
                    params=(id_range_start,id_range_end)
                    Log(query.replace("?", "'%s'") % tuple(params))  #see exact query during debugging
                    result = local_db_conn.execute(query, params).fetchone()
                    local_db_date_modified_highwater = result[0]
                    


##suppose we have more than one DB
##dbB is an intermediate replical
##dbA and dbB sync.  The most recently modified record is dbA-mrmr1 with date dbA-mrmr1-dm1
##dbA and dbB can sync by only indexing modified information; records > than dbA-mrmr1-dm1 need to sync
##dbB and dbC then syncs for the first time.  Everything in dbA will be on dbC.
##Except dbC is independent and has its own indpendent most recently dbC-mrmr1-dm1
##There is no guarantee that dbA-mrmr1-dm1 > dbC-mrmr1-dm1  or   dbA-mrmr1-dm1 < dbC-mrmr1-dm1
##To get information the information of dbC-mrmr1, we have to search dbB for the records > dbC-mrmr1-dm1
##This might imply that we dbA needs to scan dbB for values >= dbC-mrmr1-dm1
##But .... worst case is that a full replication is required

##Does using a date_replicated  help? [instead of date modified]
##Thinking it through....

##Does using a is_dirty column help?
##Thinking it through....
##dbA and dbB sync.  Nothing is_dirty
##dbA changes one record.  dbA-mrmr1 is now marked as 'dirty'
##[will stop using quotes from now on]
##dbB scans for all dirty rows and copies them over
##dbB-mrmr1 will _stay_ dirty until it gets copied to dbC
##we would need a table to track tuples
##   ownerReplicaID,replicaID,uuid,dirty
##inserting from dbA should add one row for each replicaID that dbB knows about
##the row for dbA would be not-dirty
##the row for dbC would be dirty
##dbC scans for all dirty rows, not owned by itself, and replicates them
##dbC sets row as not-dirty
##when all rows for that uuid are not-dirty; delete the uuid from the table
##NOTE: table must be locked against read and write to prevent race conditions

                query = Q.WRITE_DB_REPL_VECTOR(FAV_DB_VERSION_CURRENT)
                params = (
                    REPL_ID_HIGHWATER_INIT
                    , local_db_date_modified_highwater
                    , FULL_REPL_SUCCESS
                    #, utils.UTC_timestamp()
                    , remote_db_uuid
                    , id_range_start
                    , id_range_end
                    )          
                Log(query.replace("?", "'{}'").format(*tuple(params)))  #see exact query during debugging
                try:
                    LogR(('saving a FULL repl success between local [{}] and remote [{}]'.format(
                            local_db_conn.db_filespec
                            ,remote_db_conn.db_filespec
                            ),
                          )
                         )

                    local_db_conn.execute(query, params)
                    local_db_conn.commit()

                except:
                    LogR(("exeption querying", query, params))
                    #traceback.print_exc()
                    raise            

                Log(u"{} changes made".format(loop_number_changed_rows))


        except sqlite3.OperationalError as e:
            if e.args != ('interrupted',):
                raise
            utils.Notify(
                header= __name__ #u"Favorites"
                , msg=u"replication canceled for {} records".format(loop_number_changed_rows)
                , duration=REPLICATION_NOTIFY_DURATION
                )
            break
        except:
            LogR(query)
            LogR(tuple(params))
##            traceback.print_exc()
            raise

    
    Log(u"{} TOTAL changes replicated".format(total_number_changed_rows), C.LOGWARNING)

    return total_number_changed_rows

    #end for loop in 
        
#__________________________________________________________________
#
def Add_Sync_Favorites(dir_only=False):
##    utils.addDir(
##        name="[COLOR {}]Favorites_Sync[/COLOR]".format(C.test_text_color)
##        ,url=C.DO_NOTHING_URL
##        ,mode=C.FAVORITES_SYNC
##        #,iconimage=C.category_icon
##        ,duration=1
##        ,Folder=False 
##        )
    utils.addDir(
        name="[COLOR {}]Favorites_Sync_ForceFull[/COLOR]".format(C.test_text_color)
        ,url=C.DO_NOTHING_URL
        ,mode=C.FAVORITES_SYNC
        #,iconimage=C.category_icon
        ,duration=1
        ,keyword='True' #this is me just reusing a parameter name for this specific function
        ,Folder=False 
        )
    utils.addDir(
        name="[COLOR {}]Favorites_Import[/COLOR]".format(C.test_text_color)
        ,url=C.DO_NOTHING_URL
        ,mode=C.FAVORITES_IMPORT
        #,iconimage=C.category_icon
        ,duration=1
        ,Folder=False 
        )
    utils.addDir(
        name="[COLOR {}]Favorites_Backup[/COLOR]".format(C.test_text_color)
##        ,url=C.DO_NOTHING_URL
        ,mode=C.FAVORITES_BACKUP
        #,iconimage=C.category_icon
        ,url='C:\\Users\\poq\\AppData\\Roaming\\Kodi\\userdata\\addon_data\\plugin.video.uwc\\favorites.db'
        ,duration=1
        ,Folder=False 
        )
        
#__________________________________________________________________
#
def TableCreateString(db_version):
    return Q.MAIN_TABLE_STRING(db_version)
#__________________________________________________________________
#
def Create_Table(db_conn): #favDB_conn
    sql_command = Q.DB_SCHEMA_STRING(FAV_DB_VERSION_CURRENT, db_conn)
    Log("sql_command='{}'".format(sql_command) ) 
    try:
        if 'MySQLCursor' in str(type(db_conn)):
            db_conn.execute( sql_command )
        else:
            db_conn.executescript( sql_command )
            db_conn.commit()
    except AttributeError as e:
        Log(e.args[0],C.LOGERROR)
        LogR(dir(db_conn),C.LOGWARNING)
    except sqlite3.OperationalError as e:
        Log(sql_command,C.LOGERROR)
        utils.Notify(msg="{} {}".format(e.args[0], db_conn.db_filespec), duration=10000 )
        raise
#__________________________________________________________________
#
def Export_Import(db_conn): #favDB_conn
    DB_PRAGMA_version = Get_DB_PRAGMA_version(db_conn)
    query = Q.UPGRADE_DB_STRING(FAV_DB_VERSION_CURRENT, DB_PRAGMA_version)
    params = ()
    Log(query.replace("?", "'%s'") )  #see exact query during debugging
    db_conn.executescript( query ) #executescript  will self=commit
#__________________________________________________________________
#
def Get_DB_PRAGMA_version(db_conn): #favDB_conn
    sql_command = "PRAGMA user_version;"
    try:
    ##    Log("sql_command='{}'".format(sql_command) )
    ##    LogR(dir(db_conn),C.LOGWARNING)
    ##    LogR(db_conn.__class__,C.LOGWARNING)  #<class 'mysql.connector.cursor.MySQLCursor'>,)
        id_column_count =  db_conn.execute( sql_command )
        for a in id_column_count:
            return a[0]
    except:
        Log("sql_command='{}'".format(sql_command) )
        return 0
##        raise
#__________________________________________________________________
#
def Get_DB_PRAGMA_filename(db_conn):
    sql_command = 'SELECT file FROM pragma_database_list;'
    Log("sql_command='{}'".format(sql_command) )
    id_column_count =  db_conn.execute( sql_command )
    for a in id_column_count:
        return a[0]
#__________________________________________________________________
#
def Create_Maintain_FavDB(db_conn): #favDB_conn
    DB_PRAGMA_version = Get_DB_PRAGMA_version(db_conn)
##    LogR(DB_PRAGMA_version,C.LOGERROR)
##    LogR(Get_DB_PRAGMA_filename(db_conn),C.LOGERROR)
    if DB_PRAGMA_version == 0:
        Log('new database detected')
        Create_Table(db_conn)
    elif DB_PRAGMA_version < FAV_DB_VERSION_CURRENT:
        Log('Export_Import()')
        Export_Import(db_conn)
    else:
        Log('Database user_version is up to date')
        Create_Table(db_conn)
#__________________________________________________________________
#
@C.url_dispatcher.register("2341234123")  
def Add_Play_Random(dir_only=False):

    if dir_only:
        utils.addDir(
            name="[COLOR {}]Random Favorited Vid[/COLOR]".format(C.highlight_text_color)
            ,url=C.DO_NOTHING_URL
            ,mode="2341234123"
            ,iconimage=C.category_icon
            ,duration=2
            ,Folder=False 
            )
        return

    try:

        model = model_id = None

        favDB_cursor.row_factory = sqlite3.Row
##        sql_command = "S ELECT * FROM favorites WHERE camsite is NULL"
##        playable_items = favDB_cursor.execute(sql_command).fetchall()
####        LogR(playable_items)
##        m = random.choice(playable_items)
####        LogR(m)
##        model_id = m['id']
####        LogR(model_id)
##        model = favDB_cursor.execute("S ELECT * FROM favorites WHERE id = {}".format(model_id) ).fetchone()

        query = Q.GET_RANDOM_NOT_CAM_FAVORITE(FAV_DB_VERSION_CURRENT)
##        Log(query,C.LOGNONE)
        model = favDB_cursor.execute(query).fetchone()
##        LogR(model)
        model = dict(model)
##        LogR(model,C.LOGNONE)
##        return
    
        if 'play_method' in model and model['play_method'] in ('','None','none',None):
            play_method = None
        elif 'play_method' in model:
            play_method = model['play_method']
        else:
            play_method = None

        if 'hq_stream' in model: hq_stream = model['hq_stream']
        else: hq_stream = 0
                            
        listitem = utils.addDownLink( 
            name = model['name'] #"Random Vid of the Day" #utils.cleantext(icon_label) #model['icon_label'] 
            , url = model['url']  #model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['image']
            #, duration = model['camscore']
            , play_method = play_method
            #, fav = 'del'
            , desc = u"{}\n{}".format(utils.cleantext(model['name']), model['description'])
            , hq_stream = hq_stream
            , return_listitem = True
            )
        u = listitem[0]


        Log(repr(u)
            , C.LOGNONE
            )
        xbmc.executebuiltin('RunPlugin('+u+')')
        utils.Sleep(1000)
    except:
        traceback.print_exc()
        Log(repr((model,model_id))
            ,C.LOGNONE
            )

        
#__________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_FAVORITES)
def List():
    C.DEBUG = True
    Log("List()")
    items_list = list()

    MAX_DAYS_WITHOUT_SYNC = 7
    ONE_DAY_TIMESTAMP = 86400.0
    
    today = utils.UTC_timestamp()

    remote_favorite_db_folder = GetSetting("remote_favorite_db_folder", str)
    favorites_sync_datetime = GetSetting("favorites_sync_datetime", float)
    if remote_favorite_db_folder and favorites_sync_datetime:
        LogR( ( (today-favorites_sync_datetime)//ONE_DAY_TIMESTAMP ) )
        LogR(('next backup on GMT ', time.ctime((favorites_sync_datetime + MAX_DAYS_WITHOUT_SYNC*ONE_DAY_TIMESTAMP))),C.LOGNONE)
        if today > (favorites_sync_datetime + MAX_DAYS_WITHOUT_SYNC*ONE_DAY_TIMESTAMP):
            days = (today-favorites_sync_datetime)//ONE_DAY_TIMESTAMP
            if C.PY2:
                result = xbmcgui.Dialog().yesno(
                        heading = u"Favorites Sync"
                        , line1 = u"{} days since in favorites sync".format(days)
                        , autoclose = 10000
                        )
            if C.PY3:
                result = xbmcgui.Dialog().yesno(
                        heading = u"Favorites Sync"
                        , message= u"{} days since in favorites sync".format(days)
                        , autoclose = 10000
                        , defaultbutton = xbmcgui.DLG_YESNO_NO_BTN #only in kodi 20+
                        )
            LogR(result)
            if result:
                Favorites_Sync()
                
            
    progress_dialog_message = "Listing Favorites"
    progress_dialog = utils.Progress_Dialog(C.addon_name, progress_dialog_message)

    try: 
        texture_conn = sqlite3.connect(C.texture_DB_filespec)
        texture_conn.text_factory = sqlite3.Row #note; wild cards not work with sqlite3.Row factory


        favDB_cursor = favDB_conn.cursor()

        texture_cursor = texture_conn.cursor()
        
        if GetSetting("auto_clean_img_database", bool):
            RefreshImages()
        manually_refresh_favorites = GetSetting("manually_refresh_favorites", bool)
        play_method = GetSetting("default_playmode", str)

##        Create_Maintain_FavDB(favDB_conn)
        Create_Maintain_FavDB(favDB_cursor)

        Add_Play_Random(True)
        if C.DEBUG: Add_Sync_Favorites(True)
        
        percent = 1
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...filling/scanning webcam database...'
            )        
        camDB_conn = webcam_db.fill_webcam_db(progress_dialog) #locked so that service can't clear DB during processing
        percent = 30 #an arbitrary number...
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...matching online cams...'
            )
        i = 0
        
##        with camDB_conn:
        try:

            query = Q.LIST_FAVORITES_CAMSITE(FAV_DB_VERSION_CURRENT)
            Log(query,C.LOGNONE)

            favDB_cursor.row_factory = sqlite3.Row


            Log(" EXPLAIN QUERY PLAN " + query, C.LOGERROR)
            if 'MySQLCursor' in str(type(favDB_cursor)):
                favDB_cursor.execute(" EXPLAIN " + query)
            else:
                favDB_cursor.execute(" EXPLAIN QUERY PLAN " + query)
            for a in favDB_cursor.fetchall():
                LogR(dict(a),C.LOGNONE)                

            favDB_cursor.execute(query)
            Log(query,C.LOGNONE)
            for a in favDB_cursor.fetchall():
                pass
            

            favDB_cursor.execute(query)
            for a in favDB_cursor.fetchall():
##                continue
                
                if progress_dialog.iscanceled(): break


                name= a['name']
                url= a['url']
                mode= a['mode']
                img = a['image']
                description = a['description']
                binary_image = a['binary_image']
                camsite = a['camsite']
                uuid = a['uuid']
                model_currently_online = a['isonline']

##                LogR(a,C.LOGERROR)
                icon_label = name
                model = dict(a)
                model['video_url'] = url
                model['icon_image'] = img
                #model['camscore'] = a['camscore']
##                LogR(model,C.LOGERROR)

                model_id_via_image = "00000000" # length of 8
                if str(mode)==mfc_PLAY_MODE:
                    if "/img.mfcimg.com/" in img or "/snap.mfcimg.com/" in img :
                        model_id_via_image = img.split('/')[6]
                        if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                            model_id_via_image = img.split('/')[5]
                        #the 1 indicates model was in public chat when bookmark created
                        if model_id_via_image.startswith("mfc_a_1"):
                           model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
                        if model_id_via_image.startswith("mfc_1"):
                           model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
                        if model_id_via_image[0] == '0':
                            model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
                        img = mfc_generic_image(model_id_via_image)
                        while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
                            model_id_via_image = '0' + model_id_via_image
##                camDB_conn.row_factory = sqlite3.Row
##                query = (u"select * from camlist where (mode = ?)"
##                         " and ( (modelID LIKE ? ESCAPE '\\') or "
##                         "       ( (icon_image LIKE ? ESCAPE '\\') or "
##                         "         (icon_image LIKE ? ESCAPE '\\')"
##                         "       ) "
##                         "     )  ;"
##                         )
##                try:
##                    params = ( int(mode)
##                              ,name.decode('utf-8').replace('_', '\\_')
##                              ,r"%/mfc\_1{}?%".format(model_id_via_image)
##                              ,r"%/mfc\_a\_1{}?%".format(model_id_via_image)
##                              )
##                except:
##                    params = ( int(mode)
##                              ,name.replace('_', '\_')
##                              ,"%/mfc\_1{}?%".format(model_id_via_image)
##                              ,"%/mfc\_a\_1{}?%".format(model_id_via_image)
##                              )
##                model = camDB_conn.execute(query,params).fetchone()
##                model_currently_online = (model is not None)
                
                if model_currently_online:

                    progress_dialog.update(
                        percent  = progress_dialog.percent + 0.1
                        ,message = progress_dialog_message 
                        ,line2 = ' '
                        ,line3 = '...found {}...'.format(name)
                        )
                    Log('...found {}...'.format(name), C.LOGNONE)
                    
##                    model = dict(model)
                    icon_label = u"[COLOR {}]{}[/COLOR]".format(
                        C.search_text_color
                        , name
                        )
                    
                    if str(mode)==mfc_PLAY_MODE:
                        
                        #site allows easy name changes, but no searching via id;
                        current_model_name = model['modelID']
                        
                        if current_model_name != name: #automatically refresh name in fav database
                            Log("new mfc model name '{}' --> '{}'".format(
                                name
                                , current_model_name
                                ), C.LOGWARNING)
                            #download name also needs changing
                            downloader.rename_download(
                                name = C.DOWNLOAD_INDICATOR+name
                                ,new_name = C.DOWNLOAD_INDICATOR+current_model_name
                                ,mode = mode
                                ,friendly_name = current_model_name
                                ,url_factory = current_model_name
                                )
                            Rename_Fav(url=current_model_name, name=current_model_name, uuid=uuid)


                    model['icon_url'] = img


                elif not model_currently_online:
                
##                    model = {}
##                    icon_label = name
##                    model['video_url'] = url
##                    model['mode'] = mode
##                    model['icon_image'] = img
                    model['camscore'] = -1 #force to end 
##                    if description: model['description'] = description
##                    else: model['description'] = ''
                    model['icon_url'] = img

##                    if True or camsite:
##                        #at one point, I only wrote image if camsite; but now that CF is more common
##                        # it seems that the binary_image I store is more reliable #2025-07
##                        if True and binary_image:
##                            if C.PY2:
##                                if isinstance(binary_image, buffer):
##                                    binary_image = str(binary_image)
##                            if C.PY3:
##                                if isinstance(binary_image, bytes):
##                                    binary_image = binary_image.decode('utf8')
##                            if binary_image.startswith(('/9j/','UklG')):
##                                img_raw = base64.b64decode(binary_image)
##                            else: img_raw = binary_image
##                            model['icon_image'] = image_to_local_cache(img_raw,file_type=binary_image[0:4])
                    if binary_image:
                        if C.PY2:
                            if isinstance(binary_image, buffer):
                                binary_image = str(binary_image)
                        if C.PY3:
                            if isinstance(binary_image, bytes):
                                binary_image = binary_image.decode('utf8')
                        if binary_image.startswith('UklG'):
                            img_raw = base64.b64decode(binary_image)
                            img_raw_type='wbem'
                        elif binary_image.startswith('/9j/'):
                            img_raw = base64.b64decode(binary_image)
                            img_raw_type='jpg'
                        else:
                            img_raw = binary_image
                            img_raw_type='jpg'
                        model['icon_image'] = Insert_Binary_Image(
                            img_raw
                            ,img
                            ,img_raw_type
                            ,name,texture_cursor=texture_cursor
                            )
##                        LogR(model['name'],C.LOGERROR)
##                        LogR(model['icon_url'],C.LOGINFO)
##                        LogR(model['icon_image'],C.LOGINFO)


                if 'hq_stream' in model: hq_stream = model['hq_stream']
                else: hq_stream = 0
                    
                if 'play_method' in model and model['play_method'] in ('','None','none',None):
                    play_method = None
                elif 'play_method' in model:
                    play_method = model['play_method']
                else:
                    play_method = None

                items_list.append(
                    utils.addDownLink( 
                        name = utils.cleantext(icon_label)
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , icon_url = model['icon_url']
                        , duration = model['camscore']
                        , play_method = play_method
                        , fav = 'del'
                        , desc = utils.cleantext(model['description'])
                        , hq_stream = hq_stream
                        , return_listitem = True
                        , uuid = uuid
                        )
                    )

            progress_dialog.update(
                percent  = progress_dialog.percent + 0.1
                )
            Log("end models query",C.LOGNONE)

##            Log(sqlite3.sqlite_version,C.LOGNONE)
            
            #non cam favorites
            query = Q.LIST_FAVORITES_NOCAMSITE(FAV_DB_VERSION_CURRENT)

            favDB_cursor = favDB_conn.cursor()
            Log(query,C.LOGNONE)
            favDB_cursor.execute(" EXPLAIN QUERY PLAN " + query)
            for a in favDB_cursor.fetchall():
                LogR(dict(a),C.LOGNONE)                

##            favDB_cursor.close()
##            favDB_cursor = favDB_conn.cursor()
##            favDB_cursor.row_factory = sqlite3.Row
##
##            favDB_cursor.execute(query)
##            Log(query,C.LOGNONE)
##            for a in favDB_cursor.fetchall():
##                continue

            favDB_cursor.close()
            favDB_cursor = favDB_conn.cursor()
            favDB_cursor.row_factory = sqlite3.Row
            
            Log(query,C.LOGNONE)
##            favDB_cursor.row_factory = None
            favDB_cursor.execute(query)
            for a in favDB_cursor.fetchall():
##            for a in favDB_cursor.fetchone():

                #permit user interruption
                if progress_dialog.iscanceled(): break
                progress_dialog.update(
                    percent = progress_dialog.percent + 0.1
                    ,message = progress_dialog_message 
                    ,line2 = ' '
                    ,line3 = '...matching non cams...'
                    )

                #limit entries
                i = i+1

                if (i>FAV_LIST_LIMIT): #e.g. after limit; 1/5 ~20% chance of including item
##                    LogR((i,FAV_LIST_LIMIT,FAV_LIST_FRACTION),C.LOGNONE)
                    if FAV_LIST_FRACTION>1:
                        if int(random.random()*100) > FAV_LIST_FRACTION:
                            continue
                    else:
                        LogR(('FAV_LIMIT_reached',i,FAV_LIST_LIMIT,FAV_LIST_FRACTION)
                             ,C.LOGWARNING)
                        break

##                if 'detail' in a:
##                    LogR(dict(a),C.LOGNONE)
##                    continue
            
                name= a['name']

                if i < 5:
                    Log(name,C.LOGNONE)
                    
                url= a['url']
                mode= a['mode']
                img = a['image']
                description = a['description']
                binary_image = a['binary_image']
                camsite = a['camsite']
                uuid = a['uuid']
                model = dict(a)
                icon_label = name
                model['video_url'] = url
##                model['mode'] = mode
                model['icon_image'] = img
##                model['camscore'] = 0
##                if description: model['description'] = description
##                else: model['description'] = ''
                model['icon_url'] = img
##                LogR(model)

                # at one point, I only wrote image if camsite; but now that CF is more common
                # it seems that the binary_image I store is more reliable #2025-07
                if binary_image:
                    if C.PY2:
                        if isinstance(binary_image, buffer):
                            binary_image = str(binary_image)
                    if C.PY3:
                        if isinstance(binary_image, bytes):
                            binary_image = binary_image.decode('utf8')
                    if binary_image.startswith('UklG'):
                        img_raw = base64.b64decode(binary_image)
                        img_raw_type='wbem'
                    elif binary_image.startswith('/9j/'):
                        img_raw = base64.b64decode(binary_image)
                        img_raw_type='jpg'
                    else:
                        img_raw = binary_image
                        img_raw_type='jpg'
                    model['icon_image'] = Insert_Binary_Image(
                        img_raw,img
                        ,img_raw_type
                        ,name
                        ,texture_cursor=texture_cursor
                        )

                if 'hq_stream' in model: hq_stream = model['hq_stream']
                else: hq_stream = 0
                if 'play_method' in model and model['play_method'] in ('','None','none',None):
                    play_method = None
                elif 'play_method' in model:
                    play_method = model['play_method']
                else:
                    play_method = None

                items_list.append(
                    utils.addDownLink( 
                        name = utils.cleantext(icon_label)
                        , url = model['video_url'] 
                        , mode = model['mode'] 
                        , iconimage = model['icon_image']
                        , icon_url = model['icon_url']
                        , duration = model['camscore']
                        , play_method = play_method
                        , fav = 'del'
                        , desc = utils.cleantext(model['description'])
                        , hq_stream = hq_stream
                        , return_listitem = True
                        , uuid = uuid
                        )
                    )


            #end non-cam-favorites query
            
        except :
            LogR(traceback.format_exc(),C.LOGERROR)
            utils.notify('No Favorites found')

        finally:
            if favDB_conn: favDB_conn.close()
            if camDB_conn: camDB_conn.close()
            

    except :
        LogR(traceback.format_exc())

    finally:

        #include a refesh icon
        utils.Add_Refresh_Item(
            mode=C.REFRESH_CONTAINER_MODE
            ,progress_dialog=progress_dialog
            ,duration=1 #duration so that when sorting by duration, refresh shows after active webcams when = 1
            ,end_directory=True)

        #include a sync icon
        utils.addDir(
            name="[COLOR {}]Favorites_Sync[/COLOR]".format(C.test_text_color)
            ,url=C.DO_NOTHING_URL
            ,mode=C.FAVORITES_SYNC
            #,iconimage=C.category_icon
            #,duration=999999999 # position icon at end when sort by duration; value must be less than 2^32
            ,duration=0 # position icon at end when sort by duration desc; value must be less than 2^32
            ,Folder=False 
            )
        
        #then add all the generated listitems
        xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)

    set_default_view = {
        "path": sys.argv[0] + sys.argv[2]
        # Note: xbmcplugin.SORT_METHOD_DURATION  and "SortUtils.h".SortByTime values are different
        ,"sortmethod" : C.INITIAL_SORTMETHOD #sort by time/duration
        ,"sortdirection" : True #toggle to descending [because when blank,  default is ascending]
        ,"viewmode"      : C.INITIAL_VIEWMODE
        ,"sleeptime"     : max(100, int(FAV_LIST_LIMIT*3)) #need more time to set view will large number of items
        }
    LogR(set_default_view)
    utils.endOfDirectory( cacheToDisc= (manually_refresh_favorites==True)
                         , set_default_view=set_default_view
                         , updateListing=False
                         )

#__________________________________________________________________
#
def check_if_camsite(favmode):
    #sometimes we need to know if a favorite cam model
    result = False #default 
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_CAMS):
##        LogR((root_url, mode, favmode),C.LOGNONE)
        if (int(mode)+C.MODE_PLAY_OFFSET) == favmode:
            result = True
            break
    return result
#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_MODE
                           ,['fav','favmode','name','url','img']
                           ,['desc','camsite','icon_url','uuid']
                           )  
def Favorites(fav,favmode,name,url,img,desc=None,camsite=None,icon_url=None,uuid=None):
    LogR((C.module_name() , locals()))

    is_camsite = check_if_camsite(favmode)

    n_bak = name
    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = utils.Clean_Filename(name)
    if name in [None,'']: raise Exception("invalid name '{}'".format(n_bak))

    if fav in ["add"]:

        if img.startswith(C.translatePath("special://home/")):
            utils.Notify(u"Can't add/refresh fav when icon points to local file. Find an original source")
            return

        keyboard = xbmc.Keyboard(name, 'Change name before adding?', hidden=False)
        keyboard.doModal()
        if keyboard.isConfirmed(): name = keyboard.getText()
        else: LogR((name,'alternate name canceled during modal'),C.LOGNONE)

        # addFav will delete any previous matching url
        normalized_name = addFav(favmode, name, url, img, desc, is_camsite, uuid=uuid) 

##        utils.Notify(u"{}ed fav:'{}' url:{}".format(fav.capitalize(),normalized_name,url))

    elif fav == "del":
        
##        if str(favmode) == str(int(C.MAIN_MODE_bongacams) + C.MODE_PLAY_OFFSET): #site needs special handling
##            url = '%stream_{}/playlist.m3u8'.format(name)
        delFav(url, img, name, icon_url, uuid=uuid)
##        utils.Notify(u"Deleted fav:{} url:{}".format(name,url))

    elif fav in ["rename"]:
        keyboard = xbmc.Keyboard(name, 'Rename', hidden=False)
        keyboard.doModal()
        if keyboard.isConfirmed(): keyboard_text = keyboard.getText()
        else: return
        Rename_Fav(url=url, name=keyboard_text, uuid=uuid)


    
    elif fav in ["rebuildXX","refresh"]:

##        C.DEBUG=True
        Log(fav)
        Log(uuid)

        binary_image = None
        description = ''
        save_folder = "special://home/cache/archive_cache"
        save_folder = C.translatePath(save_folder)

        query = Q.GET_FAV_UUID(FAV_DB_VERSION_CURRENT)
        params = (uuid,) 
        Log(query.replace("?", "'%s'") % params)
        result = favDB_cursor.execute(query, params).fetchone()
        if result:
            img = result['image']
            binary_image = result['binary_image']
            description = result['description'] 
        else:
            img=binary_image=description=''
        LogR((desc,description,img,binary_image))
            
    
        if save_folder in img: #currenly using a value in cache folder
            #check for a http location in order to updat he cached version
            Log('save_folder in img')
            if img.startswith(C.translatePath("special://home/")):
                img = None
                utils.Notify(u"Can't add/refresh fav when icon points to local file. Find an original source")
                return
        else:
            Log("img '{}' does not refer to an item in the local file cache".format(img))
            try:
                b=utils.getHtml(img)
##                LogR(( type(b), b ))
                raise Exception()
                binary_image = base64.b64encode(b)
            except Exception as e:
                binary_image = None
##                LogR(e)
                Log("either we will have the original image inside database, or we get new one from http")

        Log('todo calculate MIN_VALID_IMAGE_SIZE on a per-website basis', C.LOGWARNING)
        _MIN_VALID_IMAGE_SIZE = C.MIN_VALID_IMAGE_SIZE
        binary_image_length = 0
        if binary_image: binary_image_length = len(binary_image)
        if not (binary_image_length>_MIN_VALID_IMAGE_SIZE):
            Log('binary image is too small {}. Sometimes an empty face image is provided'.format(
                repr(str(binary_image_length)))
                ,C.LOGWARNING
                )
            binary_image = None

        if binary_image:
            Log("binary_image exists, no need to get a generic over using image url ")
            rebuilt_icon_url = img

        else: #there is no binary_image
            Log("get a new binary image from website")
            LogR(img)
##            Log(repr(len(binary_image)))
            rebuilt_icon_url = None
            try:
                get_sites = utils.Get_Sites(icon_function=True)
                for module, main_mode_id,sitename in get_sites:
                    module_play_mode_id = int(main_mode_id)+C.MODE_PLAY_OFFSET


                    if module_play_mode_id == favmode:

##                        LogR((module_play_mode_id,favmode),C.LOGWARNING)
                        
                        if 'Icon_Search' in dir(module):
                            method = getattr(module, 'Icon_Search')
                            rebuilt_icon_url = module.Icon_Search(url)
                            LogR(("rebuilt_icon_url",rebuilt_icon_url))
                            if rebuilt_icon_url:
                                img = rebuilt_icon_url

                            b=utils.getHtml(img)
                            binary_image = base64.b64encode(b)

                                
                        elif 'Camgirl_Generic_Image' in dir(module):
                            method = getattr(module, 'Camgirl_Generic_Image')

                            if '_MIN_VALID_IMAGE_SIZE' in dir(module):
                                _MIN_VALID_IMAGE_SIZE = module._MIN_VALID_IMAGE_SIZE
                                Log('{} _MIN_VALID_IMAGE_SIZE is {}'.format(
                                    sitename
                                    ,_MIN_VALID_IMAGE_SIZE
                                    )
                                    )

                            b = utils.getHtml(img)
                            current_http_image_size = len(b)
                            LogR( (img,current_http_image_size,_MIN_VALID_IMAGE_SIZE) )

                            if (current_http_image_size>_MIN_VALID_IMAGE_SIZE): #fav is online; save the online img

                                if module._BAD_IMAGE_SIZES: #add another check for known 'bad' images
                                    if not (current_http_image_size in module._BAD_IMAGE_SIZES):
                                        binary_image = base64.b64encode(b)
                                else:
                                    binary_image = base64.b64encode(b)
                                    
                            else:
                                if str(favmode)==mfc_PLAY_MODE :
                                    LogR(mfc_PLAY_MODE)
                                    if ("/img.mfcimg.com/" in img) or ("/snap.mfcimg.com/" in img)  :
                                        model_id_via_image = img.split('/')[6]
                                        Log(repr(model_id_via_image))
                                        if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                                            model_id_via_image = img.split('/')[5]
                                        #the 1 indicates model was in public chat when bookmark created
                                        if model_id_via_image.startswith("mfc_a_1"):
                                           model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
                                        if model_id_via_image.startswith("mfc_1"):
                                           model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
                                        if model_id_via_image[0] == '0':
                                            model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
                                        while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
                                            model_id_via_image = '0' + model_id_via_image
                                    rebuilt_icon_url = module.Camgirl_Generic_Image(model_id_via_image)
                                else:
                                    rebuilt_icon_url = module.Camgirl_Generic_Image(name)
                                    
                                Log(repr(rebuilt_icon_url)
                                    ,C.LOGNONE
                                    )
                                if rebuilt_icon_url:
                                    img = rebuilt_icon_url
                        else:
                            Log(repr((module.__name__, dir(module)))
                                ,C.LOGNONE
                                )
                            utils.Notify(u"Site '{} does not have an icon rebuild function".format(repr(module.__name__).split('.')[-1]))
                            #get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
                            return True
                            pass
                        get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
                    
            except StopIteration:
                pass
            except GeneratorExit:
                pass
            except:
                LogR(locals())
                raise 

        if C.PY3:
            if isinstance(binary_image, bytes):
                binary_image = binary_image.decode('utf8')
##        LogR(binary_image,1,True)
        if binary_image and not binary_image.startswith(('/9j/','UklG')):
            binary_image = base64.b64encode(binary_image)
        
        if binary_image: #re-write binary to local cache
            thumbcache = xbmc.getCacheThumbName(img).replace(".tbn", ".jpg")
            if thumbcache:
                thumb_filespec = "special://thumbnails/%s/%s" % (thumbcache[0], thumbcache)
                thumb_filespec = C.translatePath(thumb_filespec)
                f = xbmcvfs.File(thumb_filespec, 'w')
                f.write(base64.b64decode(binary_image))
                f.close()
                Log("binary image written to '{}'".format(thumb_filespec))
            else:
                Log('thumbcache {} is not cached'.format(repr(thumbcache)))
##                raise Exception(u"thumbcache '{}' is not cached".format(thumbcache))
        
        # description is only changed when it is originally blank
        if not description:
            description = "{}//{}".format(
                urlparse.urlparse(url).scheme
                ,urlparse.urlparse(url).netloc
                )
        if description == "//":
            description = "{}//{}".format(
                urlparse.urlparse(img).scheme
                ,urlparse.urlparse(img).netloc
                )
                
##        raise Exception(repr((description,url,img)))

        #everything except img, binary_image, description should stay
        (query, params) = Q.REFRESH_FAV(
            FAV_DB_VERSION_CURRENT
            , uuid = uuid
            , image = img
            , description = description
            , binary_image = binary_image
            )
        try:
            result = favDB_cursor.execute(query, params)
            result = favDB_conn.commit()
        except:
##            LogR((query,params))
            #log exact query during debugging
            params = list(params)
            params[1] = 'image_replaced_for_logging'
            params = tuple(params)
            Log(query.replace("?", "'{}'").format( *params ) ,C.LOGERROR)
            raise
        

    else:
        raise NotImplementedError('unhandled fav operation '+fav)

    #notify user of what we have done
    needs_an_e = '' if fav[-1] == 'e' else 'e'
    utils.Notify(u"{}{}d fav:'{}' url:{}".format(fav.capitalize(),needs_an_e,name,url))

#__________________________________________________________________
#
# insert/write binary to local cache if not already there
def Insert_Binary_Image(binary_image, uri_image, img_raw_type, name, texture_cursor=None):

    texture_filespec = xbmc.getCacheThumbName(uri_image)
##    Log(texture_filespec,C.LOGNONE)
    if img_raw_type == 'wbem':
        texture_filespec = texture_filespec.rstrip('.tbn').rstrip('.jpg')+'.wbem'
    else:
        texture_filespec = texture_filespec.rstrip('.tbn').rstrip('.jpg')+'.jpg'
                
    cachedurl_start = "special://thumbnails/"
    if texture_filespec:
        cachedurl_ending = "{}/{}".format(texture_filespec[0:1], texture_filespec)
        texture_filespec = C.translatePath(cachedurl_start+cachedurl_ending)
        #check filespec exists?
        if xbmcvfs.exists(texture_filespec):
##            Log(u"already cached '{}' thumbcache {} ".format(name,texture_filespec),C.LOGNONE)
            return texture_filespec
        else:
            Log(u"not found  {} texture_filespec {}".format(name, texture_filespec)
                ,C.LOGNONE
                )
            Log('todo: update instead of insert?',C.LOGWARNING)
            #reuse old random value but make sure ending correct
##            if binary_image[0:3].startswith(b'RIF'):
##                cachedurl_ending = cachedurl_ending.rstrip('.jpg')+'.wbem'
            
    else:
        Log("'{}' uri_image {} is not getCacheThumbName".format(name,uri_image)
            ,C.LOGNONE
            )
        #create a new item for this
        cachedurl_ending = "".join([random.choice(string.ascii_letters[0:7] + string.digits) for x in range(0,8)]).lower()
        cachedurl_ending = "{}/{}".format(cachedurl_ending[0:1], cachedurl_ending)
        if img_raw_type == 'wbem':
            cachedurl_ending = cachedurl_ending +'.wbem'
        else:
            cachedurl_ending = cachedurl_ending +'.jpg'
        

    #write file
    import string

    #add to database
##    if not texture_cursor:
##        texture_conn = sqlite3.connect(C.texture_DB_filespec)
##        texture_conn.text_factory = sqlite3.Row #note; wild cards not work with sqlite3.Row factory
##        texture_cursor = texture_conn.cursor()
    try:
        
        query = "INSERT INTO texture(url,cachedurl,imagehash,lasthashcheck) VALUES (?,?,?,?)"
        params = (uri_image, cachedurl_ending, '','')
##        LogR((query,params),C.LOGNONE)
        texture_cursor.execute(query, params)
        inserted_row_id = texture_cursor.lastrowid
##        LogR((inserted_row_id,),C.LOGNONE)
        query = "INSERT INTO sizes(idtexture,size,width,height,usecount) VALUES (?,?,?,?,?)"
        params = (inserted_row_id, 1, 320, 240, 0)
##        LogR((query,params),C.LOGNONE)
        texture_cursor.execute(query, params)
        inserted_row_id = texture_cursor.lastrowid
##        LogR((inserted_row_id,),C.LOGNONE)

        thumb_filespec = C.translatePath(cachedurl_start+cachedurl_ending)
##        LogR(thumb_filespec,C.LOGNONE)
        f = xbmcvfs.File(thumb_filespec, 'w')
        f.write(binary_image)
        f.close()
        Log(" '{}' binary written to '{}'".format(name,thumb_filespec),C.LOGWARNING)

    finally:
        texture_cursor.connection.commit()

    
    return thumb_filespec
                
#__________________________________________________________________
#
def Insert_fav_DB(
    name
    , url
    , mode
    , image
    , description
    , camsite
    , binary_image
    , uuid
    , is_binary=True
    
    ):

##    LogR((__name__, locals()))

    if not uuid: uuid = str(uuid4())

    if is_binary: binary_image = base64.b64encode(binary_image)
    if C.PY3:
        if isinstance(binary_image, bytes):
            binary_image = binary_image.decode('utf8')

    
    if FAV_DB_VERSION_CURRENT < 3:
        #too lazy to put params in Q code
        params = (
            name
            , url
            , mode
            , image
            , description
            , camsite
            , binary_image
            )
    else:
        params = (
            name
            , url
            , mode
            , image
            , description
            , camsite
            , binary_image
            , utils.UTC_timestamp()
            , uuid
        )
    query = Q.INSERT_FAV(FAV_DB_VERSION_CURRENT)

    try:    
        favDB_cursor.execute(query, params)
        favDB_conn.commit()
    except:
        LogR(("inserting", query, params), C.LOGWARNING)
        Log( (query.replace('?',"'%s'") % params), C.LOGWARNING)
        LogR((__name__, locals()), C.LOGWARNING)
        raise

#__________________________________________________________________
#
def image_to_local_cache(binary_image, file_type):
##    LogR((__name__, locals()))
    save_folder = "special://home/cache/archive_cache"
    save_folder = C.translatePath(save_folder)
    if file_type == '/9j/':
        suffix = '.jpg'
    elif file_type == 'UklG':
        suffix = '.webp'
    else :
        suffix = '.jpg'
    save_dest = tempfile.mktemp(dir=save_folder, suffix=suffix)
    save_dest = C.makeLegalFilename(save_dest)
    f = xbmcvfs.File(save_dest, 'w')
    f.write(binary_image)
    f.close()
    return save_dest

#__________________________________________________________________
#
def find_thumbnail_in_cache(url):

##    db_versio  xx = {
##         '17':13  # Krypton
##        ,'18':13  # Leia
##        ,'19':13  # Matrix
##        ,'20':13  # nexus
##        ,'21':13  #
##        ,'22':14  #
##    }
   #texture_conn = sqlite3.connect(C.translatePath("special://database/Textures13.db"))
##    LogR(C.xbmc_version,C.LOGNONE)
##    LogR(db_version[str(C.xbmc_version[0])],C.LOGNONE)
    texture_conn = sqlite3.connect(C.texture_DB_filespec)
    ##    texture_conn.text_factory = sqlite3.Row #note: wild cards not work with sqlite3.Row factory
##    texture_conn.text_factory = sqlite3.Row # sqlite3.Row or str #note: wild cards not work with sqlite3.Row factory
    texture_cursor = texture_conn.cursor()

##    #find the image that is currently showing; it will be copied as a new record
##    #query = "S ELECT * FROM texture WHERE (url LIKE ? ) AND NOT (url LIKE ?)"
##    #params = (  url+'%', '%' + 'fav_image=true'+'%' )
##    query = "S ELECT * FROM texture WHERE (url LIKE ? )"
##    params = (  (url+'%',) )
    
    normalized_url = url.split('|')[0].split('?')[0] #discard anti-caching unique timestamp
    query = "SELECT * FROM texture WHERE url LIKE ?"
    params = (  (normalized_url+'%',) ) #wildcard because icon may be cached with a apppended header
    Log(repr((query,params))
        ,C.LOGNONE
        )
    result = texture_cursor.execute(query, params)
    result = result.fetchone()
    Log("search for '{}' found ".format(url)
##        ,C.LOGNONE
        )
    Log("                 result '{}'".format(result)
##        ,C.LOGNONE
        )
    Log("                 result '{}'".format(repr(result))
##        ,C.LOGNONE
        )

##    return None

    if not result:
#        Log(repr((query,params)),C.LOGNONE)
#        Log("search for '{}' found result '{}'".format(url, result),C.LOGNONE)
        return None
        pass

    #texture_filespec = "special://thumbnails/" + result["cachedurl"] #todo
    cachedurl_index = [idx for idx, col in enumerate(texture_cursor.description) if col[0] == 'cachedurl'][0]
    
    texture_filespec = "special://thumbnails/" + result[cachedurl_index]
    
    texture_filespec = C.translatePath(texture_filespec)
    Log(repr(texture_filespec)
##        , C.LOGNONE
        )
    if not xbmcvfs.exists(texture_filespec):
        result = None
        
    
    return result


#__________________________________________________________________
#
def Clean_Textures_DB():
    pass
            

#__________________________________________________________________
#
def addFav(mode,name,url,img,description,camsite,uuid):
    LogR(("addFav", locals()))
##    Log("addFav {}".format(repr((mode,name,url,img,description,camsite))), C.LOGNONE)

##    import uuid
##    import xbmcvfs
##
##    #get image
##    #image can be in texture folder, or we can download latest
##    img_content = utils.getHtml(img)
##    #C:\Users\x\AppData\Roaming\Kodi\cache\archive_cache
##    #save image to our cache
##    save_folder = "special://userdata/addon_data/"+C.addon_id+'/cache/' + uuid.uuid4().hex + "." + name + '.jpg'
##    save_folder = "special://userdata/addon_data/"+C.addon_id+'/cache/' + name + "." + str(mode) + '.jpg'
##    save_dest = xbmc.translatePath(save_folder)
##    Log(save_dest, C.LOGNONE)
##    
##    f = xbmcvfs.File(save_dest, 'w')
##    f.write(img_content)
##    f.close()
##
##    Insert_fav_DB(name, url, mode, save_dest, description, camsite)
##
##    return name


##    texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db")) #13 is a constant that may need to be recalculated https://kodi.wiki/view/Databases
####    texture_conn.text_factory = sqlite3.Row #note; wild cards not work with sqlite3.Row factory
##    texture_cursor = texture_conn.cursor()

##    #find the image that is currently showing; it will be copied as a new record
##    query = "SELECT * FROM texture WHERE (url LIKE ? ) AND NOT (url LIKE ?)"
##    params = (  img+'%', '%' + 'fav_image=true'+'%' )
##    #Log(repr((query,params)),C.LOGNONE)
##    result = texture_cursor.execute(query, params).fetchone()
    result = find_thumbnail_in_cache(img)
    if (result is None) and img.startswith('special://'): #maybe mode has a way to generate img
        raise Exception()
                    
    if (result is None):
        msg = u"Can't find image to refresh with. Reload the container and/or check network container"
        Log(msg
            ,C.LOGNONE
            )
        img_content = utils.getHtml(img)
        LogR(img)
        if not img_content:
            if not description.endswith('/'): description+='/'
            header = {"Referer":description}
            if not (urlencode(header) in img):
                img = img + '&' + urlencode(header)
                img = img.replace("|","&_={}|".format(utils.RandomNumber()))
                img_content = utils.getHtml(img)
        Insert_fav_DB(name, url, mode, img, description, camsite, img_content, uuid=uuid)
        return name
    else:
        Log("icon already in kodi cache '{}'".format(repr(result)), C.LOGNONE)
        pass

##    #add our new, artificially generated fav icon                    
##    #keep track of this for later
##    texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db")) #13 is a constant that may need to be recalculated https://kodi.wiki/view/Databases
####    texture_conn.text_factory = sqlite3.Row #note; wild cards not work with sqlite3.Row factory
##    texture_cursor = texture_conn.cursor()
##        if binary_image: #re-write binary to local cache
##            thumbcache = xbmc.getCacheThumbName(img).replace(".tbn", ".jpg")
##            if thumbcache:
##                thumb_filespec = "special://thumbnails/%s/%s" % (thumbcache[0], thumbcache)
##                thumb_filespec = C.translatePath(thumb_filespec)
##                f = xbmcvfs.File(thumb_filespec, 'w')
##                f.write(base64.b64decode(binary_image))
##                f.close()
##                Log("binary image written to '{}'".format(thumb_filespec))
##            else:
##                Log('thumbcache {} is not cached'.format(repr(thumbcache)))
##    #find the image that is currently showing; it will be copied as a new record
##    query = "SELECT * FROM texture WHERE (url LIKE ? ) AND NOT (url LIKE ?)"
##    params = (  img+'%', '%' + 'fav_image=true'+'%' )
##    #Log(repr((query,params)),C.LOGNONE)
##    result = texture_cursor.execute(query, params).fetchone()
##    texture_size_to_copy_id = result[0]
##    #make img different so that it will not be accidentally
###          deleted during database clean operations
##    new_image = result[1]
##    if ("|" in new_image) and ("?" in new_image) :
##        new_image = new_image.replace("|", '&' + 'fav_image=true' + "|")
##    elif ("|" in new_image):
##        new_image = new_image.replace("|", '?' + 'fav_image=true' + "|")
##    else:
##        new_image = new_image + '?' + 'fav_image=true'
##    query = "I NSERT INTO texture(url,cachedurl,imagehash,lasthashcheck) VALUES (?,?,?,?)"
##    params = (new_image, result[2], result[3],'')
##    texture_cursor.execute(query, params)
##    inserted_row_id = texture_cursor.lastrowid
##    query = "S ELECT * FROM sizes WHERE (idtexture = ? ) "
##    params = (  texture_size_to_copy_id, )
##    size_to_copy = texture_cursor.execute(query, params).fetchone()
##    query = "I NSERT INTO sizes(idtexture,size,width,height,usecount,lastusetime) VALUES (?,?,?,?,?,?)"
##    params = (inserted_row_id, size_to_copy[1], size_to_copy[2], size_to_copy[3], size_to_copy[4], size_to_copy[5])
##    Log(repr((query,params)),C.LOGNONE)
##    exec_result = texture_cursor.execute(query, params)
##    texture_conn.commit()
##    texture_conn.close()

    #img_url = img.split("|")[0] #remove these extra kodi headers which can cause problems
    #img_content = utils.getHtml(img.split("|")[0])
    img_url = result[1]
    if "|" in img_url:
        headers = img_url.split("|")[1]
        img_url = img_url.split("|")[0]
        #stream_headers = urllib.unquote_plus( video_url.split('|')[1])
        #headers = urllib.unquote_plus(headers)
        headers = urlparse.parse_qs(headers.encode('ASCII'))
        h = {}
        for a in headers:
            h[a] = str(headers[a][0])
        headers = h
    img_content = utils.getHtml(img_url,headers=headers)

    Insert_fav_DB(name, url, mode, img, description, camsite, img_content, uuid=uuid)

    return name
#__________________________________________________________________
#
def Rename_Fav(url, name, uuid):
##    LogR(("Rename_Fav", locals()))
    try:
        (query,params) = Q.RENAME_FAV(FAV_DB_VERSION_CURRENT, name, url, uuid) 
        cursor_result = favDB_cursor.execute(query,params)
        LogR(cursor_result.rowcount)
    except:
        LogR(("Rename_Fav", locals()))
        traceback.print_exc()
    finally:
        favDB_conn.commit()
        pass
#__________________________________________________________________
#
def delFav(
    url
    , img
    , name
    , icon_url
    , uuid
    ):

    LogR(("delFav", locals()))


    #delete fav and fav_image if it exists
    try:

        (query,params) = Q.DELETE_FAV(FAV_DB_VERSION_CURRENT, url, uuid)
        cursor_result = favDB_cursor.execute(query,params)
##        Log(repr(cursor_result.rowcount),xbmc.LOGNONE)

        if img in (None,'','None','none','%'):
            return

        
        #try deleting via image for site where name is easily changable
        if "|" in img: img = img.split("|")[0]
        if "?" in img:
            if "?id=" in img:
                pass
            else:
                img = img.split("?")[0]

##        sql_command = "DELETE FROM favorites WHERE image LIKE '{}%{}%'".format(img, 'fav_image=true')
##        Log("sql_command='{}'".format(sql_command), C.LOGNONE)
##        favDB_cursor.execute(sql_command)

        Log(img)

        texture_conn = sqlite3.connect(C.texture_DB_filespec)
        ##    texture_conn.text_factory = sqlite3.Row #note: wild cards not work with sqlite3.Row factory
        texture_cursor = texture_conn.cursor()

        query = (
            " SELECT "
            " id "
            " , cachedurl "
            " , url "
            " FROM texture "
            " WHERE "
            " (url LIKE ? ) "
##            " and "
##            " (url LIKE ?) "
            )
        params = (
            img+'%'
## i don't know if using fav_image end-tag still needs to be done
##            , '%' + 'fav_image=true'+'%'
            ,
            )
        Log(query.replace("?", "'%s'") % params)  #see exact query during debugging

##        raise Exception('todo')
    
        for  texture_id, texture_image_cache, texture_url in texture_cursor.execute(query,params).fetchall():
            Log(repr((texture_id, texture_image_cache, texture_url)) ,C.LOGNONE)
            query = "DELETE FROM sizes WHERE idtexture = ?;"
            params = (texture_id,)
            Log(repr((query,params)) ,C.LOGNONE)
            texture_cursor.execute(query,params)
            query = "DELETE FROM texture WHERE id = ? ;"
            params = (texture_id,)
            Log(repr((query,params)) ,C.LOGNONE)
            texture_cursor.execute(query,params)
            try:
                filespec = "special://thumbnails/" + texture_image_cache
                filespec = C.translatePath(filespec)

                if xbmcvfs.exists(filespec):
                    os.remove(filespec)
            except:
                Log(repr(filespec),C.LOGWARNING)
                traceback.print_exc()
                pass
        texture_conn.commit()

    except:
        LogR(("delFav", locals()), C.LOGWARNING)
        traceback.print_exc()
    finally:
        favDB_conn.commit()

#__________________________________________________________________
#
