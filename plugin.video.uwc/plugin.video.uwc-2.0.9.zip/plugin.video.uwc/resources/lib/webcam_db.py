'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import sqlite3
import xbmc
import threading
import traceback

from xbmc import LOGNONE

import utils
from utils import Log as Log
from utils import get_setting as GetSetting

import constants as C
from constants import Queue

from sites.chaturbate import PLAY_MODE as chaturbate_PLAY_MODE
from sites.chaturbate import GetCamgirlList as chaturbate_getCamgirlList
from sites.chaturbate import URL_COUPLES as chaturbate_URL_COUPLES

from sites.cam4 import PLAY_MODE as cam4_PLAY_MODE
from sites.cam4 import GetCamgirlList as cam4_GetCamgirlList

from sites.streamate import PLAY_MODE as streamate_PLAY_MODE
from sites.streamate import GetCamgirlList as streamate_GetCamgirlList

from sites.naked import PLAY_MODE as naked_PLAY_MODE
from sites.naked import GetCamgirlList as naked_GetCamgirlList

from sites.myfreecams import PLAY_MODE as mfc_PLAY_MODE
from sites.myfreecams import getCamgirlList as mfc_getCamgirlList

##webcams_db = C.downloadsdb
webcams_db = C.favoritesdb
#__________________________________________________________________
#
def threaded(f, daemon=False):
    def wrapped_f(q, *args, **kwargs):
        ##this function calls the decorated function and puts the result in a queue
        try:
            ret = f(*args, **kwargs)
        except:
            Log("threaded return value to be put in queue")
            traceback.print_exc()
            q.put(None)
            return
        q.put(ret)
    def wrap(*args, **kwargs):
        ##this is the function returned from the decorator. It fires off
        ##wrapped_f in a new thread and returns the thread object with
        ##the result queue attached
        q = Queue.Queue()
        t = threading.Thread(target=wrapped_f, args=(q,)+args, kwargs=kwargs)
        t.daemon = daemon
        t.start()
        t.result_queue = q        
        return t
    return wrap
##@threaded
##def internal_bongacams_GetCamgirlList(depth, notify, progress_dialog):
##    return bongacams_GetCamgirlList(depth=depth, notify=notify, progress_dialog=progress_dialog)
@threaded
def internal_naked_GetCamgirlList(depth, notify, progress_dialog):
    return naked_GetCamgirlList(depth=depth, notify=notify, progress_dialog=progress_dialog)
@threaded
def internal_streamate_GetCamgirlList(depth, notify, progress_dialog):
    return streamate_GetCamgirlList(depth=depth, notify=notify, progress_dialog=progress_dialog)
@threaded
def internal_cam4_GetCamgirlList(depth, notify, progress_dialog):
    return cam4_GetCamgirlList(depth=depth, notify=notify, progress_dialog=progress_dialog)
@threaded
def internal_chaturbate_GetCamgirlList(depth, notify, progress_dialog):
    girls_json = chaturbate_getCamgirlList(depth=depth, notify=notify, progress_dialog=progress_dialog)
    couples_json = chaturbate_getCamgirlList(url = chaturbate_URL_COUPLES, depth=1, notify=notify, progress_dialog=progress_dialog)
    return girls_json+couples_json
@threaded
def internal_mfc_GetCamgirlList(depth, notify, progress_dialog):
    return mfc_getCamgirlList(notify=False)
#__________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_SERVICE_UPDATE)  
def service_update_db():
    Log("service_update_db")
    clear_webcam_db()
    fill_webcam_db()
#__________________________________________________________________
#
def create_webcam_db():
    Log("create_webcam_db")
    webcams_conn = sqlite3.connect(webcams_db)
    webcams_conn.execute("CREATE TABLE IF NOT EXISTS camlist (serverNumber, modelID, hq_stream, date, video_url, mode INTEGER DEFAULT NULL, icon_image, camscore, play_method, description, update_date DATETIME DEFAULT CURRENT_TIMESTAMP);")
    webcams_conn.commit() 
#__________________________________________________________________
#
def clear_webcam_db(interval_minutes=5):
    Log("clear_webcam_db({})".format(interval_minutes))
    create_webcam_db()
    import datetime
    now = datetime.datetime.utcnow()
    prev = now - datetime.timedelta(minutes=interval_minutes)
    sql_command_1 = "DELETE FROM camlist WHERE update_date < ?"    
    params = (prev.isoformat(sep=' '),)
    Log("sql_command_1='{}'  ".format(sql_command_1.replace('?', repr(prev.isoformat(sep=' ')))))
    webcams_conn = sqlite3.connect(webcams_db)
    webcams_conn.execute(
        sql_command_1
        , params
        )
    webcams_conn.commit() 
#__________________________________________________________________
#
def fill_webcam_db(progress_dialog=None):
    Log("fill_webcam_db")

    if GetSetting("enable_link_crawler", bool):
        create_webcam_db()
    else:
        clear_webcam_db()
        
    class Webcam_Site(object):
        def __init__( self, *args, **kwargs):
            self.json_list = kwargs["json_list"]
            self.thread_pointer = None #kargs["thread_pointer"]
            self.thread_function = kwargs["thread_function"]
            self.mode = kwargs["mode"]
            self.setting_string = kwargs["setting_string"]
            self.search_depth = kwargs["search_depth"]
            if not ("camlist_columns" in kwargs): kwargs["camlist_columns"] = None
            self.camlist_columns = kwargs["camlist_columns"]
            if not ("json_columns"    in kwargs): kwargs["json_columns"] = None
            self.json_columns = kwargs["json_columns"]
            pass

    webcam_sites = []

##    webcam_sites.append(
##        Webcam_Site(
##            json_list = None #will be filled later
##            ,thread_function = internal_bongacams_GetCamgirlList #function to fill json_list
##            ,mode = bongacams_PLAY_MODE
##            ,setting_string = "bongacams_girls_favorites"
##            ,search_depth = 3
##            ,camlist_columns = ' (modelID  , video_url, mode, icon_image, camscore, description) values '
##            ,json_columns    = ' (:username,:video_url,:mode,:icon_image,:camscore,:description)'
##        )
##    )
    webcam_sites.append(
        Webcam_Site(
            json_list = None #will be filled later
            ,thread_function = internal_cam4_GetCamgirlList #function to fill json_list
            ,mode = cam4_PLAY_MODE
            ,setting_string = "cam4_girls_favorites"
            ,search_depth = 2
            ,camlist_columns = ' (modelID  , video_url, mode, icon_image, camscore, description) values '
            ,json_columns    = ' (:username,:video_url,:mode,:icon_image,:camscore,:description)'
        )
    )
    webcam_sites.append(
        Webcam_Site(
            json_list = None #will be filled later
            ,thread_function = internal_chaturbate_GetCamgirlList #function to fill json_list
            ,mode = chaturbate_PLAY_MODE
            ,setting_string = "chaturbate_girls_favorites"
            ,search_depth = 3
            ,camlist_columns = ' (modelID  , video_url, mode, icon_image, camscore, description) values '
            ,json_columns    = ' (:username,:video_url,:mode,:icon_image,:camscore,:description)'
        )
    )
    webcam_sites.append(
        Webcam_Site(
            json_list = None #will be filled later
            ,thread_function = internal_mfc_GetCamgirlList #function to fill json_list
            ,mode = mfc_PLAY_MODE
            ,setting_string = "mfc_girls_favorites"
            ,search_depth = 1
            ,camlist_columns = ' (  modelID, video_url, mode, icon_image, camscore, description) values '
            ,json_columns =    ' (:username,:video_url,:mode,:icon_image,:camscore,:description)'
        )
    )
    webcam_sites.append(
        Webcam_Site(
            json_list = None #will be filled later
            ,thread_function = internal_naked_GetCamgirlList #function to fill json_list
            ,mode = naked_PLAY_MODE
            ,setting_string = "naked_girls_favorites"
            ,search_depth = 1
            ,camlist_columns = ' (  hq_stream,  modelID, video_url, mode, icon_image, camscore, description) values '
            ,json_columns =    ' (:video_host,:username,:video_url,:mode,:icon_image,:camscore,:description)'
        )
    )
    webcam_sites.append(
        Webcam_Site(
            json_list = None #will be filled later
            ,thread_function = internal_streamate_GetCamgirlList #function to fill json_list
            ,mode = streamate_PLAY_MODE
            ,setting_string = "streamate_girls_favorites"
            ,search_depth = 2
            ,camlist_columns = ' (modelID  , video_url, mode, icon_image, camscore, description) values '
            ,json_columns =    ' (:username,:video_url,:mode,:icon_image,:camscore,:description)'
        )
    )

    webcams_conn = sqlite3.connect(webcams_db)
    query = "select * from camlist where mode LIKE ?"
    
    for webcam_site in webcam_sites:
        try:
            Log("setting_string='{}'".format(webcam_site.setting_string))
            if GetSetting(webcam_site.setting_string):
                webcam_site.json_list = webcams_conn.execute(query, (webcam_site.mode,) ).fetchall()
                Log("{}={}".format(webcam_site.setting_string,len(webcam_site.json_list)))
                #if the database is empty [or zero items] for this site, then prepare/start a thread that will get data for the database
                if (not webcam_site.json_list) or (webcam_site.json_list and len(webcam_site.json_list) < 1):
                    Log("{}={}".format(webcam_site.setting_string,"to_be_filled"))
                    try:
                        webcam_site.thread_pointer = webcam_site.thread_function(depth=webcam_site.search_depth, notify=False, progress_dialog=progress_dialog)
                    except:
##                        Log("inside")
                        traceback.print_exc()
                else:
                    webcam_site.thread_pointer = None
##                Log(repr(webcam_site.thread_pointer))
        except:
##            Log("outside")
            traceback.print_exc()

    try:
        try:
            for webcam_site in webcam_sites:
                if webcam_site.thread_pointer:
                    Log("starting search for '{}'".format(webcam_site.setting_string))
                    #read the result - note this is just the start of the fuction so that logging end is pointless
                    webcam_site.json_list = webcam_site.thread_pointer.result_queue.get(timeout=C.FAVORITE_LISTING_TIMEOUT)
                    
        except Queue.Empty:
            pass
        except:
            Log("result_queue.get")
            traceback.print_exc()
        finally:
            #any searches we did 'manually'; insert into dabase as cache
            webcams_conn = sqlite3.connect(webcams_db)
            webcams_cursor = webcams_conn.cursor()

            for webcam_site in webcam_sites:
                Log("finally for '{}'".format(webcam_site.setting_string))
                # when webcam_site.thread_pointer is not None and has produced results [as
                #    shown by webcam_site.json_list] add those results to the database [using
                #    using the well known columns] so that later code can use it
                if webcam_site.thread_pointer and webcam_site.json_list and webcam_site.camlist_columns and webcam_site.json_columns:
                    Log(webcam_site.setting_string)
                    webcams_cursor.executemany(
                        'insert into camlist ' + webcam_site.camlist_columns + webcam_site.json_columns
                         , webcam_site.json_list
                        )
##                    Log("len(webcam_site.json_list)='{}'".format(len(webcam_site.json_list)))
                    Log("webcams_cursor.rowcount)='{}'".format(webcams_cursor.rowcount))
            webcams_conn.commit()
            return webcams_conn
    except:
        traceback.print_exc()
#__________________________________________________________________
#
