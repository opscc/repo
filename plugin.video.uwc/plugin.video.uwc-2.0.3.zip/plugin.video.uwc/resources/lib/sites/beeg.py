'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import constants as C
from base_website import Base_Website
from utils import Log,LogR
import utils

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Beeg[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = True
    
    _ROOT_URL        = "https://beeg.com"
    _URL_CATEGORIES  = "https://store.externulls.com/tag/facts/tags?get_original=true&slug=index"#2021-09-12
    _URL_RECENT      = "https://store.externulls.com/facts/tag?id=27173&"  #2021-09-12
    _SEARCH_URL      = "https://store.externulls.com/facts/tag?slug={}&get_original=true&" 
    _MAIN_MODE = C.MAIN_MODE_beeg
    _FIRST_PAGE = 1


##    _size_filter = 400

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
##    _ITEMS_NOT_FOUND_INDICATORS = [
##        "<p>Make sure that all words are spelled correctly.</p>"
##        , "No videos found for "
##        ]

    #__________________________________________________________________________
    #
    _REGEX_icon_search = (
        '.+?poster=\\\\"(?P<thumb>[^\\\\]+)\\\\'
        )
    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
        Log(u"Icon_Search url={}, pattern={}, referer={}".format(repr(url),repr(pattern),repr(referer))
##            , C.LOGNONE
            )

        videoid = url.split('facts/file/')[1].split('/')[0]
        thumb = 'https://thumbs.externulls.com/videos/{}/{}.webp?size=480x270'.format(
            videoid
            ,utils.RandomNumber(return_integer=True,length=1)
            )
        LogR(thumb,C.LOGNONE)
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = referer
        return thumb + utils.Header2pipestring(headers)
    
    #__________________________________________________________________________
    #specific header required for listing
    _LIST_HEADERS = {
        "Accept":"application/json, text/plain, */*"
        ,"DNT":"1"
        ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0"
        ,"Origin":"https://beeg.com"
        ,"Referer":"https://beeg.com/"
        ,"Accept-Encoding":"gzip, deflate"
        ,"Accept-Language":"en-US,en;q=0.9"
    }
    #where we can find videos on this page [exclude advertisement]
    #_REGEX_video_region = ('class="main"(.+?)class="divrectr"')
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        '\n  {'
        '(?P<duration>'
            '.+?"cd_file": (?P<videourl>\d+),'
            '.+?"cd_value": "(?P<label>.+?)",'
            '.+?"fl_height": (?P<hd>\d+),'
            '.+?"id": (?P<thumb>\d+)\s'
        "(?P<desc>)"
        '.+?)\n  }'
##        '"fc_facts":'
##        '(?P<duration>'
##            '.+?"cd_file": (?P<videourl>\d+),'
##            '.+?"cd_value": "(?P<label>.+?)",'
##            '(?:.+?"fl_duration": \d+?)'
##        '),'
##        '.+?"fl_height": (?P<hd>\d+),'
##        '.+?"id": (?P<thumb>\d+)\s'
##        "(?P<desc>)"
        )
    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None#C.PLAYMODE_F4MPROXY #None = show all options  C.PLAYMODE_F4MPROXY

    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = "(.)" #'href="([^"]+)">Next '

    #__________________________________________________________________________
    #where categories can be found
    #_REGEX_categories_region = "id='categoryList'(.+)"
    _REGEX_categories = (
        '"tg_name": "(?P<label>[^"{]+)",'
        '.+?"tg_slug": "(?P<videourl>[^"{]+)"'
        '(?P<thumb>)'
        )
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        url = "https://store.externulls.com/facts/tag?slug={}&".format(url)
        return url
    #__________________________________________________________________________
    #where playable urls live
    _REGEX_playsearch_01 = (
        'fl_cdn_(?P<res>\d+)'
        '.+?"(?P<url>key=[^"]+?)"'
        )
    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by site
    def Video_Source_URL_Normalize(self, url):
        url = "https://video.beeg.com/{}".format(url)
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = "https://beeg.com/" 
        from utils import Header2pipestring as Header2pipestring
        url = url + Header2pipestring(headers)
        return url
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags = '"tg_name": "([^"]+)"'    #'"pornstar_tag".+?>([^<]+)<'
    _REGEX_tags_region = "(.+)"           #'class="categorieswrapper(.+?)<noscript>'
    #__________________________________________________________________________
    # add an alternative way to resolve listing
    def List_URL_Normalize(self, url, page):
        url = url + "limit=48&offset={}"
        url = url.format(48*(int(page)-1))
        return url
    #__________________________________________________________________________
    # add update duration as necessary
    def Normalize_Duration(self, duration):
##        LogR(locals(),C.LOGWARNING)
##        C.DEBUG = True
        try:
            import json
            d_json = json.loads('[{' + duration + '}]')
            d_json=d_json[0]
##            LogR(d_json,include_type=True)
            fc_end = d_json['fc_facts'][0]['fc_end']
            fc_start = d_json['fc_facts'][0]['fc_start']
            if fc_end == fc_start:
                duration = d_json['file']['fl_duration']
            else:
                duration = fc_end - fc_start
            
        except:
            raise
            regex = '"fl_duration": (?P<end>\d+)'
            info = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(duration)
            for item in info:
                duration = int(item.group('end'))
                break

##            
##        if '"_completeness": "Full-To-Clip"' in duration or \
##           '"_completeness": "Full-4-Clip"' in duration :
##            regex = 'fc_created".+?"fc_end": (?P<end>\d+).+?"fc_start": (?P<start>\d+)'
##            info = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(duration)
##            for item in info:
##                start = item.group('start')
##                end = item.group('end')
##                duration = int(end)-int(start)
##        else:
##            regex = '"fl_duration": (?P<end>\d+)'
##            info = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(duration)
##            for item in info:
##                duration = int(item.group('end'))
##                break
##        LogR(duration,C.LOGWARNING)
        return duration
    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
##        LogR(locals(),C.LOGWARNING)
        from utils import RandomNumber as RandomNumber
        thumb_url = "https://thumbs.externulls.com/"
        frame = "{}".format( (int(max(100,duration))//10) + (int(RandomNumber(length=1))) )  #Site allows global frame grabs...10% into vid seems ok...but the official list is ordered in such a way to make regex capture too hard
        thumb = "{}videos/{}/{}.webp?size=480x270".format(thumb_url, thumb, frame)
        return thumb
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
##        LogR(locals(),C.LOGWARNING)
        videourl = "https://store.externulls.com/facts/file/{}".format(videourl)
        return videourl
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        #note: site actually uses websockets to generate a 'slug' value for some searches
        # but I don't want to worry for this low quality site
        keyword = keyword.replace("'", "")
        return keyword.replace('+',' ').replace(' ','')
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        #note: site actually uses websockets to generate a 'slug' value for some searches
        # but I don't want to worry for this low quality site
        search_url = search_url.format(keyword)
        return search_url
    #__________________________________________________________________________
    # Change LIST to enable max recurse depth
    def List(self, url, page_start=None, page_end=None, end_directory=True
             , keyword='', testmode=False, progress_dialog=None
             , bulk_operation=False
             ):
        org = C.MAX_RECURSE_DEPTH
        if C.PY3:                       super().List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
        if C.PY2: super(Specific_Website, self).List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
        C.MAX_RECURSE_DEPTH = org
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page_start', 'page_end', 'bulk_operation'])
def Search(searchUrl, keyword=None, end_directory=True, page_start=website._FIRST_PAGE, page_end=website._FIRST_PAGE, progress_dialog=None, bulk_operation=False):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page_start=page_start, page_end=page_end, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
