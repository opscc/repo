'''
    Ultimate Whitecream
    Copyright (C) 2018 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import json
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]Hentai Haven[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_HENTAI
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://hentaihaven.co"
SEARCH_URL = ROOT_URL + '/wp-admin/admin-ajax.php'
URL_RECENT = ROOT_URL + '/wp-admin/admin-ajax.php'
#URL_CATEGORIES_1 = ROOT_URL + '/genre/hentai-uncensored/page/{}/'
#URL_CATEGORIES_1 = ROOT_URL + '/genre/hentai-uncensored-on/page/{}/'
URL_CATEGORIES_1 = ROOT_URL + '/uncensored1/page/{}/'
URL_CATEGORIES_2021 = ROOT_URL +  '/genre/2021/page/{}/'
URL_CATEGORIES_2020 = ROOT_URL +  '/genre/2020/page/{}/'
URL_CATEGORIES_2019 = ROOT_URL +  '/genre/2019/page/{}/'
URL_CATEGORIES_2018 = ROOT_URL +  '/genre/2018/page/{}/'
URL_CATEGORIES_2017 = ROOT_URL +  '/genre/2017/page/{}/'
URL_CATEGORIES_2016 = ROOT_URL +  '/genre/2016/page/{}/'
URL_CATEGORIES_2015 = ROOT_URL +  '/genre/2015/page/{}/'

MAIN_MODE          = C.MAIN_MODE_hentaihaven
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
REFRESH_MODE       = str(int(MAIN_MODE) + 4)
SEARCH_MODE        = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#

@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(
          end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)


##    headers = {
##        "User-Agent": C.USER_AGENT
##        , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
##        , "Accept": "*/*"
##        , "Origin": ROOT_URL
##        , "X-Requested-With": "XMLHttpRequest"
##        , "Referer": ROOT_URL
##        , "Accept-Encoding": "gzip"
##        , "Accept-Language": "en-US,en;q=0.9"
##    }
    headers = C.DEFAULT_HEADERS.copy()
    headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    headers["Referer"] = ROOT_URL
    
    data = "action=action_pagination&genre=all&page={}&typex=newest&search={}&pagetype=home".format(page, 'all')
    video_region = utils.postHtml(url, sent_data=data, headers=headers)
   
    if "but no results were found" in video_region or "No hay articulos" in video_region:
        video_region = ''

    Parse_List_Items(video_region, keyword, testmode)

    #
    # next page items
    #
    np_info = 'fake'  #2020-08 site does not have working last page, im not going to work for it
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_number=int(page) + 1
        np_url = url
        Log("np_url={}".format(np_url))
        if end_directory == True:
            utils.addDir(
                name= C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url)  #let user know something is happening
                List(url=np_url
                     , end_directory=end_directory
                     , keyword=keyword
                     , page=np_number)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
def Parse_List_Items(video_region, keyword, testmode):

    #
    # parse out list items
    #
    regex = '<a class="thumbnail-image".+?src="([^"]+)".+?class="tags">(.+?)class="description".+?href="([^"]+)">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #Log("info={}".format(info))
    if len(info) < 1:
        info = []
        
    for thumb, other, videourl, label  in info:
        hd = utils.Normalize_HD_String(label)
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("other={}".format(other))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , desc = ROOT_URL
            , iconimage = thumb)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)


    return True

#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("url='{}',name='{}',download='{}',playmode_string='{}'".format(url,name,download,playmode_string))
    if playmode_string:
        max_video_resolution=int(playmode_string)
    else:
        max_video_resolution = None
    description = name + '\n' + ROOT_URL



    html = utils.getHtml(url, ROOT_URL)
    regex = '<iframe src="([^"]+)"'
    next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)[0]

    html = utils.getHtml(next_link, url)
    isHLS = False
    try:
        #working 2020-07
        from resources.lib import jsunpack
        unpacked_src = jsunpack.unpack(html)
        Log("unpacked_src='{}'".format(unpacked_src))
        
        regex = 'sources:(\[.*?\])'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
        Log("sources_list='{}'".format(sources_list))
        sources = json.loads(sources_list[0])
        Log("sources='{}'".format(sources))
        Log("sources[file]='{}'".format(sources[0]['file']))
        video_url = sources[0]['file']

    except:
        #working 2020-08
        regex = 'FirePlayer\(vhash, (.+), false\);'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
        Log("sources_list='{}'".format(sources_list))
        sources = json.loads(sources_list[0])
        Log("sources='{}'".format(sources))
        video_url = "https://htstreaming.com{}?s={}&d=".format(sources['videoUrl'], sources['videoServer'])
        #https://htstreaming.com/cdn/hls/b4351fbdd294cc1f13037ff2e7cb9d6d/master.txt?s=sv2&d=
        #https://htstreaming.com/cdn/hls/d249a6fc7236089b3bfe84fde25f9d59/master.txt/?s=sv2&d=
        Log("video_url={}".format(video_url.encode()))
        isHLS = sources['videoData']['videoSources'][0]['type'] == u'hls'

    if isHLS:
        playmode_string = C.PLAYMODE_F4MPROXY
    else:
        playmode_string = None
        
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = next_link
    video_url +=  utils.Header2pipestring(headers)  #required or else acces denied
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name, download, description=description, playmode_string=playmode_string)
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, '')
    regex = '<li.+?class=".+?menu-item-object-post_tag.+?"><a href="(.+?)">(.+?)</a></li>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    for videourl, label in info:
        keyword = videourl.split('tag/')[1].split('/')[0]
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=C.search_icon 
            ,keyword=keyword
            )

    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, testmode=False):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(
          end_directory, keyword, SEARCH_URL, SEARCH_MODE, searchUrl, page)
        
    url = searchUrl

    headers = C.DEFAULT_HEADERS.copy()
    headers["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    headers["Referer"] = ROOT_URL

    data = "action=action_update_search_term&term={}".format(keyword)
    page_html = utils.postHtml(url, sent_data=data, headers=headers)
    search_results_regex = 'href="([^"]+)"'
    sub_pages = re.compile(search_results_regex, re.DOTALL | re.IGNORECASE).findall(page_html)
    for sub_page in sub_pages:
        page_html = utils.getHtml(sub_page, ROOT_URL)        
        Parse_List_Items(page_html, keyword, testmode)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#

 
