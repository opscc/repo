# coding=UTF8
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]mrsexe[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_SCENES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.mrsexe.com"
SEARCH_URL = ROOT_URL + "/?search={}"
URL_CATEGORIES = ROOT_URL
URL_RECENT = ROOT_URL + '/videos/page{}.html'

MAIN_MODE          = C.MAIN_MODE_mrsexe
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='',testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html

    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if "Aucun r&eacute;sultat pour cette recherche" in listhtml:
        video_region = ""
        listhtml = ""
    else: #distinguish between adverts and videos
        video_region = listhtml.split('thumb-list xxlarge-block-grid-5')[1].split('<ul class="right pagination">')[0]

    # parse out list items
    regex = '<li class="[^"]*">\s<a class="thumbnail" href="([^"]+)">\n<script.+?</script>\n<figure>\n<img  id=".+?" src="([^"]+)".+?/>\n<figcaption>\n<span class="video-icon"><i class="fa fa-play"></i></span>\n<span class="duration"><i class="fa fa-clock-o"></i>([^<]+)</span>\n(.+?)\n'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, duration, label in info:
        label = u"{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label))
        duration = duration.strip().replace('h ', ':00').replace(' min', ":00")
        if not thumb.startswith('http'): thumb = 'http:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        #Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    

    # next page items
    try:    
        next_page_html = listhtml.split('pagination')[1]
    except:
        next_page_html = ""
    next_page_regex = '<li class="arrow"><a href="([^\.]+?)\.html">suivant</a></li>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        #Log("np_url={}".format(np_url))
        np_number = int(page) + 1
        np_url = url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth:
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    #this site's search will return too many partial matches; contat to one word
    key = ''
    key2 = keyword.split('+')
    for k in key2:
        if len(k) > 3:
            key = key + '+' + k
    if key2:
        keyword = key.lstrip('+')
    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(title)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    html = utils.getHtml(url, ROOT_URL)
    cathtml = html.split('Cat&eacute;gories</option>')[1]
    
    regex = 'value="(/cat[^"]+)">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label in info:
        label = u"{}[COLOR {}]{}[/COLOR]".format(C.SPACING_FOR_NAMES, C.search_text_color, utils.cleantext(label)) 
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
        videourl += "page{}.html"
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=C.search_icon 
            )
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))

    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    html = utils.getHtml(url)
    second_url = re.compile(r"src='(/inc/clic\.php\?video=.+?&cat=mrsex.+?)'").findall(html)
    html = utils.getHtml('https://www.mrsexe.com' + second_url[0], '')

    #2019-05-21
    videourls = re.compile("HDtoggle\(('[^\)]+)", re.DOTALL).findall(html)
##    Log("videourls={}".format(repr(videourls)))
    #site may have multiple sources, but does not tell us the quality very well. First seems best
    if videourls:
        video_url = videourls[0].split(",")[-1].strip("'")
        #videourls = sorted(videourls, key=lambda tup: tup[1], reverse=True)
        #videourl = videourls[0][0]
    else:
        videourls = re.compile("\.src\(\"([^\"]+)\"", re.DOTALL).findall(html)
        video_url = videourls[0]
    if video_url.startswith('//'): video_url = 'http:' + video_url


    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
