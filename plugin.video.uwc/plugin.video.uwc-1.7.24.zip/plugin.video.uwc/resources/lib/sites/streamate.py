'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import sqlite3
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]StreamMate[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.streamate.com"
COOKIE_LOADER = ROOT_URL # +'/?Xld_rct=1' #this site needs some cookies to be loaded
#URL_FEMALES = 'http://api.naiadsystems.com/search/v1/list?results_per_page={}' 
##URL_FEMALES = 'https://member.naiadsystems.com/search/v3/performers?domain=streamate.com&from={}&size={}&useProductScore=false&enableProfileScore=false&enableLocalBoostIQForUSOnly=true&filters=gender:f,ff%3Bonline:true&boostedFilters=true&excludedFilters=&country=&language=en&genderSetting=f'
##https://member.naiadsystems.com/search/v3/performers?domain=streamate.com&from=0&size=48&useProductScore=false&enableProfileScore=false&enableLocalBoostIQForUSOnly=false&filters=gender:f,ff,mf,tm2f,g%3Bonline:true&boostedFilters=&excludedFilters=&country=CA&language=en&genderSetting=f
URL_FEMALES = ROOT_URL + '/search.php?F_0=504&filter_rating=none&results_per_page={}&sort_feature=none&sort_language=none&sort_region=none&pagenum={}&sssjson=1'
#https://www.streamate.com/search.php?filter_rating=none&results_per_page=50&sort_feature=none&sort_language=none&sort_region=none&pagenum=2&sssjson=1
#F_0=503& is male


SEARCH_URL = 'stub - make all sites consistent'

MAIN_MODE       = C.MAIN_MODE_streamate
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
REFRESH_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)
TEST_MODE       = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

RESULTS_PER_PAGE = 41

THUMBNAILS_FOR_SITE = "object-cdn.icfsys.com"

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():

    List(URL_FEMALES, page=FIRST_PAGE, end_directory=True, keyword='')

#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page=1, depth=1, notify=False):

    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    if '{}' in url and page:
        list_url = url.format(int(RESULTS_PER_PAGE) * (int(depth)), page)  #format the string to give us the exact number we need e.g. if depth=2 we should return RESULTS_PER_PAGE*2
##        list_url = url.format( int(RESULTS_PER_PAGE) * (int(depth)-1), int(RESULTS_PER_PAGE))

    Log("list_url='{}'".format(repr(list_url)))

    headers = C.DEFAULT_HEADERS.copy()
    headers['Accept'] = 'application/json, text/javascript, */*; q=0.01'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    
    json_html = utils.getHtml(list_url,headers=headers, save_cookie=True)

##    return {}
    

    json_items = json.loads(json_html)['Results']
    #json_items = json.loads(json_html)['performers']
    
    for json_item in json_items:
##        Log("json_item={}".format(repr(json_item)))
        performerID = str(json_item['PerformerId'])
        #performerID = str(json_item['id'])
        #icon_image = "http://m1.nsimg.net/media/snap/" + performerID + ".jpg"
        icon_image = "https://object-cdn.icfsys.com/smconnect-snapshots/320x240/" + performerID + ".jpg"
        #https://object-cdn.icfsys.com/smconnect-snapshots/320x240/52840205.jpg
        #thumbnail=https://m2.nsimg.net/biopic/320x240/39181575
        video_url = performerID
        name = utils.cleantext(json_item['Nickname'])
        #name = utils.cleantext(json_item['nickname'])
        #Log("name='{}'".format(name))
##        camscore = json_item['rating']
        camscore = json_item['SortScore']
        camscore = json_item['Rating']
        hd = ''
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, name, hd)

        json_item['username'] = name
        json_item['icon_label'] = label
        json_item['icon_image'] = icon_image
        json_item['video_url'] = name
        json_item['camscore'] = camscore
        json_item['mode'] = PLAY_MODE
        json_item['description'] = '\n' + ROOT_URL
        json_item['play_method'] = '' #blank so that defaut method is chosen a play time
        
        
    return json_items

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=FIRST_PAGE, end_directory=True, keyword=''):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))
    
    if end_directory == True:    
        utils.Add_Refresh_Item(REFRESH_MODE)
        
    models = GetCamgirlList(url=url, page=page)
    for model in models:
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            , date = model['username']
            )
        
    np_number = int(page) + 1
    np_url = url
    if end_directory == True:
        utils.addDir(
            name= C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
            ,url=np_url 
            ,mode=LIST_MODE 
            ,iconimage=C.next_icon 
            ,page=np_number
            ,keyword=keyword )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def clean_database(showdialog=True):
    #return True
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % THUMBNAILS_FOR_SITE)
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % THUMBNAILS_FOR_SITE)
            if showdialog:
                utils.notify('Finished','streamate.com images cleared')
    except:
        pass
#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name', 'img'], ['playmode_string', 'download', 'play_profile'])
def Playvid(url, name, icon_URI, download=None, playmode_string=None, play_profile=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None #final playable url


    #
    # do stuff to get a playable url
    #
    
    name = url
    
    response = utils.getHtml("https://streamate.com/ajax/config/?name=" + name + "&sakey=&sk=streamate.com&userid=0&version=2.2.0&ajax=1")
    data = json.loads(response)
    Log("data='{}'".format(data))
    performerID = int(data['performer']['id'])

    if performerID %2 == 0:
        host = "sea1c"
    else:
        host = "sea1b"
    json_url = ("https://{}-ls.naiadsystems.com/{}-edge-ls/80/live/s:{}.json{}".format(
                    host
                    ,host
                    ,name 
                    ,"?last=load&format=mp4-hls"
                    )
                )
    Log("json_url='{}'".format(json_url))

    streamate_headers = C.DEFAULT_HEADERS.copy()
    streamate_headers['Referer'] = "{}/cam/{}".format(ROOT_URL, name)
    streamate_headers['Accept'] = "application/json"
##    Log("streamate_headers='{}'".format(streamate_headers))
    referer = "{}/cam/{}".format(ROOT_URL, name)
##    Log("referer='{}'".format(referer))
    
    json_html = utils.getHtml(json_url, referer=referer, headers=streamate_headers, ignore404=True, ignore403=True)
    if not json_html:
        utils.Notify("{} is unavailable".format(name))
        return

    json_data = json.loads(json_html)
    #Log("json_data='{}'".format(json_data))

    video_url = json_data['formats']['mp4-hls']['manifest']
    Log("video_url='{}'".format(video_url))

    if playmode_string == C.PLAYMODE_INPUTSTREAM:
        Log("inputstream does not work for this site ... going direct")
        playmode_string = C.PLAYMODE_DIRECT

    video_url = "{}{}".format(video_url, utils.Header2pipestring(streamate_headers) )
    Log("video_url='{}'".format(video_url)  )

##    from resources.lib import downloader
##    download_filespec = downloader.Make_download_path(name = name, include_date = True, file_extension = '.ts')
##    utils.playvid(video_url, name, download, description=ROOT_URL, playmode_string=playmode_string, play_profile=play_profile, download_filespec=download_filespec )

    #calculate potential download name here because I want to include recording date
    from resources.lib import downloader
    download_filespec = downloader.Make_download_path(
        name = name
        , include_date = True
        , file_extension = '.ts'
        )

    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return   #during testmode, only ensure that a url can be generated

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI
        , repeat_when_available = True
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    #stub
    return True
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))

    #stub
    return True
#__________________________________________________________________________
#
