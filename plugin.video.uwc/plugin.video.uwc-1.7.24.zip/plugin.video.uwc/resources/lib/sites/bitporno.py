'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]bitporno[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.bitporno.com"
SEARCH_URL = ROOT_URL + '/?q={}&or=&cat=&sort=recent&time=someday&length=all&view=0&page={}&user='
URL_CATEGORIES = ROOT_URL + '/?q='
URL_RECENT = ROOT_URL + '/?q=&or=&cat=&sort=recent&time=someday&length=all&view=0&page={}&user='

MAIN_MODE          = C.MAIN_MODE_bitporno
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '0'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, ROOT_URL)#, ignore404=True , send_back_redirect=True)
    if "Page Not Found" in listhtml:
        video_region = ''
        listhtml = ''
    else:
        try:
            regex = 'id="search_results"(.+)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            video_region = listhtml
        #Log("video_region={}".format(video_region))

    # parse out list items
    regex = '<div class="[^"]*entry[^>]*>.*?((?:<div class="thumbnail-hd">HD</div>|))\s*<a class="[^"]+" href="([^"]+)".*?<img src="([^"]+)".*?</a>\s*<div[^>]*>([^<]+)</div>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for hd, videourl, thumb, label  in info:
        #Log("label={}".format(label))
        label=label.replace('Serakon.com - Download movies porn', '')
        label=label.replace('- VseX.in More videos porn  -', '')
        label=label.replace('- Pornxcity.com', '')
        label=label.replace('- Pornvex.com', '')
        hd = utils.Normalize_HD_String(hd)        
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        thumb = thumb + utils.Header2pipestring() + "Referer=" + ROOT_URL
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , desc = '\n' + ROOT_URL
            , iconimage = thumb )
            #, duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    

    # next page items
    try:
        regex = 'id="search_results"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
    next_page_regex = '<a href="([^"]+)" class="pages">Next</a>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
            np_url = url
            np_number = int(page) + 1
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page) == '-1'))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)
    #Log("listhtml={}".format(listhtml))

    regex = '>Categories</span>(.+?)<div id="search_ajax"'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    #Log("listhtml={}".format(listhtml))
    
    regex = '<a href="([^"]+)">([^<]+)</a>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label   in info:
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = C.html_parser.unescape(videourl).replace("page-0", "page-{}")
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=C.search_icon)
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download', 'play_profile'])
def Playvid(url, name, playmode_string=None, download=None, play_profile=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None #final playable url
    sources_list = None #intermediate var
    download_filespec = None
    videos_list = list() #hold multiple video_url when possible
        
    source_html1 = utils.getHtml(url, ROOT_URL)
#    source_html1 = 'poster="https://www153.playercdn.net/thumb/1/190716/722G5251PIU4VIFNS3DVD.jpg" style="width:100%; height:600px;">        <source src="https://www179.playercdn.net/86/3/auiZXjjV3FCLyE0SR3F3ww/1563331841/190716/836G529SC862EZB0KSUHS.mp4" type="video/mp4" label="480p" data-res="480" selected="true" /><source src="https://www227.playercdn.net/87/3/24E418Xex8i_P3g2gW0zfQ/1563331841/190716/722G5252RL8LRJJXRFSAY.mp4" type="video/mp4" label="720p" data-res="720" /><source src="https://www50.playercdn.net/88/3/vnk42g1HQgFkLh6hlDm-eA/1563331841/190716/723G5253SIOB3F5L2R6JN.mp4" type="video/mp4" label="1080p" data-res="1080" /></video></div><div class="clear"></div>'
    regex = 'jwplayer.+?file: "([^"]+)"' #works 2020-08
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
    Log("sources_list={}".format(sources_list))
    if sources_list: video_url = sources_list[0]

##    if not video_url:
##        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
##        return
##    
##    headers = C.DEFAULT_HEADERS.copy()
##    headers['Referer'] = url
##    video_url = video_url + utils.Header2pipestring(headers)
##    Log("video_url='{}'".format(video_url))
####    return
##    utils.playvid(video_url, name=name, download=download, description=description)

    #what if we fail to get a url??
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return

    #always set referrer so that 'kodi' does not appear to the target server
    if '|' not in video_url:
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        video_url = video_url + utils.Header2pipestring(headers)

##    from resources.lib import downloader
##    download_filespec = downloader.Make_download_path(name = name, include_date = True, file_extension = '.ts')

    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return   #during testmode, only ensure that a url can be generated

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        )
#__________________________________________________________________________
#
