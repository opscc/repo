'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]amateurcool[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.amateurcool.com"
SEARCH_URL = ROOT_URL + '/search/videos/{}/page1.html'
URL_CATEGORIES = ROOT_URL + '/channels/'
URL_TOP_RATED = ROOT_URL + '/top/'
URL_RECENT = ROOT_URL + '/most-recent/page{}.html'

MAIN_MODE          = C.MAIN_MODE_amateurcool
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
        
        
    # read html
    redirected_url = None
    listhtml = utils.getHtml(list_url, ignore404=True) # , ignore404=True)#, ignore404=True , send_back_redirect=True)
    if redirected_url: list_url = redirected_url
    if "no results were found" in listhtml or 'requested file was not found on this server' in listhtml:
        listhtml = ''
        video_region = ''
        next_page_html = ''
    else:
        next_page_html = listhtml.split('<div class="pagination_')[1]
        if 'main class="' in listhtml:
            video_region = listhtml.split('main class="')[1]
        else:
            video_region = listhtml

    # parse out list items
    regex = '<a href="([^"]+)".+?duration.+?class="item__stat-label">([^<]+)<.+?src="([^"]+)".+?alt="([^"]+)"(.)'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, duration, thumb, label, hd in info:
        if not (':' in duration): continue #how i skip photosets
        hd = utils.Normalize_HD_String(hd)
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label),hd)
        thumb = thumb.replace(' ','%20')
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = "https:" + videourl
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration
            )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    # next page items
    next_page_regex = "title='Next' href='([^\']+)'"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_url = url
        np_number=int(page)+1
        Log("np_number={}".format(np_number))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number 
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

##    raise Exception("fake 4 testing")

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace(' ','-').replace('+','-').replace('_','-')
    searchUrl = SEARCH_URL.format(title)
    Log("searchUrl='{}'".format(searchUrl))    
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    Log("Categories(url='{}',end_directory='{}'".format(url, end_directory))

    cathtml = utils.getHtml(url)
    cathtml = cathtml.split('main class="')[1].split('-sec-main')[0]
    regex = 'href="([^"]+)" title="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label in info:
        if not videourl.startswith('http'): videourl = "https:" + videourl
        videourl += "page{}.html"
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=C.search_icon
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
        
    page_html = utils.getHtml(url, referer=ROOT_URL)
    regex = 'title=\'Best Quality\' src=\"([^"]+)"'
    video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(page_html)[0]   

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
