'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os.path
import sys
import traceback
import xbmc
import xbmcplugin
import service

from resources.lib import downloader
from resources.lib import favorites
from resources.lib import utils
from resources.lib.sites import * #required for registering modes into dispatcher
from resources.lib.utils import Log
from resources.lib import constants as C

if int(sys.argv[1]) > 0: 
    xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available

#__________________________________________________________________________
# random dev stuff
@C.url_dispatcher.register("devtest")
def TempDevTest():

    Log('pycrypt not available using slow decryption') #, xbmc.LOGNONE)
    USEDec=3 ## 1==crypto 2==local, local pycrypto

    import array
    import base64
    from f4mUtils import python_aes
##    from f4mUtils import openssl_aes

    pass_ph = '5ee595b1c1150a9bb64ab546cc2e4e28' #was hex string; then base64decoded
    Log(repr(pass_ph))
    Log(repr(base64.b64encode(pass_ph)))
    Log(repr(array.array('B',base64.b64encode(pass_ph))))

    iv = (
        'f8b83c54b42e8f03'
        )
##            5ee595b1c1150a9bb64ab546cc2e4e28    
####          123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
####          4e57566c4e546b31596a466a4d5445314d474535596d49324e4746694e54513259324d795a54526c4d6a673d
##            4e57566c4e546b31596a466a4d544531
##            4d474535596d49324e4746694e545132
##            59324d795a54526c4d6a673d
    key  = (
        '2a265272f02233b6'
        'f5a6bbc5008bdd5b'
        )
##    key="NWVlNTk1YjFjMTE1MGE5YmI2NGFiNTQ2Y2MyZTRlMjg="
##    key = base64.b64decode(key)
#    iv = ''

    MODE_CBC = 2
    BLOCK_SIZE = 16
    def pad(data):
        length = BLOCK_SIZE - (len(data) % BLOCK_SIZE)
        return data + chr(length)*length
    def unpad(data):
        return data[:-ord(data[-1])]
    def encrypt(message, key, IV):
        #IV = Random.new().read(BLOCK_SIZE)
        aes = python_aes.new(key, MODE_CBC, IV)
        return base64.b64encode(IV + aes.encrypt(pad(message)))
    def decrypt(encrypted, key):
        encrypted = base64.b64decode(encrypted)
        IV = encrypted[:BLOCK_SIZE]
        ivb = array.array('B',IV)
        aes = python_aes.new(key, MODE_CBC, ivb)
        tt = aes.decrypt(encrypted[BLOCK_SIZE:])
        return unpad(tt)

    ivb=array.array('B',iv)
    keyb= array.array('B',key)
    Log("python_aes.new(keyb, MODE_CBC, ivb)")
    Log("keyb={}".format(repr(keyb)))
    Log("ivb={}".format(repr(ivb)))
    MODE_CBC = 2
    enc=python_aes.new(keyb, MODE_CBC, ivb)
##    enc=openssl_aes.new(keyb, 2, ivb)


    chunk = "Ygy+6ap2h0PB5sCy3s1OhNpgYsSayyyD7wFLdJ0K4JnNhydK0FTvxxbqwB02DoM423Dgukk4uLh1by60MLi9rSIqj3eg0Yad8PEHIXav82xduDDsjgfTRyqYNN+prdWjfBG+a08SXM2xJM+EjyxPbwbTMmYX7twRfwzcKxLs79uEpH36X3A/kLpew2Ydv8jsHT2oEWdz4LQVhcC971qo+4BBZUbDX+LIdCon26uleK3UpQPKIWuBkcn01Zj/LzMlk3agSq8mHEnIWFUrdnYOMjoqyFsmyTkpbtIhdzLwVPc="

##    Log(repr(decrypt(chunk, keyb)))

    #chunk = chunk[BLOCK_SIZE:]
    chunk = base64.b64decode(chunk)
#    chunk = pass_ph + chunk
#    Log("array")
    chunkB = array.array('B',chunk)
    Log("chunkB={}".format(repr(chunkB)))
##    Log("decrypt")
    chunk = enc.decrypt(chunkB)
##    Log("join")
    chunk = "".join(map(chr, chunk))
    #Log('end decrypting chunk, USEDec={}'.format(USEDec))
    Log(repr(chunk))
##    Log('afterdecrypting' + repr(chunk.encode('utf8')))


#url = 'https://dood.to/e/4la4btw5nspt'
#import resolveurl
#u = resolveurl.resolve(url)
#Log(repr(u), xbmc.LOGNONE)
#Log(repr(sys.version), xbmc.LOGNONE)
#Log('')
##xx = utils.getHtml("https://www.imdb.com/chart/top" )
##import requests
##xx = requests.get(
##    "https://www.imdb.com/chart/top" 
##    , headers={'User-agent': 'Mozilla/5.0'}
##    , timeout=20)
    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_INDEX)
def INDEX():
    if C.DEBUG:
        utils.addDir(
            name = '[COLOR {}]Test All[/COLOR]'.format(C.test_text_color)
            ,url = C.DO_NOTHING_URL
            ,mode = C.ROOT_TEST_ALL
            ,Folder = True)
        utils.addDir(
            name = '[COLOR {}]Webcam Scan[/COLOR]'.format(C.test_text_color)
             ,url = C.DO_NOTHING_URL
             ,mode = C.ROOT_SERVICE_UPDATE
             ,Folder = False)
        utils.addDir(
            name = '[COLOR {}]Webcam Record ScanStart[/COLOR]'.format(C.test_text_color)
             ,url = C.DO_NOTHING_URL
             ,mode = C.ROOT_SERVICE_SCAN_START
             ,Folder = False)
        utils.addDir(
            name = '[COLOR {}]Latest DevTest[/COLOR]'.format(C.test_text_color)
             ,url = C.DO_NOTHING_URL
             ,mode = "devtest"
             ,Folder = True)

    utils.addDir('[COLOR {}]Search All[/COLOR]'.format(C.search_text_color)            ,'',C.ROOT_SEARCH_ALL   ,iconimage=C.search_icon) #, contextMenu=test_all_context_menu)
    utils.addDir('[COLOR {}]Front Pages[/COLOR]'.format(C.refresh_text_color)          ,'',C.ROOT_FRONT_PAGE   ,iconimage=C.search_icon)
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Scenes'.format(C.program_text_color)    ,'',C.ROOT_INDEX_SCENES)
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Movies'.format(C.program_text_color)    ,'',C.ROOT_INDEX_MOVIES) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Hentai'.format(C.program_text_color)    ,'',C.ROOT_INDEX_HENTAI) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Tubes'.format(C.program_text_color)     ,'',C.ROOT_INDEX_TUBES) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Webcams'.format(C.program_text_color)   ,'',C.ROOT_INDEX_CAMS) 
    utils.addDir('[COLOR {}]Whitecream[/COLOR] Favorites'.format(C.program_text_color) ,'',C.ROOT_INDEX_FAVORITES)

    download_path = utils.get_setting('download_path', str)
    if download_path and os.path.exists(download_path):
        utils.addDir(
            name = '[COLOR {}]Whitecream[/COLOR] Download Folder'.format(C.program_text_color)
            ,url = download_path
            ,mode = C.ROOT_INDEX_DOWNLOAD_FOLDER
            ,Folder = False)
    if len(downloader.active_downloads()) > 0 or utils.get_setting('debug'):
        utils.addDir(
            name = '[COLOR {}]Background Downloads[/COLOR]'.format(C.highlight_text_color)
            , url = C.DO_NOTHING_URL
            , mode = C.ROOT_MANAGE_DOWNLOADS
            , Folder=True)
    utils.addDir(
        name='[COLOR {}]Settings[/COLOR]'.format(C.refresh_text_color)
        ,url = C.DO_NOTHING_URL
        ,mode = C.CONFIGURE_THIS_ADDON
        ,Folder=False)

    utils.endOfDirectory(cacheToDisc=False)
#__________________________________________________________________________
# display long-scene sites
@C.url_dispatcher.register(C.ROOT_INDEX_SCENES)
def INDEXS():
    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(C.LIST_AREA_SCENES):
        utils.addDir(friendly,root_url,mode,icon_filespec)
        
    utils.endOfDirectory()
#__________________________________________________________________________
# display full movie sites
@C.url_dispatcher.register(C.ROOT_INDEX_MOVIES)
def INDEXM():
    for friendly, root_url, mode, icon_filespec in utils.Get_Sites(C.LIST_AREA_MOVIES):
        #Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
# display short-clip sites
@C.url_dispatcher.register(C.ROOT_INDEX_TUBES)
def INDEXT():
    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(C.LIST_AREA_TUBES):
##        Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
# display webcam sites
@C.url_dispatcher.register(C.ROOT_INDEX_CAMS)
def INDEXW():
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_CAMS):
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
# display hentai sites
@C.url_dispatcher.register(C.ROOT_INDEX_HENTAI)
def INDEXH():
    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_HENTAI):
        utils.addDir(friendly,root_url,mode,icon_filespec)

    utils.endOfDirectory()
#__________________________________________________________________________
# display first page of some sites
@C.url_dispatcher.register(C.ROOT_FRONT_PAGE, ['page'], ['keyword'])
def Front_Page(page=1,keyword=None):
    #temporarilty force only X recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 0

    import Queue
    import threading

    get_sites = utils.Get_Sites()
    q = Queue.Queue()
    i = 0
    all_method_results = {}
    try:
        for sitename, module in get_sites:
            if i > 2: break #testing

            if module.FRONT_PAGE_CANDIDATE == True:
                if utils.get_setting(sitename + '_on_front_page'):
##                    i = i + 1 #testing
                    all_method_results[sitename] = None
                    method_to_call = getattr(module, 'List')
                    kwargs = {
                        "url": module.URL_RECENT
                        ,"end_directory": False
                        ,"page": module.FIRST_PAGE}
                    q.put((sitename,method_to_call,kwargs))

        for k in range(C.MAX_WEBCRAWLER_THREADS):
            worker = threading.Thread(target=utils.crawl, args=(q,all_method_results))
            worker.daemon = False
            worker.start()
        q.join()
        get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
    except StopIteration:
        pass
    except:
        traceback.print_exc()

    at_least_one = False
    for result in all_method_results:
        if all_method_results[result] in [None, True]:
            at_least_one = True
            break
            
    if not at_least_one:
        utils.addDir(name='[COLOR {}]Add Sites to this via Settings[/COLOR]'.format(C.refresh_text_color)
            ,url=C.DO_NOTHING_URL
            ,iconimage=C.search_icon
            ,mode=C.ROOT_INDEX_INDEX
            ,Folder=False)

    utils.endOfDirectory()        
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_DOWNLOAD_FOLDER, ['url'])
def OpenDownloadFolder(url):
    xbmc.executebuiltin("ActivateWindow(Videos, {})".format(url))
#__________________________________________________________________________
#
def change():
    if os.path.isfile(C.uwcchange):
        heading = '[B][COLOR {}]Whitecream[/COLOR] Changelog[/B]'.format(C.program_text_color)
        utils.textBox(heading,C.uwcchange)
        os.remove(C.uwcchange)
#__________________________________________________________________________
# edit settings.xml file as necessary
def Dynamic_Front_Pages_Options():
    
    settings_file = os.path.join(C.rootDir, 'resources', "settings.xml")
    import xml.etree.ElementTree as ET
    tree = ET.ElementTree(file=settings_file)

    font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
    if font_pages_element_tree is None:
        ET.SubElement(parent=tree.find("."),tag='category',attrib={'label':"Front Pages"})

    font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
    if font_pages_element_tree is None:
        pass

    for elems in font_pages_element_tree:
        elems.clear()
        elems.attrib['label'] = "Front Pages"
        for sitename, module in utils.Get_Sites():
            try:
                if hasattr(module,"website"):   # experimental; use a class for all websites
                    module = module.website
            except:
                traceback.print_exc()
                pass
            if 'FRONT_PAGE_CANDIDATE' in dir(module):
                if module.FRONT_PAGE_CANDIDATE == True:
                    ET.SubElement(parent=elems,tag='setting',attrib={'id':sitename + '_on_front_page','label':sitename + '_on_front_page','default':'false','type':'bool'})
            
    tree.write(settings_file)
#__________________________________________________________________________
#
def main(argv=None):
    if sys.argv: argv = sys.argv
    queries = utils.parse_query(sys.argv[2])
    mode = queries.get('mode', None)
    try:
        mode_via_url = sys.argv[0].split('/')[3]
        mode = str(int(mode_via_url))
    except:
        pass

    Dynamic_Front_Pages_Options()
    try:
        C.url_dispatcher.dispatch(mode, queries)
    except:
##        Log("mode='{}'".format(mode),xbmc.LOGNONE)
        raise
#__________________________________________________________________________
#
if __name__ == '__main__':
##    change()
    sys.exit(main())
#__________________________________________________________________________
#
