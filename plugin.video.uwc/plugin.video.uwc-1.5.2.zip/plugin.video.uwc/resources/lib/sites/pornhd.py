'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://www.pornhd.com"

SEARCH_URL = ROOT_URL + '/search?search={}'

URL_CATEGORIES = ROOT_URL + '/category'
URL_RECENT = ROOT_URL + '/?page={}'

URL_TOPRATED = ROOT_URL + "/top-rated-porn-videos/page/{}/"
URL_MOSTVIEWED = ROOT_URL + "/most-viewed-porn-videos/page/{}/"

MAIN_MODE       = '540'
LIST_MODE       = '541'
PLAY_MODE       = '542'
CATEGORIES_MODE = '543'
SEARCH_MODE     = '544'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    listhtml, redirected_url = utils.getHtml(list_url, send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "Sorry, no videos found" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword, ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('id="pageContent"')[1].split('class="pager')[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    #
    # parse out list items
    #
    regex = '(?:src|data-original)="([^"]+\.webp).+?time>([^<]+)<.+?title" href="([^"]+)">([^<]+)'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for thumb, duration, videourl, label in info:
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in label: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        #thumb = thumb + "|Referer=" + list_url
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        #Log("duration={}".format(duration))
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration=duration )



    #
    # next page items
    #
    try:
        next_page_html = listhtml.split('class="pager')[1]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = 'class="next ">.+?data-query-value="([^"]+)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_number in np_info:
            np_number = int(np_number)

                
            if redirected_url:  #sometimes site will 301 the url and that should now be the new one
                if '?page=' in redirected_url:
                    np_url = redirected_url.split('?page=')[0] + str(np_number)
                else:
                    np_url = redirected_url + '?page=' + str(np_number)
            else:
                np_url = url

            Log("np_url={}".format(np_url))
            if not '?page=' in np_url:
                np_url = np_url + '?page=' + str(np_number)
            else:
                np_url = np_url.split('?page=')[0] + '?page=' + str(np_number)
                
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number))
            if end_directory == True:
                utils.addDir(
                    name=np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url, '')
 
    regex = '<a href="(/c/\w+[-]\d+)" class="btn btn-default">([^"]+)</a>'
    regex = 'a href="(/category/[^"]+)".+?alt="([^"]+)".+?data-original="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label, thumb in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, label) 
        #if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
##    videopage = utils.getHtml(url, ROOT_URL, NoCookie=False) #this site needs a cookie to play
##    cookiestring = ''
##    for cookie in utils.cj:
##        #Log("cookie.domain={}".format(cookie.domain))
##        #Log("cookie.name={}".format(cookie.name))
##        
##        if cookie.domain == "www.pornhd.com" and cookie.name=="phd-ses":
##            h = "{}={}".format(cookie.name,cookie.value)
##            headers = { 'Cookie': h  }
##            cookiestring = "{}&{}".format(utils.Header2pipestring(),urllib.urlencode(headers)  )
##            Log("cookiestring={}".format(cookiestring))
##        
##    return

    videopage = utils.getHtml(url, ROOT_URL, save_cookie=True) #this site needs a cookie to play
    regex = ',sources: ({"[^}]+})'
    sources_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    #Log("sources_html={}".format(sources_html))
    sources_dict = json.loads(sources_html)
    #Log("sources_dict={}".format(sources_dict))
    list_key_value = [ [k,v] for k, v in sources_dict.items() ] #convert dict to list for the next function
    video_url = ROOT_URL + utils.SortVideos(list_key_value,0)

    Log("video_url={}".format(video_url))
    
    #this site needs a cookie to play video
    cookiestring = ''
    for cookie in utils.cj:
        if cookie.domain == "www.pornhd.com" and cookie.name=="phd-ses":
            h = "{}={}".format(cookie.name,cookie.value)
            headers = { 'Cookie': h  }
            cookiestring = "{}&{}".format(utils.Header2pipestring(),urllib.urlencode(headers)  )
            Log("cookiestring={}".format(cookiestring))

    video_url = video_url + cookiestring

    utils.playvid(video_url, name, download, description='')

#__________________________________________________________________________
#
