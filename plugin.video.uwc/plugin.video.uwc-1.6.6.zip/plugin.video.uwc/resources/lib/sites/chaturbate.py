'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import sqlite3
import urllib
import urllib2
import gzip
import StringIO
import xbmc
import xbmcplugin
import xbmcgui
import json
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://chaturbate.com"

SEARCH_URL = ROOT_URL + '/?s={}'

URL_RECENT = ROOT_URL + "/female-cams/?page={}"

URL_COUPLES = ROOT_URL + "/couple-cams/?page={}"


MAIN_MODE          = '220'
LIST_MODE          = '221'
PLAY_MODE          = '222'
REFRESH_MODE       = '224'
CLEANDATABASE_MODE = '223'


cb_headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
    'Accept': '*/*',
    'Referer': ROOT_URL,
    'Accept-Encoding': 'gzip'
     }
#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(
        name="{}[COLOR {}]Couples[/COLOR]".format(SPACING_FOR_TOPMOST,utils.search_text_color) 
        ,url=URL_COUPLES
        ,page='1'
        ,mode=LIST_MODE
        ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='1')

#__________________________________________________________________________
#
def GetCamgirlList(url=URL_RECENT, page=1, depth=1, notify=False):

    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    depth = int(depth)
    
    json_items = json.loads("[]")
    hq_bonus = int(utils.addon.getSetting("hq_bonus").lower())

    while depth > 0:
        
        if '{}' in url and page: list_url = url.format(page)
        else: list_url = url
        listhtml = utils.getHtml(list_url, ROOT_URL)


        videos_regex = ('<li class="room_list_room"'
                        '.+?<a href="([^"]+)"'
                        '.+?data-room="([^"]+)"'
                        '.+?img src="([^"]+)"'
                        '.+?class="cams"'
                        '.+?(\d+)\sviewers')
        info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
        for video_url, name, icon_image, viewers in info:

            if not video_url.startswith('http'): video_url = ROOT_URL + video_url
            hd = ''
            camscore = int(viewers)*hq_bonus #always get a bonus
            icon_label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(name), hd)

            json_item = {}
            json_item['username'] = name
            json_item['icon_label'] = icon_label
            json_item['icon_image'] = icon_image
            json_item['video_url'] = video_url
            json_item['camscore'] = camscore
            json_item['mode'] = PLAY_MODE
            json_item['description'] = '\n' + ROOT_URL
            json_item['play_method'] = 'f4mproxy'

            json_items.append(json_item)

        #recurse depth some more
        page = int(page) + 1
        depth = int(depth) - 1 
        
    return json_items


        
##    #
##    # main list items
##    #
##    videos_regex = '<li class="room_list_room".*?<a href="([^"]+)">.*?img src="([^"]+)".*?<div[^>]+>([^<]+)<\/div>.*?href[^>]+> ([^<]+)<.*?age[^>]+>([^<]+).*?,\s(\d+)\sviewers'
##    videos_regex = '<li class="room_list_room".+?<a href="([^"]+)".+?data-room="([^"]+)".+?' \
##                +  'img src="([^"]+)".+?class="cams".+?(\d+)\sviewers'
##    info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
##    for videourl, label, thumb, viewers in info:
##        hd = ''
##        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        utils.addDownLink( 
##            name = label 
##            , url = videourl 
##            , mode = PLAY_MODE 
##            , iconimage = thumb
##            , duration=int(viewers)*hq_bonus
##            , play_method='f4mproxy')
        
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'addon_handle'])
def List(url, page=None, end_directory=True, keyword='1', addon_handle=None):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

##    if int(page) % 2 == 1:
##        if end_directory == True:    
##            utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
##                SPACING_FOR_TOPMOST, utils.refresh_text_color) 
##                ,url='' 
##                ,mode=REFRESH_MODE 
##                ,iconimage=utils.refresh_icon)

    if end_directory == True:   
        utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.refresh_text_color) 
            ,url='' 
            ,mode=REFRESH_MODE 
            ,iconimage=utils.refresh_icon)


    models = GetCamgirlList(url, page, depth=int(keyword))
    for model in models:
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            )

    #
    # next page items
    #
    np_number = int(page) + 1
    np_url = url
    np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)

    recurse_levels = utils.DEFAULT_RECURSE_DEPTH
    contextMenuItems = []
    keyw = (
        "{}".format(sys.argv[0]) +
        "?url={}".format(urllib.quote_plus(url)) +
        "&mode={}".format(LIST_MODE) +
        "&keyword={}".format(recurse_levels) +
        "&page={}".format(urllib.quote_plus(str(page))) +
        "&end_directory=True" 
        )        
    contextMenuItems.append( (
        "{}[COLOR {}]Recurse ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, recurse_levels)
        , "xbmc.ActivateWindow(Videos,{})".format(keyw)  )  )
##            , "xbmc.RunPlugin({})".format(keyw) )  )

    list_item = utils.addDir(
        name= np_label
        ,url=np_url 
        ,mode=LIST_MODE 
        ,iconimage=utils.next_icon 
        ,page=np_number
        ,keyword=keyword
        ,contextMenu=contextMenuItems
        ,contextMenuReplace=False
        )


##    Log("addon_handle={}".format(addon_handle), xbmc.LOGNONE)
##    if addon_handle == None:
##
##        Log("utils.addon_handle={}".format(utils.addon_handle), xbmc.LOGNONE)
##        addon_handle = int(sys.argv[1])
##        Log("addon_handle={}".format(addon_handle), xbmc.LOGNONE)
##        
##        
##        list_item = xbmcgui.ListItem(np_label, iconImage=utils.next_icon, thumbnailImage=utils.next_icon)
##        list_item.setProperty('IsPlayable', 'false')
##        contextMenuItems = []
####            "&img={}".format(urllib.quote_plus(utils.next_icon) ) +
####            "&name={}".format(urllib.quote_plus(np_label)) +        
##        keyw = (
##            "{}".format(sys.argv[0]) +
##            "?url={}".format(urllib.quote_plus(URL_RECENT)) +
##            "&mode={}".format(LIST_MODE) +
##            "&keyword={}".format(urllib.quote_plus('2')) +
##            "&addon_handle={}".format(addon_handle) +
##            "&page={}".format(urllib.quote_plus(str(page))) +
##            "&end_directory=True" 
##            )        
##        contextMenuItems.append( (
##            'Recurse 10'
##            , "xbmc.ActivateWindow(Videos,{})".format(keyw)  )  )
####            , "xbmc.RunPlugin({})".format(keyw) )  )
##        
##        list_item.addContextMenuItems(contextMenuItems, replaceItems=True)
##        u  = ''
##        xbmcplugin.addDirectoryItem(handle=addon_handle, url=np_url, listitem=list_item, isFolder=True)


##        if section and section == INBAND_RECURSE:
##            #below will not work well because the 'back' button will return to root of addon, and not where I want     
##            u2 = u.replace("&keyword=" + urllib.quote_plus(str(keyword)), "&keyword=" + INBAND_RECURSE)
##            u2 = u2.replace("&page=" + str(page), "&page=" + str(int(page)-1)) #include the page we are on
##            u2 = u2.replace("&page=" + str(page), "&page=1")  #include the page we are on
##            contextMenuItems.append( (
##                "[COLOR {}]Recurse to Page {}[/COLOR]".format(search_text_color, MAX_RECURSE_DEPTH)
##                , "xbmc.ActivateWindow(Videos,{})".format(u2)  )  )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

##    if int(page) % 2 == 1:
##        #Log("page mod {}".format(int(page) % 2), xbmc.LOGNONE)
##        List(url, page=int(page)+1, end_directory=end_directory, keyword=keyword)
##    else:
##        #
##        # next page items
##        #
##        if not listhtml == "": 
##            next_page_html = listhtml.split('class="paging"')[1]
##        else:
##            next_page_html = ""
##        next_page_regex = 'href="([^"]+)" class="next endless_page_link".+?>next</a>'
##        np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
##        if not np_info:
##            Log("np_info not found in url='{}'".format(list_url))
##        else:
##            for np_url in np_info:
##                np_number = int(page) + 1
##                np_url = url
##                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
##                if end_directory == True:
##                    utils.addDir(
##                        name= np_label
##                        ,url=np_url 
##                        ,mode=LIST_MODE 
##                        ,iconimage=utils.next_icon 
##                        ,page=np_number
##                        ,keyword=keyword )
##                else:
##                    if int(np_number) <= MAX_SEARCH_DEPTH: #search some more, but not forever
##                        utils.Notify(msg=np_url, duration=200)  #let user know something is happening
##                        List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
##                    else:
##                        utils.add_sort_method()
##                        utils.endOfDirectory()
##                    
##        if end_directory == True:
##            utils.add_sort_method()
##            utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CLEANDATABASE_MODE)
def clean_database(showdialog=True):
    return #don't clean up image database until we figure out how to get images for off-line models
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".highwebmedia.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try:
                    os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except:
                    pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".highwebmedia.com")
            if showdialog:
                utils.notify('Finished','Chaturbate images cleared')
    except:
        pass

#__________________________________________________________________________
#
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    return True

#__________________________________________________________________________
#

def Test(keyword):

    return True
    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download', 'megabitratebonus'])
def Playvid(url, name, playmode_string = '', megabitratebonus=0, download = False):

    Log ("Playvid url='{}', name='{}', playmode_string='{}', megabitratebonus='{}', download='{}'".format(url, name, playmode_string, megabitratebonus, download), xbmc.LOGNONE  )


    #
    # do stuff to get a playable url
    #

    listhtml = utils.getHtml(url, headers=cb_headers)
    #Log("listhtml='{}'".format(listhtml), xbmc.LOGNONE)

    #we skip a few regex sections because json can't parse them
    regex = 'window.initialRoomDossier = "({.+), \\\\u0022edge_auth\\\\u0022.+?\\\\u0022}\\\\u0022(.+), \\\\u0022chat_password\\\\u0022.+?\\\\u0022}\\\\u0022(.+), \\\\u0022apps_running\\\\u0022.+?\\\\u0022\]\\]\\\\u0022(.+})";'
    #Log("regex='{}'".format(regex))
    m3u8url = re.compile(regex, re.DOTALL).findall(listhtml)
    if m3u8url:
        m3u8url = m3u8url[0]

    if m3u8url:
        qq = ""
        for a in m3u8url:
            Log(a)
            qq += a.decode('unicode_escape')

        m3u8url = qq
        #Log("m3u8url='{}'".format(m3u8url)) #can't log this because my logger can't handle some of the escape sequences
        #Log("m3u8url='{}'".format(m3u8url))

        m = json.loads(m3u8url)
        Log("m='{}'".format(m))
        
        Log("hls_source='{}'".format(m['hls_source']))
        Log("room_status='{}'".format(m['room_status']))    

        if m['room_status'] == 'public':
            m3u8stream = m['hls_source']
        else:
            m3u8stream = None
    else:
        m3u8stream = None


    video_url = re.compile(regex, re.DOTALL).findall(listhtml)
    if m3u8stream:
        video_url = m3u8stream
    else:
        utils.notify(name,'Couldn\'t find a playable webcam link')
        return
    
    Log("video_url='{}'".format(video_url)  )


    #
    # play url as needed
    #
    
    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    listitem.setContentLookup(False)

    max_bit_rate = (int(utils.addon.getSetting('max_bit_rate')) + int(megabitratebonus)) * 1000 * 1000
    default_playmode = utils.addon.getSetting('default_playmode').lower()  #allow playmode to be forced by input command, or use default from addon settings

    if playmode_string == 'f4mproxy':
        pass
    elif playmode_string == 'inputstream':
        pass
    else:
        playmode_string = default_playmode
    if download == True:
        Log("f4mproxy video_url - only this mode can capture")
        playmode_string == 'f4mproxy'
    Log("playmode_string='{}'".format(playmode_string)  )
    

    if playmode_string == '': # direct
        video_url = "{}{}".format(video_url, utils.Header2pipestring(cb_headers) )
        Log("direct video_url")

    elif playmode_string == 'f4mproxy':
        video_url = "{}{}".format(video_url, utils.Header2pipestring(cb_headers) )
        Log("f4mproxy video_url")

        if download == True:
            download_path = utils.Make_download_path(name = name, include_date = True, file_extension = '.mp4')
            Log(download_path, xbmc.LOGNONE)
            max_bit_rate = int((int(utils.addon.getSetting('max_bit_rate')) + 0.25 + int(megabitratebonus)) * 1000 * 1000 )
        else:
            download_path = None
            
        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        f4mp.playF4mLink(
            video_url
            , name
            , proxy = None
            , use_proxy_for_chunks = False
            , maxbitrate = max_bit_rate
            , simpleDownloader = False
            , auth = None
            , streamtype = 'HLSREDIR'
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , iconImage = iconimage
            , download_path = download_path
            )
        return

    elif playmode_string == 'inputstream':

        video_url = "{}{}".format(video_url, utils.Header2pipestring(cb_headers) )
        if ".m3u8" in video_url:
            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            listitem.setProperty('inputstream.adaptive.stream_headers'
                                , 'user-agent=' + 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/538.22 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'
                                + "&Referer=".format(ROOT_URL)
                                )
            Log("using inputstream")
    else:
        utils.notify(name,'Unknown playmode for webcam link')

    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( video_url, listitem)
    xbmc.Player().play(myPlayList)
    

#__________________________________________________________________________
#

##def camgirl_page(notify=False):
##
##    if notify: utils.Notify("Listing {}".format(ROOT_URL))
##
##    Log("\n chaturbate camgirl_page {} \n".format(''))
##    
##    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
##    contents = ""
##
##    FIRST_SEARCH_PAGE = 1
##    LAST_SEARCH_PAGE = 4
##    for i in range(FIRST_SEARCH_PAGE,LAST_SEARCH_PAGE):    
##        url = URL_RECENT.format(i)
##        myrequest= urllib2.Request(url)
##        myrequest.add_header('User-Agent', user_agent)
##        myrequest.add_header('Accept-Encoding', 'gzip')
##        myrequest.add_header('Referer', ROOT_URL)
##        myrequest.add_header('Accept-Language', 'en-US,en;q=0.9')
##        myrequest.add_header('Connection', 'keep-alive')
##        try:
##            response = urllib2.urlopen(myrequest, timeout=15)
##            data=''
##            if response.info().get('Content-Encoding') == 'gzip':
##                buf = StringIO.StringIO( response.read())
##                f = gzip.GzipFile(fileobj=buf)
##                data = f.read()
##                f.close()
##            else:
##                data = response.read()
##            contents=contents+data
##        except Exception, e:
##            Log("attempt connecting to err:'{}'".format(str(e)), xbmc.LOGERROR)
##
##    return contents
