'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream, hdgdl
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import os
import re
import sys

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

@utils.url_dispatcher.register('610')
def Main():
    utils.addDir('[COLOR hotpink]Search[/COLOR]','https://daftsex.com/video/',613,'','')
    List('https://daftsex.com/hot')
    xbmcplugin.endOfDirectory(utils.addon_handle)

	
@utils.url_dispatcher.register('611', ['url'], ['page'])
def List(url, page=0):
    try:
        postRequest = {'page' : str(page)}
        response = utils.postHtml(url, form_data=postRequest,headers={},compression=False)
    except:
        return None

    #match = re.compile(r'<div class="video-item">[^"]+"/watch/([^"]+)"[^/]+/[^/]+/[^/]+/([^"]+)" alt="([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)
    regex_string = '<div class="video-item">.*?Video\.show.*?\'([^\']+)\'.*?<img src="([^"]+)".*?alt="([^"]+)".*?<span class="video-time">([^<]+)<'
    match = re.compile(regex_string, re.DOTALL | re.IGNORECASE).findall(response)

    for video, img, name, duration  in match:
        name = utils.cleantext(name)
        name = "[COLOR deeppink]{}[/COLOR] {}".format(duration,name)
        utils.addDownLink(name, video, 612, img, '')

    npage = page + 1
    utils.addDir('Next Page (' + str(npage) + ')', url, 611, '', npage)
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('612', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    utils.kodilog(url)
    response = utils.getHtml(url, "https://daftsex.com/watch/")

    #utils.kodilog(response)

    vid_id = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)    
    token = re.compile('access_token: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)
    videos = re.compile('id: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)
    extra_key = re.compile('sig: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)
    sig = re.compile('"sig":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(response)
    ckey = re.compile('c_key: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(response)
    thumb = re.compile('thumb: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(response)
    cdn_files = re.compile('cdn_files: {([^}]+)}', re.DOTALL | re.IGNORECASE).findall(response)
    server = re.compile('server: "([^"]+)",', re.DOTALL | re.IGNORECASE).findall(response)
    partial = re.compile('partial: {"quality":{"([^}]+)}', re.DOTALL | re.IGNORECASE).findall(response)

    #different versions of web pagemay not have same data
    try:    token = token[0]
    except: token = None
    try:    videos = videos[0]
    except: videos = None
    try:    ckey = ckey[0]
    except: ckey = None
    try:    extra_key = extra_key[0]
    except: extra_key = None
    try:    cdn_files = cdn_files[0]
    except: cdn_files = None
    import base64
    try:    thumb = base64.b64decode(thumb[0]).strip("thumb.jpg")
    except: thumb = None
    try:    server = base64.b64decode(server[0][::-1]) #reverse string then decode it
    except: server = None
    try:    sig = sig[0]
    except: sig = None
    try:    vid_id = vid_id[0]
    except: vid_id = None
    try:    partial = partial[0]
    except: partial = None
    
    
    utils.kodilog("access_token={}".format(token))
    utils.kodilog("videos={}".format(videos))
    utils.kodilog("extra_key={}".format(extra_key))
    utils.kodilog("ckey={}".format(ckey))
    utils.kodilog("thumb={}".format(thumb))
    utils.kodilog("cdn_files={}".format(cdn_files))
    utils.kodilog("server={}".format(server))
    utils.kodilog("sig={}".format(sig))
    utils.kodilog("vid_id={}".format(vid_id))
    utils.kodilog("partial={}".format(partial))
    
    if cdn_files: #newer style

        match_240 = re.compile('"mp4_240":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        match_360 = re.compile('"mp4_360":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        match_480 = re.compile('"mp4_480":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        match_720 = re.compile('"mp4_720":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        match_1080 = re.compile('"mp4_1080":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(cdn_files)
        baseurl = "https://{}/videos/{}/".format(server,videos.replace("_","/"))
        if match_240:  videourl = "{}{}".format(baseurl, match_240[0].replace(".",".mp4?extra=") )
        if match_360:  videourl = "{}{}".format(baseurl, match_360[0].replace(".",".mp4?extra=") )
        if match_480:  videourl = "{}{}".format(baseurl, match_480[0].replace(".",".mp4?extra=") )
        if match_720:  videourl = "{}{}".format(baseurl, match_720[0].replace(".",".mp4?extra=") )
        if match_1080: videourl = "{}{}".format(baseurl, match_1080[0].replace(".",".mp4?extra=") )
    
    else: #older styple
        
        import time
        base_str = "https://{}/method/video.sig?callback=jQuery31105973447211193958_1530417119721"
        base_str = base_str + "&token={}&videos={}&extra_key={}&ckey={}&sig={}&_={}"
        intermediate_url = base_str.format(server,token,videos,extra_key,ckey,sig,int(time.time()))
        #utils.kodilog(intermediate_url)
        http_referrer = url #encode this in http command
        response = utils.getHtml ( intermediate_url, http_referrer)
        utils.kodilog(response)

        match_240 =  re.compile('"mp4_240":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
        match_360 =  re.compile('"mp4_360":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
        match_480 =  re.compile('"mp4_480":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
        match_720 =  re.compile('"mp4_720":"([^"]+)',  re.DOTALL | re.IGNORECASE).findall(response)
        match_1080 = re.compile('"mp4_1080":"([^"]+)', re.DOTALL | re.IGNORECASE).findall(response)

        #if match_240:  videourl = "{}".format(match_240[0].replace("\/",".mp4?extra=") )
        if match_240:
            try:    extra_key = re.compile('"240":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            except: pass
            videourl = "http://{}/{}&extra_key={}&videos={}".format(server, match_240[0].replace("\/","/").strip("https://"), extra_key, vid_id )
        if match_360:
            extra_key = re.compile('"360":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            videourl = "http://{}/{}&extra_key={}&videos={}".format(server, match_360[0].replace("\/","/").strip("https://"), extra_key, vid_id )
        if match_480:
            extra_key = re.compile('"480":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            videourl = "http://{}/{}&extra_key={}&videos={}".format(server, match_480[0].replace("\/","/").strip("https://"), extra_key, vid_id )
        if match_720:
            extra_key = re.compile('"720":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            videourl = "http://{}/{}&extra_key={}&videos={}".format(server, match_720[0].replace("\/","/").strip("https://"), extra_key, vid_id )
        if match_1080:
            extra_key = re.compile('"1080":"([^"]+)"', re.DOTALL | re.IGNORECASE).findall(partial)[0]
            videourl = "http://{}/{}&extra_key={}&videos={}".format(server, match_1080[0].replace("\/","/").strip("https://"), extra_key, vid_id )

        #utils.kodilog("videourl={}".format(videourl))            
        #return
    
##    response = utils.getHtml ( \
##        "https://crazycloud.ru/method/video.get?callback=jQuery311007115064239600177_1530413197600&token=" \
##        + token[0] + "&videos=" + videos[0] + "&extra_key=" + extra_key[0] + "&ckey=" \
##        + ckey[0] + "&_=1490030654101", url)

    #return
    utils.kodilog("videourl={}".format(videourl))

    if videourl:
        utils.playvid(videourl, name, download)
    else:
        utils.notify('Oh oh','Couldn\'t find a video')

		 
@utils.url_dispatcher.register('613', ['url'], ['keyword'])
def Search(url, keyword=None):
    searchUrl = url
    xbmc.log("Search: " + searchUrl)
    if not keyword:
        utils.searchDir(url, 613)
    else:
        title = keyword.replace(' ','_')
        searchUrl = searchUrl + title
        xbmc.log("Search: " + searchUrl)
        List(searchUrl)
