'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]spankbang[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = 'https://spankbang.com'
SEARCH_URL = ROOT_URL + '/s/'
SEARCH_URL = ROOT_URL + '/s/{}/{}/'
URL_CATEGORIES = ROOT_URL + '/categories' 
URL_RECENT = ROOT_URL + '/new_videos/{}/'

MAIN_MODE          = C.MAIN_MODE_spankbang
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , keyword = 'sex'
            )
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon  )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
    
    # read html
    Log("list_url={}".format(list_url))    

    from collections import OrderedDict
    headers = {} #OrderedDict() #C.DEFAULT_HEADERS.copy()
    headers['User-Agent'] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0"
    headers['Accept-Encoding'] = 'gzip'
    headers['Accept'] = '*/*'
##    headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
##    headers['Accept-Language'] = "q=0.8,en-US;q=0.5,en;q=0.3"
##    headers['Connection'] = "close"
##    headers['Te'] = "trailers"
##    headers['Upgrade-Insecure-Requests'] = "1"    
#--header "Accept-Language: q=0.8,en-US;q=0.5,en;q=0.3"
#    --header "Connection: close" --header "Te: trailers"
#--header "Upgrade-Insecure-Requests: 1" --user-agent "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0" "https://spankbang.com/new_videos/1/"
##    Log(repr(headers), xbmc.LOGNONE)
##    Log(repr(type(headers)), xbmc.LOGNONE)

##    listhtml = getHtml(list_url, hdr=headers)

##curl --header "Accept: */*"  --user-agent "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0" "https://spankbang.com/new_videos/1/"

    listhtml = utils.getHtml(list_url, headers=headers)#, ignore404=True , send_back_redirect=True)
    if "Page Not Found" in listhtml:
        video_region = ''
    else: #distinguish between adverts and videos
        try:
            regex = '<div class="results(.+)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
            Log("video region found via regex".format())
        except:
            video_region = listhtml
##    Log("video_region={}".format(video_region))

    regex = 'div class="video-item".+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?((?:class="i-hd">[^<]+<|class="i-len")).+?fa fa-clock-o"></i>([^<]+)<'
    regex = 'div class="video-item".+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="i-len">([^<]+)<.+?(?:class="i-hd">([^<]+)<|/p)'
    regex = 'div class="video-item.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="i-len">([^<]+)<.+?(?:class="i-hd">([^<]+)<|/p)'    #2020-07-03
    regex = 'div class="video-item" data-id=.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="l">([^<]+)<.+?class="(?:h|n)">([^<]+)<'  #2020-10-17
    regex = 'div class="video-item." data-id=.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="l">([^<]+)<.+?class="(?:h|n)">([^<]+)<'  #2020-11-21
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #for videourl, thumb, label, hd, duration in info:
    for videourl, thumb, label, duration, hd in info:
        hd = utils.Normalize_HD_String(hd)
        if not thumb.startswith('http'): thumb = "https:" + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration + 'm'
            , noDownload=False)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    

    #np_info=re.compile('<a href="([^"]+)">&raquo;', re.DOTALL | re.IGNORECASE).findall(listhtml)
    regex = '<a href=".+?(\d+)/">&raquo;'
    regex = 'href=".+?(\d+)/\??[^"]*">&raquo;'
    np_info=re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(url))

    for np_url in np_info:
##            Log("np_url={}".format(np_url))
        np_number = np_url
        np_url = url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth:
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword)
        break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(title,'{}')
    Log("searchUrl='{}'".format(searchUrl))    
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url)

    regex = '<a href="(/category/[^"]+)"><img src="([^"]+)"><span>([^<]+)</span>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, thumb, label in info:
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        videourl = videourl.split('?')[0] + '{}/?period=all'
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
##def Test(keyword):
##    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
##    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
##    Categories(URL_CATEGORIES, False)
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword=keyword, testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    #    Categories(URL_CATEGORIES, False)
    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    full_html = utils.getHtml(url, ROOT_URL)

    if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
        return
    
##    stream_key = re.compile("data-streamkey=\"([^\"]+)\"").findall(html)
##    if stream_key:
##        stream_key = stream_key[0]
##    else:
##        if "this video is no longer available" in html:
##            utils.Notify("Video '{}' has been deleted".format(name))
##        elif "This Video Is Private" in html:
##            utils.Notify("Video '{}' Is Private".format(name))
##        else:
##            utils.Notify("Update required for {}".format(ROOT_URL))
##        return
##    #Log(stream_key)

    description_regex = 'section class="details"(.+?)section class="user_uploads"'
    description_html = re.compile(description_regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    if description_html: description_html=description_html[0]
    else: description_html=''
    description = ''
    desc_separator_char = '; '
    pornstar_regex = 'href="(?:/pornstar/|/tag/).+?>([^<]+?)<'
    pornstars = re.compile(pornstar_regex, re.DOTALL | re.IGNORECASE).findall(description_html)
    for pornstar in pornstars:
        if pornstar.lower() not in description.lower():
            description = description + utils.cleantext(pornstar) + desc_separator_char
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log(u"description={}".format(description.decode("utf8")))



    links_regex = 'var stream_data = (.+?\]})'
    links_json_html = re.compile(links_regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    if links_json_html: links_json_html=links_json_html[0]
    else: links_json_html='{}'
##    Log("links_json_html={}".format(links_json_html))
    links_json_html = links_json_html.replace('\'','"')
    json_urls = json.loads(str(links_json_html))
    Log("json_urls={}".format(repr(json_urls)))

    list_key_value = {} 
    for json_url in json_urls:
        q = json_url
        v = json_urls[json_url]
        if (q.endswith('0p') and not q.startswith('m3u8')) or q == '4k':
            if len(v) > 0:
                v = v[0]
                list_key_value[q] = v
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function            
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )


    #we should have a url by now...
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(url, ROOT_URL))
        return

    #always set referrer so that 'kodi' does not appear on the target server
    if '|' not in video_url:
        headers = C.DEFAULT_HEADERS.copy()
        if url: headers['Referer'] = url

    Log("video_url='{}'".format(video_url))

    #during testmode, only ensure that a url can be generated
    if testmode:
        Log("Would have played video_url; but in test mode")
        return
    
    utils.playvid(video_url
                , name=name, download=download
                , description=description, playmode_string=playmode_string
                , play_profile=play_profile)
#__________________________________________________________________________
#
