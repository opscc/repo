'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib import search
from resources.lib.utils import Log
from resources.lib import constants as C

SPACING_FOR_TOPMOST = C.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  C.SPACING_FOR_NAMES
SPACING_FOR_NEXT = C.SPACING_FOR_NEXT

FRIENDLY_NAME = '[COLOR {}]PornOne[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://pornone.com"
SEARCH_URL = ROOT_URL + '/search?q='
SEARCH_URL = ROOT_URL + '/search/?q={}&page={}'
#https://pornone.com/search/?q=hands%20free&page=2
URL_CATEGORIES = ROOT_URL+'/categories/'
URL_RECENT = ROOT_URL+'/newest/{}/'

MAIN_MODE          = C.MAIN_MODE_pornone
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)
REBUILD_ICON       = str(int(MAIN_MODE) + 6)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    reload(utils)
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , keyword = 'sex'
            )
    utils.addDir(
          name=C.STANDARD_MESSAGE_CATEGORIES
          ,url=URL_CATEGORIES
          ,mode=CATEGORIES_MODE 
          ,iconimage=C.category_icon )
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    if list_url.endswith("/1/"): #site does not always like this
        list_url = list_url[:-3]
        Log(list_url)
        

        
    # read html
    r_list_url = None
    listhtml, r_list_url = utils.getHtml(list_url, ROOT_URL, ignore404=True, send_back_redirect=True)
    if r_list_url and list_url != r_list_url: 
        Log(list_url)
        Log(r_list_url)        
        #site has some cached searches that redirect...try and adapt
        if 'http' not in r_list_url:
            url = ROOT_URL + list_url + '{}/'
        else:
            url = r_list_url + '{}/'
        Log(url)

    if "No results found for this criteria" in listhtml:
        #2019-06-30   this site will return a 404 response which will lead to ugly error message via utils.getHtml(url, '')
        video_region = ""
        next_page_html = ""
        listhtml =""
    else:
        next_page_html = listhtml
        regex = '<main class="(.*</main>)'
        video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        regex = '<nav class="(.*</nav>)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        
    # parse out list items
    regex = 'class="video".+?href="([^"]+?)".+?<span class="time">([^<]+?)<.+?class="(hd-marker[^"]+)".+?img src="([^"]+?)" alt="([^"]+?)"'
    regex = ('href="([^"]+?)"'
             '.+?<span class="rounded.+?>([^<]+?)<'
             '.+?((?:img src=\"/images/hd|img src=\"))'
             #'.+?src="([^"]+?)" alt="([^"]+?)"'
             '([^"]+?)" alt="([^"]+?)"'
             )
    regex = ('href="(?P<videourl>[^"]+?)"'
             '.+?<span class="rounded.+?>(?P<duration>[^<]+?)<'
             '.+?(?P<hd>(?:img src=\"/images/hd|img src=\"))'
             '.+?<img src="(?P<thumb>[^"]+)"'
             '.+?alt="(?P<desc>[^"]+?)"'
             )    
    regex = ('href="(?P<videourl>https://pornone.com/[^"]+?)"'
             '.+?(?P<hd>(?:/hd.svg"(?=>)|(?=>\d)))'
             '.*?>(?P<duration>[\d:\s]+?)<'
             '.+?<img src="(?P<thumb>[^"]+)"'
             '.+?alt="(?P<desc>[^"]+?)"'
             ) #worked 2023-03-26
    regex = ('href="(?P<videourl>https://pornone.com/[^"]+?)"'
             '.+?(?P<hd>(?:/hd.svg"(?=>)|(?=>\d)))'
             '.*?>(?P<duration>[\d:\s]+?)<'
             '.+?data-src="(?P<thumb>[^"]+)"'
             '.+?alt="(?P<desc>[^"]+?)"'
             ) #worked 2023-05-20
    
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #for videourl, duration, hd, thumb, label in info:
    for videourl, hd, duration, thumb, label in info:
        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        hd = utils.Normalize_HD_String(hd)
##        Log(repr(label))
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)           
    if (testmode == True) and (len(videourl) > 1):
        Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)

    # next page items
    next_page_regex = '<a class=\"next link(?:s|age)\" title=\"Next Page\" href=\"(.+?)\">'
    next_page_regex = '(<span class=".+?">Next</span>)'
    
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
##            np_number = np_url.split('?')[0].split('/')[4]
##            if not np_number.isdigit(): np_number=np_url.split('/')[3]
##            if not np_number.isdigit(): np_number=np_url.split('/')[4]
##            if not np_number.isdigit(): np_number=np_url.split('/')[5]
##            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            np_number = int(page) + 1
            np_url = url
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) < (max_search_depth):    #search some more, but not forever  
                    utils.Notify(msg=np_url)  #let user know something is happening
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword
                         , progress_dialog=progress_dialog)

                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace(' ','+').replace('+','%20').lower()
    searchUrl = SEARCH_URL.format(title, '{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url, ROOT_URL)
    #cathtml = cathtml.split('class="categories-sidebar')[1].split('class="l-main"')[0]
    regex = 'pagebase="categories/"(.+?)<script>'
    regex = 'id="catgA"(.+?)</main>'
    cathtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)[0]
##    Log(repr(cathtml))
    #regex = '<a href="([^"]+)".+?class="categoryName">([^<]+)<'
    regex = '<a href="([^"]+)".+?alt="([^"]+)".data-src="([^"]+)".+?dark:text-white">([^<]+)<'

    regex = (
        '<a href="(?P<videourl>[^"]+)"'
        '.+?alt="(?P<alt_label>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?<div class="catNameDrop.+?">(?P<label>[^<]+)<'
        )
    Log(repr(regex))

    info = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(cathtml)
    for item in info:
        videourl = item.group('videourl')
        img = item.group('thumb')
        label = item.group('label')
        Log(u"label={}".format(utils.cleantext(label)))
        Log(u"img={}".format(repr(img)))
        Log(u"videourl={}".format(repr(videourl)))
        
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not img.startswith('http'): img = ROOT_URL + img
##        Log("label={}".format(label))
        #img = C.search_icon
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl+'{}/'
            ,mode=LIST_MODE 
            ,iconimage=img
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))
    
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword=keyword, testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    utils.endOfDirectory(end_directory=end_directory)

#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    page = utils.getHtml(url, ROOT_URL)

    regex = '<source src="([^"]+)".+?label="([^"]+)"'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(page)
    Log("sources_list={}".format(sources_list) )
    video_url = utils.SortVideos(
        sources=sources_list
        ,download=download
        ,vid_res_column=1
        ,max_video_resolution=max_video_resolution
        )

    #we should have a url by now...
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(url, ROOT_URL))
        return

    video_url = video_url + utils.Header2pipestring() + '&Referer=' + ROOT_URL
    Log("video_url={}".format(video_url) )

    #page = '<a id=\'star1\' href="https://pornone.com/riley-star-porn-videos-7783/"><span class="tags links">Riley Star</span'    
    regex_model = 'id=\'star\d+.+?links">(?P<model>[^<]+),<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(page)
    description = ''
    desc_separator_char = ', '
    if source_models:
        for model in source_models:
            description = description + desc_separator_char + model.group('model')
    description = description.strip(desc_separator_char)
    #Log("description={}".format(description))
    if description == '': description=name + '\n' + ROOT_URL
    else: description=description + '\n' + ROOT_URL
    #Log("description={}".format(description))

    #during testmode, only ensure that a url can be generated
    if testmode:
        Log("Would have played video_url; but in test mode")
        return

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile)
#__________________________________________________________________________
#
_REGEX_icon_search = '<meta property="og:image" content="(.*?)"'
_ROOT_URL = ROOT_URL
@C.url_dispatcher.register(REBUILD_ICON, ['url'])
def Icon_Search(url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
    page_html = utils.getHtml(url, referer=ROOT_URL)
    icon_url = re.compile(pattern, re.DOTALL | re.IGNORECASE).findall(page_html)[0]
    Log(icon_url)
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = referer
    return icon_url + utils.Header2pipestring(headers)
#__________________________________________________________________________
#
