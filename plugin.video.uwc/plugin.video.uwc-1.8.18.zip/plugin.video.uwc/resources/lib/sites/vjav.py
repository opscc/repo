'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log

class Specific_Website(Base_Website):


    _FRIENDLY_NAME = '[COLOR {}]vJav[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True

#like txx; hclips; tubeporn    
    _ROOT_URL        = "https://vjav.com"
    _URL_CATEGORIES  = _ROOT_URL + '/api/json/categories/14400/str.all.json'
    _URL_RECENT      = _ROOT_URL + '/api/json/videos/14400/str/latest-updates/60/..{}.all...json'

    _SEARCH_URL      = _ROOT_URL + '/api/videos2.php?params=259200/str/relevance/60/search..{}.all..&s={}&sort=latest-updates&date=all&type=all&duration=all'
#                https://vjav.com/api/videos.php?params=259200/str/relevance/60/search..1.all..&s=aika&sort=latest-updates&date=all&type=all&duration=all

    _MAIN_MODE =  C.MAIN_MODE_vjav
    _FIRST_PAGE = '1'

    #__________________________________________________________________________
    #which to strings may indicate that there is nothing to be found
##    _ITEMS_NOT_FOUND_INDICATORS = [
##        "<p>Make sure that all words are spelled correctly.</p>"
##        , "No videos found for "
##        ]
    #__________________________________________________________________________
    #specific header required for listing
##    _LIST_HEADERS = {
##        "Accept":"application/json, text/plain, */*"
##        ,"DNT":"1"
##        ,"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36"
##        ,"Origin":"https://beeg.com"
##        ,"Referer":"https://beeg.com/"
##        ,"Accept-Encoding":"gzip, deflate, br"
##        ,"Accept-Language":"en-US,en;q=0.9"
##    }
    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = None #'class="main"(.+?)class="divrectr"'
    #videos on this page's 'available videos' lising
    _REGEX_list_items = (
        '{"video_id":"(?P<videourl>\d+)"'
        '.+?"title":"(?P<label>[^"]+?)"'
        '.+?"duration":"(?P<duration>[^"]+?)"'
        '.+?"models":"(?P<desc>[^"]*?)"'
        '.+?"scr":"(?P<thumb>[^"]+?)"'
        '.+?"props":(?P<hd>[^,]*?),'
        )
    #__________________________________________________________________________
    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #None = show all options

    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = '("videos":\[{")'

    #__________________________________________________________________________
    #where categories can be found
    #_REGEX_categories_region = "id='categoryList'(.+)"
    _REGEX_categories = (
        ',"dir":"(?P<videourl>[^"]+)"'
        '.+?{"title":"(?P<label>[^"]+)"'
        '(?P<thumb>)'
        )
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        url = self.ROOT_URL + "/api/json/videos/86400/str/latest-updates/60/categories.{}.{}.all..day.json".format(url, '{}')
##        Log(repr(url), C.LOGNONE)
        return url
    #__________________________________________________________________________
    #where playable urls live
    _REGEX_playsearch_01 = (
        '<source src="(?P<url>[^"]+?)" type='
        '.+?(?P<res>\d)'
        )
##    #__________________________________________________________________________
##    # Change video source url found in via regex with a structure used by site
##    def Video_Source_URL_Normalize(self, url):
##        url = "https://video.beeg.com/{}".format(url)
##        headers = C.DEFAULT_HEADERS.copy()
##        headers['Referer'] = "https://beeg.com/" 
##        from resources.lib.utils import Header2pipestring as Header2pipestring
##        url = url + Header2pipestring(headers)
##        return url
    #__________________________________________________________________________
    # description for the playable url tht can be found on the 'play' page
    _REGEX_tags = 'class="link12">(?P<tag>[^<]+)<'
    _REGEX_tags_region = '(.+)'
##    #__________________________________________________________________________
##    # add an alternative way to resolve listing
##    def List_URL_Normalize(self, url, page):
##        url = url + "limit=48&offset={}"
##        url = url.format(48*(int(page)-1))
##        return url
    #__________________________________________________________________________
    # add an alternative way to resolve a playable thumbnail
    def Normalize_ThumbURL(self, thumb, duration, videourl):
##        Log(repr((thumb,duration,videourl)), C.LOGNONE)
        thumb = thumb.replace("\\/", "/")
##        Log(repr(thumb), C.LOGNONE)
        return thumb
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        videourl = self.ROOT_URL + "/api/videofile.php?video_id={}&lifetime=8640000".format( videourl )
        return videourl
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def ALTERNATE_playsearch_01(self, *args, **kargs):
        Log(repr((args,kargs)))

        import base64
        import json

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        items = json.loads(full_html)

        #stolen from current UWC 2021-02-02
        vidurl = items[0]['video_url']
        Log("vidurl='{}'".format(repr(vidurl)))
        replacemap = {'M':'\u041c', 'A':'\u0410', 'B':'\u0412', 'C':'\u0421', 'E':'\u0415', '=':'~', '+':'.', '/':','}
        for key in replacemap:
            vidurl = vidurl.replace(replacemap[key], key)
        Log("vidurl='{}'".format(repr(vidurl)))
        replacemap2 = {u'M':u'\u041c', u'A':u'\u0410', u'B':u'\u0412', u'C':u'\u0421', u'E':u'\u0415', u'=':u'~', u'+':u'.', u'/':u','}
        for key in replacemap2:
            vidurl = vidurl.replace(replacemap2[key], key)

        Log("vidurl='{}'".format(repr(vidurl)))
        video_url = base64.b64decode(vidurl)

        if not video_url.startswith('http'):
            video_url = self.ROOT_URL + video_url


        alt_results.append(  ('240', video_url)  )

        Log("alt_results={}".format(repr(alt_results)))        
        return alt_results
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        return keyword.replace('+',' ').replace(' ','%20')
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        search_url = search_url.format('{}',keyword)
        return search_url

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )

#__________________________________________________________________________
#
