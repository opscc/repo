'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
import xbmc
from resources.lib import utils
from resources.lib import search
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]eporner[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_SCENES
FRONT_PAGE_CANDIDATE = True

ROOT_URL = "https://www.eporner.com"
_ROOT_URL = ROOT_URL
SEARCH_URL = ROOT_URL + '/search/{}/{}/'
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/{}/'

FIRST_PAGE = '1' #default first page

MAIN_MODE       = C.MAIN_MODE_eporner
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , keyword = 'sex'
            )
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage = C.category_icon
        )
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={})".format(repr(url), repr(page), repr(end_directory), repr(keyword)))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)    

    # read html
    listhtml, r_list_url = utils.getHtml(list_url, ignore404=True, send_back_redirect=True)#, ignore404=True , send_back_redirect=True)
    if r_list_url and list_url != r_list_url: 
        Log(list_url)
        Log(r_list_url)        
        #site has some cached searches that redirect...try and adapt
        if 'http' not in r_list_url:
            url = ROOT_URL + list_url + '{}/'
        Log(url)
        
        
    if "but you can check other awesome vid" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml
            regex = 'id="vidresults"(.+?)(?:class="clear"|id="foot")'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            import traceback
            traceback.print_exc()
            video_region = listhtml


    # parse out list items
    regex = ('<div class="mb.+?class="mvhdico"'
             '.+?<span>([^<]+)<.+?href="([^"]+)"'
             '.+?(?:data-src|img src)="([^"]+)"'
             '.+?alt="([^"]+)"'
             '.+?title="Duration">([^<]+)<')

    regex = (
        '<div class="mb(?:"| )'
        '.+?href="([^"]+)"'
        '.+?(?:data-src|img src)="([^"]+)"'
        '.+?alt="([^"]+)"'
        '.+?class="mvhdico"'
        '.+?<span>([^<]+)<'
        '.+?title="Duration">([^<]+)<'
        )

    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #for hd, videourl, thumb, label, duration in info:
    for videourl, thumb, label, hd, duration in info:
        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc = '\n' + ROOT_URL
            , duration = duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    if (testmode == True) and (len(videourl) > 1):
        Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)

    # next page items
    try:
        regex = 'class="numlist2"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
##    Log("next_page_html={}".format(next_page_html))
    next_page_regex = "<a href='([^']+?(\d+)\/)' class='nmnext' title='Next page'>"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
#<a href="/3/" class="nmnext" title="Next page">
#<a href="/2/" class="nmnext" title="Next page">
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        Log(repr(np_info),C.LOGNONE)
        url = ROOT_URL + np_info[0][0].replace("/"+ np_info[0][1]+"/", "/{}/")
        Log(repr(url),C.LOGNONE)
        np_url = url
        np_number = int(page) + 1
##            Log("np_url={}".format(np_url))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace('+',' ').replace(' ','-') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl
         , page=FIRST_PAGE
         , end_directory=end_directory
         , keyword=keyword
         , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page) == '-1'))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    listhtml = utils.getHtml(url,ROOT_URL)
    regex = 'id="div-search-results"(.+)id="foot'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##    Log("listhtml={}".format(listhtml))
    regex = 'class="categoriesbox".+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = videourl + '/{}/'
        #Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb
            )
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword=keyword, testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile','icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    elif playmode_string == C.PLAYMODE_DIRECT:  max_video_resolution = 99999 #if 'direct' was chosen, use max available resolution
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None




    #2020-12-24
    page_html, redir_url = utils.getHtml(url, referer=ROOT_URL, send_back_redirect=True )
    
    regex = '<div class="dloaddivcol">(.+?)</div>' #2020-12-24
    sources_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(page_html)
    if not sources_html: sources_html = ''
    else: sources_html = sources_html[0]

    regex = 'href="([^"]+)".+?\((\d+)p,'
    vid_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(sources_html)
##    Log(repr(vid_list))
    list_key_value = {}
    for url, res in vid_list:
        url = ROOT_URL + url
        list_key_value[res] = url
##    Log(repr(list_key_value))
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )
##    Log("video_url={}".format(video_url))

    #we should have a url by now...
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, url))
        return
    
    #description information
    description = ""
    desc_separator_char = '; '
    regex = 'class="vit-pornstar.+?href="/pornstar/.+?>([^<]+)<\/a>'
    description_info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(page_html)
    for desc in description_info:
        description += desc_separator_char + desc
    description = description.strip(desc_separator_char)
    if description == '': description=name + '\n' + ROOT_URL
    else: description=description + '\n' + ROOT_URL
##    Log("description={}".format(description), xbmc.LOGNONE)

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return

    #during testmode, only ensure that a url can be generated
    if testmode:
        Log("Would have played video_url; but in test mode")
        return
    
##    utils.playvid(
##        video_url
##        , name=name
##        , download=download
##        , description=description
##        , playmode_string=playmode_string
##        , play_profile=play_profile)
    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
    ##            , download_filespec=download_filespec
        , mode = PLAY_MODE
    ##            , url_factory = url
        , icon_URI = icon_URI            
        )    
#__________________________________________________________________________
#

_REGEX_icon_search = (
    '.+?property="og:image" content="(?P<thumb>.+?)"'
    )
#__________________________________________________________________________
#
def Icon_Search(url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
    Log(u"Icon_Search url={}, pattern={}, referer={}".format(repr(url),repr(pattern),repr(referer))
##            , C.LOGNONE
        )
    page_content, redir_url = utils.getHtml(url, referer=ROOT_URL, send_back_redirect=True )
    info = re.compile(pattern, re.DOTALL | re.IGNORECASE).finditer(page_content)
    for item in info:
        thumb = item.group('thumb')
        if thumb and not thumb.startswith('http'): thumb = 'https:' + thumb
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = _ROOT_URL + '/'
        return thumb + utils.Header2pipestring(headers)
    return None
#__________________________________________________________________________
#
