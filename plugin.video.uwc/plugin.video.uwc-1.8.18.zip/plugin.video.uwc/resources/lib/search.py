#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import Queue
##import multiprocessing
import sqlite3
import threading
import traceback
import urllib
import xbmc
#import internal addon libraries
from resources.lib import utils
from resources.lib import constants as C
#define frequenctly used aliases
from resources.lib.utils import Log


#__________________________________________________________________________
#
def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ADD_KEYWORD, ['channel'])
def NewSearchKeyword(channel):
    Log("NewSearchKeyword channel='{}'".format( channel))
    vq = _get_keyboard(heading="Searching for...")
    if (not vq):
        return False, 0
    keyword = urllib.quote_plus(vq)
    AddKeyword(keyword)
    Quick_Search(url='', channel=channel, end_directory=True, page='1', keyword=keyword)
    utils.endOfDirectory()

#__________________________________________________________________________
#
def AddKeyword(keyword):
    Log("AddKeyword keyword='{}'".format(keyword))
    conn = sqlite3.connect(C.favoritesdb)
    db_cursor = conn.cursor()
    db_cursor.execute("INSERT INTO keywords VALUES (?)", (keyword,))
    conn.commit()
    conn.close()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.DELETE_KEYWORD, ['keyword'])
def delKeyword(keyword):
    Log('keyword: ' + keyword)
    conn = sqlite3.connect(C.favoritesdb)
    db_cursor = conn.cursor()
    db_cursor.execute("DELETE FROM keywords WHERE keyword = '%s'" % keyword)
    conn.commit()
    conn.close()
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.QWIK_SEARCH, ['url', 'channel'], ['end_directory','page','keyword'])
def Quick_Search(url, channel, end_directory=True, page='1', keyword=None):

    Log("Quick_Search url='{}', channel='{}', end_directory='{}', page='{}', keyword='{}'".format( url, channel, end_directory, page, keyword))

    if not keyword:
        ##get the search string from user; remember it; pre-populate remembered
        prev_search_string = C.this_addon.getSetting(id='quick_search_string')
        quick_search_string = _get_keyboard(
            heading="Search query"
            ,default=prev_search_string
            )
        if  quick_search_string == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.this_addon.setSetting(id='quick_search_string', value=quick_search_string)
    else:
        quick_search_string = keyword


    progress_dialog = None
    progress_dialog = utils.Progress_Dialog(C.addon_name,u"searching '{}'".format(quick_search_string))

    worker_threads = []
    monitor = xbmc.Monitor()

    try:
            
        if C.ROOT_SEARCH_ALL == str(channel):
            end_directory = False #this sub will set the directory

        get_sites = utils.Get_Sites()
        i = 0
        
        try: 
            for sitename, module in get_sites:
                if module.SEARCH_MODE == str(channel) or C.ROOT_SEARCH_ALL == str(channel):
                    #testing
                    #i = i + 1 
                    if i > 20: break
                    #/testing
                    method_to_call = getattr(module, 'Search')
                    kwargs = {
                        "searchUrl": module.SEARCH_URL
                        ,"keyword": quick_search_string
                        ,"end_directory": end_directory
                        ,"page": page
                        ,"progress_dialog": progress_dialog
                        }
##                    Log(sitename + " threading.thread - warning"
##                        ,C.LOGNONE
##                        )
                    Log(sitename + repr(kwargs)
##                        ,C.LOGNONE
                        )

                    worker = threading.Thread(name=sitename
                                              ,target=method_to_call
                                              ,args= (module.SEARCH_URL
                                                     ,quick_search_string
                                                     ,end_directory
                                                     ,page
                                                     ,progress_dialog
                                                     )
                                              )


                    worker.daemon = True
                    worker_threads.append(worker)
##                    Log(worker.name + " starting - warning"
##                        ,C.LOGNONE
##                        )
                    worker.start()
##                    Log(worker.name + " started - warning"
##                        ,C.LOGNONE
##                        )

            

            max_time = 240 #seconds_to_wait_for_search
            cur_time = 0
            still_working = True
            while still_working :
                Log('still_working'
                    ,C.LOGNONE
                    )
                if progress_dialog.iscanceled():
                    Log("progress_dialog.iscanceled()")
                    break #stop waiting

                if cur_time > max_time:
                    Log("cur_time > max_time")
                    break #stop waiting
                    
                progress_dialog.increment_percent()
                cur_time += 1
                utils.Sleep(250)
##                if monitor.waitForAbort(1): break
                still_working = False
                for worker in worker_threads:
                    if worker.is_alive():
                        Log(worker.name + " is alive - warning"
                            ,C.LOGNONE
                            )
                        still_working = True
                        break #keep waiting for active task
                    else:
##                        Log(worker.name + " is dead"
##                            ,C.LOGNONE
##                            )
                        pass
                        
                    

                
            get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
            
        except StopIteration,GeneratorExit:
            #Log("StopIteration")
            pass
        except:
            traceback.print_exc()

    finally:
        try:
            Log(repr(len(worker_threads)))
            for worker in worker_threads:
                if worker.isAlive():
                    Log("Warning: killed thread {}".format(repr(worker.name)))
                    worker._Thread__stop()
        except:
            traceback.print_exc()
                    
        if progress_dialog:
            if progress_dialog.iscanceled():
                utils.addDownLink(
                    name=C.STANDARD_MESSAGE_CANCELLED_SEARCH
                    ,url=C.DO_NOTHING_URL
                    ,duration = C.STANDARD_DURATION_REFRESH
                    ,mode=C.ROOT_INDEX_INDEX
                    )
            progress_dialog.close()

    Log("Quick_Search ended")
    utils.endOfDirectory()

    
#__________________________________________________________________________
#
#@C.url_dispatcher.register(C.QWIK_SEARCH, ['url', 'channel'], ['end_directory','page','keyword'])
def Quick_SearchX(url, channel, end_directory=True, page='1', keyword=None):
    Log("Quick_Search url='{}', channel='{}', end_directory='{}', page='{}', keyword='{}'".format( url, channel, end_directory, page, keyword))

    if not keyword:
        ##get the search string from user; remember it; pre-populate remembered
        prev_search_string = C.this_addon.getSetting(id='quick_search_string')
        quick_search_string = _get_keyboard(
            heading="Search query"
            ,default=prev_search_string
            )
        if  quick_search_string == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.this_addon.setSetting(id='quick_search_string', value=quick_search_string)
    else:
        quick_search_string = keyword


    progress_dialog = None
    progress_dialog = utils.Progress_Dialog(C.addon_name,"searching '{}'".format(quick_search_string))

    try:
            
        if C.ROOT_SEARCH_ALL == str(channel):
            end_directory = False #this sub will set the directory

        get_sites = utils.Get_Sites()
        q = Queue.Queue()
        #q = multiprocessing.Queue()
        i = 0
        all_method_results = {}
        try: 
            for sitename, module in get_sites:
                if module.SEARCH_MODE == str(channel) or C.ROOT_SEARCH_ALL == str(channel):
                    #i = i + 1 #testing
                    if i > 10: break #testing
                    all_method_results[sitename] = None
                    method_to_call = getattr(module, 'Search')
                    kwargs = {
                        "searchUrl": module.SEARCH_URL
                        ,"keyword": quick_search_string
                        ,"end_directory": end_directory
                        ,"page": page
                        ,"progress_dialog": progress_dialog
                        }
                    q.put( (sitename,method_to_call,kwargs) )
                
            for k in range(5): #C.MAX_WEBCRAWLER_THREADS):
                
##                worker = multiprocessing.Process(target=utils.crawl
##                                          , args=(q,all_method_results))

                worker = threading.Thread(target=utils.crawl
                                          , args=(q,all_method_results))
                worker.daemon = True
                worker.start()
            #q.join(60.0)
            q.join()
            get_sites.send(False) #cancel yield operations; will raise StopIteration inside get_sites
        except StopIteration:
            pass
        except:
            traceback.print_exc()
            
        for result in all_method_results:
            if not(all_method_results[result] in [None, True]):
                utils.addDownLink(
                    name=C.STANDARD_MESSAGE_FAILED_SEARCH.format(result, all_method_results[result])
                    ,url=C.DO_NOTHING_URL
                    ,mode=C.ROOT_INDEX_INDEX
                    ,duration = C.STANDARD_DURATION_REFRESH
                    )
    finally:
        if progress_dialog:
            if progress_dialog.iscanceled():
                utils.addDownLink(
                    name=C.STANDARD_MESSAGE_CANCELLED_SEARCH
                    ,url=C.DO_NOTHING_URL
                    ,duration = C.STANDARD_DURATION_REFRESH
                    ,mode=C.ROOT_INDEX_INDEX
                    )
            progress_dialog.close()

    Log("Quick_Search ended")
    utils.endOfDirectory()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_SEARCH_ALL, ['page'], ['keyword']  )
def Search_All(page=1, keyword=None):

    if not keyword:
        searchDir(url=C.DO_NOTHING_URL, mode=C.ROOT_SEARCH_ALL)
        return
    
    #temporarilty force only  X   recurse depth for this feature
    C.DEFAULT_RECURSE_DEPTH = 1
    C.MAX_RECURSE_DEPTH = 1

    Quick_Search(url=C.DO_NOTHING_URL,channel=C.ROOT_SEARCH_ALL,keyword=keyword)

    utils.endOfDirectory()
#__________________________________________________________________________
#
def searchDir(url, mode, page='1', end_directory=False):

    try:
        label = "{}[COLOR {}]Quick Search[/COLOR]".format(
            C.SPACING_FOR_TOPMOST
            ,C.search_text_color
            ) 
        utils.addDir(
            name=label
            ,url=url 
            ,mode=C.QWIK_SEARCH 
            ,iconimage=C.search_icon 
            ,page=page
            ,channel=mode
            ,end_directory=end_directory)

        utils.addDir(
            "{}[COLOR {}]Add Keyword[/COLOR]".format(C.SPACING_FOR_NEXT,C.search_text_color)
            , url=''
            , mode=C.ADD_KEYWORD
            , iconimage=C.search_icon
            , channel=mode)

        conn = sqlite3.connect(C.favoritesdb)
        db_cursor = conn.cursor()
        try:
            db_cursor.execute("SELECT * FROM keywords")
            for (keyword,) in db_cursor.fetchall():
                label = "{}[COLOR {}]{}[/COLOR]".format(
                    C.SPACING_FOR_NAMES
                    , C.time_text_color
                    , urllib.unquote_plus(keyword)
                    )
                utils.addDir(
                    name=label
                    , url=url 
                    , mode=mode
                    , iconimage=C.search_icon 
                    , page=page
                    , keyword=keyword
                    , end_directory=end_directory
                    )
        except:
            traceback.print_exc()
            pass
    except:
        traceback.print_exc()
        raise
    
    utils.endOfDirectory()
#__________________________________________________________________________
#
