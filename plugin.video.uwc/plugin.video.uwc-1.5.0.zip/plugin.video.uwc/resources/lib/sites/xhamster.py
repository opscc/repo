'''
  Ultimate Whitecream
  Copyright (C) 2016 Whitecream, hdgdl
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib2
import os
import re
import sys
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://xhamster.com"

SEARCH_URL = ROOT_URL + '/search?q={}&p={}'

URL_RECENT = ROOT_URL + '/videos/latest'
URL_CATEGORIES = ROOT_URL + '/categories'


MAIN_MODE       = '505'
LIST_MODE       = '506'
PLAY_MODE       = '507'
CATEGORIES_MODE = '508'
SEARCH_MODE     = '509'

cookie = {'Cookie': 'lang=en; search_video=%7B%22sort%22%3A%22da%22%2C%22duration%22%3A%22%22%2C%22channels%22%3A%22%3B0.1.2%22%2C%22quality%22%3A0%2C%22date%22%3A%22%22%7D;'}

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color)
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon)
        
    List(url=URL_RECENT, end_directory=True, keyword=None)

def merge_two_dicts(x, y):
    z = x.copy()   # start with x's keys and values
    z.update(y)    # modifies z with y's keys and values & returns None
    return z

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)


    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    listhtml = utils.getHtml(list_url, referer='', hdr=merge_two_dicts(cookie, utils.headers), ignore404=True ) #cookie+utils.headers
    if 'class="result-count">0</span>' in listhtml:
        video_region = ""
        next_page_html = ""
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon )
    else:
        next_page_html = listhtml
        if 'div class="banner-mobile"' in listhtml:
            video_region = listhtml.split('div class="banner-mobile"')[1]
        else:
            video_region = listhtml

    #
    # parse out list items
    #
    regex = 'thumb-image-container" href="([^"]+)".+?(thumb-image-container__icon--uhd"|thumb-image-container__icon--hd"|thumb-image-container__icon").+?src="([^"]+)" .+?alt="([^"\n]+)">.+?>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, hd, thumb, label, duration in info:
        if '--uhd' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '--fhd' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif '--hd' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.html_parser.unescape(utils.cleantext(label)), hd)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration ) 

    #
    # next page items
    #
    next_page_regex = 'class=\"xh-paginator-button  active\".+?class=\"xh-paginator-button \".+?href=\"([^\"]+)\".+?data-page=\"([^\"]+)\"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
        #note: 2019-05-01 xhamster does not have 'next' on 'newest vid page'
    else:
        #Log("np_info='{}'".format(np_info))
        for np_url, np_number in np_info:
            np_number = int(np_number)
            currentpage = np_number - 1
            if ".html" in url:
                ##normal page
                np_url = url.replace('-'+str(currentpage)+'.html', '-'+str(np_number)+'.html')
            elif "/tags/" in url:
                np_url = np_url
            else:
                ##search page
                if "p=" not in url:
                    np_url = url + "&p=" + str(currentpage)
                np_url = url.replace('p='+str(currentpage),'p='+str(np_number)) 
                
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)

            #Log("np_url='{}'".format(np_url))
            #Log("np_label='{}'".format(np_label))
            
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH #set here to support 'search_all'
                if int(np_number) < MAX_SEARCH_DEPTH: #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    response = utils.getHtml(url)
    #match = re.compile("file: '(http[^']+)", re.DOTALL | re.IGNORECASE).findall(response)
    match_2160 = re.compile('"mp4":.*?"2160p":"([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(response)
    match_720 = re.compile('"mp4":.*?"720p":"([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(response)
    match_480 = re.compile('"mp4":.*?"480p":"([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(response)
    match_240 = re.compile('"mp4":.*?"240p":"([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(response)
    match_144 = re.compile('"mp4":.*?"144p":"([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(response)

    if match_2160 and utils.addon.getSetting("allow_super_high_resolution").lower() == "true": match = match_2160
    elif match_720: match = match_720
    elif match_480: match = match_480
    elif match_240: match = match_240
    elif match_144: match = match_144
    
    if match:
        utils.playvid(match[0].replace("\/", "/"), name.replace("[COLOR {}]hd[/COLOR]".format(utils.time_text_color),""), download)
    else:
        utils.notify('Oh oh','Couldn\'t find a video')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url, '')
    cathtml = cathtml.split('class="letter-blocks page"')[1].split('<div class="search">')[0]

    regex = '<a href="([^"]+)" >([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, label) 
        #if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        thumb = utils.search_icon
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
        utils.addDir(name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace('+',' ').replace(' ','_')
    searchUrl = SEARCH_URL.format(keyword, '{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
        
