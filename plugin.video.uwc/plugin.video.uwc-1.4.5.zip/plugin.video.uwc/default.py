'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import os.path
import sys
import socket
import traceback

import xbmc
import xbmcplugin
import xbmcaddon
from resources.lib import utils
from resources.lib import favorites
from resources.lib.sites import *
from resources.lib.utils import Log

if int(sys.argv[1]) > 0: 
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
       
addon = xbmcaddon.Addon(id=utils.__scriptid__)

dialog = utils.dialog
imgDir = utils.imgDir
rootDir = utils.rootDir

@utils.url_dispatcher.register('0')
def INDEX():

    utils.addDir(name= '[COLOR {}]Search All[/COLOR]'.format(utils.search_text_color), url='',mode=utils.ROOT_SEARCH_ALL,iconimage=utils.search_icon,page=None,keyword='')
    utils.addDir(name='[COLOR {}]Front Pages[/COLOR]'.format(utils.refresh_text_color),url='',mode=utils.ROOT_FRONT_PAGE,iconimage=utils.search_icon,page=None,keyword='')

    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Scenes[/COLOR]','',1,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Movies[/COLOR]','',2,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Hentai[/COLOR]','',3,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Tubes[/COLOR]','',6,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Webcams & Streams[/COLOR]','',7,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Favorites[/COLOR]','',901,os.path.join(rootDir, 'icon.png'),'')
    download_path = addon.getSetting('download_path')
    if download_path != '' and os.path.exists(download_path):
        utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Download Folder[/COLOR]',download_path,4,os.path.join(rootDir, 'icon.png'),'',Folder=False)

    utils.endOfDirectory()

@utils.url_dispatcher.register('1')
def INDEXS():
    utils.addDir('[COLOR hotpink]WatchXXXFree[/COLOR]','',                     watchxxxfree.MAIN_MODE,os.path.join(imgDir, 'wxf.png'),'')
    utils.addDir('[COLOR hotpink]PornTrex[/COLOR]','',                             porntrex.MAIN_MODE,os.path.join(imgDir, 'pt.png'),'')
    utils.addDir('[COLOR hotpink]pornaq[/COLOR]','',                                 pornaq.MAIN_MODE,os.path.join(imgDir, 'paq.png'),'')
    utils.addDir('[COLOR hotpink]Porn00[/COLOR]','',                                 porn00.MAIN_MODE,os.path.join(imgDir, 'p00.png'),'')
    utils.addDir('[COLOR hotpink]Beeg[/COLOR]','',                                     beeg.MAIN_MODE,os.path.join(imgDir, 'bg.png'),'')
    utils.addDir('[COLOR hotpink]XvideoSpanish[/COLOR]','',                   xvideospanish.MAIN_MODE,os.path.join(imgDir, 'xvideospanish.png'),'')
    utils.addDir('[COLOR hotpink]HQPorner[/COLOR]','',                             hqporner.MAIN_MODE,os.path.join(imgDir, 'hqporner.png'),'')
    utils.addDir('[COLOR hotpink]VideoMegaPorn[/COLOR]','',                   videomegaporn.MAIN_MODE,os.path.join(imgDir, 'videomegaporn.png'),'')
    utils.addDir('[COLOR hotpink]StreamXXX[/COLOR]','',                           streamxxx.MAIN_MODE,os.path.join(imgDir, 'streamxxx.png'),'')
    utils.addDir('[COLOR hotpink]YourFreeTube[/COLOR]','',                     yourfreetube.MAIN_MODE,os.path.join(imgDir, 'yourfreetube.png'),'')
    utils.addDir('[COLOR hotpink]Xtasie[/COLOR]','',                                 xtasie.MAIN_MODE,os.path.join(imgDir, 'xtasie.png'),'')
    utils.addDir('[COLOR hotpink]Mr Sexe[/COLOR]','http://www.mrsexe.com/',          mrsexe.MAIN_MODE,os.path.join(imgDir, 'mrsexe.png'),'')
    utils.addDir('[COLOR hotpink]Ero-tik[/COLOR]','',                                erotik.MAIN_MODE,os.path.join(imgDir, 'erotik.png'),'')
    utils.addDir('[COLOR hotpink]CzechHD[/COLOR]','',                               czechhd.MAIN_MODE,os.path.join(imgDir, 'czechhd.png'),'')     
    utils.addDir('[COLOR hotpink]XXX Streams (eu)[/COLOR]' ,'',                  xxxstreams.MAIN_MODE,os.path.join(imgDir, 'xxxstreams.png'),'')
    utils.addDir('[COLOR hotpink]XXX Streams (org)[/COLOR]','',                     xxxsorg.MAIN_MODE,os.path.join(imgDir, 'xxxsorg.png'),'')
    utils.addDir('[COLOR hotpink]K18[/COLOR]','',                                       k18.MAIN_MODE,os.path.join(imgDir, 'k18.png'),'')
    utils.addDir('[COLOR hotpink]daftsex[/COLOR]','',                               daftsex.MAIN_MODE,'','')
    utils.add_sort_method()
    utils.endOfDirectory()
        
@utils.url_dispatcher.register('2')
def INDEXM():
    utils.addDir('[COLOR hotpink]Xtheatre[/COLOR]','http://xtheatre.net/page/1/',20,os.path.join(imgDir, 'xt.png'),'')
    utils.addDir('[COLOR hotpink]PornHive[/COLOR]','http://www.pornhive.tv/en/movies/all',70,os.path.join(imgDir, 'ph.png'),'')
    utils.addDir('[COLOR hotpink]StreamXXX[/COLOR]','http://streamxxx.tv/category/movies/',175,os.path.join(imgDir, 'streamxxx.png'),'')
    utils.addDir('[COLOR hotpink]ParadiseHill[/COLOR]','http://www.paradisehill.tv/en/',250,os.path.join(imgDir, 'paradisehill.png'),'')
    utils.addDir('[COLOR hotpink]FreeOMovie[/COLOR]','http://www.freeomovie.com/',370,os.path.join(imgDir, 'freeomovie.png'),'')
    utils.add_sort_method()
    utils.endOfDirectory()
       
@utils.url_dispatcher.register('6')
def INDEXT():
    utils.addDir('[COLOR hotpink]BubbaPorn[/COLOR]','',                           bubbaporn.MAIN_MODE,os.path.join(imgDir, 'bubba.png'),'')
    utils.addDir('[COLOR hotpink]Poldertube.nl (Dutch)[/COLOR]','',              poldertube.MAIN_MODE,os.path.join(imgDir, 'poldertube.png'),0)
    utils.addDir('[COLOR hotpink]Sextube.nl (Dutch)[/COLOR]','',                    sextube.MAIN_MODE,os.path.join(imgDir, 'sextube.png'),2)
    utils.addDir('[COLOR hotpink]TubePornClassic[/COLOR]','',               tubepornclassic.MAIN_MODE,os.path.join(imgDir, 'tubepornclassic.png'),'')
    utils.addDir('[COLOR hotpink]HClips[/COLOR]','',                                 hclips.MAIN_MODE,os.path.join(imgDir, 'hclips.png'),'')
    utils.addDir('[COLOR hotpink]PornHub[/COLOR]','',                               pornhub.MAIN_MODE,os.path.join(imgDir, 'pornhub.png'),'')

    utils.addDir('[COLOR hotpink]Porndig Professional[/COLOR]','http://www.porndig.com',porndig.MAIN_MODE,os.path.join(imgDir, 'porndig.png'),'', channel=porndig.main_category_id_PROFESSIONALS)
    utils.addDir('[COLOR hotpink]Porndig Amateurs[/COLOR]','http://www.porndig.com',porndig.MAIN_MODE,os.path.join(imgDir, 'porndig.png'),'', channel=porndig.main_category_id_AMATURES)

    utils.addDir('[COLOR hotpink]AbsoluPorn[/COLOR]','',                         absoluporn.MAIN_MODE,os.path.join(imgDir, 'absoluporn.gif'),'')
    utils.addDir('[COLOR hotpink]Anybunny[/COLOR]','',                             anybunny.MAIN_MODE,os.path.join(imgDir, 'anybunny.png'),'')    
    utils.addDir('[COLOR hotpink]SpankBang[/COLOR]','',                           spankbang.MAIN_MODE,os.path.join(imgDir, 'spankbang.png'),'')	
    utils.addDir('[COLOR hotpink]Amateur Cool[/COLOR]','',                      amateurcool.MAIN_MODE,os.path.join(imgDir, 'amateurcool.png'),'')	
    utils.addDir('[COLOR hotpink]Vporn[/COLOR]','',                                   vporn.MAIN_MODE,os.path.join(imgDir, 'vporn.png'),'')
    utils.addDir('[COLOR hotpink]xHamster[/COLOR]','',                             xhamster.MAIN_MODE,os.path.join(imgDir, 'xhamster.png'),'')
    utils.addDir('[COLOR hotpink]Tube8[/COLOR]','',                                   tube8.MAIN_MODE,os.path.join(imgDir, 'tube8.png'),'')
    utils.addDir('[COLOR hotpink]Xvideos[/COLOR]','',                               xvideos.MAIN_MODE,os.path.join(imgDir, 'xvideos.png'),'')
    utils.addDir('[COLOR hotpink]PornHD[/COLOR]','',                                 pornhd.MAIN_MODE,os.path.join(imgDir, 'pornhd.png'),'')
    utils.addDir('[COLOR hotpink]pornOxO[/COLOR]','',                               pornoxo.MAIN_MODE,os.path.join(imgDir, 'pornoxo.png'),'')
    utils.addDir('[COLOR hotpink]pornmaki[/COLOR]','',                             pornmaki.MAIN_MODE,os.path.join(imgDir, 'pornmaki.png'),'')
    utils.addDir('[COLOR hotpink]pornburst[/COLOR]','',                           pornburst.MAIN_MODE,os.path.join(imgDir, 'pornburst.png'),'')
    utils.addDir('[COLOR hotpink]moviefap[/COLOR]','',                             moviefap.MAIN_MODE,os.path.join(imgDir, 'moviefap.png'),'')
    utils.addDir('[COLOR hotpink]empflix[/COLOR]','',                               empflix.MAIN_MODE,os.path.join(imgDir, 'empflix.png'),'')
    utils.addDir('[COLOR hotpink]extremetube[/COLOR]','',                       extremetube.MAIN_MODE,os.path.join(imgDir, 'extremetube.png'),'')
    utils.addDir('[COLOR hotpink]faapy[/COLOR]','',                                   faapy.MAIN_MODE,os.path.join(imgDir, 'faapy.png'),'')
    utils.addDir('[COLOR hotpink]girlfriendvideos[/COLOR]','',             girlfriendvideos.MAIN_MODE,os.path.join(imgDir, 'girlfriendvideos.png'),'')
    utils.addDir('[COLOR hotpink]mofosex[/COLOR]','',                               mofosex.MAIN_MODE,os.path.join(imgDir, 'mofosex.png'),'')
    utils.addDir('[COLOR hotpink]motherless[/COLOR]','',                         motherless.MAIN_MODE,os.path.join(imgDir, 'motherless.png'),'')
    utils.addDir('[COLOR hotpink]bitporno[/COLOR]','',                             bitporno.MAIN_MODE,os.path.join(imgDir, 'bitporno.png'),'')
    utils.addDir('[COLOR hotpink]redtube[/COLOR]','',                               redtube.MAIN_MODE,os.path.join(imgDir, 'redtube.png'),'')
    utils.addDir('[COLOR hotpink]sunporno[/COLOR]','',                             sunporno.MAIN_MODE,os.path.join(imgDir, 'sunporno.png'),'')
    utils.addDir('[COLOR hotpink]porn.com[/COLOR]','',                                 porn.MAIN_MODE,os.path.join(imgDir, 'porn.com.png'),'')
    utils.addDir('[COLOR hotpink]youporn[/COLOR]','',                               youporn.MAIN_MODE,os.path.join(imgDir, 'youporn.png'),'')
    utils.addDir('[COLOR hotpink]madthumbs[/COLOR]','',                           madthumbs.MAIN_MODE,os.path.join(imgDir, 'madthumbs.png'),'')
    utils.addDir('[COLOR hotpink]slutload[/COLOR]','',                             slutload.MAIN_MODE,os.path.join(imgDir, 'slutload.png'),'')
    utils.addDir('[COLOR hotpink]ah-me[/COLOR]','',                                   ah_me.MAIN_MODE,os.path.join(imgDir, 'ah_me.png'),'')
    utils.addDir('[COLOR hotpink]eporner[/COLOR]','',                               eporner.MAIN_MODE,os.path.join(imgDir, 'eporner.png'),'')
    utils.addDir('[COLOR hotpink]pornomovies[/COLOR]','',                       pornomovies.MAIN_MODE,os.path.join(imgDir, 'pornomovies.png'),'')
    utils.addDir('[COLOR hotpink]tukif[/COLOR]','',                                   tukif.MAIN_MODE,os.path.join(imgDir, 'tukif.png'),'')    
    utils.add_sort_method()
    utils.endOfDirectory()
       
@utils.url_dispatcher.register('7')
def INDEXW():
    utils.addDir('[COLOR hotpink]Chaturbate[/COLOR] [COLOR white]- webcams[/COLOR]','https://chaturbate.com/?page=1' ,chaturbate.MAIN_MODE ,os.path.join(imgDir, 'chaturbate.png'),'')
    utils.addDir('[COLOR hotpink]MyFreeCams[/COLOR] [COLOR white]- webcams[/COLOR]','https://www.myfreecams.com', 270, os.path.join(imgDir, 'myfreecams.jpg'),'')
    utils.addDir('[COLOR hotpink]Cam4[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.cam4.com',280,os.path.join(imgDir, 'cam4.png'),'')    
    #utils.addDir('[COLOR hotpink]Camsoda[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.camsoda.com',475,os.path.join(imgDir, 'camsoda.png'),'')    
    utils.addDir('[COLOR hotpink]naked.com[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.naked.com',480,os.path.join(imgDir, 'naked.png'),'')
    if sys.version_info >= (2, 7, 9):
        utils.addDir('[COLOR hotpink]streamate.com[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.streammate.com',515,os.path.join(imgDir, 'streamate.png'),'')
    utils.addDir('[COLOR hotpink]bongacams.com[/COLOR] [COLOR white]- webcams[/COLOR]','http://www.bongacams.com',520,os.path.join(imgDir, 'bongacams.png'),'')
    utils.endOfDirectory(True)

@utils.url_dispatcher.register('3')
def INDEXH():
    utils.addDir('[COLOR hotpink]Hentaihaven[/COLOR]','http://hentaihaven.org/?sort=date',460,os.path.join(imgDir, 'hh.png'),'')
    utils.endOfDirectory()

@utils.url_dispatcher.register(utils.ROOT_SEARCH_ALL, ['page'], ['keyword']  )
def Search_All(page=1,keyword=None):

    if not keyword:
        utils.searchDir('fakeurl', mode=utils.ROOT_SEARCH_ALL)
        return
    
    #temporarilty force only  X   recurse depth for this feature
    utils.DEFAULT_RECURSE_DEPTH = 1

    #only use 'quality' providers that provide clip time
    try:    eporner.Search(eporner.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching eporner')
    try:    porntrex.Search(porntrex.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching porntrex')
    try:    k18.Search(k18.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching k18')
    try:    daftsex.Search(daftsex.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching daftsex')
    try:    pornhub.Search(pornhub.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching pornhub')
    try:     vporn.Search(vporn.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching vporn')
    try:    xhamster.Search(xhamster.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching xhamster')
    try:    hqporner.Search(hqporner.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching hqporner')
    try:    hclips.Search(hclips.SEARCH_URL, keyword, end_directory=False)
    except:  utils.Notify('error searching hclips')
    try:    youporn.Search(youporn.SEARCH_URL, keyword, end_directory=False)
    except:
        traceback.print_exc()
        utils.Notify('error searching youporn')
    try:
        porndig.Search(porndig.main_category_id_PROFESSIONALS, keyword=keyword, end_directory=False)
    except:
        traceback.print_exc()
        utils.Notify('error searching porndig')
    try:
        porn.Search(porn.SEARCH_URL, keyword=keyword, end_directory=False)
    except:
        traceback.print_exc()
        utils.Notify('error searching porn')
    try:
        pornaq.Search(pornaq.SEARCH_URL, keyword=keyword, end_directory=False)
    except:
        traceback.print_exc()
        utils.Notify('error searching pornAQ')
    try:
        porn00.Search(porn00.SEARCH_URL, keyword=keyword, end_directory=False)
    except:
        traceback.print_exc()
        utils.Notify('error searching porn00')
    try:
        hclips.Search(hclips.SEARCH_URL, keyword=keyword, end_directory=False)
    except:
        traceback.print_exc()
        utils.Notify('error searching hclips')
    try:
        erotik.Search(erotik.SEARCH_URL, keyword=keyword, end_directory=False)
    except:
        traceback.print_exc()
        utils.Notify('error searching erotik')
    try:
        beeg.Search(beeg.SEARCH_URL, keyword=keyword, end_directory=False)
    except:
        traceback.print_exc()
        utils.Notify('error searching beeg')
        
    utils.add_sort_method()
    utils.endOfDirectory()
    

#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_FRONT_PAGE, ['page'], ['keyword']  )
def Front_Page(page=1,keyword=None):

    #temporarilty force only  X   recurse depth for this feature
    utils.DEFAULT_RECURSE_DEPTH = 0

    #only use 'quality' providers that provide clip time
    try:
        hqporner.List(hqporner.URL_RECENT, page='1', end_directory=False, keyword='')
        eporner.List(  eporner.URL_RECENT, page='1', end_directory=False, keyword='')
        porntrex.List(porntrex.URL_RECENT, page='1', end_directory=False, keyword='')
        daftsex.List(  daftsex.URL_RECENT, page='1', end_directory=False, keyword='')
        pornhub.List(  pornhub.URL_RECENT, page='1', end_directory=False, keyword='')
        vporn.List(      vporn.URL_RECENT, page='1', end_directory=False, keyword='')
        xhamster.List(xhamster.URL_RECENT, page='1', end_directory=False, keyword='')
        hclips.List(    hclips.URL_RECENT, page='1', end_directory=False, keyword='')
    except:
        traceback.print_exc()
    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register('4', ['url'])
def OpenDownloadFolder(url):
    xbmc.executebuiltin("ActivateWindow(Videos, {})".format(url))

def change():
    if os.path.isfile(utils.uwcchange):
        heading = '[B][COLOR hotpink]Whitecream[/COLOR] [COLOR white]Changelog[/COLOR][/B]'
        utils.textBox(heading,utils.uwcchange)
        os.remove(utils.uwcchange)

##if not addon.getSetting('uwcage') == 'true':
##    age = dialog.yesno('WARNING: This addon contains adult material.','You may enter only if you are at least 18 years of age.', nolabel='Exit', yeslabel='Enter')
##    if age:
##        addon.setSetting('uwcage','true')
##else:
##    age = True


def main(argv=None):
    if sys.argv: argv = sys.argv
    queries = utils.parse_query(sys.argv[2])
    mode = queries.get('mode', None)
    try:
        mode_via_url = sys.argv[0].split('/')[3]
        mode = str(int(mode_via_url))
    except:
        pass

    utils.url_dispatcher.dispatch(mode, queries)

if __name__ == '__main__':
    change()
    sys.exit(main())
