'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://streamxxx.tv"

SEARCH_URL = ROOT_URL + '/page/{}/?s={}'
#https://streamxxx.tv/page/2/?s=karlie+montana

URL_CATEGORIES = ROOT_URL + '/top-tags/'
URL_CLIPS = ROOT_URL + '/category/clips/'
#URL_RECENT = ROOT_URL
URL_RECENT = ROOT_URL + '/page/{}/'

MAIN_MODE       = '175'
LIST_MODE       = '171'
PLAY_MODE       = '172'
CATEGORIES_MODE = '173'
SEARCH_MODE     = '174'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon )

    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
        
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)        
        
    if '{}' in url and page: list_url = url.format(page)
    else: list_url = url
    listhtml = utils.getHtml(list_url, url)
    if "but nothing matched your search" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon 
            )
    else: #distinguish between adverts and videos
        try:
            regex = 'id="search_results"(.+)'
            #video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
            video_region = listhtml.split('class="st-site-main')[1].split("class='page-numbers'")[0]
        except:
##            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
        
        

    #
    # main list items
    #
    #Log("video_region='{}'".format(video_region))
    videos_regex = "(?:<article id=|class=\"quadrato\").*?<a href=\"([^\"]+)\".*?title=\"([^\"]+)\".*?src=\"([^\"]+)\"" 
    videos_regex = '(?:<article id=|class="quadrato").+?<a href=([^\s]+) title="([^"]+)".*?src=([^\s]+)'  #someone removed quotes from template???
    info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb in info:

        #2019-07-06 all? of the 4k inside file lockers, so this label may not mean much
        if '/4K)' in label:
            hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
            label = label.replace('/4K)',')')
        elif '/FULLHD)' in label:
            hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
            label = label.replace('/FULLHD)',')')
        elif '/HD)' in label:
            hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
            label = label.replace('/HD)',')')
        else: hd = ""
        
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        thumb = thumb.replace(".pixhost.org/", ".pixhost.to/")
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb)


    #
    # next page items
    #
    try:
        next_page_html = listhtml.split("<ul class='page-numbers'")[1]
    except:
        next_page_html = listhtml
    #Log("next_page_html='{}'".format(next_page_html))
    next_page_regex = 'page-numbers" href="([^"]+)">Next<'
    next_page_regex = 'next page-numbers" href="?.+?page/(\d)/.+?>Next<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_number in np_info:
            #Log("np_url={}".format(np_url))
##            np_number = '' #page number can be multiple places depending if search result or not
##            if not np_number.isdigit(): np_number=np_url.split('/')[4]
##            if not np_number.isdigit(): np_number=np_url.split('/')[5]
##            if not np_number.isdigit(): np_number=np_url.split('/')[6]
##            if not np_number.isdigit(): np_number=np_url.split('/')[7]
            np_url=url
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break


    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page='1', end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    html = utils.getHtml(url, ROOT_URL)

    clips_regex = 'FILMS(.+)TOP TAGS'
    clips_html = re.compile(clips_regex, re.DOTALL).findall(html)
    #Log("clips_html='{}'".format(clips_html))
    if clips_html:
        clips_html = clips_html[0]
        clips_regex = 'li id="menu-item.+?href="([^"]+)">([^<]+)<'
        info = re.compile(clips_regex, re.DOTALL | re.IGNORECASE).findall(clips_html)
        #Log("info='{}'".format(info))
        for url, label in info:
            if url.startswith('/'): url = ROOT_URL + url
            #Log("url='{}'".format(url))
            utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color, label)
                ,url=url 
                ,mode=LIST_MODE 
                ,iconimage=utils.search_icon 
                )


    tags_region_regex = '>Top Tags<(.+?)</main>'
    tags_region_html = re.compile(tags_region_regex, re.DOTALL | re.IGNORECASE).findall(html)
    if tags_region_html:
        #Log("tags_region_html='{}'".format(tags_region_html))
        tags_region_html = tags_region_html[0]
        regex = 'a id="tag.+?href="([^"]+)" rel="tag">([^<]+)<'
        regex = 'id=tag.+?href=([^\s]+) rel=tag>([^<]+)<' #some reason, getting rid of quotes
        info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(tags_region_html)
        Log("info='{}'".format(info))
        for url, label in info:
            url = url + '/page/{}/'
            #
            utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color, label)
                ,url=url 
                ,mode=LIST_MODE 
                ,iconimage=utils.search_icon
                ,page="1"
                )

##    clips_regex = 'VIDEOS(.+)FILMS'
##    clips_html = re.compile(clips_regex, re.DOTALL).findall(html)
##    regex = 'li id="menu-item.+?href="([^"]+)".*?>([^<]+)<'
##    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(clips_html)
##    #Log("info='{}'".format(info))
##    for url, label in info:
##        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
##            SPACING_FOR_TOPMOST, utils.search_text_color, label)
##            ,url=url 
##            ,mode=LIST_MODE 
##            ,iconimage=utils.search_icon 
##            )
                        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page='1')
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    utils.PLAYVIDEO(url, name, download)
    
#__________________________________________________________________________
#

