'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc,xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://viralvideosporno.com"

SEARCH_URL = ROOT_URL + '/buscar_{}_pag-{}.html'
#http://viralvideosx.com/buscar-vina+sky.html
#https://viralvideosporno.com/buscar_kendra_pag-1.html

URL_CATEGORIES = ROOT_URL + '/top-tags/'
URL_CLIPS = ROOT_URL + '/category/clips/'
URL_RECENT = ROOT_URL + "/pagina/{}/"
#https://viralvideosporno.com/pagina/1/

MAIN_MODE       = '160'
LIST_MODE       = '161'
PLAY_MODE       = '162'
CATEGORIES_MODE = '163'
SEARCH_MODE     = '164'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):
    
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)


    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    video_region = utils.getHtml(list_url, url)
    if "NO SE HAN ENCONTRADO REGISTRO" in video_region:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon )
##    else: #distinguish between adverts and videos
##        try:
##            video_region = listhtml.split('class="contenedor_noticias')[1].split('id="pagination"')[0]
##        except:
##            video_region = listhtml


    #
    # main list items
    #
    #regex = 'pore\">.+?title=\"([^\"]+)\".*?href=\"([^\"]+)\">.+?img src=\"([^\"]+)\"'
    #regex = 'pore">.+?title="([^"]+)".+?href="([^"]+)">.+?img src="([^"]+)".+?class="tags">(.+?)</footer>'
    #regex = 'class="notice">.+?title="([^"]+)".+?href="([^"]+)">.+?class="tags">(.+?)<.+?img src="([^"]+)">'
    regex = 'class="notice_title">.+?title="([^"]+)".+?href="([^"]+)">.+?class="tags">(.+?)<.+?img src="([^"]+)">'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for label, videourl, hd, thumb in info:
        if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        if videourl.startswith('/'): videourl = 'https:' + videourl
        if thumb.startswith('/'): thumb = 'https:' + thumb
##        Log("thumb='{}'".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb)
        

    #
    # next page items
    #
    next_page_html = ""
    if not video_region == "": 
        next_page_html = video_region.split('id="pagination"')
        if next_page_html: next_page_html = next_page_html[1]
    else:
        next_page_html = ""
    next_page_html = next_page_html[::-1] # in order to use a single regex for search and normal results, we need to search backwards...
##    Log("next_page_html={}".format(next_page_html))

    #next_page_regex = ";ouqar&.*?'=eltit '([^']+)'=ferh"
    next_page_regex = "<etneiugiS>.+?'=eltit '([^']+)'=ferh"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            np_url=np_url[::-1]
            Log("np_url={}".format(np_url))
            np_number = int(page) + 1
##            np_number = '' #page number can be multiple places depending if search result or not
##            if '/' in np_url:
##                if not np_number.isdigit(): np_number=np_url.split('/')[4]
##                if not np_number.isdigit(): np_number=np_url.split('/')[5]
##                if not np_number.isdigit(): np_number=np_url.split('/')[6]
##                if not np_number.isdigit(): np_number=np_url.split('/')[7]
##            if '_pag' in np_url:
##                np_number=np_url.split('_pag-')[1].split('.')[0]
            if np_url.startswith('/'): np_url = 'http:' + np_url
            if not np_url.startswith('http'): np_url = ROOT_URL + '/' + np_url
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH
                if int(np_number) <= MAX_SEARCH_DEPTH: #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword, '{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, '')

    cathtml = re.compile('"list-categories"(.*)class="footer-margin', re.DOTALL).findall(html)[0]

    regex = 'href="([^"]+)" title="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label, thumb in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        thumb = "https:" + thumb + utils.Header2pipestring()+"&Referer=" + ROOT_URL + '/'
        keyword = videourl.split('/categories/')[1].split('/')[0]
        #Log("videourl={}".format(videourl))
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,keyword=keyword )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
##    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
##    utils.PLAYVIDEO(url, name, download)

    Log("Playvid url='{}', name='{}', download='{}'".format(url, name, download))
    
    html = utils.getHtml(url, ROOT_URL)
    regex = '<iframe src="([^"]+)"'
    try:
        next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)[0]
    except:
        utils.PLAYVIDEO(url, name, download)
        return

    html = utils.getHtml(next_link, url)
    isHLS = False
    video_url = ""
    regex = 'sources:\s*(\[.+?\])'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
##    Log("sources_list='{}'".format(sources_list))
    sources_list = sources_list[0]

##    sources_list = '[{"src": "https://s23.aparat.cam/hls/,aoqovxkuucr5fwfuhyebkzczjr3zycfppwrixc2q3sdslh5dy4lhhvo4fhta,.urlset/master.m3u8", "type": "application/x-mpegURL"}]'
#    sources_list = '{"foo": 42, "bar": {"baz": "Hello", "poo": 124.2}}'
##    Log(repr(type(sources_list)))
##    Log("sources_list='{}'".format(sources_list))
    regex = '([\w\d]+?):\s"([^"]+)"'
    sources_list = re.sub(regex, '"\\1":"\\2"',  sources_list, flags=re.IGNORECASE)
##    Log("sources_list='{}'".format(sources_list))
    
    import json
    sources = json.loads(sources_list)
    Log("sources='{}'".format(sources))
    Log("sources[src]='{}'".format(sources[0]['src']))
    video_url = sources[0]['src']


    Log("video_url={}".format(video_url.encode()))
    isHLS = True

    if isHLS:
        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        streamtype = 'HLSREDIR'
        #streamtype = 'TSDOWNLOADER'
        streamtype = 'HLS'
        download_path = ""
        if download == 1:
            download_path = utils.Make_download_path(name,file_extension='.mp4')
            
        f4mp.playF4mLink(
            video_url
            , name = name
            , use_proxy_for_chunks = False
            , maxbitrate = utils.MAX_BIT_RATE
            , simpleDownloader = False
            , auth = None
            , streamtype = streamtype
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , download_path = download_path
            )
            
        return
    
#__________________________________________________________________________
#
