#-*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

__scriptname__ = "Ultimate Whitecream"
__author__ = "Whitecream"
__credits__ = "Whitecream, Fr33m1nd, anton40, NothingGnome"
__version__ = "1.1.55"

import urllib
import urllib2
import urllib3
import re
import cookielib
import os.path
import sys
import time, datetime
import tempfile
import sqlite3
import urlparse
import base64
from StringIO import StringIO
import gzip
import traceback
import threading
import ssl
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import cloudflare
from jsunpack import unpack


if sys.version_info >= (3, 0):
    from html.parser import HTMLParser
else:
    from HTMLParser import HTMLParser
html_parser = HTMLParser()

from url_dispatcher import URL_Dispatcher
url_dispatcher = URL_Dispatcher()


USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3770.100 Safari/537.36'

#,'Accept': '*/*'
#,'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
DEFAULT_HEADERS = { 
    'User-Agent': USER_AGENT  
    , 'Accept': '*/*'
    , 'Accept-Encoding': 'gzip'
    , 'Accept-Language': 'en-US,en;q=0.9'
    }
##headers = { 
##    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'
##    , 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
##    , 'Accept-Language': 'en-US,en;q=0.8'
##    , 'Accept-Encoding': 'gzip, deflate, br'
##    , 'DNT': '1' 
##    , 'Connection': 'keep-alive'
##    , 'Upgrade-Insecure-Requests': '1'
##    , 'Cache-Control': 'max-age=0'
##    }



addon_handle = int(sys.argv[1])

this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
#xbmc.log("addon_id={}".format(addon_id), xbmc.LOGNONE)
addon_name = this_addon.getAddonInfo('name')

#addon = xbmcaddon.Addon(addon_id)
addon = this_addon

progress = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
resDir = os.path.join(rootDir, 'resources')
imgDir = os.path.join(resDir, 'images')

uwcicon = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))
uwcchange = xbmc.translatePath(os.path.join(rootDir, 'uwcchange.txt'))

profileDir = addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')
kodiver = xbmc.getInfoLabel("System.BuildVersion").split(".")[0]

refresh_text_color = addon.getSetting('refresh_text_color').lower()
search_text_color = addon.getSetting('search_text_color').lower()
time_text_color = addon.getSetting('time_text_color').lower()
icon_set = addon.getSetting('icon_set').lower()

MAX_BIT_RATE = int(float(addon.getSetting('max_bit_rate'))*1000*1000)
DEFAULT_PLAYMODE = addon.getSetting('default_playmode').lower()  #allow playmode to be forced by input command, or use default from addon settings
PLAYMODE_F4MPROXY = 'f4mproxy'
PLAYMODE_INPUTSTREAM = 'inputstream'
PLAYMODE_DEFAULT = ''

MAX_RECURSE_DEPTH = 10 #some sites will bann IP if too many requests

#xbmc.log("path={}".format(addon.getAddonInfo('path')), xbmc.LOGNONE)
#xbmc.log("addon={}".format(addon), xbmc.LOGNONE)
#xbmc.log("recursive_search_depth={}".format(addon.getSetting('recursive_search_depth')), xbmc.LOGNONE)
DEFAULT_RECURSE_DEPTH = min(MAX_RECURSE_DEPTH, int(addon.getSetting('recursive_search_depth')))
INBAND_RECURSE = 'inband_recurse'

refresh_icon   = os.path.join(imgDir, "library_update_{}.png".format(icon_set) )
search_icon    = os.path.join(imgDir, "search_{}.png".format(icon_set) )
next_icon      = os.path.join(imgDir, "next_{}.png".format(icon_set) )
category_icon  = os.path.join(imgDir, "category_{}.png".format(icon_set) )

if not os.path.exists(profileDir):
    os.makedirs(profileDir)

cj = cookielib.LWPCookieJar(xbmc.translatePath(cookiePath))
Request = urllib2.Request

import requests
my_http_session = requests.Session()

handlers = [urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler()]

if (2, 7, 8) < sys.version_info < (2, 7, 12):
    try:
        import ssl; ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        handlers += [urllib2.HTTPSHandler(context=ssl_context)]
    except:
        pass

if cj != None:
    if os.path.isfile(xbmc.translatePath(cookiePath)):
        try:
            cj.load()
        except:
            try:
                os.remove(xbmc.translatePath(cookiePath))
                pass
            except:
                dialog.ok('Oh oh','The Cookie file is locked, please restart Kodi')
                pass
    cookie_handler = urllib2.HTTPCookieProcessor(cj)
    handlers += [cookie_handler]

opener = urllib2.build_opener(*handlers)
opener = urllib2.install_opener(opener)

favoritesdb = os.path.join(profileDir, 'favorites.db')

QWIK_SEARCH = '905'
ROOT_FRONT_PAGE = '906'
FAVORITES_MODE = '900'
ROOT_SEARCH_ALL = '8'
ROOT_TEST_ALL = '5'
ROOT_INDEX_MOVIES = '2'
ROOT_INDEX_TUBES = '6'
ROOT_INDEX_CAMS = '7'
ROOT_INDEX_HENTAI = '3'
ROOT_INDEX_DOWNLOAD_FOLDER = '4'
ROOT_INDEX_INDEX = '0'
ROOT_INDEX_SCENES = '1'

FLAG_RECURSE_NEXT_PAGES = '-1'

SPACING_FOR_TOPMOST = chr(4)
SPACING_FOR_NAMES =  '' #chr(17)
SPACING_FOR_NEXT = chr(127)

def uwcimage(filename):
    img = os.path.join(imgDir, filename)
    return img

class StopDownloading(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)


def clean_filename(s):
    if not s:
        return ''
    s = re.sub(u'(?is)[^A-Za-z0-9~\]\[ \/,\'.&]','',s)
    return s.strip();

def Make_download_path(name = '', include_date = False, file_extension = ''):

    name = name.strip('\r')
    name = clean_filename(name)
    Log("Make_download_path name='{}'".format(name))    

    if name.startswith('[COLOR') and 'HQ' in name: #color
        name_regex = "(\[color[^\]]+\]HQ\[/color\])([A-Za-z0-9_\-\. ]+)()"
    else:
        name_regex = "(\[color\s*\w*\])\s*([A-Za-z0-9_\-\. ]+)\s*(\[\/color\])"
    parsed_name = re.compile(name_regex, re.DOTALL | re.IGNORECASE).findall(name)
##    Log(str(len(parsed_name)))
    if parsed_name and len(parsed_name[0]) > 1:
        name1 = name.replace(parsed_name[0][0]+parsed_name[0][1]+parsed_name[0][2],'') #trim [color        
        if name1 == '': #incases where whole string is colored
            name=parsed_name[0][1]
        else:
            name=name1

    Log("Make_download_path name='{}'".format(name))    
    name = name.strip()
    download_path = unicode(addon.getSetting("download_path").lower())
    Log("Make_download_path download_path='{}'".format(download_path))    
    if download_path == '':
        try:
            download_path = xbmcgui.Dialog().browse(0, "Download Path", 'myprograms', '', False, False)
            this_addon.setSetting(id='download_path', value=download_path)
            if not os.path.exists(download_path): os.mkdir(download_path)
        except:
            raise 
    download_path = download_path + name

    if include_date:
        download_path = download_path + datetime.datetime.now().strftime(".%Y-%m-%d")

    download_path = download_path + file_extension
    
    Log("Make_download_path download_path='{}'".format(download_path))
    return download_path


def downloadVideo(url, name):

    Log("DownloadVideo name='{}' url='{}'".format(name,url), xbmc.LOGNONE)

    def clean_filename(s):
        if not s:
            return ''
        s = re.sub(u'(?is)[^A-Za-z0-9~\]\[ \/,\'.&]','',s)
        return s.strip();
    
    if '.m3u8' in url:
        Notify("Download for M3U8 experimental")

        m3u8stream = url

        download_path = Make_download_path(name)

        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()

        proxy = None
        #proxy = "127.0.0.1:8888"
        #streamtype = 'HLSRETRY'
        streamtype = 'HLSREDIR'
        #streamtype = 'TSDOWNLOADER'
        #streamtype = 'HLS'
        f4mp.playF4mLink(
            m3u8stream
            , name = name
            , proxy = proxy
            , use_proxy_for_chunks = False
            , maxbitrate = MAX_BIT_RATE
            , simpleDownloader = False
            , auth = None
            , streamtype = streamtype
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , download_path = download_path
            )
            
        return
    
    def _pbhook(downloaded, filesize, name=None,dp=None):
        try:
            percent = min((downloaded*100)/filesize, 100)
            currently_downloaded = float(downloaded) / (1024 * 1024)
            kbps_speed = int(downloaded / (time.clock() - start))

            if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
            else:           eta = 0

            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            mbs = "[{:20}]".format(name)
            mbs += ' %.00f MB/%.00f MB' % (currently_downloaded, total)
            e = ' %.0fKbps' % kbps_speed
            #e += ' ETA:%01:%01d' % divmod(eta, 60)
            e += ' ETA:%01d' % (eta // 60)
            #dp.update(percent,'',mbs,e)
            dp.update(percent,'',mbs + e)
        except:
            traceback.print_exc()
            percent = 100
            dp.update(percent)
            dp.close()

    def getResponse(url, headers2, size):
        #Log("getResponse:{}".format(url))
        try:
            if size > 0:
                size = int(size)
                headers2['Range'] = 'bytes=%d-' % size

            req = Request(url, headers=headers2)
            resp = urllib2.urlopen(req, timeout=30, context=ssl._create_unverified_context())
            #Log("getResponse:urlopen:{}".format(url))
            return resp
        except:
            traceback.print_exc()
            return None

    def doDownload(url, dest, dp, name):

        try:
            
            #url may have include headers to be passed during transaction
            try:
                headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
            except:
                #traceback.print_exc()
                headers = dict('')


            if 'spankbang.com' in url:  url = getVideoLink(url,url)

            url = url.split('|')[0]
            file = dest.rsplit(os.sep, 1)[-1]

#            Log("headers='{}'".format(headers))

            resp = getResponse(url, headers, 0)

            if not resp:
                Notify("Download failed: {}".format(url))
                return False

            try:    content = int(resp.headers['Content-Length'])
            except: content = 0

            try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
            except: resumable = False
            if resumable: Log("Download is resumable: {}".format(url))

            if content < 1:
                Notify("Unknown filesize: {}".format(url))
                content = 1024*1024
                #xbmcgui.Dialog().ok("Ultimate Whitecream", 'Unknown filesize', 'Unable to download')
                #return False

            size = 8192
            mb   = content / (1024 * 1024)

            if content < size:
                size = content

            total   = 0
            errors  = 0
            count   = 0
            resume  = 0
            sleep   = 0

            Log('Download File Size : %dMB %s ' % (mb, dest))
            f = xbmcvfs.File(dest, 'w')

            chunk  = None
            chunks = []

            while True:

                # kill the download if kodi monitor tells us to
                monitor = xbmc.Monitor()
                if monitor.abortRequested():
                    if monitor.waitForAbort(1):
                        Log("shutting down '{}' download thread for '{}'".format(addon_id,url), xbmc.LOGNOTICE)
                        return

                downloaded = total
                for c in chunks:
                    downloaded += len(c)
                percent = min(100 * downloaded / content, 100)

                _pbhook(downloaded,content,name,dp)

                chunk = None
                error = False

                try:
                    chunk  = resp.read(size)
                    if not chunk:
                        if percent < 99:
                            error = True
                        else:
                            while len(chunks) > 0:
                                c = chunks.pop(0)
                                f.write(c)
                                del c

                            f.close()
                            Log( '%s download complete' % (dest) )
                            return True

                except Exception as e:
                    traceback.print_exc()
                    error = True
                    sleep = 10
                    errno = 0

                    if hasattr(e, 'errno'):
                        errno = e.errno

                    if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                        pass

                    if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                        errors = 10 #force resume
                        sleep  = 30

                    if errno == 11001: # 'getaddrinfo failed'
                        errors = 10 #force resume
                        sleep  = 30

                if chunk:
                    errors = 0
                    chunks.append(chunk)
                    if len(chunks) > 5:
                        c = chunks.pop(0)
                        f.write(c)
                        total += len(c)
                        del c

                if error:
                    errors += 1
                    count  += 1
                    #Log ('%d Error(s) whilst downloading %s' % (count, dest))
                    #xbmc.sleep(sleep*1000)
                    xbmc.sleep(sleep*1000)

                if (resumable and errors > 0) or errors >= 500:
                    if (not resumable and resume >= 500) or resume >= 500:
                        #Give up!
                        Log ('%s download canceled - too many error whilst downloading' % (dest))
                        f.close()
                        return False

                    resume += 1
                    errors  = 0

                    if resumable:
                        chunks  = []
                        #create new response
                        Log ('Download resumed (%d) %s' % (resume, dest) )
                        resp = getResponse(url, headers, total)
                    else:
                        #use existing response
                        pass

        except:
            traceback.print_exc()

##    def clean_filename(s):
##        if not s:
##            return ''
####        badchars = '\\/:*?\"<>|\''
####        for c in badchars:
####            s = s.replace(c, '')
##        s = re.sub(u'(?is)[^A-Za-z0-9~\]\[ \/,\'.&]','',s)
##        return s.strip();

##    Log(name)
    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
##    name = name.strip('\r')
    name = clean_filename(name)
####    Log(name)
##    if "[/COLOR]" in name:
##        n1 = name.split("[/COLOR]")
##        if n1[1] == '': name = n1[0]
##        else: name = n1[1]
####        Log(name)
##        if "[COLOR" in name:
##            name = name.split("[COLOR")[0]
####    Log(name)
####    return
##
##    download_path = this_addon.getSetting('download_path')
##    if download_path == '':
##        try:
##            download_path = xbmcgui.Dialog().browse(0, "Download Path", 'myprograms', '', False, False)
##            this_addon.setSetting(id='download_path', value=download_path)
##            if not os.path.exists(download_path): os.mkdir(download_path)
##        except:
##            raise #pass

    #Make_download_path(name = None, include_date = False, file_extension = ''):
    download_path = Make_download_path() #I want to start with path only
        
    progress_dialog = xbmcgui.DialogProgressBG()
    progress_dialog.create(addon_name,name[:50])

    tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
    tmp_file = xbmc.makeLegalFilename(tmp_file)
    start = time.clock()
    downloaded = None
    try:
        Log("url='{}'".format(url))
        downloaded = doDownload(url, tmp_file, progress_dialog, name)
        if downloaded:
            Log("clean_filename(name)='{}'".format(clean_filename(name)))
            vidfile = xbmc.makeLegalFilename(download_path + clean_filename(name) + ".mp4")
            Log("vidfile='{}'".format(vidfile))
            try:
                os.rename(tmp_file, vidfile)
                progress_dialog.close()
                return vidfile
            except Exception as e:
                try:
                    nfn = vidfile + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S") + '.mp4'
                    Log("vidfile='{}'".format(nfn))
                    os.rename(tmp_file, nfn)
                    progress_dialog.close()
                    return nfn
                except Exception as e2:
                    traceback.print_exc()
                    Notify(msg = "'{}' name:{} tmp:{}".format(e2,vidfile,tmp_file), duration=20000)
                    progress_dialog.close()
                    return tmp_file
        else:
            raise StopDownloading('Stopped Downloading')
    except:
        while os.path.exists(tmp_file):
            try:
                os.remove(tmp_file)
                progress_dialog.close()
                break
            except:
                traceback.print_exc()
                break
                pass
        progress_dialog.close()



def PLAYVIDEO(url, name, download=None, description=None):
    videosource = getHtml(url, url)
    playvideo(videosource, name, download, url, description=description)


def playvideo(videosource, name, download=None, url=None, description=None):
    Log("utils.playvideo ({},{},{},{}".format("<bunchofhtml>" , name, download, url), xbmc.LOGNONE)
    if progress:
        progress.create('Play video', 'Searching videofile.')

    hosts = []
    videourl = None

    if re.search('\.ypncdn\.com/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('youporn')

    if re.search('watchxfree\.(?:eu|io|info|stream)?/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Watchxfree')


    if re.search('streamin\.to/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamin')

    if re.search('flashx\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('FlashX')

    if re.search('mega3x\.net/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Mega3X')

    if re.search('ksplayer\.com/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('ksplayer')

    if re.search('streamcloud\.eu/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('StreamCloud')

    if re.search('streamcloud\.eu/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('StreamCloud')

    if re.search('jetload\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Jetload')
    elif re.search('(https?://jetload\.net/p/\w+/\w+.mp4)', videosource, re.DOTALL | re.IGNORECASE):
#<a href="https://jetload.net/p/kMvD8XpbDjr5/m0sl13d2jzjw.mp4" 
        hosts.append('jetload.net')
        
    if re.search('videowood\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Videowood')
    if re.search('streamdefence.com/view\.php', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamdefence')
    if re.search('strdef.world', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamdefence')


    if re.search('dato\.?porn(?:\.co|)\/\S+', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Datoporn')
    elif re.search('dato\.porn/embed', videosource, re.DOTALL | re.IGNORECASE):
        #href="http://dato.porn/embed-mormjvwfymtn.html"
        hosts.append('Datoporn')


    if re.search('(https?://clipwatching\.com/\w+/\w+.mp4)', videosource, re.DOTALL | re.IGNORECASE):
#<a href="https://clipwatching.com/zgr8sgn3vl5m/d8wjqt9rnf88.mp4" rel="nofollow noopener noreferrer" target="_blank" class="external"><strong> Streaming From ClipWatching</strong></a> </br></p>
        hosts.append('clipwatching')

    if re.search('https?://gounlimited\.to/embed', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('gounlimited')
    elif re.search('https?://gounlimited\.to/.+?\.html', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('gounlimited')
    elif re.search('https?://gounlimited\.to/.+?"', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('gounlimited')
        
    if re.search('zstream\.to/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('ZStream')

    if re.search('rapidvideo\.com/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Rapidvideo')

    if re.search('vidlox\.(?:tv|me)/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Vidlox')

    if re.search('streamcherry\.com', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamcherry')

    if re.search('streamango\.com\/embed\/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamango')

    if re.search('https?://mixdrop\.co/f/\w+', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('mixdrop')

    if re.search('<source', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Direct Source')

    if not 'keeplinks' in url:
        if re.search('keeplinks\.eu/p', videosource, re.DOTALL | re.IGNORECASE):
            hosts.append('Keeplinks <--')

    if re.search('verystream.com/e/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('verystream')

    if re.search("\.vipporns\.com\/embed\/", videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('vipporns')

    if re.search('vidoza\.net\/(?:embed|)(\.html)?', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('vidoza')

    if re.search('tubst\.net\/embed', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('tubst')

    #Log("hosts='{}'".format(hosts), xbmc.LOGNONE)
    if len(hosts) == 0:
        progress.close()
        notify('Oh oh','Couldn\'t find any video hoster')
        return
    elif len(hosts) > 1:
        #ask_which_file_hoster
        if addon.getSetting("ask_which_file_hoster") == "false":
            vidhost = hosts[0]
        else:
            vh = dialog.select('Videohost:', hosts)
            if vh == -1:
                return
            vidhost = hosts[vh]
    else:
        vidhost = hosts[0]


    if vidhost == 'jetload.net':
        Log("vidhost='{}'".format(vidhost), xbmc.LOGNONE)

        regex = '(https?://jetload\.net/p/\w+/\w+.mp4)'
        video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)[0]
        Log("video_url='{}'".format(video_url))

        video_source = getHtml(video_url, referer=url)
        #Log("video_source='{}'".format(video_source))

        regex = "x_source = '([^']+)"
        video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_source)[0]
        Log("video_url='{}'".format(video_url))

        videourl = video_url
        Log("videourl='{}'".format(videourl))
        
    elif vidhost == 'clipwatching':

        clipwatching_url = re.compile('(https?://clipwatching\.com/\w+/\w+.mp4)', re.DOTALL | re.IGNORECASE).findall(videosource)[0]
        if clipwatching_url.startswith('/'): clipwatching_url = 'https:' + clipwatching_url
        Log("clipwatching_url='{}'".format(clipwatching_url))

        clipwatching_source = getHtml(clipwatching_url, referer=url)
        Log("clipwatching_source='{}'".format(clipwatching_source))

        clipwatching_url = re.compile('sources:\s+?\["([^\[]+)"\]', re.DOTALL | re.IGNORECASE).findall(clipwatching_source)[0]
        Log("clipwatching_url='{}'".format(clipwatching_url))

        videourl = clipwatching_url
        Log("videourl='{}'".format(videourl))

        
    elif vidhost == 'mixdrop':

        mixdrop_url_f = re.compile("(https?://mixdrop\.co/f/\w+)", re.DOTALL | re.IGNORECASE).findall(videosource)[0]
        if mixdrop_url_f.startswith('/'): mixdrop_url_f = 'https:' + mixdrop_url_f
        Log("mixdrop_url_f='{}'".format(mixdrop_url_f))

        mixdrop_source = getHtml(mixdrop_url_f, referer=url)
        #Log("mixdrop_source='{}'".format(mixdrop_source))
        mixdrop_url_e = re.compile('src="(//mixdrop\.co/e/\w+)', re.DOTALL | re.IGNORECASE).findall(mixdrop_source)[0]
        if mixdrop_url_e.startswith('/'): mixdrop_url_e = 'https:' + mixdrop_url_e
        Log("mixdrop_url_e='{}'".format(mixdrop_url_e))

        mixdrop_source = getHtml(mixdrop_url_e, referer=mixdrop_url_f)
        #Log("mixdrop_source='{}'".format(mixdrop_source))

        mixdrop_js = re.compile("(<script.+?eval.+?</script>)", re.DOTALL | re.IGNORECASE).findall(mixdrop_source)[0]
        mixdrop_unpacked_js = unpack(mixdrop_js)
        Log("mixdrop_unpacked_js='{}'".format(mixdrop_unpacked_js))


        regex = ';MDCore.wurl="([^"]+)"'
        video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(mixdrop_unpacked_js)[0]
        Log("video_url='{}'".format(video_url))
        
##        import json
##        json_sources = json.loads(sources_list[0])
##        list_key_value = {} ##[] #dict()
##        for i in range(len(json_sources)):
##            dict_source = dict(json_sources[i])
##            q = str(dict_source['label'])
##            v = str(dict_source['file'])
##            if not v == "":
##                list_key_value[q] = v
##        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
##        video_url = SortVideos(list_key_value,0)

        if video_url.startswith('/'): video_url = 'https:' + video_url
        Log("video_url={}".format(video_url))


        mixdrop_headers = { "Accept-Encoding" : "identity;q=1, *;q=0" \
                    , "User-Agent" : USER_AGENT \
                    , "Accept" : "*/*" \
                    , "Referer" :  mixdrop_url_e \
                    }
        video_url += Header2pipestring(mixdrop_headers)
        Log("video_url={}".format(video_url))

        videourl = video_url

        
    elif vidhost == 'youporn':
        youporn_url = re.compile("class='videoPlayer' src=\"([^\"]+)\" ", re.DOTALL | re.IGNORECASE).findall(videosource)
        #Log("youporn_url='{}'".format(youporn_url))
        youporn_url = html_parser.unescape(youporn_url[0])
        videourl = youporn_url + Header2pipestring() #+ '&Referrer='+url
        #Log("videourl='{}'".format(videourl))
        
    if vidhost == 'HQQ':
#https://hqq.tv/player/embed_player.php?vid=bVdCa0VDMEtXS0hlT1ZKY2lsMmNUQT09&amp;autoplay=no
        hqq_url = re.compile('src=\"(https:\/\/hqq\.tv\/player\/embed\_player\.php[^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("hqq_url='{}'".format(hqq_url))
        hqq_url = hqq_url[0]
        #Log("hqq_url='{}'".format(hqq_url))


        #2019-05-29 ... HQQ denying access from porn-czech domain
        v_s = getHtml(hqq_url,referer= url)

        deb = re.compile("license_code:(.+)preload:", re.DOTALL | re.IGNORECASE).findall(v_s)
        Log("deb='{}'".format(deb[0]))
        
        license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("license_code='{}'".format(license_code))

        vipporns_url = re.compile("video_url: 'function\/0\/([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("vipporns_url='{}'".format(vipporns_url))

        fappy_salt = FaapySalt(license_code, "")
        #Log("fappysalt='{}'".format(fappy_salt))

        old_fappy_code = vipporns_url.split('/')[5]
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        old_fappy_code = old_fappy_code[0:len(fappy_salt)]  #not sure if this applies to all sites
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        new_fappy_code = ConvertFaapyCode( old_fappy_code, fappy_salt)
        #Log("new_fappy_code='{}'".format(new_fappy_code))

        vipporns_url = vipporns_url.replace(old_fappy_code, new_fappy_code)
        vipporns_url = vipporns_url + "&rnd=" + str(time.time()*100)
        #Log("vipporns_url='{}'".format(vipporns_url))

        videourl = vipporns_url
        

    if vidhost == 'vipporns':
        #Log("url='{}'".format(url))
        vipporns_url = re.compile('src=\"(https:\/\/www\.vipporns\.com\/embed\/[^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videosource)
        #Log("vipporns_url='{}'".format(vipporns_url))
        vipporns_url = vipporns_url[0]
        #Log("vipporns_url='{}'".format(vipporns_url))
        v_s = getHtml(vipporns_url)

        deb = re.compile("license_code:(.+)preload:", re.DOTALL | re.IGNORECASE).findall(v_s)
        Log("deb='{}'".format(deb[0]))
        
        license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("license_code='{}'".format(license_code))

        vipporns_url = re.compile("video_url: 'function\/0\/([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("vipporns_url='{}'".format(vipporns_url))

        fappy_salt = FaapySalt(license_code, "")
        #Log("fappysalt='{}'".format(fappy_salt))

        old_fappy_code = vipporns_url.split('/')[5]
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        old_fappy_code = old_fappy_code[0:len(fappy_salt)]  #not sure if this applies to all sites
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        new_fappy_code = ConvertFaapyCode( old_fappy_code, fappy_salt)
        #Log("new_fappy_code='{}'".format(new_fappy_code))

        vipporns_url = vipporns_url.replace(old_fappy_code, new_fappy_code)
        vipporns_url = vipporns_url + "&rnd=" + str(time.time()*100)
        #Log("vipporns_url='{}'".format(vipporns_url))

        videourl = vipporns_url



##    if vidhost == 'verystream':
##        Log("verystream hosted url='{}'".format(url))
##        verystream_url = re.compile('class=\"video-container\".+?src=\"([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videosource)
##        if verystream_url:
##            verystream_url = verystream_url[0]
##            Log("verystream_url='{}'".format(verystream_url))
##            v_s = getHtml(verystream_url)
##            playvideo(v_s, name=name, download=download, url=url)
##            return
##
##        verystream_url = re.compile('(?:href|src)=\"(https:\/\/verystream\.com\/e\/[^\/\"]+)(?:\/|\")', re.DOTALL | re.IGNORECASE).findall(videosource)
##        if verystream_url: #some sites have an extra hop
##            verystream_url = verystream_url[0]
##            Log("verystream_url='{}'".format(verystream_url))
##            v_s = getHtml(verystream_url, referer=url)
##        else:
##            v_s = videosource
##
##        verystream_url = re.compile('id=\"videolink\">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(v_s)
##        Log("verystream_url='{}'".format(verystream_url))
##
##        if verystream_url:
##            verystream_url = "https://verystream.com/gettoken/{}?mime=true".format(verystream_url[0])
##            Log("verystream_url='{}'".format(verystream_url))
##            videourl = verystream_url
        



    if vidhost == 'Watchxfree':
        watchxfree_url = re.compile(r"//(?:www\.)?watchxfree\.(?:eu|io|tv|info|stream)?/(?:embed|f)/([0-9a-zA-Z-_]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        try:
            import urlresolver
            video = urlresolver.resolve(watchxfree_url)
            if video:
                videourl = video
        except:
            notify('Oh oh','Couldn\'t find playable link')
            return


    elif vidhost == 'tubst':
        tubst_url = re.compile("https:\/\/www\.tubst\.net\/(?:embed)?\/(?:[0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        if tubst_url:
            tubst_url = tubst_url[0]
            Log("tubst_url='{}'".format(tubst_url))
            v_s = getHtml(tubst_url, url)
            playvideo(v_s, name=name, download=download, url=url)
            return
            
    elif vidhost == '1fichier':
        progress.update( 40, "", "Loading {}".format(vidhost), "" )
        streaminurl = re.compile("https:\/\/1fichier\.com\/(?:embed-)?\?(?:[0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        kodilog("{}:{}".format(vidhost, repr(streaminurl)))
        streaminurl = chkmultivids(streaminurl)
        kodilog("{}:{}".format(vidhost, repr(streaminurl)))
        progress.update( 50, "", "Loading {}".format(vidhost), "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(streaminurl)
        if video:
            progress.update( 80, "", "Loading {}".format(vidhost), "Found the video" )
            videourl = video

    elif vidhost == 'Streamin':
        progress.update( 40, "", "Loading Streamin", "" )
        streaminurl = re.compile(r"//(?:www\.)?streamin\.to/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        streaminurl = chkmultivids(streaminurl)
        streaminurl = 'http://streamin.to/embed-%s-670x400.html' % streaminurl
        progress.update( 50, "", "Loading Streamin", "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(streaminurl)
        if video:
            progress.update( 80, "", "Loading Streamin", "Found the video" )
            videourl = video

    elif vidhost == 'FlashX':
        progress.update( 40, "", "Loading FlashX", "" )
        flashxurl = re.compile(r"//(?:www\.)?flashx\.tv/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        media_id = chkmultivids(flashxurl)
        flashxurl = 'http://www.flashx.tv/%s.html' % media_id
        progress.update( 50, "", "Loading FlashX", "Sending it to urlresolver" )
        import urlresolver
        video = urlresolver.resolve(flashxurl)
        if video:
            progress.update( 80, "", "Loading FlashX", "Found the video" )
            videourl = video

    elif vidhost == 'ksplayer':
#<iframe loading="lazy" width="100%" height="100%" src="about:blank" frameborder="0" allowfullscreen="true" data-rocket-lazyload="fitvidscompatible" data-lazy-src="https://stream.ksplayer.com/embed/GyaZyGCNCgcCoi6/"></iframe><noscript>
#<iframe width="100%" height="100%" src="https://stream.ksplayer.com/embed/GyaZyGCNCgcCoi6/" frameborder="0" allowfullscreen="true"></iframe>
        
        Log("ksplayer='{}'".format(url))
        regex = '"(https?://(?:stream\.)?ksplayer\.com/(?:embed/)[0-9a-zA-Z]+/)\"'
        ksplayer_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("ksplayer_url='{}'".format(ksplayer_url))
        if len(ksplayer_url):
            ksplayer_url=ksplayer_url[0]
        
        ksplayer_src = getHtml(ksplayer_url)
        Log("ksplayer_src='{}'".format(ksplayer_src))
        regex = '<script type="text/javascript">JuicyCodes\.Run\((.*?)\);</script>'
        juicycodes_src = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(ksplayer_src)
        if juicycodes_src:
            juicycodes_src = juicycodes_src[0]
            Log("juicycodes_src='{}'".format(juicycodes_src))
            regex = '"([^"]+)"'
            juicycodes_split = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(juicycodes_src)
            juicycodes_src = ""
            for juicycode in juicycodes_split:
                juicycodes_src = juicycodes_src + juicycode
            juicycodes_src = base64.b64decode(juicycodes_src)
        else:
            Log("Can't find juicy in this vidhost")
        Log("juicycodes_src='{}'".format(juicycodes_src))

        ksplayer_js = unpack(juicycodes_src)
        Log("ksplayer_js='{}'".format(ksplayer_js))

        regex = 'sources:(\[.*\])'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(ksplayer_js)
        Log("sources_list='{}'".format(sources_list))
        
        import json
        json_sources = json.loads(sources_list[0])

        list_key_value = {} ##[] #dict()
        for i in range(len(json_sources)):
            dict_source = dict(json_sources[i])
            q = str(dict_source['label'])
            v = str(dict_source['file'])
            if not v == "":
                list_key_value[q] = v
        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
        video_url = SortVideos(list_key_value,0)
        Log("video_url={}".format(video_url))

        videourl = video_url


    elif vidhost == 'Mega3X':
        progress.update( 40, "", "Loading Mega3X", "" )
        mega3xurl = re.compile(r"(https?://(?:www\.)?mega3x.net/(?:embed-)?(?:[0-9a-zA-Z]+).html)", re.DOTALL | re.IGNORECASE).findall(videosource)
        mega3xurl = chkmultivids(mega3xurl)
        mega3xsrc = getHtml(mega3xurl,'')
        mega3xjs = re.compile("<script[^>]+>(eval[^<]+)</sc", re.DOTALL | re.IGNORECASE).findall(mega3xsrc)
        progress.update( 80, "", "Getting video file from Mega3X", "" )
        mega3xujs = unpack(mega3xjs[0])
        videourl = re.compile('file:\s?"([^"]+m3u8)"', re.DOTALL | re.IGNORECASE).findall(mega3xujs)
        videourl = videourl[0]



    elif vidhost == 'gounlimited':
        Log("gounlimited='{}'".format(url))
        #Log("videosource='{}'".format(videosource))
        
#        regex = '"?(https?://gounlimited\.to/(?:embed-[0-9a-zA-Z]+\.html|\w+/\S+\.mp4))"?'
        regex = '"?(https?://gounlimited\.to/(?:embed-[0-9a-zA-Z]+\.html|\w+/\S+\.mp4|\w+))"?' #works 2020-04-08
#https://gounlimited.to/xyqxtycqxnq6/PrincessCum.20.01.03.Dana.Wolf.720p.mp4
#https://gounlimited.to/embed-4yjfuoztjqkp.html
#https://gounlimited.to/ckoabbhrvdg6


        gounlimited_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("gounlimited_url='{}'".format(gounlimited_url))
        if not gounlimited_url:
            Log("unknown gounlimited structure", xbmc.LOGWARNING)
            return
        else:
            gounlimited_url = gounlimited_url[0]
        gounlimited_src = getHtml(gounlimited_url, url, http_timeout=50)
        #Log("gounlimited_src='{}'".format(gounlimited_src))
        
        regex = "\(p,a,c,k,e,d\).+?}\('(.*?),(\d+),(\d+),'(.*?)'"
        packed_src = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(gounlimited_src)
        if not packed_src: return
        else: packed_src = packed_src[0]
        #Log("packed_src='{}'".format(packed_src))


        p = packed_src[0]
        a = packed_src[1]
        c = packed_src[2]
        k = packed_src[3].split("|")
        source_js = dePacked(p,a,c,k,None,None)
        Log("source_js='{}'".format(source_js))
        #regex = '{sources:\["([^"]+)"'
        regex = '{(?:sources:\[|src:)"([^"]+)"'  #works 2020-04-08
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_js)
        Log("sources='{}'".format(sources))
        videourl = sources[0]

        gounlimited_headers = { "Accept-Encoding" : "identity;q=1, *;q=0" \
                    , "User-Agent" : USER_AGENT \
                    , "Accept" : "*/*" \
                    , "Referer" :  gounlimited_url \
                    }
        videourl = videourl + Header2pipestring(gounlimited_headers)
        
        Log("videourl='{}'".format(videourl))



    elif vidhost == 'Datoporn':
        #progress.update( 40, "", "Loading Datoporn", "" )
        #href="http://dato.porn/embed-mormjvwfymtn.html"
        #http://dato.porn/se4mssi34ina
        #http://dato.porn/embed-se4mssi34ina.html
        datourl = re.compile("\/\/(?:www\.)?dato\.?porn(?:\.com|\.co)?\/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("datourl='{}'".format(datourl))
        if datourl:
            Log("datourl found")
            
            datourl = chkmultivids(datourl)
            Log("datourl='{}'".format(datourl))
            datourl = "http://datoporn.co/embed-" + datourl + ".html"
            Log("datourl='{}'".format(datourl))
            datosrc = getHtml(datourl,'')
            if datosrc == '':
                datourl = "http://datoporn.com/embed-" + datourl + ".html"
                Log("datourl='{}'".format(datourl))
                datosrc = getHtml(datourl,'')

            if "File was deleted" in datosrc:
                notify('Oh oh','File is deleted from Datoporn')
                return

            datojs = re.compile("<script>.var player.+?(player.updateSrc[^<]+)</sc", re.DOTALL | re.IGNORECASE).findall(datosrc)
            try:
                #Log("datojs='{}'".format(datojs))
                datoujs = unpack(datojs[0])
            except:
                datoujs = ''
            #Log("datoujs='{}'".format(datoujs))

            #maybe a packed encoding
            regex1 = "\(p,a,c,k,e,d\).+?}\('(.*?);',"
            packed1 = re.compile(regex1, re.DOTALL).findall(datosrc)
            regex2 = "\(p,a,c,k,e,d\).+?;',(.+)\.split\(\'\|\'\)"
            packed2 = re.compile(regex2, re.DOTALL).findall(datosrc)
            #Log("packed1='{}'".format(packed1))
            #Log("packed2='{}'".format(packed2))
            if packed1 and packed2:
                p = packed1[0]
                #Log("p='{}'".format(p))
                packed_arr = packed2[0].split(',')
                a = packed_arr[0]
                c = packed_arr[1]
                k = packed_arr[2].split('|')
                #Log("a='{}'".format(a))
                #Log("c='{}'".format(c))
                #Log("k='{}'".format(k))
                datoujs = dePacked(p,a,c,k,None,None)
                Log("datoujs='{}'".format(datoujs))
            else:
                Log("not packed1 and packed2;reverint to raw html")
                datoujs = datosrc
                
            regex = 'file:\"([^\"]+mp4)\"'
            regex = 'file:\"([^\"]+mp4)\",label:\"([^\"]+)p\"'
            #regex = 'file:"([^"]+(?:\.mp4|\.m3u8|\.mpd))"(?:,label:")*(\d+|})(?:"p)*'
            video_sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(datoujs)
            if not video_sources: #try another format
                video_sources = re.compile('{src: "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(datoujs)
            if len(video_sources) == 0:
                video_sources = None
                
            Log("video_sources='{}'".format(video_sources))
            if video_sources:
                video_url = SortVideos(video_sources, substitute_res='1080')
                #videourl = videourl[0]
                videourl = "{}{}&Referer={}".format(video_url, Header2pipestring(), datourl)
            Log("='{}'".format(videourl))


    elif vidhost == 'StreamCloud':
        Log("Opening Streamcloud")
        streamcloudurl = re.compile(r"//(?:www\.)?streamcloud\.eu?/([0-9a-zA-Z-_/.]+html)", re.DOTALL | re.IGNORECASE).findall(videosource)
        streamcloudurl = chkmultivids(streamcloudurl)
        streamcloudurl = "http://streamcloud.eu/" + streamcloudurl
        Log("Getting Streamcloud page")
        schtml = postHtml(streamcloudurl)

        form_values = {}
        match = re.compile('<input.*?name="(.*?)".*?value="(.*?)">', re.DOTALL | re.IGNORECASE).findall(schtml)
        for name, value in match:
            form_values[name] = value.replace("download1","download2")

        Log("Grabbing video file")
        newscpage = postHtml(streamcloudurl, form_data=form_values)

        videourl = re.compile('file:\s*"(.+?)",', re.DOTALL | re.IGNORECASE).findall(newscpage)[0]
        streamcloud_headers = { "Accept-Encoding" : "identity;q=1, *;q=0" \
                    , "User-Agent" : USER_AGENT \
                    , "Accept" : "*/*" \
                    , "Referer" :  streamcloudurl \
                    }
        videourl = videourl + Header2pipestring(streamcloud_headers)
        Log("videourl='{}'".format(videourl), xbmc.LOGNONE)
        
    elif vidhost == 'Jetload':
        progress.update( 40, "", "Loading Jetload", "" )
        jlurl = re.compile(r'jetload\.tv/([^"]+)', re.DOTALL | re.IGNORECASE).findall(videosource)
        jlurl = chkmultivids(jlurl)
        jlurl = "http://jetload.tv/" + jlurl
        progress.update( 50, "", "Loading Jetload", "" )
        jlsrc = getHtml(jlurl, url)
        videourl = re.compile(r'file: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(jlsrc)
        if videourl:
            videourl = videourl[0]
        else:
            notify('Oh oh','File was deleted from: {}'.format(vidhost))
            return

    elif vidhost == 'Videowood':
        progress.update( 40, "", "Loading Videowood", "" )
        vwurl = re.compile(r"//(?:www\.)?videowood\.tv/(?:embed|video)/([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        vwurl = chkmultivids(vwurl)
        vwurl = 'http://www.videowood.tv/embed/' + vwurl
        progress.update( 50, "", "Loading Videowood", "Sending it to urlresolver" )
        import urlresolver
        video = urlresolver.resolve(vwurl)
        if video:
            progress.update( 80, "", "Loading Videowood", "Found the video" )
            videourl = video

    elif vidhost == 'Keeplinks <--':
        progress.update( 40, "", "Loading Keeplinks", "" )
        klurl = re.compile(r"//(?:www\.)?keeplinks\.eu/p([0-9a-zA-Z/]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        klurl = chkmultivids(klurl)
        klurl = 'http://www.keeplinks.eu/p' + klurl
        kllink = getVideoLink(klurl, '')
        kllinkid = kllink.split('/')[-1]
        klheader = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
           'Accept-Encoding': 'none',
           'Accept-Language': 'en-US,en;q=0.8',
           'Connection': 'keep-alive',
           'Cookie': 'flag['+kllinkid+'] = 1;'}
        klpage = getHtml(kllink, klurl, klheader)
        playvideo(klpage, name, download, klurl)
        return
    
    elif vidhost == 'Streamdefence':

        Log("Loading Streamdefence")
        sdurl = re.compile(r'streamdefence\.com/view.php\?ref=([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videosource)
        if sdurl:
            sdurl = chkmultivids(sdurl)
            sdurl = 'http://www.streamdefence.com/view.php?ref=' + sdurl
        else:
            sdurl = re.compile('\.strdef\.world/([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videosource)
            if sdurl:
                sdurl = 'https://www.strdef.world/' + sdurl[0]

        Log("streamdefence url:'{}'".format(sdurl))
        Log("referrer:'{}'".format(url))
        sdsrc = getHtml(sdurl, url)
        Log("Getting video file from Streamdefence")
        sdpage = streamdefence(sdsrc)

        #Log("sdpage={}".format(sdpage))
        playvideo(sdpage, name, download, sdurl)
        return

    elif vidhost == 'Filecrypt':
        Log("Loading Filecrypt")
        fcurl = re.compile(r'filecrypt\.cc/Container/([^\.]+)\.html', re.DOTALL | re.IGNORECASE).findall(videosource)
        fcurl = chkmultivids(fcurl)
        fcurl = 'http://filecrypt.cc/Container/' + fcurl + ".html"
        fcsrc = getHtml(fcurl, url)
        fcmatch = re.compile(r"onclick=\"openLink.?'([\w\-]*)',", re.DOTALL | re.IGNORECASE).findall(fcsrc)
        progress.update( 80, "", "Getting video file from Filecrypt", "" )
        fcurls = ""
        for fclink in fcmatch:
            fcpage = "http://filecrypt.cc/Link/" + fclink + ".html"
            fcpagesrc = getHtml(fcpage, fcurl)
            fclink2 = re.search('<iframe .*? noresize src="(.*)"></iframe>', fcpagesrc)
            if fclink2:
                try:
                    fcurl2 = getVideoLink(fclink2.group(1), fcpage)
                    fcurls = fcurls + " " + fcurl2
                except:
                    pass
        playvideo(fcurls, name, download, fcurl)
        return


    elif vidhost == 'vidoza':
        Log("loading vidoza")
        
        vidoza_url = re.compile("((?:https:|http:)(?://|\.)vidoza\.net/(?:embed-|)[0-9a-zA-Z]+(?:\.html|))", re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("vidoza_url={}".format(vidoza_url))
        media_id = re.compile("(?://|\.)vidoza\.net/(?:embed-|)([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("media_id={}".format(media_id))
        vidoza_url = 'http://vidoza.net/%s' % media_id[0]       
        Log("vidoza_url={}".format(vidoza_url))
        import urlresolver
        video = urlresolver.resolve(vidoza_url)
        if video:
            videourl = video

    elif vidhost == 'Vidlox':
        Log("loading Vidlox")

        #look for direc source inside html
        regex = '"(https?://.+?\.mp4)"'
        regex = '"(https?://[^"]+\.(?:mp4|m3u8))"'
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videosource)
        if sources:
            Log("sources={}".format(sources))
            videourl = sources[0]
        else:
            vidlox_url = re.compile(r"(?://|\.)vidlox\.(?:tv|me)/(?:embed-|)([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
            Log("vidlox_url={}".format(vidlox_url))
            media_id = chkmultivids(vidlox_url)
            vidlox_url = 'https://vidlox.me/%s' % media_id
            Log("vidlox_url={}".format(vidlox_url))
            import urlresolver
            video = urlresolver.resolve(vidlox_url)
            if video:
                progress.update( 80, "", "Loading Vidlox", "Found the video" )
                videourl = video
                

    elif vidhost == 'ZStream':
        progress.update( 40, "", "Loading Zstream", "" )
        zstreamurl = re.compile(r"(?://|\.)zstream\.to/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        zstreamurl = chkmultivids(zstreamurl)
        zstreamurl = 'http://zstream.to/embed-%s.html' % zstreamurl
        progress.update( 50, "", "Loading ZStream", "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(zstreamurl)
        if video:
            progress.update( 80, "", "Loading ZStream", "Found the video" )
            videourl = video

    elif vidhost == 'Streamcherry' or vidhost == 'Streamango':
        Log("streamcherry url={}".format(url))
        scstreamurl = re.compile(r"(?://|\.)(?:streamcherry|streamango)\.com/(?:embed|f)/(\w+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        scstreamurl = chkmultivids(scstreamurl)
        scstreamurl = 'https://streamcherry.com/embed/%s' % scstreamurl
        import urlresolver
        Log("scstreamurl='{}'".format(scstreamurl))
        video = urlresolver.resolve(scstreamurl)
        if video:
            progress.update( 80, "", "Loading Streamcherry", "Found the video" )
            videourl = video

    elif vidhost == 'Rapidvideo':
        progress.update( 40, "", "Loading Rapidvideo", "" )
        rpvideourl = re.compile(r"(?://|\.)(?:rapidvideo|raptu)\.com/(?:embed/|[ev]/|\?v=)?([0-9A-Za-z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        rpvideourl = chkmultivids(rpvideourl)
        rpvideourl = 'https://www.rapidvideo.com/embed/%s' % rpvideourl
        progress.update( 50, "", "Loading Rapidvideo", "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(rpvideourl)
        if video:
            progress.update( 80, "", "Loading Rapidvideo", "Found the video" )
            videourl = video

    elif vidhost == 'Direct Source':
        Log("vidhost='{}'".format(vidhost))
        #progress.update( 40, "", "Loading Direct source", "" )
        dsurl = re.compile("""<source.*?src=(?:"|')([^"']+)[^>]+>""", re.DOTALL | re.IGNORECASE).findall(videosource)
        dsurl = chkmultivids(dsurl)
        videourl = dsurl


    progress.update( 100, "", videourl, "" )

    progress.close()

    if videourl:
        playvid(videourl, name, download, description)
    else:
        notify('Oh oh','Couldn\'t find a link')
        return


def playvid(videourl, name, download=None, description=None):

    if len(videourl) > 2000:
        Log("playvid not playing broken videourl".format(videourl[0:100]) )
        return

    if download == 1:
        downloadVideo(videourl, name)
        return

    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})

    if description:
        #Log("description={}".format(description))
        listitem.setInfo("video", infoLabels={"plot": description, "plotoutline": description})        

    #Log("playing URL: {}".format(videourl) )

    if ".m3u8" in videourl:
##        Log("setting inputstream HLS for URL: " + videourl, xbmc.LOGNONE  )
##        listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
##        listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        if '|' in videourl:
            stream_headers = videourl.split("|")[1]
        else: #use default headers
            stream_headers = Header2pipestring().replace("|", '')
            videourl = videourl + Header2pipestring()
        Log("stream_headers='{}'".format(stream_headers) )
        listitem.setProperty('inputstream.adaptive.stream_headers', stream_headers)
        
    else:
        if not videourl == '' and not '|' in videourl:
            videourl = videourl+Header2pipestring()

    Log("playing URL: {}".format(videourl) )

    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    xbmc.Player().play(videourl, listitem)


def chkmultivids(videomatch):
    videolist = list(set(videomatch))
    if len(videolist) > 1:
        i = 1
        hashlist = []
        for x in videolist:
            hashlist.append('Video ' + str(i) + '  ' + x)
            i += 1
        mvideo = dialog.select('Multiple videos found', hashlist)
        if mvideo == -1:
            return
        return videolist[mvideo]
    else:
        return videomatch[0]

@url_dispatcher.register('9', ['name', 'url'])
def PlayStream(name, url):
    item = xbmcgui.ListItem(name, path = url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    return


def getHtml(url
            , referer=''
            , headers=None
            , save_cookie=None
            , sent_data=None
            , ignore404=False
            , ignore403=False
            , send_back_redirect=False
            , http_timeout=20
            , sucuri_solved=False
            , method="GET"):

    stream=False
    response = None
    redirected_url = None
##    Log("getHtml method='{}', url='{}', referer='{}', headers='{}', sent_data='{}', sucuri_solved='{}'".format(method,url,referer,headers,sent_data,sucuri_solved))

    ##cookiedump
##    for cookie in cj:
##        this_domain = urlparse.urlparse(url).netloc
##        if cookie.domain.endswith(this_domain):
##        Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
                        
    try:
                
        if not headers:
            getHtml_headers = DEFAULT_HEADERS.copy()
        else:
            getHtml_headers = headers.copy()

        if len(referer) > 1:
            getHtml_headers['Referer'] = referer

        if sent_data:
            getHtml_headers['Content-Length'] = str(len(sent_data))
##        Log("getHtml_headers='{}'".format(getHtml_headers))


        #
        # I don't know how to use cookieJar with SOCKS proxy
        #
        socks_cookies = ''
        this_domain = urlparse.urlparse(url).netloc
        temp_cookiejar = cookielib.CookieJar() #required because Requests library 2.2 will only persist cookie during direct if inside a cookiejar
##        Log("type temp_cookiejar='{}'".format(type(temp_cookiejar)))
##        Log("type cj='{}'".format(type(cj)))
        for cookie in cj:
##            Log("pre-request cookie='{}'".format(cookie))
            if cookie.domain.endswith(this_domain):
##                socks_cookies += "{}={};".format(cookie.name,cookie.value)
                temp_cookiejar.set_cookie(cookie)
##                    Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)
##        Log("socks_cookies={}".format(repr(socks_cookies)), xbmc.LOGNONE)
##        for cookie in temp_cookiejar:
##            Log("temp_cookiejar_cookie={}".format(repr(cookie)))

        if 'Cookie' in getHtml_headers:
##            Log("getHtml_headers['Cookie']={}".format(getHtml_headers['Cookie']), xbmc.LOGNONE)
            socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
        if not socks_cookies == '':
            getHtml_headers['Cookie'] = (socks_cookies).strip(';')
##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)

        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            proxy = SOCKSProxyManager(proxy_url=socks_string)
            socks_response = proxy.request(
                method
                ,url = url
                ,body = sent_data
                ,headers = getHtml_headers
                ,timeout = http_timeout
                )
            #https://requests.readthedocs.io/en/master/api/
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            data = socks_response.data
            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None
                
        elif (socks_proxy_info['uhp'] <= 0) :

            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
            else: proxies = {}
            #https://requests.readthedocs.io/en/master/api/#requests.Request            
            response = my_http_session.request(
                method
                , url=url
                , headers=getHtml_headers
                , data = sent_data
                , stream=stream
                , verify=False
                , allow_redirects=True
                , proxies=proxies
                , cookies=temp_cookiejar)
            data = response.content
            redirected_url = response.url 
            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
            else: redirected_url = None
            
##            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
##            else: proxies = {}  
##            #Log("proxies='{}'".format( proxies ) )
##            from requests import Request, Session
##            s = Session() #note: posts to https:// don't work in kodi 17; use http instead
##            req = Request(method, url=url, data=sent_data, headers=getHtml_headers, cookies=cj) #https://requests.readthedocs.io/en/master/api/
##            prepped = s.prepare_request(req)
##            response = s.send(prepped, verify=False, proxies=proxies)
##            data = response.content
##            redirected_url = response.url 
##            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
##            else: redirected_url = None
            
##        else:
##            Log("no proxy=''".format(socks_proxy_info['uhp']))
##            from requests import Request, Session
##            s = Session()
##            Log("getHtml_headers={}".format(getHtml_headers))
##            req = Request('GET', url=url, data=sent_data, headers=getHtml_headers)
##            prepped = s.prepare_request(req)
##            #https://requests.readthedocs.io/en/master/api/
##            response = s.send(prepped, verify=False)
##            data = response.content
##            redirected_url = response.url 
##            if not url == redirected_url:
##                Log("redirected_url='{}'".format(redirected_url))
##            else:
##                redirected_url = None

        if sucuri_solved == False:
            if response:
                #Log("response='{}'".format(repr(response.info())), xbmc.LOGNONE)
                if 'Server' in response.headers:
                    if response.status_code in (200,301) and response.headers['Server'] == "Sucuri/Cloudproxy":
                        import sucuri
                        if sucuri.SCRIPT_HEADER in data:
                            cookie = sucuri.Set_Cookie(data)
                            cj.set_cookie(cookie)
                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
##                            raise
                            return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)
            elif socks_response:
                if 'Server' in socks_response.headers:
                    if socks_response.status in (200,301)  and socks_response.headers[ 'Server' ] == "Sucuri/Cloudproxy":
                        import sucuri
                        if sucuri.SCRIPT_HEADER in data:
                            cookie = sucuri.Set_Cookie(data)
                            cj.set_cookie(cookie)
                            cj.save(cookiePath, ignore_expires=True, ignore_discard=True)
##                            raise
                            return getHtml(url, referer, headers, save_cookie, sent_data, ignore404, ignore403, send_back_redirect, http_timeout, sucuri_solved = True, method=method)

##        Log("data='{}'".format(data))


        if not (save_cookie == False) and (cj is not None) :
            r = None
            this_domain = urlparse.urlparse(url).netloc
##            Log("this_domain={}".format(repr(this_domain)))
##            if cj is not None and response is not None:
##                if 'Set-Cookie' in response.headers:
##                    for cookie in SetCookie_To_Array_Of_Cookie(response.headers[ 'Set-Cookie' ]) :
##                        Log("cookie={}".format(repr(cookie)))
##                        if this_domain.endswith(cookie.domain) and not cookie.discard:
##                            cj.set_cookie(cookie)
##                            Log("saving cookie={}".format(repr(cookie)))
            if isinstance(response, urllib3.response.HTTPResponse):
                r = socks_response
            else:
                r = response
            if r is not None:
                if 'Set-Cookie' in r.headers:
                    for cookie in SetCookie_To_Array_Of_Cookie(r.headers[ 'Set-Cookie' ]) :
##                        Log("cookie={}".format(repr(cookie)))
                        if not cookie.discard:
                            if save_cookie == True: #save as this domain event if cookie is not marked so
                                 cookie.domain = this_domain
                            if this_domain.endswith(cookie.domain):
                                cj.set_cookie(cookie)

                    cj.save(cookiePath, ignore_expires=False, ignore_discard=False)
##                    Log("saving cookiejar")
##            for cookie in cj:
####                if cookie.domain.endswith(this_domain):
##                Log("cookie={}".format(repr(cookie)), xbmc.LOGNONE)
                


        
    except urllib2.HTTPError as e:
        if e.info().get('Content-Encoding') == 'gzip':
            buf = StringIO( e.read())
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = e.read()
        #Log(data)  #errors='ignore'
        #notify('Oh oh',data)
        if e.code == 503 and 'cf-browser-verification' in data:
            data = cloudflare.solve(url, cj, USER_AGENT)
            
        elif e.code == 404 and ignore404 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data

        elif e.code == 403 and ignore403 == True:
            Log("404_e='{}'".format(e.read().decode()))
            if send_back_redirect == True:
                return data, redirected_url
            else:
                return data
            
        else:
            traceback.print_exc()
            raise urllib2.HTTPError()

    except Exception as e:
        if 'SSL23_GET_SERVER_HELLO' in str(e):
            notify('Oh oh','Python version to old - update to Krypton or FTMC')
            raise urllib2.HTTPError()
        else:
            Notify(msg="It looks like '{}' is down.".format(url), duration=200)
            raise
        return None

    if send_back_redirect == True:
        return data, redirected_url
    else:
        return data

    if response:
        response.close()
    
def postHtml(post_url, sent_data=None, headers=None, compression=True, NoCookie=None):
    #form_data = urllib.urlencode(form_data)
    return getHtml(url=post_url, headers=headers, save_cookie=NoCookie, sent_data=sent_data, method="POST" )

    
def xx_postHtml(post_url, form_data={}, headers={}, compression=True, NoCookie=None):
    raise
    try:
        
        from requests import Request, Session
        s = Session()

        if not headers:
            headers = DEFAULT_HEADERS.copy()
        if form_data:
            form_data = urllib.urlencode(form_data)
            headers['Content-Length'] = str(len(form_data))
            Log("form_data='{}'".format(form_data))
        if compression:
            headers['Accept-Encoding']='gzip'
        Log("headers='{}'".format(headers))

        proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
##        proxies = {"http": "127.0.0.1:8888"}
##        post_url = post_url.replace("https","http")
        request = Request('POST', post_url, data=form_data, headers=headers)
        prepped = s.prepare_request(request)
        response = s.send(prepped , proxies=proxies, verify=False)

        return response.content
            
##        for key, value in headers.items():
##            req.add_header(key,value)
####        _user_agent = 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 ' + \
####                  '(KHTML, like Gecko) Chrome/13.0.782.99 Safari/535.1'
####        req = urllib2.Request(url)
####        if form_data:
####            form_data = urllib.urlencode(form_data)
####            req = urllib2.Request(url, form_data)
####        req.add_header('User-Agent', _user_agent)
####        for k, v in headers.items():
####            req.add_header(k, v)
####        if compression:
####            req.add_header('Accept-Encoding', 'gzip')
####        proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
####        proxies = {"http": "127.0.0.1:8888"}
####        response = urllib2.urlopen(req)
####        data = response.read()
####        if not NoCookie:
####            try:
####                cj.save(cookiePath)
####            except: pass
####        response.close()
    except Exception as e:
        traceback.print_exc()
        
        if 'SSL23_GET_SERVER_HELLO' in str(e):
            notify('Oh oh','Python version to old - update to Krypton or FTMC')
            raise urllib2.HTTPError()
        else:
            Notify(msg="It looks like '{}' is down.".format(url), duration=200)
            raise urllib2.HTTPError()
        return None
    return data

def getHtml2(url):
    req = Request(url)
    response = urllib2.urlopen(req, timeout=60)
    data = response.read()
    response.close()
    return data


def getVideoLink(url, referer, hdr=None, data=None):
    if not hdr:
        req2 = Request(url, data, DEFAULT_HEADERS)
    else:
        req2 = Request(url, data, hdr)
    if len(referer) > 1:
        req2.add_header('Referer', referer)
    url2 = urllib2.urlopen(req2).geturl()
    return url2


def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q

from htmlentitydefs import name2codepoint
def htmlentitydecode(s):
    return re.sub('&(%s);' % '|'.join(name2codepoint), lambda m: unichr(name2codepoint[m.group(1)]), s)

def cleantext(text):

    text = text.replace('\t','')
    text = text.replace('\n','')
    
    if not isinstance(text, unicode):
        text = unicode(text.decode('utf-8', 'ignore'))    

##    from unidecode import unidecode
##    return unidecode(text)
    text = text.strip()

    text = htmlentitydecode(text)
    import unicodedata
    text = unicodedata.normalize('NFKD',text)
    text = html_parser.unescape(text)
    text = text.encode('utf-8')
    
    text = text.replace('&excl;','!')
    text = text.replace('&comma;',',')
    text = text.replace('&lowbar;','_')
    text = text.replace('&period;','.')
    text = text.replace('&lpar;','[')
    text = text.replace('&rpar;',']')

    return text

    #Log(text,xbmc.LOGNONE)
    #text = html_parser.unescape(text.encode('ascii', 'ignore'))
    text = htmlentitydecode(text)
    text = text.replace('&#8211;','-')
    text = text.replace('&ndash;','-')
    
    
    
    text = text.replace('&amp;','&')
    text = text.replace('&#038;','&')
    text = text.replace('&#8217;','\'')
    text = text.replace('&#8216;','\'')
    text = text.replace('&#8230;','...')
    text = text.replace('&quot;','"')
    text = text.replace('&excl;','!')
    text = text.replace('&apos;','\'')
    text = text.replace('&#039;','`')
    text = text.replace(u'ñ','n')


    #Log(text,xbmc.LOGNONE)
    #xbmc.log(  u'ñ'.encode("utf-8").decode("utf-8") , xbmc.LOGNONE)
    #text = text.encode("utf-8").replace('&ntilde;','\xf1').decode("utf-8")
    text = text.replace('&rsquo;','\'')
    text = text.encode('ascii', 'ignore').strip()


    return text


def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext

def Set_ListItem_Duration(listitem, duration):
    duration=str(duration).strip()
    duration_seconds = 0
    #Log("'{}'".format(duration), xbmc.LOGNONE)

    #somethimes will have a dot
    if '.' in duration:
        duration = duration.split('.')[1]
        
    #somethimes format will be hh:mm:ss: normalize it to what I want
    timearr= ['s ','m ','h ']
    if ':' in duration:
        duration_arr = duration.split(':')
        duration = ""
        #Log("len '{}'".format(len(duration_arr)), xbmc.LOGNONE)
        i = 0
        for duration_elem in reversed(duration_arr):
            #Log("'{}'".format(duration_elem), xbmc.LOGNONE)
            duration = duration_elem + timearr[i] + duration
            i = i+1

    duration=duration.strip()
    duration = duration.replace(' h', 'h').replace(' min', 'm').replace(' sec', 's')
    #Log("'{}'".format(duration), xbmc.LOGNONE)

    #assume format will be Xh Ym Zs
    duration_arr = duration.split(' ')
    for duration_elem in duration_arr:
        #Log(duration_elem)
        if 'h' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('h',''))*3600
        elif 'm' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('m',''))*60
        elif 's' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('s',''))
        else:
            duration_seconds = duration_seconds + int(duration_elem)
    #Log(duration_seconds)
    listitem.setInfo(type="Video", infoLabels={"duration": duration_seconds} )

def addDownLink(name, url, mode, iconimage
                , desc='', stream=None
                , fav='add', noDownload=False
                , duration=None, date=None
                , views=None, likes=None
                , play_method=None
                , hq_stream=None ):

    if fav == 'add': favtext = "Add to"
    elif fav == 'del': favtext = "Remove from"
    if not date:
        date = 0
    if not hq_stream:
        hq_stream = ''
    else:
        hq_stream = str(hq_stream)
        
    u = (
        "{}".format(sys.argv[0]) +
        "?url={}".format(urllib.quote_plus(url)) +
        "&mode={}".format(mode) +
        "&img={}".format(urllib.quote_plus(iconimage) ) +
        "&name={}".format(urllib.quote_plus(name)) +
        "&hq_stream={}".format(urllib.quote_plus(hq_stream)) +
        "&desc={}".format(urllib.quote_plus(desc.encode('utf8'))) +
        "&playmode_string={}".format(play_method)
        )
    dwnld = (
        "{}".format(sys.argv[0]) +
        "?url={}".format(urllib.quote_plus(url)) +
        "&mode={}".format(mode) +
        "&img={}".format(urllib.quote_plus(iconimage) ) +
        "&name={}".format(urllib.quote_plus(name)) +
        "&hq_stream={}".format(urllib.quote_plus(hq_stream)) +
        "&playmode_string={}".format(play_method) +
        "&download=1"
        )
    favorite = (
        "{}".format(sys.argv[0]) +
        "?url={}".format(urllib.quote_plus(url)) +
        "&mode={}".format(FAVORITES_MODE) +
        "&img={}".format(urllib.quote_plus(iconimage) ) +
        "&name={}".format(urllib.quote_plus(name)) +
        "&hq_stream={}".format(urllib.quote_plus(hq_stream)) +
        "&fav={}".format(fav) +
        "&favmode={}".format(mode) 
        )
    play_with_method = (
        "{}".format(sys.argv[0]) +
        "?url={}".format(urllib.quote_plus(url)) +
        "&mode={}".format(mode) +
        "&img={}".format(urllib.quote_plus(iconimage) ) +
        "&name={}".format(urllib.quote_plus(name)) +
        "&hq_stream={}".format(urllib.quote_plus(hq_stream)) +
        "&playmode_string={}" +
        "&megabitratebonus={}"
        )
    
##    Log("u={}".format(u))
##    Log("favorite={}".format(favorite))
    #Log("play_with_method={}".format(play_with_method))
    
    ok = True

    if len(iconimage) < 1: iconimage = uwcicon
    #Log("iconimage={}".format(iconimage))
    if not '|' in iconimage and 'http' in iconimage:
        iconimage = "{}{}".format(iconimage, Header2pipestring())
    #Log("iconimage={}".format(iconimage))

    liz = xbmcgui.ListItem(name) #, thumbnailImage=iconimage, iconImage="DefaultVideo.png")
    liz.setArt({ 'thumb': iconimage, 'fanart': iconimage }) #must include thumb to avoid error messages
    #liz.setArt({'thumb': iconimage, 'icon': iconimage, 'fanart': iconimage })
##    fanart = os.path.join(rootDir, 'fanart.jpg')
##    if addon.getSetting('posterfanart') == 'true':
##        fanart = iconimage
##        liz.setArt({'poster': iconimage})
##    liz.setArt({'fanart': fanart})

    if duration:
        Set_ListItem_Duration(liz, duration)

    liz.setContentLookup(False)
    
    if stream:
        #Log("iconimageasdasdf={}".format(iconimage))
        liz.setProperty('IsPlayable', 'true') #can't set this and use playlists at same time

    if len(desc) < 1:  desc = ''
    liz.setInfo(type="Video", infoLabels={"title": name, "plot": desc, "plotoutline": desc})

    liz.addStreamInfo('video', {'codec': 'h264'})

    contextMenuItems = []
    contextMenuItems.append(("[COLOR {}]{} favorites[/COLOR]".format(time_text_color, favtext), "xbmc.RunPlugin({})".format(favorite)))

    hq_bonus = int(addon.getSetting("hq_bonus").lower())

    #Log("play_method={}".format(play_method))
    if play_method in {PLAYMODE_INPUTSTREAM,PLAYMODE_F4MPROXY,''} :
        contextMenuItems.append( \
                (
                "[COLOR {}]{} Inputstream[/COLOR]".format(time_text_color, 'Play with')
                , "xbmc.RunPlugin({})".format(play_with_method.format('inputstream', 0))
                )
            )
        contextMenuItems.append( \
                (
                "[COLOR {}]{} F4Mproxy[/COLOR]".format(time_text_color, 'Play with')
                , "xbmc.RunPlugin({})".format(play_with_method.format(PLAYMODE_F4MPROXY, 0))
                )
            )
        contextMenuItems.append( \
                ( 
                "[COLOR {}]{} F4Mproxy + {}M[/COLOR]".format(time_text_color, 'Play with', hq_bonus)
                ,"xbmc.RunPlugin({})".format(play_with_method.format(PLAYMODE_F4MPROXY, hq_bonus))
                )
            )
    if noDownload == False:
        contextMenuItems.append(("[COLOR {}]Download Video[/COLOR]".format(time_text_color), "xbmc.RunPlugin({})".format(dwnld)))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)

    #Log("u='{}'".format(u))
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=False)
    return 


def addDir(name, url, mode, iconimage, page=None, channel=None, section=None
           , keyword='', Folder=True, duration=None, title=None, end_directory=True
           , contextMenu=None, contextMenuReplace=True):
    #return
    u = (sys.argv[0] +
     "?url=" + urllib.quote_plus(str(url)) +
     "&mode=" + str(mode) +
     "&page=" + str(page) +
     "&channel=" + str(channel) +
     "&section=" + str(section) +
     "&keyword=" + urllib.quote_plus(str(keyword)) +
     "&end_directory=" + str(end_directory) +
     "&name=" + urllib.quote_plus(str(name)))

    ok = True

    #Log("u={}".format(u))

    if len(iconimage) < 1: iconimage = uwcicon

    if not '|' in iconimage and 'http' in iconimage:
        iconimage = "{}{}".format(iconimage, Header2pipestring())

    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)

    liz.setProperty('IsPlayable', 'false')

    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    fanart = os.path.join(rootDir, 'fanart.jpg')

    if addon.getSetting('posterfanart') == 'true':
        fanart = iconimage
        liz.setArt({'poster': iconimage})

    liz.setArt({'fanart': fanart})

    if duration:
        Set_ListItem_Duration(liz, duration)

    #setting type = music instead of video means no icon to the right of the label
    #liz.setInfo(type="music", infoLabels={"Title": name})

    if title:
        liz.setInfo(type="Video", infoLabels={"Title": title})

    contextMenuItems = []
    if len(keyword) >= 1 and not("next page" in name.lower()):
        keyw = (sys.argv[0] +
            "?mode=" + str('904') +
            "&keyword=" + urllib.quote_plus(keyword))
        #if not contextMenuItems: contextMenuItems = []
        contextMenuItems.append( (
            "[COLOR {}]Remove keyword[/COLOR]".format(time_text_color)
            , "xbmc.RunPlugin({})".format(keyw) )  )

    if section and section == INBAND_RECURSE:
        #below will not work well because the 'back' button will return to root of addon, and not where I want     
        u2 = u.replace("&keyword=" + urllib.quote_plus(str(keyword)), "&keyword=" + INBAND_RECURSE)
        u2 = u2.replace("&page=" + str(page), "&page=" + str(int(page)-1)) #include the page we are on
        u2 = u2.replace("&page=" + str(page), "&page=1")  #include the page we are on
        contextMenuItems.append( (
            "[COLOR {}]Recurse to Page {}[/COLOR]".format(search_text_color, MAX_RECURSE_DEPTH)
            , "xbmc.ActivateWindow(Videos,{})".format(u2)  )  )
        contextMenuReplace=False

#####below does not work well because the 'back' button will return to root of addon, and not where I want
##    if add_recursive_search_submenu == True:
##        u2 = (sys.argv[0] +
##         "?url=" +
##         "&mode=" + str(mode) +
##         "&page=-1"
##         "&keyword=" + urllib.quote_plus(str(keyword)) +
##         "&end_directory=False" )
##        #Log("u2={}".format(u2))
##        if not contextMenuItems: contextMenuItems = []
####        contextMenuItems.append( (
####            "[COLOR {}]Recursive Search[/COLOR]".format(search_text_color)
####            , "xbmc.RunPlugin({})".format(u2)  )  )
##        contextMenuItems.append( (
##            "[COLOR {}]Recursive Search[/COLOR]".format(search_text_color)
##            , "ReplaceWindow(Videos," + u2 + ")"  )  )
##            #'XBMC.RunPlugin('+ Pluginurl+')') 
##            #"ActivateWindow(Videos," + u2 + ")"
##            #ReplaceWindow

    if contextMenu:
        contextMenuItems = contextMenu
        
    if contextMenuItems:
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)

    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=Folder)
    return liz

def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode(keyboard.getText(), "utf-8")
    else:
        return ""
    #return default

# videowood decode copied from: https://github.com/schleichdi2/OpenNfr_E2_Gui-5.3/blob/4e3b5e967344c3ddc015bc67833a5935fc869fd4/lib/python/Plugins/Extensions/MediaPortal/resources/hosters/videowood.py
def videowood(data):
    parse = re.search('(....ωﾟ.*?);</script>', data)
    if parse:
        todecode = parse.group(1).split(';')
        todecode = todecode[-1].replace(' ','')

        code = {
            "(ﾟДﾟ)[ﾟoﾟ]" : "o",
            "(ﾟДﾟ) [return]" : "\\",
            "(ﾟДﾟ) [ ﾟΘﾟ]" : "_",
            "(ﾟДﾟ) [ ﾟΘﾟﾉ]" : "b",
            "(ﾟДﾟ) [ﾟｰﾟﾉ]" : "d",
            "(ﾟДﾟ)[ﾟεﾟ]": "/",
            "(oﾟｰﾟo)": '(u)',
            "3ﾟｰﾟ3": "u",
            "(c^_^o)": "0",
            "(o^_^o)": "3",
            "ﾟεﾟ": "return",
            "ﾟωﾟﾉ": "undefined",
            "_": "3",
            "(ﾟДﾟ)['0']" : "c",
            "c": "0",
            "(ﾟΘﾟ)": "1",
            "o": "3",
            "(ﾟｰﾟ)": "4",
            }
        cryptnumbers = []
        for searchword,isword in code.iteritems():
            todecode = todecode.replace(searchword,isword)
        for i in range(len(todecode)):
            if todecode[i:i+2] == '/+':
                for j in range(i+2, len(todecode)):
                    if todecode[j:j+2] == '+/':
                        cryptnumbers.append(todecode[i+1:j])
                        i = j
                        break
                        break
        finalstring = ''
        for item in cryptnumbers:
            chrnumber = '\\'
            jcounter = 0
            while jcounter < len(item):
                clipcounter = 0
                if item[jcounter] == '(':
                    jcounter +=1
                    clipcounter += 1
                    for k in range(jcounter, len(item)):
                        if item[k] == '(':
                            clipcounter += 1
                        elif item[k] == ')':
                            clipcounter -= 1
                        if clipcounter == 0:
                            jcounter = 0
                            chrnumber = chrnumber + str(eval(item[:k+1]))
                            item = item[k+1:]
                            break
                else:
                    jcounter +=1
            finalstring = finalstring + chrnumber.decode('unicode-escape')
        stream_url = re.search('=\s*(\'|")(.*?)$', finalstring)
        if stream_url:
            return stream_url.group(2)
    else:
        return


def streamdefence(html):

    Log("streamdefence(html) detected")
    #Log("streamdefence(html)={}".format(html), xbmc.LOGNONE)

    if html == "":
        return html


    #iframe src="https://verystream.com/e/N3DnRCksHaR/younfn.mp4"
    verystream_url = re.compile('iframe src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    if verystream_url:
        verystream_url = verystream_url[0]
        Log("verystream_url={}".format(verystream_url))
        return getHtml(verystream_url)

    second_streamdefence_url = re.compile('strdef\.world/player([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    if second_streamdefence_url:
        second_streamdefence_url = 'https://www.strdef.world/player' + second_streamdefence_url[0]
        Log("second_streamdefence_url={}".format(second_streamdefence_url))
        #sdurl = "https://strdef.world/player.php?id=1ebd0d89-6813-40ed-a014-c0e2bec7252b"
        sdsrc = getHtml(second_streamdefence_url)
        return streamdefence(sdsrc)
    
    dhYas638H_code = re.compile('\(dhYas638H\(\"([0-9a-zA-Z/-_\+\=]+)\"', re.DOTALL | re.IGNORECASE).findall(html)
    if dhYas638H_code:
        Log("second encoding")
        dhYas638H_code = dhYas638H_code[0]
        try:
            dhYas638H_code = 'base64decoded(dhYas638H("' + base64.b64decode(dhYas638H_code) + '"'
            Log("base 64 decode successful")
            return streamdefence(dhYas638H_code)
        except:
            pass
        
        #Log("dhYas638H_code={}".format(dhYas638H_code) )
        dhYas638H_decoded = dhYas638H(dhYas638H_code)

        html = html.replace('dhYas638H("'+dhYas638H_code+'")', '"' + dhYas638H_decoded + '"' )
        Log("html_after_replace={}".format(html) )
        return html

    else:
        Log("second encoding NOT found")

    dhYas638H_code = None
    dhYas638H_code = re.compile('= dhYas638H\(\"?([0-9a-zA-Z-/_\+\=]+)\"?\)', re.DOTALL | re.IGNORECASE).findall(html)
    if dhYas638H_code:
        dhYas638H_code = dhYas638H_code[0]
        #Log("dhYas638H_code={}".format(dhYas638H_code), xbmc.LOGNONE)
        third_redirect = None

        third_redirect = re.compile(dhYas638H_code+'=\"([0-9a-zA-Z/-_\+\=]+)\"'  , re.DOTALL | re.IGNORECASE).findall(html)
        if third_redirect:
            third_redirect = third_redirect[0]
            #Log("third_redirect={}".format(third_redirect), xbmc.LOGNONE)        
            dhYas638H_decoded = dhYas638H(third_redirect)
            return streamdefence(dhYas638H_decoded)
    else:
        Log("no third_redirect found")        
    html = re.compile('"(https?:\/\/[^\"]+)"', re.DOTALL | re.IGNORECASE).findall(html)[0]

    #Log("decoded={}".format(html), xbmc.LOGNONE)
    return html



##playerlib.alltubes.8.6.3.v1.425.js
##in:
##var EiCkh8i4='[{"video_url":"aHR0cH\u041c6Ly9tZW1iZXIudHViZX\u0412vcm5jbGFzc2ljLmNvbS9nZXRfZmlsZS8xLz\u04154Yj\u04102NG\u04153\u041cz\u04154Yj\u04101NWJkOWI5\u041cmRmNTQ1N2\u0415wYzU0\u041cTJjNDlmZDc5O\u04218x\u041cDYx\u041cD\u0410wLz\u0415wNj\u04155\u041cj\u0410v\u041cT\u04102\u041cTky\u041c\u04215tcDQvP2Q9\u041cTgxJmJyPT\u0415wO\u0421Z0aT0xNTYxND\u04104\u041cj\u041cwJmxpcD0y\u041cTY~","is_default":1}]';
##out:
##https://member.tubepornclassic.com/get_file/1/
##18b064a7318b055bd9b92df5457a0c5412c49fd798/1061000/1061920/
##1061920.mp4/?d=181&br=108&ti=1561408230&lip=216&f=video.m3u8
##
##
##window.Dpww3Dw64 = function(k) {
##    var c = ""
##      , f = 0;
##    /[^\u0410\u0412\u0421\u0415\u041cA-Za-z0-9\.,~]/g.exec(k) && console.log("error decoding url");
##    k = k.replace(/[^\u0410\u0412\u0421\u0415\u041cA-Za-z0-9\.,~]/g, "");
##    do {
##        var e = "\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~".indexOf(k.charAt(f++))
##          , n = "\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~".indexOf(k.charAt(f++))
##          , m = "\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~".indexOf(k.charAt(f++))
##          , r = "\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~".indexOf(k.charAt(f++));
##        e = e << 2 | n >> 4;
##        n = (n & 15) << 4 | m >> 2;
##        var v = (m & 3) << 6 | r;
##        c += String.fromCharCode(e);
##        64 != m && (c += String.fromCharCode(n));
##        64 != r && (c += String.fromCharCode(v))
##    } while (f < k.length);return unescape(c)
##}
##;
def alltubes_decode(input_string):
    #Log("input_string={}".format(input_string))
    #aHR0cH\u041c6Ly9tZW1iZXIudHViZX\u0412vcm5jb
    #\u041daHR0cH\u041c
    #     01234567
    #aHR0cH\u041c
    #01234567
    k = input_string
##    Log(k[4])
##    Log(k[5])
##    Log(k[6])
    if not isinstance(input_string, unicode):
##        Log("not")
        input_string = input_string.decode("raw_unicode_escape")
    #"MaHR0cH\u041c
    k = input_string
##    #Log(k[0])
##    #Log(k[1]) #a
##    #Log(k[2]) #H
##    Log(k[4]) #R
##    Log(k[5]) #0
##    Log(k[6]) #c
    k = re.sub(u'(?is)[^\u0410\u0412\u0421\u0415\u041cA-Za-z0-9\.,~]','',k)
##    Log("regex sub")
##    Log(k[4]) #c
##    Log(k[5]) #H
##    #Log(k[6]) #\u041c

    f = 0; c= "";
    base64 = u"\u0410\u0412\u0421D\u0415FGHIJKL\u041cNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~"
    while (f < len(k)):
        e = base64.index(k[f+0])
        n = base64.index(k[f+1])
        m = base64.index(k[f+2])
        r = base64.index(k[f+3])
        f = f + 4
        e = (e << 2) | (n >> 4)
        n = ((n & 15) << 4) | (m >> 2)
        v = ((m & 3) << 6) | r
        c = c + from_char_code(e)
        if (m != 64):
            c = c + from_char_code(n)
        if (r != 64):
            c = c + from_char_code(v)
        
        

    Log("alltubes_decode={}".format(c))
##    Log("end")
    return c
    


    
def from_char_code(*args):
    return ''.join(map(unichr, args))

def dhYas638H(input_string
              , base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
              , substitutions = "[^A-Za-z0-9+/=]"
              ):
    #base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    output = "";
    i = 0;
    #Log("base64={}".format(base64.decode('utf-16')), xbmc.LOGNONE)
    #Log("input_string={}".format(input_string), xbmc.LOGNONE)
    input_string = re.sub(substitutions, "", input_string, re.DOTALL)
    #Log("input_string={}".format(input_string), xbmc.LOGNONE)
    
    while i < len(input_string) :

        #Log("i+0={},input_stringi+0={}".format(i,input_string[i+0]), xbmc.LOGNONE)        
        enc1 = base64.index(  input_string[i+0]  )
        #Log("enc1={}".format(enc1), xbmc.LOGNONE)        
        enc2 = base64.index(  input_string[i+1]  )
        #Log("enc2={}".format(enc2), xbmc.LOGNONE)        
        enc3 = base64.index(  input_string[i+2]  )
        #Log("enc3={}".format(enc3), xbmc.LOGNONE)        
        enc4 = base64.index(  input_string[i+3]  )
        #Log("enc4={}".format(enc4), xbmc.LOGNONE)        
        i = i+4

        ch1 = (enc1 << 2) | (enc2 >> 4)
        #Log("ch1={}".format(ch1), xbmc.LOGNONE)        
        ch2 = ((enc2 & 15) << 4) | (enc3 >> 2)
        #Log("ch2={}".format(ch2), xbmc.LOGNONE)        
        ch3 = ((enc3 & 3) << 6) | enc4

        output = output + from_char_code(ch1)
        #Log(output, xbmc.LOGNONE)
        
        if (enc3 != 64):
            Log(from_char_code(ch2), xbmc.LOGNONE)
            output = output + from_char_code(ch2)
            #Log("--" + output, xbmc.LOGNONE)
        if (enc4 != 64):
            output = output + from_char_code(ch3)
            #Log("-----" + output, xbmc.LOGNONE)

        ch1 = ""
        ch2 = ""
        ch3 = ""
        enc1 = ""
        enc2 = ""
        enc3 = ""
        enc4 = ""

    #Log("dhYas638H_output={}".format(output), xbmc.LOGNONE)        
    return output



def searchDir(url, mode, page='1', end_directory=True):

    label = "{}[COLOR {}]Quick Search[/COLOR]".format(SPACING_FOR_TOPMOST, search_text_color) 
    addDir(
        name= label
        ,url=url 
        ,mode=QWIK_SEARCH 
        ,iconimage=search_icon 
        ,page=page
        ,channel=mode
        ,end_directory=end_directory)

#def addDir(name, url, mode, iconimage, page=None, channel=None, section=None, keyword='', Folder=True, duration=None, title=None, end_directory=True):
    addDir(
        "{}[COLOR {}]Add Keyword[/COLOR]".format(SPACING_FOR_NEXT,search_text_color)
        , url=''
        , mode=902
        , iconimage=search_icon
        , channel=mode)

    addDir(
        "{}[COLOR {}]Clear list[/COLOR]".format(SPACING_FOR_NEXT,search_text_color)
        , url=''
        , mode=903
        , iconimage=search_icon)


    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    try:
        c.execute("SELECT * FROM keywords")
        for (keyword,) in c.fetchall():
            label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, time_text_color, urllib.unquote_plus(keyword))
            addDir(
                name=label
                , url=url 
                , mode=mode
                , iconimage=search_icon 
                , page=page
                , keyword=keyword
                , end_directory=end_directory)


    except:
        traceback.print_exc()
        pass

    add_sort_method()    
    endOfDirectory()


##@url_dispatcher.register(QWIK_SEARCH, ['url', 'channel'])
##def Quick_Search(url, channel, end_directory=True, page='1'):
@url_dispatcher.register('902', ['channel'])
def NewSearchKeyword(channel):
    Log("NewSearchKeyword channel='{}'".format( channel))
    vq = _get_keyboard(heading="Searching for...")
    if (not vq): return False, 0
    keyword = urllib.quote_plus(vq)
    AddKeyword(keyword)
    Quick_Search(url='', channel=channel, end_directory=True, page='1', keyword=keyword)
    #xbmc.executebuiltin('Container.Refresh')

@url_dispatcher.register('903')
def clearSearch():
    delallKeyword()
    xbmc.executebuiltin('Container.Refresh')


def AddKeyword(keyword):
    Log("AddKeyword keyword='{}'".format(keyword))
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("INSERT INTO keywords VALUES (?)", (keyword,))
    conn.commit()
    conn.close()


def delallKeyword():
    yes = dialog.yesno('Warning','This will clear all the keywords', 'Continue?', nolabel='No', yeslabel='Yes')
    if yes:
        conn = sqlite3.connect(favoritesdb)
        c = conn.cursor()
        c.execute("DELETE FROM keywords;")
        conn.commit()
        conn.close()

@url_dispatcher.register('904', ['keyword'])
def delKeyword(keyword):
    xbmc.log('keyword: ' + keyword)
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM keywords WHERE keyword = '%s'" % keyword)
    conn.commit()
    conn.close()
    xbmc.executebuiltin('Container.Refresh')

@url_dispatcher.register(QWIK_SEARCH, ['url', 'channel'], ['end_directory','page','keyword'])
def Quick_Search(url, channel, end_directory=True, page='1', keyword=None):

    Log("Quick_Search url='{}', channel='{}', end_directory='{}', page='{}', keyword='{}'".format( url, channel, end_directory, page, keyword))


    if not keyword:
        ##get the search string from user; remember it; pre-populate remembered
        prev_search_string = this_addon.getSetting(id='quick_search_string')
        quick_search_string = _get_keyboard( heading="Search query", default=prev_search_string  )
        if  quick_search_string == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        this_addon.setSetting(id='quick_search_string', value=quick_search_string)
        #Log("quick_search_string='{}'".format(quick_search_string))
    else:
        quick_search_string = keyword

    ##
    ## this method works, but needs to be set per site
    ##
    from resources.lib.sites import hqporner
    from resources.lib.sites import k18
    from resources.lib.sites import pornhub
    from resources.lib.sites import daftsex
    from resources.lib.sites import vporn
    from resources.lib.sites import xhamster
    from resources.lib.sites import paradisehill
    from resources.lib.sites import freeomovie
    from resources.lib.sites import bubbaporn
    from resources.lib.sites import poldertube
    from resources.lib.sites import sextube
    from resources.lib.sites import tubepornclassic
    from resources.lib.sites import hclips
    from resources.lib.sites import porndig
    from resources.lib.sites import absoluporn
    from resources.lib.sites import anybunny
    from resources.lib.sites import spankbang
    from resources.lib.sites import amateurcool
    from resources.lib.sites import beeg

    #from resources.lib.sites import erotik
    from resources.lib.sites import mrsexe

    #from resources.lib.sites import woxtube
    from resources.lib.sites import porn00
    
    from resources.lib.sites import porntrex
    from resources.lib.sites import streamxxx
    from resources.lib.sites import videomegaporn
    #from resources.lib.sites import xtasie
    from resources.lib.sites import xvideospanish
    from resources.lib.sites import xxxstreams
    from resources.lib.sites import xxxsorg
    #from resources.lib.sites import watchxxxfree
##    from resources.lib.sites import yourfreetube
    #from resources.lib.sites import czechhd
    from resources.lib.sites import tube8
    from resources.lib.sites import xvideos
    from resources.lib.sites import pornhd
    from resources.lib.sites import pornoxo
    from resources.lib.sites import pornmaki
    from resources.lib.sites import moviefap
    from resources.lib.sites import empflix
    from resources.lib.sites import extremetube
    from resources.lib.sites import faapy
    from resources.lib.sites import girlfriendvideos
    #from resources.lib.sites import mofosex
    from resources.lib.sites import motherless
    from resources.lib.sites import bitporno
    from resources.lib.sites import redtube
    from resources.lib.sites import sunporno
    #from resources.lib.sites import porn
    from resources.lib.sites import youporn
##    from resources.lib.sites import madthumbs
##    from resources.lib.sites import slutload
    from resources.lib.sites import ah_me
    from resources.lib.sites import eporner
    from resources.lib.sites import pornomovies
    from resources.lib.sites import tukif
    from resources.lib.sites import pornburst
    from resources.lib.sites import animeidhentai
    from resources.lib.sites import fpoxxx
    from resources.lib.sites import txxx
    from resources.lib.sites import vipporns
    from resources.lib.sites import hentaihaven
    
    if  txxx.SEARCH_MODE == str(channel):
        txxx.Search(txxx.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  vipporns.SEARCH_MODE == str(channel):
        vipporns.Search(vipporns.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  fpoxxx.SEARCH_MODE == str(channel):
        fpoxxx.Search(fpoxxx.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  hentaihaven.SEARCH_MODE == str(channel):
        hentaihaven.Search(hentaihaven.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  animeidhentai.SEARCH_MODE == str(channel):
        animeidhentai.Search(animeidhentai.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  pornburst.SEARCH_MODE == str(channel):
        pornburst.Search(pornburst.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  tukif.SEARCH_MODE == str(channel):
        tukif.Search(tukif.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  pornomovies.SEARCH_MODE == str(channel):
        pornomovies.Search(pornomovies.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  eporner.SEARCH_MODE == str(channel):
        eporner.Search(eporner.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  ah_me.SEARCH_MODE == str(channel):
        ah_me.Search(ah_me.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  slutload.SEARCH_MODE == str(channel):
##        slutload.Search(slutload.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  madthumbs.SEARCH_MODE == str(channel):
##        madthumbs.Search(madthumbs.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  youporn.SEARCH_MODE == str(channel):
        youporn.Search(youporn.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  porn.SEARCH_MODE == str(channel):
##        porn.Search(porn.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  sunporno.SEARCH_MODE == str(channel):
        sunporno.Search(sunporno.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  redtube.SEARCH_MODE == str(channel):
        redtube.Search(redtube.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  bitporno.SEARCH_MODE == str(channel):
        bitporno.Search(bitporno.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  motherless.SEARCH_MODE == str(channel):
        motherless.Search(motherless.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  mofosex.SEARCH_MODE == str(channel):
##        mofosex.Search(mofosex.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  girlfriendvideos.SEARCH_MODE == str(channel):
        girlfriendvideos.Search(faapy.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  faapy.SEARCH_MODE == str(channel):
        faapy.Search(faapy.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  extremetube.SEARCH_MODE == str(channel):
        extremetube.Search(extremetube.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)  
    elif  empflix.SEARCH_MODE == str(channel):
        empflix.Search(empflix.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  moviefap.SEARCH_MODE == str(channel):
        moviefap.Search(moviefap.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  pornmaki.SEARCH_MODE == str(channel):
        pornmaki.Search(pornmaki.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  pornoxo.SEARCH_MODE == str(channel):
        pornoxo.Search(pornoxo.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  pornhd.SEARCH_MODE == str(channel):
        pornhd.Search(pornhd.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  xvideos.SEARCH_MODE == str(channel):
        xvideos.Search(tube8.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  tube8.SEARCH_MODE == str(channel):
        tube8.Search(tube8.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  czechhd.SEARCH_MODE == str(channel):
##        czechhd.Search(czechhd.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  yourfreetube.SEARCH_MODE == str(channel):
##        yourfreetube.Search(yourfreetube.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  watchxxxfree.SEARCH_MODE == str(channel):
##        watchxxxfree.Search(watchxxxfree.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  xxxsorg.SEARCH_MODE == str(channel):
        xxxsorg.Search(xxxsorg.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  xxxstreams.SEARCH_MODE == str(channel):
        xxxstreams.Search(xxxstreams.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  xvideospanish.SEARCH_MODE == str(channel):
        xvideospanish.Search(xvideospanish.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  xtasie.SEARCH_MODE == str(channel):
##        xtasie.Search(xtasie.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  videomegaporn.SEARCH_MODE == str(channel):
        videomegaporn.Search(videomegaporn.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  streamxxx.SEARCH_MODE == str(channel):
        streamxxx.Search(streamxxx.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  porntrex.SEARCH_MODE == str(channel):
        porntrex.Search(porntrex.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  hdporn.SEARCH_MODE == str(channel):  #note: special for url
##        hdporn.Search(url, quick_search_string, end_directory=end_directory, page=page) 
##    elif  woxtube.SEARCH_MODE == str(channel):
##        woxtube.Search(woxtube.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 

    elif  porn00.SEARCH_MODE == str(channel):
        porn00.Search(porn00.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 


    elif  mrsexe.SEARCH_MODE == str(channel):
        mrsexe.Search(mrsexe.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
##    elif  erotik.SEARCH_MODE == str(channel):
##        erotik.Search(erotik.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  beeg.SEARCH_MODE == str(channel):
        beeg.Search(beeg.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  amateurcool.SEARCH_MODE == str(channel):
        amateurcool.Search(amateurcool.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  spankbang.SEARCH_MODE == str(channel):
        spankbang.Search(spankbang.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  anybunny.SEARCH_MODE == str(channel):
        anybunny.Search(anybunny.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  absoluporn.SEARCH_MODE == str(channel):
        absoluporn.Search(absoluporn.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page) 
    elif  porndig.SEARCH_MODE == str(channel):  #special
        porndig.Search(url, quick_search_string, end_directory=end_directory, page=page)
    elif  hclips.SEARCH_MODE == str(channel):
        hclips.Search(hclips.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  tubepornclassic.SEARCH_MODE == str(channel):
        tubepornclassic.Search(tubepornclassic.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  sextube.SEARCH_MODE == str(channel):
        sextube.Search(sextube.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  poldertube.SEARCH_MODE == str(channel):
        poldertube.Search(poldertube.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  bubbaporn.SEARCH_MODE == str(channel):
        bubbaporn.Search(bubbaporn.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  freeomovie.SEARCH_MODE == str(channel):
        freeomovie.Search(freeomovie.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  paradisehill.SEARCH_MODE == str(channel):
        paradisehill.Search(paradisehill.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  hqporner.SEARCH_MODE == str(channel):
        hqporner.Search(hqporner.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  k18.SEARCH_MODE == str(channel):
        k18.Search(k18.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  pornhub.SEARCH_MODE == str(channel):
        pornhub.Search(pornhub.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  daftsex.SEARCH_MODE == str(channel):
        daftsex.Search(daftsex.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  vporn.SEARCH_MODE == str(channel):
        vporn.Search(vporn.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)
    elif  xhamster.SEARCH_MODE == str(channel):
        xhamster.Search(xhamster.SEARCH_URL, quick_search_string, end_directory=end_directory, page=page)

    else:

        if not ROOT_SEARCH_ALL == str(channel):
            Notify(msg="Missing optimized quicksearch for mode:{} url={}".format(channel,url))

        #this method works, but has issue:
        #  the 'back' button does not work properly; it returns to the root of this addon 
        search_url = (sys.argv[0] +
         "?url=" + url +
         "&name=" + 'Quick_Search' +
         "&page=" + '1' +
         "&section=" + 'None' +
         "&mode=" + str(channel) +
         "&keyword=" + urllib.quote_plus(quick_search_string) +
         "&end_directory=" + str(end_directory) )
        
        WINDOW_VIDEO_NAV = 10025
        xbmc.executebuiltin('ActivateWindow({},{})'.format(WINDOW_VIDEO_NAV,search_url))

        add_sort_method()
        endOfDirectory()
    

def textBox(heading,announce):
    class TextBox():
        WINDOW=10147
        CONTROL_LABEL=1
        CONTROL_TEXTBOX=5
        def __init__(self,*args,**kwargs):
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win=xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()
        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            try: f=open(announce); text=f.read()
            except: text=announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return
    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        xbmc.sleep(500)

def kodilog(msg, loglevel=None):
    Log(msg,loglevel)
def log(msg='', loglevel=None):
    Log(msg, loglevel)
def Log(msg='', loglevel=None):
    #import unicodedata
    #xbmc.log(msg.decode('unicode-escape').encode('utf-8'),xbmc.LOGNONE)
    #xbmc.log(msg.decode('utf8',errors='ignore').encode('ascii',errors='ignore'),xbmc.LOGNONE)
    try:    debug = (this_addon.getSetting('debug').lower() == "true")
    except: debug = True
    if re.compile("\\u\s\s\s\s").findall(msg):
        msg = msg.decode('unicode-escape',errors='ignore').encode('utf-8',errors='ignore')
    msg = "{}: {}".format(addon_id, msg)
    if loglevel: xbmc.log(msg , loglevel)
    elif debug:  xbmc.log(msg , xbmc.LOGNONE)
    else:    xbmc.log(msg)

def Notify(header=None, msg='', duration=5000, sound=False):
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound)
def notify(header=None, msg='', duration=5000, sound=False):
    debug = (this_addon.getSetting('debug').lower() == "true")
    if threading.current_thread().name == "MainThread":
        Log( msg, xbmc.LOGNOTICE)
        if header==None or header == '':
            if len(msg) > 30:
                header = msg[0:30]
                msg = msg[-30:]
            else:
                header=msg
        xbmcgui.Dialog().notification(header, msg, uwcicon, duration, sound=False )
    elif debug:
        Log( msg, xbmc.LOGNOTICE)

def Header2pipestring(header=DEFAULT_HEADERS):
    q = "|{}".format( urllib.urlencode(header)  )
    return q

def add_sort_method():

    sort_order = int(addon.getSetting('video_sort_by'))
    if sort_order == 1:
        sort_order = xbmcplugin.SORT_METHOD_DURATION
    elif sort_order == 2:
        sort_order = xbmcplugin.SORT_METHOD_DATE
    elif sort_order == 3:
        sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
    elif sort_order == 4:
        sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
    elif sort_order == 5:
        sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
    else:
        sort_order = xbmcplugin.SORT_METHOD_UNSORTED
    
    xbmcplugin.addSortMethod(addon_handle,sortMethod=sort_order) #use preferred method first
    #xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
#    xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_DURATION)
    

## based on /player/kt_player.swf?v=4.0.4
def FaapySalt(licencekey, video_url):
    #m is a salt used later
    #d=licencecode
    #k = first 8 numbs of licence key
    #l= last 8
    c = "16px"
    #$3790 8681 2506 737
    #3790868 12506737
    #c =  video_url: 'function/0/https://faapy.com/get_file/1/1209b8bc708dea4836ab494685daf627/10000/10267/10267.mp4/',
    d = licencekey

#    f = licencekey without dollar sign, but then get changed
#        g = 1; g < d.length; g++)
#        f += o(d[g]) ? o(d[g]) : 1;
    g = 1 # starts at 1 because of dollar sign
    f = ""
    while g < len(licencekey):
##        f += licencekey[g]
        if int(licencekey[g]) == 0:
            f += '1'
        else:
            f += licencekey[g]
##        Log("f='{}'".format(f))
            
        g += 1

    #return f #for debugging
    j = len(f)/2
##    Log("j='{}'".format(j))
    f = oo(f)

    k=''
##    for i in range(1,9):
##        k += licencekey[i]
    k = str(f)[0:j+1]    
    k = oo(k)
##    Log("k='{}'".format(k))

    L=''
    
##    for i in range(8,16):
##        L += licencekey[i]
##    Log("L='{}'".format(L))
    L = str(f)[j:]
    L = oo(L)
##    Log("L='{}'".format(L))
    #return L

    g = abs(L - k)
#    return g
##    g < 0 && (g = -g)
    f = g

    g = abs(k - L)
##    g < 0 && (g = -g)
##    Log("g='{}'".format(g))

    f += g
    f *= 2
    f = str(f)
##    Log("f='{}'".format(f))
#    return f
    i = oo(c) / 2 + 2
    #Log("i='{}'".format(i))
    m = ""
####    g = 0; g < j + 1; g++)
####        for (h = 1; h <= 4; h++)
####        n = o(d[g + h]) + o(f[g]),
####        n >= i && (n -= i),
####        m += n;
####    return m
    g = 0
    while g < (j+1) :
        h = 1
        while h <= 4:
            n = oo(d[g + h]) + oo(f[g])
            if n >= i:
                n -= i
            m = m + str(n)
##            Log("m='{}'".format(m))
            h += 1

        g += 1

    return m
####o =    return function(n, r) {
####            var o = String(n).trim()
####              , i = Number(r) || (t.test(o) ? 16 : 10);
####            return e(o, i)
####            }
##    return m



def oo(val):
    return int(filter(str.isdigit, val))

def ConvertFaapyCode(code, salt):
# h = code
# i = salt
##for (var j = h, k = h.length - 1; k >= 0; k--) {
##    for (var l = k, m = k; m < i.length; m++)
##        l += parseInt(i[m]);
##    for (; l >= h.length; )
##        l -= h.length;
##    for (var n = "", o = 0; o < h.length; o++)
##        n += o == k ? h[l] : o == l ? h[k] : h[o];
##    h = n
##    }
## 1209b8bc708dea4836ab494685daf627
## 12345678901234567890123456789012
#fappysalt 48017908019764248681358958928927

    #xbmc.log("salt='{}', length={}".format(salt, len(salt)), xbmc.LOGNONE)
    #xbmc.log("code='{}', length={}".format(code, len(code)), xbmc.LOGNONE)
    j = salt
    h = code
    k = len(h)-1
    while k >= 0:

        L = k
        m = k
        while m < len(salt) :
            L = L + int(salt[m])
            m += 1

        while L >= len(h):
            L = L - len(h)

        n = ""
        o = 0
        while o < len(h):
            if o == k:
                n = n + h[L]
            else:
                if o == L:
                    n = n + h[k]
                else:
                    n = n + h[o]
                    
            o += 1

        h = n

##        Log(n)

        k -=1

    return n

@url_dispatcher.register('9999')
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()


def endOfDirectory(cacheToDisc=True):
    global addon_handle
    #Log('1. int(sys.argv[1])={}'.format(int(sys.argv[1])))
    if int(sys.argv[1]) > 0:
        addon_handle = int(sys.argv[1])
        #Log('2. int(sys.argv[1])={}'.format(int(sys.argv[1])))
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=cacheToDisc)
        #Log('3. int(sys.argv[1])={}'.format(int(sys.argv[1])))

def SortVideos(sources, vid_res_column=1, substitute_char='}', substitute_res='720'):

    #sometimes we can't get accurate resolutions and end up with a characters instead...
    # e.g. "http://video.mp4","}"     instead of   "http://video.mp4","480p"

    Log("sources='{}'".format(sources))

    maximum_video_resolution = int(addon.getSetting("maximum_video_resolution"))
    Log("maximum_video_resolution='{}'".format(maximum_video_resolution))
    s1440p_string = "1440p"
    s2160p_string = "2160p"
    s3840p_string = "3840p"
    s1080p_string = "1080p"
    s720p_string = "720p"
    s480p_string = "480p"
    if maximum_video_resolution < 3840:
        s3840p_string = "40p"
    if maximum_video_resolution < 2160:
        s2160p_string = "60p"
    if maximum_video_resolution < 1440:
        s1440p_string = "14p"
    if maximum_video_resolution < 1080:
        s1080p_string = "14p"
    if maximum_video_resolution < 720:
        s720p_string = "14p"
    if maximum_video_resolution < 480:
        s480p_string = "80p"

##     the list of videos is a bunch of urls such as xxx\360.mp4
##        i use a lambda(just for fun) to split out the numeric resolution and the reverse sort it;
##        the best resolution should end up on top
##        the 720 is replaced with 719 so that the number ending 20 does not match other possible strings the site may use to define ultra resolutions
##        the letter p is removed so that we can convert to integer and avoid the 720 is better 1080 situation if it were chars
##        the higher resolutions, when we have been told not to use them, are replaced with lower numbered strings 

    try:
        videos = sorted(sources, key=lambda tup: int(tup[vid_res_column].lower() \
                                                 .replace('720',s720p_string) \
                                                 .replace(substitute_char   ,substitute_res)\
                                                 .replace('720' ,'719')\
                                                 .replace('2160',s2160p_string)\
                                                 .replace('7p'  ,s2160p_string)\
                                                 .replace('3840',s3840p_string)\
                                                 .replace('20p' ,s3840p_string)\
                                                 .replace('1440',s1440p_string)\
                                                 .replace('1080',s1080p_string)\
                                                 .replace('480' ,s480p_string)\
                                                 .replace('p','')\
                                                 .replace('(','')\
                                                 .replace(')','')\
                                                 .replace('hd','')\
                                                 .replace('@60fs','')\
                                                 .replace('2k','')\
                                                 .replace('4k','') ), reverse=True)
    except:
        videos = None
        traceback.print_exc()

    Log("videos='{}'".format(videos))
    if len(videos) < 1:
        return None
    if vid_res_column == 1:
        video_url = videos[0][0]
    else:
        video_url = videos[0][1]
    Log("video_url='{}'".format(video_url))
    return video_url

#<script type='text/javascript'>eval(function(p,a,c,k,e,d){
#while(c--)if(k[c])p=p.replace(new RegExp('\\b'+c.toString(a)+'\\b','g'),k[c]);
#return p}('8("2s").2r({2q:[{k:"7://d.6.4/2p/,j,.s/2o.2n"}
#,{k:"7://d.6.4/q/,j,.s/2m.2l"},{k:"7://d.6.4/j/v.2k",2j:"2i"}]
#,2h:"7://d.6.4/i/2g/2f/m.2e",2d:"r%",2c:"r%",2b:""
#,2a:"29.28",27:\'26\',25:"c",24:"c",23:"22",21:"20",1z:[],q:c
#,1y:"1x 19 1w 1v 1u 1t 1s 1r",1q:c,1p:"",1o:"7://6.4"});
#1n e,h,g=0;8().1m(3(x){a(5>0&&x.b>=5&&h!=1){h=1;$(\'f.1l\').1k(\'1j\')}a(g==0&&x.b>=p&&x.b<=(p+2)){g=x.b}})
#;8().1i(3(x){o(x)});8().1h(3(){$(\'f.n\').1g()});3 o(x){$(\'f.n\').1f()
#;a(e)1e;e=1;9=0;a(1d.1c===1b){9=1}$.1a(\'7://6.4/18?17=16&15=m&14=13-12-11-10-z&y=1&9=\'+9,3(l){$(\'#w\').u(l)})}8().t(3(){});',36,101,
#'|||function|co||datoporn|https|jwplayer|adb|if|position|true|cn3|vvplay|div|x2ok|vvad||3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7ddefv2xmq|file|data|bqtkjq2dj5mn|video_ad|doPlay|104|dash|100|urlset|onReady|html||fviews||embed|badc5ab5387c0db45e2d4807e8aa74a0|1562430193|154|216|2484626|hash|file_code|view|op|dl||get|undefined|cRAds|window|return|hide|show|onComplete|onPlay|slow|fadeIn|video_ad_fadein|onTime|var|aboutlink|abouttext|displaytitle|1080p|XXX|Paul|Lena|04|07|BigTitsRoundAsses|title|tracks|start|startparam|html5|primary|hlshtml|androidhls|none|preload|79|2081|duration|stretching|height|width|jpg|00496|01|image|720p|label|mp4|mpd|manifest|m3u8|master|hls|sources|setup|vplayer'.split('|')))     

def toString(a, b=10):
    #if a > 2000: return None #only tested to this number....algo may be wrong
    t = int(a)
    remainder = t % b
    val = t // b
    if val > 9:
        val = toString(val, b)
        s = str(val)
    elif val > 0:
        s = str(val)
    else:
        s = ""
    zero_offset = 48
    if remainder > 9:
        zero_offset +=7
    s += chr( zero_offset + remainder).lower()
    return s
        
def dePacked(p,a,c,k,e,d):
    c = int(c)
    a = int(a)
    while c > 0:
        c = c - 1
        if ( k[c] ): #skip the blanks
            p = re.sub('\\b' + toString(c, a) + '\\b', k[c], p, flags=re.DOTALL)
    return p

#p: "jwplayer("vplayer").setup({sources:[{file:"https://cn3.datoporn.co/hls/,3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7h7pvv2xmq,.urlset/master.m3u8"},{file:"https://cn3.datoporn.co/dash/,3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7h7pvv2xmq,.urlset/manifest.mpd"},{file:"https://cn3.datoporn.co/3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7h7pvv2xmq/v.mp4",label:"720p"}],image:"https://cn3.datoporn.co/i/01/00496/bqtkjq2dj5mn.jpg",width:"100%",height:"100%",stretching:"",duration:"2081.79",preload:'none',androidhls:"true",hlshtml:"true",primary:"html5",startparam:"start",tracks:[],dash:true,title:"BigTitsRoundAsses 19 07 04 Lena Paul XXX 1080p",displaytitle:true,abouttext:"",aboutlink:"https://datoporn.co"});var vvplay,vvad,x2ok=0;jwplayer().onTime(function(x){if(5>0&&x.position>=5&&vvad!=1){vvad=1;$('div.video_ad_fadein').fadeIn('slow')}if(x2ok==0&&x.position>=104&&x.position<=(104+2)){x2ok=x.position}});jwplayer().onPlay(function(x){doPlay(x)});jwplayer().onComplete(function(){$('div.video_ad').show()});function doPlay(x){$('div.video_ad').hide();if(vvplay)return;vvplay=1;adb=0;if(window.cRAds===undefined){adb=1}$.get('https://datoporn.co/dl?op=view&file_code=bqtkjq2dj5mn&hash=2484626-216-154-1562441919-ea24f645509dd225056f7bac0f21b967&embed=1&adb='+adb,function(data){$('#fviews').html(data)})}jwplayer().onReady(function(){});"
#    jwplayer("vplayer").setup({sources:[{file:"https://cn3.datoporn.co/hls/,3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7elfnv2xmq,.urlset/master.m3u8"},{file:"https://cn3.datoporn.co/dash/,3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7elfnv2xmq,.urlset/manifest.mpd"},{file:"https://cn3.datoporn.co/3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7elfnv2xmq/.mp4",label:"720p"}],image:"https://cn3.datoporn.co//01/00496/bqtkjq2dj5mn.jpg",width:"100%",height:"100%",stretching:"",duration:"2081.79",preload:'none',androidhls:"true",hlshtml:"true",primary:"html5",startparam:"start",tracks:[],dash:true,title:"BigTitsRoundAsses  07 04 Lena Paul XXX 1080p",displaytitle:true,abouttext:"",aboutlink:"https://datoporn.co"});var vvplay,vvad,x2ok=;jwplayer().onTime(function(){if(>&&.position>=&&vvad!=){vvad=;$('div.video_ad_fadein').fadeIn('slow')}if(x2ok==&&.position>=104&&.position<=(104+)){x2ok=.position}});jwplayer().onPlay(function(){doPlay()});jwplayer().onComplete(function(){$('div.video_ad').show()});function doPlay(){$('div.video_ad').hide();if(vvplay)return;vvplay=;adb=;if(window.cRAds===undefined){adb=}$.get('https://datoporn.co/dl?op=view&file_code=bqtkjq2dj5mn&hash=2484626-216-154-1562430949-14e5d30086336965d1d4d856618b4226&embed=&adb='+adb,function(data){$('#fviews').html(data)})}jwplayer().onReady(function(){});

#    p='8("2s").2r({2q:[{k:"7://d.6.4/2p/,j,.s/2o.2n"},{k:"7://d.6.4/q/,j,.s/2m.2l"},{k:"7://d.6.4/j/v.2k",2j:"2i"}],2h:"7://d.6.4/i/2g/2f/m.2e",2d:"r%",2c:"r%",2b:"",2a:"29.28",27:\'26\',25:"c",24:"c",23:"22",21:"20",1z:[],q:c,1y:"1x 19 1w 1v 1u 1t 1s 1r",1q:c,1p:"",1o:"7://6.4"});1n e,h,g=0;8().1m(3(x){a(5>0&&x.b>=5&&h!=1){h=1;$(\'f.1l\').1k(\'1j\')}a(g==0&&x.b>=p&&x.b<=(p+2)){g=x.b}});8().1i(3(x){o(x)});8().1h(3(){$(\'f.n\').1g()});3 o(x){$(\'f.n\').1f();a(e)1e;e=1;9=0;a(1d.1c===1b){9=1}$.1a(\'7://6.4/18?17=16&15=m&14=13-12-11-10-z&y=1&9=\'+9,3(l){$(\'#w\').u(l)})}8().t(3(){});'
#    a =, 36
#    c=, 101
#    k =, '|||function|co||datoporn|https|jwplayer|adb|if|position|true|cn3|vvplay|div|x2ok|vvad||3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7elfnv2xmq|file|data|bqtkjq2dj5mn|video_ad|doPlay|104|dash|100|urlset|onReady|html||fviews||embed|14e5d30086336965d1d4d856618b4226|1562430949|154|216|2484626|hash|file_code|view|op|dl||get|undefined|cRAds|window|return|hide|show|onComplete|onPlay|slow|fadeIn|video_ad_fadein|onTime|var|aboutlink|abouttext|displaytitle|1080p|XXX|Paul|Lena|04|07|BigTitsRoundAsses|title|tracks|start|startparam|html5|primary|hlshtml|androidhls|none|preload|79|2081|duration|stretching|height|width|jpg|00496|01|image|720p|label|mp4|mpd|manifest|m3u8|master|hls|sources|setup|vplayer'.split('|')))
#        ('8("2s").2r({2q:[{k:"7://d.6.4/2p/,j,.s/2o.2n"}
#,{k:"7://d.6.4/q/,j,.s/2m.2l"},{k:"7://d.6.4/j/v.2k",2j:"2i"}]
#,2h:"7://d.6.4/i/2g/2f/m.2e",2d:"r%",2c:"r%",2b:""
#,2a:"29.28",27:\'26\',25:"c",24:"c",23:"22",21:"20",1z:[],q:c
#,1y:"1x 19 1w 1v 1u 1t 1s 1r",1q:c,1p:"",1o:"7://6.4"});
#1n e,h,g=0;8().1m(3(x){a(5>0&&x.b>=5&&h!=1){h=1;$(\'f.1l\').1k(\'1j\')}a(g==0&&x.b>=p&&x.b<=(p+2)){g=x.b}})
#;8().1i(3(x){o(x)});8().1h(3(){$(\'f.n\').1g()});3 o(x){$(\'f.n\').1f()
#;a(e)1e;e=1;9=0;a(1d.1c===1b){9=1}$.1a(\'7://6.4/18?17=16&15=m&14=13-12-11-10-z&y=1&9=\'+9,3(l){$(\'#w\').u(l)})}8().t(3(){});',36,101,
#'|||function|co||datoporn|https|jwplayer|adb|if|position|true|cn3|vvplay|div|x2ok|vvad||3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7ddefv2xmq|file|data|bqtkjq2dj5mn|video_ad|doPlay|104|dash|100|urlset|onReady|html||fviews||embed|badc5ab5387c0db45e2d4807e8aa74a0|1562430193|154|216|2484626|hash|file_code|view|op|dl||get|undefined|cRAds|window|return|hide|show|onComplete|onPlay|slow|fadeIn|video_ad_fadein|onTime|var|aboutlink|abouttext|displaytitle|1080p|XXX|Paul|Lena|04|07|BigTitsRoundAsses|title|tracks|start|startparam|html5|primary|hlshtml|androidhls|none|preload|79|2081|duration|stretching|height|width|jpg|00496|01|image|720p|label|mp4|mpd|manifest|m3u8|master|hls|sources|setup|vplayer'.split('|')))



@url_dispatcher.register(ROOT_TEST_ALL)
def TEST_ALL():

    prev_search_string = this_addon.getSetting(id='quick_search_string')
    quick_search_string = _get_keyboard( heading="Search query", default=prev_search_string  )
    if  quick_search_string == '' :
        return False, 0  ## if blank or the user cancelled the keyboard, return
    this_addon.setSetting(id='quick_search_string', value=quick_search_string)

    import importlib

    #generate list of potential test sites by listing dir
    libDir = os.path.join(resDir, 'lib')
    sitesDir = os.path.join(libDir, 'sites')
    files = []
    # r=root, d=directories, f = files
    for r, d, f in os.walk(sitesDir):
        for file in f:
            #Log("file='{}'".format(file))
            if file.endswith('.py') and not file.startswith('_') :
                f2 = file[:-len('.py')]
                #Log("file='{}'".format(f2))
                files.append(f2)

    #add them to settings file if they are not already there
    something_changed = False
    import json
    TESTING_LIST_NAME = 'test_list'
    test_list = this_addon.getSetting(id=TESTING_LIST_NAME)
    if test_list == "": 
        test_list = json.loads("{}")
        this_addon.setSetting(id=TESTING_LIST_NAME, value=json.dumps(test_list))
        something_changed = True
    else:
        test_list = json.loads(test_list)
    #Log("test_list='{}'".format(test_list))

    for f in files:
        if not f in test_list:
            Log("added f='{}'".format(f))
            test_list[f] = ''
            something_changed = True
    if something_changed == True:
        this_addon.setSetting(id=TESTING_LIST_NAME, value=json.dumps(test_list))
    

    #remove any settings file items if not in listing dir
    something_changed = False
    things_to_delete = {}
    for key in test_list.keys():
        if not key in files:
            #Log('will be removing' + key)
            things_to_delete[key] = key
    for key in things_to_delete:
        Log("removing key='{}'".format(key))
        del test_list[key]
        something_changed = True
    if something_changed == True:
        this_addon.setSetting(id=TESTING_LIST_NAME, value=json.dumps(test_list))


    #temporarilty force only  X   recurse depth for this feature
    DEFAULT_RECURSE_DEPTH = 1
    MAX_RECURSE_DEPTH = 3
    
    #in the order of of settings file items, if not passed test today, perform test
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    something_changed = False
    something_failed = False
    for test_candidate in test_list:
        Log("test_list[{}]='{}'".format(test_candidate, test_list[test_candidate])) 
        if test_list[test_candidate] < today:
            
            try:
                sitename = test_candidate
                module = importlib.import_module('resources.lib.sites.'+sitename)
                method_to_call = getattr(module, 'Test')
                result = method_to_call(quick_search_string)
                Log('passed test for {}'.format(sitename), xbmc.LOGWARNING)
                test_list[test_candidate] = today
                something_changed = True
                this_addon.setSetting(id=TESTING_LIST_NAME, value=json.dumps(test_list))
                
            except:
                traceback.print_exc()
                addDownLink(
                    name="[COLOR {}]{}[/COLOR]".format('orange', 'failed {}'.format(sitename))
                    ,url='httpsomething'
                    ,mode=1
                    ,iconimage='')
                something_failed = True
                ## stop if we have an error
                #Notify(msg='failed {}'.format(sitename), duration=500, sound=True)
                #add_sort_method()
                #endOfDirectory()
                #return

    if not something_failed:
        addDownLink(
                name="[COLOR {}]{}[/COLOR]".format('green', 'all tests passed on {}'.format(today))
                ,url='httpsomething'
                ,mode=1
                ,iconimage='')
    
    add_sort_method()
    endOfDirectory()
    return

    #if test passes, remove settings file item, add to end of list + date, save settings
    #stop when nothing has changed

def Sleep (time):
    while time > 0 and not xbmc.abortRequested:
        xbmc.sleep( min(1000, time) )
        time = time - 1000

def get_set(genset,n):
    nd=genset.getElementsByTagName(n)[0]
    #Log("get_set='{}'".format(nd))
    if nd.lastChild is None:
        #Log("  {}='{}'".format(n,nd.lastChild))
        return nd.lastChild
    else:
        #Log("  {}='{}'".format(n,nd.lastChild.data))
        return nd.lastChild.data

def Socks_Proxy_Active():
    
    from xml.dom import minidom
    gen_set=minidom.parse(xbmc.translatePath('special://home/userdata/guisettings.xml'))
    uhp = get_set(gen_set,"usehttpproxy")
    uhp = uhp.lower()=='true'
    if uhp:
##        Log("a proxy is enabled='{} with value='{}''".format(uhp, int(get_set(gen_set,"httpproxytype")) ))
        #return {'uhp': int(get_set(gen_set,"httpproxytype"))==4  or int(get_set(gen_set,"httpproxytype"))==5  or int(get_set(gen_set,"httpproxytype"))==0
        return {'uhp': int(get_set(gen_set,"httpproxytype"))
                , 'ps': get_set(gen_set,"httpproxyserver")
                , 'pp': int(get_set(gen_set,"httpproxyport"))
                , 'un': get_set(gen_set,"httpproxyusername")
                , 'up': get_set(gen_set,"httpproxypassword")
                }
    else:
        return {'uhp':-1, 'ps':None, 'pp':None, 'un':None, 'up':None}

def RandomNumber(return_integer=True,length=18):
    import random
    nc_string = str(random.random())
    if return_integer:
        nc_string = nc_string.split('.')[1]
    while len(nc_string) < length:
        nc_string += str(random.randint(10,99))    
    return nc_string

def SetCookie_To_Array_Of_Cookie(set_cookie_string):
##    Log("set_cookie_string='{}'".format(set_cookie_string))
    cookies_array = []
    #regex = "(?is)(\s?expires=\w\w\w,\s\d\d-\w\w\w-\d{2,4}\s\d{1,2}:\d\d:\d\d(?:\s?\w{3})?;?)"
    regex = "(\s?expires=(.{27,29})(?:;|,)?)"
    regex = "(\s?expires=([^;]+)(?:;|$)?)"
    
    set_cookie_string_no_expires = re.sub(regex,'',set_cookie_string, flags=re.IGNORECASE)
##    Log("set_cookie_string_no_expires='{}'".format(set_cookie_string_no_expires))
##    return cookies_array
    #https://docs.python.org/2/library/cookielib.html#cookielib.Cookie.is_expired
    for cook in set_cookie_string_no_expires.split(', '):
        if cook == '': break #in case blank cookie
##        Log("cook='{}'".format(repr(cook)))
        morsels = None
        name=None
        value=None
        port=None
        port_specified=False
        domain=''
        domain_specified=False
        domain_initial_dot=False
        path=''
        path_specified=False
        max_age=None
        expire_date=None
        comment=None
        comment_url=None
        discard=False #True if this is a session cookie
        secure=True #True if cookie should only be returned over a secure connection
        for morsel in cook.split('; '):
##            morsel=morsel.rstrip(';') #in case a cookie has only name/value
##            Log("morsel='{}'".format(repr(morsel)))

            if not '=' in morsel:
                ##single word value
                pass ##I am ignoring these ones
            
            else:
                #morsels = morsel.split("=")
                morsels=[morsel[0: morsel.find("=")] , morsel[morsel.find("=")+len("="): (max(morsel.find(";"), len(morsel)))      ] ]
##                Log(str(morsel.find("=")+len("=")))
##                Log(str(morsel.find(";")))
##                Log(str(max(morsel.find(";"), len(morsel))))
                #Log("morsels='{}'".format(repr(morsels)))
                if morsels[0].lower() == 'path':
                    path=morsels[1]
                    path_specified=True
                elif morsels[0].lower() == 'max-age':
                    max_age=morsels[1] #essentially same info as expires; written as seconds(from now, presumably)which means cookie is only good for current session
##                    Log("morsel='{}'".format(repr(morsel)))
##                    Log("morsels[1]='{}'".format(morsels[1]))
##                    Log("max_age='{}'".format(max_age))
                    max_age=int(max_age)
                elif morsels[0].lower() == 'domain':
                    domain=morsels[1]
                    domain_specified=True
                    if domain[0]=='.': domain_initial_dot = True
                elif morsels[0].lower() == 'port':
                    port=morsels[1]
                    port_specified=True
                elif morsels[0].lower() == 'comment':
                    comment=morsels[1]
                elif morsels[0].lower() == 'samesite':
                    pass
                elif morsels[0].lower() == 'comment_url':
                    comment_url=morsels[1]
                else:
                    name=morsels[0]
                    value=morsels[1]
                    regex = "{}={};?.*?expires=([^;]+)".format(re.escape(name),re.escape(value))
##                    Log(regex) 
                    try:
                        expire_date_arr= re.compile(regex, re.DOTALL | re.IGNORECASE).findall(set_cookie_string)
                        if len(expire_date_arr)<1:
                            #discard=True
                            Log("Cant find exipre date for regex='{}'".format(regex))
                            Log("morsel='{}'".format(morsel))
                            Log("name='{}'".format(name))
                            Log("value='{}'".format(value))
                            Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
                            Log("cook='{}'".format(cook))
                            Log("set_cookie_string='{}'".format(set_cookie_string))
                            Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))

                        else:
                            expire_date = expire_date_arr[0]
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("(type(datetime.datetime.now())='{}'".format(type(datetime.datetime.now())))
##                            Log("{}".format(datetime.datetime(1970,1,1).strftime("%a, %d %b %Y %H:%M:%S %Z")))
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("expire_date='{}'".format(expire_date))

                            expire_formats = {"%a, %d-%b-%Y %H:%M:%S %Z"
                                              , "%a, %d-%b-%y %H:%M:%S %Z"
                                              , "%a, %d %b %Y %H:%M:%S %Z"
                                              , "%a, %d %b %y %H:%M:%S %Z" }
                            for expire_format in expire_formats:
                                try:
                                    expire_date = datetime.datetime.strptime(expire_date, expire_format)
##                                    Log("morsel='{}'".format(morsel))
##                                    Log("Match on {}".format(expire_format)) 
                                    expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
##                                    Log("expire_date='{}' type={}".format(expire_date,type(expire_date)))  
                                    break
                                except TypeError:
##                                    Log("TypeError") 
                                    try:
                                        expire_date = datetime.datetime(*(time.strptime(expire_date, expire_format)[0:6]))
##                                      Log("Match on {} with bugfix ".format(expire_format)) 
                                        expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
                                        break
                                    except:
##                                        traceback.print_exc()
                                        pass
                                    
                                except:
##                                    traceback.print_exc()
                                    pass
                                
##                                Log("(type(expire_date)='{}'".format(type(expire_date)))
##                                if type(expire_date) == "<type 'datetime.datetime'>":

##                            Log("final (type(expire_date)='{}'".format(type(expire_date)))
##                            Log("final expire_date='{}'".format(expire_date))
                            if not (type(expire_date) == type(0)):
                                Log("Failed to convert expire_date='{}' using format '{}'".format(expire_date,expire_format))  
##                                Log("expire_date='{}'".format(expire_date))  
##                                Log("morsel='{}'".format(repr(morsel)))
##                                Log("name='{}'".format(repr(name)))
##                                Log("value='{}'".format(repr(value)))
##                                Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                                Log("cook='{}'".format(cook))
##                                Log("set_cookie_string='{}'".format(set_cookie_string))
##                                Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                                expire_date = 0
                                

                    except:
                        traceback.print_exc()
                        Log("Error parsing expire value for cookie")
                        Log("name='{}'".format(repr(name)))
                        Log("value='{}'".format(repr(value)))
                        Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
                        Log("cook='{}'".format(cook))
                        Log("set_cookie_string='{}'".format(set_cookie_string))
                        Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                        if expire_date: #might have been set by maxage
                            expire_date = 0
                        pass
                    
        if max_age:
            expire_date = max_age
            
##        discard=(isinstance(expire_date, int))
        
        ck = cookielib.Cookie(version=0,
                      name=name,
                      value=value,
                      port=port,
                      port_specified=port_specified,
                      domain=domain,
                      domain_specified=domain_specified,
                      domain_initial_dot=domain_initial_dot,
                      path=path,
                      path_specified=path_specified,
                      secure=secure,
                      expires=expire_date,
                      discard=discard,
                      comment=comment,
                      comment_url=comment_url,
                      rest={},
                      rfc2109=False)
##        Log("cook='{}'".format(repr(cook)))
##        Log("ck='{}'".format(repr(ck)))
        cookies_array.append(ck)

    #Log("cookies_array='{}'".format(cookies_array))
                
    return cookies_array

##set_cookie_string=""
#####set_cookie_string="__cfduid=d67377f30463115c667045bf55bec89511600712553;"
#####set_cookie_string="__cfduid=d67377f30463115c667045bf55bec89511600712553"
##set_cookie_string="__cfduid=d67377f30463115c667045bf55bec89511600712553; expires=Wed, 21-Oct-20 18:22:33 GMT; path=/; domain=.chaturbate.com; HttpOnly; SameSite=Lax, csrftoken=dzRg4rY4J2nzHqMVQFy3iqbSEh2RmPhG20kQrZbjUg2txLaV7qvUTmxYmBKm2D28; expires=Mon, 20-Sep-2021 18:22:33 GMT; Max-Age=31449600; Path=/; secure, stcki=\"GkUUZp=1\0547bERd5=0\054jV5-cv=0\"; expires=Wed, 21-Oct-2020 18:22:33 GMT; Max-Age=2592000; Path=/, affkey=eJyrVipSslJQyigpKSi20tdPzkgsKS1KSixJ1UvOz1WqBQChoAqo; Domain=.chaturbate.com; expires=Wed, 21-Oct-2020 18:22:33 GMT; Max-Age=2592000; Path=/, sbr=\"sec:sbr253c4af5-16a7-4d59-8371-7aeb1ea008cb:1kKQSP:6S1BqcW8iowFJUpsT7r3XvnmRmA\"; expires=Sat, 17-Jun-2023 18:22:33 GMT; httponly; Max-Age=86313600; Path=/; secure, dwf_s_a=False; expires=Wed, 21-Oct-2020 18:22:33 GMT; Max-Age=2592000; Path=/; secure, __cf_bm=330e4815263f477416480d94cab94137c2a67eac-1600712553-1800-AT79Mn5w5b4/yTMb/VitIh5d/3fnq2eBb7UlTxISBv51H5U81eT8ZBCh2r9AOf+c4cFecX8tg3ibxZDFxPQhk+8=; path=/; expires=Mon, 21-Sep-20 18:52:33 GMT; domain=.chaturbate.com; HttpOnly; Secure; SameSite=None"
####from dateutil.parser import parse
####dtetime = parse('2018-06-29 22:21:41')
####Log("dtetime='{}'".format(dtetime))
####
####set_cookie_string='sid=2631949386060939264; path=/; expires=Tue, 31-Dec-2030 12:00:00 GMT; domain=.youporn.com, yp-device=pc; path=/; expires=Thu, 24 Sep 2020 20:46:24 GMT; domain=.youporn.com, country=CA; path=/; expires=Sat, 18 Sep 2021 20:46:24 GMT; domain=.youporn.com, referer_params=; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/; SameSite=Lax'
##set_cookie_string='__cfduid=de1de3ed642597622a054e9fd6cb5b19e1601068557; expires=Sun, 25-Oct-20 21:15:57 GMT; path=/; domain=.htstreaming.com; HttpOnly; SameSite=Lax, PHPSESSID=98ku7bfl0radnh8aig1vstv516; path=/'
##set_cookie_string='__cfduid=d2a1fd954be188caa5e1d2b483be728321601121596; expires=Mon, 26-Oct-20 11:59:56 GMT; path=/; domain=.chaturbate.com; HttpOnly; SameSite=Lax, affkey=eJyrVipSslJQyigpKSi20tdPzkgsKS1KSixJ1UvOz1WqBQChoAqo; Domain=.chaturbate.com; expires=Mon, 26-Oct-2020 11:59:56 GMT; Max-Age=2592000; Path=/, sbr="sec:sbr5e42f88d-cbd6-4e15-8c95-aac7032fbff5:1kM8rs:mMlQtnh2aDWs7EGvAAzIjMMAvHk"; expires=Thu, 22-Jun-2023 11:59:56 GMT; httponly; Max-Age=86313600; Path=/; secure, tbu__k_______=; expires=Thu, 01-Jan-1970 00:00:00 GMT; Max-Age=0; Path=/, tipvol=20; expires=Wed, 25-Nov-2020 04:59:56 GMT; Max-Age=5158800; Path=/, csrftoken=jzzLB7RXK7vYahklMYakb79k5OV7cosupiEYKTCp0ZUKhaeUq4EfBQrbYqR8TS1Q; expires=Sat, 25-Sep-2021 11:59:56 GMT; Max-Age=31449600; Path=/; secure, stcki="ozRbDm=0\054i8mSBi=0\054F66dxQ=0\054s0siAv=1"; expires=Mon, 26-Oct-2020 11:59:56 GMT; Max-Age=2592000; Path=/, dwf_s_a=True; expires=Mon, 26-Oct-2020 11:59:56 GMT; Max-Age=2592000; Path=/; secure, __cf_bm=27dca7f410abbcb29b14eb953a7a791c5ae81361-1601121596-1800-AftPlub44jS/AeBph998x6wrkXqPPI+Rr9xBuIvcrky1W4DVR/e3cSGYA8qSXezeiHWbbjMzQLNp0xmmsuskzwo=; path=/; expires=Sat, 26-Sep-20 12:29:56 GMT; domain=.chaturbate.com; HttpOnly; Secure'
##set_cookie_string='visid=a03374ecb4ed87943a4e1aa0076821f0; expires=Tue, 14-Oct-2025 18:40:09 GMT; path=/; domain=pornone.com, ismobile=3; expires=Fri, 15-Oct-2021 18:40:09 GMT; path=/; domain=pornone.com, sr=a%3A1%3A%7Bs%3A13%3A%22blake+blossom%22%3Bi%3A1%3B%7D; expires=Sat, 16-Oct-2021 00:28:55 GMT'
##cookies_array=SetCookie_To_Array_Of_Cookie(set_cookie_string)
##for cookie in cookies_array:
##    Log("cookie='{}'".format(repr(cookie)))
##    cj.set_cookie(cookie)
##cj.save(cookiePath, ignore_expires=True, ignore_discard=True)



    
##gounlimited_src ="<script type='text/javascript'>eval(function(p,a,c,k,e,d){while(c--)if(k[c])p=p.replace(new RegExp('\\b'+c.toString(a)+'\\b','g'),k[c]);return p}('p 8=2f 7.2e({2d:[\"c://2c.b.a/2b/v.2a\"],29:\'28\',27:\"c://26.b.a/25/24/23/k.22\",21:\"s%\",20:\"s%\",1z:q,1y:\"#1x\",1w:{1v:3(){},},1u:{1t:[],1s:{1r:1q,1p:1o*r*r,1n:1m,1l:q}}});p d,i,h=0;8.g(7.f.1k,3(x){6(5>0&&x.9>=5&&i!=1){i=1;$(\'e.1j\').1i(\'1h\')}6(h==0&&x.9>=o&&x.9<=(o+2)){h=x.9}});8.g(7.f.1g,3(){n()});8.g(7.f.1f,3(){$(\'e.m\').1e()});3 n(){$(\'e.m\').l();$(\'#1d\').l();6(d)1c;d=1;4=0;6(1b.1a===19){4=1}$.18(\'c://b.a/17?16=15&14=k&13=12-11-10-z-y&w=1&4=\'+4,3(j){$(\'#u\').t(j)})}',36,88,'|||function|adb||if|Clappr|player|current|to|gounlimited|https|vvplay|div|Events|on|x2ok|vvad|data|qpr3zy5ot5k7|hide|video_ad|doPlay|31|var|true|1024|100|html|fviews||embed||166397cb53abe9b6082daf9272a55a09|1574387010|119|75|6453636|hash|file_code|view|op|dl|get|undefined|cRAds|window|return|over_player_msg|show|PLAYER_ENDED|PLAYER_PLAY|slow|fadeIn|video_ad_fadein|PLAYER_TIMEUPDATE|capLevelToPlayerSize|600|maxMaxBufferLength|60|maxBufferSize|30|maxBufferLength|hlsjsConfig|externalTracks|playback|onReady|events|vplayer|parentId|disableVideoTagContextMenu|height|width|jpg|01290|01|77|images|poster|none|preload|mp4|tea5vrzfn72qzxfffmlipntg5ygu5fp4n64xy6nl6jo34otvasbv3uhudpia|fs81|sources|Player|new'.split('|')))</script>"
##gounlimited_src ="<script type='text/javascript'>eval(function(p,a,c,k,e,d){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c]{p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('j 8=i(\"1c\");j l={P:\"m%\",O:\"m%\",N:\"16:9\",M:L,K:J,I:\"H\",G:\"F\",E:\"\",B:\"0://C.w.1/d/A=p-q-n\",r:{s:\"o\",u:\"5\",v:\"0://a.t.1/x/y\",},z:[{\"4\":\"0://b.2.1/6/3/R/c/\",\"h\":\"D\",\"e\":\"f/g\"},{\"4\":\"0://b.2.1/6/3/S/c/\",\"h\":\"1a\",\"e\":\"f/g\"},{\"4\":\"0://b.2.1/6/3/1g/c/\",\"h\":\"1d\",\"e\":\"f/g\"}],1i:1h,1f:{4:\"\",6:\"\",11:\"1b-U\",},V:{W:\"#X\",Y:\"14\",Z:\"T 10, 12 13\",15:\"\",}};8.17(l);8.19(\"0://k.2.1/Q/i/18/7.1m\",\"1e 1k\",1l(){1n.1j(\"0://k.2.1/7/3/\",\"1o\")},\"7\");',62,87,'https|com|ksplayer|aw8G4StVmo8VwIu|file||link|download|player|||cdn2|7c92fa40f8bf37ec5d9c5f34b82fede9||type|video|mp4|label|jwplayer|var|stream|config|100||vast|w1280|h720|advertising|client|adtng|skipoffset|tag|googleusercontent|get|10002711|sources|11JlDHTXrxFG7n2GfdEFFeJ492O6Jlua4|image|lh3|360P|aboutlink|Hi|abouttext|html5|primary|true|controls|false|autostart|aspectratio|height|width|templates|360|480|Trebuchet|left|captions|color|ffffff|fontSize|fontFamily|MS|position|Sans|Serif||backgroundColor||setup|assets|addButton|480P|top|video_player|720P|Download|logo|720|null|tracks|open|Video|function|svg|window|_blank'.split('|')))</script>"
###e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){
###gounlimited_src ="<script type='text/javascript'>eval(function(p,a,c,k,e,d){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('j 8=i(\"1c\");j l={P:\"m%\",O:\"m%\",N:\"16:9\",M:L,K:J,I:\"H\",G:\"F\",E:\"\",B:\"0://C.w.1/d/A=p-q-n\",r:{s:\"o\",u:\"5\",v:\"0://a.t.1/x/y\",},z:[{\"4\":\"0://b.2.1/6/3/R/c/\",\"h\":\"D\",\"e\":\"f/g\"},{\"4\":\"0://b.2.1/6/3/S/c/\",\"h\":\"1a\",\"e\":\"f/g\"},{\"4\":\"0://b.2.1/6/3/1g/c/\",\"h\":\"1d\",\"e\":\"f/g\"}],1i:1h,1f:{4:\"\",6:\"\",11:\"1b-U\",},V:{W:\"#X\",Y:\"14\",Z:\"T 10, 12 13\",15:\"\",}};8.17(l);8.19(\"0://k.2.1/Q/i/18/7.1m\",\"1e 1k\",1l(){1n.1j(\"0://k.2.1/7/3/\",\"1o\")},\"7\");',62,87,'https|com|ksplayer|aw8G4StVmo8VwIu|file||link|download|player|||cdn2|7c92fa40f8bf37ec5d9c5f34b82fede9||type|video|mp4|label|jwplayer|var|stream|config|100||vast|w1280|h720|advertising|client|adtng|skipoffset|tag|googleusercontent|get|10002711|sources|11JlDHTXrxFG7n2GfdEFFeJ492O6Jlua4|image|lh3|360P|aboutlink|Hi|abouttext|html5|primary|true|controls|false|autostart|aspectratio|height|width|templates|360|480|Trebuchet|left|captions|color|ffffff|fontSize|fontFamily|MS|position|Sans|Serif||backgroundColor||setup|assets|addButton|480P|top|video_player|720P|Download|logo|720|null|tracks|open|Video|function|svg|window|_blank'.split('|'))))</script>"
##gounlimited_src ="eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('j 8=i(\"1c\");j l={P:\"m%\",O:\"m%\",N:\"16:9\",M:L,K:J,I:\"H\",G:\"F\",E:\"\",B:\"0://C.w.1/d/A=p-q-n\",r:{s:\"o\",u:\"5\",v:\"0://a.t.1/x/y\",},z:[{\"4\":\"0://b.2.1/6/3/R/c/\",\"h\":\"D\",\"e\":\"f/g\"},{\"4\":\"0://b.2.1/6/3/S/c/\",\"h\":\"1a\",\"e\":\"f/g\"},{\"4\":\"0://b.2.1/6/3/1g/c/\",\"h\":\"1d\",\"e\":\"f/g\"}],1i:1h,1f:{4:\"\",6:\"\",11:\"1b-U\",},V:{W:\"#X\",Y:\"14\",Z:\"T 10, 12 13\",15:\"\",}};8.17(l);8.19(\"0://k.2.1/Q/i/18/7.1m\",\"1e 1k\",1l(){1n.1j(\"0://k.2.1/7/3/\",\"1o\")},\"7\");',62,87,'https|com|ksplayer|aw8G4StVmo8VwIu|file||link|download|player|||cdn2|7c92fa40f8bf37ec5d9c5f34b82fede9||type|video|mp4|label|jwplayer|var|stream|config|100||vast|w1280|h720|advertising|client|adtng|skipoffset|tag|googleusercontent|get|10002711|sources|11JlDHTXrxFG7n2GfdEFFeJ492O6Jlua4|image|lh3|360P|aboutlink|Hi|abouttext|html5|primary|true|controls|false|autostart|aspectratio|height|width|templates|360|480|Trebuchet|left|captions|color|ffffff|fontSize|fontFamily|MS|position|Sans|Serif||backgroundColor||setup|assets|addButton|480P|top|video_player|720P|Download|logo|720|null|tracks|open|Video|function|svg|window|_blank'.split('|'),0,{}))"
##source_js = unpack(gounlimited_src)
####regex = "\(p,a,c,k,e,d\).+?}\('(.*?),(\d+),(\d+),'(.*?)'"
####packed_src = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(gounlimited_src)
####if packed_src:
####    packed_src = packed_src[0]
####Log("packed_src='{}'".format(packed_src),xbmc.LOGNONE)
####p = packed_src[0]
####a = packed_src[1]
####c = packed_src[2]
####k = packed_src[3].split("|")
####        Log("p='{}'".format(p))
####        Log("a='{}'".format(a))
####        Log("c='{}'".format(c))
####        Log("k='{}'".format(k))
####source_js = dePacked(p,a,c,k,None,None)
##Log("source_js='{}'".format(source_js),xbmc.LOGNONE)


##aa = Socks_Proxy_Active()
##Log(aa)
##Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )


#              "L2dldF9maWxlLzIyLzNmZWFhNWY0NjlhOTZmМ2МwOTZkYWМwNmRjZjhkZmQ1NWЕzNGVlМzЕ2Zi8xNTg0NzАwМС8xNTg0NzQ5Ny8xNTg0NzQ5N19ocS5tcDQvP2Q9МjА3NСZicj0xNTЕmdGk9МTU3NjUyNjU4Мw~~"       


##Log( dhYas638H( u"L2dldF9maWxlLzIyLzNmZWFhNWY0NjlhOTZmМ2МwOTZkYWМwNmRjZjhkZmQ1МzlkNmYyZjQ5Ni8xNTg0NzАwМС8xNTg0NzQ5Ny8xNTg0NzQ5N19ocS5tcDQvP2Q9МjА3NСZicj0xNTЕmdGk9МTU3NjUyODg0Мw~~"
##              , u"АВСDЕFGHIJKLМNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,~"
##              , u"[^АВСЕМA-Za-z0-9\.\,\~]")
##    , xbmc.LOGNONE)

##Make_download_path('[COLOR hotpink]HQ[/COLOR] Catjira')
##Make_download_path('[COLOR yellow]MeggMilligun[/COLOR]')
##Make_download_path('they have no boundaries between real life and porn' )
##Make_download_path('Blonde Married Milf I pulled (part 3) BUSTED!!! [COLOR hotpink]hd[/COLOR]')

##getHtml("https://animeidhentai.com/" )
##import sucuri
###"S='Yz0nbU8zJy5jaGFyQXQoMikrIjVzdSIuc2xpY2UoMCwxKSArICIiICsiNHUiLmNoYXJBdCgwKSArICIiICtTdHJpbmcuZnJvbUNoYXJDb2RlKDB4MzgpICsgICcnICsnUjAnLnNsaWNlKDEsMikrU3RyaW5nLmZyb21DaGFyQ29kZSg1MikgKyAgJycgKycnKyc7dTc2Jy5zdWJzdHIoMywgMSkgKyAnJyArIApTdHJpbmcuZnJvbUNoYXJDb2RlKDU0KSArIFN0cmluZy5mcm9tQ2hhckNvZGUoNDgpICsgICcnICsgCiI1c3UiLnNsaWNlKDAsMSkgKyAiZXAiLmNoYXJBdCgwKSArICcxNicuc2xpY2UoMSwyKSsiIiArImIiLnNsaWNlKDAsMSkgKyAneTk0Jy5jaGFyQXQoMikrICcnICsgCiI4byIuY2hhckF0KDApICsgU3RyaW5nLmZyb21DaGFyQ29kZSg1MSkgKyAiZSIgKyAiYSIgKyAgJycgK1N0cmluZy5mcm9tQ2hhckNvZGUoNTcpICsgIjAiICsgImIiLnNsaWNlKDAsMSkgKyAiMCIgKyAgJycgKycnKyI3IiArICdqSjcnLmNoYXJBdCgyKSsgJycgKycnKyc5clQxJy5zdWJzdHIoMywgMSkgKyAnJyArIAondkc3Jy5jaGFyQXQoMikrICcnICsgClN0cmluZy5mcm9tQ2hhckNvZGUoNTYpICsgIjkiICsgIjciLnNsaWNlKDAsMSkgKyAiOXN1Y3VyIi5jaGFyQXQoMCkrIjgiLnNsaWNlKDAsMSkgKyAnNycgKyAgIiIgKycnO2RvY3VtZW50LmNvb2tpZT0ncycrJ3N1Jy5jaGFyQXQoMSkrJ2MnKyd1c3VjJy5jaGFyQXQoMCkrICdyJysnJysnc3VjdWknLmNoYXJBdCg0KSsgJ3N1Y3VyXycuY2hhckF0KDUpICsgJ2NzdScuY2hhckF0KDApICsnc3VjdXJsJy5jaGFyQXQoNSkgKyAnbycrJycrJ3UnKydkJysncHN1YycuY2hhckF0KDApKyAncnN1Jy5jaGFyQXQoMCkgKydvc3VjdScuY2hhckF0KDApICArJ3gnKycnKydzdWN1eScuY2hhckF0KDQpKyAnXycrJ3UnKydzdWN1cnUnLmNoYXJBdCg1KSArICdpJysnJysnZHN1Jy5jaGFyQXQoMCkgKydfc3VjdScuY2hhckF0KDApICArJ2EnLmNoYXJBdCgwKSsnYycrJ2QnKycxJysnMScrJzInKycwJysnczInLmNoYXJBdCgxKSsnc3VjdWUnLmNoYXJBdCg0KSsgIj0iICsgYyArICc7cGF0aD0vO21heC1hZ2U9ODY0MDAnOyBsb2NhdGlvbi5yZWxvYWQoKTs='"
##data = ("<noscript>Javascript is required. Please enable javascript before you are allowed to see this page.</noscript><script>var s={},u,c,U,r,i,l=0,a,e=eval,w=String.fromCharCode,sucuri_cloudproxy_js='',"
##        "S='cz0iMHN1Y3VyIi5jaGFyQXQoMCkrIiIgKyIzZSIuY2hhckF0KDApICsgIjRzZWMiLnN1YnN0cigwLDEpICsgICcnICsgCiJjbiIuY2hhckF0KDApICsgJ0dyVDQnLnN1YnN0cigzLCAxKSArJ2EnICsgICAnJyArJycrImJ0Ii5jaGFyQXQoMCkgKyAiYSIuc2xpY2UoMCwxKSArIFN0cmluZy5mcm9tQ2hhckNvZGUoMHgzMykgKyAiNHNlYyIuc3Vic3RyKDAsMSkgKyAnYycgKyAgJ2YnICsgICIiICsnZicgKyAgICcnICsiZnN1Y3VyIi5jaGFyQXQoMCkrJ1ZtWWYnLnN1YnN0cigzLCAxKSArIiIgKyIxIiArICAnJyArIAoiMXN1Ii5zbGljZSgwLDEpICsgIjhzdSIuc2xpY2UoMCwxKSArICAnJyArImVzdSIuc2xpY2UoMCwxKSArICJmIiArICcyJyArICAiNyIgKyAiIiArImJzZWMiLnN1YnN0cigwLDEpICsgIjMiICsgICcnICsnJysiYXEiLmNoYXJBdCgwKSArICIyc2VjIi5zdWJzdHIoMCwxKSArICAnJyArJycrJ2YnICsgICIxIiArICAnJyArJycrImZzZWMiLnN1YnN0cigwLDEpICsgJzQnICsgICI0IiArICAnJyArJycrIjFzdSIuc2xpY2UoMCwxKSArICcnO2RvY3VtZW50LmNvb2tpZT0nc3VjdXJpcycuY2hhckF0KDYpKyd1c3UnLmNoYXJBdCgwKSArJ2MnKyd1JysnJysnc3VyJy5jaGFyQXQoMikrJ2lzdWN1cicuY2hhckF0KDApKyAnXycrJycrJ2NzdWMnLmNoYXJBdCgwKSsgJ2wnKydvc3VjdScuY2hhckF0KDApICArJ3VzdWN1Jy5jaGFyQXQoMCkgICsnZCcrJ3BzdWMnLmNoYXJBdCgwKSsgJ3N1Y3VyJy5jaGFyQXQoNCkrICdvcycuY2hhckF0KDApKydzdXgnLmNoYXJBdCgyKSsneScrJycrJ18nKyd1Jy5jaGFyQXQoMCkrJ3N1Y3VyaXUnLmNoYXJBdCg2KSsnaScrJycrJ2QnKydzdWN1cmlfJy5jaGFyQXQoNikrJ2FzdWMnLmNoYXJBdCgwKSsgJzUnKyc4JysnYicrJ2YnKydjJy5jaGFyQXQoMCkrJzZzdWN1cmknLmNoYXJBdCgwKSArICdzdWN1OScuY2hhckF0KDQpKyAnN3N1Jy5jaGFyQXQoMCkgKyI9IiArIHMgKyAnO3BhdGg9LzttYXgtYWdlPTg2NDAwJzsgbG9jYXRpb24ucmVsb2FkKCk7'"
##        ";L=S.length;U=0;r='';var A='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';for(u=0;u<64;u++){s[A.charAt(u)]=u;}for(i=0;i<L;i++){c=s[S.charAt(i)];U=(U<<6)+c;l+=6;while(l>=8){((a=(U>>>(l-=8))&0xff)||(i<(L-2)))&&(r+=w(a));}}e(r);</script></html>'")
##sucuri.Set_Cookie(data,cj)
##    

##good vv
##https://www.fpo.xxx/get_file/10/7a00741a18c1b638a15d355b8d397323/192000/192420/192420_720p.mp4/?br=1884&rnd=1601391636051
##https://www.fpo.xxx/get_file/10/d8577832035aab9170633b58141a3d1c/192000/192420/192420_720p.mp4/?br=1884?rnd=9706728826888
##bad  ^^

##videourl='https://www.fpo.xxx/get_file/10/7a00741a18c1b638a15d355b8d397323/192000/192420/192420_720p.mp4/?br=1884'
##license_code='$309969210226426'
##Log("license_code='{}'".format(license_code) )
##fappy_salt = FaapySalt(license_code, "")
##Log("fappysalt='{}'".format(fappy_salt))
##old_fappy_code =  videourl.split('/')[5]
##Log("old_fappy_code='{}'".format(old_fappy_code))
##new_fappy_code = ConvertFaapyCode( old_fappy_code, fappy_salt)
##Log("new_fappy_code='{}'".format(new_fappy_code))
    
##
##import urllib2, ssl
##class NoRedirection(urllib2.HTTPErrorProcessor):
##    def http_response(self, request, response):
##        return response
##    https_response = http_response
##h = ""
##my_list=[]
##opener = urllib2.build_opener(NoRedirection, urllib2.HTTPCookieProcessor(cj))
##for a in DEFAULT_HEADERS:
##    opener.addheaders = [(a, DEFAULT_HEADERS[a]), ("Referer", "url" ) ]
##    my_list += (a, DEFAULT_HEADERS[a])
##    opener.addheader = {("Referer", "url" )}
##opener.addheaders = my_list
##Log("my_list.my_list={}".format(repr(my_list)))
##Log("opener.addheaders={}".format(repr(opener.addheaders)))
##Log("opener.addheader={}".format(repr(opener.addheader)))
##
    

