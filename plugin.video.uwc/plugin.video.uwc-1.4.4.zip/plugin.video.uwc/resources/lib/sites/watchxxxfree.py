'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://watchxxxfreeinhd.com"

SEARCH_URL = ROOT_URL + '/page/1/?s={}'

URL_CATEGORIES = ROOT_URL
URL_RECENT = ROOT_URL + '/page/{}/?filtre=date&cat=0'
URL_TOPRATED = ROOT_URL + "/top-rated-porn-videos/page/{}/"
URL_MOSTVIEWED = ROOT_URL + "/most-viewed-porn-videos/page/{}/"

MAIN_MODE = '10'
LIST_MODE =  '11'
PLAY_MODE = '12'
CATEGORIES_MODE = '13'
SEARCH_MODE = '14'

#__________________________________________________________________________
# 

##BASE_URL = "https://watchxxxfreeinhd.com/"
##SEARCH_URL = BASE_URL + "page/1/?s="

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        
    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    listhtml = utils.getHtml(list_url, '')
    if "nothing matched your search criteria" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}'".format(keyword)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        video_region = listhtml.split('id="center"')[1].split('class="pagination')[0]
    #Log("video_region={}".format(video_region))


    #
    # parse out list items
    #
    regex = 'src="([^"]+)".class="attachment-thumb_site.*?title="([^"]+)".*?<a href="([^"]+)".*?class="time-infos".*?>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for thumb, label, videourl, duration in info:
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in label: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("duration={}".format(duration))  #2019-07-08  site is not setting time info 
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb )


    #
    # next page items
    #
##    if not video_region == "" and 'div class="pagination' in listhtml:
##        next_page_html = listhtml.split('class="clear"></div>\n<div class="pagination"')[1]
##    else:
##        next_page_html = ""
    if '?s=' in list_url:
        next_page_regex = '<link rel="next" href="([^"]+)"'
    else:
        next_page_regex = 'href=\"([^\"]+)\">Next &rsaquo;</a>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            np_number=''
            if '/' in np_url:
                if not np_number.isdigit(): np_number=np_url.split('/')[4]
                if not np_number.isdigit(): np_number=np_url.split('/')[5]
                if not np_number.isdigit(): np_number=np_url.split('/')[6]
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(searchUrl, keyword=None, end_directory=True):

    if not keyword:
        utils.searchDir(searchUrl, SEARCH_MODE)
        return

    org_end_directory = end_directory
    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)

    end_directory = org_end_directory
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
