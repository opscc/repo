'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "http://xtasie.com"

SEARCH_URL = ROOT_URL + '/?s={}'

URL_CATEGORIES = ROOT_URL + '/video-porn-categories/'
URL_RECENT = ROOT_URL + "/porn-video-list/page/{}/"
URL_TOPRATED = ROOT_URL + "/top-rated-porn-videos/page/{}/"
URL_MOSTVIEWED = ROOT_URL + "/most-viewed-porn-videos/page/{}/"

MAIN_MODE = '200'
LIST_MODE =  '201'
PLAY_MODE = '202'
CATEGORIES_MODE = '203'
SEARCH_MODE = '204'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(
        name="[COLOR {}]Categories[/COLOR]".format( 
        utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE
        ,iconimage=utils.search_icon 
        )  
    utils.addDir(
        name="[COLOR {}]Top Rated[/COLOR]".format( 
        utils.search_text_color) 
        ,url=URL_TOPRATED
        ,mode=LIST_MODE
        ,iconimage=utils.search_icon
        ,page=1
        )
    utils.addDir(
        name="[COLOR {}]Most Viewed[/COLOR]".format( 
        utils.search_text_color) 
        ,url=URL_MOSTVIEWED
        ,mode=LIST_MODE
        ,iconimage=utils.search_icon
        ,page=1
        )    

    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):
    
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))
    
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    listhtml = utils.getHtml(list_url, ROOT_URL)
    if "NO SE HAN ENCONTRADO REGISTRO" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}'".format(keyword)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon 
            )
    else: #distinguish between adverts and videos
        video_region = listhtml.split('id="main"')[1].split('="ts-pagination')[0]


    #
    # main list items
    #
    videos_regex = '<div class=\"image-holder\">.+?<img.*?data-original=\"([^\"]+)\" alt=\"([^\"]+)\".+?.+?href=\"([^\"]+)\".*?>'
    info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(video_region)
#    Log("info='{}'".format(info))
    for thumb, label, videourl in info:

        #2019-07-09 dead links will not have a thumb;  and will be skipped by regex

        if '/4K)' in label:
            hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
            label = label.replace('/4K)',')')
        elif '/FULLHD)' in label:
            hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
            label = label.replace('/FULLHD)',')')
        elif '/HD)' in label:
            hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
            label = label.replace('/HD)',')')
        else: hd = ""
        
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        
        if videourl.startswith('/'): videourl = 'http:' + videourl
        if thumb.startswith('/'): thumb = 'http:' + thumb

        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb)
        

    #
    # next page items
    #
    if not video_region == "": 
        next_page_html = listhtml.split('="ts-pagination')[1]
    else:
        next_page_html = ""
    next_page_regex = '<a class="next page-numbers" href="([^"]+)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_number = '' #page number can be multiple places depending if search result or not
            if '/' in np_url:
                if not np_number.isdigit(): np_number=np_url.split('/')[4]
                if not np_number.isdigit(): np_number=np_url.split('/')[5]
                if not np_number.isdigit(): np_number=np_url.split('/')[6]
                if not np_number.isdigit(): np_number=np_url.split('/')[7]
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                if int(np_number) <= MAX_SEARCH_DEPTH: #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                else:
                    utils.add_sort_method()
                    utils.endOfDirectory()

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(searchUrl, keyword=None, end_directory=True):

    if not keyword:
        utils.searchDir(searchUrl, SEARCH_MODE)
        return

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=True
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):

    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, '')

    #cathtml = re.compile('"list-categories"(.*)class="footer-margin', re.DOTALL).findall(html)[0]

    regex = 'href=\"(.+?categories/[^\"]+)\".+?src=\"([^\"]+)\".+?<h2>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    for videourl, thumb, label in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        keyword = videourl.split('categories/')[1].split('/')[0]
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,keyword=keyword
            )
        
    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)

#__________________________________________________________________________
#
