'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import sys
import json
import re
import urllib
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://www.bitporno.com"

SEARCH_URL = ROOT_URL + '/?q={}&or=&cat=&sort=recent&time=someday&length=all&view=0&page={}'

URL_CATEGORIES = ROOT_URL + '/?q='
URL_RECENT = ROOT_URL + '/?q=&or=&cat=&time=someday&length=all&view=0&page={}'

MAIN_MODE       = '660'
LIST_MODE       = '661'
PLAY_MODE       = '662'
CATEGORIES_MODE = '663'
SEARCH_MODE     = '664'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon)
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and not(page == None):
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "Page Not Found" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}'".format(keyword)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            regex = 'id="search_results"(.+)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))



    #
    # parse out list items
    #
    regex = '<div class="[^"]*entry[^>]*>.*?((?:<div class="thumbnail-hd">HD</div>|))\s*<a class="[^"]+" href="([^"]+)"[^>]*>\s*<img src="([^"]+)"[^>]*>\s*</a>\s*<div[^>]*>(.+?)</div>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for hd, videourl, thumb, label  in info:
        #Log("label={}".format(label))
        #Log("hd={}".format(hd))
        label=label.replace('Serakon.com - Download movies porn', '')
        label=label.replace(' - VseX.in More videos porn - ', '')
        if   '2160' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif   'hd' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        
        thumb = thumb + utils.Header2pipestring() + "Referer=" + ROOT_URL
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label={}".format(label))
##        Log("duration={}".format(duration))
##        Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb )
            #, duration=duration )



    #
    # next page items
    #
    try:
        regex = 'id="search_results"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = '<a href="([^"]+)" class="pages">Next</a>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
#            Log("np_url.split('/')={}".format(np_url.split('/')))
            np_number = '' 
            if '/' in np_url: np_url = np_url.split('/')[-1]
            Log("np_url={}".format(np_url))
            if '?page=' in np_url: np_number = np_url.split('?page=')[1]
            if '&amp;page=' in np_url: np_number = np_url.split('&amp;page=')[1].split('&')[0]
#            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
            np_url = url
            Log("np_number={}".format(np_number))
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number))
            if end_directory == True:
                utils.addDir(
                    name=np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    #Log('int(sys.argv[1])={}'.format((sys.argv)))
    #return

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

##    org_end_directory = end_directory
##    if utils.addon.getSetting("force_recursive_search").lower() == "true":
##        end_directory=False

#https://www.bitporno.com/?q=lexi+belle&or=&cat=&sort=recent&time=someday&length=all&view=0&page=3&user=
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page='0', end_directory=end_directory, keyword=keyword)

##    end_directory = org_end_directory

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()


#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    source_html1 = utils.getHtml(url, ROOT_URL)
#    source_html1 = 'poster="https://www153.playercdn.net/thumb/1/190716/722G5251PIU4VIFNS3DVD.jpg" style="width:100%; height:600px;">        <source src="https://www179.playercdn.net/86/3/auiZXjjV3FCLyE0SR3F3ww/1563331841/190716/836G529SC862EZB0KSUHS.mp4" type="video/mp4" label="480p" data-res="480" selected="true" /><source src="https://www227.playercdn.net/87/3/24E418Xex8i_P3g2gW0zfQ/1563331841/190716/722G5252RL8LRJJXRFSAY.mp4" type="video/mp4" label="720p" data-res="720" /><source src="https://www50.playercdn.net/88/3/vnk42g1HQgFkLh6hlDm-eA/1563331841/190716/723G5253SIOB3F5L2R6JN.mp4" type="video/mp4" label="1080p" data-res="1080" /></video></div><div class="clear"></div>'
    description = name

    regex = '<source src="([^"]+)".+?label="([^"]+)"'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
    #Log("sources_list={}".format(sources_list))
    video_url = utils.SortVideos(sources_list,1)
    video_url = video_url.replace('\/','/') + utils.Header2pipestring() + '&Referer=' + url
                            
    Log("video_url={}".format(video_url))
        
    utils.playvid(video_url, name, download, description=description)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):

    listhtml = utils.getHtml(url)
    #Log("listhtml={}".format(listhtml))

    regex = '>Categories</span>(.+?)<div id="search_ajax"'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    #Log("listhtml={}".format(listhtml))
    
    regex = '<a href="([^"]+)">([^<]+)</a>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label   in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = utils.html_parser.unescape(videourl) + '&page={}'
        #Log("videourl={}".format(videourl))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page="1"
            ,iconimage=utils.search_icon)
        
    utils.add_sort_method()
    utils.endOfDirectory()
    
#__________________________________________________________________________
#
