'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES =  ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 10

ROOT_URL = "https://www.freeomovie.com"

SEARCH_URL = ROOT_URL + '/?s='

URL_CATEGORIES = ROOT_URL

MAIN_MODE   = '370'
LIST_MODE   = '371'
PLAY_MODE   = '372'
CAT_MODE    = '373'
SEARCH_MODE = '374'


@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CAT_MODE 
        ,iconimage=utils.search_icon )

    List(ROOT_URL)

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon )
        
    listhtml = utils.getHtml(url, url)

    regex = '<h2><a href="([^"]+)".*?title="([^"]+)">.+?<img src="([^"]+)".+? width="'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for url, label, thumb in info:
        label = utils.cleantext(label)
        #Log("label={}".format(label))
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = url 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , noDownload=False)
        


    next_page_regex = "class=\"nextpostslink\".+?href=\"([^\"]+)\""
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        #Log("np_info={}".format(np_info))
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            np_number = '' #page number can be multiple places depending if search result or not
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if not np_number.isdigit(): np_number=np_url.split('/')[6]
            if not np_number.isdigit(): np_number=np_url.split('/')[7]
            
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
            else:
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(np_url, end_directory)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()



@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):

    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(searchUrl, end_directory)
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        

@utils.url_dispatcher.register(CAT_MODE, ['url'])
def Categories(url):
    html = utils.getHtml(url, '')

    regex = "\"cat-item.+?href=\"([^\"]+)\".+?>([^<]+)<"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    Log("info='{}'".format(info))
    for url, label in info:
        #if url.startswith('/'): url = ROOT_URL + url
        #if thumb.startswith('/'): thumb = ROOT_URL + thumb
        #Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )

    utils.add_sort_method()
    utils.endOfDirectory()


@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])   
def Playvid(url, name, download=None):

    utils.PLAYVIDEO(url, name, download)
    return

    html_src = utils.getHtml(url, ROOT_URL)

    regex = "\(p,a,c,k,e,d\).+?}\('(.*?),(\d+),(\d+),'(.*?)'"
    packed_src = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html_src)
    if not packed_src:
        return
    else:
        packed_src = packed_src[0]

    #packed_src = "<script type='text/javascript'>eval(function(p,a,c,k,e,d){while(c--)if(k[c])p=p.replace(new RegExp('\\b'+c.toString(a)+'\\b','g'),k[c]);return p}('o 8=2g 7.2f({2e:[\"c://2d.b.a/2c/v.2b\"],2a:29\\',28:\"c://27.b.a/26/25/24/23.22\",21:\"r%\",20:\"r%\",1z:p,1y:\"#1x\",1w:{1v:3(){},},1u:{1t:[],1s:{1r:1q,1p:1o*q*q,1n:1m,1l:p}}});o d,i,h=0;8.g(7.f.1k,3(x){6(5>0&&x.9>=5&&i!=1){i=1;$(\\'e.1j\\').1i(\\'1h\\')}6(h==0&&x.9>=n&&x.9<=(n+2)){h=x.9}});8.g(7.f.1g,3(){m()});8.g(7.f.1f,3(){$(\\'e.l\\').1e()});3 m(){$(\\'e.l\\').k();$(\\'#1d\\').k();6(d)1c;d=1;4=0;6(1b.1a===19){4=1}$.18(\\'c://b.a/17?16=15&14=13&12=11-10-z-y-w&u=1&4=\\'+4,3(j){$(\\'#t\\').s(j)})}',36,89,'|||function|adb||if|Clappr|player|current|to|gounlimited|https|vvplay|div|Events|on|x2ok|vvad|data|hide|video_ad|doPlay|64|var|true|1024|100|html|fviews|embed||1ff457f06dc007f4637669a64e22af61||1563478049|154|216|2873469|hash|894rcx62vus4|file_code|view|op|dl|get|undefined|cRAds|window|return|over_player_msg|show|PLAYER_ENDED|PLAYER_PLAY|slow|fadeIn|video_ad_fadein|PLAYER_TIMEUPDATE|capLevelToPlayerSize|600|maxMaxBufferLength|60|maxBufferSize|30|maxBufferLength|hlsjsConfig|externalTracks|playback|onReady|events|vplayer|parentId|disableVideoTagContextMenu|height|width|jpg|ysnytu0j1hbi|00573|01|62|images|poster|none|preload|mp4|tea5upuee32qzxfffmqybptf6jrdklfcznx5v5rfmwwl3vslj3cufezdhb3q|fs66|sources|Player|new'.split('|')))"


    temp_esc_char = "@@@"
    packed_src = packed_src.replace("\\'", temp_esc_char)
##    Log("packed_src='{}'".format(packed_src))

    regex = "'([^\\']+)',(\d+),(\d+),'([^\\']+)'"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(packed_src)    
##    Log("info='{}'".format(info))
    for p, a, c, k in info:
        p = p.replace(temp_esc_char,"\'")
        k = k.split("|")
##        Log("p='{}'".format(p))
##        Log("a='{}'".format(a))
##        Log("c='{}'".format(c))
##        Log("k='{}'".format(k))
        source_js = utils.dePacked(p,a,c,k,None,None)
##        Log("source_js='{}'".format(source_js))
        regex = '{sources:\["([^"]+)"'
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_js)
        video_url = sources[0]
        Log("video_url='{}'".format(video_url))

        utils.playvid(video_url, name, download)
