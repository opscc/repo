'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import sys

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "http://www.poldertube.nl"

SEARCH_URL = ROOT_URL + '/pornofilms/zoeken/{}'

URL_RECENT = ROOT_URL + '/pornofilms/nieuw'
URL_CATEGORIES = ROOT_URL + '/categorieen'
URL_TOPRATED = ROOT_URL + '/ajax/best_rated/?page=1'

MAIN_MODE = '100'
LIST_MODE =  '101'
PLAY_MODE = '102'
CAT_MODE = '103'
SEARCH_MODE = '104'



@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CAT_MODE 
        ,iconimage=utils.search_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    listhtml = utils.getHtml(url, '')

    video_region = listhtml.split('//END Footer links')[0]

    regex = '<article([^>]*)>.*?href="([^"]+)".*?src="([^"]+)".*?<h3>([^<]+)<.*?duration">[^\d]+([^\s<]+)(?:\s|<)'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for hd, videourl, thumb, label, duration in info:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        duration = duration.replace(' min','s').replace(':','m ')
        #Log("hd={}".format(hd))
        #Log("videourl={}".format(videourl))
        #Log("label={}".format(label))
        #Log("thumb={}".format(thumb))
        #Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration
            , noDownload=False)



    next_page_regex ='<a href="([^"]+)" title="volgende '
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_number = np_url.split('/')[3]
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
            else:
                utils.Notify(msg=np_url, duration=500)  #let user know something is happening
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    List(np_url, end_directory)
                else:
                    utils.add_sort_method()
                    utils.endOfDirectory()    
                    

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        


@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
##@utils.url_dispatcher.register('102', ['url', 'name'], ['download'])
##def Play(url,name, download=None):
    videopage = utils.getHtml(url, '')
    videourl = re.compile('<source src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = videourl[0]
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:    
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)


@utils.url_dispatcher.register(CAT_MODE, ['url'])
def Categories(url):

    html = utils.getHtml(url, '')

    regex = '<div class="category".*?href="([^"]+)".*?<h2>([^<]+)<.*?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    Log("info='{}'".format(info))
    for url, label, thumb in info:
        if url.startswith('/'): url = ROOT_URL + url
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,Folder=True 
            )

    utils.add_sort_method()
    utils.endOfDirectory()


##@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
##def Search(url, keyword=None, end_directory=True):
##
##    searchUrl = url
##    if not keyword:
##        utils.searchDir(url, SEARCH_MODE)
##        return
##
##    end_directory=False #used when testing multipagesearch
##    
##    title = keyword.replace(' ','%20').replace('+','%20')
##    searchUrl = searchUrl.format(title)
##    Log("searchUrl='{}'".format(searchUrl))
##    List(searchUrl, end_directory)
##
##    end_directory=True #used when testing multipagesearch
##    
##    if end_directory == True:
##        utils.add_sort_method()
##        utils.endOfDirectory()
        

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    org_end_directory = end_directory
    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False

    keyword = keyword.replace(' ','%20').replace('+','%20')
    searchUrl = searchUrl.format(keyword)

    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)

    end_directory = org_end_directory

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

        
