'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://girlfriendvideos.com"

SEARCH_URL = ROOT_URL + '/search.fcgi?query={}'
#https://girlfriendvideos.com/search.fcgi?query=young+gf

URL_CATEGORIES = ROOT_URL + '/categories.php'
URL_RECENT = ROOT_URL + '/pages/index/{}.php'

MAIN_MODE       = '630'
LIST_MODE       = '631'
PLAY_MODE       = '632'
CATEGORIES_MODE = '633'
SEARCH_MODE     = '634'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon)
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url)#, send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "o matches found. Please try alternative se" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}'".format(keyword)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            #video_region = listhtml.split('<center><h1>')[1].split('&nbsp;Prev Page &nbsp;')[0]
            regex = '(?:<center><font size="5"><b>|<center><h1>)(.+)<br>\s<center><table class="contab"'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    #
    # parse out list items
    #
    regex = '<a href="(/content.+?php)" class="vtt">([^<]+)<.+?img src="([^"]+)".+?div class="vlen">.+?(\d+:\d+).+?<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, duration in info:
        #Log("label={}".format(label))
        #Log("hd={}".format(hd))
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in label: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not videourl.startswith('http'): videourl = ROOT_URL +  videourl
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        #thumb = thumb + "|Referer=" + list_url
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        #Log("duration={}".format(duration))
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration=duration )



    #
    # next page items
    #
    try:
        regex = '<br>\s<center><table class="contab"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = 'href="([^"]+)">Next Page'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
#            Log("np_url.split('/')={}".format(np_url.split('/')))
            np_number = '' 
            if '/' in np_url: np_url = np_url.split('/')[-1]
            if not np_number.isdigit(): np_number = np_url.split('.php')[0]
#            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
            np_url=url
            Log("np_number={}".format(np_number))
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number))
            if end_directory == True:
                utils.addDir(
                    name=np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    org_end_directory = end_directory
    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False

#https://girlfriendvideos.com/search.fcgi?query=young+gf
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    end_directory = org_end_directory

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    source_html1 = utils.getHtml(url, ROOT_URL)
#    source_html1 = ""
    description = name
    regex = "license_code: '(?P<lic>[^']+)'.+?video_url: 'function\/0\/(?P<vid>[^']+)"
    regex = 'href="(/videos/[^"]+)"'
##url=%s
##build=http://www.girlfriendvideos.com%s
		
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)[0]
    video_url = ROOT_URL + sources_list
                            
#    source_url_vars = source_url_vars[0]
#    Log("sources_list={}".format(sources_list))
#    video_url = utils.SortVideos(sources_list,0)
#    video_url = video_url.replace('\/','/') + utils.Header2pipestring() + '&Referer=' + url

##    json_sources = json.loads(source_url_vars)
##    Log("json_sources={}".format(json_sources))
##    Log("json_sources[quality_720p]={}".format(json_sources['quality_720p']))

##    if source_url_vars: #
##        2019 desktop version of page
##        #from: https://www.empflix.com/combine/tnaflix.desktop.js,flixplayer.desktop.js,lazyload.desktop.js,thumbplayer.desktop.js,tnaflix.desktop.channels.js,ws.js,suggest.js,dyn.js,textarea-caret-position.js,URL.js,tnaflix.desktop.notifications.js,perfect-scrollbar.js,sortable.js,flex-images.js,masonry.js,3be38.js,imagesloaded.js?1562849301
##        Log("source_url_vars={}".format(source_url_vars))
##        source_url_vars = source_url_vars[0]
##        source_url2 = "https://cdn-fck.empflix.com/empflix/"+source_url_vars[1] 
##        source_url2 += "-1.fid?key="+source_url_vars[3] 
##        source_url2 += "&VID="+source_url_vars[0]  
##        source_url2 += "&nomp4=1&catID=0&rollover=1&startThumb="+source_url_vars[2] 
##        source_url2 += "&embed=0&utm_source=0&multiview=0&premium=1&country=0user=0&vip=1&cd=0&ref=0&alpha"
##
##        Log("source_url2={}".format(source_url2))
##        source_html2 = utils.getHtml(source_url2, url)
##        regex = '<res>([^<]+).+?<videoLink><!\[CDATA\[([^\]]+)'
##        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
##        Log("sources_list={}".format(sources_list))
##        video_url = utils.SortVideos(sources_list,0)
##        video_url = utils.html_parser.unescape(video_url)
##        Log("video_url={}".format(video_url))
##        video_url = "https:" + video_url + utils.Header2pipestring() + '&Referer=' + url
##        
##    else: #2018 mobile version  if you use an ipad header, but then you are limited in vid resolution
##        regex = '"contentUrl" content="([^"]+)"'
##        source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
##        source_url2 = source_url2[0]
##        video_url = source_url2 + utils.Header2pipestring() + '&Referer=' + url
##
##        regex = 'flashvars.config = escape."([^ ]+)&VID='
##        source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)[0]
##        source_url2 = source_url2 + utils.Header2pipestring() + '&Referer=' + url
##        #Log("source_url2={}".format(source_url2))
##        source_html2 = utils.getHtml(source_url2, url)
##        regex = '<videoLink>(.+?)</videoLink>'
##        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
##        #Log("sources_list={}".format(sources_list))
##        video_url = sources_list[0]

    Log("video_url={}".format(video_url))
        
    utils.playvid(video_url, name, download, description=description)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):

    listhtml = utils.getHtml(url)

    regex = '<a href="(/pages/[^"]+/1.php)">([^"]+)</a>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label   in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = videourl.replace('/1.php', '/{}.php')
        #Log("videourl={}".format(videourl))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page="1"
            ,iconimage=utils.search_icon)
        
    utils.add_sort_method()
    utils.endOfDirectory()
    
#__________________________________________________________________________
#
