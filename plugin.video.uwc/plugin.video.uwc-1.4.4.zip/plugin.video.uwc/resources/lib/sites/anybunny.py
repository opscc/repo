'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "http://anybunny.com"

SEARCH_URL = ROOT_URL + '/top/{}'

URL_CATEGORIES = ROOT_URL
URL_TOP_RATED = ROOT_URL + '/top/'
URL_RECENT = ROOT_URL + '/new/'

MAIN_MODE = '320'
LIST_MODE =  '321'
PLAY_MODE = '322'
CATEGORIES_MODE = '323'
SEARCH_MODE = '324'
CHANNELS_MODE = '325'


#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(name="{}[COLOR {}]Top videos[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_TOP_RATED
        ,mode=LIST_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True
        )
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True
        )
    List(URL_RECENT, end_directory=True)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory', 'keyword'])
def List(url, end_directory=True, keyword=None):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    listhtml = utils.getHtml(url, '')
    if "did not match any " in listhtml:
        video_region = ""
        label = ""
        if keyword: label = "Nothing found for '{}'".format(keyword)
        utils.addDir(name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon 
            ,Folder=False
            )
    else:
        video_region = listhtml.split('class="main"')[1]
        video_region = video_region.split('class="divrectr"')[0]
 
    regex = "class='nuyrfe' href='([^']+)'.*?src='([^']+)'.*?alt='([^']+)'"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label in info:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , noDownload=False)
        

    next_page_html = listhtml #.split('class=linkscts')[1]
    next_page_regex = 'href="([^"]+)">Next '
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_number=np_url.split('=')[1]
            #if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            np_url=np_url.replace(" ","%20")
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
            else:
                utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                else:
                    utils.add_sort_method()
                    utils.endOfDirectory()

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Play(url, name, download=None):


    abpage = utils.getHtml(url, url)
    vartucurl = re.compile('<iframe.*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(abpage)[0]
    embedpage = utils.getHtml(vartucurl, url)
    scripturl = re.compile("src='([^']+)", re.DOTALL | re.IGNORECASE).findall(embedpage)[0]
    scripturl = "https://vartuc.com" + scripturl
    #videopage = utils.getHtml(scripturl, vartucurl, vartuchdr)
    videopage = utils.getHtml(scripturl, vartucurl)

    #https://azblowjobtube.com/kt_player/player.php?id=2806993&s=MhCqUdeCkqOCnPdNPuzxyA&ts=1561758799&ver=x HTTP/1.1
    #2019-06-28 site obfuskates code; i.e need to replace "'+ghbva+'" with "."
    video_url = re.compile("irue842=(.*?);uSS1Comp=", re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    Log("video_url={}".format(video_url))
    match = re.compile(r'(gh\w\w\w)="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    for repl, repl2 in match:
        video_url = video_url.replace("'+"+repl+"+'",repl2)
    Log("video_url={}".format(video_url))


    utils.playvideo(videosource=video_url, name=name, download=download, url=url)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):

    listhtml = utils.getHtml(url, '')
 
    regex = "<a href='/top/([^']+)'>.*?src='([^']+)' alt='([^']+)'"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, label) 
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = URL_RECENT + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
        utils.addDir(name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,Folder=True
            )
        
    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(searchUrl, keyword=None, end_directory=True):
    #Log("searchUrl='{}'".format(searchUrl))
    #Log("end_directory='{}'".format(end_directory))
    if not keyword:
        utils.searchDir(searchUrl, SEARCH_MODE)
        return

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False #used when testing multipagesearch

    title = keyword.replace('+',' ').replace(' ','_')
    searchUrl = searchUrl.format(title)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=True #used when testing multipagesearch
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

