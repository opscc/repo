'''
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import traceback
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]xHamster[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://xhamster.com"
#SEARCH_URL = ROOT_URL + '/search?q={}&p={}'
SEARCH_URL = ROOT_URL + '/search/{}?page={}'
##https://xhamster.com/search/sex?page=2
#https://xhamster.com/search/hazel+wowgirls?page=4
#URL_RECENT = ROOT_URL + '/videos/latest'
URL_RECENT = ROOT_URL + '/newest/{}'
URL_CATEGORIES = ROOT_URL + '/categories'

MAIN_MODE          = C.MAIN_MODE_xhamster
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

cookie = {'Cookie': 'lang=en; search_video=%7B%22sort%22%3A%22da%22%2C%22duration%22%3A%22%22%2C%22channels%22%3A%22%3B0.1.2%22%2C%22quality%22%3A0%2C%22date%22%3A%22%22%7D;'}

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , keyword = 'sex'
            )
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon)
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
def merge_two_dicts(x, y):
    z = x.copy()   # start with x's keys and values
    z.update(y)    # modifies z with y's keys and values & returns None
    return z
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(
        end_directory
        , keyword
        , SEARCH_URL
        , SEARCH_MODE
        , url
        , page)

    # read html
    listhtml = utils.getHtml(list_url
                             , referer=ROOT_URL
                             #, headers=merge_two_dicts(cookie, C.DEFAULT_HEADERS)
                             , ignore404=True
                             ) #cookie+C.headers
    if 'class="result-count">0</span>' in listhtml:
        video_region = ""
        next_page_html = ""
        listhtml = ''
    else:
        next_page_html = listhtml
        if 'div class="banner-mobile"' in listhtml:
            video_region = listhtml.split('div class="banner-mobile"')[1]
        else:
            video_region = listhtml

    #
    # parse out list items
    #
    #data-role="thumb-link"
    regex = ('thumb-image-container" (?:data-role="thumb-link" |)href="(?P<videourl>[^"]+)"'
             '.+?src="(?P<thumb>[^"]+)"'
             '.+?alt="(?P<label>[^"]+)">'
             '.+?(?P<hd>thumb-image-container__icon--uhd"|thumb-image-container__icon--hd"|thumb-image-container__icon")'
             '.+?span data-role-video-duration(?:="")?>(?P<duration>[^<]+)<'
             '(?P<desc>)'
             )
    regex = ('data-role="thumb-link" href="(?P<videourl>[^"]+)"'
             '.+?src="(?P<thumb>[^"]+)"'
             '.+?alt="(?P<label>[^"]+)"'
             '.+?(?P<hd>thumb-image-container__icon--uhd|thumb-image-container__icon--hd|thumb-image-container__icon)'
             '.+?span data-role="video-duration">(?P<duration>[^<]+)<'
             '(?P<desc>)'
             )
##    Log(regex)
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
##    Log('regex done')
    for videourl, thumb, label, hd, duration, desc in info:


        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        hd = utils.Normalize_HD_String(hd)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES
                                , C.html_parser.unescape(utils.cleantext(label))
                                , hd)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc = '\n' + ROOT_URL
            , duration = duration ) 
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    if (testmode == True) and (len(videourl) > 1):
        try:
            Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)
        except:
            traceback.print_exc()
    
    #
    # next page items
    #
    next_page_regex = ('class="xh-paginator-button\W*?active\W*"'
                       '.+?data-page="next" href="'
                       )
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_url = url
        np_number = int(page) + 1
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number 
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)                    
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    page_html = utils.getHtml(url, referer=ROOT_URL)
    #Log("page_html={}".format(page_html))
    regex = 'window.initials=(.*?)</script>'
    movies_html1 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(page_html)[0]
##    Log("movies_html1={}".format(movies_html1))



    regex_model = '"categories":(.*?),"(?:editable|reported)"'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).findall(movies_html1)
    description = ''
    desc_separator_char = '; '
    for json_model_source in source_models:
        json_sources = json.loads(json_model_source)
        for model in json_sources:
            if model['isPornstar'] == True:
                model = model['name']
##                Log(repr(model))
##                Log(repr(description))
                if model.lower() not in description.lower():
                    description = description + utils.cleantext(model) + desc_separator_char
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))
    

##    import ast
##    Log("movies_html={}".format(ast.literal_eval(movies_html)))
##    regex = '"sources":(.*?),"categories"' #we can't capture everyting here because parser does not like [] structure #worked 2020-05
    regex = '"sources":(.*?),"channelModel"' #we can't capture everyting here because parser does not like [] structure
    movies_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(movies_html1)[0]

##    Log("movies_html={}".format(movies_html))
##    import ast
##    Log("movies_html={}".format(ast.literal_eval(movies_html)))
    
    json_sources = json.loads(movies_html)
##    Log("json_urls={}".format(json_urls))
##    Log('json_urls["mp4"]={}'.format(json_urls["mp4"]))
##    Log(json_urls["mp4"]['720p'])
    list_key_value = {}
    for json_source in json_sources['mp4']:
        q = json_source
        v = json_sources['mp4'][json_source]
        if not v == "":
            list_key_value[q] = v
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )
    
    #we should have a url by now...
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(url, ROOT_URL))
        return

    #always set referrer so that 'kodi' does not appear on the target server
    if '|' not in video_url:
        headers = C.DEFAULT_HEADERS.copy()
        if url: headers['Referer'] = url
        video_url = video_url + utils.Header2pipestring(headers)

    #during testmode, only ensure that a url can be generated
    if testmode:
        Log("Would have played video_url; but in test mode")
        return

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile)
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    cathtml = utils.getHtml(url, '')
    cathtml = cathtml.split('class="letter-blocks page"')[1].split('<div class="search">')[0]

    regex = '<a href="([^"]+)" >([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label in info:
        thumb = C.search_icon
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("thumb={}".format(thumb))
        videourl = videourl + '/{}'
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace('+',' ').replace(' ','_')
    searchUrl = SEARCH_URL.format(keyword, '{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page) == '-1'))
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword, end_directory=True):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
