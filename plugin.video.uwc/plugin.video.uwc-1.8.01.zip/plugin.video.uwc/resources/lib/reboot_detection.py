import datetime,time
##import socket, platform, os
import subprocess
from resources.lib import constants as C
from resources.lib import utils
from resources.lib.utils import Log as Log

#__________________________________________________________________
#
def reboot_required_detection():

    last_reboot = C.addon.getSetting('last_reboot')
    try:
        last_reboot = datetime.datetime(*(time.strptime(last_reboot, "%Y-%m-%d")[0:6]))
    except:
        last_reboot = datetime.datetime(*(time.strptime("1980-12-2", "%Y-%m-%d")[0:6]))
        C.this_addon.setSetting(id='last_reboot', value=last_reboot.strftime("%Y-%m-%d"))
        
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    today = datetime.datetime(*(time.strptime(today, "%Y-%m-%d")[0:6]))
##    if not isinstance(last_reboot, datetime.date):
##        last_reboot = datetime.date(1980, 1, 1)
##        C.this_addon.setSetting(id='last_reboot', value=last_reboot.strftime("%Y-%m-%d"))

##    if (last_reboot >= today):
##        Log(repr((last_reboot,today)))
##        Log('already restarted today - skipping ping check', C.LOGNONE)
##    else:
    Log('begin check if network is working')
##    info = ('1.1.1.1',)
####        info = ('8.8.8.8',) 
##    param = '-n' if platform.system().lower()=='windows' else '-c'        
##    command = ['ping', param, '2', info[0]]
##    Log(repr(command))
##    result = (subprocess.call(command, stderr=subprocess.STDOUT, shell=True) == 0)
    result = utils.Is_Online()
##    result = False; Log("Warning: simulating result during a dev test")
##    Log(repr(result))
    if result: #"Received = 4" in response:
        Log("Is_Online() is true")#, C.LOGNONE)
    else:
        Log("Ping is false")#, C.LOGNONE)
        if (last_reboot >= today):  
##            Log(repr((last_reboot,today)))
            Log('already restarted today - notify only')
            utils.Notify(header="Network offline", msg="Manually restart ASAP", duration=15000, allow_all_thread_names=True)
        else:
            utils.Notify(header="Network offline", msg="Kodi will schedule computer restart", duration=30000, allow_all_thread_names=True)
            result = (subprocess.call("shutdown -r -t 120", shell=True) == 0)
            C.this_addon.setSetting(id='last_reboot', value=datetime.datetime.now().strftime("%Y-%m-%d"))
##        pass  
#__________________________________________________________________
#

##
##
##def Is_Online(server='1.1.1.1', port='80'):
##    
##    #use simplecache to store last time we did a network check
##    # ... works like a static var across all threads
##    last_online_check = utils.global_cache.get("last_online_check")
##    if last_online_check:
##        Log("skip Is_Online() Error to be more obvious on logs") #dev
####        return True
##    Log("1Is_Online()")
##    
##    ip = xbmc.getIPAddress() #in case we don't have IP
##    Log(repr(ip))
##    if (not ip) or ip.startswith('169.254'): # or ip.startswith('172.'):
##        Log("2 not IP ")
##        #return False
##
##    import socket
##    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
##    Log("3")
##    try:
##        s.connect((server, int(port)))
##        Log("4")
##    except socket.error as msg:
##        Log(repr(msg))
##        if msg.errno == 10051: #not reachable
##            s.close()
##        Log("6")
##        return False
##    finally:
##        s.close()
##
##    last_online_check = datetime.datetime.now()
##    utils.global_cache.set(
##        endpoint = "last_online_check" #(CACHE_STRING+url+str(page)+str(depth))
##        ,data = repr(datetime.datetime.now())
##        ,expiration = datetime.timedelta(seconds=75)
##        )
##    
##    return True
###__________________________________________________________________
###
##
