'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib #used for urlencode
import re
import xbmc
from resources.lib import utils
from resources.lib import search
from resources.lib.utils import Log
from resources.lib import constants as C


FRIENDLY_NAME = '[COLOR {}]porndig[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = True

#2019-07-21 site similar to tukif 
ROOT_URL = "https://www.porndig.com"
SEARCH_URL = ROOT_URL + '/search/'
URL_CATEGORIES_PRO = ROOT_URL
URL_CATEGORIES_AMATURE = ROOT_URL + '/amateur/videos/'
URL_CHANNELS = ROOT_URL + '/channels/'

MAIN_MODE          = C.MAIN_MODE_porndig
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

main_category_id_AMATURES = '4'
main_category_id_PROFESSIONALS = '1'
SECTION_DEFAULT = 0
SECTION_PORNSTARS = 2

URL_RECENT = ""
FIRST_PAGE = '1'

HITS_PER_PAGE = 36

SITE_HEADERS = {
            'User-Agent': C.USER_AGENT
            ,'X-Requested-With': 'XMLHttpRequest'
            ,'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            ,'Accept': '*/*'
            ,'Accept-Encoding': 'gzip, deflate'
            ,'Accept-Language': 'en-US,en;q=0.8,nl;q=0.6'
            ,'Connection': 'keep-alive'
            ,'Cookie': ''
            }

#__________________________________________________________________________
#

@C.url_dispatcher.register(MAIN_MODE, ['channel'])
def Main(porn_amatuer):
    porn_amatuer = str(porn_amatuer)
    Log("VideoListData() porn_amatuer={}".format(porn_amatuer))
    
    if porn_amatuer == main_category_id_AMATURES:
        URL_CATEGORIES = URL_CATEGORIES_AMATURE
    else:
        URL_CATEGORIES = URL_CATEGORIES_PRO
        porn_amatuer = main_category_id_PROFESSIONALS
    

    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.search_icon 
        ,Folder=True
        ,channel=porn_amatuer
        )

    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(porn_amatuer=porn_amatuer
         , category_or_star=SECTION_DEFAULT
         , page=FIRST_PAGE
         , end_directory=True
         , progress_dialog=progress_dialog)

#__________________________________________________________________________
#

def VideoListData(page, channel):
    Log("VideoListData() page={} channel={}".format(page,channel))
    
    sort = 'date'
    offset = (page-1) * HITS_PER_PAGE
##    if addon.getSetting("pdsection") == '1':
##        catid = 4
##    else:
##        catid = 1
    values = {'main_category_id': channel,
              'type': 'post',
              'name': 'category_videos',
              'filters[filter_type]': sort,
              'filters[filter_period]': '',
              'offset': offset}
    return urllib.urlencode(values)

#__________________________________________________________________________
#

def CatListData(page, porn_amatuer, category_id):
    Log("CatListData() page={} channel={} category_id={}".format(page,porn_amatuer,category_id))
    sort = 'date'
    offset = (page-1) * HITS_PER_PAGE
    values = {
              'main_category_id': porn_amatuer
              ,'type': 'post'
              ,'name': 'category_videos'
              ,'filters[filter_type]': sort
              ,'filters[filter_period]': ''
              ,'filters[filter_quality][]': '270'
              ,'offset': offset
              ,'category_id[]': category_id
              ,'filters[filter_duration][t1]': '45'
              ,'filters[filter_duration][t2]': '26'
              ,'filters[filter_duration][t3]': '15'
              ,'filters[filter_duration][t4]': '14'
              }
    data = urllib.urlencode(values).replace('t1','').replace('t2','').replace('t3','').replace('t4','')
    return data
#__________________________________________________________________________
#

def SearchData(page, channel, keyword):
    offset = (page-1) * HITS_PER_PAGE
    values = {'main_category_id': channel,
              'type': 'post',
              'name': 'search_posts',
              'filters[filter_type]': 'date',
              'search': keyword,
              'offset': offset}
    return urllib.urlencode(values)

#__________________________________________________________________________
#

def VideoListStudio(page, channel):
    sort = 'date'
    offset = (page-1) * HITS_PER_PAGE
    values = {'main_category_id': channel,
              'type': 'post',
              'name': 'studio_related_videos',
              'filters[filter_type]': sort,
              'filters[filter_period]': '',
              'offset': offset,
              'content_id': channel}
    return urllib.urlencode(values)

#__________________________________________________________________________
#

##@C.url_dispatcher.register(PORNSTARS_MODE, ['url', 'channel'], ['page'])
##def Pornstars(url, channel, page=1):
##    data = PornstarListData(page, channel)
##    urldata = utils.getHtml(url, referer=pdreferer, headers=SITE_HEADERS, data=data)
##    urldata, has_more = ParseJson(urldata)
##    i = 0
##    match = re.compile(r'pornstar_([\d]+).*?alt="([^"]+)".*?Videos</div> <div class="value">([\d]+)',
##                       re.DOTALL | re.IGNORECASE).findall(urldata)
##    for ID, studio, videos in match:
##        title = studio + " Videos: [COLOR deeppink]" + videos + "[/COLOR]"
##        img = "http://static-push.porndig.com/media/default/pornstars/pornstar_" + ID + ".jpg"
##        utils.addDir(title, '', LIST_MODE, img, 0, ID, 2)
##        i += 1
##    if i >= 60:
##        page += 1
##        utils.addDir('Page ' + str(page), url, PORNSTARS_MODE, '', page)
##
##    utils.endOfDirectory()
##
###__________________________________________________________________________
###
##
##@C.url_dispatcher.register(STUDIOS_MODE, ['url'], ['page'])
##def Studios(url, page=1):
##
##    data = StudioListData(page)
##    urldata = utils.getHtml(url, referer=pdreferer, headers=SITE_HEADERS, data=data)
##    urldata, has_more = ParseJson(urldata)
##    i = 0
##    match = re.compile(r'studio_([\d]+).*?alt="([^"]+)".*?Videos</div> <div class="value">([\d]+)',
##                       re.DOTALL | re.IGNORECASE).findall(urldata)
##    for ID, studio, videos in match:
##        title = studio + " Videos: [COLOR deeppink]" + videos + "[/COLOR]"
##        img = "http://static-push.porndig.com/media/default/studios/studio_" + ID + ".jpg"
##        utils.addDir(title, '', LIST_MODE, img, 0, ID, 1)
##        i += 1
##    if i >= 60:
##        page += 1
##        utils.addDir('Page ' + str(page), url, STUDIOS_MODE, '', page)
##
##    utils.endOfDirectory()

#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url', 'channel'], ['end_directory'])
def Categories(url, porn_amatuer, end_directory=True):

    try:
        html = utils.getHtml(url, ROOT_URL)

        #regex = 'name="filter_category_id"(.+?)name="filter_tag_id"'
        regex = 'class="sidebar_subsection_main_categories"(.+?)class="js_sidebar'
        
        
        video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)[0]

        #for this site, we only want the numerical value for the channel
        #regex = 'data-category_name="([^"]+)".+?data-url="/channels/([^/]+)/'
        regex = 'class="sidebar_section_item" href="/channels/([^/]+)/.+?title="([^"]+)"'
        info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
        for category_or_star, label in info:
    ##        Log("label='{}'".format(label))
            utils.addDir(
                name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
                ,url=porn_amatuer 
                ,mode=LIST_MODE
                ,iconimage=C.search_icon 
                ,Folder=True
                ,section=category_or_star
                ,page=FIRST_PAGE
                )
    except:
        #pass
        raise
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))
    
    List(porn_amatuer=main_category_id_PROFESSIONALS
         , category_or_star=SECTION_DEFAULT
         , page=FIRST_PAGE
         , end_directory=False)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url', 'section'], ['page', 'keyword', 'end_directory', 'testmode'])
def List(porn_amatuer=main_category_id_PROFESSIONALS, category_or_star=SECTION_DEFAULT, page=1, keyword='', end_directory=True, testmode=False, url='', progress_dialog=None):
    Log("List(porn_amatuer={}, category_or_star={}, page={}, end_directory={}, keyword={}".format(porn_amatuer, category_or_star, page, end_directory, keyword))
    Log("url={}".format(url))
    
    page = int(page)

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
        
    if category_or_star == SECTION_DEFAULT:
        data = VideoListData(page, porn_amatuer)
        post_url_suffix = "/posts/load_more_posts"
        regex = '<a.*?href="([^"]+)" title="([^"]+)".*?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)" title="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)"\s+?alt="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".+?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)"\s+?alt="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".+?<span class="pull-left">([^<]+)<'  #worked pre-2020-08
        regex = 'data-post_duration="(?P<duration>\d+)".+?href="(?P<videourl>[^"]+)".+?alt="(?P<label>[^"]+)".+?class="icon.+?_qlt_(?P<hd>\S+).+?img data-src="(?P<thumb>[^"]+)"' #worked pre 2022-10
        regex = ('data-post_duration="(?P<duration>\d+)"'
                 '.+?href="(?P<videourl>[^"]+)"'
                 '.+?class="icon.+?_qlt_(?P<hd>\S+)'
                 '.+?alt="(?P<label>[^"]+)"'
                 '.+?img data-src="(?P<thumb>[^"]+)"'
                 )

    elif category_or_star == 1:
        data = VideoListStudio(page, porn_amatuer)
    elif category_or_star == SECTION_PORNSTARS:
        data = VideoListPornstar(page, porn_amatuer, category_or_star)
        post_url_suffix = "/pornstars/load_more_pornstars"
        regex = '<a href="([^"]+)" title="([^"]+)".*?img src="([^"]+)".*?(0)'
    elif category_or_star == 3:
        data = CatListData(page, channel)
    elif str(category_or_star) == SEARCH_MODE:
        data = SearchData(page, porn_amatuer, keyword)
        post_url_suffix = "/posts/load_more_posts"
        regex = '<a.*?href="([^"]+)" title="([^"]+)".*?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)" title="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)"\s+?alt="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".+?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)"\s+?alt="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".+?<span class="pull-left">([^<]+)<'  #worked pre-2020-08
        regex = 'data-post_duration="(\d+)".+?href="([^"]+)".+?alt="([^"]+)".+?class="icon.+?_qlt_(\S+).+?img data-src="([^"]+)"'
        regex = 'data-post_duration="(?P<duration>\d+)".+?href="(?P<videourl>[^"]+)".+?alt="(?P<label>[^"]+)".+?img data-src="(?P<thumb>[^"]+)".+?class="icon.+?_qlt_(?P<hd>\S+)'
        regex = ('data-post_duration="(?P<duration>\d+)"'
                 '.+?href="(?P<videourl>[^"]+)"'
                 '.+?class="icon.+?_qlt_(?P<hd>\S+)'
                 '.+?alt="(?P<label>[^"]+)"'
                 '.+?img data-src="(?P<thumb>[^"]+)"'
                 )
        regex = ('data-post_duration="(?P<duration>\d+)"'
                 '.+?href="(?P<videourl>[^"]+)"'
                 '.+?alt="(?P<label>[^"]+)"'
                 '.+?img data-src="(?P<thumb>[^"]+)"'
                 '.+?class="bubble_mobile_quality"(?P<hd>.+?)</i>'
                 )
                    
                                                                                               
    else:
        data = CatListData(page, porn_amatuer, category_or_star)
        post_url_suffix = "/posts/load_more_posts"
        regex = '<a.*?href="([^"]+)" title="([^"]+)".*?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)" title="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)"\s+?alt="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".+?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)"\s+?alt="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".+?<span class="pull-left">([^<]+)<'  #worked pre-2020-08
        regex = 'data-post_duration="(?P<duration>\d+)".+?href="(?P<videourl>[^"]+)".+?alt="(?P<label>[^"]+)".+?class="icon.+?_qlt_(?P<hd>\S+).+?img data-src="(?P<thumb>[^"]+)"'
        regex = ('data-post_duration="(?P<duration>\d+)"'
                 '.+?href="(?P<videourl>[^"]+)"'
                 '.+?class="icon.+?_qlt_(?P<hd>\S+)'
                 '.+?alt="(?P<label>[^"]+)"'
                 '.+?img data-src="(?P<thumb>[^"]+)"'
                 )
    Log("data='{}'".format(data))

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = ROOT_URL
    headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
    headers['X-Requested-With'] = 'XMLHttpRequest'

    urldata = utils.postHtml(ROOT_URL + post_url_suffix, headers=headers, sent_data=data)
    
    video_region, has_more = ParseJson(urldata)
    #Log("video_region ={}".format(video_region))
    
##    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
##    for duration, videourl, label, hd, thumb in info:
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(video_region)
    videourl = ''
    for item in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        videourl = item.group('videourl')
        thumb = item.group('thumb')
        label = item.group('label')
        hd = item.group('hd')
        duration = item.group('duration')

##        Log(repr(videourl))
##        Log(repr(label))


        hd = utils.Normalize_HD_String(hd)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        duration = duration.replace(' min','')
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration )
    utils.Check_For_Minimum(videourl, keyword, MAIN_MODE, ROOT_URL, testmode)


    if has_more == False:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(porn_amatuer))
    else:
        np_number = int(page)+1
        # this is a _FAKE_ url for this site only, used for Notify()
        np_url = ROOT_URL + '/page=' + str(np_number) 
##        Log("np_number={}".format(np_number))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=porn_amatuer 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number 
                ,Folder=True 
                ,channel=porn_amatuer
                ,section=category_or_star
                ,keyword=keyword
                )
        else:
            if int(np_number) < max_search_depth:
                utils.Notify(msg=np_url)
                List(
                    porn_amatuer=porn_amatuer
                     , keyword=keyword
                     , category_or_star=category_or_star
                     , page=np_number
                     , end_directory=end_directory
                    )

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace(' ','+')
    Log("searchUrl='{}'".format(SEARCH_URL.format(title)))
    List(porn_amatuer=main_category_id_PROFESSIONALS
         , category_or_star=SEARCH_MODE
         , keyword=title
         , end_directory=end_directory
         , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    videopage = utils.getHtml(url, referer=ROOT_URL, headers=SITE_HEADERS)

    video_links = re.compile('<a href="([^"]+)" class="post_download_link clearfix">[^>]+>.*?(\d+p).*?<',
                       re.DOTALL | re.IGNORECASE).findall(videopage)
    video_url = utils.SortVideos(
        sources=video_links
        ,download=download
        ,vid_res_column=1
        ,max_video_resolution=max_video_resolution
        )

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return

    regex_model = 'data-pornstar_id="\d+".*?>(?P<model>[^<]+)<(?:/a>|/span></div>)'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(videopage)
    description = ''
    desc_separator_char = '; '
    if source_models:
        for model in source_models:
            description = description + desc_separator_char + model.group('model')
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))
    
    headers = C.DEFAULT_HEADERS.copy()
    headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    headers['Referer'] = ROOT_URL

    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
def ParseJson(urldata):
    import json
    items = json.loads(urldata)
    success = items['success']
    has_more = items['data']['has_more']
    data = items['data']['content']
    if len(data) == 0: data = ''

    return data, has_more
#__________________________________________________________________________
#
