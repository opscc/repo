'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 NothingGnome

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]spankbang[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = 'https://spankbang.com'
SEARCH_URL = ROOT_URL + '/s/'
SEARCH_URL = ROOT_URL + '/s/{}/{}/'
URL_CATEGORIES = ROOT_URL + '/categories' 
URL_RECENT = ROOT_URL + '/new_videos/{}/'

MAIN_MODE          = C.MAIN_MODE_spankbang
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon  )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
    
    # read html
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if "Page Not Found" in listhtml:
        video_region = ''
    else: #distinguish between adverts and videos
        try:
            regex = '<div class="results(.+)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
            Log("video region found via regex".format())
        except:
            video_region = listhtml
        #Log("video_region={}".format(video_region))

    regex = 'div class="video-item".+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?((?:class="i-hd">[^<]+<|class="i-len")).+?fa fa-clock-o"></i>([^<]+)<'
    regex = 'div class="video-item".+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="i-len">([^<]+)<.+?(?:class="i-hd">([^<]+)<|/p)'
    regex = 'div class="video-item.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="i-len">([^<]+)<.+?(?:class="i-hd">([^<]+)<|/p)'    #2020-07-03
    regex = 'div class="video-item" data-id=.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="l">([^<]+)<.+?class="(?:h|n)">([^<]+)<'  #2020-10-17
    regex = 'div class="video-item." data-id=.+?<a href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)".+?class="l">([^<]+)<.+?class="(?:h|n)">([^<]+)<'  #2020-11-21
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #for videourl, thumb, label, hd, duration in info:
    for videourl, thumb, label, duration, hd in info:
        hd = utils.Normalize_HD_String(hd)
        if not thumb.startswith('http'): thumb = "https:" + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration + 'm'
            , noDownload=False)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    

    #np_info=re.compile('<a href="([^"]+)">&raquo;', re.DOTALL | re.IGNORECASE).findall(listhtml)
    regex = '<a href=".+?(\d+)/">&raquo;'
    regex = 'href=".+?(\d+)/\??[^"]*">&raquo;'
    np_info=re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(url))

    for np_url in np_info:
##            Log("np_url={}".format(np_url))
        np_number = np_url
        np_url = url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth:
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword)
        break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(title,'{}')
    Log("searchUrl='{}'".format(searchUrl))    
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url)

    regex = '<a href="(/category/[^"]+)"><img src="([^"]+)"><span>([^<]+)</span>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, thumb, label in info:
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        videourl = videourl.split('?')[0] + '{}/?period=all'
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    full_html = utils.getHtml(url, ROOT_URL)

    if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
        return
    
##    stream_key = re.compile("data-streamkey=\"([^\"]+)\"").findall(html)
##    if stream_key:
##        stream_key = stream_key[0]
##    else:
##        if "this video is no longer available" in html:
##            utils.Notify("Video '{}' has been deleted".format(name))
##        elif "This Video Is Private" in html:
##            utils.Notify("Video '{}' Is Private".format(name))
##        else:
##            utils.Notify("Update required for {}".format(ROOT_URL))
##        return
##    #Log(stream_key)

    description_regex = 'section class="details"(.+?)section class="user_uploads"'
    description_html = re.compile(description_regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    if description_html: description_html=description_html[0]
    else: description_html=''
    description = ''
    desc_separator_char = '; '
    pornstar_regex = 'href="(?:/pornstar/|/tag/).+?>([^<]+?)<'
    pornstars = re.compile(pornstar_regex, re.DOTALL | re.IGNORECASE).findall(description_html)
    for pornstar in pornstars:
        if pornstar.lower() not in description.lower():
            description = description + utils.cleantext(pornstar) + desc_separator_char
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log(u"description={}".format(description.decode("utf8")))



    links_regex = 'var stream_data = (.+?\]})'
    links_json_html = re.compile(links_regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    if links_json_html: links_json_html=links_json_html[0]
    else: links_json_html='{}'
##    Log("links_json_html={}".format(links_json_html))
    links_json_html = links_json_html.replace('\'','"')
    json_urls = json.loads(str(links_json_html))
    Log("json_urls={}".format(repr(json_urls)))

    list_key_value = {} 
    for json_url in json_urls:
        q = json_url
        v = json_urls[json_url]
        if (q.endswith('0p') and not q.startswith('m3u8')) or q == '4k':
            if len(v) > 0:
                v = v[0]
                list_key_value[q] = v
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function            
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )


    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
    utils.playvid(video_url, name=name, download=download, description=description)

    return True

#__________________________________________________________________________
#


##
##    match = None
##
##    match_4k = json_urls["4k"]
##    match_1080 = json_urls["1080p"]
##    match_720 = json_urls["720p"]
##    match_480 = json_urls["480p"]
##    match_320 = json_urls["320p"]
##    match_240 = json_urls["240p"]
##
##    match_m3u8_4k = json_urls["m3u8_4k"]
##    match_m3u8_1080 = json_urls["m3u8_1080p"]
##    match_m3u8_720 = json_urls["m3u8_720p"]
##    match_m3u8_480 = json_urls["m3u8_480p"]
##    match_m3u8_320 = json_urls["m3u8_320p"]
##    match_m3u8_240 = json_urls["m3u8_240p"]
##
##    maximum_video_resolution = int(C.addon.getSetting("maximum_video_resolution"))
##
##    if match_4k and maximum_video_resolution >= 1440:
##        match = match_4k
##    elif match_1080 and maximum_video_resolution >= 1080:
##        match = match_1080
##    elif match_m3u8_1080 and maximum_video_resolution >= 1080:
##        match = match_m3u8_1080
##    elif match_720 and maximum_video_resolution >= 720:
##        match = match_720
##    elif match_m3u8_720 and maximum_video_resolution >= 720:
##        match = match_m3u8_720
##    elif match_480: match = match_480
##    elif match_320: match = match_320
##    elif match_240: match = match_240
##
##    Log("match={}".format(match))
##    if type(match) == list:
##        #match = match[0]
##        import random
##        match = random.choice(match)
####        Log("match={}".format(match))
####        Log("match={}".format(type(match)))
##
##        
##    #Log(match)
##    if match:
##        utils.playvid(videourl=match, name=name, download=download, description=description + '\n' + ROOT_URL )
##    else:
##        utils.notify('Oh oh','Couldn\'t find a video')

