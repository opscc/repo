'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]hentaidude[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_HENTAI
    _FRONT_PAGE_CANDIDATE = False
    _ROOT_URL        = "https://hentaidude.com"
    _URL_CATEGORIES  = _ROOT_URL + '/?orderby=date'  #2021-03 site brotli encoded root page and I can't install decoder
    _URL_RECENT      = _ROOT_URL + '/page/{}/?orderby=date'
    _SEARCH_URL      = _ROOT_URL + '/page/{}/?s={}'
    _MAIN_MODE = C.MAIN_MODE_hentaidude
    _FIRST_PAGE = '1'

    #where we can find videos on this page [exclude advertisement]
    #_REGEX_video_region = '(?:data-section_name="day_by_day_section" data-espnode|video_row_main_search"|data-espnode="videolist")(.+?)(?:id="pagination"|<footer>)'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        ]
    #videos on this page
    _REGEX_video_region = 'id="content">(.+)(?:style="display:none;"|Related Videos)'
    _REGEX_list_items = (
        'class="videoPost".+?title="(?P<label>[^"]+)"'
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '(?P<hd>)'
        '(?P<duration>)'
        )
    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'class="navigation"(.+?)<script'
    _REGEX_next_page_regex = '(Next &rsaquo;)'
    #if we need to save html cookies
    _SAVE_COOKIES = False
    #where categories can be found
    #_REGEX_categories_region = 'class="category-list-view"(.+?)/section-wrapper'
    _REGEX_categories = (
        'data-tag="(?P<videourl>.+?)" class="btn'
        '.+?>(?P<label>[^"]+)<span'
        '(?P<thumb>)'
        )
    #where playable urls live
    _REGEX_playsearch_01 = (
        'data-hls-src(?P<res>\d+)'
        '="(?P<url>[^"]+)"'
        )
    #description for the playable url
##    _REGEX_tags = '"/pornstar/.+?>([^<]+)<'
##    _REGEX_tags_region = 'class="detail-video-block"(.+?)class="comments-wrapper"'
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + '/page/{}/?tid=' + url 
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format('{}', keyword)
    #__________________________________________________________________________
    # Override here so that any potential self.* reference happens
    def Playvid(self, url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))

        description = name + '\n' + self.ROOT_URL
        
        from resources.lib import utils
        import re
        import json
        import urllib
        html = utils.getHtml(url, website.ROOT_URL)
        headers = C.DEFAULT_HEADERS.copy()
        headers['Accept'] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        match = re.compile("action: 'msv-get-sources'.+?id: '(.+?)'.+?nonce: '(.+?)'", re.DOTALL | re.IGNORECASE).findall(html)[0]
        payload = {'action':'msv-get-sources', 'id':match[0], 'nonce':match[1]}
        payload = "{}".format( urllib.urlencode(payload) )
        sources = utils.postHtml(
            'https://hentaidude.com/wp-admin/admin-ajax.php'
            , sent_data=payload
            , headers=headers
            #, compression=False
            #, NoCookie=None
            )
        Log("sources='{}'".format(repr(sources)))
        if not sources:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,website.ROOT_URL))
            return
        sJson = json.loads(sources)
        Log("sJson='{}'".format(repr(sJson)))
        if not sJson['success']:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,website.ROOT_URL))
            return
        video_url = sJson['sources']['video-source-0']
        Log("video_url='{}'".format(video_url))

        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = website.ROOT_URL
        video_url = video_url + utils.Header2pipestring(headers)
        Log("video_url='{}'".format(video_url))
        if testmode:
            Log("Would have played video_url; but in test mode")
            return   #during testmode, only ensure that a url can be generated

        utils.playvid(video_url, name=name, download=download, description=description)
    #__________________________________________________________________________
    #

#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    website.Playvid(url, name, download, playmode_string, play_profile=play_profile, testmode=testmode)
#__________________________________________________________________________
#
