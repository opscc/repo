'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]anybunny[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "http://anybunny.com"
SEARCH_URL = ROOT_URL + '/top/{}?p={}'
URL_CATEGORIES = ROOT_URL
URL_TOP_RATED = ROOT_URL + '/top/'
URL_RECENT = ROOT_URL + '/new/?p={}'

MAIN_MODE          = C.MAIN_MODE_anybunny
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
CHANNELS_MODE      = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name="{}[COLOR {}]Top videos[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color) 
        ,url=URL_TOP_RATED
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon )
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=FIRST_PAGE, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, ROOT_URL)
    if "did not match any " in listhtml:
        video_region = ""
        listhtml = ""
    else:
        video_region = listhtml.split('class="main"')[1]
        video_region = video_region.split('class="divrectr"')[0]


    # parse out list items
    regex = "class='nuyrfe' href='([^']+)'.*?src='([^']+)'.*?alt='([^']+)'(.)"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, hd in info:
        hd = utils.Normalize_HD_String(hd)
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label),hd)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , desc = '\n' + ROOT_URL
            , iconimage = thumb )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    
    # next page items
    next_page_html = listhtml #.split('class=linkscts')[1]
    next_page_regex = 'href="([^"]+)">Next '
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url in np_info:
        np_number=np_url.split('=')[1]
        if np_url.startswith('/'): np_url = ROOT_URL + np_url
        np_url=np_url.replace(" ","%20")
        #Log("np_url={}".format(np_url))
        #Log("np_number={}".format(np_number))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number 
                ,section = C.INBAND_RECURSE
                ,keyword=keyword
                )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
        break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace('+',' ').replace(' ','_')
    searchUrl = SEARCH_URL.format(title, '{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))        
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url, ROOT_URL)
 
    regex = "<a href='/top/([^']+)'>.*?src='([^']+)' alt='([^']+)'"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = URL_RECENT + videourl
##        Log("thumb={}".format(thumb))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            )
        
    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    
    abpage = utils.getHtml(url, ROOT_URL)
##    Log("abpage='{}'".format(repr(abpage)))

    if any(x in abpage for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
        return


    regex = "source src='([^']+?mp4[^']+?)'"
    direct_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(abpage)
    if direct_url:
        Log("direct_url={}".format(repr(direct_url)))
        video_url = direct_url[0] + utils.Header2pipestring() + '&Referer=' + ROOT_URL
        Log("video_url={}".format(video_url))
        utils.playvid(video_url=video_url, name=name, download=download, description=description)
        return

    regex = "source src='([^']+?)' type='application/x-mpegURL'"
    hls_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(abpage)
    if hls_url:
        Log("hls_url={}".format(repr(hls_url)))
        video_url = hls_url[0] + utils.Header2pipestring() + '&Referer=' + ROOT_URL
        Log("video_url={}".format(video_url))
        utils.playvid(video_url=video_url, name=name, download=download, description=description)
        return

    regex = '<iframe.*?src="([^"]+)"'
    vartuc_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(abpage)
##    Log("vartuc_url='{}'".format(repr(vartuc_url)))
    if vartuc_url: vartuc_url = vartuc_url[0]
##    Log("vartuc_url='{}'".format(repr(vartuc_url)))
    if not vartuc_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    
    embedpage = utils.getHtml(vartuc_url, url)
    scripturl = re.compile("src='([^']+)", re.DOTALL | re.IGNORECASE).findall(embedpage)[0]
    scripturl = "https://vartuC.com" + scripturl
    #videopage = utils.getHtml(scripturl, vartucurl, vartuchdr)
    videopage = utils.getHtml(scripturl, vartuc_url)

    #https://azblowjobtube.com/kt_player/player.php?id=2806993&s=MhCqUdeCkqOCnPdNPuzxyA&ts=1561758799&ver=x HTTP/1.1
    #2019-06-28 site obfuskates code; i.e need to replace "'+ghbva+'" with "."
    video_url = re.compile("irue842=(.*?);uSS1Comp=", re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    Log("video_url={}".format(video_url))
    match = re.compile(r'(gh\w\w\w)="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    for repl, repl2 in match:
        video_url = video_url.replace("'+"+repl+"+'",repl2)

    Log("video_url={}".format(video_url))
    from resources.lib import resolver
    video_url = resolver.resolve_video(videosource=video_url, name=name, download=download, url=url)

    Log("video_url={}".format(video_url))
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#



