    #-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import json
import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

HITS_PER_PAGE = 60

FRIENDLY_NAME = '[COLOR {}]HClips[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://hclips.com"
SEARCH_URL = ROOT_URL + '/search/{}/?q={}&p=0'
SEARCH_URL = ROOT_URL + '/api/videos.php?params=259200/str/relevance/{}/search..{}.all..day&s={}'.format(HITS_PER_PAGE, '{}', '{}')
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_CATEGORIES = ROOT_URL + '/api/json/categories/14400/str.all.json'
URL_CHANNELS = ROOT_URL + '/channels/'
URL_RECENT = ROOT_URL + '/api/json/videos/86400/str/latest-updates/{}/..{}.all..day.json'.format(HITS_PER_PAGE, '{}')

# like txxx
# like hclips
# like tubepornclassic

MAIN_MODE          = C.MAIN_MODE_hclips
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
##    if '{}' in url and page > 0 :
    listhtml = utils.getHtml(list_url, ROOT_URL) #, ignore404=True)#, ignore404=True , send_back_redirect=True)

    json_content = json.loads(listhtml)
    if 'error' in json_content:
        video_region = ''
        utils.Check_For_Minimum([], keyword, MAIN_MODE, ROOT_URL, testmode)


    # parse out list items
    if 'videos' in json_content:
        for hit in json_content['videos']:
            #Log("hit='{}'".format(hit))
            videourl = "{}/videos/{}/{}/".format(ROOT_URL, hit['video_id'], hit['dir'])
            thumb = hit['scr']
            label = hit['title']
            duration = hit['duration']
            try:
                hd = hit['props']["hd"]
            except:
                hd = ""
            if hd in ["1"]:
                hd = "720" #this site is always at least 'hd'

            hd = utils.Normalize_HD_String(hd)
##            if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(C.search_text_color)
##            elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(C.refresh_text_color)
##            elif  '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(C.time_text_color)
##            elif    '1' in hd: hd = "[COLOR {}]hd[/COLOR]".format(C.time_text_color)
##            else: hd = ""

            label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
            utils.addDownLink( 
                name = label 
                , url = videourl 
                , mode = PLAY_MODE 
                , iconimage = thumb
                , desc='\n' + ROOT_URL
                , duration = duration )
        utils.Check_For_Minimum(json_content['videos'], keyword, MAIN_MODE, ROOT_URL, testmode)

##    #
##    # check for a minimum
##    #
##    if len(info) < 1:
##        label = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "No more items")
##        if not keyword == '': label += " for '{}'".format(keyword)
##        label +=  " on '{}'".format(ROOT_URL)
##        utils.addDir(
##            name=label
##            ,url=C.DO_NOTHING_URL
##            ,mode=MAIN_MODE
##            )
##        if testmode:
##            raise OSError
    

    #
    # next page items
    #
    if 'total_count' in json_content:
        total_count = int(json_content['total_count'])
        page = int(page)
        if page * HITS_PER_PAGE >= total_count:
            Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
            Log("current_page*HITS_PER_PAGE={} total_count={}".format(page * HITS_PER_PAGE, total_count))
        else:
            np_url = url
            np_number = page + 1
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword
                    )
            else:
               if int(np_number) <= max_search_depth:
                    utils.Notify(msg=np_url)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','%20').replace('+','%20')
    searchUrl = SEARCH_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    json_html = utils.getHtml(url, ROOT_URL)
    json_content = json.loads(json_html)

    # parse out list items
    if 'categories' in json_content:
        for hit in json_content['categories']:
            #Log("hit='{}'".format(hit))

            url = "{}/api/json/videos/86400/str/latest-updates/{}/categories.{}.{}.all..day.json" \
                .format(ROOT_URL, HITS_PER_PAGE,  hit['dir'], '{}')
            label = hit['title']
##            label = "{}[COLOR {}]{}[/COLOR]".format(
##                SPACING_FOR_TOPMOST
##                , C.search_text_color
##                , utils.cleantext(label)
##                )
            utils.addDir(
                name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
                ,url=url 
                ,mode=LIST_MODE
                ,page=FIRST_PAGE
                ,iconimage=C.search_icon
                )

    if len(json_content) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format(
                C.highlight_text_color
                , 'failed Categories {}'.format(ROOT_URL)
                )
            ,url=list_url
            ,mode=MAIN_MODE
            )
        raise OSError

    utils.endOfDirectory(end_directory=end_directory)        
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL


    video_id = url.split('/')[4]

    if len(video_id) < 7:
        padder1 = '0'
    else:
        padder1 = video_id[0:1] + '000000' 
    padder2 = video_id[0:(len(video_id)-3)] + '000' 
    mask = "https://hclips.com/api/json/video/86400/{}/{}/{}.json".format(padder1, padder2, video_id)
##    Log("mask={}".format(mask))
##    return
    json_url = mask.format(video_id)
    json_source = utils.getHtml(json_url, url)
    json_content = json.loads(json_source)
    #Log("json_content={}".format(json_content), xbmc.LOGNONE)
    if 'error' in json_content:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        return        

    description = json_content['video']['description']
    Log("description={}".format(description))
    if 'on HClips.com,' in description: description = description.split('on HClips.com,')[0]
    if description == '':
        description=name + '\n' + ROOT_URL
    else:
        description=description + '\n' + ROOT_URL
    Log("description={}".format(description))
    

    mask = "https://hclips.com/api/videofile.php?video_id={}&lifetime=8640000"
    json_url = mask.format(video_id)
    json_source = utils.getHtml(json_url, url)
    json_content = json.loads(json_source)
    Log("json_content={}".format(json_content))
    if 'error' in json_content:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        return

    from resources.lib import resolver
    video_url= ROOT_URL + resolver.alltubes_decode(json_content[0]['video_url'])

##    headers = {
##        'User-Agent': C.USER_AGENT
##        ,'Referer': url
##       }
##    video_url = video_url + utils.Header2pipestring(headers)  #required or else acces denied
##    Log("video_url={}".format(video_url.encode()))
##
##    utils.playvid(video_url, name, download, description)

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
