#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import sqlite3
import traceback
import xbmc 
import xbmcaddon
import xbmcvfs

#import internal addon libraries
import utils 
import constants as C
#define common aliases
from utils import Log

#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CONFIGURE_THIS_ADDON)
def configure_THIS_addon():
    Log("configure_THIS_addon")
    xbmcaddon.Addon(id=C.addon_id).openSettings()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CONFIGURE_INPUTSTREAM)
def configure_inputstream():
    Log("configure_inputstream")
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CONFIGURE_FMPROXY)
def configure_inputstream():
    Log("CONFIGURE_FMPROXY")
    xbmcaddon.Addon(id='script.video.F4mProxy').openSettings()
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.CLEAN_TEXTURES)
def Clean_Textures_DB():
    Log(__name__)

    #13 is a constant that may need to be recalculated https://kodi.wiki/view/Databases    
    texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db")) 
    db_version = {
        '17':13  # Krypton
        ,'18':13  # Leia
        ,'19':13  # Matrix
        ,'20':13  # nexus
        ,'21':13  #
        ,'22':14  #
    }
    texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures{}.db".format(db_version[C.xbmc_version])))

    
    try:    

        texture_cursor = texture_conn.cursor()

        query = "SELECT * FROM texture"
        params = ''
        Log(repr((query,params))
            ,C.LOGNONE
            )
        texture_cursor.execute(query,'')
        
        cachedurl_index = [idx for idx, col in enumerate(texture_cursor.description) if col[0] == 'cachedurl'][0]
        id_index = [idx for idx, col in enumerate(texture_cursor.description) if col[0] == 'id'][0]
        texture_folder = "special://thumbnails/"
        texture_folder = xbmc.translatePath(texture_folder)
        Log(repr(texture_folder)
            ,C.LOGNONE
            )
        

        progress_dialog_message = "Deleting missing Textures"
        progress_dialog = None
        progress_dialog = utils.Progress_Dialog(C.addon_name, progress_dialog_message)

        percent = 1
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...scanning...'
            )
            
        for result in texture_cursor.execute(query).fetchall():

            if progress_dialog.iscanceled(): break

            progress_dialog.increment_percent(0.01)
            Log(repr(progress_dialog.percent)
                , C.LOGNONE
                )

            texture_filespec = texture_folder + result[cachedurl_index]
            Log(repr(texture_filespec)
                , C.LOGNONE
                )
            
            if not xbmcvfs.exists(texture_filespec):
                query = "DELETE FROM texture WHERE id = ?"
                params = (result[id_index], )
                Log(repr((query,params))
                    ,C.LOGNONE
                    )
                texture_cursor.execute(query,params)
                
            #return

        
    except:
        traceback.print_exc()
    finally:
        texture_conn.commit()
        
#__________________________________________________________________________
#

@C.url_dispatcher.register(C.CLEAN_SIMPLECACHE)
def Clean_SimpleCache_DB():

    Log(__name__)    
    
    texture_conn = sqlite3.connect(xbmc.translatePath("special://home/userdata/addon_data/script.module.simplecache/simplecache.db")) 
    
    
    try:    

        texture_cursor = texture_conn.cursor()

        query = "DELETE FROM simplecache WHERE id LIKE 'plugin.video.uwc_gethtml_%'"
        params = ''
        Log(repr((query,params))
            ,C.LOGNONE
            )
        texture_cursor.execute(query,params)
        
##        cachedurl_index = [idx for idx, col in enumerate(texture_cursor.description) if col[0] == 'cachedurl'][0]
##        id_index = [idx for idx, col in enumerate(texture_cursor.description) if col[0] == 'id'][0]
##        texture_folder = "special://thumbnails/"
##        texture_folder = xbmc.translatePath(texture_folder)
##        Log(repr(texture_folder)
##            ,C.LOGNONE
##            )
##        
##
##        progress_dialog_message = "Deleteing missing Textures"
##        progress_dialog = None
##        progress_dialog = utils.Progress_Dialog(C.addon_name, progress_dialog_message)
##
##        percent = 1
##        progress_dialog.update(
##            percent = int(percent)
##            ,message = progress_dialog_message 
##            ,line2 = ' '
##            ,line3 = '...scanning...'
##            )
##            
##        for result in texture_cursor.execute(query).fetchall():
##
##            if progress_dialog.iscanceled(): break
##
####            progress_dialog.update(
####                percent  = progress_dialog.percent + 0.01
####                ,message = progress_dialog_message 
####                ,line2 = ' '
####                #,line3 = '...found {}...'.format(name)
####                )
##            progress_dialog.increment_percent(0.01)
##
##            Log(repr(progress_dialog.percent)
##                , C.LOGNONE
##                )
####            if progress_dialog.percent > 2.1: break
##                
##            
##            texture_filespec = texture_folder + result[cachedurl_index]
##            Log(repr(texture_filespec)
##                , C.LOGNONE
##                )
##            
##            if not xbmcvfs.exists(texture_filespec):
##                query = "DELETE FROM texture WHERE id = ?"
##                params = (result[id_index], )
##                Log(repr((query,params))
##                    ,C.LOGNONE
##                    )
##                texture_cursor.execute(query,params)
##                
##            #return

        
    except:
        traceback.print_exc()
    finally:
        texture_conn.commit()
        
#__________________________________________________________________________
#

