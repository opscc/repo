'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

#ROOT_URL = "https://www.vporn.com"
ROOT_URL = "https://www.pornone.com"

SEARCH_URL = ROOT_URL + '/search?q='

URL_CATEGORIES = ROOT_URL+'/categories/'
URL_RECENT = ROOT_URL+'/newest/'

MAIN_MODE       = '500'
LIST_MODE       = '501'
PLAY_MODE       = '502'
CATEGORIES_MODE = '503'
SEARCH_MODE     = '504'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color)
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)


    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))
    listhtml = utils.getHtml(list_url, '', ignore404=True )
    if "No results found for this criteria" in listhtml:
        #2019-06-30   this site will return a 404 response which will lead to ugly error message via utils.getHtml(url, '')
        video_region = ""
        next_page_html = ""
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon )
    else:
        next_page_html = listhtml
        if 'div class="banner-mobile"' in listhtml:
            video_region = listhtml.split('div class="banner-mobile"')[1]
        else:
            video_region = listhtml

    #
    # parse out list items
    #
    regex = 'class="video".+?href="([^"]+?)".+?<span class="time">([^<]+?)<.+?img src="([^"]+?)" alt="([^"]+?)"'
    regex = 'class="video".+?href="([^"]+?)".+?<span class="time">([^<]+?)<.+?class="(hd-marker[^"]+)".+?img src="([^"]+?)" alt="([^"]+?)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, duration, hd, thumb, label in info:
        if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  'is-hd' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration )
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError            
        

    #
    # next page items
    #
    next_page_regex = '<a class=\"next link(?:s|age)\" title=\"Next Page\" href=\"(.+?)\">'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        #Log("np_info='{}'".format(np_info))
        for np_url in np_info:
            np_number = np_url.split('?')[0].split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH #set here to support 'search_all'
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                    

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url, '')
    cathtml = cathtml.split('class="categories-sidebar')[1].split('class="l-main"')[0]

    regex = '<a href="([^"]+)".+?class="categoryName">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, label) 
        #if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        thumb = utils.search_icon
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon
            )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
    
@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    Log("url='{}', name='{}', download='{}'".format(url, name, download))

    page = utils.getHtml(url, ROOT_URL)

    regex = '<source src="([^"]+)".+?label="([^"]+)"'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(page)
    #Log("sources_list={}".format(sources_list))
    video_url = utils.SortVideos(sources_list,1)
    video_url = video_url + utils.Header2pipestring() + '&Referer=' + ROOT_URL
                            
    Log("video_url={}".format(video_url))

    if not video_url:
        utils.notify('Oh oh','Couldn\'t find a video')
        return

    #page = '<a id=\'star1\' href="https://pornone.com/riley-star-porn-videos-7783/"><span class="tags links">Riley Star</span'    
    regex_model = 'id=\'star\d+.+?links">(?P<model>[^<]+)<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(page)
    description = ''
    desc_separator_char = '; '
    if source_models:
        for model in source_models:
            description = description + desc_separator_char + model.group('model')
    description = description.strip(desc_separator_char)
    #Log("description={}".format(description))
    if description == '':
        description=name + '\n' + ROOT_URL
    else:
        description=description + '\n' + ROOT_URL
    Log("description={}".format(description))

        
    utils.playvid(video_url, name, download, description=description)
    
    return
        
    match = None
    match_480 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="480p"', re.DOTALL | re.IGNORECASE).findall(page)
    match_720 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="720p HD"', re.DOTALL | re.IGNORECASE).findall(page)
    match_1080 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="1080p"', re.DOTALL | re.IGNORECASE).findall(page)
    if match_1080 and not match : match = match_1080
    if match_720 and not match : match = match_720
    if match_480 and not match : match = match_480
    if not match:
        Log("no match found at url='{}', name=''".format(url,name), xbmc.LOGNONE)

    videourl = match[0]+utils.Header2pipestring()+"&Referer=" + ROOT_URL
    utils.playvid(videourl, name, download, description=description)

#__________________________________________________________________________
#


