'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin,xbmc
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://hqporner.com"

SEARCH_URL = ROOT_URL + '/?q='

URL_RECENT = ROOT_URL + '/hdporn/{}'
URL_CATEGORIES  = ROOT_URL + "/porn-categories.php"

URL_SUFFIX_GIRLS = "/porn-actress.php"
URL_SUFFIX_STUDIOS = "/porn-studios.php"

MAIN_MODE       = '150'
LIST_MODE       = '151'
PLAY_MODE       = '152'
CATEGORIES_MODE = '153'
SEARCH_MODE     = '154'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon )
    utils.addDir("{}[COLOR {}]Studios[/COLOR]   ".format(SPACING_FOR_TOPMOST, utils.search_text_color)
                ,url = ROOT_URL + URL_SUFFIX_STUDIOS
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.search_icon )
    utils.addDir("{}[COLOR {}]Girls[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color)
                ,url = ROOT_URL + URL_SUFFIX_GIRLS
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.search_icon )

    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List [url='{}', page='{}', end_directory='{}', keyword='{}']".format(url,page,end_directory,keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url)) 
    listhtml = utils.getHtml(list_url)
    if "I can't find porn to your request" in listhtml:
        video_region = ""
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon )
    else: #distinguish between adverts and videos
        video_region = listhtml.split('<ul class="actions pagination">')[0] # re.compile('(.+)<a href="([^"]+)"[^>]+>Next', re.DOTALL | re.IGNORECASE).findall(listhtml)[0][0]


    #
    # parse out list items
    #
    regex = 'src="([^"]+)" alt="([^"]+)".*?<a href="([^"]+)".*?fa-clock-o meta-data">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for thumb, label, videourl, duration in info:
        label = utils.cleantext(label).strip()
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    #
    # check for a minimum during tesing
    #
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError
    
        
    #
    # next page items
    #
    next_page_regex = '<a href="([^"]+)"[^>]+>Next'
    next_page_regex = 'class="actions pagination".+?<a href="([^"]+)"[^>]+>Next'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_number=np_url.split('/')[1]
            if not np_number.isdigit() and ('&p=' in np_url) : np_number=np_url.split('&p=')[1]
            if not np_number.isdigit(): np_number=np_url.split('/')[2]
            if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword)
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    listhtml = utils.getHtml(url, '')
 
    regex = '<a href="([^"]+)"[^<]+<img src="([^"]+)" alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, label) 
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    source_html = utils.getHtml(url, ROOT_URL)

    iframeurl = re.compile(r"nativeplayer\.php\?i=([^']+)", re.DOTALL | re.IGNORECASE).findall(source_html)
    if not (iframeurl[0].startswith('http')):
        iframeurl = 'https:' + iframeurl[0]

    video_url = None
    try:
        if (not video_url) and re.search('bemywife', iframeurl, re.DOTALL | re.IGNORECASE):
            Log("bemywife{}".format(""))
            video_url = getBMW(iframeurl,url)
    except: pass
    Log("video_url={}".format(video_url))
    try:
        if (not video_url) and re.search('mydaddy', iframeurl, re.DOTALL | re.IGNORECASE):
            Log("mydaddy{}".format(""))
            video_url = getBMW(iframeurl,url)
    except: pass
    Log("video_url={}".format(video_url))
    try:
        if (not video_url) and re.search('\/hqwo\.cc\/', iframeurl, re.DOTALL | re.IGNORECASE):
            Log("hqwo{}".format(iframeurl))
            video_url = getBMW(iframeurl, referer=url)
    except: pass
    Log("video_url={}".format(video_url))
    try:
        if not video_url and re.search('5\.79', iframeurl, re.DOTALL | re.IGNORECASE):
            Log("getIP{}".format(""))
            video_url = getIP(iframeurl)
    except: pass
    Log("video_url={}".format(video_url))
    try:
        if not video_url and re.search('flyflv', iframeurl, re.DOTALL | re.IGNORECASE):
            Log("flyflv{}".format(""))
            if (iframeurl.startswith('https:')):
                #apr 2018; https requires authentication for this site, http no
                iframeurl = iframeurl.replace('https://','http://')
            video_url = getFly(iframeurl)
    except: pass
    try:
        if not video_url and re.search('bigcdn', iframeurl, re.DOTALL | re.IGNORECASE):
            Log("bigcdn{}".format(""))
            if (iframeurl.startswith('https:')):
                #apr 2018; https requires authentication for this site, http no
                iframeurl = iframeurl.replace('https://','http://')
            video_url = getFly(iframeurl)
    except: pass
    
    if not video_url:
        utils.notify('Oh oh','Couldn\'t find a supported videohost')
        return

    if not video_url.startswith('http'): video_url = 'https:' + video_url

    description = ""
    desc_separator_char = ';   '
    regex = 'href="\/actress\/[^"]+".+?>([^<]+)<\/a>'
    description_info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html)
    for desc in description_info:
        description += desc_separator_char + desc
    description = description.strip(desc_separator_char)
##    Log("description={}".format(description))
##    return

    utils.playvid(video_url, name, download, description=description  + '\n' + ROOT_URL)

#__________________________________________________________________________
#

def getBMW(url, referer=""):

    Log("getBMW url='{}', referer='{}'".format(url,referer))
    videopage = utils.getHtml(url, referer)
    #Log("videopage='{}'".format(videopage))

    intermediate_url = None
    regex = "src='(https://n\d\.hqwo\.cc/.+?)'"
    re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    if re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage):
        regex = "<script type='text/javascript'\s+?src='(https://n\d\.hqwo\.cc/.+?)'"
        intermediate_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
        if intermediate_url: intermediate_url = intermediate_url[0]
        Log("intermediate_url='{}'".format(intermediate_url))
        videopage = utils.getHtml(intermediate_url, url)
        #Log("videopage='{}'".format(videopage))

    #sources_list = re.compile(r'file: "([^"]+mp4)", label: "(\d+)', re.DOTALL | re.IGNORECASE).findall(videopage)
    regex = '(?:file:|src=).+?"([^"]+?mp4).+?(?:label:|title=).*?"(\d+)'
    regex = '(?:file"?:|src=).+?"([^"]+?mp4).+?(?:label"?:|title=).*?"(\d+)'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)

    Log("sources_list='{}'".format(sources_list))
    if len(sources_list) < 1:
        return None

    list_key_value = {} ##[] #dict()
    for i in range(len(sources_list)):
        q = sources_list[i][0]
        #q = q.split(':')[1].replace('"', '')
        v = sources_list[i][1]
        #v = sources_list[i][1].split('url:')[1].replace('"', '')
        if not v == "":
            list_key_value[q] = v
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    Log("list_key_value='{}'".format(list_key_value))

    video_url = utils.SortVideos(list_key_value,1)    
    try:
        #videourl = videos[0]
        video_url = utils.SortVideos(list_key_value,1)
    except:
        #this exception code exists for legacy pages...
        videos = re.compile('src=\'(https\:\S+)\'>', re.DOTALL | re.IGNORECASE).findall(videopage)
        video_url = getIP2(videos[0])

    Log("video_url={}".format(video_url))
    return video_url

def getIP2(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('"file": "(\S+)",', re.DOTALL | re.IGNORECASE).findall(videopage)    
    videourl = videos[-1]
    return videourl


def getIP(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('file": "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = videos[-1]
    return videourl

def getFly(url):
    videopage = utils.getHtml(url, '')
    videos = re.compile('src=\'(.*)\' type=', re.IGNORECASE).findall(videopage)
    videourl = videos[-1]
    if not (videourl.startswith('http')):
        videourl = 'http:' + videourl
        
    return videourl
