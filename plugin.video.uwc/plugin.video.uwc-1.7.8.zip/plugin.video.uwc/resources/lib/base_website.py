'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import traceback
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

class Base_Website(object):
    
    def __init__(self):
        #don't set these; they are set in the sub-class
##        self._ROOT_URL = '' #"https://www.youporn.com"
        pass

    @property
    def FRIENDLY_NAME(self):
        return self._FRIENDLY_NAME
    @property
    def LIST_AREA(self):
        return self._LIST_AREA
##    @LIST_AREA.setter
##    def LIST_AREA(self, value):
##        self._LIST_AREA = value
    @property
    def FRONT_PAGE_CANDIDATE(self):
        return self._FRONT_PAGE_CANDIDATE
    @property
    def ROOT_URL(self):
        return self._ROOT_URL
    @property
    def SEARCH_URL(self):
        return self._SEARCH_URL  #_ROOT_URL + '/search/?query={}&page={}')
    @property
    def URL_CATEGORIES(self):
        return self._URL_CATEGORIES   #_ROOT_URL + '/categories/'
    @property
    def URL_RECENT(self):
        return self._URL_RECENT  #_ROOT_URL + '/browse/time/?page={}'

    @property
    def SAVE_COOKIES(self):
        return self._SAVE_COOKIES
    _SAVE_COOKIES = False

    @property
    def MAIN_MODE(self):
        return self._MAIN_MODE
    @property
    def LIST_MODE(self):
        return str(int(self._MAIN_MODE) + 1)
    @property
    def PLAY_MODE(self):
        return str(int(self._MAIN_MODE) + 2)
    @property
    def CATEGORIES_MODE(self):
        return str(int(self._MAIN_MODE) + 3)
    @property
    def SEARCH_MODE(self):
        return str(int(self._MAIN_MODE) + 4)
    @property
    def TEST_MODE(self):
        return str(int(self._MAIN_MODE) + 5)


    @property
    def FIRST_PAGE(self):
        return self._FIRST_PAGE
    _FIRST_PAGE = "1"

    @property
    def ITEMS_NOT_FOUND_INDICATORS(self):
        return self._ITEMS_NOT_FOUND_INDICATORS
    _ITEMS_NOT_FOUND_INDICATORS = []
    @property
    def REGEX_video_region(self):
        return self._REGEX_video_region
    _REGEX_video_region = '(.+)'
    @property
    def REGEX_list_items(self):
        return self._REGEX_list_items
    #no default; instance must override or see an error
    
    @property
    def REGEX_next_page_region(self):
        return self._REGEX_next_page_region
    _REGEX_next_page_region = '(.+)'
    @property
    def REGEX_next_page_regex(self):
        return self._REGEX_next_page_regex
    #no default; instance must override or see an error
    
    @property
    def REGEX_play_region(self):
        return self._REGEX_play_region
    _REGEX_play_region = '(.+)'
    @property
    def REGEX_playsearch_01(self):
        return self._REGEX_playsearch_01
    #no default; instance must override or see an error

    @property
    def REGEX_tags_region(self):
        return self._REGEX_tags_region
    _REGEX_tags_region = '(.+)'
    @property
    def REGEX_tags(self):
        return self._REGEX_tags
    _REGEX_tags = None #default is not to look for this

    @property
    def REGEX_categories_region(self):
        return self._REGEX_categories_region
    _REGEX_categories_region = '(.+)'
    @property
    def REGEX_categories(self):
        return self._REGEX_categories
    _REGEX_categories = None #default is not to look for this



    #__________________________________________________________________________
    # Which right click properties to add to icon
    # C.PLAYMODE_VARIABLE, None #adds properies such as play480, play1080
    # ""  #adds properies such as C.PLAYMODE_F4MPROXY C.PLAYMODE_INPUTSTREAM
    @property
    def Right_Click_Option(self):
        return self._Right_Click_Option
    _Right_Click_Option = C.PLAYMODE_VARIABLE

    #__________________________________________________________________________
    # Class default
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, *args, **kargs):
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args)>0): keyword = args[0]
        else                                     : keyword = ""
        Log("keyword='{}'".format(repr(keyword)))
        return keyword.replace(' ','+')
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args)>0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args)>1): keyword = args[1]
        elif (args is not None) and (len(args)>0): keyword = args[0]
        else                                     : keyword = ""
##        Log(repr(args))
##        Log(repr(kargs))
##        Log("search_url='{}'".format(repr(search_url)))
##        Log("keyword='{}'".format(repr(keyword)))
        return search_url.format(keyword, '{}')
    #__________________________________________________________________________
    # Class default
    # Change list url as neeeded by website
    def List_URL_Normalize(self, url):
        return url #do nothing by default
    #__________________________________________________________________________
    # Class default
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return url #do nothing by default
    #__________________________________________________________________________
    # Class default
    # Change video source url found in via regex with a structure used by website
    def Video_Source_URL_Normalize(self, url):
        return utils.cleantext(url) 

    #__________________________________________________________________________
    #  
    def Main(self):
        if C.DEBUG:
            utils.addDir( 
                name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
                , url = C.DO_NOTHING_URL 
                , mode = self.TEST_MODE 
                )
        if self.URL_CATEGORIES:
            utils.addDir(
                name=C.STANDARD_MESSAGE_CATEGORIES 
                ,url = self.URL_CATEGORIES
                ,mode = self.CATEGORIES_MODE
                ,iconimage=C.category_icon)
        self.List(self.URL_RECENT, page=self.FIRST_PAGE, end_directory=True, keyword='')
        utils.endOfDirectory()
    #__________________________________________________________________________
    #
    def List(self, url, page=None, end_directory=True, keyword='', testmode=False):
        Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

        (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, self.SEARCH_URL, self.SEARCH_MODE, url, page)

        list_url = self.List_URL_Normalize(list_url)

        # read html
        redirected_url = None
        full_html = utils.getHtml(list_url, referer=self.ROOT_URL+'/', ignore404=True, save_cookie=self.SAVE_COOKIES)# , send_back_redirect=True)
        if redirected_url: list_url = redirected_url

        if any(x in full_html for x in self.ITEMS_NOT_FOUND_INDICATORS):
            video_region = ''
            full_html = ''
        else: #distinguish between adverts and videos
            try:
                video_region = re.compile(self.REGEX_video_region, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
            except:
                video_region = full_html
##        Log("video_region={}".format(repr(video_region)))

        # parse out list items
        info = re.compile(self.REGEX_list_items, re.DOTALL | re.IGNORECASE).finditer(video_region)
        videourl=''
        for item in info:
##            Log("item={}".format(repr(item)))
##            Log("item={}".format(repr(dir(item))))
            videourl=item.group('videourl')
            thumb=item.group('thumb')
            label=item.group('label')
            hd=item.group('hd')
            duration=item.group('duration')
            
##            Log("hd={}".format(hd))
##            Log("duration={}".format(duration))
            hd = utils.Normalize_HD_String(hd)
            if not videourl.startswith('http'): videourl = self.ROOT_URL + videourl
            if not thumb.startswith('http'): thumb =  "https:"  + thumb
            duration = duration.replace(' min','s').replace(':','m ')
##            duration = duration.replace(' ','')
            label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
            utils.addDownLink( 
                name = label 
                , url = videourl 
                , mode = self.PLAY_MODE 
                , iconimage = thumb
                , desc='\n' + self.ROOT_URL
                , duration = duration
                , play_method = self.Right_Click_Option
                )
        utils.Check_For_Minimum(videourl, keyword, self.MAIN_MODE, self.ROOT_URL, testmode)

        if (testmode == True) and (len(videourl)>1):
##            try:
            self.Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)
##            except:
##                traceback.print_exc()


        # next page items
        try:
            next_page_html = re.compile(self.REGEX_next_page_region, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
        except:
            next_page_html = full_html
        np_info = re.compile(self.REGEX_next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
        if not np_info:
            Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
        else:
            np_number = int(page) + 1
            np_url = url
##                Log("np_url={}".format(np_url))
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=self.LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number))
                    self.List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

        utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
    #__________________________________________________________________________
    #
    def Search(self, searchUrl, keyword=None, end_directory=True, page=0):
        Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

        if not keyword:
            utils.searchDir(url=searchUrl, mode=self.SEARCH_MODE, page=page, end_directory=end_directory)
            return

##        keyword = keyword.replace(' ','+') #.replace(' ','%20')
        keyword = self.Search_Keyword_Normalize(keyword=keyword)
##        keyword = self.Search_Keyword_Normalize(keyword)        
##        searchUrl = self.SEARCH_URL.format(keyword, '{}')
##        searchUrl = self.Search_URL_Normalize(search_url=self.SEARCH_URL, keyword=keyword)
        searchUrl = self.Search_URL_Normalize(self.SEARCH_URL, keyword=keyword)
##        searchUrl = self.Search_URL_Normalize()
        Log("searchUrl='{}'".format(searchUrl))
        self.List(url=searchUrl, page=self.FIRST_PAGE, end_directory=end_directory, keyword=keyword)

        utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
    #__________________________________________________________________________
    #
    def Categories(self, url, end_directory=True):
        Log("Categories(url='{}', end_directory='{}')".format(url, end_directory))

        listhtml = utils.getHtml(url=url, referer=self.ROOT_URL, save_cookie=self.SAVE_COOKIES)
        listhtml = re.compile(self.REGEX_categories_region, re.DOTALL | re.IGNORECASE).findall(listhtml)
        if listhtml: listhtml = listhtml[0]
        else: listhtml = ''
        info = re.compile(self.REGEX_categories, re.DOTALL | re.IGNORECASE).finditer(listhtml)
        for item in info:
            videourl=item.group('videourl')
            thumb=item.group('thumb')
            label=item.group('label')
            videourl = self.Category_URL_Normalize(videourl)
            utils.addDir(
                name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
                ,url=videourl
                ,mode=self.LIST_MODE
                ,page=self.FIRST_PAGE
                ,iconimage=thumb
                )

        utils.endOfDirectory(end_directory=end_directory)
    #__________________________________________________________________________
    #
    def Test(self, keyword=None, end_directory=False):
        Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))

        #force user to specify a keyword to search for because not all searches will 'succeed' or 'fail' reliably
        if not keyword:
            prev_keyword = C.addon.getSetting(id='quick_search_string')
            keyword = utils._get_keyboard( heading="Search query", default=prev_keyword  )
            if  keyword == '' :
                return False, 0  ## if blank or the user cancelled the keyboard, return
            C.addon.setSetting(id='quick_search_string', value=keyword)
        self.Categories(self.URL_CATEGORIES, False)
        self.Search(searchUrl=self.SEARCH_URL, keyword=keyword, end_directory=False, page=self.FIRST_PAGE)
        self.List(self.URL_RECENT, page=self.FIRST_PAGE, end_directory=False, keyword='', testmode=True)

        if end_directory:
            utils.addDir(
                    name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, self.ROOT_URL)
                    ,url=C.DO_NOTHING_URL
                    ,mode=C.NO_ACTION_MODE
                    )
        
        utils.endOfDirectory(end_directory=end_directory)
    #__________________________________________________________________________
    #
    def Playvid(self, url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
        if playmode_string and playmode_string[0].isdigit():
            max_video_resolution=int(playmode_string)
        else: max_video_resolution = None
        description = name + '\n' + self.ROOT_URL
        video_url = None

        full_html = utils.getHtml(url, self.ROOT_URL, save_cookie=self.SAVE_COOKIES )
##        Log("type(full_html)='{}'".format(type(full_html)))
        
        #
        #sometimes the video was deleted
        #
        if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,self.ROOT_URL))
            Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
            return

        #
        #sometimes it is usefull to only look in one part of the page
        #
        if self.REGEX_play_region:
            source_html = re.compile(self.REGEX_play_region, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
        else:
            source_html = full_html
##        Log("type(source_html)='{}'".format(type(source_html)))

        #
        #sometime the page itself contains direct video file links
        #
        if C.FLAG_USE_RESOLVER_ONLY not in self.REGEX_playsearch_01:
            sources_list = re.compile(self.REGEX_playsearch_01, re.DOTALL | re.IGNORECASE).finditer(source_html)
    ##        Log("sources_list='{}'".format(repr(sources_list)))
    ##        Log("type(sources_list)='{}'".format(type(sources_list)))
            if (type(sources_list) != 'str'):
##                Log("list with items (res,url)")
                videos_list = list()
                for source in sources_list:
    ##                Log("source='{}'".format(repr(source)))
    ##                Log("type(source)='{}'".format(type(source)))
    ##                Log("source.groups='{}'".format(repr(source.groups)))
    ##                Log("dir(source)='{}'".format(dir(source)))
    ##                Log(" dir(source.group)='{}'".format(dir(source.group)))
    ##                Log("dir(source.groups)='{}'".format(dir(source.groups)))
    ##                Log("dir(source.groupdict())='{}'".format(dir(source.groupdict())))
                    if 'json' in source.groupdict():
                        sources_list = source.group('json')
    ##                    Log("sources_list='{}'".format(repr(sources_list)))
    ##                    Log("type(sources_list)='{}'".format(type(sources_list)))
                        break
                    videos_list.append(  (  source.group('res') , self.Video_Source_URL_Normalize(source.group('url') ) ) )

            if len(videos_list) < 1: #must be json
                Log("convert json to a list; with items (res,url)")
                json_sources = json.loads(sources_list)
    ##            Log("json_sources='{}'".format(repr(json_sources)))
                list_key_value = {} ##[] #dict()
                for json_src in json_sources:
                    if 'videoUrl' in json_src:
            ##            Log("json_src={}".format(json_src['videoUrl']))
                        if json_src['videoUrl'] != '':
                            #list_key_value[json_src['quality']] = json_src['videoUrl']
                            videos_list.append( (json_src['quality'], json_src['videoUrl'] ) )
    ##            videos_list = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function


    ##        Log("videos_list='{}'".format(repr(videos_list)))
            video_url = utils.SortVideos(
                sources=videos_list
                ,download=download
                ,vid_res_column=0
                ,max_video_resolution=max_video_resolution
                )
            

        #
        #sometime the page can only be resolved by another tool
        #
        if C.FLAG_USE_RESOLVER_ONLY in self.REGEX_playsearch_01:
            from resources.lib import resolver
            video_url = resolver.resolve_video(videosource=source_html, name=name, download=download, url=url)


        #
        #sometime the page has a list of actors
        #            
        if self.REGEX_tags_region is not None:
            description = ''
            desc_separator_char = '; '
            region_html = re.compile(self.REGEX_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
            if region_html:
                source_tags = re.compile(self.REGEX_tags, re.DOTALL | re.IGNORECASE).findall(region_html[0])
                for tag in source_tags:
                    if tag.lower() not in description.lower():
                        description = "{}{}{}".format(description,utils.cleantext(tag),desc_separator_char)
            description = description.strip(desc_separator_char)
            if description == '':  description=name + '\n' + self.ROOT_URL
            else:           description=description + '\n' + self.ROOT_URL
            Log("description={}".format(description))


        if not video_url:
            if testmode:
                raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, self.ROOT_URL))
            else:
                utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, self.ROOT_URL))
            return
        
        #
        #always set referrer so that 'kodi' does not appear on the target server
        # 
        if '|' not in video_url:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = url
            video_url = video_url + utils.Header2pipestring(headers)

        Log("video_url='{}'".format(video_url))
        if testmode:
            Log("Would have played video_url; but in test mode")
            return   #during testmode, only ensure that a url can be generated

        utils.playvid(video_url, name=name, download=download, description=description, playmode_string=playmode_string, play_profile=play_profile)
    #__________________________________________________________________________
    #

