'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C


FRIENDLY_NAME = '[COLOR {}]jav.guru[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_MOVIES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://jav.guru"
SEARCH_URL = ROOT_URL + '/page/{}/?s={}'
URL_RECENT = ROOT_URL + '/page/{}/'

MAIN_MODE       = C.MAIN_MODE_javguru
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1' #default first page

#__________________________________________________________________________
#

@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(name="{}[COLOR {}]English Subbed[/COLOR]".format( 
                C.SPACING_FOR_TOPMOST, C.search_text_color) 
                ,url = SEARCH_URL
                ,mode = SEARCH_MODE
                ,keyword="English Subbed"
                ,page=FIRST_PAGE 
                ,iconimage=C.search_icon )
    utils.addDir(name="{}[COLOR {}]Uncensored[/COLOR]".format( 
                C.SPACING_FOR_TOPMOST, C.search_text_color) 
                ,url = 'https://jav.guru/category/jav-uncensored/page/{}/'
                ,mode = LIST_MODE
                ,page=FIRST_PAGE 
                ,iconimage=C.search_icon )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List [url='{}', page='{}', end_directory='{}', keyword='{}']".format(url,page,end_directory,keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    #
    # read html
    #
    listhtml = utils.getHtml(list_url)
    if any(x in listhtml for x in ["I can't find porn to your request", "Sorry, nothing good matched"]) :
        listhtml = ""
        video_region = ""
    else:    #distinguish between adverts and videos
        regex = 'id="main"(.*)class="paging-navigation"'
        video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
        if video_region:
            video_region=video_region[0]
        else:
            video_region=''

    #
    # parse out list items
    #
    regex = '<article.+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    regex = 'class="inside-article".+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label in info:
        desc = utils.cleantext(label)
        name = utils.cleantext(label.split(']')[-1]).strip()
        name = "{}{}".format(C.SPACING_FOR_NAMES, name)
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log(u"desc={}".format(desc.decode('utf8')))
        utils.addDownLink( 
            name = name 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc = "{}\n{}".format(desc,ROOT_URL)
            )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
        
    #
    # next page items
    #
    next_page_regex = "class=(?:'pages'|\"pagination\").+?class=(?:'|\")current(?:'|\")>(\d+)<"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info: Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url in np_info:
        np_url = url
        np_number=int(page)+1
        #Log("np_url={}".format(np_url))
        #Log("np_number={}".format(np_number))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format('{}',keyword) 
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=page, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))        
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    listhtml = utils.getHtml(url, '')
 
    regex = '<a href="([^"]+)"[^<]+<img src="([^"]+)" alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("thumb={}".format(thumb))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb )
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
##    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    source_html = utils.getHtml(url, ROOT_URL)

    regex_model_area = 'Actress:(.+)Studio'
    models_html = re.compile(regex_model_area, re.DOTALL | re.IGNORECASE).findall(source_html)
    if models_html: models_html=models_html[0]
    else: models_html = ''
    regex_model = '/actress/.+?rel="tag">(?P<model>[^<]+)<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(models_html)
    description = ''
    desc_separator_char = '; '
    if source_models:
        for model in source_models:
            description = description + desc_separator_char + model.group('model')
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))

    headers = C.DEFAULT_HEADERS.copy()
    headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    
    regex_vid_sources = '","iframe_url":"([^"]+)"'
    vid_sources = re.compile(regex_vid_sources, re.DOTALL | re.IGNORECASE).findall(source_html)
    source_html = ''
    sources = {}
    import base64
    for vid_source in vid_sources:
        Log("vid_source={}".format(vid_source))
        src = base64.b64decode(vid_source).split('&bg=')[0]
        Log("src={}".format(src))
        if 'd=' in src:
            src_forward = src.split('d=')[1]
            src_reverse = src.split('d=')[0] + 'r=' + src_forward[::-1]
        else:
            if '?bg=' in src:
                src_reverse = src.split('?bg=')[0]
##        Log("src_forward={}".format(src_forward))
        Log("src_reverse={}".format(src_reverse))
        headers['Referer'] = src
        url = src_reverse
        locker_html, locker_url = utils.getHtml(url, headers=headers, send_back_redirect=True)
        Log("locker_url={}".format(locker_url))
        if not locker_url:
            locker_url = url
        source_html = source_html + locker_url + "  "

    if source_html == '':
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return
##    if not video_url.startswith('http'): video_url = 'https:' + video_url

##    Log("source_html={}".format(source_html))

    from resources.lib import resolver
    video_url = resolver.resolve_video(videosource=source_html, name=name, download=download, url=url)
    Log("video_url={}".format(video_url))
    if not video_url:
        utils.Notify("No video file found for {}".format(name))
        return
    utils.playvid(video_url, name=name, download=download, description=description)

#__________________________________________________________________________
#
