'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log

class Specific_Website(Base_Website):
    
    _FRIENDLY_NAME = '[COLOR {}]Bubbaporn[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = True

    _ROOT_URL           = "https://www.bubbaporn.com"
##    _URL_RECENT         = _ROOT_URL + '/ajax/homepage/?page={}'
    _URL_RECENT         = _ROOT_URL + '/page{}.html'
    _URL_CATEGORIES     = _ROOT_URL + '/channels/'
##    _SEARCH_URL         = _ROOT_URL + '/ajax/new_search/?q={}&page={}'
    _SEARCH_URL         = _ROOT_URL + '/search/page{}.html?q={}'

    _MAIN_MODE = C.MAIN_MODE_bubbaporn

    _FIRST_PAGE = '1' #Note:site does not support page1.html

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = '(.+)'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        ]

    #videos on this page    
    _REGEX_list_items = (
        'box-escena.+?href="(?P<videourl>[^"]+)"'
        '.+?data-stats-video-name="(?P<label>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?duracion">(?P<duration>[^<]+)<'
        '(?P<hd>)'
        )

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'data-ajax-url="([^"]+)"'
    _REGEX_next_page_regex =   '(.+)'

    #where categories can be found
    _REGEX_categories_region = "(.+)"
    _REGEX_categories = (
        '<img src="(?P<thumb>[^"]+)"'
        '[^<]+<[^"]+"(?P<videourl>[^"]+)"'
        '>(?P<label>[^<]+)<'
        )

    #where playable urls live
    _REGEX_playsearch_01 = (
        '(?P<res>\d)'
        '.+?<source src="(?P<url>[^"]+)"'
        )

    #description for the playable url
    _REGEX_tags = (
        "href='/pornstar/.+?>([^<]+)<"
        )
    _REGEX_tags_region = '<div id="data-video">(.+?)<div class="clear">'


    #__________________________________________________________________________
    # Change list url as neeeded by website
    def List_URL_Normalize(self, url):
        #even though 2nd page uses the .html, first page will not; no page # works thouth 
        return url.replace('page1.html', '')

    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        #even though 2nd page uses the .html, first page will not; no page # works thouth 
        return self.ROOT_URL + url + 'page{}.html'

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args)>0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args)>1): keyword = args[1]
        elif (args is not None) and (len(args)>0): keyword = args[0]
        else                                     : keyword = ""
        return search_url.format('{}',keyword)

#__________________________________________________________________________
#
website = Specific_Website() #always need this
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    website.Playvid(url, name, download, playmode_string)
#__________________________________________________________________________
#
