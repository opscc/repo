'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import traceback
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C


FRIENDLY_NAME = '[COLOR {}]Beeg[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_SCENES
FRONT_PAGE_CANDIDATE = True

ROOT_URL = "https://beeg.com"
SEARCH_URL = ROOT_URL #fake; will use the other SEARCH* items # + '/api/v6/'+C.addon.getSetting('bgversion')+'/index/main/{}/pc?query={}'
URL_RECENT = ROOT_URL + '/api/v6/'+C.addon.getSetting('bgversion')+'/index/main/{}/pc'
URL_CATEGORIES = URL_RECENT 
#                                                                            /index/tag/0/pc?tag=juicy	
#SEARCH_TAGS_URL     = ROOT_URL + '/api/v6/'+C.addon.getSetting('bgversion')+'/index/tag/{}/pc?search_mode=code&tag={}'
SEARCH_TAGS_URL     = ROOT_URL + '/api/v6/'+C.addon.getSetting('bgversion')+'/index/tag/{}/pc?tag={}'
SEARCH_CHANNELS_URL = 'https://api.beeg.com' + '/api/v6/'+C.addon.getSetting('bgversion')+'/index/channel/{}/pc?channel={}'
SEARCH_PEOPLE_URL   = ROOT_URL + '/api/v6/'+C.addon.getSetting('bgversion')+'/index/people/{}/pc?search_mode=code&people={}'

MAIN_MODE          = C.MAIN_MODE_beeg
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '0' #default first page

#__________________________________________________________________________
#

def Version():

    #bgpage = utils.getHtml(ROOT_URL,'')
    #bgversion = re.compile("var beeg_version = (\d+);", re.DOTALL | re.IGNORECASE).findall(bgpage)[0] #2019-05-03
    bgversion = "1593627308202" #2020-07-03 info is hard coded in a .js file now
    bgversion = "1609860730705"     
    bgsavedversion = C.addon.getSetting('bgversion')
    if bgversion <> bgsavedversion: #or not bgsalt:
        C.addon.setSetting('bgversion',bgversion)
    return bgversion

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    bgversion = Version()
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List [url='{}', page='{}', end_directory='{}', keyword='{}']".format(url,page,end_directory,keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    bgversion = C.addon.getSetting('bgversion')

    if url.count('{}') == 1:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))
    listjson = utils.getHtml(url=list_url, referer=list_url, ignore404=True)
    Log("listjson='{}'".format(listjson))
    if "Index not found." in listjson  or   '"pages":0' in listjson:
        json_urls = json.loads('{"pages":0, "videos":[]}') # avoid having to check for nulls in later code
        if   '/tag/'     in list_url : detail = 'tag/'
        elif '/channel/' in list_url : detail = 'channel/'
        elif '/people/'  in list_url : detail = 'people/'
        else: detail = ''
        utils.Check_For_Minimum(json_urls['videos'], detail+keyword, MAIN_MODE, ROOT_URL, testmode)
    else:
        json_urls = json.loads(listjson)
    Log("json_urls={}".format(repr(json_urls)))

    for viditem in json_urls['videos']:
##        Log("viditem={}".format(viditem), xbmc.LOGNONE)
        if not viditem['title']: viditem['title'] = viditem['ps_name']
        label = utils.cleantext(C.html_parser.unescape(viditem['title']))
        if 'quality' in viditem: hd = str(viditem['quality']).lower()
        else: hd = ""
        hd = utils.Normalize_HD_String(hd)

        label = "{}{}{}".format(C.SPACING_FOR_NAMES, label, hd)
        #thumb = "https://img.beeg.com/236x177/" + str(viditem['id']) +  ".jpg"
        if viditem['thumbs']:
            if not viditem['thumbs'][0]['crops'] == None:
                if viditem['thumbs'][0]['crops']['4x3']['left'] : # if not null
                    thumb = "https://img.beeg.com/264x198/{}/{}x{}x{}x{}/{}".format(
                        '4x3'
                        ,viditem['thumbs'][0]['crops']['4x3']['left']
                        ,viditem['thumbs'][0]['crops']['4x3']['top']
                        ,viditem['thumbs'][0]['crops']['4x3']['width']
                        ,viditem['thumbs'][0]['crops']['4x3']['height']
                        ,viditem['thumbs'][0]['image'])
                else:
                    thumb = "https://img.beeg.com/264x198/{}/{}".format(
                        '4x3'
                        ,viditem['thumbs'][0]['image'])                            
                #https://img.beeg.com/264x198/4x3/45x0x960x720/20072-0169.jpg
            else:
                thumb = "https://img.beeg.com/264x198/{}/{}".format(
                    '4x3'
                    ,viditem['thumbs'][0]['image'])
            vid_start = viditem['thumbs'][0]['start']
            if not vid_start: vid_start = 0
            vid_end = viditem['thumbs'][0]['end']
            if not vid_end: vid_end = viditem['duration']
            if not vid_end: vid_end = 0 #sometimes wil not even have a value for this!
            duration = '{}s'.format(vid_end-vid_start)
            videourl = ROOT_URL + "/api/v6/{}/video/{}?v=2&s={}&e={}".format(bgversion, viditem['svid'] , vid_start, vid_end )
            utils.addDownLink( 
                name = label 
                , url = videourl 
                , mode = PLAY_MODE 
                , iconimage = thumb
                , desc='\n' + ROOT_URL
                , duration = duration 
                )
        else:
            thumb = ""
            vid_start = 0
            vid_end = 0
            duration = '0s'
        
    # next page items
    page = int(page)
    if  page >= (int(json_urls['pages'])-1)  :
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_number = page + 1
        np_url = url
        #Log("np_label='{}'".format(np_label))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(int(np_number+1))
                ,url = np_url 
                ,mode = LIST_MODE 
                ,iconimage = C.next_icon 
                ,page = np_number 
                ,section = C.INBAND_RECURSE
                ,keyword = keyword
                )
        else:
            if np_number <= max_search_depth:
                utils.Notify(msg=np_url.format(np_number))
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))
    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','').replace('+','')
    searchUrl = SEARCH_TAGS_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))    
    List(url=searchUrl, page=FIRST_PAGE, end_directory=False, keyword=keyword)
    searchUrl = SEARCH_PEOPLE_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))    
    List(url=searchUrl, page=FIRST_PAGE, end_directory=False, keyword=keyword)
    searchUrl = SEARCH_CHANNELS_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))    
    List(url=searchUrl, page=FIRST_PAGE, end_directory=False, keyword=keyword)
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page) == '-1'))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    url = url.format(FIRST_PAGE)
    listjson = utils.getHtml(url=url, referer=url)
    json_urls = json.loads(listjson)
    for tag_item in json_urls['tags']:
        tag = tag_item['tag']
        #Log("tag={}".format(tag))
        videourl = SEARCH_TAGS_URL.format('{}', tag.replace(' ','%20'))
##        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, C.search_text_color, tag) 
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(tag))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=C.search_icon
            ,page=FIRST_PAGE
            )
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
        
    videopage = utils.getHtml(url, ROOT_URL)
    #Log("videopage={}".format(videopage))
    
    json_sources = json.loads(videopage)

    list_key_value = {}
    for json_source in json_sources:
        #Log("json_source={}".format(json_source))
        #Log("json_source={}".format(json_sources['sources']['mp4'][json_source]['src']))
        q = json_source
        v = json_sources[json_source]
        q_int = re.search(r'\d+', q)
        if q_int: q_int = int(re.search(r'\d+', q).group())
        if v and not v == "" and type(q_int) == int: #not blank, null and an integer
            list_key_value[str(q_int)] = v
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )
##    Log("video_url={}".format(video_url))

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return

    video_url = video_url.replace("{DATA_MARKERS}","data=pc_XX__{}_".format(json_sources['bundle_version'] ))
    if not video_url.startswith("http:"): video_url = "https:" + video_url
##    Log("video_url={}".format(video_url))
    video_url = video_url + utils.Header2pipestring()+"&Referer=" + ROOT_URL

    #
    #description information
    #    
    Log(repr(json_sources), xbmc.LOGNONE)
    #normalize a few things to avoid indents later on
    if not("cast" in json_sources):
        json_sources["cast"] = None
    if not("cast_ext" in json_sources):
        json_sources["cast_ext"] = []
    if json_sources["cast_ext"] is None:
        json_sources["cast_ext"] = []
    if not("ps_name" in json_sources):
        json_sources["ps_name"] = ''
    desc_separator_char = '; '
    description = json_sources["cast"]
    if description is None: #info not here, try ...
        description = ''
        for model in json_sources["cast_ext"]:
##            Log(repr(model))
            model = model["name"]
            if model.lower() not in description.lower():
                description = description + utils.cleantext(C.html_parser.unescape(model)) + desc_separator_char
    description = description.strip(desc_separator_char)

    if download:
        #site does not always have good video names, compensate by adding cast info
        name_separator_char = '.'
        name = description + name_separator_char + name + name_separator_char + json_sources["ps_name"]
        name = name.strip(name_separator_char)
        Log(name, xbmc.LOGNONE)

    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log(u"description={}".format(description.decode("utf8")))


##    return

    utils.playvid(video_url, name, download, description=description)

    return

#__________________________________________________________________________
#
