'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]ah-me[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.ah-me.com"
SEARCH_URL = ROOT_URL + '/search/{}/page{}.html'
URL_CATEGORIES = ROOT_URL + '/channels/'
URL_RECENT = ROOT_URL + '/most-recent/page{}.html'

MAIN_MODE       = C.MAIN_MODE_ah_me
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1' #default first page

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if "<p>Make sure that all words are spelled correctly.</p>" in listhtml:
        listhtml = ''
        video_region = ''
    else: #distinguish between adverts and videos
        try:
            regex = '(?:class="pages-nav-border"|id="search_results_block")(.+?)(?:class="pages-nav"|id="wrapBlocks")'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml

    # parse out list items
    regex = 'data-movie.+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)".+?((?:class="icon-hd"|class="to-fav)).+?class="time">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, hd, duration in info:
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label={}".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
        

    #
    # next page items
    #
    try:
        regex = 'class="pages-nav">(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = 'href="([^"]+)\.html">Next<'  #site will use display:none if no more pages exist instead of omitting the Next element
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else: #for np_url in np_info:
##            Log("np_url={}".format(np_url))
##        np_url = C.html_parser.unescape(np_url)
###            Log("np_url.split('/')={}".format(np_url.split('/')))
##        np_number = '' 
##        if '/' in np_url: np_url = np_url.strip('/').split('/')[-1]
##        Log("np_url={}".format(np_url))
##        if '?page=' in np_url: np_number = np_url.split('?page=')[1]
##        if '&page=' in np_url: np_number = np_url.split('&page=')[1]
##        if 'page' in np_url: np_number = np_url.split('page')[1]
###            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
        np_number = int(page)+1
        np_url = url
        Log("np_number={}".format(np_number))
        Log("np_url={}".format(np_url))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)
    regex = 'class="thumbs-container"(.+)class="footer'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    regex = '<a href="([^"]+)page1\.html".+?src="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
##        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, C.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = videourl + '/page{}.html'
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb) #C.search_icon)
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL

    source_html1 = utils.getHtml(url, ROOT_URL)
#    source_html1 = ',"mediaDefinitions":[{"defaultQuality":true,"format":"","quality":"720","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/720P_1500K_18335131.mp4?0idsYiD-jh4q8NCS0v6iC1R4SAvv9m-WqnqgA6QzCKeNUJDGO0ciQkPcv4LJoOhew2wWEAC9YYOXyjV9PcTKi3ORzGohLfp1w3G8b_JlOHa10127jyitWfiJ5v8yjGiLVtt2SaTCU0Lsm4k70rkKP5Gy9YFytRi6xQRA4Wabo9WmcJ_P_1Fx0jDk0ou7LTiqlJ5LMLnZw0rQEEJ1"},{"defaultQuality":false,"format":"","quality":"480","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/480P_600K_18335131.mp4?tkV8JplE8wnw9uFa8936-HctKRAu0uOgmukr-_x2SZ6-pa3CHzujAQaO8hXeUfnqK9VpiEKx88u4-MWns7sAIkg8I3XB1NeLT2PXLYf4ugY_-9wTqm-uh0dQD94l4cNzuL1d7o2IQ-PxweNWVKv9hGOQcevk7BnGAxJ7dSla2jXUjfQt0BSbTpxxyrTBtBZmBRoEE8hB5HXhIw"},{"defaultQuality":false,"format":"","quality":"240","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/240P_400K_18335131.mp4?STGBmiZrtxfV2QjInJOYcX1LyZEQmXVjos6jS4pRDHosxZXN3JvlNrY0f_96RbC94YLDrkRiyLidn7MpRlLqIzOScqQtx9aU5ruyvBOx0PnpZmtNHiDljbyOaY_sDvBugfGT21tHRqs-Js9Alb9V8AqkCoDcuo1nFVB0qZu8qpvJzczAvXvwVPVR1GB3ypqczItFjAaCAFLdtg"}],'
    regex = 'data-src="([^"]+\.(?:mp4|flv))"'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
    Log("sources_list={}".format(sources_list))
    video_url = sources_list[0]

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))
##    return
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
