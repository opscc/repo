'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream, hdgdl
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sqlite3
import time
import xbmc
#import xbmcgui
import json

from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

SPACING_FOR_TOPMOST = C.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  C.SPACING_FOR_NAMES
SPACING_FOR_NEXT = C.SPACING_FOR_NEXT
#MAX_SEARCH_DEPTH = C.DEFAULT_RECURSE_DEPTH

FRIENDLY_NAME = '[COLOR {}]Naked.com[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.naked.com"
SEARCH_URL = 'stub - make all sites consistent'
URL_FEMALES = ROOT_URL + "/live/girls/"
RESULTS_PER_PAGE = 0

MAIN_MODE       = '480'
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
REFRESH_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():

    List(URL_FEMALES, page=FIRST_PAGE, end_directory=True, keyword='')

#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page=1, depth=1, notify=False):

    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    if '{}' in url and page: list_url = url.format((int(page)-1)*RESULTS_PER_PAGE)
    else: list_url = url

    i = 0

    json_items = json.loads("{}")

    data = utils.getHtml(list_url, '')

    #Log(data, xbmc.LOGNONE)

    
    regex = 'window.__homePageData__ = ({.+?});\s+?</script>'
    regex = "'models':\s\[\s+?({.+}),\s+\],\s+'favorites':\s\["
    html_models = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(data)[0]

##    Log(html_models, xbmc.LOGNONE)

    html_models = '{ "models": [' + html_models + ']}'
##    Log(html_models, xbmc.LOGNONE)
    json_models = json.loads(html_models)
##    Log(repr(json_models), xbmc.LOGNONE)

    for model in json_models["models"]:
##        Log(repr(model), xbmc.LOGNONE)
        model_id = model["model_id"]
        seo_name = model["model_seo_name"]
        video_host = model["video_host"]
        icon_image = "https://live-screencaps.vscdns.com/{}-desktop.jpg".format(model_id)
        video_url = (
            "{}/webservices/chat-room-interface.php?a=login_room&model_id={}".format( \
                   ROOT_URL, model_id)
               )
        camscore = int(model["num_users"])
        hd = model["video_width"]
        if hd:
            hd = str(hd.split('x')[0])
        else:
            hd = ''
        if   '4k' in hd :
            camscore=camscore*10
            hd = " [COLOR {}]uhd[/COLOR]".format(C.refresh_text_color)
        elif '1920' in hd :
            camscore=camscore*5
            hd = " [COLOR {}]fhd[/COLOR]".format(C.refresh_text_color)
        elif '1280' in hd :
            camscore=camscore*2
            hd = " [COLOR {}]hd[/COLOR]".format(C.time_text_color)
        elif '1152' in hd :
            camscore=camscore*1
            hd = " [COLOR {}]hd[/COLOR]".format(C.time_text_color)
        else:
            hd = ""
        icon_label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(seo_name), hd)

        json_item = {}
        json_item['username'] = seo_name
        json_item['icon_label'] = icon_label
        json_item['icon_image'] = icon_image
        json_item['video_url'] = video_url
        json_item['camscore'] = camscore
        json_item['mode'] = PLAY_MODE
        json_item['description'] = '\n' + ROOT_URL
        json_item['play_method'] = ''
        json_item['video_host'] = video_host

        if model['room_status_char'] == 'O':
            json_items[json_item['username']] = json_item
        
##        Log(repr(json_item), xbmc.LOGNONE)
##        Log("json_items='{}'".format(json_items),xbmc.LOGNONE)
##        i += 1
##        if i> 10:
####            Log("json_items='{}'".format(json_items),xbmc.LOGNONE)
##            return json_items 
        


    return json_items
    


##    hq_bonus = int(C.addon.getSetting("hq_bonus").lower())

    #regex = 'data-model-id="([^"]+)".+?data-model-name="([^"]+)".+?data-model-seo-name="([^"]+)".+?data-video-host="([^"]+)".+?data-live-image-src="([^"]+)"'
    #regex = 'data-model-id=\\\\"([^"]+)\\\\"data-model-name=\\\\"([^"]+)\\\\"data-model-seo-name=\\\\"([^"]+)\\\\".+?data-video-host=\\\\"([^"]+)\\\\".+?data-live-image-src=\\\\"([^"]+)\\\\"' #before ~2020-12-12
    #regex = '"video_host":"([^"]+)".+?"video_width":"([^"]+)".+?"power_score":"([^"]+)".+?"model_id":"([^"]+)".+?"image":"([^"]+)".+?"model_name":"([^"]+)".+?"model_seo_name":"([^"]+)"'
    regex = '"video_host":"([^"]+)".+?"video_width":"([^"]+)".+?"power_score":"([^"]+)".+?"model_id":"([^"]+)".+?"image":"([^"]+)".+?"model_name":"([^"]+)".+?"model_seo_name":"([^"]+)"'
    model_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(data)
    for video_host, hd, camscore, model_id,  icon_image, name, seo_name in model_list:
##        Log(seo_name, xbmc.LOGNONE)
##        icon_image = icon_image.replace("\/", "/")
        icon_image = "https://live-screencaps.vscdns.com/{}-desktop.jpg".format(model_id)
##        Log(icon_image, xbmc.LOGNONE)
##        Log(hd, xbmc.LOGNONE)
        #name = model
        #videourl = "https://www.naked.com/?model="+name
        #utils.addDownLink(name, videourl, PLAY_MODE, img, '', noDownload=True)
        video_url = (
            "{}/webservices/chat-room-interface.php?a=login_room&model_id={}".format( \
                   ROOT_URL, model_id)
               )
        camscore = int(camscore)
        if camscore == 0: camscore = 1
        camscore = int(camscore/100)
        #hd = ""
        if hd:
            hd = str(hd.split('x')[0])
        else:
            hd = ''
        if   '4k' in hd :
            camscore=camscore*10
            hd = " [COLOR {}]uhd[/COLOR]".format(C.refresh_text_color)
        elif '1920' in hd :
            camscore=camscore*5
            hd = " [COLOR {}]fhd[/COLOR]".format(C.refresh_text_color)
        elif '1280' in hd :
            camscore=camscore*1
            hd = " [COLOR {}]hd[/COLOR]".format(C.time_text_color)
        elif '1152' in hd :
            camscore=camscore*1
            hd = " [COLOR {}]hd[/COLOR]".format(C.time_text_color)
        else:
            hd = ""
        icon_label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(seo_name), hd)            

##        if not(name == utils.cleantext(seo_name)):
##            Log("seo_name '{}' '{}' '{}'".format(name,seo_name, utils.cleantext(seo_name)))

##        json_item = {}
##        json_item['username'] = seo_name
##        json_item['icon_label'] = icon_label
##        json_item['icon_image'] = icon_image
##        json_item['video_url'] = video_url
##        json_item['camscore'] = camscore
##        json_item['mode'] = PLAY_MODE
##        json_item['description'] = '\n' + ROOT_URL
##        json_item['play_method'] = 'f4mproxy'
##        json_item['video_host'] = video_host
##        json_items.append(json_item)

##        Log(str(camscore), xbmc.LOGNONE)
        
        json_item = {}
        json_item['username'] = seo_name
        json_item['icon_label'] = icon_label
        json_item['icon_image'] = icon_image
        json_item['video_url'] = video_url
        json_item['camscore'] = camscore
        json_item['mode'] = PLAY_MODE
        json_item['description'] = '\n' + ROOT_URL
        json_item['play_method'] = ''
        json_item['video_host'] = video_host
        json_items[json_item['username']] = json_item
        
##        Log(json_item, xbmc.LOGNONE)
##        Log("json_items='{}'".format(json_items),xbmc.LOGNONE)
##        Log(json_items[seo_name], xbmc.LOGNONE)
##        i += 1
##        if i> 10:
##            Log("json_items='{}'".format(json_items),xbmc.LOGNONE)
##            return json_items        

##    Log("json_items='{}'".format(json_items),xbmc.LOGNONE)
    return json_items

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page='{}', end_directory='{}', keyword='{}')".format(url, page, end_directory, keyword))
    
    if end_directory == True:    
        utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
            C.SPACING_FOR_TOPMOST, C.refresh_text_color) 
            ,url='' 
            ,mode=REFRESH_MODE 
            ,iconimage=C.refresh_icon)


    models = GetCamgirlList(url, page)
    for model in models:
        utils.addDownLink( 
            name = models[model]['icon_label'] 
            , url = models[model]['video_url'] 
            , mode = models[model]['mode'] 
            , iconimage = models[model]['icon_image']
            , duration = models[model]['camscore']
            , play_method = models[model]['play_method']
            , desc = models[model]['description']
            , hq_stream = models[model]['video_host'] #used to carry this info special to this provider; some links need this for some reason; maybe a dead server on day of programming?
            )
    #
    # check for a minimum during tesing
    #
    if len(models) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError


    #
    # no next page at this time
    #
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')
    
#__________________________________________________________________________
#
def clean_database(showdialog=False):

    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".vscdns.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try:
                    os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except:
                    pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".vscdns.com")
            if showdialog:
                utils.notify('Finished','naked.com images cleared')
    except:
        pass

#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download', 'play_profile', 'hq_stream'])
def Playvid(url, name, playmode_string = '', download = False, play_profile=0, hq_stream=None):
    
    Log ("Playvid url='{}', name='{}', playmode_string='{}', play_profile='{}', download='{}', data_video_host='{}'".format(url, name, playmode_string, play_profile, download, hq_stream), xbmc.LOGNONE  )

    #used to carry this info special to this provider; some links need this for some reason; maybe a dead server on day of programming?
    data_video_host = hq_stream
    

    #
    # do stuff to get a playable url
    #

    json_html = utils.getHtml(url=url, referer=ROOT_URL, headers = C.DEFAULT_HEADERS)
    Log("json_html='{}'".format(json_html)  )
    json_info = json.loads(json_html)
    Log("json_info='{}'".format(json_info)  )

    if json_info['status'] == 'failed':
        utils.Notify("{} is unavailable".format(name))
        return
    if json_info['config']['room']['status'] != 'O':
        utils.Notify("{} is private".format(json_info['config']['performer']['name_seo']))
        return
    
    params = json_info['params']
    Log("params='{}'".format(params))
    import base64
    params = base64.b64decode(params)
    Log("params='{}'".format(params))

    name_seo = json_info['config']['performer']['name_seo']


    model_id = params.split('model_id=')[1].split('&')[0]
    Log("model_id='{}'".format(model_id))
    if data_video_host:
        video_host = data_video_host
    else:
        video_host = params.split('video_host=')[1].split('&')[0]
    Log("video_host='{}'".format(video_host))

    url = (
        "{}/webservices/live-chat.php?a=get_cdn_info2&model_id={}&video_codec=4&video_host={}&user_id=0&t={}".format( \
               ROOT_URL, model_id, video_host, str(int(time.time()*1000)))
           )

    json_html = utils.getHtml(url=url, referer=ROOT_URL, headers = C.DEFAULT_HEADERS)
    Log("json_html='{}'".format(json_html)  )
    json_info = json.loads(json_html)

    import random
    provider = random.choice(json_info["hls"]["providers"])
    #provider = json_info["hls"]["providers"][2]
##    Log("provider='{}'".format(provider)  )
    video_url = ( "https://" 
                  + provider['stream_host'] 
                  + "/"
                  + provider['stream_name']
                  + "?key=" 
                  + provider['stream_key'] 
                  )
    naked_headers = {
                    'User-Agent': C.USER_AGENT
                    ,'Accept': "*/*"
                    ,'Referer': "{}/?model={}".format(ROOT_URL, name_seo )
                    ,'Accept-Encoding': 'gzip'
                    ,'Accept-Language': 'en-US,en;q=0.9'
                    }
#    Log("naked_headers='{}'".format(naked_headers) , xbmc.LOGNONE )



    playmode_string = C.PLAYMODE_INPUTSTREAM #for this site need to use this because it is best with a good encryption routine, which I don't have

    video_url = "{}{}".format(video_url, utils.Header2pipestring(naked_headers) )
    Log("video_url='{}'".format(video_url)  )
##    utils.playvid(video_url, name, download, description=ROOT_URL, playmode_string=playmode_string, play_profile=play_profile)

    from resources.lib import downloader
    download_filespec = downloader.Make_download_path(name = name, include_date = True, file_extension = '.ts')

    utils.playvid(video_url, name, download, description=ROOT_URL, playmode_string=playmode_string, play_profile=play_profile, download_filespec=download_filespec )

    return
    
##
##    #
##    # play url as needed
##    #
##
##    Log("video_url='{}'".format(video_url)  )
##
##    iconimage = xbmc.getInfoImage("ListItem.Thumb")
##    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
##    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
##    listitem.setContentLookup(False)
##
####    max_bit_rate = C.MAX_BIT_RATE  + int((int(play_profile)) * 1000 * 1000)
####    max_bit_rate_download = C.MAX_BIT_RATE  + int((int(play_profile) + 0.25) * 1000 * 1000)
##
##    if playmode_string == C.PLAYMODE_F4MPROXY:
##        pass
##    elif playmode_string == C.PLAYMODE_INPUTSTREAM:
##        pass
##    else:
##        playmode_string = C.DEFAULT_PLAYMODE 
##    if download == True:
##        Log("f4mproxy video_url - only this mode can capture")
##        playmode_string = C.PLAYMODE_F4MPROXY
##    Log("playmode_string='{}'".format(playmode_string)  )
##    
##    if playmode_string == '': # direct
##        video_url = "{}{}".format(video_url, utils.Header2pipestring(naked_headers) )
##        Log("direct video_url")
##
##    elif playmode_string == C.PLAYMODE_F4MPROXY:
##        video_url = "{}{}".format(video_url, utils.Header2pipestring(naked_headers) )
##        Log("f4mproxy video_url")
##
##        if download == True:
##            download_path = C.Make_download_path(name = name, include_date = True, file_extension = '.mp4')
##            Log("download_path={}".format(download_path), xbmc.LOGNONE)
##        else:
##            download_path = None
##
##        if play_profile == 0: play_profile='profile_01'
##        initial_bitrate = int(float(C.addon.getSetting(play_profile + "_initial"))* 1000 * 1000)
##        maximum_bitrate = int(float(C.addon.getSetting(play_profile + "_maximum"))* 1000 * 1000)
##        allow_upscale = C.addon.getSetting(play_profile + "_allow_upscale")
##        allow_downscale = C.addon.getSetting(play_profile + "_allow_downscale")
##        always_refresh_m3u8 = C.addon.getSetting(play_profile + "_always_refresh_m3u8")
##        downscale_threshhold = C.addon.getSetting(play_profile + "_downscale_threshhold")
##        upscale_threshhold = C.addon.getSetting(play_profile + "_upscale_threshhold")
##        upscale_penalty = C.addon.getSetting(play_profile + "_upscale_penalty")
##        pre_cache_size_max = int(float(C.addon.getSetting(play_profile + "_" + "pre_cache_size_max"))* 1000 * 1000)
##        
##        from F4mProxy import f4mProxyHelper
##        streamtype = 'HLSRETRY'        
##        f4mp=f4mProxyHelper()
##        f4mp.playF4mLink(
##            video_url
##            , name
##            , proxy = None
##            , use_proxy_for_chunks = False
##            , maxbitrate = maximum_bitrate
##            , simpleDownloader = False
##            , auth = None
##            , streamtype = streamtype
##            , setResolved = False
##            , swf = None
##            , callbackpath = ""
##            , callbackparam = ""
##            , iconImage = iconimage
##            , download_path = download_path
##            , initial_bitrate = initial_bitrate
##            , allow_upscale = allow_upscale
##            , allow_downscale = allow_downscale
##            , always_refresh_m3u8 = always_refresh_m3u8
##            , downscale_threshhold = downscale_threshhold
##            , upscale_threshhold = upscale_threshhold
##            , upscale_penalty = upscale_penalty
##            , pre_cache_size_max = pre_cache_size_max
##            )
##        return
##            
##    elif playmode_string == C.PLAYMODE_INPUTSTREAM:
##
##        video_url = "{}{}".format(video_url, utils.Header2pipestring(naked_headers) )
##        if ".m3u8" in video_url:
##            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
##            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
##            listitem.setProperty('inputstream.adaptive.stream_headers'
##                                 , utils.Header2pipestring(naked_headers).strip("|") )
##            Log("using inputstream")
##    else:
##        utils.notify(name,'Unknown playmode for webcam link')
##
##    Log("video_url='{}'".format(video_url)  )
##
##    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
##    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
##    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
##    myPlayList.add( video_url, listitem)
##    xbmc.Player().play(myPlayList)
    
#__________________________________________________________________________
#

def Search(searchUrl, keyword=None, end_directory=True, page=0):
    return True

#__________________________________________________________________________
#

def Test(keyword):

    List(ROOT_URL, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    return True

    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#
