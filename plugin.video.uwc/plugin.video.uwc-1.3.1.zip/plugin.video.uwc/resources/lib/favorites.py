'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sqlite3

import xbmc, xbmcplugin

from resources.lib import utils
from resources.lib.utils import Log as Log

from sites.chaturbate import clean_database as clean_chaturbate
from sites.chaturbate import camgirl_page as camgirl_page

from sites.cam4 import clean_database as cleancam4
from sites.naked import clean_database as cleannaked

#from sites.myfreecams import getCamgirlInfo as getCamgirlInfo
from sites.myfreecams import getCamgirlList as getCamgirlList
from sites.myfreecams import getCamgirlInfo as getCamgirlInfo
from sites.myfreecams import clean_database as clean_mfc

import time
import traceback

log = utils.kodilog

dialog = utils.dialog
favoritesdb = utils.favoritesdb

conn = sqlite3.connect(favoritesdb)
c = conn.cursor()
try:
    c.executescript("CREATE TABLE IF NOT EXISTS favorites (name, url, mode, image);")
    c.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
except:
    pass
conn.close()

@utils.url_dispatcher.register('899')  
def RefreshContainter():
##    Log("here5", xbmc.LOGNONE)
##    clean_chaturbate(False)
##    #Log("here4", xbmc.LOGNONE)
##    cleancam4(False)
##    #Log("here3", xbmc.LOGNONE)
##    cleannaked(False)
##    #Log("here2", xbmc.LOGNONE)
##    clean_mfc(False)
##    #Log("here1", xbmc.LOGNONE)
    xbmc.executebuiltin('Container.Refresh')
    
@utils.url_dispatcher.register('901')  
def List():
    if utils.addon.getSetting("auto_clean_img_database").lower() == "true":
        clean_chaturbate(False)
        cleancam4(False)
        cleannaked(False)
        clean_mfc(False)

    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()

    utils.addDir("[COLOR {}] Refresh[/COLOR]".format(utils.refresh_text_color),'',899,'',Folder=False)
    
    try:
        c.execute("SELECT * FROM favorites")

        chaturbategirls = camgirl_page()
        mfcgirls = getCamgirlList()
        
        for (name, url, mode, img) in c.fetchall():
            try:
                if 'chaturbate.com' in url:
                    name = name.split(' [COLOR')[0]
                    if '<a href="/{}/">'.format(name) in chaturbategirls:
                        name = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,name)
                    else:
                        log( "'{}' not found in page1".format(name) )
                    utils.addDownLink(name=name, url=url, mode=int(mode), iconimage=img, desc='', stream='', fav='del')

                elif '.mfcimg.com' in img:
                        #serverNumber,modelID,newServer=getCamgirlInfo(name)
                        serverNumber,modelID,newServer = getCamgirlInfo(name, mfcgirls)
                        log("name={},serverNumber={},modelID={},newServer={}".format(name,serverNumber,modelID,newServer))
                        if serverNumber > 0: #    if model server found; an online/active image can be used
                            if newServer == False:
                                img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc_{}?no-cache={}".format(serverNumber,modelID,time.time())
                            else:
                                img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc_a_{}?no-cache={}".format(serverNumber,modelID,time.time())
                                #      https://snap.mfcimg.com/snapimg/439/320x240/mfc_a_117172451

                            name = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color,name)
                            utils.addDownLink(name, url, int(mode), img, '', '', 'del')
                        else:  #else use default
                            if "snap.mfcimg.com/" in img:
                                log(img)
                                modelid = img.split('/')[6][5:] #trim first 5 chars
                                log(modelid)
                                img = "https://img.mfcimg.com/photos2/{}/{}/avatar.300x300.jpg".format(modelid[:3], modelid)
                                log(img)
                            #https://img.mfcimg.com/photos2/214/21455613/avatar.300x300.jpg
                                
                            utils.addDownLink(name, url, int(mode), img, '', '', 'del')
                else:
                    utils.addDownLink(name.strip(), url, int(mode), img, '', '', 'del')

            except:
                traceback.print_exc()

        xbmcplugin.addSortMethod(handle=utils.addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)    
        xbmcplugin.endOfDirectory(utils.addon_handle)
    except Exception,e:
        xbmc.log(str(e) , xbmc.LOGNONE)    
        utils.notify('No Favorites','No Favorites found')

    #cleanup objects
    conn.close()
    return

@utils.url_dispatcher.register('900', ['fav','favmode','name','url','img'])  
def Favorites(fav,favmode,name,url,img):
    if fav == "add":
        delFav(url)
        addFav(favmode, name, url, img)
        utils.notify('Favorite added','Video added to the favorites')
    elif fav == "del":
        delFav(url)
        utils.notify('Favorite deleted','Video removed from the list')
        xbmc.executebuiltin('Container.Refresh')

def addFav(mode,name,url,img):
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("INSERT INTO favorites VALUES (?,?,?,?)", (name, url, mode, img))
    conn.commit()
    conn.close()

def delFav(url):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM favorites WHERE url = '%s'" % url)
    conn.commit()
    conn.close()
