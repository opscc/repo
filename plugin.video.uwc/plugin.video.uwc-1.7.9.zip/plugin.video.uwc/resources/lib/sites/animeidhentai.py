'''
    Ultimate Whitecream
    Copyright (C) 2018 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import json
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]Animeid Hentai[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_HENTAI
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://animeidhentai.com"
SEARCH_URL = ROOT_URL + '/wp-admin/admin-ajax.php'
URL_RECENT = ROOT_URL + '/genre/2021/page/{}/'
URL_CATEGORIES_1 = ROOT_URL + '/genre/hentai-uncensored/page/{}/'

URL_CATEGORIES_2021 = ROOT_URL +  '/genre/2021/page/{}/'
URL_CATEGORIES_2020 = ROOT_URL +  '/genre/2020/page/{}/'
URL_CATEGORIES_2019 = ROOT_URL +  '/genre/2019/page/{}/'
URL_CATEGORIES_2018 = ROOT_URL +  '/genre/2018/page/{}/'
URL_CATEGORIES_2017 = ROOT_URL +  '/genre/2017/page/{}/'
URL_CATEGORIES_2016 = ROOT_URL +  '/genre/2016/page/{}/'
URL_CATEGORIES_2015 = ROOT_URL +  '/genre/2015/page/{}/'

MAIN_MODE          = C.MAIN_MODE_animeidhentai
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#


@C.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Uncensored[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color)
        ,url=URL_CATEGORIES_1
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon
        , end_directory=True, keyword='', page=FIRST_PAGE         )

    utils.addDir(name="{}[COLOR {}]2021[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color)
        ,url=URL_CATEGORIES_2021
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon
        ,end_directory=True, keyword='', page=FIRST_PAGE       )
    
    utils.addDir(name="{}[COLOR {}]2020[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color)
        ,url=URL_CATEGORIES_2020
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon
        ,end_directory=True, keyword='', page=FIRST_PAGE       )
    
    utils.addDir(name="{}[COLOR {}]2019[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color)
        ,url=URL_CATEGORIES_2019
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon
        ,end_directory=True, keyword='', page=FIRST_PAGE         )
    
    utils.addDir(name="{}[COLOR {}]2018[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color)
        ,url=URL_CATEGORIES_2018
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon
        ,end_directory=True, keyword='', page=FIRST_PAGE         )

    utils.addDir(name="{}[COLOR {}]2017[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color)
        ,url=URL_CATEGORIES_2017
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon 
        ,end_directory=True, keyword='', page=FIRST_PAGE         )
    
    utils.addDir(name="{}[COLOR {}]2016[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color)
        ,url=URL_CATEGORIES_2016
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon 
        ,end_directory=True, keyword='', page=FIRST_PAGE         )
    
    utils.addDir(name="{}[COLOR {}]2015[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color)
        ,url=URL_CATEGORIES_2015
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon
        ,end_directory=True, keyword='', page=FIRST_PAGE         )

    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, list_url)
    video_region = listhtml
    #Log("video_region={}".format(video_region))

    Parse_List_Items(video_region, keyword, testmode)

    # next page items
    try:
        regex = 'class="loop-nav-inner"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
    next_page_regex = 'pagination.+?"[^"]+/page/(\d+)/" class="next'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
            np_number = np_url
            np_url = url
##            Log("np_url={}".format(np_url))
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= max_search_depth:
                    utils.Notify(msg=np_url)  #let user know something is happening
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword)   
            break

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
def Parse_List_Items(video_region, keyword, testmode):
    #
    # parse out list items
    #
    regex = 'article class=.+?entry-title">([^<]+)<(.+?)src="??([^"\s]+(?:jpg|png))"??\s.+?href="??([^"\s]+)"??\s'
    regex = '<article class=.+?"entry-title">([^<]+)<(.+?)data-lazy-src="([^"]+)".+?href="([^"]+)"'
    regex = '<article class=.+?"entry-title">([^<]+)<(.+?)src="([^"]+\.jpg)".+?href="([^"]+)"(.)'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
##    Log("info={}".format(info))
##    if len(info) < 1:
##        label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
##        utils.addDir(
##            name=label
##            ,url=''
##            ,mode=''
##            ,iconimage=C.next_icon
##            )
    for label, other, thumb, videourl, hd in info:
        hd = utils.Normalize_HD_String(hd)
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        Log("videourl={}".format(videourl + '/'))
        utils.addDownLink( 
            name = label 
            , url = videourl + '/'
            , mode = PLAY_MODE
            , desc = ROOT_URL
            , iconimage = thumb
            )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    return True
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, testmode=False):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    url = searchUrl

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)
    
    headers = {
        "User-Agent": C.USER_AGENT
        , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        , "Accept": "*/*"
        , "Origin": ROOT_URL
        , "X-Requested-With": "XMLHttpRequest"
        , "Referer": SEARCH_URL.format(keyword)
        , "Accept-Encoding": "gzip"
        , "Accept-Language": "en-US,en;q=0.9"
    }

    data = "action=ajax_pagination&query_vars=null&page={}&order=latest&search={}".format(page,keyword)
    page_html = utils.postHtml(url, sent_data=data, headers=headers)
##    Log("page_html='{}'".format(page_html))

    # parse out list items
    Parse_List_Items(page_html, keyword, testmode)
    

    next_page_regex = 'current" class="page-link" href="' + searchUrl + '(?:\?paged=\d+|)">(\d+)<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(page_html)

    last_page_regex = 'class="page-link" href="' + searchUrl + '(?:\?paged=\d+|)">(\d+)<'
    lp_info = re.compile(last_page_regex, re.DOTALL | re.IGNORECASE).findall(page_html)
##    Log("lp_info='{}'".format(lp_info))

    if lp_info:
        lp_info = lp_info[-1]
##        Log("lp_info='{}'".format(lp_info))
        if str(lp_info) == str(page):
            #Log("lp_info found; setting np to empty set")
            np_info = {}
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(url))
    else:
        np_number = int(page) + 1
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=searchUrl 
                ,mode=SEARCH_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,keyword=keyword
                ,end_directory=end_directory)
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=SEARCH_URL.format(keyword, np_number))  #let user know something is happening
                Search(searchUrl=searchUrl, keyword=keyword, end_directory=end_directory, page=np_number)
            
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, ROOT_URL)
    regex = '<li.+?class=".+?menu-item-object-post_tag.+?"><a href="(.+?)">(.+?)</a></li>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    for videourl, label in info:
        keyword = videourl.split('tag/')[1].split('/')[0]
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=C.search_icon 
            ,keyword=keyword )

    utils.endOfDirectory(end_directory=end_directory)        
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    html = utils.getHtml(url, ROOT_URL)

    #Log("html='{}'".format(html))
    regex = 'id="play-iframe".+?src="([^"]+)"' #2020-12-14
    next_link = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)[0]

    html = utils.getHtml(next_link, url)
    isHLS = False
    try:
        #working 2020-07
        from resources.lib import jsunpack
        unpacked_src = jsunpack.unpack(html)
        Log("unpacked_src='{}'".format(unpacked_src))
        
        regex = 'sources:(\[.*?\])'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(unpacked_src)
        Log("sources_list='{}'".format(sources_list))
        sources = json.loads(sources_list[0])
        Log("sources='{}'".format(sources))
        Log("sources[file]='{}'".format(sources[0]['file']))
        video_url = sources[0]['file']

    except:
        #working 2020-08
        regex = 'FirePlayer\(vhash, (.+), false\);'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
        Log("sources_list='{}'".format(sources_list))
        sources = json.loads(sources_list[0])
        Log("sources='{}'".format(sources))
        video_url = "https://htstreaming.com{}?s={}&d=".format(
            sources['videoUrl']
            ,sources['videoServer']
            )
        #https://htstreaming.com/cdn/hls/b4351fbdd294cc1f13037ff2e7cb9d6d/master.txt?s=sv2&d=
        #https://htstreaming.com/cdn/hls/d249a6fc7236089b3bfe84fde25f9d59/master.txt/?s=sv2&d=
        Log("video_url={}".format(video_url.encode()))
        isHLS = sources['videoData']['videoSources'][0]['type'] == u'hls'


    if isHLS:
        playmode_string = C.PLAYMODE_F4MPROXY
    else:
        playmode_string = None

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = next_link
    video_url +=  utils.Header2pipestring(headers)  #required or else acces denied

    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name, download, description=description, playmode_string=playmode_string)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
#__________________________________________________________________________
#

 
