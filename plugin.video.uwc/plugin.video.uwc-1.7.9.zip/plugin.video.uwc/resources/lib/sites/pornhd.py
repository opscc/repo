'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]PornHD[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.pornhd.com"
SEARCH_URL = ROOT_URL + '/search?search={}&page={}'
URL_CATEGORIES = ROOT_URL + '/category'
URL_RECENT = ROOT_URL + '/?page={}'
URL_TOPRATED = ROOT_URL + "/top-rated-porn-videos/page/{}/"
URL_MOSTVIEWED = ROOT_URL + "/most-viewed-porn-videos/page/{}/"

MAIN_MODE          = C.MAIN_MODE_pornhd
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(name=C.STANDARD_MESSAGE_CATEGORIES
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=C.category_icon )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml, redirected_url = utils.getHtml(list_url, send_back_redirect=True, ignore404=True)
    if redirected_url:  list_url = redirected_url
    if "Sorry, no videos found" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('class="video-list-container"')[1].split('class="section-margin pagination-wrapper')[0]
        except:
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    # parse out list items
    regex = 'class="video-item ".+?href="([^"]+)".+?.+?srcset="([^"]+\.jpg)".+?img alt="([^"]+)".+?video-duration">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, duration in info:
        hd = utils.Normalize_HD_String(label)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)


    # next page items
    try:
        next_page_html = listhtml.split('class="pagination-list"')[1]
    except:
        next_page_html = listhtml
    next_page_regex = 'class="pagination-next" href="([^"]+(\d+))"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url, np_number in np_info:
        np_url = C.html_parser.unescape(np_url)
##        Log("np_number={} np_url={}".format(np_number,np_url))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace('+',' ').replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword, '{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url, ROOT_URL)
 
    regex = 'a href="(/category/[^"]+)".+?alt="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label, thumb in info:
        videourl += '?page={}'
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,page=FIRST_PAGE
            ,mode=LIST_MODE 
            ,iconimage=thumb
            )
        
    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL

    videopage = utils.getHtml(url, ROOT_URL, save_cookie=True) #this site needs a cookie to play

    regex = '<source.+?src="([^"]+)".+?res=\'([^\']+)\''
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
##    Log("sources_list={}".format(sources_list))
    list_key_value = {} ##[] #dict()
    for i in range(len(sources_list)):
        q = sources_list[i][0]
        #q = q.split(':')[1].replace('"', '')
        v = sources_list[i][1]
        #v = sources_list[i][1].split('url:')[1].replace('"', '')
        if not v == "":
            list_key_value[q] = v
    list_key_value = [ [k,v] for k, v in list_key_value.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=list_key_value
        ,download=download
        ,vid_res_column=1
        ,max_video_resolution=max_video_resolution
        )

    import cookielib
    cj = cookielib.LWPCookieJar(C.cookiePath)
    try:
        cj.load(ignore_discard=True, ignore_expires=True)
    except:
        pass
    
    #this site needs a cookie to play video
    cookiestring = ''
    h = ''
    for cookie in cj:
##        break
        if cookie.domain.endswith(".pornhd.com"):
##            Log("cookie={}".format(cookie))
            if cookie.name=="xx __cfduid":
                h += "{}={}".format(cookie.name,cookie.value) + ';'
            if cookie.name=="xx tsid":
                h += "{}={}".format(cookie.name,cookie.value) + ';'
            if cookie.name=="XSRF-TOKEN":
                h += "{}={}".format(cookie.name,cookie.value) + ';'
            if cookie.name=="laravel_session":
                h += "{}={}".format(cookie.name,cookie.value) + ';'
            if cookie.name=="xx wmttrd": 
                h += "{}={}".format(cookie.name,cookie.value) + ';'
    h = h.strip(';')
    
    if len(h) > 1:
        headers = { 'Cookie': h  }
        #cookiestring = "{}&{}".format(utils.Header2pipestring(),urllib.urlencode(headers)  )
        cookiestring = "{}&Cookie={}".format(utils.Header2pipestring(), h)
        Log("cookiestring={}".format(cookiestring))

    #need as second call without redirection to get the latest cookies

    import urllib2, ssl
    class NoRedirection(urllib2.HTTPErrorProcessor):
        def http_response(self, request, response):
            return response
        https_response = http_response
    
    url2 = video_url
    Log("url2={}".format(url2))

    opener = urllib2.build_opener(NoRedirection, urllib2.HTTPCookieProcessor(cj))
    headers = []
    for a in C.DEFAULT_HEADERS:
        headers.append ((a, C.DEFAULT_HEADERS[a]))
    headers.append (("Referer", url ))
    headers.append (("Cookie", h ))
    opener.addheaders = headers
    Log("opener.addheaders={}".format(repr(opener.addheaders)))

    response = opener.open(video_url) #, context=ssl._create_unverified_context())
    if response.code == 302:
        video_url = response.headers['Location']

    #this site needs a cookie to play video
    cookiestring = ''
    h = ''
    for cookie in cj:
        if cookie.domain.endswith(".pornhd.com"):
##            Log("cookie={}".format(cookie))
            if cookie.name=="xx  __cfduid":
                h += "{}={}".format(cookie.name,cookie.value) + ';'
            if cookie.name=="xx tsid":
                h += "{}={}".format(cookie.name,cookie.value) + ';'
            if cookie.name=="xx XSRF-TOKEN":
                h += "{}={}".format(cookie.name,cookie.value) + ';'
            if cookie.name=="laravel_session":
                h += "{}={}".format(cookie.name,cookie.value) + ';'
            if cookie.name=="xx wmttrd": 
                h += "{}={}".format(cookie.name,cookie.value) + ';'
    h = h.strip(';')
    if len(h) > 1:
        headers = { 'Cookie': h  }
        cookiestring = "{}&Cookie={}".format(utils.Header2pipestring(), h)
        Log("cookiestring={}".format(cookiestring))

    video_url = video_url + cookiestring
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name, download, description=description)
#__________________________________________________________________________
#
