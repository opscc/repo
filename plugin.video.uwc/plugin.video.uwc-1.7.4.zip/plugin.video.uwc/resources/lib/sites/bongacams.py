'''
    Ultimate Whitecream
    Copyright (C) 2017 Whitecream, hdgdl
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import sqlite3
import json

import xbmc
import xbmcplugin
import xbmcgui
import urllib

from resources.lib import utils
from resources.lib.utils import Log


MAIN_MODE          = '520'
LIST_MODE          = '521'
PLAY_MODE          = '522'
REFRESH_MODE       = '524'

ROOT_URL = "https://bongacams.com"
URL_FEMALES = ROOT_URL + "/tools/listing_v3.php?livetab=female&online_only=true&offset={}&model_search%5Bbase_sort%5D=popular%5Bgender%5D%5B%5D=female&_online_filter=0"
#URL_FEMALES = ROOT_URL + "/tools/listing_v3.php?livetab=female&online_only=true&offset={}&model_search%%5Bgender%5D%5B%5D=female&_online_filter=0"
URL_COUPLES = ROOT_URL + "/tools/listing_v3.php?livetab=couples&online_only=true&offset={}&model_search%5Bbase_sort%5D=popular%5Bgender%5D%5B%5D=couples&_online_filter=0"

SEARCH_URL = 'stub - make all sites consistent'

RESULTS_PER_PAGE = 60 

#__________________________________________________________________________
#
@utils.url_dispatcher.register(MAIN_MODE)
def Main():
##    utils.addDir('[COLOR red]Refresh bongacams.com images[/COLOR]','',REFRESH_MODE,'',Folder=False)
##    utils.addDir('[COLOR hotpink]Female[/COLOR]','http://tools.bongacams.com/promo.php?c=226355&type=api&api_type=json&categories[]=female',LIST_MODE,'','')
##    utils.addDir('[COLOR hotpink]Male[/COLOR]','http://tools.bongacams.com/promo.php?c=226355&type=api&api_type=json&categories[]=male',LIST_MODE,'','')
##    utils.addDir('[COLOR hotpink]Transsexual[/COLOR]','http://tools.bongacams.com/promo.php?c=226355&type=api&api_type=json&categories[]=transsexual',LIST_MODE,'','')
##    utils.addDir('[COLOR hotpink]Couples[/COLOR]','http://tools.bongacams.com/promo.php?c=226355&type=api&api_type=json&categories[]=couples',LIST_MODE,'','')
##    xbmcplugin.endOfDirectory(utils.addon_handle)

    utils.addDir(
        name="{}[COLOR {}]Couples[/COLOR]".format(utils.SPACING_FOR_TOPMOST,utils.search_text_color) 
        ,url=URL_COUPLES
        ,page='1'
        ,mode=LIST_MODE
        ,iconimage=utils.category_icon )

    
    List(URL_FEMALES, page='1', end_directory=True, keyword='')


#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page=1, depth=1, notify=False):

    if notify: utils.Notify("Listing {}".format(ROOT_URL))
        
    if '{}' in url and page: list_url = url.format((int(page)-1)*RESULTS_PER_PAGE*depth)
    else: list_url = url
    #note: max results per page is 130 regardless

    cookie = '{"sorting":"camscore","th_type":"live","limit":' + str(RESULTS_PER_PAGE*depth) + ',"display":"medium","c_limit":8}'
    cookie = urllib.quote(cookie)
    bongacam_header = {
                    'User-Agent': utils.USER_AGENT
                    ,'Accept': "application/json, text/plain, */*"
                    ,'Referer': "{}".format(ROOT_URL)
                    ,'Accept-Encoding': 'gzip'
                    ,'Cookie': 'ls01=' + cookie
                    ,'X-Requested-With': 'XMLHttpRequest'
                    }
    json_html = utils.getHtml(list_url, headers=bongacam_header)

    json_items = json.loads(json_html)
    
    hq_bonus = int(utils.addon.getSetting("hq_bonus").lower())
    #play_method = str(utils.addon.getSetting("default_playmode").lower())

    for json_item in json_items['models']:
        #Log("json_item='{}'".format(json_item))
        camscore=int(json_item["viewers"])
        hd = json_item["vq"]
        if hd:
            hd = str(hd.split('x')[0])
        else:
            hd = ''

        if   '4k' in hd :
            camscore=camscore*hq_bonus*100
            hd = "[COLOR {}]uhd[/COLOR]".format(utils.refresh_text_color)
        elif '1920' in hd :
            camscore=camscore*hq_bonus*10
            hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif '1280' in hd :
            camscore=camscore*hq_bonus*1
            hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        elif '1152' in hd :
            camscore=camscore*hq_bonus*1
            hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else:
            hd = ""

        name = json_item['display_name']
        icon_image = "https:" + json_item['thumb_image']
        video_url = json_item["username"]
        label = "{}{} {}".format(utils.SPACING_FOR_NAMES, utils.cleantext(name), hd)

        json_item['username'] = json_item["display_name"]
        json_item['icon_label'] = label
        json_item['icon_image'] = icon_image
        json_item['video_url'] = video_url
        json_item['camscore'] = camscore
        json_item['mode'] = PLAY_MODE
        json_item['description'] = '\n' + ROOT_URL
        json_item['play_method'] = '' #leave this blank so that default value is used

    online_count = int(json_items['online_count'])  # this is not used as an actual length, but as a way to send queries to website in order to get the next set of X items
    json_items = json_items['models']

    #remove models that can not be seen
    change_made = True
    while change_made:
        change_made = False
        for i in xrange(len(json_items)):
##            Log("json_items[i]='{}'".format(json_items[i]), xbmc.LOGNONE)
            if not (json_items[i]['room'] in {'public'}):
##            if json_items[i]["is_away"] == True:
                json_items.pop(i)
                change_made = True
                break
    
    return json_items, online_count

##    Log("len json_items['models']='{}'".format(len (json_items['models'])))
##    return json_items['models'], int(json_items['online_count'])


#__________________________________________________________________________
#
@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))
    
    if end_directory == True:    
        utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
            utils.SPACING_FOR_TOPMOST, utils.refresh_text_color) 
            ,url='' 
            ,mode=REFRESH_MODE 
            ,iconimage=utils.refresh_icon)

    models, online_count = GetCamgirlList(url, page)
    for model in models:
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            )

    #
    # check for a minimum during tesing
    #
    if len(models) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError
        
    if models:
        Log("online_count='{}'".format(online_count))
        if online_count:
            #online_count = int(models['online_count'])
            page_window = RESULTS_PER_PAGE * int(page)
            has_next_page = (online_count > page_window)
            #Log("has_next_page='{}'".format(has_next_page))
            if has_next_page: 
                np_number = int(page) + 1
                np_url = url
                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(utils.SPACING_FOR_NEXT, utils.search_text_color, np_number)
                if end_directory == True:
                    utils.addDir(
                        name= np_label
                        ,url=np_url 
                        ,mode=LIST_MODE 
                        ,iconimage=utils.next_icon 
                        ,page=np_number
                        ,keyword=keyword )
            
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
@utils.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    #clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')
    
#__________________________________________________________________________
#
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % "bongacams.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % "bongacams.com")
            if showdialog:
                utils.notify('Finished','bongacams.com images cleared')
    except:
        pass

#__________________________________________________________________________
#

def Search(searchUrl, keyword=None, end_directory=True, page=0):
    return True
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_FEMALES, page='1', end_directory=False, keyword='', testmode=True)
    return True
##    List('http://tools.bongacams.com/promo.php?c=226355&type=api&api_type=json&categories[]=female')
##    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
##    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#
@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download', 'megabitratebonus'])
def Playvid(url, name, playmode_string = '', download = False, megabitratebonus=0):
    
    Log ("Playvid url='{}', name='{}', playmode_string='{}', megabitratebonus='{}', download='{}'".format(url, name, playmode_string, megabitratebonus, download), xbmc.LOGNONE  )

    #
    # do stuff to get a playable url
    #
    username = url
    bongacam_headers = {
                    'User-Agent': utils.USER_AGENT
                    ,'Accept': "application/json, text/plain, */*"
                    ,'Referer': "{}".format(ROOT_URL)
                    ,'Accept-Encoding': 'gzip'
                    ,'X-Requested-With': 'XMLHttpRequest'
                    ,'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    }
    try:
        #https://bongacams.com/tools/amf.php?x-country=ca&res=1062342?1590534880043
        #method=getRoomData&args%5B%5D=ivy-8&args%5B%5D=true
        postRequest = {'method' : 'getRoomData', 'args[]' : str(username)}
        postRequest = urllib.urlencode(postRequest)
        #postRequest = "method=getRoomData&args[]=" + url + "&args[]=true"
        response = utils.postHtml(ROOT_URL + '/tools/amf.php', sent_data=postRequest, headers=bongacam_headers,compression=True)
    except:
        utils.Notify("{} is unavailable".format(name))
        raise
        return
    
    amf_json = json.loads(response)
    Log("amf_json='{}'".format(amf_json))
    if not ('performerData' in amf_json):
        utils.Notify("{} is unavailable".format(name))
        return
    else:
        if amf_json['performerData']['showType'] in ('private','group'):
            display_name = amf_json['performerData']['displayName']
            utils.Notify("{} is private".format(display_name))
            return

    if not 'videoServerUrl' in amf_json['localData']:
        display_name = amf_json['performerData']['displayName']
        utils.Notify("{} is unavailable".format(display_name))
        return
    
    if amf_json['localData']['videoServerUrl'].startswith("//mobile"):
       video_url = 'https:' + amf_json['localData']['videoServerUrl'] + '/hls/stream_' + username + '.m3u8'  
    else:
       video_url = 'https:' + amf_json['localData']['videoServerUrl'] + '/hls/stream_' + username + '/playlist.m3u8'


    #
    # play url as needed
    #

    Log("video_url='{}'".format(video_url)  )

    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    listitem.setContentLookup(False)

    max_bit_rate = utils.MAX_BIT_RATE  + int((int(megabitratebonus)) * 1000 * 1000)
    max_bit_rate_download = utils.MAX_BIT_RATE  + int((int(megabitratebonus) + 0.25) * 1000 * 1000)


    if playmode_string == utils.PLAYMODE_F4MPROXY:
        pass
    elif playmode_string == utils.PLAYMODE_INPUTSTREAM:
        pass
    else:
        playmode_string = utils.DEFAULT_PLAYMODE 
    if download == True:
        Log("f4mproxy video_url - only this mode can capture")
        playmode_string = utils.PLAYMODE_F4MPROXY
    Log("playmode_string='{}'".format(playmode_string)  )

    #playmode_string = ''
    
    if playmode_string == '': # direct
        video_url = "{}{}".format(video_url, utils.Header2pipestring() )
        Log("direct video_url")

    elif playmode_string == utils.PLAYMODE_F4MPROXY:
        video_url = "{}{}".format(video_url, utils.Header2pipestring() )
        Log("f4mproxy video_url")

        if download == True:
            download_path = utils.Make_download_path(name = name, include_date = True, file_extension = '.mp4')
            Log("download_path={}".format(download_path), xbmc.LOGNONE)
        else:
            download_path = None
            
        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        f4mp.playF4mLink(
            video_url
            , name
            , proxy = None
            , use_proxy_for_chunks = False
            , maxbitrate = max_bit_rate_download
            , simpleDownloader = False
            , auth = None
            , streamtype = 'HLSREDIR'
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , iconImage = iconimage
            , download_path = download_path
            )
        return
            
    elif playmode_string == utils.PLAYMODE_INPUTSTREAM:

        video_url = "{}{}".format(video_url, utils.Header2pipestring() )
        if ".m3u8" in video_url:
            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            listitem.setProperty('inputstream.adaptive.stream_headers'
                                , 'user-agent=' + 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/538.22 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'
                                + "&Referer=".format(ROOT_URL)
                                )
            Log("using inputstream")
    else:
        utils.notify(name,'Unknown playmode for webcam link')

    Log("video_url='{}'".format(video_url)  )

    #xbmc.Player().stop()
    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( video_url, listitem)
    xbmc.Player().play(myPlayList)
    
#__________________________________________________________________________
#
