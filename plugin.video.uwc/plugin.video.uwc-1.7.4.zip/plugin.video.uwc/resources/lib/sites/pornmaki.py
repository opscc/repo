'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://pornmaki.com"

SEARCH_URL = ROOT_URL + '/search/videos/{}/page{}.html'
#https://pornmaki.com/search/videos/kylie-page/page2.html

URL_CATEGORIES = ROOT_URL + '/channels/'
##URL_RECENT = ROOT_URL + '/most-recent/'
URL_RECENT = ROOT_URL + '/most-recent/page{}.html'

URL_TOPRATED = ROOT_URL + "/channels.php"

MAIN_MODE       = '560'
LIST_MODE       = '561'
PLAY_MODE       = '562'
CATEGORIES_MODE = '563'
SEARCH_MODE     = '564'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
        
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    listhtml, redirected_url = utils.getHtml(list_url, send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "Sorry, no videos found" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('<p class="popup-title"')[1].split('pagination-block')[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    #
    # parse out list items
    #
    regex = 'id="([^"]+)" alt="([^"]+)".+?src="([^"]+)".+?<span class="video-length">([\d:]+)</span>'
    regex = 'id="([^"]+)" alt="([^"]+)".+?data-src="([^"]+)".+?<span class="video-length">([\d:]+)</span>' #2020-10
    regex = 'videoBox ">\s<a href="([^"]+)".+?alt="([^"]+)".+?data-src="([^"]+)".+?<span class="video-length">([\d:]+)</span>' #2020-10
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, duration in info:
        #Log("label={}".format(label))
        #Log("hd={}".format(hd))
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in label: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        #if not videourl.startswith('http'): videourl = ROOT_URL + '/embed/' + videourl
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        #thumb = thumb + "|Referer=" + list_url
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        #Log("duration={}".format(duration))
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    #
    # check for a minimum during tesing
    #
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError


    #
    # next page items
    #
    try:
        next_page_html = listhtml.split('pagination-block"')[1]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = 'page-next" href="([^"]+)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
##            Log("np_url={}".format(np_url))
##            np_number = ''
##            if not np_number.isdigit():
##                np_number=np_url.split('page')[1].split('.html')[0]
##            if not np_url.startswith('http'):
##                np_url = list_url.split('page')[0] + 'page' + str(np_number) + '.html'
            np_number = int(page) + 1
            np_url = url
            
            Log("np_number={}".format(np_url))
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number))
            if end_directory == True:
                utils.addDir(
                    name=np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

##SEARCH_URL = ROOT_URL + '/search/videos/{}/page{}.html'
###https://pornmaki.com/search/videos/kylie-page/page2.html
##

    keyword = keyword.replace('+',' ').replace(' ','-')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page='1', end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    Log("url='{}', name='{}', download='{}'".format(url, name, download))

    videopage = utils.getHtml(url, ROOT_URL)
##    Log("videopage={}".format(videopage))
##    videopage = 'sources: [{"src": "https:\/\/cdn.pornoxo.com\/key=IVU3oblQyV6MJG98-WHL2w,end=1563041646,ip=216.154.65.37\/ip=216.154.65.37\/speed=514178\/buffer=3.0\/2019-06\/hq_43934117335285d42dab7b076fcb225e.mp4", "desc": "720p" ,"active":"true"}, {"src": "https:\/\/cdn.pornoxo.com\/key=2BAi1iE-vFSNcxrVYIpShg,end=1563041646,ip=216.154.65.37\/ip=216.154.65.37\/speed=312550\/buffer=3.0\/2019-06\/43934117335285d42dab7b076fcb225e.mp4", "desc": "480p" ,"active":""},{"src": "https:\/\/cdn.pornoxo.com\/key=dddFvPvYGKaZRsgNBXCqfA,end=1563041646,ip=216.154.65.37\/ip=216.154.65.37\/speed=151364\/buffer=3.0\/2019-06\/m_43934117335285d42dab7b076fcb225e.mp4", "desc": "360p","active":""}],'

    regex = 'file:"([^"]+)"'
    video_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    if video_url:
        video_url = video_url[0]
    else:
##        Log("videopage={}".format(videopage))
        pass
##    Log("sources_html={}".format(sources_html))
##    Log(type(sources_html))
    
##    sources_html = sources_html.replace('\/','/')
##    Log("sources_html={}".format(sources_html))
##    Log(type(sources_html))
    
#    regex = '"src":.*?"([^"]+)".*?"desc":.*?"([^"]+)"'
#    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(sources_html)
##    Log("sources_list={}".format(sources_list))
##    Log(type(sources_html))

##    sources_dict = json.loads(sources_html)
##    #Log("sources_dict={}".format(sources_dict))
##    list_key_value = [ [k,v] for k, v in sources_dict.items() ] #convert dict to list for the next function

##    video_url = utils.SortVideos(sources_list,1)

    description = ''
    pornstar_regex = 'class="player-info-link" href="/pornstar/.+?>\s*&nbsp;([^<]+?)\s*<'
    pornstars = re.compile(pornstar_regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    Log("pornstars={}".format(pornstars))
    for pornstar in pornstars:
        description = pornstar + '; ' + description
    description = description.strip('; ')
    if description == '': description = name
    description = description + '\n' + ROOT_URL
    #Log("description={}".format(description))
    

    utils.playvid(video_url, name, download, description=description)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url, '')
 
    regex = '<div class="channelspot">.+?href="([^"]+)".+?img src="([^"]+)" alt="(.+?) Porn Tube'
    regex = '<a title=.+?href="([^"]+)".+?>([^<]+)\s<'
    regex = "<a href=\"(/channels/[^\"]+)\".+?src='([^\']+)' alt='([^']+)'"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        #Log("thumb={}".format(thumb))
        videourl += "page{}.html"
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page=1
            ,iconimage=thumb) #utils.search_icon)
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#
