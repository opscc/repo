'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://www.youporn.com"

SEARCH_URL = ROOT_URL + '/search/?query={}&page={}'

URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/?page={}'

MAIN_MODE       = '700'
LIST_MODE       = '701'
PLAY_MODE       = '702'
CATEGORIES_MODE = '703'
SEARCH_MODE     = '704'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon)
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url, ignore404=True)# , send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "<p>Make sure that all words are spelled correctly.</p>" in listhtml or "No videos found for " in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            regex = '(?:data-section_name="day_by_day_section" data-espnode|video_row_main_search"|data-espnode="videolist")(.+?)(?:id="pagination"|<footer>)'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
##            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))



    #
    # parse out list items
    #
    regex = 'data-video-id.+?href="([^"]+)".+?alt=\'([^"]+)\'.+?data-thumbnail="([^"]+)".+?"video-duration">([\d:]+)<.*?((?:class="icon icon-hd-text"></i>|</div>))'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, duration, hd in info:
        #Log("label={}".format(label))
        #Log("hd={}".format(hd))
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  'icon-hd' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        #thumb = thumb + "|Referer=" + list_url
        duration = duration.replace(' ','')
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label={}".format(label))
##        Log("duration={}".format(duration))
##        Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration )
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError


    #
    # next page items
    #
    try:
        regex = 'id="pagination"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml
##    Log("next_page_html={}".format(next_page_html))

    next_page_regex = 'id="next".+?href="([^"]+)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_url = utils.html_parser.unescape(np_url)
#            Log("np_url.split('/')={}".format(np_url.split('/')))
            np_number = ''
#href="/?page=3"
#href="/search/?query=lexi+belle&amp;page=2"
            if '/' in np_url: np_url = np_url.strip('/').split('/')[-1]
            Log("np_url={}".format(np_url))
            if '?page=' in np_url: np_number = np_url.split('?page=')[1]
            if '&page=' in np_url: np_number = np_url.split('&page=')[1]
            if 'page' in np_url and not np_number.isdigit(): np_number = np_url.split('page')[1]
            if '&p=' in np_url: np_number = np_url.split('&p=')[1]
            if '?p=' in np_url: np_number = np_url.split('?p=')[1]
#            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
            np_url = url
            Log("np_number={}".format(np_number))
            Log("np_url={}".format(np_url))
            if not np_number == '':
                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number))
            else:
                np_label = None
            if not np_label:
                Log("np_info not found in url='{}'".format(list_url))
            else:
                if end_directory == True:
                    utils.addDir(
                        name=np_label
                        ,url=np_url 
                        ,mode=LIST_MODE 
                        ,iconimage=utils.next_icon 
                        ,page=np_number
                        ,section = utils.INBAND_RECURSE
                        ,keyword=keyword )
                else:
                    if int(np_number) <= (max_search_depth): #search some more, but not forever
                        utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                        List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    
    keyword = keyword.replace(' ','+') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    Log("Playvid url='{}', name='{}', download='{}'".format(url, name, download))

    source_html1 = utils.getHtml(url, ROOT_URL)
    #source_html1 = 'page_params.video.mediaDefinition = [{"format":"","quality":"720","videoUrl":"https:\/\/cv.ypncdn.com\/201907\/04\/15425688\/720p_1500k_15425688\/YouPorn_-_bree-daniels-transforms-into-hottest-cock-craving-redhead.mp4?a5dcae8e1adc0bdaed975f0760fb5e05f5175e7cfa739a0ceef5f3f7d9341aaec65ab144304409f11d72b756652844199ed88cc5be32882ef3c91ad65e5192411685a7c9612049db4e9129c2f164121551f5bda29cdb3b18eb1211ad3f166fce43f3c2019ae879764680416a95d4789cb256d23003433c6cd3be74d3a05b7e9ee3743ea0225742901bf36216a75d6fa385933d86718a86382c12b57672e9449b88a67b733511884d2359a4be131003fe70ccf97996bc8a"},{"format":"","quality":"480","videoUrl":"https:\/\/cv.ypncdn.com\/201907\/04\/15425688\/480p_750k_15425688\/YouPorn_-_bree-daniels-transforms-into-hottest-cock-craving-redhead.mp4?a5dcae8e1adc0bdaed975f0761fb5e055d8e9fa6f26e90819c47510e809d870c4c7039025ce82e2e52cfdc5baa33325821404b0d5672630a42da4a229d568731389a7c54f4edc74f6bb093d06198ef50273ed2ce5c487aebf047b96b51d4a135e683ee02b11884a01ac95d6ddb4a516cefd6d3efc4bf4908bbcf25172839ff815d98cad33aa155f31f50a5141bb627093c97ba6757138ed74d20fc34cd719676c48326e867611cb847851370d84521df39fe30eedd7b"},{"format":"","quality":"240","videoUrl":"https:\/\/cv.ypncdn.com\/201907\/04\/15425688\/240p_240k_15425688\/YouPorn_-_bree-daniels-transforms-into-hottest-cock-craving-redhead.mp4?a5dcae8e1adc0bdaed975f0761fb5e055d8e9fa6f26e90819c47510e809d870c4c7039025ce82e2e52cfdc5baa33325e1088d0ba13faba59ee5c35889074bfb53aefc7e1e74088746cdc6d097c1f173c6d89b01abb6e43521ae21a1fea57a9a606e865840de1e5a1b7793a91735227e4eaa65c9508d7f20bcccaec4ea6d53e637ccbc280950d3c6870ac01d4ae05dab47eb02ab5b88e2bdd5ec232d9d2e2f229deb9ade7c7a4b776c5d27a4e867916735504d263e150"},{"format":"upsell","quality":"1080"}];'

    regex = 'page_params.video.mediaDefinition = (\[[^\]]+\]);'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)[0]
##    Log("sources_list={}".format(sources_list))
##    Log("sources_list={}".format(type(sources_list)))

##    regex = '"quality":"([^"]+)","videoUrl":"([^"]+)"'
##    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(sources_list)
##    Log("sources_list={}".format(sources_list))
##    Log("sources_list={}".format(type(sources_list)))

    json_sources = json.loads(sources_list)
##    Log("json_sources={}".format(json_sources))
##    Log("json_sources={}".format(type(json_sources)))

    list_key_value = {} ##[] #dict()
    for json_src in json_sources:
        #Log("json_src={}".format(json_src))
        if 'videoUrl' in json_src:
##            Log("json_src={}".format(json_src['quality']))
##            Log("json_src={}".format(json_src['videoUrl']))
            list_key_value[json_src['quality']] = json_src['videoUrl']

##    Log("list_key_value={}".format(list_key_value))
##    Log("list_key_value={}".format(type(list_key_value)))


    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
##    Log("list_key_value={}".format(list_key_value))
##    Log("list_key_value={}".format(type(list_key_value)))

    video_url = utils.SortVideos(list_key_value,0)

    video_url = video_url + utils.Header2pipestring() + '&Referer=' + url

    Log("video_url={}".format(video_url))

    description = ''
    desc_separator_char = '; '
    tags_region_regex = 'class="categoriesTags">(.+?)class="reset"'
    tags_region_html = re.compile(tags_region_regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
    Log(u"tags_region_html={}".format(tags_region_html))
    if tags_region_html:
        regex_tags = '<a href.+?>(?P<tag>[^<]+)<'
        source_tags = re.compile(regex_tags, re.DOTALL | re.IGNORECASE).finditer(tags_region_html)
        if source_tags:
            for tag in source_tags:
                description += desc_separator_char + utils.html_parser.unescape(tag.group('tag'))
    description = description.strip(desc_separator_char)
    if description == '':
        description=name + '\n' + ROOT_URL
    else:
        description=description + '\n' + ROOT_URL
    Log(u"description={}".format(description))
    
        
    utils.playvid(video_url, name, download, description=description)


####    return
####    sources_list = sources_list[0]
####    Log("sources_list={}".format(sources_list))
####    Log("sources_list={}".format(type(sources_list)))
##
####    video_url = utils.SortVideos(sources_list,0)
####    Log("video_url={}".format(video_url))
##
##    list_key_value = {} ##[] #dict()
##    for i in range(len(sources_list)):
##        #Log("sources_list[i]={}".format(sources_list[i]))
##        #Log("type sources_list[i]={}".format(type(sources_list[i])))
##        
##        #dict_source = dict(sources_list[i])
##        q = sources_list[i][0]
####        Log("q={}".format((q)))
####        Log("type q={}".format(type(q)))
##        q = q.split(':')[1].replace('"', '')
####        Log("q={}".format(q))
####        Log("type q={}".format(type(q)))
##        v = sources_list[i][1]
##        v = sources_list[i][1].split('url:')[1].replace('"', '')
##        if not v == "":
##            list_key_value[q] = v
##            #list_key_value += {q,v}
####    Log("list_key_value={}".format(list_key_value))
####    Log("list_key_value={}".format(type(list_key_value)))
##
##
##    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
####    Log("list_key_value={}".format(list_key_value))
####    Log("list_key_value={}".format(type(list_key_value)))
##
##    video_url = utils.SortVideos(list_key_value,0)
##
##    video_url = video_url + utils.Header2pipestring() + '&Referer=' + url
##    
##    return
##    
##    
##    json_sources = json.loads(sources_list[0])
##
##    list_key_value = {} ##[] #dict()
##    for i in range(len(json_sources)):
##        dict_source = dict(json_sources[i])
##        q = str(dict_source['quality'])
##        v = str(dict_source['videoUrl'])
##        if not v == "":
##            list_key_value[q] = v
##    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
##    video_url = utils.SortVideos(list_key_value,0)
##    Log("video_url={}".format(video_url))


#    Log("sources_list={}".format(sources_list))
#    video_url = utils.SortVideos(sources_list,0)
#    video_url = video_url.replace('\/','/') + utils.Header2pipestring() + '&Referer=' + url
                            
#    source_url_vars = source_url_vars[0]
#    Log("sources_list={}".format(sources_list))
#    video_url = utils.SortVideos(sources_list,0)
#    video_url = video_url.replace('\/','/') + utils.Header2pipestring() + '&Referer=' + url

##    json_sources = json.loads(source_url_vars)
##    Log("json_sources={}".format(json_sources))
##    Log("json_sources[quality_720p]={}".format(json_sources['quality_720p']))

##    if source_url_vars: #
##        2019 desktop version of page
##        #from: https://www.empflix.com/combine/tnaflix.desktop.js,flixplayer.desktop.js,lazyload.desktop.js,thumbplayer.desktop.js,tnaflix.desktop.channels.js,ws.js,suggest.js,dyn.js,textarea-caret-position.js,URL.js,tnaflix.desktop.notifications.js,perfect-scrollbar.js,sortable.js,flex-images.js,masonry.js,3be38.js,imagesloaded.js?1562849301
##        Log("source_url_vars={}".format(source_url_vars))
##        source_url_vars = source_url_vars[0]
##        source_url2 = "https://cdn-fck.empflix.com/empflix/"+source_url_vars[1] 
##        source_url2 += "-1.fid?key="+source_url_vars[3] 
##        source_url2 += "&VID="+source_url_vars[0]  
##        source_url2 += "&nomp4=1&catID=0&rollover=1&startThumb="+source_url_vars[2] 
##        source_url2 += "&embed=0&utm_source=0&multiview=0&premium=1&country=0user=0&vip=1&cd=0&ref=0&alpha"
##
##        Log("source_url2={}".format(source_url2))
##        source_html2 = utils.getHtml(source_url2, url)
##        regex = '<res>([^<]+).+?<videoLink><!\[CDATA\[([^\]]+)'
##        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
##        Log("sources_list={}".format(sources_list))
##        video_url = utils.SortVideos(sources_list,0)
##        video_url = utils.html_parser.unescape(video_url)
##        Log("video_url={}".format(video_url))
##        video_url = "https:" + video_url + utils.Header2pipestring() + '&Referer=' + url
##        
##    else: #2018 mobile version  if you use an ipad header, but then you are limited in vid resolution
##        regex = '"contentUrl" content="([^"]+)"'
##        source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
##        source_url2 = source_url2[0]
##        video_url = source_url2 + utils.Header2pipestring() + '&Referer=' + url
##
##        regex = 'flashvars.config = escape."([^ ]+)&VID='
##        source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)[0]
##        source_url2 = source_url2 + utils.Header2pipestring() + '&Referer=' + url
##        #Log("source_url2={}".format(source_url2))
##        source_html2 = utils.getHtml(source_url2, url)
##        regex = '<videoLink>(.+?)</videoLink>'
##        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
##        #Log("sources_list={}".format(sources_list))
##        video_url = sources_list[0]


#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)

    regex = "id='categoryList'(.+)"
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##    Log("listhtml={}".format(listhtml))
    
    regex = '<a href="([^"]+)".+?data-original="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
#https://www.youporn.com/category/9/blowjob/?page=2
        videourl = videourl + '?page={}'
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page="1"
            ,iconimage=thumb) #utils.search_icon)
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#
