'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

progress = utils.progress
#play with this to get sorting working the way I want
spacing_for_topmost = ""
spacing_for_names = ""
spacing_for_next = ""
MAX_SEARCH_DEPTH = 10
URL_ROOT = "https://www.pornhub.com"
SEARCH_URL = 'https://www.pornhub.com/video/search?o=mr&search='

@utils.url_dispatcher.register('390')
def Main():
    utils.addDir('[COLOR {}]Search[/COLOR]'.format(utils.search_text_color),SEARCH_URL, 394, '', '')
    utils.addDir('[COLOR {}]Categories[/COLOR]'.format(utils.search_text_color) , URL_ROOT+'/categories?o=al', 393, '', '')
    List(URL_ROOT+'/video?o=cm')
    utils.add_sort_method()
    utils.endOfDirectory()


@utils.url_dispatcher.register('391', ['url'], ['end_directory'])
def List(url, end_directory=True):
    print "pornhub::List " + url
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None
    
    #match = re.compile('<li class="videoblock.+?<a href="([^"]+)" title="([^"]+)".+?<var class="duration">([^<]+)</var>(.*?)</div.*?data-mediumthumb="([^"]+)"', re.DOTALL).findall(listhtml)
    #for videopage, name, duration, hd, img in match:
    match = re.compile('class=\"preloadLine\".+?href=\"\/view_video\.php\?viewkey=([^\"]+)\" title=\"([^\"]+)\".+?data-thumb_url = \"([^\"]+)\".+?\"duration\">([^<]+)<\/', re.DOTALL).findall(listhtml)
    for videopage, name, img, duration in match:
        name = utils.cleantext(name)
        videopage = "/view_video.php?viewkey="+videopage
        Log("videopage='{}'".format(videopage))
        utils.addDownLink(name, URL_ROOT + videopage, 392, img, '', duration=duration)

    np_url=re.compile('<li class="page_next"><a href="(.+?)" class="orangeButton">Next', re.DOTALL).findall(listhtml)
    if np_url:
        np_url = np_url[0]
        Log("np_url='{}'".format(np_url))
        try:
            np_number = np_url.split('=')[3]  #sometimes page number is 3rd
        except:
            np_number = np_url.split('=')[2]  #sometimes page number is 2nd
        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(spacing_for_next,utils.search_text_color, np_number)
        np_url= URL_ROOT + np_url.replace('&amp;','&')

        if end_directory == True:
            Log("np_label='{}'".format(np_label))
            Log("np_url='{}'".format(np_url))
            utils.addDir(np_label, np_url, 391, '', Folder=True)
            utils.add_sort_method()
            utils.endOfDirectory()
        else:
            utils.Notify(msg=np_url, duration=2000)  #let user know something is happening
            if int(np_number) < MAX_SEARCH_DEPTH: #search some more, but not forever
                List(np_url, end_directory)
    else:
        Log("np_url not found")
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register('394', ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 394)
        return

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("Search: " + searchUrl)
    
    List(searchUrl, end_directory)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register('393', ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<div class="category-wrapper ">\s*?<a href="([^"]+)"\s*?alt="([^"]+)".*?<img.*?data-thumb_url="([^"]+)"', re.DOTALL).findall(cathtml)
    for catpage, name, img in match:
        if '?' in catpage:
            utils.addDir(name, URL_ROOT + catpage + "&o=cm", 391, img, '')
        else:
            utils.addDir(name, URL_ROOT + catpage + "?o=cm", 391, img, '')

    utils.add_sort_method()
    utils.endOfDirectory()


@utils.url_dispatcher.register('392', ['url', 'name'], ['download'])    
def Playvid(url, name, download=None):
    Log("url='{}'".format(url))
    html = utils.getHtml(url, '')
    match = re.compile(r"""quality_([0-9]{3,4})p\s*=(?:"|')?([^'";]+)(?:"|')?;""", re.DOTALL | re.IGNORECASE).findall(html)
    match = sorted(match, key=lambda x: int(x[0]), reverse=True)
    videolink = match[0][1]
    Log("videolink='{}'".format(videolink))
    if "/*" in videolink:
        videolink = re.sub(r"/\*[^/]+/", "", videolink).replace("+","")

        linkparts = re.compile(r"(\w+)", re.DOTALL | re.IGNORECASE).findall(videolink)
        for part in linkparts:
            partval = re.compile(part+'="(.*?)";', re.DOTALL | re.IGNORECASE).findall(html)[0]
            partval = partval.replace('" + "','')
            videolink = videolink.replace(part, partval)

    videourl = videolink.replace(" ","")

    utils.playvid(videourl, name, download)
   
