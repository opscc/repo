'''
  Ultimate Whitecream
  Copyright (C) 2016 Whitecream, hdgdl
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib2
import os
import re
import sys
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log
if sys.version_info >= (3, 0):
    from html.parser import HTMLParser
else:
    from HTMLParser import HTMLParser
html_parser = HTMLParser()

#play with this to get sorting working the way I want
spacing_for_topmost = ""
spacing_for_names = ""
spacing_for_next = ""
MAX_SEARCH_DEPTH = 10
URL_ROOT = "https://xhamster.com"
SEARCH_URL = 'https://xhamster.com/search?q=%s&p=1'
cookie = {'Cookie': 'lang=en; search_video=%7B%22sort%22%3A%22da%22%2C%22duration%22%3A%22%22%2C%22channels%22%3A%22%3B0.1.2%22%2C%22quality%22%3A0%2C%22date%22%3A%22%22%7D;'}

@utils.url_dispatcher.register('505')
def Main():
    utils.addDir('[COLOR {}]Search[/COLOR]'.format(utils.search_text_color), SEARCH_URL, 509,'','')
    List('https://xhamster.com/videos/latest')
    utils.add_sort_method()
    utils.endOfDirectory()
	
@utils.url_dispatcher.register('506', ['url'], ['end_directory'])
def List(url, end_directory=True):
    Log("url='{}'".format(url))

    try:
        response = utils.getHtml(url, '', cookie)
    except:
        return None

    #match = re.compile(r'<a href="([^"]+)[^>]+hRotator[^\']+\'([^\']+)[^"]+"([^"]+)[^<]+[^>]+><b>([0-9:]+)<', re.DOTALL | re.IGNORECASE).findall(response)
    match = re.compile(r'thumb-image-container" href="([^"]+)" .+?src="([^"]+)" .+?alt="([^"\n]+)">.+?>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(response)

    #for video, img, name, runtime in match:
    for video, img, name, runtime in match:
        #name = runtime + " - " + utils.cleantext(name)
        name = utils.cleantext(name)
        name = html_parser.unescape(name)
#        Log("video='{}', img='{}', name='{}', runtime='{}',".format(video, img, name, runtime),xbmc.LOGNONE)
        utils.addDownLink(name, video, 507, img \
                          ,'', stream=False, duration=runtime, noDownload=False)

    #currentpage = re.compile("class='pager.*<span>([0-9]+)</span><a", re.DOTALL | re.IGNORECASE).findall(response)
    np_info = re.compile('class=\"xh-paginator-button  active\".+?class=\"xh-paginator-button \".+?href=\"([^\"]+)\".+?data-page=\"([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(response)
    if np_info:
        #Log("np_info='{}'".format(np_info))
        for np_url, np_number in np_info:
            #Log("np_url='{}'".format(np_url))
            np_number = int(np_number)
            currentpage = np_number - 1
            if ".html" in url:
                ##normal page
                np_url = url.replace('-'+str(currentpage)+'.html', '-'+str(np_number)+'.html')
            else:
                ##search page
                if "p=" not in url:
                    np_url = url + "&p=" + str(currentpage)
                np_url = url.replace('p='+str(currentpage),'p='+str(np_number)) 
                
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(spacing_for_next,utils.search_text_color, np_number)

            #Log("np_url='{}'".format(np_url))
            #Log("np_label='{}'".format(np_label))
            
            if end_directory == True:
                utils.addDir(np_label, np_url, 506, '', Folder=True)
                utils.add_sort_method()
                utils.endOfDirectory()
            else:
                utils.Notify(msg=np_url, duration=2000)  #let user know something is happening
                if int(np_number) < MAX_SEARCH_DEPTH: #search some more, but not forever
                    List(np_url, end_directory)

            
    else:
        #note: 2019-05-01 xhamster does not have 'next' on 'newest vid page'
        Log("np_info not found")

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        

@utils.url_dispatcher.register('507', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    response = utils.getHtml(url)
    #match = re.compile("file: '(http[^']+)", re.DOTALL | re.IGNORECASE).findall(response)
    match_720 = re.compile('"mp4":.*?"720p":"([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(response)
    match_480 = re.compile('"mp4":.*?"480p":"([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(response)
    match_240 = re.compile('"mp4":.*?"240p":"([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(response)
    if match_720: match = match_720
    elif match_480: match = match_480
    elif match_240: match = match_240
    
    if match:
        utils.playvid(match[0].replace("\/", "/"), name, download)
    else:
        utils.notify('Oh oh','Couldn\'t find a video')

@utils.url_dispatcher.register('508', ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '', cookie)
    match = re.compile('<a  href="(.+?)">([^<]+)<').findall(cathtml)
    
    for url, name in match[0:]:
        utils.addDir(name, url, 506, '')
    xbmcplugin.endOfDirectory(utils.addon_handle)
    
@utils.url_dispatcher.register('509', ['url'], ['keyword', 'end_directory'] )
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    #Log("Search: " + searchUrl, xbmc.LOGNONE)
    if not keyword:
        utils.searchDir(url, 509)
        return

    title = keyword.replace(' ','_')
    searchUrl = searchUrl % keyword
    #Log("Search: " + searchUrl, xbmc.LOGNONE)
    List(searchUrl, end_directory)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
