'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmcplugin
import urllib, urllib2

from resources.lib import utils
from resources.lib.utils import Log as Log

progress = utils.progress
  

@utils.url_dispatcher.register('130')
def Main():
#    utils.addDir("  [COLOR {}]Categories[/COLOR]".format(utils.search_text_color),'http://www.xvideospanish.net/categorias/',133,'','')
    List('https://www.xvideospanish.net/')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('131', ['url'])
def List(url):
    utils.addDir("  [COLOR {}]Search[/COLOR]".format(utils.search_text_color),'https://www.xvideospanish.com/?s=',134,'','')
    try:        listhtml = utils.getHtml(url, '')
    except:     return None

    match = re.compile('<a href="([^"]+)" title="([^"]+)">.*?<img data-src="([^"]+)"', re.DOTALL | re.IGNORECASE | re.DOTALL ).findall(listhtml)
    for videopage, name, img in match:
        #name = utils.cleantext(name[7:])
        name = " " + utils.cleantext(name)
        utils.addDownLink(name, videopage, 132, img, '')
    try:
        #nextp=re.compile('<a class="nextpostslink" rel="next" href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        #utils.addDir('Next Page', nextp[0], 131,'')
        nextp=re.compile('<link rel="next" href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        #Log(nextp)
        npage=nextp[0].split('/')[4]
        utils.addDir("[COLOR {}]Next Page ({})[/COLOR]".format(utils.search_text_color, npage), nextp[0], 131, '', npage)
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('134', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 134)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)

@utils.url_dispatcher.register('133', ['url'])
def Categories(url):
    Log(url)
    cathtml = utils.getHtml(url, '')
    match = re.compile('data-original="([^"]+)".*?href="([^"]+)">([^<]+)<.*?strong>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for img, catpage, name, videos in match:
        name = "{} [COLOR {}] {} videos[/COLOR]".format(name, utils.search_text_color, videos)
        utils.addDir(name, catpage, 131, img)
    xbmcplugin.endOfDirectory(utils.addon_handle)   


@utils.url_dispatcher.register('132', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    #2019-02-05
    cathtml = utils.getHtml(url, url)
    #parse out and ... 
    match1 = re.compile('itemprop="embedURL" content="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(cathtml)

    if not match1:
        #old style
        #b4 2019-02-05 this was all that was required
        utils.PLAYVIDEO(url, name, download)        
        return
    
    referrer = match1[0]
    match2 = re.compile('itemprop="embedURL" content="([^&]+)&', re.DOTALL | re.IGNORECASE).findall(cathtml)
    begin_url = match2[0].split('id=')[0]
    id_url = match2[0].split('id=')[1]



    
    Log(match2[0])
    #... reverse the string
    videourl = begin_url + 'ir=' + id_url[::-1]
    Log("referrer="+referrer)
    Log("videourl="+videourl)
    #add required headers
    headers = { 'Referer': referrer
                , 'User-Agent': utils.USER_AGENT}
    
    #videourl_with_headers = "{}{}&Referer={}".format(videourl, utils.Header2pipestring(), referrer)
    videourl_with_headers = "{}|{}".format(videourl, urllib.urlencode(headers))
    Log("videourl_with_headers="+videourl_with_headers)

    req = urllib2.Request(videourl)
    req.add_header('Referer', referrer)
    req.add_header('User-Agent', utils.USER_AGENT)
    
    response = urllib2.urlopen(req, timeout=60)
    location = response.info().get('Location')
    Log(  repr(response) )
    Log(response.geturl())
    utils.playvideo(response.geturl(), name, download=download, url=videourl)
    

##GET https://openload.co/stream/5xyKI-fNxsg~1549475847~108.175.0.0~N7lYpDic?mime=true HTTP/1.1
##Host: openload.co
##Connection: keep-alive
##DNT: 1
##Accept-Encoding: identity;q=1, *;q=0
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36
##chrome-proxy: frfr
##Accept: */*
##Referer: https://openload.co/embed/5xyKI-fNxsg//
##Accept-Language: en-US,en;q=0.9
##Range: bytes=0-
##

        
    #return
    #utils.playvid(videourl_with_headers, name, download)

    return

    #b4 2019-02-05 this was all that was required
    utils.PLAYVIDEO(url, name, download)
