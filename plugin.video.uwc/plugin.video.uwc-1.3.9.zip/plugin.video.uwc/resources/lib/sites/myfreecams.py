'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import re
import sys
import random
import sqlite3
import urllib

import traceback

import inputstreamhelper
import time
import random
import json

try:     import simplejson
except:  import json as simplejson   

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib import websocket

from resources.lib.utils import Log as log
from resources.lib.utils import Log

import socket

__user_agent__ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"

import xbmcaddon
ADDON=xbmcaddon.Addon()


MAX_READ_COUNT = 100
CAMGIRLSERVER = None
CAMGIRLCHANID = None
CAMGIRLUID = None
CAMGIRL = None
CXID = None
CTXENC = None
TKX = None
SESSION_ID = None
PLATFORM_ID = None

SERV = None
RESPKEY = None
STYPE = None
OPTS = None

serverList = None                

FCUOPT_PLATFORM_MFC = 1
FCUOPT_PLATFORM_CAMYOU = 2

vs_str={}
vs_str[0]="PUBLIC"
vs_str[2]="AWAY"
vs_str[12]="PVT"
vs_str[13]="GROUP"
vs_str[14]="GROUP"
vs_str[90]="CAM OFF"
vs_str[127]="OFFLINE"
vs_str[128]="TRUEPVT"

@utils.url_dispatcher.register('270')
def Main():


    #["nm","sid","uid","vs","pid","lv",{"u":["camserv","phase","chat_color","chat_font","chat_opt","creation","avatar","profile","photos","blurb"]},{"m":["new_model","missmfc","camscore","continent","flags","rank","rc","topic","hidecs"]}]
    #,["Ally2112",509410217,22597863,2,1,4,1324,"z","6B238E",39,1,1478116147,1,1,41,"jade2112",0,0,                     363.00,"NA",3104,0,2,"plz%20tip%20if%20u%20like%20me%2F5%20tokns%20per%20pm%2F20%20tok%20chat%2F135%20tok%205%20mins%20or%20%2410%20usd%20thru%20paypal%2F50%20tok%20tit%20flash%2F55%20tok%20ass%20flash%2F10%20tok%20splits%2F%2025%20tok%20top%20or%20shorts%20off",1]
    #,["Jonah_sh",509493608,28307153,0,1,4,960,"z","9F5F9F",48,1,1529276155,1,1,7,"Hello, there :)",0,0,                576.50,"NA",68640,0,11,"bored%20and%20horny!%20%20come%20get%20me%20high%20and%20flirt!%20%20all%20requests%20can%20be%20priced!",0]
    #,["HotAnnelisse",515802337,28315476,0,1,4,1218,"z","FF0000",2,1,1529354501,1,1,1,"Life Is Sexxy",0,0,              1353.60,"EU",15392,0,21,"snap---111%20%20whatsapp-333%20show%20cum%20500",0]
    #,["AmelinDesire",517468057,28383938,0,1,4,808,"z","FF0000",5,1,1529961811,1,1,28,"Hello,Im Your Candy Doll!:*",0,0,163.90,"EU",6176,0,2,"",0]],"type":21}'
##    listhtml = '{"count":1608,"op":4,"owner":0,"rdata":[["nm","sid","uid","vs","pid","lv",{"u":["camserv","phase","chat_color","chat_font","chat_opt","creation","avatar","profile","photos","blurb"]},{"m":["new_model","missmfc","camscore","continent","flags","rank","rc","topic","hidecs"]}],["Ally2112",509410217,22597863,2,1,4,1324,"z","6B238E",39,1,1478116147,1,1,41,"jade2112",0,0,363.00,"NA",3104,0,2,"plz%20tip%20if%20u%20like%20me%2F5%20tokns%20per%20pm%2F20%20tok%20chat%2F135%20tok%205%20mins%20or%20%2410%20usd%20thru%20paypal%2F50%20tok%20tit%20flash%2F55%20tok%20ass%20flash%2F10%20tok%20splits%2F%2025%20tok%20top%20or%20shorts%20off",1],["Jonah_sh",509493608,28307153,0,1,4,960,"z","9F5F9F",48,1,1529276155,1,1,7,"Hello, there :)",0,0,576.50,"NA",68640,0,11,"bored%20and%20horny!%20%20come%20get%20me%20high%20and%20flirt!%20%20all%20requests%20can%20be%20priced!",0],["HotAnnelisse",515802337,28315476,0,1,4,1218,"z","FF0000",2,1,1529354501,1,1,1,"Life Is Sexxy",0,0,1353.60,"EU",15392,0,21,"snap---111%20%20whatsapp-333%20show%20cum%20500",0],["AmelinDesire",517468057,28383938,0,1,4,808,"z","FF0000",5,1,1529961811,1,1,28,"Hello,Im Your Candy Doll!:*",0,0,163.90,"EU",6176,0,2,"",0]],"type":21}'
##    json_playlist = json.loads(listhtml)['rdata'] 
##    del json_playlist[0]
##    key = 'HotAnnelisse'
##    for item in json_playlist:
##        if item[0] == key:
##            Log(key)
##            break
##    #Log(repr(json_playlist["HotAnnelisse"]))
##
##    xbmcplugin.endOfDirectory(utils.addon_handle)
##    return

##    #Log(json_playlist.items())
##    Log(repr(json_playlist ))
##    Log(repr(sorted(json_playlist, reverse=True, key=lambda camscore: camscore[18]) ))
##    return
##    json_playlist.sort()
##    Log(repr(json_playlist ))
##    return
##21:52:26.434 T:3444    NONE: [[u'HotAnnelisse', 515802337, 28315476, 0, 1, 4, 1218, u'z', u'FF0000', 2, 1, 1529354501, 1, 1, 1, u'Life Is Sexxy', 0, 0, 1353.6, u'EU', 15392, 0, 21, u'snap---111%20%20whatsapp-333%20show%20cum%20500', 0],
##                              [u'Jonah_sh', 509493608, 28307153, 0, 1, 4, 960, u'z', u'9F5F9F', 48, 1, 1529276155, 1, 1, 7, u'Hello, there :)', 0, 0, 576.5, u'NA', 68640, 0, 11, u'bored%20and%20horny!%20%20come%20get%20me%20high%20and%20flirt!%20%20all%20requests%20can%20be%20priced!', 0],
##                              [u'Ally2112', 509410217, 22597863, 2, 1, 4, 1324, u'z', u'6B238E', 39, 1, 1478116147, 1, 1, 41, u'jade2112', 0, 0, 363.0, u'NA', 3104, 0, 2, u'plz%20tip%20if%20u%20like%20me%2F5%20tokns%20per%20pm%2F20%20tok%20chat%2F135%20tok%205%20mins%20or%20%2410%20usd%20thru%20paypal%2F50%20tok%20tit%20flash%2F55%20tok%20ass%20flash%2F10%20tok%20splits%2F%2025%20tok%20top%20or%20shorts%20off', 1],
##                              [u'AmelinDesire', 517468057, 28383938, 0, 1, 4, 808, u'z', u'FF0000', 5, 1, 1529961811, 1, 1, 28, u'Hello,Im Your Candy Doll!:*', 0, 0, 163.9, u'EU', 6176, 0, 2, u'', 0]]
##
##    json_playlist = json.loads(listhtml)
##    Log(repr(json_playlist['rdata'][1][18] ))
##    entries = sorted(json_playlist.items(), key=lambda items: items['rdata'][1][18], reverse=True)
##    Log(repr(entries))
##        
##    return

    #List('https://www.myfreecams.com/mfc2/php/online_models_splash.php')
    #List('https://www.myfreecams.com/php/FcwExtResp.php?respkey=1988578532&type=14&opts=256&serv=35&nc=0.21365841439926414&_=1533249626968')
    serv, respkey, stype, opts = getRespkey()
    List("https://www.myfreecams.com/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        respkey, stype, opts, serv, random.random(), time.time() )   )

def arrayPositionForKeyname(array, key):
    i=0
    for val in array:
        #Log(str(type(val)) + repr(val))
        if isinstance(val, unicode):
            if val == key:
                #Log("{}".format(i))
                return i 
            i += 1
        elif isinstance(val, dict):
            #Log("L2keys:"+repr(val.keys()))
            #Log("L2vals:"+repr(val.values()))
            for val2 in val.values():
                #Log("L2:"+str(type(val2)) + repr(val2))
                if isinstance(val2, (list, dict, tuple)):
                    for val3 in val2:
                        #Log("L3:" + str(type(val3)) + repr(val3))
                        if val3 == key:
                            #Log("{}".format(i))
                            return i 
                        i += 1
                elif isinstance(val2, unicode):
                    if val2 == key:
                        #Log("{}".format(i))
                        return i
                    i += 1
    return None
                    
@utils.url_dispatcher.register('271', ['url'])
def List(url):

    #utils.addDir("[COLOR {}]Refresh[/COLOR]".format(utils.refresh_text_color),'',mode=273,iconimage='',Folder=False)
    utils.addDir(name="[COLOR {}]Refresh[/COLOR]".format( \
        utils.refresh_text_color) \
        ,url='' \
        ,mode=273 \
        ,iconimage=utils.refresh_icon \
        ,Folder=False \
        )
    
    try: listhtml = utils.getHtml(url)
    except: return None

    json_playlist = json.loads(listhtml)['rdata']

    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ... 
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
    #Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    # ... schema which I don't want [errors during sorting]
    del json_playlist[0] 

    #sort so that top camscore is on top
    entries = sorted(json_playlist, reverse=True, key=lambda camscore: camscore[camscore_index])

    #add list items...
    for playItem in entries:
        if playItem[vs_index] == 0: #only show model in public chat

            serv_number = playItem[camserv_index]
            if Is_new_server(serv_number):
                server439hack = "_a"
                name_hq_prefix = "[COLOR {}]HQ[/COLOR] ".format(utils.time_text_color)
            else:
                server439hack = ""
                name_hq_prefix = ""

            #normalizeServer will return a string such as video1234;
            #I only want to return the 1234 portion
            norm_serv_number = int(filter(str.isdigit,   str(NormalizeServerNumber(serv_number)) )) 

            img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc{}_{}".format( \
                norm_serv_number, \
                server439hack, \
                NormalizeChannelID(playItem[uid_index]))

            camscore = str(int(playItem[camscore_index]))

            utils.addDownLink(name_hq_prefix + playItem[name_index], playItem[name_index], 272, img \
                              ,'', stream=False, duration=camscore, noDownload=True, bitrate=name_hq_prefix)

    utils.add_sort_method()
    xbmcplugin.endOfDirectory(utils.addon_handle)



##    if not isinstance(server, int):  return 0
##    server = int(server)
##    if server >= 1545 and server <= 1559:
##        server = server - 1000
##    elif server >= 500:
##        server = server - 500
##    return server

def NormalizeChannelID(uid, platform_id=FCUOPT_PLATFORM_MFC):
    if not isinstance(uid, int):  return 0
    uid = int(uid)
    if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
        return uid + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
    else:
        return uid + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
    
@utils.url_dispatcher.register('272', ['url', 'name'])
def Playvid(url, name):
    log ("Playvid sys.argv='{}'; utils.addon_handle='{}'; ".format( sys.argv[1], utils.addon_handle )  )
    #return
    videourl = myfreecam_start(url)
    if not videourl:
        Log('Couldn\'t find a playable webcam link')
        return



    normServerNumber = NormalizeServerNumber(CAMGIRLSERVER)
    
    iconimage = xbmc.getInfoImage("ListItem.Thumb")

    listitem = xbmcgui.ListItem(path=videourl)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})

    playmode = int(utils.addon.getSetting('chatplay'))
    if playmode == 22:
        try:
            Log(CAMGIRLSERVER)
            Log(CAMGIRLCHANID)
            Log(CAMGIRLUID)
            Log(CAMGIRL)
            Log(CXID)
            Log(CTXENC)
            Log(CTXENC.split('/')[1] )
            Log(TKX)
            Log(PLATFORM_ID)
        except:
            pass

        #https://forum.kodi.tv/showthread.php?tid=93280
        #listitem.setProperty("SWFPlayer", "https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152")
        #listitem.setProperty("swfUrl", "https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152")
##        listitem.setProperty("server", "{}".format(normServerNumber) ) #"video2003")
##        listitem.setProperty("state", "90")
##        listitem.setProperty("videoPrefix", "video")
##        listitem.setProperty("sessionID", str(CXID)) #"838299700")
##        listitem.setProperty("roomID", str(CAMGIRLCHANID) ) #"120642838")
##        listitem.setProperty("password", str(TKX) ) # "851b61c5da")
##        listitem.setProperty("vidctx", str(CTXENC.split('/')[1]) )#"WzgzODI5OTcwMCwwLDEsMCwwLDAsMCw1MTY3Mjc1XQ==")
##        listitem.setProperty("ngx", "true")
##        listitem.setProperty("phase", "a")
##        listitem.setProperty("mode", "DOWNLOAD")
##        listitem.setProperty("truepvt", "0")
##        listitem.setProperty("platformID", str(PLATFORM_ID) ) #"1")
##        listitem.setProperty("modelID", str(CAMGIRLUID) ) #"20642838")

        #listitem.setProperty("app", "NxServer")
        #listitem.setProperty("pageUrl", "https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=1550272065&target=main")
        #listitem.setProperty("playpath", "mfc_a_{}?ctx={}&tkx={}\"".format(CAMGIRLCHANID, str(CTXENC.split('/')[1]), TKX) )
           
        videourl = "rtmp://{}.myfreecams.com:1935/NxServer".format(normServerNumber)
        videourl += " app=NxServer"
        videourl += " swfUrl=https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152"
        videourl += " tcUrl=rtmp://{}.myfreecams.com:1935/NxServer".format(normServerNumber)
##app: NxServer
##flashVer: WIN 32,0,0,144
##swfUrl: https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152
        videourl += " pageUrl=https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=1550272065&target=main"
##pageUrl: https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=1550272065&target=main
##Playpath: mfc_a_126658261?ctx=Wzg1ODAwMDE1OCwwLDEsMCwwLDAsMCw1MTY3ODA3XQ==&tkx=3b8229a8da
        videourl += " playPath=mfc_a_{}?ctx={}&tkx={}".format(CAMGIRLCHANID, str(CTXENC.split('/')[1]), TKX  )
        #videourl += " flashVer=WIN 32,0,0,142"
        #videourl += " objectEncoding=0"
        videourl += " conn=N:{}".format(str(CXID)) #sessionid
        videourl += " conn=S:{}".format(str(TKX)) 
        videourl += " conn=S:{}".format(str(CAMGIRLCHANID)) 
        videourl += " conn=S:{}".format("a")
        videourl += " conn=S:{}".format("DOWNLOAD")        
        videourl += " conn=N:{}".format(CAMGIRLUID)
        videourl += " conn=N:0"
        videourl += " conn=S:{}".format(str(CTXENC.split('/')[1]))
        
        
##Processing connect
##app: NxServer
##flashVer: WIN 32,0,0,144
##swfUrl: https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152
##ERROR: HTTP_get, TLS_Connect failed
##ERROR: RTMP_HashSWF: connection lost while downloading swfurl https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152
##tcUrl: rtmp://video2011.myfreecams.com:1935/NxServer
##pageUrl: https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=1550272065&target=main
##Playpath: mfc_a_126658261?ctx=Wzg1ODAwMDE1OCwwLDEsMCwwLDAsMCw1MTY3ODA3XQ==&tkx=3b8229a8da
##Saving as: mfc_a_126658261
##INFO: Metadata:
##INFO:   Server                NGINX RTMP fcs-dev 0.180628
##INFO:   width                 1280.00
##INFO:   height                720.00
##INFO:   displayWidth          1280.00
##INFO:   displayHeight         720.00
##INFO:   duration              0.00
##INFO:   framerate             30.00
##INFO:   fps                   30.00
##INFO:   videodatarate         2500.00
##INFO:   videocodecid          0.00
##INFO:   audiodatarate         160.00
##INFO:   audiocodecid          0.00
##INFO:   profile
##INFO:   level
##INFO:   fcsid                 87e53e42-320e-11e9-8dd6-509a4c68a9be
##Playpath: mfc_a_126658261?ctx=Wzg1ODAwMDE1OCwwLDEsMCwwLDAsMCw1MTY3ODA3XQ==&tkx=3b8229a8da
##Saving as: mfc_a_12665826101

##        streamserver = "rtmp://%s/live-edge"%(flv_info[2])
##        modelname = flv_info[1]
##        username = flv_info[8]
##        #utils.Log(flv_info[12].decode(), xbmc.LOGNONE)
##        #utils.Log(flv_info[12].encode('utf8'), xbmc.LOGNONE)
##        #utils.Log(flv_info[12].replace('\u0022', '"'), xbmc.LOGNONE)
##        password = urllib.unquote(flv_info[12].replace('\u0022', '"'))
##        unknown = flv_info[13]
##        swfurl = "https://chaturbate.com/static/flash/CBV_2p690.swf"
##        swfurl = "https://chaturbate.com" + flv_info[0]
##
##        #utils.Log(swfurl, xbmc.LOGNONE)
##        #utils.Log(streamserver, xbmc.LOGNONE)
##        #utils.Log(modelname, xbmc.LOGNONE)
##        #utils.Log(password, xbmc.LOGNONE)
##        #utils.Log(username, xbmc.LOGNONE)
##        
##        
##        videourl = "{} app=live-edge swfUrl={} tcUrl={}"\
##                   .format( streamserver, swfurl, streamserver )
##        videourl += " pageUrl=https://chaturbate.com/{}/ conn=S:AnonymousUser"\
##                    .format(modelname)
##        videourl += " conn=S:{} conn=S:2.690 conn=S:{}"\
##                    .format(modelname ,username)
##        videourl += " conn=S:{} playpath=mp4".format(password)
##        utils.Log(videourl)
##<embed wmode="transparent" 
##src="/flash/MfcVideoNg-1080p-20180424.swf?nc=152" swliveconnect="true" quality="high" 
##flashvars="&amp;server=video2011
##&amp;state=90
##&amp;videoPrefix=video
##&amp;sessionID=857533566
##&amp;roomID=126658261
##&amp;password=a887226b6a
##&amp;vidctx=Wzg1NzUzMzU2NiwwLDEsMCwwLDAsMCw1MTY3Nzk1XQ%3D%3D
##&amp;ngx=true
##&amp;phase=a
##&amp;mode=DOWNLOAD&amp;truepvt=0&amp;platformID=1
##&amp;modelID=26658261" bgcolor="#000000" width="480" height="270" id="fvideo_ff" name="fvideo" 
       
    elif  videourl.endswith('.mpd') or playmode == 3: # Inputstream
        utils.Log("videourl mpd='{}'".format(videourl), xbmc.LOGNONE)
        is_helper = inputstreamhelper.Helper('mpd')
        listitem.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        listitem.setProperty('inputstream.adaptive.stream_headers', utils.Header2pipestring(utils.headers).replace("|", '') + \
                             '&Origin=https://www.myfreecams.com&Referer=https://www.myfreecams.com/_html/player.html?broadcaster_id=0')
        
        if  videourl.endswith('.mpd'):
            listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        else:
            log ("HLS:'.mpd') or ('.m3u8'")
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')

        if not '|' in videourl: videourl = videourl + utils.Header2pipestring()

            
    else:
        log ("not .mpd")

        if playmode == 1: # F4mProxy
            m3u8stream = "{}{}".format(videourl, utils.Header2pipestring() )
            utils.Log("fmproxy m3u8stream='{}' {}".format(m3u8stream, int(utils.addon.getSetting('max_bit_rate'))*1000*1000), xbmc.LOGNONE)
            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            f4mp.playF4mLink(
                m3u8stream
                , name
                , proxy = None
                , use_proxy_for_chunks = False
                , maxbitrate = int(utils.addon.getSetting('max_bit_rate'))*1000*1000
                , simpleDownloader = False
                , auth = None
                , streamtype = 'HLSREDIR'
                , setResolved = False
                , swf = None
                , callbackpath = ""
                , callbackparam = ""
                , iconImage = iconimage

                )
            #, download_path='c:\\temp\\Swish Swish (Ft. Nicki Minaj) - Katy Perry.ts'
            return
        
            
    if not '|' in videourl: videourl = videourl + utils.Header2pipestring()
            
    #log ("Playvid sys.argv='{}'; utils.addon_handle='{}'; ".format( sys.argv[1], utils.addon_handle )  )
    if int(sys.argv[1]) == -1:
        log ("no handle")
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        pl.add(videourl, listitem)
        xbmc.Player().play(pl)
    else:
        log ("yes handle")
        xbmcplugin.setResolvedUrl( utils.addon_handle , True, listitem)


def valid_info():
    if CAMGIRLSERVER < 0 :
        log('valid_info: missing camgirlserver')
        return False
    if CAMGIRLCHANID < 0:
        log('valid_info: missing CAMGIRLCHANID')
        return False
    if CAMGIRLUID < 0:
        log('valid_info: missing CAMGIRLUID')
        return False
    if not CAMGIRL:
        log('valid_info: missing CAMGIRL')
        return False
    if not CXID:
        log('valid_info: missing CXID')
        #return False
    if not CTXENC:
        log('valid_info: missing CTXENC')
        #return False
    if not TKX:
        log('valid_info: missing TKX')
        #return False
    if not PLATFORM_ID:
        log('valid_info: missing PLATFORM_ID')
        return False

    return True
    
def fc_decode_json(m):
    try:
        m = m.replace('\r', '\\r').replace('\n', '\\n')
        return simplejson.loads(m[m.find("{"):].decode("utf-8","ignore"))
    except:
        return simplejson.loads("{\"lv\":0}")

def read_model_data(m, camgirl_to_find):
    global CAMGIRLSERVER
    global CAMGIRLCHANID
    global CAMGIRLUID
    global CAMGIRL
    global PLATFORM_ID

    msg = fc_decode_json(m)
    log( "msg:%s" % simplejson.dumps(msg) )

    try:
        if msg['uid'] == 0:
            return # these lines don't have any more useful information    
    except:
        pass

    try:
        if msg['uid'] == camgirl_to_find:
            log( "uid:%s" % camgirl_to_find, xbmc.LOGERROR )
            
    except:
        return
    
    try:
        if camgirl_to_find == msg['nm'].lower():
            CAMGIRL = msg['nm'] #make sure we know who we are talking to:  'nm' can exist multiple places
    except:
        return
    
    if CAMGIRL:

        #vs = visibility status; 0 value means in public chat...don't know how to parse group/private chats
        vs = msg['vs']
        if not (vs == 0):
            vs_string=vs_str[vs]
            utils.notify(msg="{} is {}".format(CAMGIRL, vs_string) )
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            CAMGIRLCHANID = -1
            CAMGIRLUID = -1
            return

        try:
            CAMGIRLUID    = msg['uid']
            PLATFORM_ID   = msg['pid']
            if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
                CAMGIRLCHANID = msg['uid'] + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
            else:
                CAMGIRLCHANID = msg['uid'] + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
        except:
            pass

        u_info=msg['u']
        try:
            CAMGIRLSERVER = u_info['camserv']
        except KeyError:
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            pass
        except Exception, e:
            #log(('parsing msg dictionary for name:%s' % str(e) ), xbmc.LOGERROR)
            pass

def millitime():
    return int(time.time()) * 1000


def getServerList():
    global serverList

    if serverList:
        return serverList
    #connect to one of the chat servers; random since we don't know how to parse page
    #we need to use 8080 because the other choice, https, does not work with websocket
    url="https://m.myfreecams.com/configproxy.php".format(random.random())
    try:
        listhtml = utils.getHtml(url)
    except:
        traceback.print_exc()
        return None

    serverList = simplejson.loads(listhtml)
    return serverList

def chatserverList():
    return getServerList()['chat_servers']

def h5videoserverList():
    return getServerList()['h5video_servers']

def ngvideoserverList():
    return getServerList()['ngvideo_servers']

def wzvideoserverList():
    return getServerList()['wzobs_servers']



def NormalizeServerNumber(server):
    result_server = server
    try:
        result_server = ngvideoserverList()[str(server)]
    except:
        try:
            result_server = h5videoserverList()[str(server)]
        except:
            try:
                result_server = wzvideoserverList()[str(server)]
            except:
                result_server = 'video' + str(server)
                log("excepti start:{} end:{}".format(server, result_server))
        
    log("NormalizeServerNumber start:{} end:{}".format(server, result_server))
    return result_server

def getChatServerWebsocket_test(login_version='20080910'):

    global SESSION_ID
    global CXID
    global CTXENC
    global TKX
    global SERV
    global RESPKEY
    global STYPE
    global OPTS
    
##    #internal chat server list
##    #acutal list at https://m.myfreecams.com/configproxy.php
##    xchat=[
##        20, 22, 23, 24, 25, 28, 29,
##        30, 31, 32, 33, 34, 35, 36, 39,
##        42, 43, 44, 45, 46, 47, 48, 49,
##        50, 51, 52, 53, 54, 58, 59, 
##        60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
##        70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
##        80, 81, 83, 84, 85, 86, 87, 88, 89,
##        90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
##        100, 101, 102, 103, 104, 105, 106, 109,
##        111, 112, 113, 114, 115, 116, 118, 119,
##        120, 121, 122, 123, 124, 125, 126, 127
##      ]

##    #connect to one of the chat servers; random since we don't know how to parse page
##    #we need to use 8080 because the other choice, https, does not work with websocket
##    url="https://m.myfreecams.com/configproxy.php".format(random.random())
##    try:
##        listhtml = utils.getHtml(url)
##    except:
##        traceback.print_exc()
##        return None

    #xchat = simplejson.loads(listhtml)['chat_servers']
    xchat = chatserverList()
    #log(repr(xchat))

    sock_buf=None
    ws = None
    failed_count = 0
    failed_count_max = 12
    while not ws and (failed_count < failed_count_max):
        try: 
            #server_number = str(random.choice(xchat))
            #host = "ws://xchat"+server_number+".myfreecams.com:8080/fcsl"
            #host = "wss://xchat"+server_number+".myfreecams.com/fcsl"
            

            FCTYPE_EXTDATA = 81
            FCTYPE_LOGIN = 1
            
            url="https://api.myfreecams.com/dc?nc={}&site=mobileweb".format(random.random())
            try:
                start_time = millitime()
                listhtml = utils.getHtml(url)
                stop_time = millitime()
            except:
                try:
                    listhtml = utils.getHtml(url)
                    stop_time = millitime()
                except:
                    raise

            #log(listhtml)
            #log(repr(simplejson.loads(listhtml)['result'] ))
            temp_cid = simplejson.loads(listhtml)['result']['cid']
            #1 0 0 81 0 %7B%22err%22%3A0%2C%22start%22%3A1540244867743%2C%22stop%22%3A1540244867841%2C%22a%22%3A9841%2C%22time%22%3A1540244866%2C%22key%22%3A%22e228274f6d0a0f01ab5fe96b400efea5%22%2C%22cid%22%3A%22e2f15f2f%22%2C%22pid%22%3A1%2C%22site%22%3A%22mobileweb%22%7D
            #1 0 0 81 0 %7B%22err%22%3A0%2C%22start%22%3A1540312443000%2C%22stop%22%3A1540312443000%2C%22a%22%3A9841%2C%22time%22%3A1540312440%2C%22key%22%3A%22dac863e753ca9e58cf14947580317586%22%2C%22cid%22%3A%228dcc26f8%22%2C%22pid%22%3A1%2C%22site%22%3D%22mobileweb%22%7D


            temp_key = simplejson.loads(listhtml)['result']['key']
            temp_time = int(simplejson.loads(listhtml)['result']['time'])
            #log(temp_cid)
            #log(temp_key)
            #log(str(temp_time))
            socket_message_1 = "{} 0 0 {} 0 ".format(FCTYPE_LOGIN, FCTYPE_EXTDATA)
            
            socket_message_2 = '"err":0,"start":{},"stop":{},"a":9841,"time":{},"key":"{}","cid":"{}","pid":{},"site":"mobileweb"'.format( \
                       start_time, stop_time, temp_time, temp_key, temp_cid, FCUOPT_PLATFORM_MFC)
            socket_message_2 = '{'+socket_message_2+'}'
            #log(socket_message_2)
            socket_message_2=urllib.quote(socket_message_2)
            #log(socket_message_2)
            socket_message = socket_message_1 + socket_message_2
            #log(socket_message)


            ws = None
            while not ws and (failed_count < failed_count_max):
                try:
                    failed_count += 1
                    ws = websocket.WebSocket()
                    host = "wss://{}.myfreecams.com/fcsl".format(random.choice(xchat))
                    log("connecting to host '{}'".format(host) )
                    ws = websocket.create_connection(host)
                except:
                    #traceback.print_exc()
                    time.sleep(0.1)
                    ws = None

            time.sleep(1)
            ws.send("fcsws_20180422\n\0")
            ws.send(socket_message + "\n\0")
            
            sock_buf=None
            sock_buf = ws.recv()
            #log(sock_buf)
            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            temp_login_id = hdr.group(6)

            socket_message = "{} 0 0 {} 0 {}@guest:guest".format(FCTYPE_LOGIN, login_version, temp_login_id)
            #log(socket_message)
            ws.send(socket_message + "\n\0" )

            #ws.close()
            #return
            #log("her")

            sock_buf=None
            quitting = 0
            fc = None
            readcount = 0
            while quitting == 0:
                sock_buf = ws.recv()
                readcount = readcount+1
                if readcount > 20: break #infinite loop detection
                while True:
                    #log("raw_buf:'{}'".format(sock_buf))
                    hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
                    #if bool(hdr) == 0:
                    #    log("recv() again")
                    #    #break #recv() again for the response we need

                    fc = hdr.group(1)
                    #log("header group:%s"%fc)
                    #first six bytes of fc tells us size of message
                    #rest of bytes in fc is the fc message type
                    mlen   = int(fc[0:6])# characters from position 0 (included) to 6 (excluded)
                    msg=sock_buf[6:6+mlen] 
                    if len(msg) < mlen:
                        log("len(msg) {} < mlen {}".format(len(msg), mlen))
                        #rembuf=''.join(sock_buf)
                        #break

                    FCTYPE_MODELGROUP = 33
                    FCTYPE_TKX = 30
                    #log("msg:%s"%msg)
                    msg = fc_decode_json(urllib.unquote(msg))
                    #log("msg:%s" % simplejson.dumps(msg) )

                    try:
                        CXID = msg['cxid']
                        CTXENC = urllib2.unquote(msg['ctxenc'])
                        TKX = msg['tkx']
                        log( "CxID={}".format(CXID) )
                        break # these lines don't have any more useful information
                    except:
                        pass
            
                    try:
                        uid = int(msg['uid'])
                        if uid == 0:
                            SESSION_ID = msg['sid']
                            log( "GuestID={}".format(msg['nm']) )
                        quitting = 1 #all necessary info should be here by now
                        break # these lines don't have any more useful information
                    except:
                        pass
            
                    try:
                        if not SERV: #these variables are sent twice differently - we only need the first
                            SERV = msg['serv']
                            RESPKEY = msg['respkey']
                            STYPE = msg['type']
                            OPTS = msg['opts']
                            break # these lines don't have any more useful information
                        #return serv, respkey, stype, opts
                    except:
                        pass

                    sock_buf=sock_buf[6+mlen:]
                    if len(sock_buf) == 0:
                        break

        except Exception, e:
            failed_count += 1
            log("xchat server '{}' could not be opened [{}]".format(repr(e), failed_count))
            ws = None


    return ws


##def getChatServerWebsocket(login_version='20080910'):
##
##    global SESSION_ID
##    global CXID
##    global CTXENC
##    global TKX
##    global SERV
##    global RESPKEY
##    global STYPE
##    global OPTS
##
##    
##    #internal chat server list
##    #acutal list at https://m.myfreecams.com/configproxy.php
##    xchat=[
##        20, 22, 23, 24, 25, 28, 29,
##        30, 31, 32, 33, 34, 35, 36, 39,
##        42, 43, 44, 45, 46, 47, 48, 49,
##        50, 51, 52, 53, 54, 58, 59, 
##        60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
##        70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
##        80, 81, 83, 84, 85, 86, 87, 88, 89,
##        90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
##        100, 101, 102, 103, 104, 105, 106, 109,
##        111, 112, 113, 114, 115, 116, 118, 119,
##        120, 121, 122, 123, 124, 125, 126, 127
##      ]
##
##    #connect to one of the chat servers; random since we don't know how to parse page
##    #we need to use 8080 because the other choice, https, does not work with websocket
##
##
##    sock_buf=None
##    ws = None
##    failed_count = 0
##    failed_count_max = 12
##    while not ws and (failed_count < failed_count_max):
##        try: 
##            server_number = str(random.choice(xchat))
##            host = "ws://xchat"+server_number+".myfreecams.com:8080/fcsl"
##            host = "wss://xchat"+server_number+".myfreecams.com/fcsl"
##            log("connecting to host '{}'".format(host) )
##            ws = None
##            ws = websocket.WebSocket()
##            ws = websocket.create_connection(host)
##            ws.send("1 0 0 {} 0 guest:guest\n\0".format(login_version) )
##            ws.send("0 0 0 0 0 -\n\0")
##            #return ws
##        except Exception, e:
##            failed_count += 1
##            log("xchat server '{}' could not be opened [{}]".format(repr(e), failed_count))
##            ws = None
##    #log("her")
##
##    sock_buf=None
##    quitting = 0
##    fc = None
##    readcount = 0
##    while quitting == 0:
##        sock_buf = ws.recv()
##        readcount = readcount+1
##        if readcount > 20: break
##        while True:
##            log(sock_buf)
##            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
##            if bool(hdr) == 0:
##                #log("recv() again")
##                break #recv() again for the response we need
##
##            fc = hdr.group(1)
##            mlen   = int(fc[0:4])
##            msg=sock_buf[4:4+mlen]
##            if len(msg) < mlen:
##                log("len(msg) < mlen")
##                rembuf=''.join(sock_buf)
##                break
##            
##            msg = fc_decode_json(urllib.unquote(msg))
##            log( "msg:%s" % simplejson.dumps(msg) )
##
##            try:
##                CXID = msg['cxid']
##                CTXENC = urllib2.unquote(msg['ctxenc'])
##                TKX = msg['tkx']
##                log( "CxID={}".format(CXID) )
##                break # these lines don't have any more useful information
##            except:
##                pass
##    
##            try:
##                uid = int(msg['uid'])
##                if uid == 0:
##                    SESSION_ID = msg['sid']
##                    log( "GuestID={}".format(msg['nm']) )
##                quitting = 1 #all necessary info should be here by now
##                break # these lines don't have any more useful information
##            except:
##                pass
##    
##            try:
##                if not SERV: #these variables are sent twice differently - we only need the first
##                    SERV = msg['serv']
##                    RESPKEY = msg['respkey']
##                    STYPE = msg['type']
##                    OPTS = msg['opts']
##                    break # these lines don't have any more useful information
##                #return serv, respkey, stype, opts
##            except:
##                pass
##
##            readcount = readcount+1
##
##            sock_buf=sock_buf[4+mlen:]
##            if len(sock_buf) == 0:
##                break
##
##    log("her-end")
##
##    return ws
    
def getRespkey(camgirl_to_find=''):

    if not SERV:
        ws = getChatServerWebsocket_test()
        #ws = getChatServerWebsocket()
        if ws:
            ws.close()

    return SERV,RESPKEY,STYPE,OPTS

def getCamgirlList():
    Log("\n getCamgirlList {} \n".format(''))
    #return json-like list of online models
    serv, respkey, stype, opts = getRespkey()
    url = "https://www.myfreecams.com/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        respkey, stype, opts, serv, random.random(), time.time() )

    try:
        listhtml = utils.getHtml(url)
    except:
        return None

    return json.loads(listhtml)['rdata'] 

def getCamgirlInfo(camgirl_to_find, json_playlist):
    #Log("\n getCamgirlInfo [{},{}] \n".format(camgirl_to_find, json_playlist[0]))

    if not json_playlist:
        return None, None, None, None

    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ... 
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
    #Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    #del json_playlist[0] #we may not delte this entry because variable is by reference and future calls may need it
    
    key = camgirl_to_find #'HotAnnelisse'
    for item in json_playlist:
        if item[name_index] == key:
            Log("\n getCamgirlInfo [{},{}] \n".format(camgirl_to_find, repr(item)))
            if item[vs_index] !=0:  #return null if not online
                return None, None, None, None
            
            camserv = int(item[camserv_index])
            is_new_server  = Is_new_server(camserv)

            #normalizeServer will return a string such as video1234;
            #I only want to return the 1234 portion
            camserv = int(filter(str.isdigit,   str(NormalizeServerNumber(camserv)) )) 

            camscore = int(item[camscore_index])

            uid = NormalizeChannelID(item[uid_index])
            Log("\n getCamgirlInfo returning [{},{},{},{}] \n".format(key, camserv, uid, is_new_server  ))
            return camserv, uid, is_new_server, camscore
            break

    return None, None, None, None

def Is_new_server(camserv):
    #corresponds to "onWzObsVideoServer" json information that we may need to start parsing
    #log(str(camserv))        
    try:
        
        server = ngvideoserverList()[str(camserv)]
        #log ("return Is_new_server = true")
        return True
    except:
        try:
            server = wzvideoserverList()[str(camserv)]
            #log ("return Is_new_server = true")
            return True
        except:
            #log ("return Is_new_server = false")
            return False

    return    (camserv in range(545,559))        \
                        or (camserv in range(437,440))  \
                        or (camserv in range(888,897))  
    

def myfreecam_start(camgirl_to_find):

#getCamgirlInfo returning [ChillANNout,548,129724868,True]
#                                             getCamgirlInfo [ChillANNout,[u'ChillANNout', 760339032, 29724868, 0, 1, 4, 1554, u'a', u'FF0000', 31, 1, 1538427081, 1, 1, 1, u'One day a week im just being myself,the rest of the week-restoring reputation.', 0, 0, 7183.8, u'EU', 343072, 98, 89, u'check%20my%20hair.7%20if%20im%20cute%2C88%20love%2C999%20snap%2C666%20shot%2C333%20black%20jack%2C150%20pm%2C140%204%20spanks%2C4444%20happy', 0]]
#    camgirl_to_find = '29724868'
    camgirl_to_find = camgirl_to_find.lower()
    
    log("\n myfreecam_start [{}] \n".format(camgirl_to_find))

    ws = None
    attempts = 0
    max_attempts = 2
    while (not ws) and (attempts < max_attempts):
        #ws = getChatServerWebsocket_test('20071025')
        ws = getChatServerWebsocket_test('20180422')
        #ws = getChatServerWebsocket()
        time.sleep(1)
        attempts = attempts + 1
        log ("attempt to getChatServerWebsocket")

    if not ws:
        utils.notify( "Failed to get websocket connection.  Check internet connection or try later")
        return ''
    
    rembuf=""
    quitting = 0
    readcount = 0

    #log( "SESSION_ID={}".format(SESSION_ID) )

    websocket_search_command = "10 {} 0 {} 0 {}".format(SESSION_ID, int(time.time()), camgirl_to_find)
    log("websocket_search_command=" + websocket_search_command)
    ws.send(websocket_search_command+"\n\0")

    MESSAGE_FIELD_LENGTH = 6 #for 2018 messages
    #MESSAGE_FIELD_LENGTH = 4 #for 2017 messages
    while quitting == 0:
        
        readcount = readcount + 1
        if readcount > MAX_READ_COUNT:
            log ("readcount > MAX_READ_COUNT")
            break

        sock_buf =  ws.recv()
        sock_buf = rembuf + sock_buf
        
        rembuf=""
        while True:
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX

            log("rawsock_buf:%s"%sock_buf)

            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
#           log( repr(hdr) )
            if bool(hdr) == 0:
                log ("bool(hdr) == 0:")
                quitting=1
                break #recv() again for the response we need

            fc = hdr.group(1)
            mlen   = int(fc[0:MESSAGE_FIELD_LENGTH])

            FCRESPONSE_SUCCESS = 0
            FCRESPONSE_ERROR = 1
            if int(hdr.group(5)) == FCRESPONSE_ERROR:
                utils.Notify(msg="'{}' renamed or deleted".format(camgirl_to_find))
                quitting=1
                break

            msg=sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH+mlen]
            if len(msg) < mlen:
                rembuf=''.join(sock_buf)
                log ("len(msg) < mlen")
                break

            read_model_data( urllib.unquote(msg) , camgirl_to_find) 

            if valid_info():
                quitting=1
                break

            if CAMGIRLSERVER == -1:
                quitting=1
                break

                sock_buf=sock_buf[MESSAGE_FIELD_LENGTH+mlen:]
            if len(sock_buf) == 0:
                #log ("len(sock_buf) == 0:")
                break

    ws.close()

    if readcount > MAX_READ_COUNT:
        utils.notify(msg= "{} was not found.  Maybe renamed".format(camgirl_to_find), duration=10000, sound=False)
        return ''
    
    if not valid_info() or (CAMGIRLSERVER < 1) :
        #utils.notify( msg = ("{} is not online".format(camgirl_to_find)) )
        return ''

    try:

        head = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"

        if Is_new_server(CAMGIRLSERVER):
            serv, respkey, stype, opts = getRespkey('') #populates value for CXID
            
            #try new servers
            Url="https://{}.myfreecams.com:8444/x-hls/{}/{}/{}/mfc_a_{}.m3u8{}".format(
                NormalizeServerNumber(CAMGIRLSERVER)
                , CXID
                , CAMGIRLCHANID
                , urllib.quote(CTXENC)
                , CAMGIRLCHANID
                , "?nc="+str(random.random())
                ) 
            log('attempt connecting to HLS host {}|User-Agent={}'.format(Url,head))
            req = urllib2.Request(Url)
            req.add_header('User-Agent', head)
            try:
                aa = urllib2.urlopen(req, timeout=10)
                Url = Url +('|user-agent='+head)
                log('returning URL ' + Url)
                #utils.notify(msg= "{} is HQ".format(camgirl_to_find), duration=10000, sound=False)
                return Url
            except Exception, e:
                log("exception '{}' opening url '{}' ".format(repr(e),Url))
                #utils.notify( 'Oh oh', ("URL for {} is not responding".format(CAMGIRL)))
                Url = ''


        #mobile site
        #Url="http://video"+str(CAMGIRLSERVER)+".myfreecams.com:1935/NxServer/ngrp:mfc_"+str(CAMGIRLCHANID)+".f4v_mobile/playlist.m3u8" 
        if Is_new_server(CAMGIRLSERVER):
            server439hack = "_a"
        else:
            server439hack = ""

        if PLATFORM_ID == FCUOPT_PLATFORM_MFC:
            if ADDON.getSetting('use_mobile_stream').lower() == "true":
                Url = "https://{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8".format( \
                    NormalizeServerNumber(CAMGIRLSERVER),server439hack,CAMGIRLCHANID)
            else:
                Url = "https://{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_desktop/manifest.mpd".format( \
                    NormalizeServerNumber(CAMGIRLSERVER),server439hack,CAMGIRLCHANID)
        elif PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
            Url="https://{}.camyou.com/NxServer/ngrp:cam_{}.f4v_desktop/manifest.mpd".format( \
                NormalizeServerNumber(CAMGIRLSERVER),CAMGIRLCHANID)


        log('attempt connecting to host {}|{}'.format(Url,head))
        req = urllib2.Request(Url)
        req.add_header('User-Agent', head)
        try:
            aa = urllib2.urlopen(req, timeout=15)
            #log("aa contents '%s' " % aa.read().encode('UTF-8'))
            return Url
        except Exception, e:
            log("exception '{}' opening url '{}' ".format(repr(e),Url))
            #Url = ""

        if Url == '':
            utils.notify( 'Oh oh', ("URL for {} is not responding".format(camgirl_to_find)))
                    
    except Exception, e:
        log(('attempt connecting to err:%s' % str(e) ), xbmc.LOGERROR)
        return ''

    utils.notify( msg = ("{} is not online".format(camgirl_to_find)))
    return Url

@utils.url_dispatcher.register('273')
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            if showdialog==True:
                utils.notify('Finished','Images cleared')
    except:
        pass

    if showdialog==True:
        xbmc.executebuiltin('Container.Refresh')
    
