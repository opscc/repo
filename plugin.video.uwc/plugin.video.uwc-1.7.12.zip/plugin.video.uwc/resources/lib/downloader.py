#-*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
import traceback
from utils import *
import xbmc
import xbmcvfs
import xbmcgui

import sqlite3
import datetime
import _strptime #because https://www.raspberrypi.org/forums/viewtopic.php?t=166912

downloads_db = ":memory:" #maybe one day create a service that keeps conn in memory; easier to clean dead connections
downloads_db = C.favoritesdb

#__________________________________________________________________________
#
class Progress_Dialog(object):
    import threading, xbmcgui
    def __init__(
        self
        , title
        , message
        ):
        if threading.current_thread().name != "MainThread":
            self.dialog_progress = None
        self.dialog_progress = xbmcgui.DialogProgress()
        self.dialog_progress.create(title, message)
    def iscanceled(self):
        if self.dialog_progress:
            return self.dialog_progress.iscanceled()
        else:
            return True
    def close(self):
        if not self.dialog_progress: return
        self.dialog_progress.close()
        self.dialog_progress = None
    def update(self
               ,percent
               ,message=None
               ,line2=None
               ,line3=None
               ):
        if not self.dialog_progress: return

        if not message:
            self.dialog_progress.update(percent)
            return
        if not line2:
            self.dialog_progress.update(percent, message)
            return
        if not line3:
            self.dialog_progress.update(percent, message, line2)
            return
        self.dialog_progress.update(percent, message, line2, line3)
#__________________________________________________________________________
#
class StopDownloading(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)
#__________________________________________________________________________
#
def Clean_Filename(s, include_square_braces=True, delete_first_color=False):
    if not s: return ''
    s = s.strip('\r')
    if delete_first_color:
        s = (re.sub(u'(?i)\[cOLOR \w+?\].+?\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(u'(?i)\[\/Color\]','',s))
    if include_square_braces:
        s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_]',' ',s))
    else:
        s = (re.sub(u'(?is)[^A-Za-z0-9~     ,\'.&_]',' ',s))
    while '  ' in s:
        s = s.replace('  ', ' ')
    return s.strip()
#__________________________________________________________________________
#
def Make_download_path(name = '', include_date = False, file_extension = ''):
    Log(u"Make_download_path name='{}'".format(name))

    name = Clean_Filename(name)
   
    download_path = unicode(C.addon.getSetting("download_path").lower())
    Log("Make_download_path download_path='{}'".format(download_path))    
    if download_path == '':
        try:
            download_path = xbmcgui.Dialog().browse(0, "Download Path", 'myprograms', '', False, False)
            C.addon.setSetting(id='download_path', value=download_path)
            if not os.path.exists(download_path): os.mkdir(download_path)
        except:
            raise 
    download_path = download_path + name

    if include_date:
        download_path = download_path + datetime.datetime.now().strftime(".%Y-%m-%d")

    download_path = download_path + file_extension
    
    Log("Make_download_path download_path='{}'".format(download_path))
    return download_path
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_STOP_DOWNLOAD, ['url','name'], ['refresh_container'])
def Stop_Download(url,name,refresh_container=True):
    name = Clean_Filename(name,delete_first_color=True)
    Log("Stop_Download({},{}) start".format(name, url))

##    Log(repr(sys.argv)+repr(sys.argv[2]),LOGNONE)
    
##    if refresh_container == False:
##        Manage_Downloads()
####        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
####        xbmc.executebuiltin("Container.Refresh")
##        Log("Stop_Download end '{}'".format(url))
##        return

    
    progress_dialog = None
    if refresh_container == True:
        progress_dialog = Progress_Dialog(C.addon_name,"stopping {}".format(name))

##    progress_dialog = None
##    if threading.current_thread().name == "MainThread":
##        progress_dialog = xbmcgui.DialogProgress()
##        progress_dialog.create(C.addon_name,"stopping {}".format(name))
    
    import gc
    stop_name = None
    loop_interruptor = 0
    for obj in gc.get_objects():
        loop_interruptor += 1
        if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS: # pause to allow other stuff
            if progress_dialog and progress_dialog.iscanceled():
                obj = None
                break
            Sleep(C.GC_SEARCHLOOP_PAUSE) # pause to allow other stuff
            loop_interruptor = 0        
        if '__class__' in repr(dir(obj)) :
            if (
                'HLSDownloaderRetry.HLSDownloaderRetry' in repr(obj.__class__)
                or
                'MP4Downloader' in repr(obj.__class__)
                ):
                if hasattr(obj, 'stop_playing_event') and hasattr(obj, 'url'):
                    if url.startswith(obj.url) and obj.stop_playing_event:
                        obj.stop_playing_event.set()
                        stop_name = obj.name
                        obj = None
                        break
    else:
        pass
##        Log("does this happen on loop break?", LOGNONE)
##        obj = None


    if stop_name and obj is None:
        Notify("Stopped '{}'".format(stop_name))
        delete_download(url)        
    elif obj: #went through everything but not background thread in gc
        Notify("Deleted <inactive> {} from database".format(name))
        delete_download(url)        
        #raise Exception("found obj, but could not stop")
    else:
        Log("Cancelled delete of {}".format(name))

    if progress_dialog: progress_dialog.close()

##    Log(repr(sys.argv[1]))
##    xbmcplugin.setResolvedUrl(sys.argv[1], True)

    Log("Stop_Download end '{}'".format(url))


    if refresh_container == True:
        xbmc.executebuiltin("Container.Refresh")
    return

    if refresh_container:
        #xbmc.executebuiltin("Container.Refresh")
        
        Log(threading.current_thread().name)
        if threading.current_thread().name == "MainThread": #no refresh when called in a background thread; 
    #        Manage_Downloads() #using this will leave a history
            #xbmc.executebuiltin("Container.Refresh")
            st = "ReplaceWindow(Videos,{})".format(sys.argv[0]+sys.argv[2]+"&refresh_container=false")
##            Log(st, LOGNONE)
            xbmc.executebuiltin(st)
##        xbmc.executebuiltin("PreviousMenu")
        #xbmc.executebuiltin('Container.Update()')
        pass
#__________________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_MANAGE_DOWNLOADS)
def Manage_Downloads():
    Log("Manage_Downloads start")
##    Log(threading.current_thread().name, LOGNONE)
##    threading.current_thread().name = "Manage_Downloads"
##    Log(threading.current_thread().name, LOGNONE)
    clean_downloads()
    one_instance_found = False
    for name, url, c, d, start_time, e, f, g, h in active_downloads():
        one_instance_found = True
        name = "[COLOR {}]Stop downloading[/COLOR] '{}'".format(
            C.search_text_color
            , name[len(C.DOWNLOAD_INDICATOR):]
            )
        #using adddir adds error message to log; shows 'busy' indicator
##        addDir(
##            name = name
##            , url = url
##            , mode = C.ROOT_STOP_DOWNLOAD
##            )
        #using addownlink has right click menu; manully have to show 'busy' indicator        
        addDownLink(
            name = name
            , url = url
            , mode = C.ROOT_STOP_DOWNLOAD
            , play_method = C.PLAYMODE_NO_OPTIONS
            )
    if one_instance_found == False:
        addDir(
            name="Nothing downloading in background"
            , url=C.DO_NOTHING_URL
            , mode=C.ROOT_INDEX_INDEX
            )
    Log("Manage_Downloads end")    
    endOfDirectory()
    #endOfDirectory(updateListing=True)
    return 
##
##    import gc
##
##    has_more = True
##    one_instance_found = False
##    loop_interruptor = 0
##    
##    try:
##        
##        while has_more:
##            has_more = False
##            for obj in gc.get_objects():
##                loop_interruptor += 1
##                if loop_interruptor > C.GC_SEARCHLOOP_ITERATIONS: # pause to allow other stuff
##                    Sleep(C.GC_SEARCHLOOP_PAUSE) # pause to allow other stuff
##                    loop_interruptor = 0
##                try:
####                    Log(repr(dir(obj)))
##                    if '__class__' in repr(dir(obj)) : # isInstance does not work; also some objects don't implement __class__
##                        if 'HLSDownloaderRetry.HLSDownloaderRetry' in repr(obj.__class__):
##                            if obj.stop_playing_event:
####                                Log("HLSDownloaderRetry object found='{}'".format(obj.name))
##                                if obj.stop_playing_event.isSet() == False:
##
##                                    
##
##                                    if obj.dumpfile is not None: #only background will have this
##
##                                        one_instance_found = True
##
##                                        name = "[COLOR {}]Stop downloading[/COLOR] '{}'".format(
##                                            C.search_text_color
##                                            , obj.name)
##                                        addDownLink(name = name
##                                                    , url=obj.url
##                                                    , mode=C.ROOT_STOP_DOWNLOAD
##                                                    , play_method = C.PLAYMODE_NO_OPTIONS
##                                                    , noDownload = True
##                                                    )
##                except:
##                    raise
##            obj = None
##                    
##    except:
##        traceback.print_exc()
##
##    if one_instance_found == False:
##        addDir(
##            name="Nothing downloading in background"
##            , url=C.DO_NOTHING_URL
##            , mode=C.ROOT_INDEX_INDEX
##            )
##        C.addon.setSetting(id='background_download', value="false")
##    else:
##        C.addon.setSetting(id='background_download', value="true")
##    
##    endOfDirectory()
##
##    Log("Manage_Downloads end")

#__________________________________________________________________________
#
def _pbhook(downloaded, filesize, start, name=None, progress_dialog=None):
    try:
        percent = min((downloaded*100)/filesize, 100)
        currently_downloaded = float(downloaded) / (1024 * 1024)
        kbps_speed = int(downloaded / (time.clock() - start))

        if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
        else:           eta = 0

        kbps_speed = kbps_speed / 1024
        total = float(filesize) / (1024 * 1024)
        mbs = "[{:20}]".format(name)
        mbs += ' %.00f MB/%.00f MB' % (currently_downloaded, total)
        e = ' %.0fKbps' % kbps_speed
        e += ' ETA:%01d' % (eta // 60)
        progress_dialog.update(percent,'',mbs + e)
    except:
        traceback.print_exc()
        percent = 100
        progress_dialog.update(percent)
        progress_dialog.close()
#__________________________________________________________________________
#
def getResponse(url, headers2, size):
    #Log("getResponse:{}".format(url))
    import urllib2
    import ssl
    Request = urllib2.Request
    try:
        if size > 0:
            size = int(size)
            headers2['Range'] = 'bytes=%d-' % size
        req = Request(url, headers=headers2)
        resp = urllib2.urlopen(req, timeout=30, context=ssl._create_unverified_context())
        #Log("getResponse:urlopen:{}".format(url))
        return resp
    except:
        traceback.print_exc()
        return None
#__________________________________________________________________________
#
def doDownload(url, dest, progress_dialog, name, stop_event):

    start = time.clock()

    try:
        
        #url may have include headers to be passed during transaction
        try:
            headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
        except:
            #traceback.print_exc()
            headers = dict('')


        #if 'spankbang.com' in url:  url = getVideoLink(url,url)

        url = url.split('|')[0]
        file = dest.rsplit(os.sep, 1)[-1]

#            Log("headers='{}'".format(headers))

        resp = getResponse(url, headers, 0)
        #utils.getHtml(url, headers=headers)
        
        if not resp:
            Notify("Download failed: {}".format(url))
            return False

        try:
            content = int(resp.headers['Content-Length'])
            Log("Expected file size {:,}bytes for '{}'".format(content, name))
        except: content = 0

        try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
        except: resumable = False
        if resumable: Log("Download is resumable: {}".format(url))

        if content < 1:
            Notify("Unknown filesize: {}".format(url))
            content = 1024*1024*1024


        size = 8192
        mb   = content / (1024 * 1024)

        if content < size:
            size = content

        total   = 0
        errors  = 0
        count   = 0
        resume  = 0
        sleep   = 0

        Log('Download File Size : %dMB %s ' % (mb, dest))
        f = xbmcvfs.File(dest, 'w')

        chunk  = None
        chunks = []

        while True:

            # kill the download if kodi monitor tells us to
            monitor = xbmc.Monitor()
            if monitor.abortRequested():
                if monitor.waitForAbort(0.1):
                    Log("shutting down '{}' download thread for '{}'".format(addon_id,url), xbmc.LOGNOTICE)
                    break

            if stop_event.isSet() == True:
                Log("stop_event.isSet()")
                break
            
            downloaded = total
            for c in chunks:
                downloaded += len(c)
            percent = min(100 * downloaded / content, 100)

            _pbhook(downloaded,content,start,name,progress_dialog)

            chunk = None
            error = False

            try:
                chunk  = resp.read(size)
                if not chunk:
                    if percent < 99:
                        error = True
                    else:
                        while len(chunks) > 0:
                            c = chunks.pop(0)
                            f.write(c)
                            del c

                        f.close()
                        Log( '%s download complete' % (dest) )
                        return True

            except Exception as e:
                traceback.print_exc()
                error = True
                sleep = 10
                errno = 0

                if hasattr(e, 'errno'):
                    errno = e.errno
                    Log(repr(errno))

                if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                    pass

                if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                    errors = 10 #force resume
                    sleep  = 10

                if errno == 11001: # 'getaddrinfo failed'
                    errors = 10 #force resume
                    sleep  = 10

            if chunk:
                errors = 0
                chunks.append(chunk)
                if len(chunks) > 5:
                    c = chunks.pop(0)
                    f.write(c)
                    total += len(c)
                    del c

            if error:
                errors += 1
                count  += 1
                xbmc.sleep(sleep*1000)

            if (resumable and errors > 0) or errors >= 500:
                if (not resumable and resume >= 500) or resume >= 500:
                    #Give up!
                    Log ('%s download canceled - too many error whilst downloading' % (dest))
                    f.close()
                    return False

                resume += 1
                errors  = 0

                if resumable:
                    chunks  = []
                    #create new response
                    Log ('Download resumed (%d) %s' % (resume, dest) )
                    resp = getResponse(url, headers, total)
                else:
                    #use existing response
                    pass

    except:
        #traceback.print_exc()
        raise

#__________________________________________________________________________
#
class MP4Downloader(object):
    def __init__(
        self
        , name
        , stop_playing_event
        , download_path
        , url
        ):
        self.name = name
        self.stop_playing_event = stop_playing_event
        self.download_path = download_path
        self.url = url
    def keep_sending_video( self ) :

        url = self.url
        dest = self.download_path
        name = self.name
        stop_playing_event = self.stop_playing_event

        url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on

        name = Clean_Filename(name)
        download_path = Make_download_path() #I want to start with path only
            
        progress_dialog = xbmcgui.DialogProgressBG()
        progress_dialog.create(C.addon_name,name[:50])
##        progress_dialog = Progress_Dialog(C.addon_name,name[:50])

        import tempfile
        
        tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
        tmp_file = xbmc.makeLegalFilename(tmp_file)
        start = time.clock()
        downloaded = None
        try:
            Log("url='{}'".format(url))
            ###def doDownload(url, dest, dp, name, stop_event):
            downloaded = doDownload(url, tmp_file, progress_dialog, name, stop_playing_event)
            if downloaded:
                Log("Clean_Filename(name)='{}'".format(Clean_Filename(name,include_square_braces=False)))
                vidfile = xbmc.makeLegalFilename(download_path + Clean_Filename(name, include_square_braces=False) + ".mp4")
                Log("vidfile='{}'".format(vidfile))
                try:
                    os.rename(tmp_file, vidfile)
                    return vidfile
                except Exception as e:
                    try:
                        nfn = vidfile + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S") + '.mp4'
                        Log("vidfile='{}'".format(nfn))
                        os.rename(tmp_file, nfn)
                        return nfn
                    except Exception as e2:
                        traceback.print_exc()
                        Notify(msg = "'{}' name:{} tmp:{}".format(e2,vidfile,tmp_file), duration=20000)
                        return tmp_file
            else:
                raise StopDownloading('Stopped Downloading')
        except StopDownloading:
            while os.path.exists(tmp_file):
                try:
                    os.remove(tmp_file)
                except:
                    traceback.print_exc()
        except:
            traceback.print_exc()
            while os.path.exists(tmp_file):
                try:
                    os.remove(tmp_file)
                except:
                    traceback.print_exc()
        finally:
            if progress_dialog:
                progress_dialog.close()
            progress_dialog = None
#__________________________________________________________________________
#
def Background_MP4Downloader(url, download_path, name):

    stop_playing_event = threading.Event()
    name = Clean_Filename(name)

    Log("Background_MP4Downloader instance")
    downloader = MP4Downloader(
          name = name
        , url = url
        , stop_playing_event = stop_playing_event
        , download_path = download_path
        )
    Log("Background_MP4Downloader keep sending start")

    now = datetime.datetime.utcnow()
    add_download_result = add_download(
        name=C.DOWNLOAD_INDICATOR+name
        , url=url
        , file_spec=download_path
        , expected_size=None
        , start_time=db_date_formatter(now)
        )
    if add_download_result != True:
        Log("seem to be already downloading, but that is a success for now")
        downloader = None
        return
        
    downloader.keep_sending_video()
    Log("Background_MP4Downloader keep sending finish")

    downloader = None
    Stop_Download(url, name, False)
#__________________________________________________________________________
#
def Background_HLSDownloader(url, download_path, name):

    progress_dialog = xbmcgui.DialogProgressBG()
    progress_dialog.create(C.addon_name,name[:50])

    play_profile = 'profile_00' #the download profile
    initial_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "initial"))* 1000 * 1000)
    maximum_bitrate = int(float(C.addon.getSetting(play_profile + "_" + "maximum"))* 1000 * 1000)
    allow_upscale = C.addon.getSetting(play_profile + "_" + "allow_upscale")
    allow_downscale = C.addon.getSetting(play_profile + "_" + "allow_downscale")
    always_refresh_m3u8 = C.addon.getSetting(play_profile + "_" + "always_refresh_m3u8")
    downscale_threshhold = C.addon.getSetting(play_profile + "_" + "downscale_threshhold")
    upscale_threshhold = C.addon.getSetting(play_profile + "_" + "upscale_threshhold")
    upscale_penalty = C.addon.getSetting(play_profile + "_" + "upscale_penalty")
    pre_cache_size_max = int(float(C.addon.getSetting(play_profile + "_" + "pre_cache_size_max"))* 1000 * 1000)

    stop_playing_event = threading.Event()
    seek_forward_event = threading.Event()
    import HLSDownloaderRetry

    Log("Background_HLSDownloader instance")
    downloader = HLSDownloaderRetry.HLSDownloaderRetry()
    downloader.init(
          url = url
        , stop_playing_event = stop_playing_event
        , seek_forward_event = seek_forward_event
        , maxbitrate = maximum_bitrate
        , download_path = download_path
        , initial_bitrate = initial_bitrate
        , allow_upscale = allow_upscale
        , allow_downscale = allow_downscale
        , always_refresh_m3u8 = always_refresh_m3u8
        , downscale_threshhold = downscale_threshhold
        , upscale_threshhold = upscale_threshhold
        , upscale_penalty = upscale_penalty
        , pre_cache_size_max = pre_cache_size_max
        )
    Log("Background_HLSDownloader keep sending start")

##    for obj in threading.enumerate():
##        Log("obj='{}'".format(dir(obj)))
##        Log("obj.name='{}'".format(obj.name))

    downloader.keep_sending_video(None)
    Log("Background_HLSDownloader keep sending finish")

    downloader = None

    Stop_Download(url, name, False)

    if progress_dialog: progress_dialog.close()
    progress_dialog = None
#__________________________________________________________________________
#
def Test_All():
    #test: if url already there; check if task is in progress
    #test: in progress, report success
    #test: NOT in progress, delete old and add new and start
##    for (qq) in active_downloads():
##        Log(repr(qq))
##        pass
    return
#__________________________________________________________________________
#
def downloadVideo(url, name, download_path=None):
    
    Log(u"DownloadVideo name='{}' url='{}'".format(Clean_Filename(name),url), xbmc.LOGNONE)
    Notify(u"Downloading '{}' in background".format(Clean_Filename(name)))

    now = datetime.datetime.utcnow()
    name = Clean_Filename(name)

    hls_download = any(x in url for x in ['.m3u8', '/hls/'])
    if hls_download:
        Log("hls download")
        if download_path is None:   
            download_path = Make_download_path(name, file_extension = '.ts')

        add_download_result = add_download(
            name=C.DOWNLOAD_INDICATOR+name
            , url=url
            , file_spec=download_path
            , expected_size=None
            , start_time=db_date_formatter(now)
            )

        if add_download_result != True:
            Log("seem to be already downloading, but that is a success for now")
            return

        proxy_thread = threading.Thread(
            name=C.DOWNLOAD_INDICATOR+name
            ,target=Background_HLSDownloader
            ,args=(url, download_path, name)
            )
        proxy_thread.daemon = True
        proxy_thread.start()

##        for obj in threading.enumerate():
##            Log("obj='{}'".format(dir(obj)))
##            Log("obj.name='{}'".format(obj.name))

        return

    else:
        Log("mp4 download")
        if download_path is None:   
            download_path = Make_download_path(name, file_extension = '.mp4')

        proxy_thread = threading.Thread(
            name=C.DOWNLOAD_INDICATOR+name
            ,target=Background_MP4Downloader
            ,args=(url, download_path, name )
            )
        proxy_thread.daemon = True
        proxy_thread.start()
        return

    raise Exception("should not reach here")
##
##    def _pbhook(downloaded, filesize, start, name=None,dp=None):
##        try:
##            percent = min((downloaded*100)/filesize, 100)
##            currently_downloaded = float(downloaded) / (1024 * 1024)
##            kbps_speed = int(downloaded / (time.clock() - start))
##
##            if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
##            else:           eta = 0
##
##            kbps_speed = kbps_speed / 1024
##            total = float(filesize) / (1024 * 1024)
##            mbs = "[{:20}]".format(name)
##            mbs += ' %.00f MB/%.00f MB' % (currently_downloaded, total)
##            e = ' %.0fKbps' % kbps_speed
##            e += ' ETA:%01d' % (eta // 60)
##            dp.update(percent,'',mbs + e)
##        except:
##            traceback.print_exc()
##            percent = 100
##            dp.update(percent)
##            dp.close()
##
##    def getResponse(url, headers2, size):
##        #Log("getResponse:{}".format(url))
##        import urllib2
##        import ssl
##        Request = urllib2.Request
##        try:
##            if size > 0:
##                size = int(size)
##                headers2['Range'] = 'bytes=%d-' % size
##            req = Request(url, headers=headers2)
##            resp = urllib2.urlopen(req, timeout=30, context=ssl._create_unverified_context())
##            #Log("getResponse:urlopen:{}".format(url))
##            return resp
##        except:
##            traceback.print_exc()
##            return None
##
##    def doDownload(url, dest, dp, name):
##
##        try:
##            
##            #url may have include headers to be passed during transaction
##            try:
##                headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
##            except:
##                #traceback.print_exc()
##                headers = dict('')
##
##
##            #if 'spankbang.com' in url:  url = getVideoLink(url,url)
##
##            url = url.split('|')[0]
##            file = dest.rsplit(os.sep, 1)[-1]
##
###            Log("headers='{}'".format(headers))
##
##            resp = getResponse(url, headers, 0)
##            #utils.getHtml(url, headers=headers)
##            
##            if not resp:
##                Notify("Download failed: {}".format(url))
##                return False
##
##            try:
##                content = int(resp.headers['Content-Length'])
##                Log("Expected file size {:,}bytes for '{}'".format(content, name))
##            except: content = 0
##
##            try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
##            except: resumable = False
##            if resumable: Log("Download is resumable: {}".format(url))
##
##            if content < 1:
##                Notify("Unknown filesize: {}".format(url))
##                content = 1024*1024*1024
##
##
##            size = 8192
##            mb   = content / (1024 * 1024)
##
##            if content < size:
##                size = content
##
##            total   = 0
##            errors  = 0
##            count   = 0
##            resume  = 0
##            sleep   = 0
##
##            Log('Download File Size : %dMB %s ' % (mb, dest))
##            f = xbmcvfs.File(dest, 'w')
##
##            chunk  = None
##            chunks = []
##
##            while True:
##
##                # kill the download if kodi monitor tells us to
##                monitor = xbmc.Monitor()
##                if monitor.abortRequested():
##                    if monitor.waitForAbort(1):
##                        Log("shutting down '{}' download thread for '{}'".format(addon_id,url), xbmc.LOGNOTICE)
##                        return
##
##                downloaded = total
##                for c in chunks:
##                    downloaded += len(c)
##                percent = min(100 * downloaded / content, 100)
##
##                _pbhook(downloaded,content,start, name,dp)
##
##                chunk = None
##                error = False
##
##                try:
##                    chunk  = resp.read(size)
##                    if not chunk:
##                        if percent < 99:
##                            error = True
##                        else:
##                            while len(chunks) > 0:
##                                c = chunks.pop(0)
##                                f.write(c)
##                                del c
##
##                            f.close()
##                            Log( '%s download complete' % (dest) )
##                            return True
##
##                except Exception as e:
##                    traceback.print_exc()
##                    error = True
##                    sleep = 10
##                    errno = 0
##
##                    if hasattr(e, 'errno'):
##                        errno = e.errno
##
##                    if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
##                        pass
##
##                    if errno == 10054: #'An existing connection was forcibly closed by the remote host'
##                        errors = 10 #force resume
##                        sleep  = 30
##
##                    if errno == 11001: # 'getaddrinfo failed'
##                        errors = 10 #force resume
##                        sleep  = 30
##
##                if chunk:
##                    errors = 0
##                    chunks.append(chunk)
##                    if len(chunks) > 5:
##                        c = chunks.pop(0)
##                        f.write(c)
##                        total += len(c)
##                        del c
##
##                if error:
##                    errors += 1
##                    count  += 1
##                    #Log ('%d Error(s) whilst downloading %s' % (count, dest))
##                    #xbmc.sleep(sleep*1000)
##                    xbmc.sleep(sleep*1000)
##
##                if (resumable and errors > 0) or errors >= 500:
##                    if (not resumable and resume >= 500) or resume >= 500:
##                        #Give up!
##                        Log ('%s download canceled - too many error whilst downloading' % (dest))
##                        f.close()
##                        return False
##
##                    resume += 1
##                    errors  = 0
##
##                    if resumable:
##                        chunks  = []
##                        #create new response
##                        Log ('Download resumed (%d) %s' % (resume, dest) )
##                        resp = getResponse(url, headers, total)
##                    else:
##                        #use existing response
##                        pass
##
##        except:
##            traceback.print_exc()
##
##    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
##
##    name = Clean_Filename(name)
##
##    download_path = Make_download_path() #I want to start with path only
##        
##    progress_dialog = xbmcgui.DialogProgressBG()
##    progress_dialog.create(C.addon_name,name[:50])
##
##    import tempfile
##    
##    tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
##    tmp_file = xbmc.makeLegalFilename(tmp_file)
##    start = time.clock()
##    downloaded = None
##    try:
##        Log("url='{}'".format(url))
##        downloaded = doDownload(url, tmp_file, progress_dialog, name)
##        if downloaded:
##            Log("Clean_Filename(name)='{}'".format(Clean_Filename(name,include_square_braces=False)))
##            vidfile = xbmc.makeLegalFilename(download_path + Clean_Filename(name, include_square_braces=False) + ".mp4")
##            Log("vidfile='{}'".format(vidfile))
##            try:
##                os.rename(tmp_file, vidfile)
##                return vidfile
##            except Exception as e:
##                try:
##                    nfn = vidfile + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S") + '.mp4'
##                    Log("vidfile='{}'".format(nfn))
##                    os.rename(tmp_file, nfn)
##                    return nfn
##                except Exception as e2:
##                    traceback.print_exc()
##                    Notify(msg = "'{}' name:{} tmp:{}".format(e2,vidfile,tmp_file), duration=20000)
##                    return tmp_file
##        else:
##            raise StopDownloading('Stopped Downloading')
##    except:
##        traceback.print_exc()
##        while os.path.exists(tmp_file):
##            try:
##                os.remove(tmp_file)
##                progress_dialog.close()
##                break
##            except:
##                traceback.print_exc()
##                break
##                pass
##    finally:
##        if progress_dialog:
##            progress_dialog.close()
#__________________________________________________________________
#
def make_downloads_db():
    sql_command = (
        "CREATE TABLE IF NOT EXISTS downloads ("
        #"CREATE TABLE downloads ("
        "name"
        ", url"
        ", file_spec"
        ", expected_size"
        ", start_time"
        ", update_time"
        ", current_size"
        ", current_data_rate"
        ", expected_end_time"
        ");"
        )
    Log("sql_command='{}'".format(sql_command) )#, LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        conn.text_factory = str
        downDB_cursor = conn.cursor()
        downDB_cursor.executescript(sql_command)
        conn.commit()
##        Log(repr(active_downloads()), LOGNONE)
    finally:
        if conn: conn.close()
    return True

#__________________________________________________________________
#
def db_date_formatter(date):
    return date.isoformat() #strftime("%Y%m%d.%H%M%S")
#__________________________________________________________________
#
def clean_downloads(days_too_old=1.0):
    Log("clean_downloads(days_too_old={}) start".format(days_too_old))
##    raise NotImplementedError('clean_downloads')
    too_old_day  = db_date_formatter(datetime.datetime.utcnow()-datetime.timedelta(days_too_old))
    too_old_hour = db_date_formatter(datetime.datetime.utcnow()-datetime.timedelta((days_too_old/24.0)))
    sql_command = (
        "SELECT name, url FROM downloads "
        "WHERE "
        "    (start_time  < '{}')"
        "    OR ( "
        "         (update_time < '{}') "
        "         AND "
        "         ( substr(file_spec,length(file_spec)-(length('.ts')-1)) != '.ts')"
	"	);"
        ).format(too_old_day,too_old_hour)
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        downDB_cursor = conn.cursor()
        downDB_cursor.execute(sql_command)
        cleanable_items = downDB_cursor.fetchall()
        conn.close()
        for name, url in cleanable_items:
            proxy_thread = threading.Thread(
                name="download_cleaner."+Clean_Filename(name)
                ,target=Stop_Download
                ,args=(url,name,False)
                )
            proxy_thread.daemon = True
            proxy_thread.start()
    finally:
        if conn: conn.close()
    Log("clean_downloads end")
    return True
#__________________________________________________________________
#
def active_downloads():
    make_downloads_db()
    active = None
    sql_command = "SELECT * FROM downloads"
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        downDB_cursor = conn.cursor()
        downDB_cursor.execute(sql_command)
        active = downDB_cursor.fetchall()
##        Log(repr(active), LOGNONE)
    finally:
        if conn: conn.close()
    return active
#__________________________________________________________________
#
def delete_download(url):
    sql_command = "DELETE FROM downloads WHERE url = '{}'".format(sanitize_sql(url))
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        conn.execute(sql_command)
        conn.commit()
    finally:
        if conn: conn.close()
    return True
#__________________________________________________________________
#
def add_download(name, url, file_spec, expected_size, start_time):
    sql_command_1 = (
        "SELECT file_spec FROM downloads " #url could be different when retrying same download
        #"WHERE  file_spec LIKE '{}'".format(sanitize_sql(file_spec))
        "WHERE  file_spec LIKE (?)"
        )
    sql_command_2 = (
        "INSERT INTO downloads "
        "( name"
        ", url"
        ", file_spec"
        ", expected_size"
        ", start_time" #note: start time is a parameter in order to force consistent formatting
        ", update_time" #record dead if something has not updated recently
        ") VALUES "
        "(?, ?, ?, ?, ?, ?)"
##        "'{}','{}','{}','{}','{}','{}'"
##        ")".format(
##              sanitize_sql(name)
##            , sanitize_sql(url)
##            , sanitize_sql(file_spec)
##            , sanitize_sql(str(expected_size)) #size can be None
##            , sanitize_sql(start_time)
##            , sanitize_sql(start_time)
##            )
        )
    Log("sql_command_1='{}'".format(sql_command_1) )#,LOGNONE)
    Log("sql_command_2='{}'".format(sql_command_2) )#,LOGNONE)
    try:
        conn = sqlite3.connect(downloads_db)
        downDB_cursor = conn.cursor()
        #downDB_cursor.execute(sql_command_1)
        Log((sanitize_sql(file_spec)))
        downDB_cursor.execute(
            sql_command_1
            , (sanitize_sql(file_spec),)
            )
        items = downDB_cursor.fetchall()
        if len(items) > 0 :
            Log("url already there")
            return False
        else:
##            downDB_cursor.execute(sql_command_2)
            downDB_cursor.execute(
                sql_command_2
                ,   ( sanitize_sql(name)
                    , sanitize_sql(url)
                    , sanitize_sql(file_spec)
                    , sanitize_sql(str(expected_size)) #size can be None
                    , sanitize_sql(start_time)
                    , sanitize_sql(start_time)
                    )
                )                
            conn.commit()
    finally:
        if conn: conn.close()
    return True
##
##WITH t as (	select url from downloads where url LIKE 'http://87.98.141.1%')
##	SELECT 
##		url as u
##		,	(SELECT substr(
##						url
##						,0
##						,min(coalesce(nullif(instr(url,'?'),0),nullif(instr(url,'?'),0)))
##					)
##				) as 'other'
##		,CASE WHEN 
##			(SELECT substr(
##						url
##						,0
##						,min(coalesce(nullif(instr(url,'?'),0),nullif(instr(url,'|'),0)))
##					)
##				)
##			IS NULL
##		THEN 'was null' 
##		ELSE 'was not null'
##		END as 'case state'
##	FROM T
##	

#__________________________________________________________________________
#
def sanitize_sql(information):
    if sqlite3.complete_statement(information):
        raise sqlite3.IntegrityError
    return information #.replace("'", "''")
#__________________________________________________________________________
#
def un_sanitize_sql(information):
    return information
    #return urllib.unquote_plus(information) #todo: unsanitize info to prevent bad sql command
#__________________________________________________________________________
#
