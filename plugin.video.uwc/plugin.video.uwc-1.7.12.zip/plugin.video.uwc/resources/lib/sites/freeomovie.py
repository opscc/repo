'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]freeomovie[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_MOVIES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.freeomovie.to"
SEARCH_URL = ROOT_URL + '/?s='
URL_RECENT = ROOT_URL + '/page/{}/'
URL_CATEGORIES = ROOT_URL

MAIN_MODE       = '370'
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon )

    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))


    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    listhtml = utils.getHtml(list_url)

    regex = 'class="boxtitle".+?<a href="([^"]+)".+?title="([^"]+)">.+?src="([^"]+)".+? alt="'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for url, label, thumb in info:
        label = utils.cleantext(label)
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = url 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , noDownload=False)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)


    next_page_regex = "class=\"nextpostslink\".+?href=\"([^\"]+)\""
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url in np_info:
        #Log("np_url={}".format(np_url))
        np_number = '' #page number can be multiple places depending if search result or not
        if not np_number.isdigit(): np_number=np_url.split('/')[4]
        if not np_number.isdigit(): np_number=np_url.split('/')[5]
        if not np_number.isdigit(): np_number=np_url.split('/')[6]
        if not np_number.isdigit(): np_number=np_url.split('/')[7]
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number 
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth:
                utils.Notify(msg=np_url)  #let user know something is happening
                List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    searchUrl = SEARCH_URL + keyword.replace(' ','+')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))       
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    html = utils.getHtml(url, ROOT_URL)

    regex = "\"cat-item.+?href=\"([^\"]+)\".+?>([^<]+)<"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    Log("info='{}'".format(info))
    for url, label in info:
        #Log("url='{}'".format(url))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=C.search_icon
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    needs_resolving_source = utils.getHtml(url, ROOT_URL)

    from resources.lib import resolver
    video_url = resolver.resolve_video(videosource=needs_resolving_source, name=name, download=download, url=url)
    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
    Log("video_url='{}'".format(video_url))
    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
