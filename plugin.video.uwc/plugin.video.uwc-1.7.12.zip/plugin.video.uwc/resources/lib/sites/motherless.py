'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]motherless[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://motherless.com"
SEARCH_URL = ROOT_URL + '/term/videos/{}?range=0&size=0&sort=relevance&page={}'
URL_CATEGORIES = ROOT_URL
URL_RECENT = ROOT_URL + '/videos/recent?page={}'

MAIN_MODE          = C.MAIN_MODE_motherless
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1'

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    List(URL_RECENT, FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if "Page Not Found" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            regex = 'id="content"(.+)class=\'pagination_link'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            #utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))

    # parse out list items
    regex = 'class="thumb-container.+?href="([^"]+?)".+?"size">([^<]+?)<.+?"static" src="([^"]+?)".+?alt="([^"]+?)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, duration, thumb, label  in info:
        hd = utils.Normalize_HD_String(label)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label={}".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    # next page items
    try:
        regex = 'class="content-inner".+?class=\'pagination_link(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        next_page_html = listhtml

    next_page_regex = '<a href="([^"]+=\d)"[^>]+>NEXT'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
##            np_number = '' 
##            if '/' in np_url: np_url = np_url.split('/')[-1]
####            Log("np_url={}".format(np_url))
##            if '?page=' in np_url: np_number = np_url.split('?page=')[1]
##            if '&page=' in np_url: np_number = np_url.split('&page=')[1]
            np_number = int(page) + 1
            np_url=url
##            Log("np_number={}".format(np_number))
##            Log("np_url={}".format(np_url))
##            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, C.search_text_color, int(np_number))
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= max_search_depth: #search some more, but not forever
                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))
    
    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace('+',' ').replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)

    #regex = '<div class="menu-categories-tab"\s+data-orientation="straight">(.+?)<div id="content">'
    regex = '<div class="menu-categories-tab"\s+data-orientation="straight">(.+?)class="clear-both"'
    try: 
        listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        Log("listhtml={}".format(listhtml), xbmc.LOGNONE)
        raise
   
    regex = '<li>\s+<a href="([^"]+)".+?>([^<]+)</a>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label   in info:
        #label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, C.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        #https://motherless.com/porn/wife/videos?page=4
        videourl = videourl + '/videos?page={}'
        #Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=C.search_icon)

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL

    source_html1 = utils.getHtml(url, ROOT_URL)

    if 'Please refresh, if no luck, please check back in a few minutes' in source_html1:
        utils.Notify("Refresh in a few minutes")
        return        

##    regex = "'(http[^']+mp4)"
    regex = '<source src="([^"]+)".+?res="([^"]+)p"'
    regex = 'data-quality="(\d+)p".+?<source src="([^"]+)"'
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
##    video_url = sources_list[0]
    video_url = utils.SortVideos(
        sources=sources_list
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )
##    Log("video_url='{}'".format(video_url))

    if not video_url: #try older syntax
        regex = "'(http[^']+mp4)"
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
        if sources_list:
            video_url = sources_list[0]
    
    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        return
    video_url = video_url + utils.Header2pipestring() + '&Referer=' + url
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
