'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import re
import sys
import random
import sqlite3
import urllib

import traceback

import inputstreamhelper
import time
import random
import json
import datetime
                
try:     import simplejson
except:  import json as simplejson   

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib import websocket
from resources.lib.utils import Log
from resources.lib.utils import Sleep


import socket
__USER_AGENT__ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"


import xbmcaddon
ADDON=xbmcaddon.Addon()


FRIENDLY_NAME = '[COLOR {}]MyFreeCams[/COLOR]'.format(utils.time_text_color)
LIST_AREA = utils.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.myfreecams.com"

SEARCH_URL = 'stub - make all sites consistent'

MESSAGE_FIELD_LENGTH = None
MAX_READ_COUNT = 100
CAMGIRLSERVER = None
CAMGIRLCHANID = None
CAMGIRLUID = None
CAMGIRL = None
CXID = None
CTXENC = None
TKX = None
SESSION_ID = None
PLATFORM_ID = None

SERV = None
RESPKEY = None
STYPE = None
OPTS = None

XCHAT_HOST = None

serverList = None                

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

FCUOPT_PLATFORM_MFC = 1
FCUOPT_PLATFORM_CAMYOU = 2

vs_str={}
vs_str[0]="PUBLIC"
vs_str[2]="AWAY"
vs_str[12]="PVT"
vs_str[13]="GROUP"
vs_str[14]="GROUP"
vs_str[90]="CAM OFF"
vs_str[127]="OFFLINE"
vs_str[128]="TRUEPVT"

MAIN_MODE    = '270'
LIST_MODE    = '271'
PLAY_MODE    = '272'
REFRESH_MODE = '273'
SEARCH_MODE  = '274'

FCTYPE_EXTDATA = 81
FCTYPE_LOGIN = 1
FCTYPE_MODELGROUP = 33
FCTYPE_TKX = 30
FCTYPE_EXTDATA = 81
FCTYPE_DETAILS = 5
FCTYPE_ADDIGNORE = 7
FCTYPE_SESSIONSTATE = 20

MAX_BUFFER_READ_ATTEMPTS = 10

MAX_LIST_ITEMS = 3000


FCWEXTRESP_URL = None



nc_string = str(random.random())
while len(nc_string) < 18:
    nc_string += str(random.randint(10,99))

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    global FCWEXTRESP_URL
    serv, respkey, stype, opts = getRespkey()
    if respkey is None:
        raise Exception("Null response key.Can't continue")
    FCWEXTRESP_URL = ROOT_URL + "/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        respkey, stype, opts, serv, random.random(), millitime() ) 
    List( FCWEXTRESP_URL )

#__________________________________________________________________________
#

def arrayPositionForKeyname(array, key):
    i=0
    for val in array:
        if isinstance(val, unicode):
            if val == key:
                return i 
            i += 1
        elif isinstance(val, dict):
            for val2 in val.values():
                if isinstance(val2, (list, dict, tuple)):
                    for val3 in val2:
                        if val3 == key:
                            return i 
                        i += 1
                elif isinstance(val2, unicode):
                    if val2 == key:
                        return i
                    i += 1
    return None

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'])
def List(url):

    utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.refresh_text_color)
        ,url=''
        ,mode=REFRESH_MODE
        ,iconimage=utils.refresh_icon
        ,duration=55*60*60+55*60+55
        ,Folder=False 
        )

    FCL_CAMS = 21
    hq_bonus = int(utils.addon.getSetting("hq_bonus").lower())

    try:
        listhtml = utils.getHtml(url)
    except:
        return None
    json_playlist = json.loads(listhtml)['rdata']

##    try:
##        json_playlist = None
##        while json_playlist is None:
##            listhtml = utils.getHtml(url)
##            json_playlist = json.loads(listhtml)
##            if not (json_playlist['type'] == FCL_CAMS ):
##                Log(repr(json_playlist['type']), xbmc.LOGNONE)
##                json_playlist = None
##            else:
##                json_playlist = json_playlist['rdata']
##    except:
##        
##        return None

    




    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ... 
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
    #Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    # ... schema which I don't want [errors during sorting]
    del json_playlist[0] 

    #sort so that top camscore is on top
    entries = sorted(json_playlist, reverse=True, key=lambda camscore: camscore[camscore_index])
##    Log(repr(entries), xbmc.LOGNONE)

    #add list items...
    for playItem in entries[:MAX_LIST_ITEMS]:
        if not(playItem[vs_index] == 0):
##            Log("{} is {}".format(playItem[name_index], vs_str[playItem[vs_index]]), xbmc.LOGNONE)
            pass
        else: #only show model in public chat
            serv_number = playItem[camserv_index]
            if Is_new_server(serv_number):
                server439hack = "_a"
                name_hq_prefix = ""
                name_hq_prefix = "[COLOR {}]HQ[/COLOR] ".format(utils.time_text_color)
                hq_stream = True
            else:
                server439hack = ""
                name_hq_prefix = ""
                hq_stream = False

            #normalizeServer will return a string such as video1234;
            #I only want to return the 1234 portion
            norm_serv_number = int(filter(str.isdigit,   str(NormalizeServerNumber(serv_number)) )) 
##            Log("serv_number='{}'".format(serv_number))
##            Log("norm_serv_number='{}'".format(norm_serv_number))
##            return
        
            icon_img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc{}_{}{}".format( \
                norm_serv_number, \
                server439hack, \
                NormalizeChannelID(playItem[uid_index]), \
                "?no-cache="+str(int(time.time()*2))
                )

##            Log("icon_img='{}'".format(icon_img))

            camscore = int(playItem[camscore_index])

            model_name = playItem[name_index]
            icon_label = name_hq_prefix + model_name
##            Log("icon_label='{}'".format(icon_label))

            #show others that are using the same server
            alternate_channel = ""
##            for altStreamItems in entries:
##                if serv_number == altStreamItems[camserv_index]:
##                    if altStreamItems[name_index] != model_name:
##                        alternate_channel += altStreamItems[name_index] + " "

            camscore = int(camscore)

##            if hq_stream and hq_bonus and alternate_channel == "":
##                camscore = camscore * hq_bonus

            url = playItem[name_index]
            utils.addDownLink(
                name = icon_label
                , url = url
                , mode = PLAY_MODE
                , iconimage = icon_img
                , duration = str(camscore)
                , play_method = utils.PLAYMODE_DEFAULT 
                , hq_stream = hq_stream
                , desc = alternate_channel
                )
                #, stream = True #must be true to use setResolvedUrl

    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

def NormalizeChannelID(uid, platform_id=FCUOPT_PLATFORM_MFC):
    if not isinstance(uid, int):  return 0
    uid = int(uid)
    if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
        return uid + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
    else:
        return uid + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['hq_stream', 'playmode_string', 'download', 'megabitratebonus'])
def Playvid(url, name, hq_stream=False, playmode_string = '', megabitratebonus=0, download = False, ):

    Log ("Playvid url='{}' name='{}' hq_stream='{}' playmode_string='{}', megabitratebonus='{}' download='{}'".format(url, name, hq_stream, playmode_string, megabitratebonus, download)  )

    #if bool(hq_stream) == False:
    if hq_stream:
        mfc_xchat_host = utils.addon.getSetting(id='mfc_xchat_host')
        #Log ("mfc_xchat_host={}".format(mfc_xchat_host))
        if not mfc_xchat_host == '':
            websocket_connection = websocket.WebSocket()
            websocket_connection = websocket.create_connection(mfc_xchat_host)
        else:
            websocket_connection = getChatServerWebsocket()
        
        websocket_connection.send("hello fcserver\n\0")
        websocket_connection.send("1 0 0 20071025 0 guest:guest\n\0")
        quitting = 0
        rembuf=""
        MESSAGE_FIELD_LENGTH = 6
        while quitting == 0:
            sock_buf = websocket_connection.recv()
            sock_buf = rembuf+sock_buf
            rembuf=""
            while True:
                hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
                if bool(hdr) == 0: break
                fc = hdr.group(1)
                mlen = int(fc[0:MESSAGE_FIELD_LENGTH])
                fc_type = int(fc[MESSAGE_FIELD_LENGTH:])
                msg=sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH+mlen]
                if len(msg) < mlen:
                    rembuf=''.join(sock_buf)
                    break
                msg=urllib.unquote(msg)
                if fc_type == 1:
                    websocket_connection.send("10 0 0 20 0 %s\n\0" % url)
                elif fc_type == 10:
                    read_model_data(msg, url)
                    quitting = 1
                sock_buf=sock_buf[MESSAGE_FIELD_LENGTH+mlen:]
                if len(sock_buf) == 0:
                    break
        #websocket_connection.close() 
        if CAMGIRLSERVER > 0:
##            videourl = "http://{}.myfreecams.com:1935/NxServer/ngrp:mfc_{}.f4v_mobile/playlist.m3u8".format( \
##                NormalizeServerNumber(CAMGIRLSERVER), CAMGIRLCHANID)
##https://video762.myfreecams.com    /NxServer/ngrp:mfc_119531282.f4v_mobile/playlist.m3u8?nc=0.5108004147504717



            if Is_new_server(CAMGIRLSERVER):
                server439hack = "_a"
##                hq_stream = True
            else:
                server439hack = ""


##            video_url = "https://{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8?nc={}".format( \
##                NormalizeServerNumber(CAMGIRLSERVER), server439hack,  CAMGIRLCHANID, nc_string )
            video_url = "https://{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8".format( \
                NormalizeServerNumber(CAMGIRLSERVER), server439hack,  CAMGIRLCHANID )
            
            
##            videourl = "http://{}.myfreecams.com:1935/NxServer/ngrp:mfc_{}.f4v_desktop/manifest.mpd".format( \
##                NormalizeServerNumber(CAMGIRLSERVER), CAMGIRLCHANID)
            Log ("video_url={}".format(video_url))
        else:
            Log ("CAMGIRLSERVER={}".format(CAMGIRLSERVER))
            return

    else: #NOT hq stream

        videourl = None
        websocket_connection = None
        try:
            video_url, websocket_connection = myfreecam_start(camgirl_to_find=url)
        except:
            traceback.print_exc()
        
        if not video_url or not websocket_connection:
            Log("Could not find a playable webcam link for '{}'".format(name))
            return

    #normServerNumber = NormalizeServerNumber(CAMGIRLSERVER)

    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    listitem.setContentLookup(False)
##    listitem.setInfo(type="Video", infoLabels={"title": name, "plot": name, "plotoutline": name})
##    listitem.addStreamInfo('video', {'codec': 'h264'})
        
    max_bit_rate = utils.MAX_BIT_RATE  + int((int(megabitratebonus)) * 1000 * 1000)
    max_bit_rate_download = utils.MAX_BIT_RATE  + int((int(megabitratebonus) + 0.25) * 1000 * 1000)
    
    if playmode_string == utils.PLAYMODE_F4MPROXY:
        pass
    elif playmode_string == utils.PLAYMODE_INPUTSTREAM:
        pass
    else:
        playmode_string = utils.DEFAULT_PLAYMODE
    if download == True:
        Log("f4mproxy video_url - only this mode can capture")
        playmode_string == utils.PLAYMODE_F4MPROXY
    Log("playmode_string='{}'".format(playmode_string)  )

    if playmode_string == '': # direct
        video_url = "{}{}".format(video_url, utils.Header2pipestring(mfc_headers) )
        Log("direct video_url")        
    if playmode_string == 2: #rtmp
        #2019, the kodi 17,18 rtmp client does not have required options
        utils.Notify("RTMP is not currently supported")
        return

    elif playmode_string == utils.PLAYMODE_INPUTSTREAM or '.mpd' in video_url : # Inputstream
        Log("videourl has mpd or playmode=3.  Using inputstream.adaptive")

        if  '.mpd' in video_url:
            Log ('setting inputstream type MPD')
            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            #2019-07-28  Inputstream is bugged...it uses a combination of the property and | trailer to se headers
            mfc_headers = {
                 'Connection': 'keep-alive'
                , 'Origin': ROOT_URL
                , 'User-Agent': __USER_AGENT__
                , 'DNT': '1'
                , 'Accept': '*/*'
                , 'Referer': ROOT_URL + '/_html/player.html?broadcaster_id=0&vcc=' + str(int(time.time())) + '&target=main'
                , 'Accept-Encoding': 'gzip, deflate, br'
                , 'Accept-Language': 'en-US,en;q=0.9'
                }
            mfc_headers = {
                    'Accept-Charset': 'UTF-8,*;q=0.8'
                    , 'User-Agent': __USER_AGENT__
                    , 'Accept': '*/*'
                    }

            video_url = video_url + utils.Header2pipestring(mfc_headers)
            listitem.setProperty('inputstream.adaptive.stream_headers', utils.Header2pipestring(mfc_headers)[1:] )
            
        else:
            Log ('setting inputstream type HLS')

            mfc_headers = {
                'Connection': 'keep-alive'
                , 'Origin': 'https://m.myfreecams.com'
                , 'User-Agent': __USER_AGENT__
                , 'Referer': 'https://m.myfreecams.com/chats'

            }

            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
##            listitem.setProperty('inputstream.adaptive.stream_headers', utils.Header2pipestring(mfc_headers)[1:] )
            listitem.setProperty('inputstream.adaptive.stream_headers'
                                , 'user-agent=' + 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/538.22 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'
                                + "&Referer={}".format(ROOT_URL)
                                + "&Connection=Keep-Alive"
                                )
            
    elif playmode_string == utils.PLAYMODE_F4MPROXY:

        Log("f4mproxy video_url")

        mfc_headers = {
                'User-Agent': __USER_AGENT__
                , 'Accept': '*/*'
                , 'Referer': ROOT_URL
                , 'Accept-Encoding': 'gzip, deflate, br'
                , 'Accept-Language': 'en-US,en;q=0.9'
                }

        video_url = "{}{}".format(video_url, utils.Header2pipestring(mfc_headers) )
        
        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        if download == True:
            download_path = utils.Make_download_path(name = name, include_date = True, file_extension = '.mp4')
            Log(download_path, xbmc.LOGNONE)
        else:
            download_path = None

        streamtype = 'HLSRETRY'
        f4mp.playF4mLink(
            video_url
            , name
            , proxy = None
            , use_proxy_for_chunks = False
            , maxbitrate = max_bit_rate_download
            , simpleDownloader = False
            , auth = None
            , streamtype = streamtype
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , iconImage = iconimage
            , download_path = download_path
            )
            
        return
    else:
        utils.notify(name,'Unknown playmode for webcam link')

    mfc_headers = {
        'Connection': 'keep-alive'
        , 'Origin': 'https://m.myfreecams.com'
        , 'User-Agent': __USER_AGENT__
        , 'Referer': 'https://m.myfreecams.com/chats'

    }

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Accept': '*/*',
        'Referer': ROOT_URL,
        'Accept-Encoding': 'gzip',
        'Connection': 'keep-alive'
     }

##    if not playmode == 2 and not ('.mpd' in videourl or playmode == 3) : #rtmp
    if not '|' in video_url:
        Log ("video_url needs headers")
        video_url = video_url + utils.Header2pipestring(headers)

    Log ("video_url={}".format(video_url))

    #xbmc.Player().stop()
    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( video_url, listitem)
    xbmc.Player().play(myPlayList)
    
       

def valid_info():
    if CAMGIRLSERVER < 0 :
        Log('valid_info: missing camgirlserver')
        return False
    if CAMGIRLCHANID < 0:
        Log('valid_info: missing CAMGIRLCHANID')
        return False
    if CAMGIRLUID < 0:
        Log('valid_info: missing CAMGIRLUID')
        return False
    if not CAMGIRL:
        Log('valid_info: missing CAMGIRL')
        return False
    if not CXID:
        Log('valid_info: missing CXID')
        return False
    if not CTXENC:
        Log('valid_info: missing CTXENC')
        return False
    if not TKX:
        Log('valid_info: missing TKX')
        return False
    if not PLATFORM_ID:
        Log('valid_info: missing PLATFORM_ID')
        return False

    return True
    
def fc_decode_json(m):
    try:
        m = m.replace('\r', '\\r').replace('\n', '\\n')
        return simplejson.loads(m[m.find("{"):].decode("utf-8","ignore"))
    except:
        return simplejson.loads("{\"lv\":0}")

def read_model_data(m, camgirl_to_find):
    global CAMGIRLSERVER
    global CAMGIRLCHANID
    global CAMGIRLUID
    global CAMGIRL
    global PLATFORM_ID

    camgirl_to_find = camgirl_to_find.lower() 
    Log("\n read_model_data [msg='<>', camgirl_to_find='{}'] \n".format(camgirl_to_find))

    msg = fc_decode_json(m)
    Log( "msg:%s" % simplejson.dumps(msg) )

    try:
        if msg['uid'] == 0:
            return # these lines don't have any more useful information    
    except:
        pass

    try:
        if msg['uid'] == camgirl_to_find:
            Log( "uid:%s" % camgirl_to_find, xbmc.LOGERROR )
            
    except:
        return
    
    try:
        if camgirl_to_find == msg['nm'].lower():
            CAMGIRL = msg['nm'] #make sure we know who we are talking to:  'nm' can exist multiple places
    except:
        return
    
    if CAMGIRL:

        #vs = visibility status; 0 value means in public chat...don't know how to parse group/private chats
        vs = msg['vs']
        if not (vs == 0):
            vs_string=vs_str[vs]
            utils.notify(msg="{} is {}".format(CAMGIRL, vs_string) )
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            CAMGIRLCHANID = -1
            CAMGIRLUID = -1
            return

        try:
            CAMGIRLUID    = msg['uid']
            PLATFORM_ID   = msg['pid']
            if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
                CAMGIRLCHANID = msg['uid'] + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
            else:
                CAMGIRLCHANID = msg['uid'] + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
        except:
            pass

        u_info=msg['u']
        try:
            CAMGIRLSERVER = u_info['camserv']
        except KeyError:
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            pass
        except Exception, e:
            #Log(('parsing msg dictionary for name:%s' % str(e) ), xbmc.LOGERROR)
            pass

def millitime():
    return int(time.time()) * 1000


def getServerList():
    global serverList

    last_serverlist_refresh = utils.addon.getSetting('last_serverlist_refresh')
    last_serverlist_refresh = datetime.datetime(*(time.strptime(last_serverlist_refresh, "%Y-%m-%d")[0:6]))

    today = datetime.datetime.now().strftime("%Y-%m-%d")
    today = datetime.datetime(*(time.strptime(today, "%Y-%m-%d")[0:6]))
    if not isinstance(last_serverlist_refresh, datetime.date):
        last_serverlist_refresh = datetime.date(1980, 1, 1)

    if last_serverlist_refresh >= today:  # then we can read list from settings
        mfc_serverlist = utils.addon.getSetting('mfc_serverlist')
        Log("using server list from settings")
        serverList = json.loads(mfc_serverlist)

    if serverList:
        return serverList

    #connect to one of the chat servers; random since we don't know how to parse page
    #we need to use 8080 because the other choice, https, does not work with websocket
    url="https://m.myfreecams.com/configproxy.php".format(random.random())
    #post summer 2019
    #ROOT_URL/_js/serverconfig.js?_=1574525594465
    url=ROOT_URL + "/_js/serverconfig.js?_={}".format(random.random())

    try:
        listhtml = utils.getHtml(url)
    except:
        traceback.print_exc()
        return None

    serverList = simplejson.loads(listhtml)

    for num in serverList['h5video_servers']:
##        Log(num)
##        Log(serverList['h5video_servers'][num])
        serverList[num] = serverList['h5video_servers'][num]
    for num in serverList['ngvideo_servers']:
        serverList[num] = serverList['ngvideo_servers'][num]
    for num in serverList['wzobs_servers']:
        serverList[num] = serverList['wzobs_servers'][num]
        
    utils.addon.setSetting(id='last_serverlist_refresh', value=today.strftime("%Y-%m-%d"))    
    utils.addon.setSetting(id='mfc_serverlist', value= json.dumps(serverList) )

    return serverList

def chatserverList():
    global serverList
    if not serverList: getServerList()
    return serverList['chat_servers']

def h5videoserverList():
    global serverList
    if not serverList: getServerList()
    return serverList['h5video_servers']
##    return getServerList()['h5video_servers']

def ngvideoserverList():
    global serverList
    if not serverList: getServerList()
    return serverList['ngvideo_servers']
##    return getServerList()['ngvideo_servers']

def wzvideoserverList():
    global serverList
    if not serverList: getServerList()
    return serverList['wzobs_servers']
##    return getServerList()['wzobs_servers']


def NormalizeServerNumber(server):
##    Log("\n NormalizeServerNumber [{}] \n".format(server))
    global serverList
    result_server = server
    if not serverList:
        getServerList()
##    else:
##        Log(repr(serverList))
    try:
        result_server = serverList[str(server)]
    except:
        pass

##    try:
##        result_server = ngvideoserverList()[str(server)]
##    except:
##        try:
##            result_server = h5videoserverList()[str(server)]
##        except:
##            try:
##                result_server = wzvideoserverList()[str(server)]
##            except:
##                result_server = 'video' + str(server)

##    Log("result_server='{}'".format(result_server))
    return result_server

def getChatServerWebsocket(login_version='20071025'):

    global SESSION_ID
    global CXID
    global CTXENC
    global TKX
    global SERV
    global RESPKEY
    global STYPE
    global OPTS
    global MESSAGE_FIELD_LENGTH
    global XCHAT_HOST
    
    Log("\n getChatServerWebsocket [{}] \n".format(login_version))
    
    xchat = chatserverList()
    sock_buf=None
    ws = None
    failed_count = 0
    FAILED_COUNT_MAX = 4

    while not ws and (failed_count < FAILED_COUNT_MAX):
        try: 
            ws = None
            while not ws and (failed_count < FAILED_COUNT_MAX):

                try:
                    failed_count += 1
                    mfc_xchat_host = utils.addon.getSetting(id='mfc_xchat_host')
                    Log("cached mfc_xchat_host='{}'".format(mfc_xchat_host) )
                    MESSAGE_FIELD_LENGTH = 6 #post 2018 messages
                    while mfc_xchat_host == '' and (failed_count < FAILED_COUNT_MAX):
                        mfc_xchat_host = random.choice(xchat)
                        Log("random mfc_xchat_host='{}'".format(mfc_xchat_host) )
                        if mfc_xchat_host[0:1] == 'x': #there are some ychat servers
                            mfc_xchat_host = "ws://{}.myfreecams.com:8080/fcsl".format( mfc_xchat_host )
                            if mfc_xchat_host[2] == ':':
                                MESSAGE_FIELD_LENGTH = 6 #post 2018 messages
                            else:
                                MESSAGE_FIELD_LENGTH = 4 #pre 2018 messages
                            XCHAT_HOST = mfc_xchat_host
                        else:
                            failed_count += 1
                            mfc_xchat_host = ''
                    if not(mfc_xchat_host == ''):
                        ws = websocket.create_connection(mfc_xchat_host)
                        utils.addon.setSetting(id='mfc_xchat_host', value=mfc_xchat_host)

##                    failed_count += 1
##                    host = None
##                    while host == None and (failed_count < failed_count_max):
##                        host = random.choice(xchat)
##                        Log("host='{}'".format(host) )
##                        if host[0:1] == 'x': #there are some ychat servers
##                            host = "ws://{}.myfreecams.com:8080/fcsl".format( host )
##                            if host[2] == ':':
##                                MESSAGE_FIELD_LENGTH = 6 #post 2018 messages
##                            else:
##                                MESSAGE_FIELD_LENGTH = 4 #pre 2018 messages
##                            XCHAT_HOST = host
##                        else:
##                            failed_count += 1
##                            host = None
##                    if host:
##                        ws = websocket.create_connection(host)
##                        utils.addon.setSetting(id='mfc_xchat_host', value=host)

                except:
                    traceback.print_exc()
                    utils.addon.setSetting(id='mfc_xchat_host', value='')                    
                    time.sleep(0.1)
                    ws = None
            
            #time.sleep(0.1)

#            ws.send("hello fcserver\n\0")
            if not ws: #failed? then wait a bit a try again
                time.sleep(0.2)
                break
            
            ws.send("fcsws_20180422\n\0")
#            ws.send(socket_message + "\n\0")

##            if login_version=='20080910':
##                ws.send('0 0 0 0 0 -' + "\n\0")

            socket_message = "{} 0 0 {} 0 1/guest:guest".format(FCTYPE_LOGIN, login_version)
            ws.send(socket_message + "\n\0" )
            
            sock_buf=None
            sock_buf = ws.recv()
            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            #temp_login_id = hdr.group(6)
            SESSION_ID = hdr.group(3)

            sock_buf=None
            quitting = False
            fc = None
            readcount = 0
            while quitting == False:
                sock_buf = ws.recv()
                readcount = readcount + 1
                if (readcount > MAX_BUFFER_READ_ATTEMPTS): quitting = True #infinite loop detection

                while (len(sock_buf) > 0) and (quitting == False):
                    hdr = re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
                    fc = hdr.group(1)
##                    Log("fc={}".format(fc) )
                    #first bytes of fc tells us size of message
                    #rest of bytes in fc is the fc message type
                    try:
                        msg_type = int(fc[MESSAGE_FIELD_LENGTH:])
                    except:
                        msg_type = int(fc)
##                    Log("msg_type={}".format(msg_type) )

                    mlen = int(fc[0:MESSAGE_FIELD_LENGTH])# characters from position 0 (included) to 6 (excluded)
                    msg = sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH+mlen] 
##                    if len(msg) < mlen:
##                        Log("len(msg) {} < mlen {}".format(len(msg), mlen))
##                        pass
                    msg = urllib.unquote(msg)
                    Log( "msg='{}'".format(msg) )                    
                    msg = fc_decode_json(msg)

                    if msg_type == FCTYPE_TKX:
                        try:
                            CXID = msg['cxid']
                            CTXENC = urllib2.unquote(msg['ctxenc'])
                            TKX = msg['tkx']
##                            Log( "CxID={}".format(CXID) )
##                            Log( "TKX={}".format(TKX) )
##                            Log( "CTXENC={}".format(CTXENC) )
                            break # these lines don't have any more useful information
                        except:
                            pass

                    if msg_type == FCTYPE_EXTDATA:
                        try:
                            if not SERV: #these variables are sent twice differently - we only need the first
                                SERV = msg['serv'] #the xchatserver we are talking to
                                Log( "SERV={}".format(SERV) )
                                RESPKEY = msg['respkey'] 
                                STYPE = msg['type']
                                OPTS = msg['opts']
                                break # these lines don't have any more useful information
                        except:
                            pass

                    if msg_type == FCTYPE_DETAILS:
                        SESSION_ID = msg['sid']
                        break # these lines don't have any more useful information

                    if msg_type == FCTYPE_SESSIONSTATE:
                        quitting = True 
                        break #all necessary info should be here by now
                        
                    sock_buf=sock_buf[MESSAGE_FIELD_LENGTH+mlen:]

        except:
            traceback.print_exc()
            failed_count += 1
            ws = None

    return ws #returning open websocket
    
def getRespkey(camgirl_to_find=''):

    if not SERV:
        ws = getChatServerWebsocket()
        if ws:
            ws.close()

    return SERV, RESPKEY, STYPE, OPTS

def getCamgirlList(notify=False):

    if notify: utils.Notify("Listing {}".format(ROOT_URL))
    
##    Log("\n mfc getCamgirlList {} \n".format(''))
    #return json-like list of online models
    serv, respkey, stype, opts = getRespkey()

    #https://www.myfreecams.com/php/FcwExtResp.php?respkey=1317370146&type=14&opts=256&serv=74  &nc=0.9482386169606472&_=1574525719448
    #https://www.myfreecams.com/php/FcwExtResp.php?respkey=1823878848&type=14&opts=256&serv=49  &nc=0.5449995113      &_=1574784440.56
    #https://www.myfreecams.com/php/FcwExtResp.php?respkey=1814290054&type=14&opts=256&serv=1488&nc=0.65319852890623  &_=1574784754000
    url = ROOT_URL + "/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        respkey, stype, opts, serv, nc_string, millitime() )

    try:
        listhtml = utils.getHtml(url)
    except:
        return None

    return json.loads(listhtml)['rdata'] 

def getCamgirlInfo(camgirl_to_find, json_playlist):
    #Log("\n getCamgirlInfo [{},{}] \n".format(camgirl_to_find, json_playlist[0]))

    if not json_playlist:
        return None, None, None, None

    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ... 
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
    #Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    #del json_playlist[0] #we may not delte this entry because variable is by reference and future calls may need it
    
    key = camgirl_to_find #'HotAnnelisse'
    for item in json_playlist:
        if item[name_index] == key:
##            Log("\n getCamgirlInfo [{},{}] \n".format(camgirl_to_find, repr(item)))
            if item[vs_index] !=0:  #return null if not online
                return None, None, None, None, None, None
            
            camserv = int(item[camserv_index])
            is_new_server  = Is_new_server(camserv)
            modelID = NormalizeChannelID(item[uid_index])

            #normalizeServer will return a string such as video1234; I only want the number
            serverNumber = int(filter(str.isdigit,   str(NormalizeServerNumber(camserv)) )) 

            if is_new_server:
                is_new_server_hack = 'a_'
            else:
                is_new_server_hack = ''

            icon_img = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc_{}{}".format(serverNumber,is_new_server_hack,modelID)
            icon_img += "?no-cache="+str(time.time()*100) #add randomization for caching proxies
##            Log("icon_img='{}'".format(icon_img))

            icon_label = "[COLOR {}]{}[/COLOR]".format(utils.search_text_color, camgirl_to_find)
            if is_new_server: #add some color for hq streams
                icon_label += " [COLOR {}]HQ[/COLOR]".format(utils.time_text_color)

            camscore = int(item[camscore_index])
            
            #Log("\n getCamgirlInfo returning [{},{},{},{}] \n".format(key, camserv, modelID, is_new_server  ))
            return serverNumber, modelID, is_new_server, camscore, icon_img, icon_label
            break

    return None, None, None, None, None, None

def Is_new_server(camserv):
    #corresponds to "onWzObsVideoServer" json information that we may need to start parsing
    #GET https://www.myfreecams.com/_js/serverconfig.js?_=1583266403437
    try:
        
        server = ngvideoserverList()[str(camserv)]
        #log ("return Is_new_server = true")
        return True
    except:
        try:
            #wzvideoserverList  seems to be webRTC ??? , which is some time of encrypted RTMP
            server = wzvideoserverList()[str(camserv)]
            #log ("return Is_new_server = true")
            return True
        except:
            #log ("return Is_new_server = false")
            return False

    return    (camserv in range(545,559))        \
                        or (camserv in range(437,440))  \
                        or (camserv in range(888,897))  
    

def myfreecam_start(camgirl_to_find):

    camgirl_to_find = camgirl_to_find.lower()

    Log("\n myfreecam_start [{}] \n".format(camgirl_to_find))

    websocket_connection = None
    attempts = 0
    max_attempts = 2
    while (not websocket_connection) and (attempts < max_attempts):
        #websocket_connection = getChatServerWebsocket('20080910') ##message styles are from mfc_desktop
        websocket_connection = getChatServerWebsocket('20071025')  ##message styles are from mfc_mobile
        time.sleep(0.1)
        attempts = attempts + 1
    if not websocket_connection:
        utils.notify( "Failed to get websocket connection.  Check internet connection or try later")
        return '', None

    url = ROOT_URL + "/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        RESPKEY, STYPE, OPTS, SERV, nc_string, millitime() )
    try:
        listhtml = utils.getHtml(url)
    except:
        raise    

    rembuf=""
    quitting = 0
    readcount = 0

    FCTYPE_USERNAMELOOKUP = 10
    FCTYPE_ROOMDATA = 44

    websocket_search_command = "{} {} 0 {} 0 {}".format(FCTYPE_USERNAMELOOKUP, SESSION_ID, int(time.time()), camgirl_to_find)
##    Log("websocket_search_command=" + websocket_search_command)
    websocket_connection.send(websocket_search_command+"\n\0")

    websocket_search_command = "{} {} 0 1 0".format(FCTYPE_ROOMDATA, SESSION_ID)
    Log("websocket_search_command=" + websocket_search_command)
    websocket_connection.send(websocket_search_command+"\n\0")

##    ws.close()
##    return '', None

    #MESSAGE_FIELD_LENGTH = 6 #for 2018 messages
    #MESSAGE_FIELD_LENGTH = 4 #for 2017 messages
    while quitting == 0:
        
        readcount = readcount + 1
        if readcount > MAX_READ_COUNT: # infinite loop check
            break

        sock_buf = websocket_connection.recv()

        while len(sock_buf) > 0: 
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX
    #        Log("rawsock_buf:%s"%sock_buf)

            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            if bool(hdr) == 0:
                #Log ("bool(hdr) == 0:")
                #quitting=1
                break #recv() again for the response we need

            fc = hdr.group(1)
            mlen = int(fc[0:MESSAGE_FIELD_LENGTH]) #sometimes multiple messages are part of same recv
            msg_type = int(fc[MESSAGE_FIELD_LENGTH:])
##            Log("msg_type={}".format(msg_type) )

            if msg_type == FCTYPE_USERNAMELOOKUP:

                FCRESPONSE_ERROR = 1
                if int(hdr.group(5)) == FCRESPONSE_ERROR:
                    utils.Notify(msg="'{}' renamed or deleted".format(camgirl_to_find))
                    quitting=1
                    break

                msg = sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH + mlen]
    ##            if len(msg) < mlen: #check for long msgs that required multiple rcvs
    ##                rembuf=''.join(sock_buf)
    ##                #Log ("len(msg) < mlen")
    ##                break
                read_model_data( urllib.unquote(msg) , camgirl_to_find) 

            #we are definitely done when the information for the camgirl shows up and/or offline
            validInfo = valid_info()
            if validInfo or CAMGIRLSERVER == -1:
                quitting=1
                Log ("valid_info()={} or CAMGIRLSERVER == -1".format(validInfo))
                break

            #otherwise, trim the message we have processed
            sock_buf = sock_buf[MESSAGE_FIELD_LENGTH + mlen:]
            if len(sock_buf) == 0: #there was only one message in this receive
                #log ("len(sock_buf) == 0:")
                break

        
    if readcount > MAX_READ_COUNT:
        utils.notify(msg= "{} was not found.  Maybe renamed".format(camgirl_to_find), duration=10000, sound=False)
        #if ws: ws.close()
        return '', None
    
    if not valid_info() or (CAMGIRLSERVER < 1) :
        #utils.notify( msg = ("{} is not online".format(camgirl_to_find)) )
        websocket_connection.close()
        return '', None

    #join the websocket channel to make sure we dont get disconnect(?)
    FCTYPE_JOINCHAN = 51
    FCCHAN_JOIN = 1
    FCCHAN_HISTORY = 8
    FCCHAN_PART = 2

#    head = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
    video_url = None
    if Is_new_server(CAMGIRLSERVER) == "":
        server439hack = "_a"
                
        #try new servers
        video_url="https://{}.myfreecams.com:8444/x-hls/{}/{}/{}/mfc_a_{}.m3u8{}".format(
            NormalizeServerNumber(CAMGIRLSERVER)
            , CXID
            , CAMGIRLCHANID
            , urllib.quote(CTXENC)
            , CAMGIRLCHANID
            , "?nc="+nc_string
            ) 


    if PLATFORM_ID == FCUOPT_PLATFORM_MFC:
        Log('not new server, not camU')
        server439hack = ""

        video_url = "http://{}.myfreecams.com:1935/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8{}"
        video_url = video_url.format( \
                        NormalizeServerNumber(CAMGIRLSERVER)
                        ,server439hack
                        ,CAMGIRLCHANID
                        ,''
                        )

    elif PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
        video_url="https://{}.camyou.com/NxServer/ngrp:cam_{}.f4v_desktop/manifest.mpd"
        video_url= video_url.format( \
            NormalizeServerNumber(CAMGIRLSERVER)
            ,CAMGIRLCHANID
            )

    Log("video_url={}".format(video_url))


    websocket_connection.close()
    return video_url, websocket_connection

#__________________________________________________________________________
#

@utils.url_dispatcher.register(REFRESH_MODE)
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try:
                    os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except:
                    pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            if showdialog==True:
                utils.notify('Finished','Images cleared')
    except:
        pass

    if showdialog==True:
        xbmc.executebuiltin('Container.Refresh')


#__________________________________________________________________________
#

def Search(searchUrl, keyword=None, end_directory=True, page=0):
    return True

#__________________________________________________________________________
#

def Test(keyword):

    return True

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#
