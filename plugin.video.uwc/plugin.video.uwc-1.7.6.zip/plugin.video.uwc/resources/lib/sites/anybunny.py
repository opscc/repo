'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

FRIENDLY_NAME = '[COLOR {}]anybunny[/COLOR]'.format(utils.time_text_color)
LIST_AREA = utils.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "http://anybunny.com"

SEARCH_URL = ROOT_URL + '/top/{}'

URL_CATEGORIES = ROOT_URL
URL_TOP_RATED = ROOT_URL + '/top/'
URL_RECENT = ROOT_URL + '/new/'

MAIN_MODE       = '320'
LIST_MODE       = '321'
PLAY_MODE       = '322'
CATEGORIES_MODE = '323'
SEARCH_MODE     = '324'
CHANNELS_MODE   = '325'


#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(name="{}[COLOR {}]Top videos[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_TOP_RATED
        ,mode=LIST_MODE 
        ,iconimage=utils.category_icon )
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon )

    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)


    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url)) 
    listhtml = utils.getHtml(list_url, '')
    if "did not match any " in listhtml:
        video_region = ""
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon )
    else:
        video_region = listhtml.split('class="main"')[1]
        video_region = video_region.split('class="divrectr"')[0]


    #
    # parse out list items
    #
    regex = "class='nuyrfe' href='([^']+)'.*?src='([^']+)'.*?alt='([^']+)'"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label in info:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , desc = '\n' + ROOT_URL
            , iconimage = thumb )

    #
    # check for a minimum during tesing
    #
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError
    
    #
    # next page items
    #
    next_page_html = listhtml #.split('class=linkscts')[1]
    next_page_regex = 'href="([^"]+)">Next '
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_number=np_url.split('=')[1]
            #if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            np_url=np_url.replace(" ","%20")
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace('+',' ').replace(' ','_')
    searchUrl = SEARCH_URL.format(title)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url, '')
 
    regex = "<a href='/top/([^']+)'>.*?src='([^']+)' alt='([^']+)'"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = URL_RECENT + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
        utils.addDir(name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Play(url, name, download=None):

    desc = name + '\n' + ROOT_URL
    
    abpage = utils.getHtml(url, ROOT_URL)

    regex = "source src='([^']+?mp4[^']+?)'"
    direct_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(abpage)
    if direct_url:
        video_url = direct_url[0]
        Log("video_url={}".format(video_url))
        utils.playvid(videourl=video_url, name=name, download=download, description=desc)
    else:
        regex = '<iframe.*?src="([^"]+)"'
        vartuc_url = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(abpage)
        if vartuc_url: vartuc_url = vartuc_url[0]
        embedpage = utils.getHtml(vartuc_url, url)
        scripturl = re.compile("src='([^']+)", re.DOTALL | re.IGNORECASE).findall(embedpage)[0]
        scripturl = "https://vartuc.com" + scripturl
        #videopage = utils.getHtml(scripturl, vartucurl, vartuchdr)
        videopage = utils.getHtml(scripturl, vartuc_url)

        #https://azblowjobtube.com/kt_player/player.php?id=2806993&s=MhCqUdeCkqOCnPdNPuzxyA&ts=1561758799&ver=x HTTP/1.1
        #2019-06-28 site obfuskates code; i.e need to replace "'+ghbva+'" with "."
        video_url = re.compile("irue842=(.*?);uSS1Comp=", re.DOTALL | re.IGNORECASE).findall(videopage)[0]
        Log("video_url={}".format(video_url))
        match = re.compile(r'(gh\w\w\w)="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)
        for repl, repl2 in match:
            video_url = video_url.replace("'+"+repl+"+'",repl2)

        Log("video_url={}".format(video_url))
        utils.playvideo(videosource=video_url, name=name, download=download, url=url, description=desc)

#__________________________________________________________________________
#



