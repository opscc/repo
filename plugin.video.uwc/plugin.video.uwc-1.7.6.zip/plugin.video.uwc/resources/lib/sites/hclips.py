    #-*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import json
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

HITS_PER_PAGE = 60

FRIENDLY_NAME = '[COLOR {}]HClips[/COLOR]'.format(utils.time_text_color)
LIST_AREA = utils.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://hclips.com"
SEARCH_URL = ROOT_URL + '/search/{}/?q={}&p=0'
SEARCH_URL = ROOT_URL + '/api/videos.php?params=259200/str/relevance/{}/search..{}.all..day&s={}'.format(HITS_PER_PAGE, '{}', '{}')
##GET https://hclips.com/api/videos.php?params=86400/str/relevance/60/search..1.all..day&s=Miss%20Noir,%20Noir_xx,%20Blancnoir,%20Izzy_xx,%20Missnoir_xx HTTP/1.1

URL_CATEGORIES = ROOT_URL + '/categories/'
URL_CATEGORIES = ROOT_URL + '/api/json/categories/14400/str.all.json'
#https://hclips.com/api/json/categories/14400/str.all.json

URL_CHANNELS = ROOT_URL + '/channels/'
#URL_RECENT = ROOT_URL + '/latest-updates/{}/?sort=latest-updates&date=day&type=all'

URL_RECENT = ROOT_URL + '/api/json/videos/86400/str/latest-updates/{}/..{}.all..day.json'.format(HITS_PER_PAGE, '{}')
##GET https://hclips.com/api/json/videos/86400/str/latest-updates/60/..4.all..day.json HTTP/1.1
##Host: hclips.com
##Referer: https://hclips.com


MAIN_MODE       = '380'
LIST_MODE       = '381'
PLAY_MODE       = '382'
CATEGORIES_MODE = '383'
SEARCH_MODE     = '384'
CHANNELS_MODE   = '385'

##SITE_HEADERS = {
##    'User-Agent': utils.USER_AGENT
##    ,'Referer': ROOT_URL
##   }

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon )
    
##    utils.addDir(name="{}[COLOR {}]Channels[/COLOR]".format( 
##        SPACING_FOR_TOPMOST, utils.search_text_color) 
##        ,url=URL_CHANNELS
##        ,mode=CHANNELS_MODE 
##        ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon )
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page > 0 :
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url, ROOT_URL) #, ignore404=True)#, ignore404=True , send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url

    json_content = json.loads(listhtml)
    
    #if "but you can check other awesome vid" in listhtml:
    if 'error' in json_content:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
        
##    else: #distinguish between adverts and videos
##        try:
##            #regex = '(?:class="pages-nav-border"|id="vidresults")(.+?)(?:class="numlist2"|id="wrapBlocks")'
##            #video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##            video_region = listhtml.split('class="paginat')[0].split('class="thumb_holder"')[1]
##        except:
##            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
##            video_region = listhtml

##    from requests import Request, Session
##    s = Session()
##    post_url = 'https://hclips.com/sn4diyux.php'
##    headers = {"User-Agent": utils.USER_AGENT
##               , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
##               , "Referer": list_url
##               }
##    data = post_code
##
##    proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
##    #proxies = {"http": "127.0.0.1:8888"}
##
##    req = Request('POST', post_url, data=data, headers=headers)
##    prepped = s.prepare_request(req)
##    resp = s.send(prepped , proxies=proxies, verify=False)
##    #Log("resp.status_code='{}'".format(repr(resp.status_code)))
##    #Log("resp.content='{}'".format(repr(resp.content)))
##
##    regex = "'([^']+)'"
##    file_code = re.compile(regex, re.DOTALL ).findall(resp.content) [0]
##    #Log("file_code={}".format(file_code))
##    import json
##    items = json.loads(file_code)
##    videourl= utils.alltubes_decode(items[0]['video_url'])
            
    #
    # parse out list items
    #
    if 'videos' in json_content:
        for hit in json_content['videos']:
            #Log("hit='{}'".format(hit))
            videourl = "{}/videos/{}/{}/".format(ROOT_URL, hit['video_id'], hit['dir'])
            thumb = hit['scr']
            label = hit['title']
            duration = hit['duration']
            try:
                hd = hit['props']["hd"]
            except:
                hd = ""
            if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
            elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
            elif  '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
            elif    '1' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
            else: hd = ""

            label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
            utils.addDownLink( 
                name = label 
                , url = videourl 
                , mode = PLAY_MODE 
                , iconimage = thumb
                , desc='\n' + ROOT_URL
                , duration = duration )
    if len(json_content) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError
    

    #
    # next page items
    #
    if 'total_count' in json_content:
        total_count = int(json_content['total_count'])
        page = int(page)
        if page * HITS_PER_PAGE >= total_count:
            Log("np_info not found in url='{}'".format(url))
            Log("current_page*HITS_PER_PAGE={} total_count={}".format(page * HITS_PER_PAGE, total_count))
        else:
            np_number = page + 1
##            search_term = re.compile('&s=([^;]+)').findall(list_url)
##            if search_term: #this was a search result
##                #Log("hit='{}'".format(hit))
##                np_url = SEARCH_URL.format(np_number,   search_term[0].replace(' ','%20'))

            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            np_url = url
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
               if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)

    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    
    keyword = keyword.replace(' ','%20').replace('+','%20')
    searchUrl = SEARCH_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

##https://hclips.com/api/json/categories/14400/str.all.json #2020-05-20
# https://hclips.com/api/json/categories/14400/str.all.json', referer=''

    json_html = utils.getHtml(url, ROOT_URL)
    json_content = json.loads(json_html)

#GET https://hclips.com/api/json/videos/86400/str/latest-updates/60/categories.webcam.1.all..day.json HTTP/1.1
           
    #
    # parse out list items
    #
    if 'categories' in json_content:
        for hit in json_content['categories']:
            #Log("hit='{}'".format(hit))

            
            url = "{}/api/json/videos/86400/str/latest-updates/{}/categories.{}.{}.all..day.json" \
                .format(ROOT_URL, HITS_PER_PAGE,  hit['dir'], '{}')
            label = hit['title']
            label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, utils.cleantext(label) )
            utils.addDir(
                name=label
                ,url=url 
                ,mode=LIST_MODE
                ,page=1
                ,iconimage=utils.search_icon )

    if len(json_content) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'failed Categories {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError
        
##
##    regex = 'href="([^"]+)" class="thumb">.+?src="([^"]+)".+?title="([^"]+)"'
##    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
##    Log("info='{}'".format(info))
##    for url, thumb, label in info:
##        if url.startswith('/'): url = ROOT_URL + url
##        if thumb.startswith('/'): thumb = ROOT_URL + thumb
##        #Log("url='{}'".format(url))
##        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
##            SPACING_FOR_TOPMOST, utils.search_text_color, label)
##            ,url=url 
##            ,mode=LIST_MODE 
##            ,iconimage=thumb )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=1)
    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#


@utils.url_dispatcher.register(CHANNELS_MODE, ['url'], ['end_directory'])
def Channels(url, end_directory=False):
    
    listhtml = utils.getHtml(url, '')

    video_region = listhtml.split('h1>Channels</h1')[1]

    regex = '<a href="([^"]+)".+?src="([^"]+)" alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label in info:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        #duration = duration.replace(' min','s').replace(':','m ')
##        #Log("hd={}".format(hd))
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, label)
        utils.addDir(name= label
            ,url=videourl 
            ,mode=LIST_MODE 
            ,iconimage=thumb )

    next_page_regex ='item--next.*?href="([^"]+)".*?data-parameters="([^"]+)"'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url, number_info in np_info:
            np_number = np_url.split('/')[2]
            if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            search_term = re.compile(' s:([^;]+);').findall(number_info)
            if search_term: #this was a search result
                np_url = SEARCH_URL.format(np_number,search_term[0].replace(' ','%20'))
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
            else:
                utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    Channels(np_url, False)
                else:
                    utils.add_sort_method()
                    utils.endOfDirectory()    
                    
    utils.add_sort_method()
    utils.endOfDirectory()
        

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

##    Log("Playvid url='{}',name='{}',download='{}'".format(url,name,download))

    video_id = url.split('/')[4]
    
           
##    url = 'https://hclips.com/api/json/video/86400/0/171000/171846.json'
##    url = 'https://hclips.com/api/json/video/86400/7000000/7548000/7548729.json'
##    url = 'https://hclips.com/videos/171846/bro-sis-and-mama-roleplay/'
##    url = 'https://hclips.com/videos/7548729/gabbi-carter-property-sex-720p-60fps/'
##    video_id = url.split('/')[4]
##    Log("video_id={}".format(video_id))
    if len(video_id) < 7:
        padder1 = '0'
    else:
        padder1 = video_id[0:1] + '000000' 
    padder2 = video_id[0:(len(video_id)-3)] + '000' 
    mask = "https://hclips.com/api/json/video/86400/{}/{}/{}.json".format(padder1, padder2, video_id)
##    Log("mask={}".format(mask))
##    return
    json_url = mask.format(video_id)
    json_source = utils.getHtml(json_url, url)
    json_content = json.loads(json_source)
    #Log("json_content={}".format(json_content), xbmc.LOGNONE)
    if 'error' in json_content:
        utils.Notify("Video not found '{}' for '{}'".format(json_content['error'] , url) )
        return        

    description = json_content['video']['description']
    Log("description={}".format(description))
    if 'on HClips.com,' in description: description = description.split('on HClips.com,')[0]
    if description == '':
        description=name + '\n' + ROOT_URL
    else:
        description=description + '\n' + ROOT_URL
    Log("description={}".format(description))
    

    mask = "https://hclips.com/api/videofile.php?video_id={}&lifetime=8640000"
    json_url = mask.format(video_id)
    json_source = utils.getHtml(json_url, url)
    json_content = json.loads(json_source)
##    Log("json_content={}".format(json_content))
    if 'error' in json_content:
        utils.Notify("Video not found '{}' for '{}'".format(json_content['error'] , url) )
        return
        
    video_url= ROOT_URL + utils.alltubes_decode(json_content[0]['video_url'])
##    Log("video_url={}".format(video_url.encode()))
    headers = {
        'User-Agent': utils.USER_AGENT
        ,'Referer': url
       }
    video_url = video_url + utils.Header2pipestring(headers)  #required or else acces denied
    Log("video_url={}".format(video_url.encode()))

##    return

    utils.playvid(video_url, name, download, description)

###on HClips.com,
##    
##    if download == 1:
##        utils.downloadVideo(video_url, name)
##    else:    
##        iconimage = xbmc.getInfoImage("ListItem.Thumb")
##        listitem = xbmcgui.ListItem(name)
##        xbmc.Player().play(item=video_url, listitem=listitem)
##        
##    return    

##
##    ### pre 2020-02-15 below
##    regex = "pC3:'([^']+)',.+?\"video_id\": (\d+),"
##    vid_codes = re.compile(regex, re.DOTALL ).findall(videopage)
##    for code, vid_id in vid_codes:
##        post_code = str(vid_id) + ',' + code
##        #Log("post_code={}".format(post_code))
##        import urllib
##        post_code = 'param=' + urllib.quote(post_code)
##        #Log("post_code={}".format(post_code))
##
##    from requests import Request, Session
##    s = Session()
##    post_url = 'https://hclips.com/sn4diyux.php'
##    headers = {"User-Agent": utils.USER_AGENT
##               , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
##               , "Referer": url
##               }
##    data = post_code
##
##    proxies = {}  #note: posts to https:// don't work in kodi 17; use http instead
##    #proxies = {"http": "127.0.0.1:8888"}
##
##    req = Request('POST', post_url, data=data, headers=headers)
##    prepped = s.prepare_request(req)
##    resp = s.send(prepped , proxies=proxies, verify=False)
##    #Log("resp.status_code='{}'".format(repr(resp.status_code)))
##    #Log("resp.content='{}'".format(repr(resp.content)))
##
##    regex = "'([^']+)'"
##    file_code = re.compile(regex, re.DOTALL ).findall(resp.content) [0]
##    #Log("file_code={}".format(file_code))
##    import json
##    items = json.loads(file_code)
##    videourl= utils.alltubes_decode(items[0]['video_url'])
##    #Log("videourl={}".format(videourl.encode()))
##    headers = {
##        'User-Agent': utils.USER_AGENT
##        ,'Referer': 'https://hclips.com/'
##       }
##    videourl = videourl + utils.Header2pipestring(headers)  #required or else acces denied
##    Log("videourl={}".format(videourl.encode()))
##
##    
##    if download == 1:
##        utils.downloadVideo(videourl, name)
##    else:    
##        iconimage = xbmc.getInfoImage("ListItem.Thumb")
##        listitem = xbmcgui.ListItem(name)
##        xbmc.Player().play(item=videourl, listitem=listitem)

#__________________________________________________________________________
#
