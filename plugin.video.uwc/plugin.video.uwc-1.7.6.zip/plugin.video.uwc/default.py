'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import os.path
import sys
import socket
import traceback

import xbmc
import xbmcplugin
import xbmcaddon
from resources.lib import utils
from resources.lib import favorites
from resources.lib.sites import * #required for registering modes into dispatcher
from resources.lib.utils import Log

if int(sys.argv[1]) > 0: 
    xbmcplugin.setContent(int(sys.argv[1]), 'movies') #required to make InfoWall(etc) views available
       
dialog = utils.dialog

#__________________________________________________________________________
#
def Dynamic_Front_Pages_Options():
    settings_file = os.path.join(utils.rootDir, 'resources', "settings.xml")
##    Log( "SETTING FILE %s" % settings_file )
    import xml.etree.ElementTree as ET
    tree = ET.ElementTree(file=settings_file)

##    from io import open
##    requires xml v3.8 
##    with open(settings_file+'.xml', mode='w', encoding='utf-8') as out_file:
##        tree.canonicalize(tree.tostring(), out=out_file, with_comments=True)
##    return
    
#label="Front Pages"
    #Search for the entry in the settings file
    font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
    if font_pages_element_tree is None:
##        Log("not found, creating")
        ET.SubElement(parent=tree.find("."),tag='category',attrib={'label':"Front Pages"})

    font_pages_element_tree = tree.findall(".//category[@label='{0}']".format("Front Pages")) #should only be one of these
    if font_pages_element_tree is None:
##        Log("not found 2")
        pass


    for elems in font_pages_element_tree:
    #for elems in tree.iterfind(".//category[@label='{0}']".format("Front Pages")): #should only be one of these
##        Log(repr(elems.items()))
##        existing_settings = {}
##        for elem in elems: #remember existing settings
####            Log(repr(elem.items()))
##            existing_settings[elem.attrib['id']] = elem
####        Log(repr(existing_settings))
####        for elem in existing_settings:
####            Log(repr(existing_settings[elem].items()))

        elems.clear()
        elems.attrib['label'] = "Front Pages"
        
##        for elem in elems: 
##            elems.remove(elem)
##        for elem in elems: 
##            elems.remove(elem)
##        Log("after remove")
##        for elem in elems: 
##            Log(repr(elem.items()))
##        Log("existing after remove")
##        for elem in existing_settings:
##            Log(repr(existing_settings[elem].items()))
            
        for sitename, module in utils.Get_Sites():
            if module.FRONT_PAGE_CANDIDATE == True:
                ET.SubElement(parent=elems,tag='setting',attrib={'id':sitename+'_on_front_page','label':sitename+'_on_front_page','default':'false','type':'bool'})
            
             #[('default', 'true'), ('type', 'bool'), ('id', 'hqporner_on_front_page'), ('label', 'hqporner_on_front_page')]
##        ET.SubElement(parent=elems,tag='setting',attrib={'id':'test_id2','label':'test_label2','default':'false','type':'bool'})
##        Log("after insert")
##        for elem in elems: 
##            Log(repr(elem.items()))




            
##        for elem in elems: #should only be one of these
####            Log(repr(elem))
##            Log(repr(elem.items()))
####            Log(repr(elem.tag))
##            Log(repr(elem.attrib['label']))
##            if elem.tag == 'category':
                
##                if elem.attrib['id'] == 'arduino_port':
##                    elem.set('values', available_ports)
##
    tree.write(settings_file)
##    Log("force log flush")
##        <setting default="true" id="daftsex_on_front_page" label="daftsex_on_front_page" type="bool" />
##        <setting default="true" id="eporner_on_front_page" label="eporner_on_front_page" type="bool" />
##        <setting default="true" id="porntrex_on_front_page" label="porntrex_on_front_page" type="bool" />
##        <setting default="true" id="pornhub_on_front_page" label="pornhub_on_front_page" type="bool" />
##        <setting default="true" id="vporn_on_front_page" label="vporn_on_front_page" type="bool" />
##        <setting default="true" id="xhamster_on_front_page" label="xhamster_on_front_page" type="bool" />
##        <setting default="true" id="hclips_on_front_page" label="hclips_on_front_page" type="bool" />        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_INDEX_INDEX)
def INDEX():

    if utils.this_addon.getSetting('debug').lower() == "true" :
        utils.addDir('[COLOR {}]Test All[/COLOR]'.format('orange')                    ,'',utils.ROOT_TEST_ALL       ,iconimage=utils.search_icon,page=None,keyword='')
    utils.addDir('[COLOR {}]Search All[/COLOR]'.format(utils.search_text_color)       ,'',utils.ROOT_SEARCH_ALL     ,iconimage=utils.search_icon,page=None,keyword='')
    utils.addDir('[COLOR {}]Front Pages[/COLOR]'.format(utils.refresh_text_color)     ,'',utils.ROOT_FRONT_PAGE     ,utils.search_icon)#,page=None,keyword='')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Scenes[/COLOR]'      ,'',utils.ROOT_INDEX_SCENES   ) #,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Movies[/COLOR]'      ,'',utils.ROOT_INDEX_MOVIES   ) #,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Hentai[/COLOR]'      ,'',utils.ROOT_INDEX_HENTAI   ) #,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Tubes[/COLOR]'       ,'',utils.ROOT_INDEX_TUBES    ) #,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Webcams[/COLOR]'     ,'',utils.ROOT_INDEX_CAMS     ) #,os.path.join(rootDir, 'icon.png'),'')
    utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Favorites[/COLOR]'   ,'',utils.ROOT_INDEX_FAVORITES) #,os.path.join(rootDir, 'icon.png'),'')
    download_path = utils.this_addon.getSetting('download_path')
    if download_path != '' and os.path.exists(download_path):
        utils.addDir('[COLOR hotpink]Whitecream[/COLOR] [COLOR white]Download Folder[/COLOR]',download_path,utils.ROOT_INDEX_DOWNLOAD_FOLDER,None,Folder=False)

    utils.endOfDirectory(True)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_INDEX_SCENES)
def INDEXS():

    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(utils.LIST_AREA_SCENES):
        #Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)
        
    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#
        
@utils.url_dispatcher.register(utils.ROOT_INDEX_MOVIES)
def INDEXM():

    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(utils.LIST_AREA_MOVIES):
        #Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)
        
    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_INDEX_TUBES)
def INDEXT():

    for friendly, root_url, mode, icon_filespec  in utils.Get_Sites(utils.LIST_AREA_TUBES):
        #Log("friendly='{}'".format(friendly),xbmc.LOGNONE)
        utils.addDir(friendly,root_url,mode,icon_filespec)
        
    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_INDEX_CAMS)
def INDEXW():

    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(utils.LIST_AREA_CAMS):
        utils.addDir(friendly,root_url,mode,icon_filespec)
    utils.add_sort_method()
    utils.endOfDirectory(True)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_INDEX_HENTAI)
def INDEXH():

    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(utils.LIST_AREA_HENTAI):
        utils.addDir(friendly,root_url,mode,icon_filespec)
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_SEARCH_ALL, ['page'], ['keyword']  )
def Search_All(page=1,keyword=''):

    if not keyword:
        utils.searchDir('fakeurl', mode=utils.ROOT_SEARCH_ALL)
        return
    
    #temporarilty force only  X   recurse depth for this feature
    utils.DEFAULT_RECURSE_DEPTH = 1
    utils.MAX_RECURSE_DEPTH = 1


    for sitename, module in utils.Get_Sites():
        method_to_call = getattr(module, 'Search')
        try:
            result = method_to_call(module.SEARCH_URL, keyword=keyword, end_directory=False)
            #result = method_to_call('http://127.0.0.1', keyword=keyword, end_directory=False)
            Log('passed search for {}'.format(sitename))

        except:
            Log('failed search for {}'.format(sitename), xbmc.LOGWARNING)
            traceback.print_exc()
            utils.addDownLink(
                name="[COLOR {}]{}[/COLOR]".format('orange', 'failed search on {}'.format(sitename))
                ,url='httpsomething'
                ,mode=1
                ,iconimage='')

    
    utils.add_sort_method()
    utils.endOfDirectory(True)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_FRONT_PAGE, ['page'], ['keyword']  )
def Front_Page(page=1,keyword=None):

    #temporarilty force only  X   recurse depth for this feature
    utils.DEFAULT_RECURSE_DEPTH = 0
    at_least_one=False

    for sitename, module in utils.Get_Sites():
        if module.FRONT_PAGE_CANDIDATE == True:
            if utils.this_addon.getSetting(sitename+'_on_front_page').lower() == "true" :
                at_least_one=True
                method_to_call = getattr(module, 'List')
                try:
                    result = method_to_call(url=module.URL_RECENT, page=module.FIRST_PAGE, end_directory=False)
                except:
                    Log("sitename='{}'".format(sitename),xbmc.LOGNONE)
                    traceback.print_exc()
    if not at_least_one:
        utils.addDir('[COLOR {}]Add Sites to this via Settings[/COLOR]'.format(utils.refresh_text_color)
                     ,url='',iconimage=utils.search_icon
                     ,mode=utils.ROOT_INDEX_INDEX
                     ,Folder=False)



    utils.add_sort_method()
    utils.endOfDirectory()


#__________________________________________________________________________
#

@utils.url_dispatcher.register(utils.ROOT_INDEX_DOWNLOAD_FOLDER, ['url'])
def OpenDownloadFolder(url):
    xbmc.executebuiltin("ActivateWindow(Videos, {})".format(url))

#__________________________________________________________________________
#

def change():
    if os.path.isfile(utils.uwcchange):
        heading = '[B][COLOR hotpink]Whitecream[/COLOR] [COLOR white]Changelog[/COLOR][/B]'
        utils.textBox(heading,utils.uwcchange)
        os.remove(utils.uwcchange)

##if not addon.getSetting('uwcage') == 'true':
##    age = dialog.yesno('WARNING: This addon contains adult material.','You may enter only if you are at least 18 years of age.', nolabel='Exit', yeslabel='Enter')
##    if age:
##        addon.setSetting('uwcage','true')
##else:
##    age = True


def main(argv=None):
    if sys.argv: argv = sys.argv
    queries = utils.parse_query(sys.argv[2])
    mode = queries.get('mode', None)
    try:
        mode_via_url = sys.argv[0].split('/')[3]
        mode = str(int(mode_via_url))
    except:
        pass

    Dynamic_Front_Pages_Options()

    try:
        utils.url_dispatcher.dispatch(mode, queries)
    except:
##        Log("mode='{}'".format(mode),xbmc.LOGNONE)
        raise
                    
if __name__ == '__main__':
    change()
    sys.exit(main())
