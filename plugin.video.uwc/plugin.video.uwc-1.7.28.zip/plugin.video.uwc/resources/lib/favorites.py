'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import random
import re
import sqlite3
import xbmc
import xbmcplugin

from resources.lib import webcam_db
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib.utils import get_setting as GetSetting

from xbmc import LOGNONE
from resources.lib import constants as C

from sites.chaturbate import PLAY_MODE as chaturbate_PLAY_MODE
from sites.chaturbate import clean_database as chaturbate_clean
from sites.chaturbate import Camgirl_Generic_Image as chaturbate_generic_image
from sites.cam4 import PLAY_MODE as cam4_PLAY_MODE
from sites.cam4 import clean_database as cam4_clean
from sites.streamate import PLAY_MODE as streamate_PLAY_MODE
from sites.streamate import clean_database as streamate_clean
from sites.naked import PLAY_MODE as naked_PLAY_MODE
from sites.naked import clean_database as naked_clean
from sites.bongacams import PLAY_MODE as bongacams_PLAY_MODE
from sites.bongacams import clean_database as bongacams_clean
from sites.bongacams import Camgirl_Generic_Image as bongacams_generic_image
from sites.myfreecams import PLAY_MODE as mfc_PLAY_MODE
from sites.myfreecams import clean_database as mfc_clean
from sites.myfreecams import Camgirl_Generic_Image as mfc_generic_image

import time
import traceback

FAV_DB_VERSION = 1

favoritesdb = C.favoritesdb
downloadsdb = C.downloadsdb

#__________________________________________________________________
#
def RefreshImages():
    chaturbate_clean(False)
    cam4_clean(False)
    naked_clean(False)
    mfc_clean(False)
    streamate_clean(False)
    bongacams_clean(False)
#__________________________________________________________________
#
@C.url_dispatcher.register(C.REFRESH_CONTAINER_MODE)  
def RefreshContainter():
    webcam_db.clear_webcam_db( 1 ) # if manually refreshing, latest required, but 1 min should be good enough
    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________
#
@C.url_dispatcher.register("2341234123")  
def Add_Play_Random(dir_only=False):

    if dir_only:
        utils.addDir(
            name="Random Favorited Vid"
            ,url=C.DO_NOTHING_URL
            ,mode="2341234123"
            ,iconimage=C.category_icon
            ,duration=1
            ,Folder=False 
            )
        return

    try:

        model = model_id = None
        
        favDB_conn = sqlite3.connect(favoritesdb)
        favDB_conn.text_factory = str
        favDB_cursor = favDB_conn.cursor()
        sql_command = "SELECT * FROM favorites WHERE camsite is NULL"
        Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
        playable_items = favDB_cursor.execute(sql_command).fetchall()
    ##    Log(repr((playable_items[0][0])))
    ##    Log(repr(len(playable_items[0])))
    ##    random_vid_number = random.randint(0,playable_items[0][0])
    ##    Log(repr(random_vid_number))
    ##    favDB_cursor.execute("SELECT * FROM favorites")
    ##    sql_command = "SELECT * FROM favorites"
    ##    model = favDB_conn.execute(sql_command).fetchone()
    ##    Log(repr(model))
        model_id = random.choice(playable_items)[0]


        favDB_cursor.row_factory = sqlite3.Row
        model = favDB_cursor.execute("SELECT * FROM favorites WHERE id = {}".format(model_id) ).fetchone()
    ##    Log(repr(model))
        model = dict(model)
        Log(repr(model))
            
        if 'play_method' in model and model['play_method'] in ('','None','none',None):
            play_method = None
        elif 'play_method' in model:
            play_method = model['play_method']
        else:
            play_method = None

        if 'hq_stream' in model: hq_stream = model['hq_stream']
        else: hq_stream = 0
                            
        listitem = utils.addDownLink( 
            name = model['name'] #"Random Vid of the Day" #utils.cleantext(icon_label) #model['icon_label'] 
            , url = model['url']  #model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['image']
            #, duration = model['camscore']
            , play_method = play_method
            #, fav = 'del'
            , desc = u"{}\n{}".format(utils.cleantext(model['name']), model['description'])
            , hq_stream = hq_stream
            , return_listitem = True
            )
        Log(repr(listitem))
        u = listitem[0]
        Log(repr(u))
        xbmc.executebuiltin('RunPlugin('+u+')')

    except:
        traceback.print_exc()
        Log(repr((repr(model),model_id)),C.LOGNONE)
        
    
    

#__________________________________________________________________
#
def Create_Table(favDB_conn):
    favDB_cursor = favDB_conn.cursor()
    sql_command = (
        "BEGIN TRANSACTION;"
        "CREATE TABLE IF NOT EXISTS favorites (id INTEGER PRIMARY KEY, name, url, mode, image, description TEXT DEFAULT '', camsite INTEGER DEFAULT NULL);"
        "COMMIT;"
        "PRAGMA user_version = {};".format(FAV_DB_VERSION)
        )
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    favDB_conn.executescript( sql_command )
#__________________________________________________________________
#
def Export_Import(favDB_conn):
    favDB_cursor = favDB_conn.cursor()
    sql_command = (
        "BEGIN TRANSACTION;"
        "DROP TABLE IF EXISTS favorites_bak;"
        "ALTER TABLE favorites RENAME TO favorites_bak;"
        "CREATE TABLE IF NOT EXISTS favorites (id INTEGER PRIMARY KEY, name, url, mode, image, description TEXT DEFAULT '', camsite INTEGER DEFAULT NULL);"
        "INSERT INTO favorites (name, url, mode, image, description, camsite) SELECT name, url, mode, image, description, camsite FROM favorites_bak;"
        "COMMIT;"
        "PRAGMA user_version = {};".format(FAV_DB_VERSION)
        )
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    favDB_conn.executescript( sql_command )
#__________________________________________________________________
#
def Create_Maintain_FavDB(favDB_conn):
    favDB_cursor = favDB_conn.cursor()
    sql_command = "PRAGMA user_version"
    Log("sql_command='{}'".format(sql_command) )#,LOGNONE)
    id_column_count =  favDB_conn.execute( sql_command )
    for a in id_column_count:
#        Log(repr(a[0]))
        if a[0] < FAV_DB_VERSION:
            Log('Export_Import()')
            Export_Import(favDB_conn)
        else:
            Log('Database user_version is up to date')
            Create_Table(favDB_conn)
    
#__________________________________________________________________
#
@C.url_dispatcher.register(C.ROOT_INDEX_FAVORITES)
def List():
    Log("List()")
    items_list = list()


    progress_dialog_message = "Listing Favorites"
    progress_dialog = None
    progress_dialog = utils.Progress_Dialog(C.addon_name, progress_dialog_message)

    try: 

        if GetSetting("auto_clean_img_database", bool):
            RefreshImages()
        manually_refresh_favorites = GetSetting("manually_refresh_favorites", bool)
        play_method = GetSetting("default_playmode", str)

    ##    utils.endOfDirectory(cacheToDisc=( manually_refresh_favorites==True) ) #dev testing
    ##    return

        favDB_conn = sqlite3.connect(favoritesdb)
        Create_Maintain_FavDB(favDB_conn)
        favDB_conn.text_factory = str
        favDB_cursor = favDB_conn.cursor()

        Add_Play_Random(True)
##        utils.endOfDirectory(cacheToDisc=( manually_refresh_favorites==True) )
##        return


        percent = 1
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...filling/scanning webcam database...'
            )        
        camDB_conn = webcam_db.fill_webcam_db(progress_dialog) #locked so that service can't clear DB during processing
        percent = 50 #an arbitrary number...
        progress_dialog.update(
            percent = int(percent)
            ,message = progress_dialog_message 
            ,line2 = ' '
            ,line3 = '...matching online cams...'
            )        
        with camDB_conn:
            
            try:

                favDB_cursor.execute("SELECT * FROM favorites")
                for (fav_id, name, url, mode, img, description, camsite) in favDB_cursor.fetchall():

                    if progress_dialog.iscanceled(): break
                    
##                    percent = percent + 0.03
##                    percent = min(percent,100)
##                    progress_dialog.update(
##                        percent = int(percent)
##                        ,message = progress_dialog_message 
##                        ,line2 = ' '
##                        ,line3 = '...searching for {} ...'.format(name)
##                        )

                    try:
##                        Log("name='{}',url='{}',mode='{}',img='{}'".format(repr(name), repr(url), repr(mode), repr(img)), xbmc.LOGNONE)
                        model_id_via_image = "00000000" # length of 8
                        if str(mode)==mfc_PLAY_MODE:
                            if "/img.mfcimg.com/" in img or "/snap.mfcimg.com/" in img :
                                model_id_via_image = img.split('/')[6]
                                if not model_id_via_image.startswith("mfc_"): #bookmarked when avatar image was being shown instead of preivew image
                                    model_id_via_image = img.split('/')[5]
                                #the 1 indicates model was in public chat when bookmark created
                                if model_id_via_image.startswith("mfc_a_1"):
                                   model_id_via_image = model_id_via_image[len("mfc_a_1"):].split('?')[0]
                                if model_id_via_image.startswith("mfc_1"):
                                   model_id_via_image = model_id_via_image[len("mfc_1"):].split('?')[0]
                                if model_id_via_image[0] == '0':
                                    model_id_via_image = model_id_via_image[1:].split('?')[0] #trim zero from front
                                #img = "https://img.mfcimg.com/photos2/{}/{}/avatar.300x300.jpg".format(model_id_via_image[:3], model_id_via_image)
                                img = mfc_generic_image(model_id_via_image)
                                while len(model_id_via_image) < 8: #put zeros back to make at least 8 for icon search
                                    model_id_via_image = '0' + model_id_via_image
        ##                    Log("model_id_via_image='{}'".format(repr(model_id_via_image)))

                        camDB_conn.row_factory = sqlite3.Row
                        query = u"select * from camlist where (mode = ?) and ((modelID LIKE ?) or ((icon_image LIKE ?) or (icon_image LIKE ?)) )"#.format(model_id_via_image)
                        try:
                            params = (int(mode),name.decode('utf-8'),u"%/mfc_1{}?%".format(model_id_via_image),u"%/mfc_a_1{}?%".format(model_id_via_image))
                        except:
                            params = (int(mode),name,u"%/mfc_1{}?%".format(model_id_via_image),u"%/mfc_a_1{}?%".format(model_id_via_image))
    ##                        Log("name={},url={},mode={},img={}".format(repr(name), repr(url), repr(mode), repr(img)))

##                        Log(repr((query,params)),C.LOGNONE)
                        model = camDB_conn.execute(query,params).fetchone()
                        model_found = (model is not None)
                        
                        if model_found:

                            progress_dialog.update(
                                percent  = progress_dialog.percent + 0.1
                                ,message = progress_dialog_message 
                                ,line2 = ' '
                                ,line3 = '...found {}...'.format(name)
                                )
                            Log('...found {}...'.format(name), C.LOGNONE)
                            
                            model = dict(model)
                            Log("query={} params={} ".format(repr(query), repr(params) ))
                            Log("model='{}'".format(repr(model)) ) #, xbmc.LOGNONE)
                            Log("name={},url={},mode={},img={}".format(repr(name), repr(url), repr(mode), repr(img)) )#, xbmc.LOGNONE)
                            icon_label = "[COLOR {}]{}[/COLOR]".format(C.search_text_color, name)
                            if str(mode)==mfc_PLAY_MODE:
                                #site allows easy name changes, but no searching via id;
                                current_model_name = model['modelID']
                                if current_model_name != name: #automatically refresh name in fav database
                                    Log("new mfc model name '{}' --> '{}'".format(name, current_model_name), xbmc.LOGNOTICE)
                                    #download name also needs changing
                                    import downloader
                                    downloader.rename_download(
                                        name = C.DOWNLOAD_INDICATOR+name
                                        ,new_name = C.DOWNLOAD_INDICATOR+current_model_name
                                        ,mode = mode
                                        ,friendly_name = current_model_name
                                        ,url_factory = current_model_name
                                        )
                                                               
                                    delFav(
                                        url = name
                                        , img = img
                                        ) #Favorites() was supposed to do the del, but can't because of url value issue
                                    Favorites(
                                        fav="refresh"
                                        , favmode = mode
                                        , name = current_model_name
                                        , url = current_model_name
                                        , img = img
                                        , desc = description)


                            if str(mode)==chaturbate_PLAY_MODE:
                                #if not 'fav_image=true' in img:
                                chaturbate_clean(False, name+'%')
                            if str(mode)==naked_PLAY_MODE:
                                model_id = url.split('model_id=')[1]
                                naked_clean(False, model_id+'%')
                                

    
                        else: # model_found == false)
                            model = {}
                            icon_label = name
                            model['video_url'] = url
                            model['mode'] = mode
                            model['icon_image'] = img
                            model['camscore'] = 0
                            #model['play_method'] = C.DEFAULT_PLAYMODE
                            if description: model['description'] = description
                            else: model['description'] = ''

                        if 'hq_stream' in model: hq_stream = model['hq_stream']
                        else: hq_stream = 0
                            
                        if 'play_method' in model and model['play_method'] in ('','None','none',None):
                            play_method = None
                        elif 'play_method' in model:
                            play_method = model['play_method']
                        else:
                            play_method = None
        ##                Log("model['play_method']='{}'".format(repr(model['play_method'])))


##                        if 'fav_image=true' in model['icon_image']: # never send this internal artifact to remote server
##                            model['icon_image'] = model['icon_image'].replace('&'+'fav_image=true','').replace('?'+'fav_image=true','')


##                        Log(repr(model), xbmc.LOGNONE)
                        items_list.append(
                            utils.addDownLink( 
                                name = utils.cleantext(icon_label) #model['icon_label'] 
                                , url = model['video_url'] 
                                , mode = model['mode'] 
                                , iconimage = model['icon_image']
                                , duration = model['camscore']
                                , play_method = play_method
                                , fav = 'del'
                                , desc = utils.cleantext(model['description'])
                                , hq_stream = hq_stream
                                , return_listitem = True
                                )
                            )
                        
                    except:
                        traceback.print_exc()
                
            except :
                traceback.print_exc()
                utils.notify('No Favorites found')
            finally:
                if favDB_conn: favDB_conn.close()

    finally:
##        Add_Play_Random()
        utils.Add_Refresh_Item(
            mode=C.REFRESH_CONTAINER_MODE
            ,progress_dialog=progress_dialog
            ,duration=1 #duration so that when sorting by duration, refresh shows after active webcams when = 1
            ,end_directory=True)
        xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)

    utils.endOfDirectory(cacheToDisc=( manually_refresh_favorites==True) )
#__________________________________________________________________
#
@C.url_dispatcher.register(C.FAVORITES_MODE, ['fav','favmode','name','url','img'],['desc','camsite'])  
def Favorites(fav,favmode,name,url,img,desc=None,camsite=None):
    Log("name='{}',url='{}',img='{}',camsite='{}'".format(name, url, img, camsite), LOGNONE)

    for friendly, root_url, mode, icon_filespec  in  utils.Get_Sites(C.LIST_AREA_CAMS):
        Log(repr((root_url, mode, favmode)))
        if (int(mode)+2) == favmode:
            camsite = True

    n_bak = name
    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = utils.Clean_Filename(name)
    if name in [None,'']: raise Exception("invalid name '{}'".format(n_bak))

    if fav in ["add","refresh"]:
        if favmode == int(bongacams_PLAY_MODE): #site needs special handling
            url = '%stream_{}/playlist.m3u8'.format(name)
        delFav(url, img, name)
        if favmode == int(bongacams_PLAY_MODE):
            img = bongacams_generic_image(name,url,img)
        elif favmode == int(chaturbate_PLAY_MODE):
            img = chaturbate_generic_image(name,url,img)
        normalized_name = addFav(favmode, name, url, img, desc, camsite)
        utils.Notify("{}ed fav:'{}' url:{}".format(fav.capitalize(),normalized_name,url))

    elif fav == "del":
        if favmode == int(bongacams_PLAY_MODE): #site needs special handling
            url = '%stream_{}/playlist.m3u8'.format(name)
        delFav(url, img, name)
        utils.Notify("Deleted fav:{} url:{}".format(name,url))

#__________________________________________________________________
#
def Insert_fav_DB(name, url, mode, image, description, camsite):
    favDB_conn = sqlite3.connect(favoritesdb)
    favDB_conn.text_factory = str
    favDB_cursor = favDB_conn.cursor()
    query = "INSERT INTO favorites (name, url, mode, image, description, camsite) VALUES (?,?,?,?,?, ?)"
    params = (name, url, mode, image, description, camsite)
    Log(repr((query,params)),C.LOGNONE)
    favDB_cursor.execute(query, params)
    favDB_conn.commit()
    favDB_conn.close()

#__________________________________________________________________
#
def addFav(mode,name,url,img,description,camsite):

    Log("addFav {}".format(repr((mode,name,url,img,description,camsite))), xbmc.LOGNONE)

    texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db")) #13 is a constant that may need to be recalculated https://kodi.wiki/view/Databases
##    texture_conn.text_factory = sqlite3.Row #note; wild cards not work with sqlite3.Row factory
    texture_cursor = texture_conn.cursor()

    #find the image that is currently showing; it will be copied as a new record
    query = "SELECT * FROM texture WHERE (url LIKE ? ) AND NOT (url LIKE ?)"
    params = (  img+'%', '%' + 'fav_image=true'+'%' )
    #Log(repr((query,params)),C.LOGNONE)
    result = texture_cursor.execute(query, params).fetchone()


    if result is None:
        msg = "Can't find image to refresh with. Reload the container and/or check network container"
        Log(msg)
        Insert_fav_DB(name, url, mode, img, description, camsite)
        return name

    #add our new, artificially generated fav icon                    
    #keep track of this for later
    texture_size_to_copy_id = result[0]
    #make img different so that it will not be accidentally deleted during database clean operations
    new_image = result[1]
    if ("|" in new_image) and ("?" in new_image) :
        new_image = new_image.replace("|", '&' + 'fav_image=true' + "|")
    elif ("|" in new_image):
        new_image = new_image.replace("|", '?' + 'fav_image=true' + "|")
    else:
        new_image = new_image + '?' + 'fav_image=true'
    query = "INSERT INTO texture(url,cachedurl,imagehash,lasthashcheck) VALUES (?,?,?,?)"
    params = (new_image, result[2], result[3],'')
##    Log(repr((query,params)))
    texture_cursor.execute(query, params)
    inserted_row_id = texture_cursor.lastrowid
    query = "SELECT * FROM sizes WHERE (idtexture = ? ) "
    params = (  texture_size_to_copy_id, )
    size_to_copy = texture_cursor.execute(query, params).fetchone()
    query = "INSERT INTO sizes(idtexture,size,width,height,usecount,lastusetime) VALUES (?,?,?,?,?,?)"
    params = (inserted_row_id, size_to_copy[1], size_to_copy[2], size_to_copy[3], size_to_copy[4], size_to_copy[5])
    Log(repr((query,params)),C.LOGNONE)
    exec_result = texture_cursor.execute(query, params)
    texture_conn.commit()
    texture_conn.close()

    Insert_fav_DB(name, url, mode, new_image, description, camsite)

    return name
#__________________________________________________________________
#
def delFav(url, img, name):
    Log("delFav {}".format(repr((url,img))), xbmc.LOGNONE)
    

    #delete fav and fav_image if it exists
    try:

        favDB_conn = sqlite3.connect(favoritesdb)
        favDB_cursor = favDB_conn.cursor()
        query = "DELETE FROM favorites WHERE url LIKE ?;"
        params = (url,)
        Log(repr((query,params)) ,xbmc.LOGNONE)
        cursor_result = favDB_cursor.execute(query,params)
##        Log(repr(cursor_result.rowcount),xbmc.LOGNONE)
        if not img in (None,'','None','none','%'): #try deleting via image for site where name is easily changable
            if "|" in img: img = img.split("|")[0]
            if "?" in img:
                if "?id=" in img:
                    pass
                else:
                    img = img.split("?")[0]
            sql_command = "DELETE FROM favorites WHERE image LIKE '{}%{}%'".format(img, 'fav_image=true')
            Log("sql_command='{}'".format(sql_command), LOGNONE)
            favDB_cursor.execute(sql_command)

        texture_conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    ##    texture_conn.text_factory = sqlite3.Row #note; wild cards not work with sqlite3.Row factory
        texture_cursor = texture_conn.cursor()
        query = "SELECT id, cachedurl, url FROM texture WHERE (url LIKE ? ) and (url LIKE ?) "
        params = (  img+'%', '%' + 'fav_image=true'+'%')
        Log(repr((query,params)),C.LOGNONE)
        for  texture_id, texture_image_cache, texture_url in texture_cursor.execute(query,params):
            Log(repr((texture_id, texture_image_cache, texture_url)) ,xbmc.LOGNONE)            
            query = "DELETE FROM sizes WHERE idtexture = ?;"
            params = (texture_id,)
            Log(repr((query,params)) ,xbmc.LOGNONE)
            texture_cursor.execute(query,params)
            query = "DELETE FROM texture WHERE id = ? ;"
            params = (texture_id,)
            Log(repr((query,params)) ,xbmc.LOGNONE)
            texture_cursor.execute(query,params)
            try:
                import os
                filespec = "special://thumbnails/" + texture_image_cache
                filespec = xbmc.translatePath(filespec)
                Log(repr(filespec),xbmc.LOGNONE)
                os.remove(filespec)
            except:
                traceback.print_exc()
                pass

    except:
        traceback.print_exc()
        pass

    texture_conn.commit()
    texture_conn.close()
    
    favDB_conn.commit()
    favDB_conn.close()
#__________________________________________________________________
#
