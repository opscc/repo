#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import traceback
import urllib
import xbmc
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib.utils import get_setting as GetSetting
from resources.lib import constants as C

class Base_Website(object):
    
    def __init__(self):
        #don't set these; they are set in the sub-class
        pass
    @property
    def FRIENDLY_NAME(self):
        return self._FRIENDLY_NAME
    @property
    def LIST_AREA(self):
        return self._LIST_AREA
    @property
    def LIST_METHOD(self):
        return self._LIST_METHOD
    _LIST_METHOD = "GET"

    @property
    def LIST_HEADERS(self):
        return self._LIST_HEADERS
    _LIST_HEADERS = None
    @property
    def PLAY_HEADERS(self):
        return self._PLAY_HEADERS
    _PLAY_HEADERS = None
    @property
    def SHOW_PLAY_URL(self):
        return self._SHOW_PLAY_URL
    _SHOW_PLAY_URL = True
    @property
    def IGNORE_404(self):
        return self._IGNORE_404
    _IGNORE_404 = True
    @property
    def FRONT_PAGE_CANDIDATE(self):
        return self._FRONT_PAGE_CANDIDATE
    @property
    def ROOT_URL(self):
        return self._ROOT_URL
    @property
    def SEARCH_URL(self):
        return self._SEARCH_URL  #_ROOT_URL + '/search/?query={}&page={}')
    @property
    def URL_CATEGORIES(self):
        return self._URL_CATEGORIES   #_ROOT_URL + '/categories/'
    @property
    def URL_RECENT(self):
        return self._URL_RECENT  #_ROOT_URL + '/browse/time/?page={}'

    @property
    def SAVE_COOKIES(self):
        return self._SAVE_COOKIES
    _SAVE_COOKIES = False

    @property
    def MAIN_MODE(self):
        return self._MAIN_MODE
    @property
    def LIST_MODE(self):
        return str(int(self._MAIN_MODE) + 1)
    @property
    def PLAY_MODE(self):
        return str(int(self._MAIN_MODE) + 2)
    @property
    def CATEGORIES_MODE(self):
        return str(int(self._MAIN_MODE) + 3)
    @property
    def SEARCH_MODE(self):
        return str(int(self._MAIN_MODE) + 4)
    @property
    def TEST_MODE(self):
        return str(int(self._MAIN_MODE) + 5)


    @property
    def FIRST_PAGE(self):
        return self._FIRST_PAGE
    _FIRST_PAGE = "1"

    @property
    def ITEMS_NOT_FOUND_INDICATORS(self):
        return self._ITEMS_NOT_FOUND_INDICATORS
    _ITEMS_NOT_FOUND_INDICATORS = []
    @property
    def REGEX_video_region(self):
        return self._REGEX_video_region
    _REGEX_video_region = None
    @property
    def REGEX_list_items(self):
        return self._REGEX_list_items
    #no default; instance must override or see an error
    
    @property
    def REGEX_next_page_region(self):
        return self._REGEX_next_page_region
    _REGEX_next_page_region = '(.+)'
    @property
    def REGEX_next_page_regex(self):
        return self._REGEX_next_page_regex
    #no default; instance must override or see an error
    
    @property
    def REGEX_play_region(self):
        return self._REGEX_play_region
    _REGEX_play_region = '(.+)'
    @property
    def REGEX_playsearch_01(self):
        return self._REGEX_playsearch_01
    #no default; instance must override or see an error
    

    @property  #if we happen to be using json to search for playable vids, expect the json item that specifies the url to be labeled as...
    def REGEX_playsearch_JSON_urlstring(self):
        return self._REGEX_playsearch_JSON_urlstring
    _REGEX_playsearch_JSON_urlstring = 'videoUrl'
    @property #if we happen to be using json to search for playable vids, expect the json item that specifies quality to be labeled as...
    def REGEX_playsearch_JSON_qualitystring(self):
        return self._REGEX_playsearch_JSON_qualitystring
    _REGEX_playsearch_JSON_qualitystring = 'quality'



    @property
    def REGEX_tags_region(self):
        return self._REGEX_tags_region
    _REGEX_tags_region = None
    @property
    def REGEX_tags(self):
        return self._REGEX_tags
    _REGEX_tags = None #default is not to look for this

    @property
    def REGEX_categories_region(self):
        return self._REGEX_categories_region
    _REGEX_categories_region = '(.+)'
    @property
    def REGEX_categories(self):
        return self._REGEX_categories
    _REGEX_categories = None #default is not to look for this

    #__________________________________________________________________________
    # sometimes we need a POST+data instead of a GET
    _LIST_DATA = None
    def LIST_DATA(self,**kargs):
        if self._LIST_DATA:
            return self._LIST_DATA(self, kargs)
        else:
            return None
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    _ALTERNATE_playsearch_01 = None
    def ALTERNATE_playsearch_01(self, *args, **kargs):
        if self._ALTERNATE_playsearch_01:
            return self._ALTERNATE_playsearch_01(self, *args, **kargs)
        else:
            return None
    #__________________________________________________________________________
    # Which right click properties to add to icon
    # C.PLAYMODE_VARIABLE, None #adds properies such as play480, play1080
    # "" #adds properies such as C.PLAYMODE_F4MPROXY C.PLAYMODE_INPUTSTREAM
    @property
    def Right_Click_Option(self):
        return self._Right_Click_Option
    _Right_Click_Option = None
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants
    def Search_Keyword_Normalize(self, *args, **kargs):
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args) > 0): keyword = args[0]
        else                                     : keyword = ""
        Log("keyword='{}'".format(repr(keyword)))
        return keyword.replace(' ','+')
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        #search_url = kwargs.pop("search_url", None)
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args) > 0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args) > 1): keyword = args[1]
        elif (args is not None) and (len(args) > 0): keyword = args[0]
        else                                     : keyword = ""
##        Log(repr(args))
##        Log(repr(kargs))
##        Log("search_url='{}'".format(repr(search_url)))
##        Log("keyword='{}'".format(repr(keyword)))
        return search_url.format(keyword, '{}')
    #__________________________________________________________________________
    # Change listing url as neeeded by website
    def List_URL_Normalize(self, url, page=None):
        return url #do nothing by default
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return url #do nothing by default
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        return thumb #do nothing by default
    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by site
    def Video_Source_URL_Normalize(self, url):
        return utils.cleantext(url) 
    #__________________________________________________________________________
    # Construct save file path when default is not good enough
    def Make_Download_Path(self, *args, **kargs):
        return None 
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self.ROOT_URL + videourl
        return videourl
    #__________________________________________________________________________
    # Change thumb url created by List as neeeded by website; not all params must be used
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        if not thumb.startswith('http'): thumb = "https:" + thumb
        return thumb
    #__________________________________________________________________________
    # Change label created by List as neeeded by website
    def Normalize_ListLabel(self, label, hd):
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        return label        
    #__________________________________________________________________________
    #
    def Main(self):
        if C.DEBUG:
            utils.addDir(name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
                , url = C.DO_NOTHING_URL 
                , mode = self.TEST_MODE
                , keyword = ''
                )
        if self.URL_CATEGORIES is not None:
##            Log("type(self.URL_CATEGORIES)='{}'".format(type(self.URL_CATEGORIES)))
            if type(self.URL_CATEGORIES ) == str:
                utils.addDir(
                    name = C.STANDARD_MESSAGE_CATEGORIES 
                    ,url = self.URL_CATEGORIES
                    ,mode = self.CATEGORIES_MODE
                    ,iconimage=C.category_icon)
            elif str(type(self.URL_CATEGORIES)) == "<type 'instancemethod'>":
                self.URL_CATEGORIES()

        progress_dialog = utils.Progress_Dialog(C.addon_name, self._FRIENDLY_NAME)
        self.List(self.URL_RECENT, page=self.FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)
        utils.endOfDirectory()
    #__________________________________________________________________________
    #
    def List(self, url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
        Log(u"List(url={}, page={}, end_directory={}, keyword={}".format(repr(url), repr(page), repr(end_directory), repr(keyword)))

##        if not progress_dialog: progress_dialog = utils.Progress_Dialog(C.addon_name, self._FRIENDLY_NAME)

        (inband_recurse,end_directory,max_search_depth,list_url) = utils.Initialize_Common_Icons(end_directory
                                                                                                 , keyword
                                                                                                 , self.SEARCH_URL
                                                                                                 , self.SEARCH_MODE
                                                                                                 , url
                                                                                                 , page)

        list_url = self.List_URL_Normalize(list_url, page)

        # read html
        redirected_url = None
        full_html = utils.getHtml(
            list_url
            , referer = self.ROOT_URL + '/'
            , headers = self.LIST_HEADERS
            , ignore404 = self.IGNORE_404 #True
            , save_cookie = self.SAVE_COOKIES
            , method = self.LIST_METHOD
            , sent_data = self.LIST_DATA(page=page,keyword=keyword)
            )
        if redirected_url: list_url = redirected_url

        #delted video?
        if any(x in full_html for x in self.ITEMS_NOT_FOUND_INDICATORS):
            video_region = ''
            full_html = ''
            Log("ITEMS_NOT_FOUND_INDICATORS")

        #distinguish between adverts and videos
        try:
            video_region = re.compile(self.REGEX_video_region, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
        except:
            video_region = full_html

        # parse out list items
##        Log(self.REGEX_list_items)
        info = re.compile(self.REGEX_list_items, re.DOTALL | re.IGNORECASE).finditer(video_region)
        videourl = ''
        items_list = list()
        for item in info:

            if progress_dialog:
                if progress_dialog.iscanceled(): break
                progress_dialog.increment_percent()


            videourl = item.group('videourl')
            thumb = item.group('thumb')
            label = item.group('label')
            hd = item.group('hd')
            duration = item.group('duration')
            duration = duration.replace(' min','s')#.replace(':','m ')
            thumb = self.Normalize_ThumbURL(thumb, duration, videourl) #must run before videourl normalized
            hd = utils.Normalize_HD_String(hd)
            videourl = self.Normalize_VideoURL(videourl)
            label = self.Normalize_ListLabel(label, hd)
##            Log(u"label={}".format(utils.cleantext(label)))
##            Log(u"thumb={}".format(repr(thumb)))
##            Log(u"videourl={}".format(repr(videourl)))
##            Log(u"hd={}".format(repr(hd)))
##            Log(u"duration={}".format(repr(duration)))
            items_list.append(
                utils.addDownLink(
                    name = label 
                    , url = videourl 
                    , mode = self.PLAY_MODE 
                    , iconimage = thumb
                    , desc = '\n' + self.ROOT_URL
                    , duration = duration
                    , play_method = self.Right_Click_Option
                    , return_listitem = True
                    )
                )
##        Log(repr(videourl))
        utils.Check_For_Minimum(videourl, keyword, self.MAIN_MODE, self.ROOT_URL, testmode)
        if (testmode == True) and (len(videourl) > 1):
##            pass
            self.Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)

        # next page items
        try:
            next_page_html = re.compile(self.REGEX_next_page_region, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
        except:
            next_page_html = full_html
        np_info = re.compile(self.REGEX_next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
        if not np_info:
            Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
            np_number = max_search_depth + 1
        else:
            np_number = int(page) + 1
            if (len(items_list) < 1): np_number += max_search_depth #ensure another List does not happen
            np_url = url
            if (end_directory == True) and (len(items_list) > 0):
                items_list.append(
                    utils.addDir(
                        name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                        ,url=np_url 
                        ,mode=self.LIST_MODE 
                        ,iconimage=C.next_icon 
                        ,page=np_number
                        ,section = C.INBAND_RECURSE
                        ,keyword=keyword
                        ,return_listitem = True)
                    )

        import xbmcplugin
        xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)

        #recurse if necessary
        if (end_directory == False) and (np_number <= max_search_depth):
            if '{}' in np_url:
                msg = np_url.format(np_number)
            else: #some sites don't have a page number here, but I want to show it
                msg = np_url + "&page={}".format(np_number)
            utils.Notify(msg=msg)
            self.List(
                url=np_url
                , page=np_number
                , end_directory=end_directory
                , keyword=keyword
                , progress_dialog=progress_dialog
                )
        
        utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
    #__________________________________________________________________________
    #
    def Search(self, searchUrl, keyword=None, end_directory=True, page=0, progress_dialog=None):
        Log(u"Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

        if not searchUrl:
            return
        if not keyword:
            utils.searchDir(url=searchUrl, mode=self.SEARCH_MODE, page=page, end_directory=end_directory)
            return

        keyword = urllib.unquote_plus(keyword)
        keyword = self.Search_Keyword_Normalize(keyword=keyword)
        searchUrl = self.Search_URL_Normalize(self.SEARCH_URL, keyword=keyword)
        self.List(url=searchUrl, page=self.FIRST_PAGE, end_directory=end_directory, keyword=keyword, progress_dialog=progress_dialog)

        utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page) == C.FLAG_RECURSE_NEXT_PAGES))
    #__________________________________________________________________________
    #
    def Categories(self, url, end_directory=True):
        Log("Categories(url='{}', end_directory='{}')".format(url, end_directory))
        if not url: return

        category_html = utils.getHtml(url=url, referer=self.ROOT_URL, save_cookie=self.SAVE_COOKIES)
        category_html = re.compile(self.REGEX_categories_region, re.DOTALL | re.IGNORECASE).findall(category_html)
        if category_html: category_html = category_html[0]
        else: category_html = ''
##        Log("category_html={}".format(repr(category_html)))
        info = re.compile(self.REGEX_categories, re.DOTALL | re.IGNORECASE).finditer(category_html)
        for item in info:
            videourl = item.group('videourl')
            thumb = item.group('thumb')
            label = item.group('label')
            videourl = self.Category_URL_Normalize(videourl)
            thumb = self.Category_THUMB_Normalize(thumb)
##            Log(repr(label))
##            Log(repr(videourl))
##            Log(repr(thumb))
            utils.addDir(
                name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
                ,url=videourl
                ,mode=self.LIST_MODE
                ,page=self.FIRST_PAGE
                ,iconimage=thumb
            )

        utils.endOfDirectory(end_directory=end_directory)
    #__________________________________________________________________________
    #
    def Test(self, keyword=None, end_directory=False):
        Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))

        #force user to specify a keyword to search for because not all searches
        #will 'succeed' or 'fail' reliably
        if not keyword:
            keyword = GetSetting('quick_search_string')
        if not keyword:
            #prev_keyword = C.addon.get_xxx__Setting(id='quick_search_string')
            prev_keyword = GetSetting('quick_search_string')
            keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
            if  keyword == '' :
                return False, 0  ## if blank or the user cancelled the keyboard, return
            C.addon.setSetting(id='quick_search_string', value=keyword)
        self.Categories(self.URL_CATEGORIES, False)
        self.Search(searchUrl=self.SEARCH_URL, keyword=keyword, end_directory=False, page=self.FIRST_PAGE)
        self.List(self.URL_RECENT, page=self.FIRST_PAGE, end_directory=False, keyword='', testmode=True)

        if end_directory:
            utils.addDir(
                name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, self.ROOT_URL)
                ,url=C.DO_NOTHING_URL
                ,mode=C.NO_ACTION_MODE)
        
        utils.endOfDirectory(end_directory=end_directory)
    #__________________________________________________________________________
    #
    def Playvid(self, url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
        name = utils.cleantext(name)
        Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
        if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
        else: max_video_resolution = None
        description = name + '\n' + self.ROOT_URL
        video_url = None #final playable url
        sources_list = None #intermediate var
        download_filespec = self.Make_Download_Path(name=name) #
        videos_list = list() #hold multiple video_url when possible

        full_html = utils.getHtml(url, self.ROOT_URL, save_cookie=self.SAVE_COOKIES)
##        Log("type(full_html)='{}'".format(type(full_html)))
##        Log("(full_html)='{}'".format(full_html))
        
        #
        #sometimes the video was deleted
        #
        if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,self.ROOT_URL))
            Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
            return

        #
        #sometimes it is usefull to only look in one part of the page
        #
        if self.REGEX_play_region:
            source_html = re.compile(self.REGEX_play_region, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
        else:
            source_html = full_html
        Log("type(source_html)='{}'".format(type(source_html)))
        

        #if C.FLAG_USE_RESOLVER_ONLY not in self.REGEX_playsearch_01:
        if self.REGEX_playsearch_01:
##            Log((self.REGEX_playsearch_01))
            Log(repr(self.REGEX_playsearch_01))
            sources_list = re.compile(self.REGEX_playsearch_01, re.DOTALL | re.IGNORECASE).finditer(source_html)


        #sometimes the page itself contains direct video file links
        if sources_list and '(?P<res>' in self.REGEX_playsearch_01:
            Log("list with items (res,url)")
            for source in sources_list:
##                Log("sources_list='{}'".format(repr(source)))
                if 'res' in source.groupdict():
                    videos_list.append((source.group('res') , self.Video_Source_URL_Normalize(source.group('url'))))

        #sometimes the page itself contains direct video file links encoded as
        #json
        if sources_list and '(?P<json>' in self.REGEX_playsearch_01:
            for source in sources_list:
                if 'json' in source.groupdict():
                    Log("converting json to a list; with items (res,url)")
                    sources_list = source.group('json')
##                    Log(repr(sources_list))
                    json_sources = json.loads(sources_list)
##                    Log("json_sources='{}'".format(repr(json_sources)))




                    for json_src in json_sources:
                        if self._REGEX_playsearch_JSON_urlstring in json_src:
                            if json_src[self._REGEX_playsearch_JSON_urlstring] != '':
##                                Log(repr(type(json_src['quality'])))
                                if self._REGEX_playsearch_JSON_qualitystring in json_src:
                                    q = json_src[self._REGEX_playsearch_JSON_qualitystring]
                                    if type(json_src[self._REGEX_playsearch_JSON_qualitystring]) == list:
                                        #sometimes this happens...for quality 1
                                        q = '1'
                                else:
                                    q = '1'
                                videos_list.append((q, json_src[self._REGEX_playsearch_JSON_urlstring]))

        #sometimes this is defined
        if (len(videos_list) < 1) and self.ALTERNATE_playsearch_01:
            Log("using ALTERNATE_playsearch_01")
            alt_results = self.ALTERNATE_playsearch_01(
                full_html=full_html
                , referer=url
                , download=download
                , ask_which_file_hoster=not(testmode)
                , name=name                
                )
            Log("alt_results='{}'".format(repr(alt_results)))
            if alt_results:
                #playmode_string = None #allow playvid to figure out best player
                for alt_res, alt_url in alt_results:
                    videos_list.append((alt_res, alt_url))


        #when multiple videos are available; use the best/worst resolution
        if len(videos_list) > 0:
            Log("videos_list='{}'".format(repr(videos_list)))
            video_url = utils.SortVideos(
                sources=videos_list
                ,download=download
                ,vid_res_column=0
                ,max_video_resolution=max_video_resolution)


        #sometimes the page can only be resolved by another tool
        if self.REGEX_playsearch_01 == C.FLAG_USE_RESOLVER_ONLY:
            from resources.lib import resolver
            video_url = resolver.resolve_video(
                videosource=source_html
                , name=name
                , download=download
                , url=url
                , ask_which_file_hoster=not(testmode)
                )

        #what if we fail to get a url??
        if not video_url:
            if testmode:
                raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, self.ROOT_URL))
            else:
                utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, url))
            return

        #sometimes the page has a list of actors
        if self.REGEX_tags_region is not None:
            description = ''
            desc_separator_char = '; '
            region_html = re.compile(self.REGEX_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
            if region_html:
                source_tags = re.compile(self.REGEX_tags, re.DOTALL | re.IGNORECASE).findall(region_html[0])
                for tag in source_tags:
                    tag = utils.cleantext(tag)
                    if tag.lower() not in description.lower():
                        description = u"{}{}{}".format(description,tag,desc_separator_char)
            description = description.strip(desc_separator_char)
            if description == '':  description = name + '\n' + self.ROOT_URL
            else:           description = description + '\n' + self.ROOT_URL
            Log(u"description={}".format(description))
        if self._SHOW_PLAY_URL:
            description = description + '\n' + video_url.split('|')[0] #2021-11 can't use multiple \n


        #always set referrer so that 'kodi' does not appear to the target server
        headers = None
        if '|' not in video_url:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = url
        if headers:
            video_url = video_url + utils.Header2pipestring(headers)
        if self._PLAY_HEADERS:
##            Log(video_url)
            #url will already have | symbol; we should append to existing
            video_url = video_url + '&' +utils.Header2pipestring(self._PLAY_HEADERS)[1:]
##            Log(video_url)

        #during testmode, only ensure that a url can be generated
        Log("video_url='{}'".format(video_url))
        if testmode:
            Log("Would have played video_url; but in test mode")
            return   


        utils.playvid(
            video_url
            , name=name
            , download=download
            , description=description
            , playmode_string=playmode_string
            , play_profile=play_profile
            , download_filespec=download_filespec
            , mode = self.PLAY_MODE
            , url_factory = url
            , icon_URI = icon_URI            
            )
    #__________________________________________________________________________
    #

