'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib import constants as C
from resources.lib.base_website import Base_Website
from resources.lib.utils import Log as Log
from resources.lib.utils import addDir as addDir

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]PornHD[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False
    _ROOT_URL        = "https://www.pornhd.com"
    _URL_CATEGORIES  = _ROOT_URL + '/category'
    _URL_RECENT      = _ROOT_URL + '/?order=newest&page={}'
    _SEARCH_URL      = _ROOT_URL + '/search?search={}&page={}'

    _MAIN_MODE = C.MAIN_MODE_pornhd
    _FIRST_PAGE = '1'
    _Right_Click_Option = None # C.DEFAULT_PLAYMODE # None to allow all possibilities [e.g. present HLS or MP4 play options]
    _SAVE_COOKIES = False       #if we need to save html cookies
    _ITEMS_NOT_FOUND_INDICATORS = [] #which to strings may indicate that there is nothing to be found


        
    #__________________________________________________________________________
    #videos on this page
    _REGEX_video_region = (
##        'class="video-list-container"'
##        '(.+?)'
##        '<nav class="pagination'
        '</phd-live-stream-item>\s*'
        '(<phd-video-item.+?)'
        '<nav class="pagination'
        )
    _REGEX_list_items = (

        'class="video-item '
        '.+?href="(?P<videourl>[^"]+)"'
        '.+?srcset="(?P<thumb>[^"]+)" type="image/jpeg"'
        '.+?alt="(?P<label>[^"]+)"'
        '.+?class="video-duration">\s*(?P<duration>[\d:]+)'
        '(?P<hd>)'
        '(?P<desc>)'
        
##        '<phd-video-item '
##        'duration="PT(?P<duration>[^"]+)"'
##        '.+?href="(?P<videourl>[^"]+)"'
##        '.+?srcset="(?P<thumb>[^"]+)" type="image/jpeg"'
##        '.+?alt="(?P<label>[^"]+)"'
##        '(?P<hd>)'
##        '(?P<desc>)'
        
##        'class="video-item'
##        '.+?href="(?P<videourl>[^"]+)"'
##        '.+?srcset="(?P<thumb>[^"]+)" type="image/jpeg"'
##        '.+?alt="(?P<label>[^"]+)"'
##        '.+?class="video-duration">\s*(?P<duration>[\d:]+)'
##        '(?P<hd>)'
##        '(?P<desc>)'
        )

    _IGNORE_404 = True
    _SAVE_COOKIES = True

##    _LIST_METHOD = "POST"
##    _LIST_HEADERS = {
##        "User-Agent": C.USER_AGENT
##        , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
##        , "Referer": _ROOT_URL
##        , "X-Requested-With": "XMLHttpRequest"
##        , "Accept-Encoding": "gzip"
##        , "Accept-Language": "en-US,en;q=0.9"
##    }
##    def LIST_DATA(self, **kargs):
##        page = kargs["page"]
####        keyword = kargs["keyword"]
##        return "page={}".format(page)
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = '<nav class="pagination(.+?)</nav>'
    _REGEX_next_page_regex = '(class="pagination-next")' #as long as result is not empty

    #__________________________________________________________________________
##    _REGEX_categories_region = 
##        (
##        'class="main_category_header"(.+)'
##        )
    _REGEX_categories = (
        'a href="(?P<videourl>/category/[^"]+)"'
        '.+?srcset="(?P<thumb>[^"]+)" type="image/jpeg"'
        '.+?alt="(?P<label>[^"]+)"'
        )
##    _REGEX_categories = (
##        '<span class="ic-check icr"><span>(?P<label>.+?)<'
##        '.+?<li data-id="(?P<videourl>.+?)"'
##        '(?P<thumb>)'
##        )
    def Category_URL_Normalize(self, url): # Change url found in via regex with structure neeeded by website
        return self._ROOT_URL + url + '?page={}'
    def Category_THUMB_Normalize(self, thumb): # Change url found in via regex with structure neeeded by website
        return "https:" + thumb
##    #override categor from a basic url to custom function
##    def _URL_CATEGORIES(self):
##        cat_url = self._ROOT_URL + '/genres/uncensored/page/{}/' #2021-09-12
##        addDir(
##            name = '[COLOR {}]Uncensored[/COLOR]'.format(C.search_text_color)
##            ,url = cat_url
##            ,mode = self.LIST_MODE
##            ,page = self._FIRST_PAGE
##            ,iconimage=C.category_icon)
##        pass
##    def Categories(self, url, end_directory=True):
##        return True

    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        keyword = keyword.replace('+',' ').replace(' ','%20')
        return search_url.format(keyword, '{}')

##    #__________________________________________________________________________
##    #where playable urls live
    _REGEX_playsearch_01 = None #not for this site
##    (
##        ',?"?mediaDefinitions?"?:(?P<json>.+?\]),'  #video data as json
##        'data-hls-src(?P<res>\d+)'                #video data as res+url
##        '="(?P<url>[^"]+)"'
##        )

    #description for the playable url
    _REGEX_tags = "https://pornhive.tv/actor/.+?</i>\s(?P<model>[^<]+)<"
#href="https://pornhive.tv/actor/cadence-lux/" class="btn btn-secondary btn-xs me-2 mb-3"><i class="bi bi-person-fill"></i> Cadence Lux</a>
    #'<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    _REGEX_tags_region = None #'class="detail-video-block"(.+?)class="comments-wrapper"'

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url; returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        Log("_ALTERNATE_playsearch_01(args='{}',kargs='{}'".format(repr(args)[0:250], repr(kargs)[0:250]))

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        import base64, json, re
        from resources.lib import utils

        video_url = ''

        regex = '<source.+?src="([^"]+)".+?res=\'([^\']+)\''
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        list_key_value = {}
        for i in range(len(sources_list)):
            q = sources_list[i][0]
            u = sources_list[i][1]
            if not u == "":
                list_key_value[q] = u
        list_key_value = [ [k,v] for k, v in list_key_value.items() ] #convert dict to list for the next function
        video_url = utils.SortVideos(
            sources=list_key_value
            ,download=False
            ,vid_res_column=1
            ,max_video_resolution=None
            )
            
        import cookielib
        cj = cookielib.LWPCookieJar(C.cookiePath)
        try:
            cj.load(ignore_discard=True, ignore_expires=True)
        except:
            pass
        
        #this site needs a cookie to play video
        cookiestring = ''
        h = ''
        for cookie in cj:
            if cookie.domain.endswith(".pornhd.com"):
                if cookie.name=="xx __cfduid":
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
                if cookie.name=="xx tsid":
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
                if cookie.name=="XSRF-TOKEN":
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
                if cookie.name=="laravel_session":
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
                if cookie.name=="xx wmttrd": 
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
        h = h.strip(';')
        
        if len(h) > 1:
            headers = { 'Cookie': h  }
            cookiestring = "{}&Cookie={}".format(utils.Header2pipestring(), h)
            Log("cookiestring={}".format(cookiestring))

        #need as second call without redirection to get the latest cookies
        import urllib2, ssl
        class NoRedirection(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
            https_response = http_response
        

        opener = urllib2.build_opener(NoRedirection, urllib2.HTTPCookieProcessor(cj))
        headers = []
        for a in C.DEFAULT_HEADERS:
            headers.append ((a, C.DEFAULT_HEADERS[a]))
        headers.append (("Referer", url ))
        headers.append (("Cookie", h ))
        opener.addheaders = headers
        Log("opener.addheaders={}".format(repr(opener.addheaders)))

        response = opener.open(video_url) #, context=ssl._create_unverified_context())
        if response.code == 302:
            video_url = response.headers['Location']
            Log("redirected video_url={}".format(video_url))

        video_url = video_url.replace('&amp;', '&')


        #this site needs a cookie to play video
        cookiestring = ''
        h = ''
        for cookie in cj:
            if cookie.domain.endswith(".pornhd.com"):
                if cookie.name=="xx  __cfduid":
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
                if cookie.name=="tsid":
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
                if cookie.name=="xx XSRF-TOKEN":
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
                if cookie.name=="xx laravel_session":
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
                if cookie.name=="wmttrd": 
                    h += "{}={}".format(cookie.name,cookie.value) + ';'
        h = h.strip(';')
        if len(h) > 1:
            headers = { 'Cookie': h  }
            cookiestring = "{}&Cookie={}".format(utils.Header2pipestring(), h)
            Log("cookiestring={}".format(cookiestring))
##            video_url = video_url + cookiestring


        alt_results.append( ('1', video_url) )

        return alt_results


    #__________________________________________________________________________
    #

#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    website.Playvid(url, name, download, playmode_string, play_profile=play_profile, testmode=testmode)
#__________________________________________________________________________
#
