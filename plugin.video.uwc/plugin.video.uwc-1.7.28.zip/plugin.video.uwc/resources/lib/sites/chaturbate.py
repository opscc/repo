'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import datetime
import json
import re
import sys
import traceback
import urllib
import xbmc
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]Chaturbate[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://chaturbate.com"
SEARCH_URL = ROOT_URL + '/?s={}'
URL_RECENT = ROOT_URL + "/female-cams/?page={}"
URL_COUPLES = ROOT_URL + "/couple-cams/?page={}"

MAIN_MODE          = C.MAIN_MODE_chaturbate
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CLEANDATABASE_MODE = str(int(MAIN_MODE) + 3)
REFRESH_MODE       = str(int(MAIN_MODE) + 4)
SEARCH_MODE        = str(int(MAIN_MODE) + 5)
TEST_MODE          = str(int(MAIN_MODE) + 6)

FIRST_PAGE = '1'
KEYWORD = '1'
ROOM_DATA_PREFIX = "cached_chaturbate_data_"
ROOM_DATA_CACHE_DURATION = 2
CACHE_STRING = "chaturbate_girls"
MOST_RECENT_LIST = "chaturbate_MRL" #needed for REFRESH mode
#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name="{}[COLOR {}]Couples[/COLOR]".format(
            C.SPACING_FOR_TOPMOST
            ,C.search_text_color
            ) 
        ,url=URL_COUPLES
        ,page=FIRST_PAGE
        ,mode=LIST_MODE
        ,iconimage=C.category_icon
        ,keyword=KEYWORD
        
        )
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword=KEYWORD)
#__________________________________________________________________________
#
def GetCamgirlList(url=URL_RECENT, page=FIRST_PAGE, depth=1, notify=False, progress_dialog=None):
    if notify: utils.Notify("Listing {}".format(ROOT_URL))


##    return json.loads("[]")  #testing
    
    json_items = utils.global_cache.get(CACHE_STRING+url+str(page)+str(depth))
##    json_items = None #testing
    if json_items and (len(json_items) > 0)  :
        Log("using global_cache chaturbate_girls")
        return json_items

    depth = int(depth)
    json_items = json.loads("[]") 
    while depth > 0:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        
        if '{}' in url and page: list_url = url.format(page)
        else: list_url = url

        #recurse depth some more
        page = int(page) + 1
        depth = int(depth) - 1 

        listhtml = utils.getHtml(list_url, ROOT_URL, save_cookie=False)
        if listhtml is None: return json_items #in case we don't have IP
        
        videos_regex = (
            '<li class="room_list_room"'
            '.+?<a href="([^"]+)"'
            '.+?data-room="([^"]+)"'
            '.+?img src="([^"]+)"'
            )
        if 'class="cams"' in listhtml: #2020-10 some don't report this data...leading to crashed regex
            videos_regex += '.+?class="cams".+?(\d+)\sviewers'
        else: 
            videos_regex += '.+?class="age.+?(\d+)</span>'
            #Log("no viewers")
            
        info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
        for video_url, name, icon_image, viewers in info:

            if progress_dialog:
                if progress_dialog.iscanceled(): break
##                progress_percent+=0.1
##                progress_dialog.update((progress_percent))
##                progress_dialog.update((progress_dialog.percent + 0.05))
                progress_dialog.increment_percent()

##            Log("video_url={}".format(video_url))
            if not video_url.startswith('http'): video_url = ROOT_URL + video_url
            hd = ''
            camscore = int(viewers)  #always gets a bonus because site is generally hq
            icon_label = "{}{} {}".format(C.SPACING_FOR_NAMES, utils.cleantext(name), hd)

##            if '?' in icon_image: icon_image = icon_image.split('?')[0] #site includes anti-cache element that I don't want to store so that icons info can be more easily cached by kodi

##            Log( repr(name) + repr(icon_image), xbmc.LOGNONE )
                
            json_item = {}
            json_item['username'] = name
            json_item['icon_label'] = icon_label
            json_item['icon_image'] = icon_image
            json_item['video_url'] = video_url
            json_item['camscore'] = camscore
            json_item['mode'] = PLAY_MODE
            json_item['description'] = '\n' + ROOT_URL
            json_item['play_method'] = ''

            json_items.append(json_item)

    utils.global_cache.set(
        endpoint = (CACHE_STRING+url+str(page)+str(depth))
        ,data = json_items
        ,expiration = datetime.timedelta(minutes=ROOM_DATA_CACHE_DURATION)
        )
    
    return json_items
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=FIRST_PAGE, end_directory=True, keyword=FIRST_PAGE, progress_dialog=None):#, progress_percent=0):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    utils.global_cache.set(  #see REFRESH_MODE for why/how used
        endpoint = MOST_RECENT_LIST
        ,data = {"url":url, "page":page, "keyword": keyword}
        )

    if not progress_dialog:
        progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
##        progress_percent = 0

    try:
        items_list = list()
        
        models = GetCamgirlList(url, page, depth=int(keyword), progress_dialog=progress_dialog)
        for model in models:
            items_list.append(
                utils.addDownLink( 
                    name = model['icon_label'] 
                    , url = model['video_url'] 
                    , mode = model['mode'] 
                    , iconimage = model['icon_image']
                    , duration = model['camscore']
                    , play_method = model['play_method']
                    , desc = model['description']
                    , return_listitem = True #allows for bulk appending of list items
                    )
                )

        # next page items
        np_number = int(page) + 1
        np_url = url
        
        #add custom menu option to next page item that allows extra recursion/search
        recurse_levels = C.DEFAULT_RECURSE_DEPTH
        keyw = (
            "{}".format(sys.argv[0]) +
            "?url={}".format(urllib.quote_plus(url)) +
            "&mode={}".format(LIST_MODE) +
            "&keyword={}".format(recurse_levels) +
            "&page={}".format(urllib.quote_plus(str(page))) +
            "&end_directory=True" 
            )        
        contextMenuItems = []
        contextMenuItems.append(
                (
                    "{}[COLOR {}]Recurse ({})[/COLOR]".format(C.SPACING_FOR_NEXT, C.search_text_color, recurse_levels)
                    , "xbmc.ActivateWindow(Videos,{})".format(keyw)
                )
            )

        #prepare to bulk-add the video items
        items_list.append(
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,keyword=keyword
                ,contextMenu=contextMenuItems
                ,contextMenuReplace=False
                ,return_listitem = True #allows for bulk appending of list items
                )
            )
            
    finally:
        #add refresh and video items
        utils.Add_Refresh_Item(
            mode=REFRESH_MODE
            ,progress_dialog=progress_dialog
            ,end_directory=end_directory)
        xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    '''
    Because I can't find a generic image for not-online models, I will only refresh
    images that currently online
    The list of online models is cached in the global cache, but that list depends on
    url,page,depth
    I believe the 'Container.Refresh'  item knows those things [how else could a
    refresh happen?] but I can't find documentation on how to extract it
    Therefore I must cache the that data
    Is is very likely that I may miss some icons that should be deleted, particuarly if
    a recursive listing was made, but this entire listing is a best-effort
    '''
    most_recent = utils.global_cache.get(endpoint = MOST_RECENT_LIST)
##    progress_dialog = utils.Progress_Dialog(C.addon_name, '..cleaning cached images' )
##    models = GetCamgirlList(most_recent['url'], most_recent['page'], depth=int(most_recent['keyword']), progress_dialog=progress_dialog)
##    for model in models:
##        progress_dialog.increment_percent()
##        clean_database(showdialog=False, specific_texture=model['username']+'%' )
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
@C.url_dispatcher.register(CLEANDATABASE_MODE)
def clean_database(showdialog=True, specific_texture=None):
    if specific_texture in [None,'']: return #don't clean up entire image database until we figure out how to get images for off-line models
    DEFAULT_IMAGE_DOMAIN = "%.highwebmedia.com%"
    FAV_ICON_FLAG = '%fav_image=true%'
    import os
    import sqlite3
    texture_connection = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    texture_cursor = texture_connection.cursor()
    try:
        image_domain = DEFAULT_IMAGE_DOMAIN
        if not(specific_texture in [None,'']):
            image_domain = image_domain + specific_texture #+ '%'
##            query = "SELECT id, cachedurl, url FROM texture WHERE url LIKE '{}';".format(image_domain)
        query = "SELECT id, cachedurl, url FROM texture "\
                "WHERE (url LIKE ?) " \
                "AND (cachedurl NOT IN (SELECT cachedurl FROM texture WHERE url LIKE ?) )"
        params = (image_domain, FAV_ICON_FLAG)
        Log(repr((query,params))) #,xbmc.LOGNONE)
        for texture_id, texture_image_cache, texture_url in texture_cursor.execute(query,params):
##            Log(repr((texture_id, texture_image_cache, texture_url)) ,xbmc.LOGNONE)
            query = "DELETE FROM sizes WHERE idtexture = ?"
            params = (texture_id,)
##            Log(repr((query,params)) ,xbmc.LOGNONE)
            texture_cursor.execute(query,params)
            query = "DELETE FROM texture WHERE id = ?"
##            Log(repr((query,params)) ,xbmc.LOGNONE)
            texture_cursor.execute(query,params)
            try:
                filespec = "special://thumbnails/" + texture_image_cache
                filespec = xbmc.translatePath(filespec)
##                Log(repr(filespec),xbmc.LOGNONE)
                os.remove(filespec)
            except:
                traceback.print_exc()
                pass
            
        if showdialog:
            utils.notify(FRIENDLY_NAME +' images cleared')
    except:
        traceback.print_exc()
        pass
    finally:
        texture_connection.commit()
        texture_connection.close()
#__________________________________________________________________________
#
def Search(searchUrl, keyword=None, end_directory=True, page=0, progress_dialog=None):
    return True
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))
    return True
#__________________________________________________________________________
#
def Camgirl_Generic_Image(model_id, url=None, current_icon=None):

    model_id = utils.Clean_Filename(model_id)
    Log("refreshing icon for {}".format(repr(model_id)), xbmc.LOGNONE)

    generated = False

    #site has generic banner whose size is smaller than this
    generic_icon_size = 5000

    response = utils.getHtml(current_icon, send_back_response=True)
    if len(response.data) > generic_icon_size: # we don't want the generic banner
        icon_image_url = current_icon
        generated = True
        Log("current_icon was found; image {} ".format(repr(icon_image_url)), xbmc.LOGNONE)
    else:
        #try using the current streaming pic
        icon_image_url = "https://roomimg.stream.highwebmedia.com/riw/{}.jpg".format(model_id)
        response = utils.getHtml(icon_image_url, send_back_response=True)

    if not generated and (len(response.data) > generic_icon_size):
        generated = True
        Log("a current online image was found  {} ".format(repr(icon_image_url)), xbmc.LOGNONE)

    if not generated:
        # a generic banner was found
        # try and find a better image from the biography
        try:
            icon_image = current_icon
            headers = C.DEFAULT_HEADERS.copy()
            headers['X-Requested-With'] = 'XMLHttpRequest'
            headers['Accept'] = '*/*'
            info_url = 'https://chaturbate.com/api/biocontext/{}/'.format(model_id)
            json_html = utils.getHtml(info_url, headers=headers)
            json_info = json.loads(json_html)
            if 'photo_sets' in json_info:
                if len(json_info['photo_sets']) > 0:
                    icon_image_url = json_info['photo_sets'][0]['cover_url']
                    Log("photo set found in bio", xbmc.LOGNONE)
                else:
                    Log("not online; no album; keping original", xbmc.LOGNONE)
                    icon_image_url = current_icon
        except:
            Log("exception; no changes", xbmc.LOGNONE)
            icon_image_url = current_icon
            traceback.print_exc()




    Log(repr(icon_image_url), xbmc.LOGNONE)
    return icon_image_url
##
##
##    return current_icon
##    model_id = utils.Clean_Filename(model_id)
##    room_data = getRoomData(model_id)
##    try:
##        icon_image = 'https://i.bcicdn.com' + room_data['performerData']['avatarUrl']
##        icon_image = icon_image.replace('_avatars.jpg', '_profile_m.jpg')
##    except:
##        traceback.print_exc()
##        icon_image = current_icon
##    return icon_image
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name', 'img'], ['playmode_string', 'download', 'play_profile'])
def Playvid(url, name, icon_URI, download=None, playmode_string=None, play_profile=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}',icon_URI={})".format(url,name,download,playmode_string,play_profile,repr(icon_URI)))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    name = utils.Clean_Filename(name)
    description = name + '\n' + ROOT_URL
    video_url = None #final playable url

    # do stuff to get a playable url
    #listhtml = utils.getHtml(url, headers=cb_headers)
    listhtml = utils.getHtml(url, referer=ROOT_URL)
##    Log("listhtml='{}'".format(listhtml), xbmc.LOGNONE)

    #we skip a few regex sections because json can't parse the jscript string
    regex = 'window.initialRoomDossier = "({.+), \\\\u0022edge_auth'
    m3u8url = re.compile(regex, re.DOTALL).findall(listhtml)
    if m3u8url:
        m3u8url = m3u8url[0]
        m3u8url = m3u8url.decode('unicode_escape') + '}'
        #Log("m3u8url='{}'".format(m3u8url)) #can't log this because my logger can't handle some of the escape sequences
        #Log("m3u8url='{}'".format(m3u8url))
        m = json.loads(m3u8url)
        if m['room_status'] == 'public':
            video_url = m['hls_source']
        else:
            utils.notify(name,'Room is not public')
            video_url = None

    #what if we fail to get a url??
    if not video_url:
        if download: #create a 'fake' dowload url so that scheduled d/l can happen
            video_url = url + C.SCHEDULED_DOWNLOAD_INDICATOR
        elif testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
            return

    #always set referrer so that 'kodi' does not appear to the target server
    if '|' not in video_url:
        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        video_url = video_url + utils.Header2pipestring(headers)

    #calculate potential download name here because I want to include recording date
    from resources.lib import downloader
    download_filespec = downloader.Make_download_path(
        name = name
        , include_date = True
        , file_extension = '.ts'
        )

    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return   #during testmode, only ensure that a url can be generated

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI
        , repeat_when_available = True
        )
#__________________________________________________________________________
#

