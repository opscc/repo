'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import base64,re,urllib
import xbmc,xbmcgui,xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "http://www.pornhive.tv"

SEARCH_URL = ROOT_URL + '/en/search?keyword='

URL_CATEGORIES = ROOT_URL + '/en/categories'

URL_RECENT = ROOT_URL + '/en/page/'

MAIN_MODE       = '70'
LIST_MODE       = '71'
PLAY_MODE       = '72'
CATEGORIES_MODE = '73'
SEARCH_MODE     = '74'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon)
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)
        
    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url)

    #
    # parse out list items
    #
    videos_regex = 'anel-img">\s+<a href="([^"]+)">\s+<img.*?data-src="([^"]+)".*?alt="([^"]+)'
    videos_info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in videos_info:
        #2019-07-21 no duration or quality information
        hd = ''
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb )
            #, duration=duration )


    #
    # next page items
    #
    next_page_regex = "\"pagination\".+?<a href=\"([^\"]+)\" data-ci-pagination-page=\"([^\"]+)\" rel=\"next\">Next &rsaquo;"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url, np_number in np_info:
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number)/32)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number )

            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH * 32   #32 exists for this website only
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    
    title = keyword.replace(' ','+')
    searchUrl = SEARCH_URL + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url, '')

    cathtml = utils.getHtml(url)
    cat_page_regex = 'panel-img">\s+<a href="([^"]+)".*?alt="([^"]+)"'
    cat_page_info = re.compile(cat_page_regex, re.DOTALL).findall(cathtml)
    for np_url, np_label in cat_page_info:
        #2019-06-19: this website uses a separate call to get images; I am not going to bother looking them up
        np_label="{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, np_label)
        utils.addDir(
            name= np_label
            ,url=np_url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Play(url, name, download=None):

    Log("Playvid url={}".format(url))
        
    videopage = utils.getHtml(url, '')
    if 'extra_urls' in videopage:
        baseurls = re.compile("'(aHr[^']+)", re.DOTALL | re.IGNORECASE).findall(videopage)
        #send all the decoded URLs as part of the html source; will be further parsed by util library
        for base in baseurls:
            videopage = "\"" + base64.b64decode(base) + "\" " + videopage

    utils.playvideo(videopage, name, download, url=url)
