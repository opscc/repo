'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import re
import sys
import random
import sqlite3
import urllib

import traceback

import inputstreamhelper
import time
import random
import json
import datetime
                
try:     import simplejson
except:  import json as simplejson   

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib import websocket
from resources.lib.utils import Log


import socket
__user_agent__ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"

import xbmcaddon
ADDON=xbmcaddon.Addon()


MAX_READ_COUNT = 100
CAMGIRLSERVER = None
CAMGIRLCHANID = None
CAMGIRLUID = None
CAMGIRL = None
CXID = None
CTXENC = None
TKX = None
SESSION_ID = None
PLATFORM_ID = None

SERV = None
RESPKEY = None
STYPE = None
OPTS = None

serverList = None                

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

FCUOPT_PLATFORM_MFC = 1
FCUOPT_PLATFORM_CAMYOU = 2

vs_str={}
vs_str[0]="PUBLIC"
vs_str[2]="AWAY"
vs_str[12]="PVT"
vs_str[13]="GROUP"
vs_str[14]="GROUP"
vs_str[90]="CAM OFF"
vs_str[127]="OFFLINE"
vs_str[128]="TRUEPVT"

MAIN_MODE = '270'
LIST_MODE =  '271'
PLAY_MODE = '272'
REFRESH_MODE = '273'
SEARCH_MODE = '274'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    serv, respkey, stype, opts = getRespkey()
    List("https://www.myfreecams.com/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        respkey, stype, opts, serv, random.random(), time.time() )   )

#__________________________________________________________________________
#

def arrayPositionForKeyname(array, key):
    i=0
    for val in array:
        if isinstance(val, unicode):
            if val == key:
                return i 
            i += 1
        elif isinstance(val, dict):
            for val2 in val.values():
                if isinstance(val2, (list, dict, tuple)):
                    for val3 in val2:
                        if val3 == key:
                            return i 
                        i += 1
                elif isinstance(val2, unicode):
                    if val2 == key:
                        return i
                    i += 1
    return None

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'])
def List(url):

    utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.refresh_text_color)
        ,url=''
        ,mode=REFRESH_MODE
        ,iconimage=utils.refresh_icon 
        ,Folder=False 
        )
    
    try:
        listhtml = utils.getHtml(url)
    except:
        return None

    json_playlist = json.loads(listhtml)['rdata']

    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ... 
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
    #Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    # ... schema which I don't want [errors during sorting]
    del json_playlist[0] 

    #sort so that top camscore is on top
    entries = sorted(json_playlist, reverse=True, key=lambda camscore: camscore[camscore_index])

    #add list items...
    for playItem in entries:
        if playItem[vs_index] == 0: #only show model in public chat

            serv_number = playItem[camserv_index]
            if Is_new_server(serv_number):
                server439hack = "_a"
                name_hq_prefix = "[COLOR {}]HQ[/COLOR] ".format(utils.time_text_color)
            else:
                server439hack = ""
                name_hq_prefix = ""

            #normalizeServer will return a string such as video1234;
            #I only want to return the 1234 portion
            norm_serv_number = int(filter(str.isdigit,   str(NormalizeServerNumber(serv_number)) )) 

            thumb = "https://snap.mfcimg.com/snapimg/{}/320x240/mfc{}_{}".format( \
                norm_serv_number, \
                server439hack, \
                NormalizeChannelID(playItem[uid_index]))

            camscore = str(int(playItem[camscore_index]))

            label = name_hq_prefix + playItem[name_index]
            url = playItem[name_index]
            utils.addDownLink(
                name = label
                , url = url
                , mode = PLAY_MODE
                , iconimage = thumb
                , duration=str(int(camscore))
                , bitrate='fmproxy'
                )
                            

    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

def NormalizeChannelID(uid, platform_id=FCUOPT_PLATFORM_MFC):
    if not isinstance(uid, int):  return 0
    uid = int(uid)
    if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
        return uid + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
    else:
        return uid + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download'])
def Playvid(url, name, playmode_string = '', download = False):

    Log ("Playvid url='{}' name='{}' playmode_string='{}' download='{}'".format(url, name, playmode_string, download), xbmc.LOGNONE  )

    #return
    videourl = myfreecam_start(url)
    if not videourl:
        Log('Couldn\'t find a playable webcam link')
        return

    normServerNumber = NormalizeServerNumber(CAMGIRLSERVER)
    
    iconimage = xbmc.getInfoImage("ListItem.Thumb")

    listitem = xbmcgui.ListItem(path=videourl)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})

    #allow playmode to be forced by input command, or use default from addon settings
    if playmode_string == 'fmproxy':
        playmode = 1
    elif playmode_string == 'rtmp':
        playmode = 2
    elif playmode_string == 'inputstream':
        playmode = 3
    else:
        playmode = int(utils.addon.getSetting('chatplay'))
    if download == True:
        playmode = 1 #force this mode to capture
    
    if playmode == 22: #rtmp

        if not Is_new_server(CAMGIRLSERVER):
            #CXID = "838299700"
            CTXENC = 'fake/fake'
            TKX = 'fake'
            flash_helper = 'https://www.myfreecams.com/flash/Video181015.swf'
            serv, respkey, stype, opts = getRespkey('') #populates value for CXID
        else:
            flash_helper = 'https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152'
        try:
            Log(CAMGIRLSERVER)
            Log(CAMGIRLCHANID)
            Log(CAMGIRLUID)
            Log(CAMGIRL)
            Log(CXID)
            Log(CTXENC)
            Log(CTXENC.split('/')[1] )
            Log(TKX)
            Log(PLATFORM_ID)
        except:
            pass



        #    serv, respkey, stype, opts = getRespkey('') #populates value for CXID
            
        #https://forum.kodi.tv/showthread.php?tid=93280
        #listitem.setProperty("SWFPlayer", "https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152")
        #listitem.setProperty("swfUrl", "https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152")
##        listitem.setProperty("server", "{}".format(normServerNumber) ) #"video2003")
##        listitem.setProperty("state", "90")
##        listitem.setProperty("videoPrefix", "video")
##        listitem.setProperty("sessionID", str(CXID)) #"838299700")
##        listitem.setProperty("roomID", str(CAMGIRLCHANID) ) #"120642838")
##        listitem.setProperty("password", str(TKX) ) # "851b61c5da")
##        listitem.setProperty("vidctx", str(CTXENC.split('/')[1]) )#"WzgzODI5OTcwMCwwLDEsMCwwLDAsMCw1MTY3Mjc1XQ==")
##        listitem.setProperty("ngx", "true")
##        listitem.setProperty("phase", "a")
##        listitem.setProperty("mode", "DOWNLOAD")
##        listitem.setProperty("truepvt", "0")
##        listitem.setProperty("platformID", str(PLATFORM_ID) ) #"1")
##        listitem.setProperty("modelID", str(CAMGIRLUID) ) #"20642838")

        #listitem.setProperty("app", "NxServer")
        #listitem.setProperty("pageUrl", "https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=1550272065&target=main")
        #listitem.setProperty("playpath", "mfc_a_{}?ctx={}&tkx={}\"".format(CAMGIRLCHANID, str(CTXENC.split('/')[1]), TKX) )
           
        videourl = "rtmp://{}.myfreecams.com:1935/NxServer".format(normServerNumber)
        videourl += " app=NxServer"
        videourl += " swfUrl=" + flash_helper
        videourl += " tcUrl=rtmp://{}.myfreecams.com:1935/NxServer".format(normServerNumber)
##app: NxServer
##flashVer: WIN 32,0,0,144
##swfUrl: https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152

#pageUrl=https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=1560185776&target=main

        import time
        vcc = int(time.time())

        videourl += " pageUrl=https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc={}&target=main".format(vcc)

##pageUrl: https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=1550272065&target=main
##Playpath: mfc_a_126658261?ctx=Wzg1ODAwMDE1OCwwLDEsMCwwLDAsMCw1MTY3ODA3XQ==&tkx=3b8229a8da
        #videourl += " playPath=mfc_a_{}?ctx={}&tkx={}".format(CAMGIRLCHANID, str(CTXENC.split('/')[1]), TKX  )

        #videourl += " objectEncoding=0"

        videourl += " conn=N:{}".format(str(CXID)) #sessionid
        if not TKX == 'fake':
            videourl += " conn=S:{}".format(str(TKX))
        else:
            videourl += " conn=S:{}".format('')
        
        videourl += " conn=S:{}".format(str(CAMGIRLCHANID)) 
#            videourl += " conn=S:{}".format("a")
        videourl += " conn=S:{}".format("DOWNLOAD")        
        videourl += " conn=N:{}".format(CAMGIRLUID)
        videourl += " conn=N:0"
        if not TKX == 'fake':
            videourl += " conn=S:{}".format(str(CTXENC.split('/')[1]))
        else:
            videourl += " conn=S:{}".format('')


        #videourl += " flashVer=\"WIN 32,0,0,207\""
        videourl += " flashVer=WIN\\2032,0,0,207"

        #videourl += " playlist=1"
        #videourl += " buffer=1000"
        #videourl += " start=1"
        #videourl += " playlist=1"
        videourl += " swfVfy=true"
        videourl += " live=true"
        videourl += " playpath=mp4:mfc_{}.f4v".format(CAMGIRLCHANID)
        #videourl += " subscribe=mp4:mfc_{}.f4v".format(CAMGIRLCHANID)

        


        videourl += " startDownload={}".format(str(CAMGIRLCHANID))
        
        xbmc.Player().play(videourl)
        return
        
##Processing connect
##app: NxServer
##flashVer: WIN 32,0,0,144
##swfUrl: https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152
##ERROR: HTTP_get, TLS_Connect failed
##ERROR: RTMP_HashSWF: connection lost while downloading swfurl https://www.myfreecams.com/flash/MfcVideoNg-1080p-20180424.swf?nc=152
##tcUrl: rtmp://video2011.myfreecams.com:1935/NxServer
##pageUrl: https://www.myfreecams.com/_html/player.html?broadcaster_id=0&vcc=1550272065&target=main
##Playpath: mfc_a_126658261?ctx=Wzg1ODAwMDE1OCwwLDEsMCwwLDAsMCw1MTY3ODA3XQ==&tkx=3b8229a8da
##Saving as: mfc_a_126658261
##INFO: Metadata:
##INFO:   Server                NGINX RTMP fcs-dev 0.180628
##INFO:   width                 1280.00
##INFO:   height                720.00
##INFO:   displayWidth          1280.00
##INFO:   displayHeight         720.00
##INFO:   duration              0.00
##INFO:   framerate             30.00
##INFO:   fps                   30.00
##INFO:   videodatarate         2500.00
##INFO:   videocodecid          0.00
##INFO:   audiodatarate         160.00
##INFO:   audiocodecid          0.00
##INFO:   profile
##INFO:   level
##INFO:   fcsid                 87e53e42-320e-11e9-8dd6-509a4c68a9be
##Playpath: mfc_a_126658261?ctx=Wzg1ODAwMDE1OCwwLDEsMCwwLDAsMCw1MTY3ODA3XQ==&tkx=3b8229a8da
##Saving as: mfc_a_12665826101

##        streamserver = "rtmp://%s/live-edge"%(flv_info[2])
##        modelname = flv_info[1]
##        username = flv_info[8]
##        #utils.Log(flv_info[12].decode(), xbmc.LOGNONE)
##        #utils.Log(flv_info[12].encode('utf8'), xbmc.LOGNONE)
##        #utils.Log(flv_info[12].replace('\u0022', '"'), xbmc.LOGNONE)
##        password = urllib.unquote(flv_info[12].replace('\u0022', '"'))
##        unknown = flv_info[13]
##        swfurl = "https://chaturbate.com/static/flash/CBV_2p690.swf"
##        swfurl = "https://chaturbate.com" + flv_info[0]
##
##        #utils.Log(swfurl, xbmc.LOGNONE)
##        #utils.Log(streamserver, xbmc.LOGNONE)
##        #utils.Log(modelname, xbmc.LOGNONE)
##        #utils.Log(password, xbmc.LOGNONE)
##        #utils.Log(username, xbmc.LOGNONE)
##        
##        
##        videourl = "{} app=live-edge swfUrl={} tcUrl={}"\
##                   .format( streamserver, swfurl, streamserver )
##        videourl += " pageUrl=https://chaturbate.com/{}/ conn=S:AnonymousUser"\
##                    .format(modelname)
##        videourl += " conn=S:{} conn=S:2.690 conn=S:{}"\
##                    .format(modelname ,username)
##        videourl += " conn=S:{} playpath=mp4".format(password)
##        utils.Log(videourl)
##<embed wmode="transparent" 
##src="/flash/MfcVideoNg-1080p-20180424.swf?nc=152" swliveconnect="true" quality="high" 
##flashvars="&amp;server=video2011
##&amp;state=90
##&amp;videoPrefix=video
##&amp;sessionID=857533566
##&amp;roomID=126658261
##&amp;password=a887226b6a
##&amp;vidctx=Wzg1NzUzMzU2NiwwLDEsMCwwLDAsMCw1MTY3Nzk1XQ%3D%3D
##&amp;ngx=true
##&amp;phase=a
##&amp;mode=DOWNLOAD&amp;truepvt=0&amp;platformID=1
##&amp;modelID=26658261" bgcolor="#000000" width="480" height="270" id="fvideo_ff" name="fvideo" 
       
    elif  videourl.endswith('.mpd') or playmode == 3: # Inputstream
        utils.Log("videourl mpd='{}'".format(videourl), xbmc.LOGNONE)
        is_helper = inputstreamhelper.Helper('mpd')
        listitem.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        listitem.setProperty('inputstream.adaptive.stream_headers', utils.Header2pipestring(utils.headers).replace("|", '') + \
                             '&Origin=https://www.myfreecams.com&Referer=https://www.myfreecams.com/_html/player.html?broadcaster_id=0')
        
        if  videourl.endswith('.mpd'):
            listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        else:
            Log ("HLS:'.mpd') or ('.m3u8'")
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')

        if not '|' in videourl: videourl = videourl + utils.Header2pipestring()

            
    else:
        Log ("not .mpd")

        if playmode == 1: # F4mProxy
            m3u8stream = "{}{}".format(videourl, utils.Header2pipestring() )
            utils.Log("fmproxy m3u8stream='{}' {}".format(m3u8stream, int(utils.addon.getSetting('max_bit_rate'))*1000*1000), xbmc.LOGNONE)
            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            if download == True:

##                if "[/COLOR]" in name:
##                    n1 = name.split("[/COLOR]")
##                    if n1[1] == '': name = n1[0]
##                    else: name = n1[1]
##                    if "[COLOR" in name:
##                        name = name.split("[COLOR")[0]
##                    name = name.strip(' ')
                name = name.strip()
                name_regex = "(?:\[color\s*\w*\]|)([A-Za-z0-9_\-\. ]+)(?:\[\/color\s*\]|)"
                name = re.compile(name_regex, re.DOTALL | re.IGNORECASE).findall(name)[0]
                name = name.strip()
                download_path = utils.addon.getSetting("download_path").lower()
                download_path = download_path + name + datetime.datetime.now().strftime(".%Y-%m-%d") + '.mp4'
                Log("download_path='{}'".format(download_path))
            else:
                download_path = None

            f4mp.playF4mLink(
                m3u8stream
                , name
                , proxy = None
                , use_proxy_for_chunks = False
                , maxbitrate = int(utils.addon.getSetting('max_bit_rate'))*1000*1000
                , simpleDownloader = False
                , auth = None
                , streamtype = 'HLSREDIR'
                , setResolved = False
                , swf = None
                , callbackpath = ""
                , callbackparam = ""
                , iconImage = iconimage
                , download_path = download_path
                )
            #, download_path='c:\\temp\\Swish Swish (Ft. Nicki Minaj) - Katy Perry.ts'
            return
        

    if not playmode == 2: #rtmp
        if not '|' in videourl: videourl = videourl + utils.Header2pipestring()
            
    if int(sys.argv[1]) == -1:
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        pl.add(videourl, listitem)
        xbmc.Player().play(pl)
    else:
        xbmcplugin.setResolvedUrl( utils.addon_handle , True, listitem)


def valid_info():
    if CAMGIRLSERVER < 0 :
        Log('valid_info: missing camgirlserver')
        return False
    if CAMGIRLCHANID < 0:
        Log('valid_info: missing CAMGIRLCHANID')
        return False
    if CAMGIRLUID < 0:
        Log('valid_info: missing CAMGIRLUID')
        return False
    if not CAMGIRL:
        Log('valid_info: missing CAMGIRL')
        return False
    if not CXID:
        Log('valid_info: missing CXID')
        #return False
    if not CTXENC:
        Log('valid_info: missing CTXENC')
        #return False
    if not TKX:
        Log('valid_info: missing TKX')
        #return False
    if not PLATFORM_ID:
        Log('valid_info: missing PLATFORM_ID')
        return False

    return True
    
def fc_decode_json(m):
    try:
        m = m.replace('\r', '\\r').replace('\n', '\\n')
        return simplejson.loads(m[m.find("{"):].decode("utf-8","ignore"))
    except:
        return simplejson.loads("{\"lv\":0}")

def read_model_data(m, camgirl_to_find):
    global CAMGIRLSERVER
    global CAMGIRLCHANID
    global CAMGIRLUID
    global CAMGIRL
    global PLATFORM_ID

    msg = fc_decode_json(m)
    Log( "msg:%s" % simplejson.dumps(msg) )

    try:
        if msg['uid'] == 0:
            return # these lines don't have any more useful information    
    except:
        pass

    try:
        if msg['uid'] == camgirl_to_find:
            Log( "uid:%s" % camgirl_to_find, xbmc.LOGERROR )
            
    except:
        return
    
    try:
        if camgirl_to_find == msg['nm'].lower():
            CAMGIRL = msg['nm'] #make sure we know who we are talking to:  'nm' can exist multiple places
    except:
        return
    
    if CAMGIRL:

        #vs = visibility status; 0 value means in public chat...don't know how to parse group/private chats
        vs = msg['vs']
        if not (vs == 0):
            vs_string=vs_str[vs]
            utils.notify(msg="{} is {}".format(CAMGIRL, vs_string) )
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            CAMGIRLCHANID = -1
            CAMGIRLUID = -1
            return

        try:
            CAMGIRLUID    = msg['uid']
            PLATFORM_ID   = msg['pid']
            if PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
                CAMGIRLCHANID = msg['uid'] + 400000000  #1e8 means public chat; there is also 2e8 and 4e8
            else:
                CAMGIRLCHANID = msg['uid'] + 100000000  #1e8 means public chat; there is also 2e8 and 4e8
        except:
            pass

        u_info=msg['u']
        try:
            CAMGIRLSERVER = u_info['camserv']
        except KeyError:
            CAMGIRLSERVER = -1 #make sure we not None so that the validation works
            CXID = -1
            CTXENC = -1
            TKX = -1
            pass
        except Exception, e:
            #Log(('parsing msg dictionary for name:%s' % str(e) ), xbmc.LOGERROR)
            pass

def millitime():
    return int(time.time()) * 1000


def getServerList():
    global serverList

    if serverList:
        return serverList
    #connect to one of the chat servers; random since we don't know how to parse page
    #we need to use 8080 because the other choice, https, does not work with websocket
    url="https://m.myfreecams.com/configproxy.php".format(random.random())
    try:
        listhtml = utils.getHtml(url)
    except:
        traceback.print_exc()
        return None

    serverList = simplejson.loads(listhtml)
    return serverList

def chatserverList():
    return getServerList()['chat_servers']

def h5videoserverList():
    return getServerList()['h5video_servers']

def ngvideoserverList():
    return getServerList()['ngvideo_servers']

def wzvideoserverList():
    return getServerList()['wzobs_servers']



def NormalizeServerNumber(server):
    result_server = server
    try:
        result_server = ngvideoserverList()[str(server)]
    except:
        try:
            result_server = h5videoserverList()[str(server)]
        except:
            try:
                result_server = wzvideoserverList()[str(server)]
            except:
                result_server = 'video' + str(server)

    return result_server

def getChatServerWebsocket_test(login_version='20080910'):

    global SESSION_ID
    global CXID
    global CTXENC
    global TKX
    global SERV
    global RESPKEY
    global STYPE
    global OPTS
    
##    #internal chat server list
##    #acutal list at https://m.myfreecams.com/configproxy.php
##    xchat=[
##        20, 22, 23, 24, 25, 28, 29,
##        30, 31, 32, 33, 34, 35, 36, 39,
##        42, 43, 44, 45, 46, 47, 48, 49,
##        50, 51, 52, 53, 54, 58, 59, 
##        60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
##        70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
##        80, 81, 83, 84, 85, 86, 87, 88, 89,
##        90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
##        100, 101, 102, 103, 104, 105, 106, 109,
##        111, 112, 113, 114, 115, 116, 118, 119,
##        120, 121, 122, 123, 124, 125, 126, 127
##      ]

##    #connect to one of the chat servers; random since we don't know how to parse page
##    #we need to use 8080 because the other choice, https, does not work with websocket
##    url="https://m.myfreecams.com/configproxy.php".format(random.random())
##    try:
##        listhtml = utils.getHtml(url)
##    except:
##        traceback.print_exc()
##        return None

    #xchat = simplejson.loads(listhtml)['chat_servers']
    xchat = chatserverList()

    sock_buf=None
    ws = None
    failed_count = 0
    failed_count_max = 12
    while not ws and (failed_count < failed_count_max):
        try: 
            #server_number = str(random.choice(xchat))
            #host = "ws://xchat"+server_number+".myfreecams.com:8080/fcsl"
            #host = "wss://xchat"+server_number+".myfreecams.com/fcsl"
            

            FCTYPE_EXTDATA = 81
            FCTYPE_LOGIN = 1
            
            url="https://api.myfreecams.com/dc?nc={}&site=mobileweb".format(random.random())
            try:
                start_time = millitime()
                listhtml = utils.getHtml(url)
                stop_time = millitime()
            except:
                try:
                    listhtml = utils.getHtml(url)
                    stop_time = millitime()
                except:
                    raise

            temp_cid = simplejson.loads(listhtml)['result']['cid']

            temp_key = simplejson.loads(listhtml)['result']['key']
            temp_time = int(simplejson.loads(listhtml)['result']['time'])

            socket_message_1 = "{} 0 0 {} 0 ".format(FCTYPE_LOGIN, FCTYPE_EXTDATA)
            
            socket_message_2 = '"err":0,"start":{},"stop":{},"a":9841,"time":{},"key":"{}","cid":"{}","pid":{},"site":"mobileweb"'.format( \
                       start_time, stop_time, temp_time, temp_key, temp_cid, FCUOPT_PLATFORM_MFC)
            socket_message_2 = '{'+socket_message_2+'}'
            socket_message_2=urllib.quote(socket_message_2)
            socket_message = socket_message_1 + socket_message_2


            ws = None
            while not ws and (failed_count < failed_count_max):
                try:
                    failed_count += 1
                    ws = websocket.WebSocket()
                    host = "wss://{}.myfreecams.com/fcsl".format(random.choice(xchat))
                    Log("connecting to host '{}'".format(host) )
                    ws = websocket.create_connection(host)
                except:
                    #traceback.print_exc()
                    time.sleep(0.1)
                    ws = None

            time.sleep(1)
            ws.send("fcsws_20180422\n\0")
            ws.send(socket_message + "\n\0")
            
            sock_buf=None
            sock_buf = ws.recv()
            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            temp_login_id = hdr.group(6)

            socket_message = "{} 0 0 {} 0 {}@guest:guest".format(FCTYPE_LOGIN, login_version, temp_login_id)
            ws.send(socket_message + "\n\0" )

            sock_buf=None
            quitting = 0
            fc = None
            readcount = 0
            while quitting == 0:
                sock_buf = ws.recv()
                readcount = readcount+1
                if readcount > 20: break #infinite loop detection
                while True:
                    hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
                    fc = hdr.group(1)
                    #first six bytes of fc tells us size of message
                    #rest of bytes in fc is the fc message type
                    mlen   = int(fc[0:6])# characters from position 0 (included) to 6 (excluded)
                    msg=sock_buf[6:6+mlen] 
                    if len(msg) < mlen:
                        Log("len(msg) {} < mlen {}".format(len(msg), mlen))

                    FCTYPE_MODELGROUP = 33
                    FCTYPE_TKX = 30

                    msg = fc_decode_json(urllib.unquote(msg))

                    try:
                        CXID = msg['cxid']
                        CTXENC = urllib2.unquote(msg['ctxenc'])
                        TKX = msg['tkx']
                        Log( "CxID={}".format(CXID) )
                        break # these lines don't have any more useful information
                    except:
                        pass
            
                    try:
                        uid = int(msg['uid'])
                        if uid == 0:
                            SESSION_ID = msg['sid']
                            Log( "GuestID={}".format(msg['nm']) )
                        quitting = 1 #all necessary info should be here by now
                        break # these lines don't have any more useful information
                    except:
                        pass
            
                    try:
                        if not SERV: #these variables are sent twice differently - we only need the first
                            SERV = msg['serv']
                            RESPKEY = msg['respkey']
                            STYPE = msg['type']
                            OPTS = msg['opts']
                            break # these lines don't have any more useful information
                        #return serv, respkey, stype, opts
                    except:
                        pass

                    sock_buf=sock_buf[6+mlen:]
                    if len(sock_buf) == 0:
                        break

        except Exception, e:
            failed_count += 1
            Log("xchat server '{}' could not be opened [{}]".format(repr(e), failed_count))
            ws = None


    return ws
    
def getRespkey(camgirl_to_find=''):

    if not SERV:
        ws = getChatServerWebsocket_test()
        if ws:
            ws.close()

    return SERV,RESPKEY,STYPE,OPTS

def getCamgirlList():
    Log("\n getCamgirlList {} \n".format(''))
    #return json-like list of online models
    serv, respkey, stype, opts = getRespkey()
    url = "https://www.myfreecams.com/php/FcwExtResp.php?respkey={}&type={}&opts={}&serv={}&nc={}&_={}".format(
        respkey, stype, opts, serv, random.random(), time.time() )

    try:
        listhtml = utils.getHtml(url)
    except:
        return None

    return json.loads(listhtml)['rdata'] 

def getCamgirlInfo(camgirl_to_find, json_playlist):
    #Log("\n getCamgirlInfo [{},{}] \n".format(camgirl_to_find, json_playlist[0]))

    if not json_playlist:
        return None, None, None, None

    # the first entry is a schema ...
    #numbers are the only way I can use the vendor's array  ... 
    camscore_index = arrayPositionForKeyname(json_playlist[0], 'camscore')
    name_index = arrayPositionForKeyname(json_playlist[0], 'nm')
    uid_index = arrayPositionForKeyname(json_playlist[0], 'uid')
    camserv_index = arrayPositionForKeyname(json_playlist[0], 'camserv')
    vs_index = arrayPositionForKeyname(json_playlist[0], 'vs')
    #Log("vs_index:{} camscore_index:{} name_index:{} uid_index:{} camserv_index:{}".format(vs_index, camscore_index,name_index,uid_index,camserv_index))

    #del json_playlist[0] #we may not delte this entry because variable is by reference and future calls may need it
    
    key = camgirl_to_find #'HotAnnelisse'
    for item in json_playlist:
        if item[name_index] == key:
            Log("\n getCamgirlInfo [{},{}] \n".format(camgirl_to_find, repr(item)))
            if item[vs_index] !=0:  #return null if not online
                return None, None, None, None
            
            camserv = int(item[camserv_index])
            is_new_server  = Is_new_server(camserv)

            #normalizeServer will return a string such as video1234;
            #I only want to return the 1234 portion
            camserv = int(filter(str.isdigit,   str(NormalizeServerNumber(camserv)) )) 

            camscore = int(item[camscore_index])

            uid = NormalizeChannelID(item[uid_index])
            Log("\n getCamgirlInfo returning [{},{},{},{}] \n".format(key, camserv, uid, is_new_server  ))
            return camserv, uid, is_new_server, camscore
            break

    return None, None, None, None

def Is_new_server(camserv):
    #corresponds to "onWzObsVideoServer" json information that we may need to start parsing

    try:
        
        server = ngvideoserverList()[str(camserv)]
        #log ("return Is_new_server = true")
        return True
    except:
        try:
            server = wzvideoserverList()[str(camserv)]
            #log ("return Is_new_server = true")
            return True
        except:
            #log ("return Is_new_server = false")
            return False

    return    (camserv in range(545,559))        \
                        or (camserv in range(437,440))  \
                        or (camserv in range(888,897))  
    

def myfreecam_start(camgirl_to_find):

#getCamgirlInfo returning [ChillANNout,548,129724868,True]
#                                             getCamgirlInfo [ChillANNout,[u'ChillANNout', 760339032, 29724868, 0, 1, 4, 1554, u'a', u'FF0000', 31, 1, 1538427081, 1, 1, 1, u'One day a week im just being myself,the rest of the week-restoring reputation.', 0, 0, 7183.8, u'EU', 343072, 98, 89, u'check%20my%20hair.7%20if%20im%20cute%2C88%20love%2C999%20snap%2C666%20shot%2C333%20black%20jack%2C150%20pm%2C140%204%20spanks%2C4444%20happy', 0]]
#    camgirl_to_find = '29724868'
    camgirl_to_find = camgirl_to_find.lower()
    
    Log("\n myfreecam_start [{}] \n".format(camgirl_to_find))

    ws = None
    attempts = 0
    max_attempts = 2
    while (not ws) and (attempts < max_attempts):
        #ws = getChatServerWebsocket_test('20071025')
        ws = getChatServerWebsocket_test('20180422')
        #ws = getChatServerWebsocket()
        time.sleep(1)
        attempts = attempts + 1
        Log ("attempt to getChatServerWebsocket")

    if not ws:
        utils.notify( "Failed to get websocket connection.  Check internet connection or try later")
        return ''
    
    rembuf=""
    quitting = 0
    readcount = 0

    websocket_search_command = "10 {} 0 {} 0 {}".format(SESSION_ID, int(time.time()), camgirl_to_find)
    Log("websocket_search_command=" + websocket_search_command)
    ws.send(websocket_search_command+"\n\0")

    MESSAGE_FIELD_LENGTH = 6 #for 2018 messages
    #MESSAGE_FIELD_LENGTH = 4 #for 2017 messages
    while quitting == 0:
        
        readcount = readcount + 1
        if readcount > MAX_READ_COUNT:
            #Log ("readcount > MAX_READ_COUNT")
            break

        sock_buf =  ws.recv()
        sock_buf = rembuf + sock_buf
        
        rembuf=""
        while True:
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX
            Log("rawsock_buf:%s"%sock_buf)

            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            if bool(hdr) == 0:
                #Log ("bool(hdr) == 0:")
                quitting=1
                break #recv() again for the response we need

            fc = hdr.group(1)
            mlen   = int(fc[0:MESSAGE_FIELD_LENGTH])

            FCRESPONSE_SUCCESS = 0
            FCRESPONSE_ERROR = 1
            if int(hdr.group(5)) == FCRESPONSE_ERROR:
                utils.Notify(msg="'{}' renamed or deleted".format(camgirl_to_find))
                quitting=1
                break

            msg=sock_buf[MESSAGE_FIELD_LENGTH:MESSAGE_FIELD_LENGTH+mlen]
            if len(msg) < mlen:
                rembuf=''.join(sock_buf)
                #Log ("len(msg) < mlen")
                break

            read_model_data( urllib.unquote(msg) , camgirl_to_find) 

            if valid_info():
                quitting=1
                break

            if CAMGIRLSERVER == -1:
                quitting=1
                break

                sock_buf=sock_buf[MESSAGE_FIELD_LENGTH+mlen:]
            if len(sock_buf) == 0:
                #log ("len(sock_buf) == 0:")
                break

    ws.close()

    if readcount > MAX_READ_COUNT:
        utils.notify(msg= "{} was not found.  Maybe renamed".format(camgirl_to_find), duration=10000, sound=False)
        return ''
    
    if not valid_info() or (CAMGIRLSERVER < 1) :
        #utils.notify( msg = ("{} is not online".format(camgirl_to_find)) )
        return ''

    try:

        head = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"

        if Is_new_server(CAMGIRLSERVER):
            serv, respkey, stype, opts = getRespkey('') #populates value for CXID
            
            #try new servers
            Url="https://{}.myfreecams.com:8444/x-hls/{}/{}/{}/mfc_a_{}.m3u8{}".format(
                NormalizeServerNumber(CAMGIRLSERVER)
                , CXID
                , CAMGIRLCHANID
                , urllib.quote(CTXENC)
                , CAMGIRLCHANID
                , "?nc="+str(random.random())
                ) 
            Log('attempt connecting to HLS host {}|User-Agent={}'.format(Url,head))
            req = urllib2.Request(Url)
            req.add_header('User-Agent', head)
            try:
                aa = urllib2.urlopen(req, timeout=10)
                Url = Url +('|user-agent='+head)
                Log('returning URL ' + Url)
                #utils.notify(msg= "{} is HQ".format(camgirl_to_find), duration=10000, sound=False)
                return Url
            except Exception, e:
                Log("exception '{}' opening url '{}' ".format(repr(e),Url))
                #utils.notify( 'Oh oh', ("URL for {} is not responding".format(CAMGIRL)))
                Url = ''


        #mobile site
        #Url="http://video"+str(CAMGIRLSERVER)+".myfreecams.com:1935/NxServer/ngrp:mfc_"+str(CAMGIRLCHANID)+".f4v_mobile/playlist.m3u8" 
        if Is_new_server(CAMGIRLSERVER):
            server439hack = "_a"
        else:
            server439hack = ""

        if PLATFORM_ID == FCUOPT_PLATFORM_MFC:
            if ADDON.getSetting('use_mobile_stream').lower() == "true":
                Url = "https://{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_mobile/playlist.m3u8".format( \
                    NormalizeServerNumber(CAMGIRLSERVER),server439hack,CAMGIRLCHANID)
            else:
                Url = "https://{}.myfreecams.com/NxServer/ngrp:mfc{}_{}.f4v_desktop/manifest.mpd".format( \
                    NormalizeServerNumber(CAMGIRLSERVER),server439hack,CAMGIRLCHANID)
        elif PLATFORM_ID == FCUOPT_PLATFORM_CAMYOU:
            Url="https://{}.camyou.com/NxServer/ngrp:cam_{}.f4v_desktop/manifest.mpd".format( \
                NormalizeServerNumber(CAMGIRLSERVER),CAMGIRLCHANID)


        Log('attempt connecting to host {}|{}'.format(Url,head))
        req = urllib2.Request(Url)
        req.add_header('User-Agent', head)
        try:
            aa = urllib2.urlopen(req, timeout=15)
            return Url
        except Exception, e:
            Log("exception '{}' opening url '{}' ".format(repr(e),Url))


        if Url == '':
            utils.notify( 'Oh oh', ("URL for {} is not responding".format(camgirl_to_find)))
                    
    except Exception, e:
        Log(('attempt connecting to err:%s' % str(e) ), xbmc.LOGERROR)
        return ''

    utils.notify( msg = ("{} is not online".format(camgirl_to_find)))
    return Url

#__________________________________________________________________________
#

@utils.url_dispatcher.register(REFRESH_MODE)
def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".mfcimg.com")
            if showdialog==True:
                utils.notify('Finished','Images cleared')
    except:
        pass

    if showdialog==True:
        xbmc.executebuiltin('Container.Refresh')
    
#__________________________________________________________________________
#
