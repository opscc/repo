'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "http://www.absoluporn.com"

SEARCH_URL = ROOT_URL + '/en/search-{}-1.html'

URL_CATEGORIES = ROOT_URL + '/en'
URL_TOP_RATED = ROOT_URL + '/en/wall-note-1.html'
URL_MOST_VIEWED = ROOT_URL + '/en/wall-main-1.html'
URL_LONGEST = ROOT_URL + '/en/wall-time-1.html'
URL_RECENT = ROOT_URL + '/en/wall-date-1.html'

MAIN_MODE = '300'
LIST_MODE =  '301'
PLAY_MODE = '302'
CATEGORIES_MODE = '303'
SEARCH_MODE = '304'
CHANNELS_MODE = '305'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Top Rated[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_TOP_RATED
        ,mode=LIST_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True
        )

    utils.addDir(name="{}[COLOR {}]Most Viewed[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_MOST_VIEWED
        ,mode=LIST_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True
        )

    utils.addDir(name="{}[COLOR {}]Longest[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_LONGEST
        ,mode=LIST_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True
        )

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True
        )
    
    List(URL_RECENT, end_directory=True)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    listhtml = utils.getHtml(url, '')

    video_region = listhtml.split('class="bloc-menu-centre')[1]
    video_region = video_region.split('<script>')[0]
 
    regex = 'thumb-main-titre"><a href="..([^"]+)".*?title="([^"]+)".*?src="([^"]+)".*?<div class="thumb-info">(.*?)time">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, hd, duration in info:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        videourl = videourl.replace(" ","%20")
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration
            , noDownload=False)
        

    next_page_html = listhtml.split('<div class="bloc-thumb">')[0]
    next_page_regex = '<span class="text16">.+?href="..([^"]+)".+?>([^<]+)<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url, np_number in np_info:
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_number = int(np_number)
            #if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            np_url=np_url.replace(" ","%20")
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
            else:
                utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    List(np_url, end_directory)
                else:
                    utils.add_sort_method()
                    utils.endOfDirectory()

    if  end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Play(url, name, download=None):
    videopage = utils.getHtml(url, '')
    servervideo = re.compile("servervideo = '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    vpath = re.compile("path = '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    repp = re.compile(r"repp = '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    filee = re.compile("filee = '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    videourl = servervideo + vpath + repp + filee
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):

    all_html = utils.getHtml(url, '')

    cat_html = all_html.split('class="pvicon-categorie"')[1]
    cat_html = cat_html.split('>All tags<')[0]

#&nbsp;&nbsp;<a href="../en/wall-31-1.html" class="link1b">Amateur</a>&nbsp;

    regex = 'href="..([^"]+)".+?>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cat_html)
    Log("info='{}'".format(info))
    for url, label in info:
        if url.startswith('/'): url = ROOT_URL + url
        Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )

    utils.add_sort_method()
    utils.endOfDirectory()
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    Log("url='{}'".format(url))
    Log("end_directory='{}'".format(end_directory))
    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False #used when testing multipagesearch

    title = keyword.replace(' ','%20')
    searchUrl = searchUrl.format(title)
    Log("searchUrl='{}'".format(searchUrl))
    List(searchUrl, end_directory)

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=True #used when testing multipagesearch
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
