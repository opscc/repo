'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES =  ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 10

ROOT_URL = "https://www.freeomovie.com"
SEARCH_URL = ROOT_URL + '/?s='
URL_CATEGORIES = ROOT_URL

MAIN_MODE = '370'
LIST_MODE =  '371'
PLAY_MODE = '372'
CAT_MODE = '373'
SEARCH_MODE = '374'


@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    #utils.addDir('[COLOR hotpink]Categories[/COLOR]','http://www.freeomovie.com/', CAT_MODE, '', '')
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CAT_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True 
        )

    List(ROOT_URL)

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    #utils.addDir('[COLOR hotpink]Search[/COLOR]','http://www.freeomovie.com/?s=', SEARCH_MODE, '', '')
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    listhtml = utils.getHtml(url, url)

    regex = '<h2><a href="([^"]+)".*?title="([^"]+)">.+?<img src="([^"]+)".+? width="'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for url, label, thumb in info:
        label = utils.cleantext(label)
        #Log("label={}".format(label))
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = url 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , noDownload=False)
        
##    match = re.compile('<h2><a href="([^"]+)".*?title="([^"]+)">.+?<img src="([^"]+)".+? width="', re.DOTALL).findall(listhtml)
##    for videopage, name, img in match:
##        name = utils.cleantext(name)
##        img = img.replace('/i/','/t/')
##        utils.addDownLink(name, videopage, PLAY_MODE, img, '')

##    try:
##        nextp = re.compile('<span class=\'current\'>.+?</span><a class="page larger" href="([^"]+)"').findall(listhtml)
##        utils.addDir('Next Page', nextp[0], LIST_MODE,'')
##    except: pass
##    xbmcplugin.endOfDirectory(utils.addon_handle)
    next_page_regex = "class=\"nextpostslink\".+?href=\"([^\"]+)\""
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        #Log("np_info={}".format(np_info))
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            np_number = '' #page number can be multiple places depending if search result or not
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if not np_number.isdigit(): np_number=np_url.split('/')[6]
            if not np_number.isdigit(): np_number=np_url.split('/')[7]
            
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
                utils.add_sort_method()
                utils.endOfDirectory()
            else:
                utils.Notify(msg=np_url, duration=500)  #let user know something is happening
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    List(np_url, end_directory)
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

##@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword'])     
##def Search(url, keyword=None):
##    searchUrl = url
##    if not keyword:
##        utils.searchDir(url, SEARCH_MODE)
##    else:
##        title = keyword.replace(' ','+')
##        searchUrl = searchUrl + title
##        print "Searching URL: " + searchUrl
##        List(searchUrl)

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):

    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    #end_directory=False #used when testing multipagesearch
    
    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(searchUrl, end_directory)

    #end_directory=True #used when testing multipagesearch
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        

##@utils.url_dispatcher.register(CAT_MODE, ['url']) 
##def Cat(url):
##    listhtml = utils.getHtml(url, '')
##    match = re.compile('<li><a href="([^"]+)" rel="tag">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
##    for catpage, name in match:
##        name = utils.cleantext(name)
##        utils.addDir(name, catpage, LIST_MODE, '', '')
##    xbmcplugin.endOfDirectory(utils.addon_handle)
@utils.url_dispatcher.register(CAT_MODE, ['url'])
def Categories(url):
    html = utils.getHtml(url, '')

    regex = "\"cat-item.+?href=\"([^\"]+)\".+?>([^<]+)<"
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    Log("info='{}'".format(info))
    for url, label in info:
        #if url.startswith('/'): url = ROOT_URL + url
        #if thumb.startswith('/'): thumb = ROOT_URL + thumb
        #Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )

    utils.add_sort_method()
    utils.endOfDirectory()



@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])   
def Playvid(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)
