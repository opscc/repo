'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

addon = utils.addon

sortlistxt = [addon.getLocalizedString(30022), addon.getLocalizedString(30023), addon.getLocalizedString(30024),
            addon.getLocalizedString(30025)]   

SPACING_FOR_TOPMOST = ""
SPACING_FOR_NAMES = ""
SPACING_FOR_NEXT = ""
MAX_SEARCH_DEPTH = 10
ROOT_URL = "https://xtheatre.org"
SEARCH_URL = ROOT_URL + '/page/1/?filtre=title&display=extract&s='

URL_SUFFIX_PAGE1 = 'hdporn/1'
URL_SUFFIX_GIRLS = "porn-actress.php"
URL_SUFFIX_STUDIOS = "porn-actress.php"
URL_SUFFIX_CATEGORIES = "/categories/"

MAIN_MODE = '20'
LIST_MODE =  '21'
PLAY_MODE = '23'
CAT_MODE = '22'
SEARCH_MODE = '24'


@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    #utils.addDir('[COLOR {}]Categories[/COLOR]'.format(utils.search_text_color),'https://xxxmoviestream.com/categories/',22,'','')
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=ROOT_URL+URL_SUFFIX_CATEGORIES 
        ,mode=CAT_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True 
        )
    List(ROOT_URL +'/category/movies/?filtre=date&display=extract&filtre=title&display=extract', end_directory=True)

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, SEARCH_MODE)
        return

    #end_directory=False
    
    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(searchUrl, end_directory)

    #end_directory=True
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['end_directory'])
def List(url, end_directory=True):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( \
            SPACING_FOR_TOPMOST, utils.search_text_color) \
            ,url=SEARCH_URL \
            ,mode=SEARCH_MODE \
            ,iconimage=utils.search_icon \
            ,Folder=True \
            )
        
    listhtml = utils.getHtml(url, '')

    #match = re.compile(r'src="([^"]+?)" class="attachment.*?<a href="([^"]+)" title="([^"]+)".*?<div class="right">(.*?)</div>\s+</li>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    #for img, videopage, name, desc in match:
    match = re.compile('class=\"left\".*?src=\"http([^\"]+)\".*?title=\"([^\"]+)\".*?<a href=\"([^\"]+)\".*?<p>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match_len=len(match)
    #i = 0

    for img, name, videopage, desc in match:
        img = "http" + img #this site still requiers http only
        name = utils.cleantext(name)
        desc = utils.cleanhtml(desc)
        desc = utils.cleantext(desc)
        videopage = videopage.replace('#038;','&')
        Log("videopage={}".format(videopage))
        #utils.addDownLink(name, videopage, PLAY_MODE, img, desc)
        utils.addDownLink( 
            name = name 
            , url = videopage 
            , mode = PLAY_MODE 
            , iconimage = img
            , desc=desc
            , noDownload=False)
        

    next_page_regex = "class=\"pagination\".*?class=\"current\".*?href='([^']+)' class=\"inactive\">([^<]+)<"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if np_info:
        for np_url, np_number in np_info:
            np_url = np_url.replace('#038;','&')
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)

            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
                utils.add_sort_method()
                utils.endOfDirectory()
            else:
                utils.Notify(msg=np_url, duration=500)  #let user know something is happening
                if int(np_number) < MAX_SEARCH_DEPTH:    #search some more, but not forever
                    List(np_url, end_directory)
    else:
        Log("np_info not found")
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()


@utils.url_dispatcher.register(CAT_MODE, ['url'])
def Categories(url):
    cathtml = utils.getHtml(url)
    cat_page_regex = 'data-lazy-src.*?src=\"([^\"]+)\".*?href=\"([^\"]+)\".*?title=\"([^\"]+)\"'
    match = re.compile(cat_page_regex, re.DOTALL).findall(cathtml)
    for np_img, np_url, np_label in match:
        np_label="{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, np_label)
        utils.addDir(
            name= np_label
            ,url=np_url 
            ,mode=LIST_MODE 
            ,iconimage=np_img
            ,Folder=True 
            )

    utils.add_sort_method()
    utils.endOfDirectory()

    
@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def XTVideo(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)


