'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin
import xbmcgui
import time

from resources.lib import utils
from resources.lib.utils import Log
from random import randint

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://www.porntrex.com"

SEARCH_URL = ROOT_URL + "/search/{}/?mode=async&function=get_block&block_id=list_videos_videos&q={}&category_ids=&sort_by=relevance&from_videos={}&from_albums={}"

URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + "/latest-updates/{}/"
URL_CATEGORIES_PAGE= ROOT_URL + "/categories/{}/?mode=async&function=get_block&block_id=list_videos_common_videos_list_norm&sort_by=post_date&from4={}"

MAIN_MODE = '50'
LIST_MODE =  '51'
PLAY_MODE = '52'
CATEGORIES_MODE = '53'
SEARCH_MODE = '54'


#__________________________________________________________________________
#


@utils.url_dispatcher.register(MAIN_MODE, ['url'])
def Main(url):

    utils.addDir(
        name="[COLOR {}]Categories[/COLOR]".format( 
        utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE
        ,iconimage=utils.refresh_icon 
        )    

    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            )
        
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    listhtml = utils.getHtml(list_url, '')
    if "is no data in this list" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}'".format(keyword)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon 
            )
    else: #distinguish between adverts and videos
        video_region = listhtml.split('class="porntrex-box"')[1].split('class="pagination"')[0]

    #
    # main list items
    #
    regex = '<img class=\"cover lazyload\" data-src=\"(?P<thumb>[^\"]+)\".+?class="quality">(?P<quality>[\d]+).+?clock-o\"><\/i>(?P<duration>[^<]+).+?href=\"(?P<url>[^\"]+)\" title=\"(?P<title>[^\"]+)\"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for thumb, hd, duration, videourl, label in info:
        #Log("hd={}".format(hd))
        if '2160' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        thumb = thumb.replace('1.jpg?v=3', str(randint(1,10)) + '.jpg' + utils.Header2pipestring() + '&Referer=' + ROOT_URL + '/' )
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration)


    #
    # next page items
    #
    if not video_region == "": 
        next_page_html = listhtml.split('class="pagination"')[1]
    else:
        next_page_html = ""
    next_page_regex = 'class="next"><a href="([^"]+)".+?from(?:_videos\+from_albums|4|):(\d+)'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url, np_number in np_info:
            #Log("np_url={}".format(np_url))
            if '/search/' in list_url:
                np_url = SEARCH_URL.format(keyword, keyword.replace('%20','+'), np_number, np_number )
            if '/categories/' in list_url:
                np_url = URL_CATEGORIES_PAGE.format(keyword, np_number )
            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                else:
                    utils.add_sort_method()
                    utils.endOfDirectory()
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    videopage = utils.getHtml(url, '')
    
    license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(videopage)[0]

    sources = re.compile("video(?:_alt|)_url\d?: '([^']+)',.+?video(?:_alt|)_url\d?_text: '(\d+)", re.DOTALL | re.IGNORECASE).findall(videopage)
    #Log("sources={}".format(sources))
    if not sources:
        utils.Notify("No video file found for {}".format(name))
        return
    
    videourl = utils.SortVideos(sources, 1)
    Log("videourl={}".format(videourl))
    
    Log("license_code='{}'".format(license_code) )
    fappy_salt = utils.FaapySalt(license_code, "")
    Log("fappysalt='{}'".format(fappy_salt))
    old_fappy_code =  videourl.split('/')[5]
    Log("old_fappy_code='{}'".format(old_fappy_code))
    new_fappy_code = utils.ConvertFaapyCode( old_fappy_code, fappy_salt)
    Log("new_fappy_code='{}'".format(new_fappy_code))

    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)


#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(searchUrl, keyword=None, end_directory=True):

    if not keyword:
        utils.searchDir(searchUrl, SEARCH_MODE)
        return

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False

    keyword = keyword.replace('+',' ').replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword, keyword.replace('%20','+'), "1", "1" )
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, keyword=keyword, end_directory=end_directory)

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=True
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):

    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, '')

    cathtml = re.compile('"list-categories"(.*)class="footer-margin', re.DOTALL).findall(html)[0]

    regex = 'href="([^"]+)" title="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label, thumb in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        thumb = "https:" + thumb + utils.Header2pipestring()+"&Referer=" + ROOT_URL + '/'
        keyword = videourl.split('/categories/')[1].split('/')[0]
        #Log("videourl={}".format(videourl))
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,keyword=keyword
            )
        
    utils.add_sort_method()
    utils.endOfDirectory()

