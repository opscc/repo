'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://www.vporn.com"

SEARCH_URL = ROOT_URL + '/search?q='

URL_CATEGORIES = ROOT_URL+'/newest/'
URL_RECENT = ROOT_URL+'/newest/'

MAIN_MODE = '500'
LIST_MODE =  '501'
PLAY_MODE = '502'
CATEGORIES_MODE = '503'
SEARCH_MODE = '504'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    
    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color)
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.search_icon )
    
    List(url=URL_RECENT, end_directory=True, keyword=None)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):
    
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    listhtml = utils.getHtml(url, '', ignore404=True )

    if "No results found for this criteria" in listhtml:
        #2019-06-30   this site will return a 404 response which will lead to ugly error message via utils.getHtml(url, '')
        video_region = ""
        next_page_html = ""
        label = ""
        if keyword: label = "Nothing found for '{}'".format(keyword)
        utils.addDir(name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon 
            ,Folder=False
            )
    else:
        next_page_html = listhtml
        if 'div class="banner-mobile"' in listhtml:
            video_region = listhtml.split('div class="banner-mobile"')[1]
        else:
            video_region = listhtml

            
##    match = re.compile('class="video".+?href="([^"]+?)".+?<span class="time">([^<]+?)<.+?img src="([^"]+?)" alt="([^"]+?)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
##    for videopage, duration, img, name in match:
##        name = utils.cleantext(name)
##        utils.addDownLink(name, videopage, PLAY_MODE, img \
##                ,'', stream=False, duration=duration)

    regex = 'class="video".+?href="([^"]+?)".+?<span class="time">([^<]+?)<.+?img src="([^"]+?)" alt="([^"]+?)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, duration, thumb, label in info:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration 
            , noDownload=False)
        

    next_page_regex = '<a class=\"next link(?:s|age)\" title=\"Next Page\" href=\"(.+?)\">'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        #Log("np_info='{}'".format(np_info))
        for np_url in np_info:
            np_number = np_url.split('?')[0].split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number 
                    ,Folder=True 
                    )
            else:
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                    

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    page = utils.getHtml(url, '')
    #match = re.compile(r'videoUrlMedium = "(.+?)"', re.DOTALL | re.IGNORECASE).findall(page)
    match = None
    match_480 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="480p"', re.DOTALL | re.IGNORECASE).findall(page)
    match_720 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="720p HD"', re.DOTALL | re.IGNORECASE).findall(page)
    match_1080 = re.compile(r'<source src="([^"]+)" type="video/mp4" label="1080p"', re.DOTALL | re.IGNORECASE).findall(page)
    if match_1080 and not match : match = match_1080
    if match_720 and not match : match = match_720
    if match_480 and not match : match = match_480
    if not match:
        #try older style web page
        #match = re.compile(r'<video id="vporn-video-player".*? src="([^"]+)" type="video/mp4" label="1080p"', re.DOTALL | re.IGNORECASE).findall(page)
        #<video id="vporn-video-player
        Log("no match found at url='{}', name=''".format(url,name), xbmc.LOGNONE)

    videourl = match[0]+utils.Header2pipestring()+"&Referer=https://www.vporn.com"
    utils.playvid(videourl, name, download)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):
    
    cathtml = utils.getHtml(url, '')
    cathtml = cathtml.split('class="cats-all')[1].split('class="playlist')[0]

    regex = '<a href="([^"]+)".+?>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, label) 
        #if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        thumb = utils.search_icon
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        Log("videourl={}".format(videourl))
        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
        utils.addDir(name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,Folder=True
            )

    utils.add_sort_method()
    utils.endOfDirectory()

    
#__________________________________________________________________________
#
    
@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(searchUrl, keyword=None, end_directory=True):

    if not keyword:
        utils.searchDir(searchUrl, SEARCH_MODE)
        return
    
    org_end_directory = end_directory
    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False
    
    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)
    
    end_directory = org_end_directory
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
