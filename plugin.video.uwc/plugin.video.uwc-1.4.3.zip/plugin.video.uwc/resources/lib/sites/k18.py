'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import sys
import xbmc, xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://k18.co"

SEARCH_URL = ROOT_URL + '/?s='

URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/page/1/?filter=latest'

MAIN_MODE = '230'
LIST_MODE =  '231'
PLAY_MODE = '232'
CATEGORIES_MODE = '233'
SEARCH_MODE = '234'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.search_icon 
                )

    List(URL_RECENT, page='0', end_directory=True)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True 
            )
        
    listhtml = utils.getHtml(url, '')

    if "ut nothing matched your search terms" in listhtml:
        video_region = ""
        label = ""
        if keyword: label = "Nothing found for '{}'".format(keyword)
        utils.addDir(name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon 
            ,Folder=False
            )
    else: #distinguish between adverts and videos
        video_region = listhtml.split('class="widget-title"')[1]


    info_duration = []
    info_no_duration = []
    if 'duration\"' in video_region: #need this test because regex will go forever if info is not found
        regex = '<article id=\".+?href=\"([^\"]+)\".+?title=\"([^\"]+)\".+?(?:data-src|poster)=\"([^\"]+)\".+?duration\">([^<]+)<'
        info_duration = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
        #Log("info_duration={}".format(info_duration))
    else: #searched items don't include duration
        regex = '<article id=\".+?href=\"([^\"]+).+?data-src=\"([^\"]+).+?alt=\"([^\"]+)\"'
        info_no_duration = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
        Log("info_no_duration={}".format(info_no_duration))



    for videourl, label, thumb, duration in info_duration:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration )
    for videourl, thumb, label in info_no_duration:
        label = utils.cleantext(label)
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb)
            

        

    next_page_html = listhtml #.split('class=linkscts')[1]
    next_page_regex = "\"pagination\".+?class=\"current\".+?href=(?:\"|')([^\"']+)(?:\"|') class=\"inactive\""
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            np_number=np_url.split('/')[4]
            #Log("np_number={}".format(np_number))
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if not np_number.isdigit(): np_number=np_url.split('/')[6]
            if not np_url.startswith('http'): np_url = ROOT_URL + '/' + np_url
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url = np_url 
                    ,mode = LIST_MODE 
                    ,iconimage = utils.next_icon 
                    ,page=np_number 
                    )
            else:
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(searchUrl, keyword=None, end_directory=True):

    if not keyword:
        utils.searchDir(searchUrl, SEARCH_MODE)
        return

    org_end_directory = end_directory
    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)

    end_directory = org_end_directory
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')

    regex = '<article id=\".+?href=\"([^\"]+)\".+?src=\"([^\"]+)\".+?\"cat-title\">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, thumb, label in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, label) 
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            )
    
    np_url=re.compile("<li class='pagination-nav'><a href=\"(.+?)\"", re.DOTALL).findall(cathtml)
    if np_url:
        np_url = np_url[0]
        #Log("np_url='{}'".format(np_url))
        try:
            np_number = np_url.split('page/')[1]
            np_number = int(np_number.split('/')[0])
        except:
            Log("unkown page location")
        if int(np_number) < 20: #search some more, but not forever
            Categories(np_url)
    else:
        Log("np_url not found")

    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    videopage = utils.getHtml(url, referer=url)
    
    match = re.compile('content=\"https://www.pornhub.com/embed/([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videopage)
    if match: # this is a redirect; use that site's play code
        from resources.lib.sites import pornhub
        pornhub_url = "https://www.pornhub.com/view_video.php?viewkey="+match[0]
        pornhub.Playvid(pornhub_url, name=name, download=download)
        return

    match = re.compile('itemprop="embedURL" content=\"(https://www.youporn.com/embed/[^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videopage)
    if match: # this is a redirect; use that site's play code
        match= match[0] + '/'
        Log("match='{}'".format(match))
        videopage = utils.getHtml(match, referer=url)

    utils.playvideo(videopage, name, download, url)

#__________________________________________________________________________
#
