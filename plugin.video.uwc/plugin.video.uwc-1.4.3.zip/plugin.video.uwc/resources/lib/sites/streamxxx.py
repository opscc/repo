'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://streamxxx.tv"

SEARCH_URL = ROOT_URL + '/?s={}'

URL_CATEGORIES = ROOT_URL + '/top-tags/'
URL_CLIPS = ROOT_URL + '/category/clips/'
URL_RECENT = ROOT_URL

MAIN_MODE = '175'
LIST_MODE =  '171'
PLAY_MODE = '172'
CATEGORIES_MODE = '173'
SEARCH_MODE = '174'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.search_icon 
        ,Folder=True 
        )
       
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))


    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        
        
    if '{}' in url and page: list_url = url.format(page)
    else: list_url = url
    listhtml = utils.getHtml(list_url, url)
    if "but nothing matched your search" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}'".format(keyword)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon 
            )
    else: #distinguish between adverts and videos
        video_region = listhtml.split('class="st-site-main')[1].split("class='page-numbers'")[0]
        

    #
    # main list items
    #
    #Log("video_region='{}'".format(video_region))
    videos_regex = "(?:<article id=|class=\"quadrato\").*?<a href=\"([^\"]+)\".*?title=\"([^\"]+)\".*?src=\"([^\"]+)\""
    info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb in info:

        #2019-07-06 all? of the 4k inside file lockers, so this label may not mean much
        if '/4K)' in label:
            hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
            label = label.replace('/4K)',')')
        elif '/FULLHD)' in label:
            hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
            label = label.replace('/FULLHD)',')')
        elif '/HD)' in label:
            hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
            label = label.replace('/HD)',')')
        else: hd = ""
        
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        thumb = thumb.replace(".pixhost.org/", ".pixhost.to/")
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb)


    #Log("listhtml='{}'".format(listhtml))
    #
    # next page items
    #
    if not video_region == "": 
        next_page_html = listhtml.split("<ul class='page-numbers'")[1]
    else:
        next_page_html = ""
    #Log("next_page_html='{}'".format(next_page_html))
    next_page_regex = 'page-numbers" href="([^"]+)">Next<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            #Log("np_url={}".format(np_url))
            np_number = '' #page number can be multiple places depending if search result or not
            if not np_number.isdigit(): np_number=np_url.split('/')[4]
            if not np_number.isdigit(): np_number=np_url.split('/')[5]
            if not np_number.isdigit(): np_number=np_url.split('/')[6]
            if not np_number.isdigit(): np_number=np_url.split('/')[7]
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                else:
                    utils.add_sort_method()
                    utils.endOfDirectory()


    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory'])
def Search(searchUrl, keyword=None, end_directory=True):

    if not keyword:
        utils.searchDir(searchUrl, SEARCH_MODE)
        return

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=False

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, end_directory=end_directory, keyword=keyword)

    if utils.addon.getSetting("force_recursive_search").lower() == "true":
        end_directory=True
    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'])
def Categories(url):
    html = utils.getHtml(url, '')

    clips_regex = 'FILMS(.+)TOP TAGS'
    clips_html = re.compile(clips_regex, re.DOTALL).findall(html)[0]
    #Log("clips_html='{}'".format(clips_html))
    clips_regex = 'li id="menu-item.+?href="([^"]+)">([^<]+)<'
    info = re.compile(clips_regex, re.DOTALL | re.IGNORECASE).findall(clips_html)
    #Log("info='{}'".format(info))
    for url, label in info:
        if url.startswith('/'): url = ROOT_URL + url
        #Log("url='{}'".format(url))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            )
        
    regex = 'a id="tag.+?href="([^"]+)" rel="tag">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    #Log("info='{}'".format(info))
    for url, label in info:
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            )

    clips_regex = 'VIDEOS(.+)FILMS'
    clips_html = re.compile(clips_regex, re.DOTALL).findall(html)[0]
    regex = 'li id="menu-item.+?href="([^"]+)".*?>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(clips_html)
    #Log("info='{}'".format(info))
    for url, label in info:
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            )
                        
    utils.add_sort_method()
    utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    utils.PLAYVIDEO(url, name, download)
    
##    datosrc="                                            <script type='text/javascript'>eval(function(p,a,c,k,e,d){while(c--)if(k[c])p=p.replace(new RegExp('\\b'+c.toString(a)+'\\b','g'),k[c]);return p}('8(\"2o\").2n({2m:[{k:\"7://d.6.4/2l/,j,.s/2k.2j\"},{k:\"7://d.6.4/q/,j,.s/2i.2h\"},{k:\"7://d.6.4/j/v.2g\",2f:\"2e\"}],2d:\"7://d.6.4/i/2c/2b/m.2a\",29:\"r%\",28:\"r%\",27:\"\",26:\"25.24\",23:\'22\',21:\"c\",20:\"c\",1z:\"1y\",1x:\"1w\",1v:[],q:c,1u:\"1t 1s 1r 1q\",1p:c,1o:\"\",1n:\"7://6.4\"});1m e,h,g=0;8().1l(3(x){a(5>0&&x.b>=5&&h!=1){h=1;$(\'f.1k\').1j(\'1i\')}a(g==0&&x.b>=p&&x.b<=(p+2)){g=x.b}});8().1h(3(x){o(x)});8().1g(3(){$(\'f.n\').1f()});3 o(x){$(\'f.n\').1e();a(e)1d;e=1;9=0;a(1c.1b===1a){9=1}$.19(\'7://6.4/18?17=16&15=m&14=13-12-11-10-z&y=1&9=\'+9,3(l){$(\'#w\').u(l)})}8().t(3(){});',36,97,'|||function|co||datoporn|https|jwplayer|adb|if|position|true|cn3|vvplay|div|x2ok|vvad||3rcpbrrmglcmj4otnml4ozkip2h7jtfaaryqatypvij5x27nsgh2rghnzixa|file|data|374jrdtozbtr|video_ad|doPlay|78|dash|100|urlset|onReady|html||fviews||embed|fee9832247fab1c0ca963c2338752fed|1562454613|154|216|2484627|hash|file_code|view|op|dl|get|undefined|cRAds|window|return|hide|show|onComplete|onPlay|slow|fadeIn|video_ad_fadein|onTime|var|aboutlink|abouttext|displaytitle|1080p|Danger|Abella|RealityKings|title|tracks|start|startparam|html5|primary|hlshtml|androidhls|none|preload|47|1560|duration|stretching|height|width|jpg|00496|01|image|720p|label|mp4|mpd|manifest|m3u8|master|hls|sources|setup|vplayer'.split('|')))"
##
##    #regex = "\(p,a,c,k,e,d\).+?}\(';',(.+)\.split\(\'\|\'\)"
##    regex1 = "\(p,a,c,k,e,d\).+?}\('(.*?);',"
##    packed1 = re.compile(regex1, re.DOTALL).findall(datosrc)
##    regex2 = "\(p,a,c,k,e,d\).+?;',(.+)\.split\(\'\|\'\)"
##    packed2 = re.compile(regex2, re.DOTALL).findall(datosrc)
##    Log("packed1='{}'".format(packed1))
##    Log("packed2='{}'".format(packed2))
##    if packed1 and packed2:
##        p = packed1[0]
##        Log("p='{}'".format(p))
##        packed_arr = packed2[0].split(',')
##        a = packed_arr[0]
##        c = packed_arr[1]
##        k = packed_arr[2].split('|')
##        Log("a='{}'".format(a))
##        Log("c='{}'".format(c))
##        Log("k='{}'".format(k))
##        datoujs = utils.dePacked(p,a,c,k,None,None)
##        Log("datoujs='{}'".format(datoujs))
##
##
##    regex = 'file:\"([^\"]+mp4)\"'
##    regex = 'file:\"([^\"]+mp4)\",label:\"([^\"]+)p\"'
##    videourl = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(datoujs)
##    if not videourl: #try another format
##        videourl = re.compile('{src: "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(datoujs)
##    if len(videourl) == 0:
##        videourl = None
##    Log("videourl='{}'".format(videourl))
##    if videourl:
##        video_url = utils.SortVideos(videourl)
##        Log(video_url)
##        videourl = videourl[0]
##        videourl = "{}{}&Referer={}".format(videourl, utils.Header2pipestring(), "the url")
##        Log(videourl)
##        
##    return

##    p='8("2s").2r({2q:[{k:"7://d.6.4/2p/,j,.s/2o.2n"},{k:"7://d.6.4/q/,j,.s/2m.2l"},{k:"7://d.6.4/j/v.2k",2j:"2i"}],2h:"7://d.6.4/i/2g/2f/m.2e",2d:"r%",2c:"r%",2b:"",2a:"29.28",27:\'26\',25:"c",24:"c",23:"22",21:"20",1z:[],q:c,1y:"1x 19 1w 1v 1u 1t 1s 1r",1q:c,1p:"",1o:"7://6.4"});1n e,h,g=0;8().1m(3(x){a(5>0&&x.b>=5&&h!=1){h=1;$(\'f.1l\').1k(\'1j\')}a(g==0&&x.b>=p&&x.b<=(p+2)){g=x.b}});8().1i(3(x){o(x)});8().1h(3(){$(\'f.n\').1g()});3 o(x){$(\'f.n\').1f();a(e)1e;e=1;9=0;a(1d.1c===1b){9=1}$.1a(\'7://6.4/18?17=16&15=m&14=13-12-11-10-z&y=1&9=\'+9,3(l){$(\'#w\').u(l)})}8().t(3(){});'
##    a = 36
##    c =  101
##    k = '|||function|co||datoporn|https|jwplayer|adb|if|position|true|cn3|vvplay|div|x2ok|vvad||3rcpbrzmglcmj4otnml4onaohzxaxdb3wrtkcbp5gnnz72cthv7elfnv2xmq|file|data|bqtkjq2dj5mn|video_ad|doPlay|104|dash|100|urlset|onReady|html||fviews||embed|14e5d30086336965d1d4d856618b4226|1562430949|154|216|2484626|hash|file_code|view|op|dl||get|undefined|cRAds|window|return|hide|show|onComplete|onPlay|slow|fadeIn|video_ad_fadein|onTime|var|aboutlink|abouttext|displaytitle|1080p|XXX|Paul|Lena|04|07|BigTitsRoundAsses|title|tracks|start|startparam|html5|primary|hlshtml|androidhls|none|preload|79|2081|duration|stretching|height|width|jpg|00496|01|image|720p|label|mp4|mpd|manifest|m3u8|master|hls|sources|setup|vplayer'.split('|')
##    dep = utils.dePacked(p,a,c,k,None,None)
##    Log(dep)
##    utils.endOfDirectory()
##    return


