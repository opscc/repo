import datetime,time
import subprocess
from resources.lib import constants as C
from resources.lib import utils
from resources.lib.utils import Log as Log

#__________________________________________________________________
#
def reboot_required_detection():
    last_reboot = C.addon.getSetting('last_reboot')
    try:
        last_reboot = datetime.datetime(*(time.strptime(last_reboot, "%Y-%m-%d")[0:6]))
    except:
        last_reboot = datetime.datetime(*(time.strptime("1980-12-2", "%Y-%m-%d")[0:6]))
        C.this_addon.setSetting(id='last_reboot', value=last_reboot.strftime("%Y-%m-%d"))

    #work around for some flakiness previously found related to calculating 'today'
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    today = datetime.datetime(*(time.strptime(today, "%Y-%m-%d")[0:6]))

##    previousTime = time.time()
##    while (not xbmc.abortRequested):
##        if ( time.time()-previousTime > 5):
##            print "XBMC has returned from standby"
##            previousTime = time.time()
##            utils.Sleep(1000)
##        else:
##            previousTime = time.time()
##            utils.Sleep(1000)

    Log('begin check if network is working')
    utils.Sleep(10000) #sleep an extra 10 seconds in case this has been triggered after a power wakeup event
    result = utils.Is_Online()
    if result is True:
        Log("Is_Online() is true")#, C.LOGNONE)
    else:
        Log("Ping is false")#, C.LOGNONE)
        if (last_reboot >= today):  
            Log('already restarted today - notify only')
            utils.Notify(header="Network offline", msg="Manually restart ASAP", duration=15000, allow_all_thread_names=True)
        else:
            utils.Notify(header="Network offline", msg="Kodi will schedule computer restart", duration=30000, allow_all_thread_names=True)
            result = (subprocess.call("shutdown -r -t 120", shell=True) == 0)
            C.this_addon.setSetting(id='last_reboot', value=datetime.datetime.now().strftime("%Y-%m-%d"))
#__________________________________________________________________
#
