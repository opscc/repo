'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]absoluporn[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "http://www.absoluporn.com"

SEARCH_URL = ROOT_URL + '/en/search-{}-1.html'

URL_CATEGORIES = ROOT_URL + '/en'
URL_TOP_RATED = ROOT_URL + '/en/wall-note-1.html'
URL_MOST_VIEWED = ROOT_URL + '/en/wall-main-1.html'
URL_LONGEST = ROOT_URL + '/en/wall-time-1.html'
URL_RECENT = ROOT_URL + '/en/wall-date-1.html'

MAIN_MODE       = C.MAIN_MODE_absoluporn
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)

FIRST_PAGE = '1' #default first page

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(name="{}[COLOR {}]Top Rated[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color) 
        ,url=URL_TOP_RATED
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon )

    utils.addDir(name="{}[COLOR {}]Most Viewed[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color) 
        ,url=URL_MOST_VIEWED
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon )

    utils.addDir(name="{}[COLOR {}]Longest[/COLOR]".format( 
        C.SPACING_FOR_TOPMOST, C.search_text_color) 
        ,url=URL_LONGEST
        ,mode=LIST_MODE 
        ,iconimage=C.category_icon )

    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon )
    
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=FIRST_PAGE, end_directory=True, keyword='', testmode=False):
    Log("List(url={}, page={}, end_directory={}, keyword={})".format(url, page, end_directory, keyword))


    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url)
    video_region = listhtml.split('class="bloc-menu-centre')[1]
    video_region = video_region.split('<script>')[0]

    # parse out list items
    regex = 'thumb-main-titre"><a href="..([^"]+)".*?title="([^"]+)".*?src="([^"]+)".*?<div class="thumb-info">(.*?)time">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, hd, duration in info:
##        Log("hd={}".format(hd))        
        hd = utils.Normalize_HD_String(hd)
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)        
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        videourl = videourl.replace(" ","%20")
##        Log("videourl={}".format(videourl))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    #
    # next page items
    #
    next_page_html = listhtml.split('<div class="bloc-thumb">')[0]
    next_page_regex = '<span class="text16">.+?href="..([^"]+)".+?>([^<]+)<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url, np_number in np_info:
            np_number = int(np_number)
            #if not np_number.isdigit(): np_number=np_url.split('/')[3]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            np_url=np_url.replace(" ","%20")
            Log("np_url={}".format(np_url))
            Log("np_number={}".format(np_number))
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number 
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= max_search_depth:
                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword)
            break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={})".format(searchUrl, page, end_directory, keyword))
    
    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    title = keyword.replace(' ','%20')
    searchUrl = SEARCH_URL.format(title)
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=FIRST_PAGE, end_directory=end_directory, keyword=keyword)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))       
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    all_html = utils.getHtml(url, ROOT_URL)
    cat_html = all_html.split('class="pvicon-categorie"')[1]
    cat_html = cat_html.split('>All tags<')[0]
    regex = 'href="..([^"]+)".+?>([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cat_html)
##    Log("info='{}'".format(info))
    for url, label in info:
        if url.startswith('/'): url = ROOT_URL + url
        #Log("url='{}'".format(url))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=C.search_icon )
        
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def Test(keyword):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    
    full_html = utils.getHtml(url)
    servervideo = re.compile("servervideo = '([^']+)'", re.DOTALL | re.IGNORECASE).findall(full_html)
    vpath = re.compile("path = '([^']+)'", re.DOTALL | re.IGNORECASE).findall(full_html)[0]
    repp = re.compile(r"repp = '([^']+)'", re.DOTALL | re.IGNORECASE).findall(full_html)[0]
    filee = re.compile("filee = '([^']+)'", re.DOTALL | re.IGNORECASE).findall(full_html)[0]

    video_url = servervideo[0] + vpath + repp + filee
    if not video_url.startswith("http:"): video_url = "https:" + video_url

    description = ''
    desc_separator_char = '; '
    regex_tags_region = '(.+)'
    regex_tags = 'class="link12">(?P<tag>[^<]+)<'
    region_html = re.compile(regex_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
    if region_html:
        source_tags = re.compile(regex_tags, re.DOTALL | re.IGNORECASE).findall(region_html[0])
        for tag in source_tags:
            if tag.lower() not in description.lower():
                description = "{}{}{}".format(description,utils.cleantext(tag),desc_separator_char)
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))


    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name, download, description=description)
#__________________________________________________________________________
#
