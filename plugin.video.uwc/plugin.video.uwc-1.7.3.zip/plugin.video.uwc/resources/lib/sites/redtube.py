'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
import xbmc, xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://www.redtube.com"

SEARCH_URL = ROOT_URL + '/?search={}&page={}'

URL_CATEGORIES = ROOT_URL + '/categories'
URL_RECENT = ROOT_URL + '/?page={}'

MAIN_MODE       = '670'
LIST_MODE       = '671'
PLAY_MODE       = '672'
CATEGORIES_MODE = '673'
SEARCH_MODE     = '674'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon)
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
        
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url, ignore404=True)# , send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "Page Not Found" in listhtml or 'No Search Results' in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            regex = '(?:id="browse_section"|id="search_results_block")(.+)(?:id="w_pagination"|class="title_inactive")'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))



    #
    # parse out list items
    #
    regex = 'alt="([^"]+)".+?data-src="([^"]+)".+?"duration">\s+((?:<span class="hd-video-text">HD</span>|))\s+(\d+:\d+).+?href="(/[^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for label, thumb, hd, duration, videourl in info:
        #Log("label={}".format(label))
        #Log("hd={}".format(hd))
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '>HD' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        #thumb = thumb + "|Referer=" + list_url
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
##        Log("label={}".format(label), xbmc.LOGNONE)
##        Log("duration={}".format(duration))
##        Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    #
    # check for a minimum during tesing
    #
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'listitems failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError


    #
    # next page items
    #
    try:
        regex = 'id="w_pagination"(.+)'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = 'id="wp_navNext" class="js_pop_page.+?href="([^"]+=\d)">'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            np_url = utils.html_parser.unescape(np_url)
#            Log("np_url.split('/')={}".format(np_url.split('/')))
            np_number = '' 
            if '/' in np_url: np_url = np_url.strip('/').split('/')[-1]
            Log("np_url={}".format(np_url))
            if '?page=' in np_url: np_number = np_url.split('?page=')[1]
            if '&page=' in np_url: np_number = np_url.split('&page=')[1]
#            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
            np_url=url.lower() #site will redirect if mixed case
##            Log("np_number={}".format(np_number))
##            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number))
            if end_directory == True:
                utils.addDir(
                    name=np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)

    regex = 'class="main_category_header"(.+)'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##    Log("listhtml={}".format(listhtml))
    
    regex = 'class="category_item_wrapper.+?href="([^"]+)".+?data-src="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"

#https://www.redtube.com/redtube/brunette?page=3
        videourl = videourl + '?page={}'
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page="1"
            ,iconimage=thumb) #utils.search_icon)
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    source_html1 = utils.getHtml(url, ROOT_URL)
#    source_html1 = ',"mediaDefinitions":[{"defaultQuality":true,"format":"","quality":"720","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/720P_1500K_18335131.mp4?0idsYiD-jh4q8NCS0v6iC1R4SAvv9m-WqnqgA6QzCKeNUJDGO0ciQkPcv4LJoOhew2wWEAC9YYOXyjV9PcTKi3ORzGohLfp1w3G8b_JlOHa10127jyitWfiJ5v8yjGiLVtt2SaTCU0Lsm4k70rkKP5Gy9YFytRi6xQRA4Wabo9WmcJ_P_1Fx0jDk0ou7LTiqlJ5LMLnZw0rQEEJ1"},{"defaultQuality":false,"format":"","quality":"480","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/480P_600K_18335131.mp4?tkV8JplE8wnw9uFa8936-HctKRAu0uOgmukr-_x2SZ6-pa3CHzujAQaO8hXeUfnqK9VpiEKx88u4-MWns7sAIkg8I3XB1NeLT2PXLYf4ugY_-9wTqm-uh0dQD94l4cNzuL1d7o2IQ-PxweNWVKv9hGOQcevk7BnGAxJ7dSla2jXUjfQt0BSbTpxxyrTBtBZmBRoEE8hB5HXhIw"},{"defaultQuality":false,"format":"","quality":"240","videoUrl":"https:\/\/cv.rdtcdn.com\/media\/videos\/201907\/02\/18335131\/240P_400K_18335131.mp4?STGBmiZrtxfV2QjInJOYcX1LyZEQmXVjos6jS4pRDHosxZXN3JvlNrY0f_96RbC94YLDrkRiyLidn7MpRlLqIzOScqQtx9aU5ruyvBOx0PnpZmtNHiDljbyOaY_sDvBugfGT21tHRqs-Js9Alb9V8AqkCoDcuo1nFVB0qZu8qpvJzczAvXvwVPVR1GB3ypqczItFjAaCAFLdtg"}],'
#    Log("source_html1={}".format(source_html1))

    regex = ',"mediaDefinitions?":([^\]]+\]),'
    regex = ',?"?mediaDefinitions?"?:(.+?\]),'
    
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
    Log("sources_list={}".format(sources_list))
    json_sources = json.loads(sources_list[0])

    list_key_value = {} ##[] #dict()
    for i in range(len(json_sources)):
        dict_source = dict(json_sources[i])
        q = str(dict_source['quality'])
        v = str(dict_source['videoUrl'])
        if not (".m3u8?" in v): ## skip HLS for now
            if not v == "":
                list_key_value[q] = v
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    Log("list_key_value={}".format(list_key_value))
    video_url = utils.SortVideos(list_key_value,0)
    Log("video_url={}".format(video_url))
        
    utils.playvid(video_url, name, download, description=name)
    
#__________________________________________________________________________
#
