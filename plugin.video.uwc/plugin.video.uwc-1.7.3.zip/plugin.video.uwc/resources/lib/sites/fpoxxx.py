'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin
import xbmcgui
import time

from resources.lib import utils
from resources.lib.utils import Log
from random import randint

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://www.fpo.xxx"

#SEARCH_URL = ROOT_URL + "/search/{}/?mode=async&function=get_block&block_id=list_videos_videos&q={}&category_ids=&sort_by=relevance&from_videos={}&from_albums={}"
SEARCH_URL = ROOT_URL +  "/search/{}/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q={}&category_ids=&sort_by=&from_videos={}"
#              /search/ariana-marie /?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=ariana+marie&category_ids=&sort_by=&from_videos=02&from_albums=02

URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + "/latest-updates/?mode=async&function=get_block&block_id=list_videos_latest_videos_list&sort_by=post_date&from={}"
     #https://www.fpo.xxx/latest-updates/?mode=async&function=get_block&block_id=list_videos_latest_videos_list&sort_by=post_date&from=6&_=1580915860033 HTTP/1.1
#https://www.fpo.xxx/?mode=async&function=get_block&block_id=list_videos_most_recent_videos&sort_by=post_date_and_rating&from=01 #2019-08-01



URL_CATEGORIES_PAGE= ROOT_URL + "/categories/{}/?mode=async&function=get_block&block_id=list_videos_common_videos_list_norm&sort_by=post_date&from4={}"

MAIN_MODE       = '950'
LIST_MODE       = '951'
PLAY_MODE       = '952'
CATEGORIES_MODE = '953'
SEARCH_MODE     = '954'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

##    utils.addDir(
##        name="[COLOR {}]Categories[/COLOR]".format( 
##        utils.search_text_color) 
##        ,url=URL_CATEGORIES
##        ,mode=CATEGORIES_MODE
##        ,iconimage=utils.category_icon )

    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon )
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)
        
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    listhtml = utils.getHtml(list_url, '')
    if "is no data in this list" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon  )
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('class="porntrex-box"')[1].split('class="pagination"')[0]
        except:
            video_region = listhtml

    #
    # main list items
    #
    #regex = '<img class=\"cover lazyload\" data-src=\"(?P<thumb>[^\"]+)\".+?class="quality">(?P<quality>[\d]+).+?clock-o\"><\/i>(?P<duration>[^<]+).+?href=\"(?P<url>[^\"]+)\" title=\"(?P<title>[^\"]+)\"'
    regex = 'class="item.+?href="([^"]+)".+?title="([^"]+)".+?data-original="([^"]+)".+?class="duration">([^<]+)<.+?((?:<span class="is-hd">HD</span>|</div>))'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, duration, hd  in info:
##        Log("hd={}".format(hd))
        if '2160' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif 'HD' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration)
    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError
                

    #
    # next page items
    #
    try:
        next_page_html = listhtml.split('class="pagination"')[1]
    except:
        next_page_html = listhtml
    next_page_regex = 'class="next"><a href="([^"]+)".+?from(?:_videos\+from_albums|4|):(\d+)'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url, np_number in np_info:
            #Log("np_url={}".format(np_url))
            if '/search/' in list_url:
                np_url = SEARCH_URL.format(keyword, keyword.replace('%20','+'), np_number, np_number )
            if '/categories/' in list_url:
                np_url = URL_CATEGORIES_PAGE.format(keyword, np_number )
            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
            np_url=url
            Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

#              /search/ariana-marie /?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=ariana+marie&category_ids=&sort_by=&from_videos=02&from_albums=02

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword.replace('+','-'),keyword,'{}')

    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, '')

    cathtml = re.compile('"list-categories"(.*)class="footer-margin', re.DOTALL).findall(html)[0]

    regex = 'href="([^"]+)" title="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label, thumb in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, utils.cleantext(label)) 
        thumb = "https:" + thumb + utils.Header2pipestring()+"&Referer=" + ROOT_URL + '/'
        keyword = videourl.split('/categories/')[1].split('/')[0]
        #Log("videourl={}".format(videourl))
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,keyword=keyword )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
##    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    Log("Playvid (url='{}', name='{}', download='{}')".format(url, name, download))
    source_html1 = utils.getHtml(url, ROOT_URL)
#    source_html1 = "var flashvars = {  video_id: '3152648', license_code: '$524530617305183', lrc: '70275956', rnd: '1563642980', video_url: 'function/0/https://www.slutload.com/get_file/1/a238c212f61197c42461a4a5ad39119d73b41c4b98/3152000/3152648/3152648.mp4/', postfix: '.mp4', video_url_text: '480p', video_alt_url: 'function/0/https://www.slutload.com/get_file/1/6204add9dd801544c5b62338e421802c5f57c0187b/3152000/3152648/3152648_720p.mp4/', video_alt_url_text: '720p', video_alt_url_hd: '1', default_slot: '2', preview_url: 'https://i-rnsec.slutload-media.com/kvs/3152000/3152648/preview.jpg', skin: 'youtube.css', logo_position: '0,0', logo_anchor: 'topleft', bt: '5', volume: '1', preload: 'auto', hide_controlbar: '1', autoplay: 'true', related_src: 'https://www.slutload.com/related_videos_html/3152648/', related_on_pause: 'true', disable_preview_resize: 'true', embed: '1'};"
#    regex = "license_code: '(?P<lic>[^']+)'.+?video_url: 'function\/0\/(?P<vid>[^']+).+?(?:video_alt_url_hd: 'function\/0\/(?P<vid2>[^']+)|skin)"
    regex = "flashvars.+?license_code:.+?'(?P<lic>[^']+)'"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(source_html1)
    license_code = sources_list.next().group('lic')

    Log("license_code={}".format(license_code))

    list_key_value = {}

    regex = "(?:video_url|video_alt_url.?): '(?P<url>[^']+).+?(?:video_url|video_alt_url.?)_text: '(?P<res>\d+)p'"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(source_html1)
    for source_list in sources_list:
        if source_list.group('res'):
            list_key_value[source_list.group('res')] = source_list.group('url')
        else:
            list_key_value['240'] = source_list.group('url')
    Log("list_key_value={}".format(list_key_value))

    if len(list_key_value) < 1:
        utils.Notify("Video files not found")
        return
    
    list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
    encoded_url = utils.SortVideos(list_key_value,0)
    video_url = encoded_url

    if video_url.startswith("function/0/"):
        video_url = video_url.split("function/0/")[1]
        Log("video_url={}".format(video_url))
    
    fappy_salt = utils.FaapySalt(license_code, "")
    Log("fappysalt='{}'".format(fappy_salt))
    encoded_fappy_code =  video_url.split('/')[5][0:32]
    Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
##    new_fappy_code = utils.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
##    Log("new_fappy_code='{}'".format(new_fappy_code))
##    video_url = video_url.replace(encoded_fappy_code, new_fappy_code)
    video_url += '?rnd=' + utils.RandomNumber(length=13)


    video_url = video_url + utils.Header2pipestring() + '&Referer=' + url
    Log("video_url={}".format(video_url))


    utils.playvid(video_url, name, download, description=name + '\n' + ROOT_URL)


        
#__________________________________________________________________________
#

