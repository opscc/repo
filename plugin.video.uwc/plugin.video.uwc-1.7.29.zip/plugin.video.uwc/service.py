import random
import threading
import traceback
import xbmc

from resources.lib import constants as C
from resources.lib import downloader
from resources.lib import thread_cache 
from resources.lib import utils
from resources.lib import webcam_db
from resources.lib.utils import Log as Log
from resources.lib.utils import Sleep as Sleep
from resources.lib.utils import get_setting as GetSetting

#__________________________________________________________________
#
monitor = xbmc.Monitor()
#MIN_SLEEP_SECONDS = int(C.addon.getSetting("min_service_interval"))
MIN_SLEEP_SECONDS = GetSetting("min_service_interval", int)
#__________________________________________________________________________
#
class EndingException(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)
#__________________________________________________________________
#
def recording_service(stop_event):
    try:
        while not monitor.abortRequested():
            sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
            Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
            if stop_event.isSet():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_recording_service", bool):
                downloader.scan_and_start_db()
    except EndingException as ex:
##        traceback.print_exc()
        Log(ex.value)
    except:
        traceback.print_exc()


#__________________________________________________________________
#
def reboot_required_detection():
    try:

        import datetime,time
        last_reboot = C.addon.getSetting('last_reboot')
        if last_reboot == '':
            last_reboot = datetime.date(1980, 1, 1).strftime("%Y-%m-%d")
        last_reboot = datetime.datetime(*(time.strptime(last_reboot, "%Y-%m-%d")[0:6]))
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        today = datetime.datetime(*(time.strptime(today, "%Y-%m-%d")[0:6]))
        if not isinstance(last_reboot, datetime.date):
            last_reboot = datetime.date(1980, 1, 1)

        if (last_reboot >= today):  
            Log(repr((last_reboot,today)))
            Log('already restarted today', C.LOGNONE)
        else:
            Log('confirming we are up')
            import socket, platform, subprocess  
    ##        info = socket.gethostbyname_ex("dns.google")[2]
    ##        Log(repr(info))
    ##        Log(repr(dir(info)))
            info = ('8.8.8.7',)
            info = ('8.8.8.8',) 
            import os

            param = '-n' if platform.system().lower()=='windows' else '-c'        
            command = ['ping', param, '2', info[0]]
            result = (subprocess.call(command, stderr=subprocess.STDOUT, shell=True) == 0)
            #result = False
            Log(repr(result))
    ##        response = os.system("ping {}".format(info[0]))
    ##        Log(repr(response))
            if result: #"Received = 4" in response:
                Log("Ping Successful", C.LOGNONE)
            else:
                Log("Ping failed", C.LOGNONE)
                C.this_addon.setSetting(id='last_reboot', value=datetime.datetime.now().strftime("%Y-%m-%d"))
            
                #command = ['shutdown', '-t', '120']
                #Log(repr(command))            
                result = (subprocess.call("shutdown -r -t 120", shell=True) == 0)
                #Log(repr(result))
                pass    
         
    except:
        traceback.print_exc()
#__________________________________________________________________
#
def link_crawler(stop_event):
    sleeptime = 5 #a constant value; long enough for other stuff to start
    if monitor.waitForAbort(int(sleeptime)):
        Log("{} ending due to abort".format(threading.current_thread().name))
        return

    try:
        while not monitor.abortRequested():
            if stop_event.isSet():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_link_crawler", bool):
                webcam_db.clear_webcam_db()
                webcam_db.fill_webcam_db()

            if GetSetting("reboot_required_detection", bool):
                reboot_required_detection()

                
            sleeptime = int(GetSetting("service_periodic_interval", int) * (random.random() ))
            sleeptime = max(sleeptime, GetSetting("min_service_interval", int) )
            Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
    except EndingException as ex:
        Log(ex.value)
    except:
        traceback.print_exc()

    return

##    sleeptime = 5 #a constant value; long enough for other stuff to start
##    Log("{} sleeping {} seconds before next action ".format(repr(threading.current_thread().name), sleeptime) )
##    if monitor.waitForAbort(int(sleeptime)):
##        Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
##        return
##    while not monitor.abortRequested():
##        if stop_event.isSet():
##            Log("ending thread {} due to stop_event".format(repr(threading.current_thread().name)))
##            break
##        #enable_link_crawler = C.addon.getSetting("enable_link_crawler").lower() == "true" ## ... do some work
##        enable_link_crawler = GetSetting("enable_link_crawler") ## ... do some work
##        if enable_link_crawler:
##            try:
##                webcam_db.clear_webcam_db()
##                webcam_db.fill_webcam_db()
##            except:
##                traceback.print_exc()
##        else:
##            Log("enable_link_crawler is false")
##            break
##            
##        ## sleep then ... do some work
##        #sleeptime = int(int(C.addon.getSetting("service_periodic_interval")) * (random.random())  )
##        sleeptime = int(GetSetting("service_periodic_interval", int) * (random.random())  )
##        Log("sleeptime={}".format(sleeptime))
##        sleeptime = max(sleeptime, MIN_SLEEP_SECONDS)
##        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
##        if monitor.waitForAbort(sleeptime):
##            Log("ending thread {} due to abort".format(repr(threading.current_thread().name)))
##            break

#__________________________________________________________________
#
if __name__ == '__main__':

    C.DEBUG = GetSetting('debug')
       
    threading.current_thread().name = C.addon_id+".service"

    proxy_thread_recording_service = None
    recording_service_stop_event = None
    proxy_thread_crawler = None
    crawler_stop_event = None

    thread_cache = thread_cache.uwcSimpleCache()
    thread_cache._identifier = '__main__'
    Log(repr(thread_cache), xbmc.LOGNONE) #log this so that i can confirm that correct cache is always being 

    while not monitor.abortRequested():

        # start thread for link_crawler service
        if GetSetting("enable_link_crawler", bool):
            try:        
                if (not proxy_thread_crawler) or (not proxy_thread_crawler.is_alive()) : 
                    crawler_stop_event = threading.Event()
                    proxy_thread_crawler = threading.Thread(
                        target=link_crawler
                        ,args=(crawler_stop_event,)
                        ,name=C.addon_id+".link_crawler"
                        )
                    proxy_thread_crawler.daemon = True
                    proxy_thread_crawler.start()
                else:
                    pass
            except:
                traceback.print_exc()
        else:
            if proxy_thread_crawler:
                if crawler_stop_event: crawler_stop_event.set()
                proxy_thread_crawler = None


        # start thread for enable_recording_service service
        if GetSetting("enable_recording_service", bool):
            try:
                if (not proxy_thread_recording_service) or (not proxy_thread_recording_service.is_alive()) : # start thread
                    recording_service_stop_event = threading.Event()
                    proxy_thread_recording_service = threading.Thread(
                        target=recording_service
                        ,args=(recording_service_stop_event,)
                        ,name=C.addon_id+".recording_service"
                        )
                    proxy_thread_recording_service.daemon = True
                    proxy_thread_recording_service.start()
                else:
                    pass
            except:
                traceback.print_exc()
        else:
            if proxy_thread_recording_service:
                if recording_service_stop_event: recording_service_stop_event.set()
                proxy_thread_recording_service = None

        ## sleep then ... do some work
        sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        if monitor.waitForAbort(sleeptime):
            Log("{} ending due to abort".format(threading.current_thread().name))
            break

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = GetSetting('debug')

    if proxy_thread_crawler:
        if crawler_stop_event: crawler_stop_event.set()
    if proxy_thread_recording_service:
        if proxy_thread_recording_service: recording_service_stop_event.set()
#__________________________________________________________________
#
