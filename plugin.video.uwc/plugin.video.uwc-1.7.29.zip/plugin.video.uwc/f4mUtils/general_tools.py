#import Cookie
import cookielib
import datetime
import time
import os, errno
import re
import requests
import traceback
import urllib3
import urlparse
import xbmc
import xbmcaddon

import constants as c

this_addon = xbmcaddon.Addon()
DEBUG = (this_addon.getSetting('debug').lower() == "true")
addon_id = str(this_addon.getAddonInfo('id'))
profileDir = this_addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')
cookieJar = cookielib.LWPCookieJar(xbmc.translatePath(cookiePath))
my_http_session = requests.Session()

from urllib3 import PoolManager
proxy = PoolManager()

###__________________________________________________________________
###
#either I set a path to a certificate PEM, or accept warning messages from urllib3, or suppress all urllib3 warnings
# https://wiki.mozilla.org/CA/Included_Certificates
##if C.DEBUG: urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
certPath = os.path.join(os.path.dirname(__file__), "cacert.pem")  # located in same folder as this one

###__________________________________________________________________
###
def Bool(data): #convert an object into True or False; can't trust python's
    return (str(data) in ['true', 'True'])

###__________________________________________________________________
###
def IsNotNone(data):
    return not(str(data) in ['None', 'none', ''])

###__________________________________________________________________
###
def IsNone(data):
    return (str(data) in ['None', 'none', ''])

###__________________________________________________________________
###
def Debugging():
##    return True
    global DEBUG
    try:
        this_addon = xbmcaddon.Addon()
        DEBUG = (this_addon.getSetting('debug').lower() == "true")
    except: DEBUG = True
    return  DEBUG

###__________________________________________________________________
###

def Log(msg="", loglevel=None):
##    xbmc.log(msg , xbmc.LOGNONE)
##    return
    try: 
        msg = "{}:{} {}".format(
            os.path.basename(traceback.extract_stack(limit=2)[0][0])
            ,traceback.extract_stack(limit=2)[0][1]
            ,msg
            )
    except:
        pass
    msg = "{}: {}".format(addon_id, msg)
    if   loglevel is not None: xbmc.log(msg , loglevel)
    elif          Debugging(): xbmc.log(msg , xbmc.LOGNONE)
    else:                      xbmc.log(msg)

###__________________________________________________________________
###
# Modified `sleep` command that honors a user exit request
def Sleep(num, check_interval=c.DEFAULT_SLEEP_INTERVAL_STEP):
    #num will be in milliseconds
    num = int(num)
    sleep_interval = min(check_interval, num)
##    Log("num='{}' sleep_interval='{}'".format(num,sleep_interval))
    while num > 0: #used to include an 'abort requested' check, but but that caused problems
        sleep_interval = min(check_interval, num)
        time.sleep(sleep_interval/1000.0) #convert it to a float seconds - that is how the time wants it
        num = num - check_interval

###__________________________________________________________________
###
def GetCacheDirFileSpec():
    addon = xbmcaddon.Addon()
    profile_dir = addon.getAddonInfo('profile')
    profile_dir = xbmc.translatePath(profile_dir).decode("utf-8")
    temp_path = os.path.join(profile_dir, c.TEMP_CACHE_FILE_FOLDER)
    try:
        os.mkdir(temp_path)
    except OSError as e:
        if e.errno == errno.EEXIST:
            pass
        else:
            raise
##    Log("temp_path='{}'".format(temp_path))
    return temp_path

###__________________________________________________________________
###
def CleanCacheDir():
    temp_path = GetCacheDirFileSpec()
    for root, dirs, files in os.walk(temp_path):
        for name in files:
            filename = os.path.join(root, name)
            mtime = os.path.getmtime(filename)
##            Log(repr(time.gmtime(mtime)))
            if (time.time() - mtime) > 120:  #file modified more than 120 seconds
                DeleteCacheFile(filename)
###__________________________________________________________________
###
def DeleteCacheFile(filespec):
#    traceback.print_stack()
    try:
        if filespec.endswith(c.TEMP_CACHE_FILE_EXT):
            Log("deleting filespec='{}'".format(filespec))
            delete_attempt = 0
            while os.path.exists(filespec) and delete_attempt <= c.TEMP_FILE_MANIPULATION_ATTEMPTS:
                delete_attempt += 1
                Sleep(c.TIME_BEFORE_TEMP_FILE_MANIPULATION)
                try:
                    os.remove(filespec)
                except:
                    if delete_attempt == c.TEMP_FILE_MANIPULATION_ATTEMPTS:
                        traceback.print_exc()
                    pass
            else:
                if not os.path.exists(filespec):
                    Log("{} deleted".format(repr(filespec).replace('\\\\', '\\')))
    except:
        traceback.print_exc()
        
###__________________________________________________________________
###
def TempCacheFile():
    #return writable file object
    import tempfile
    return tempfile.NamedTemporaryFile(
        mode = 'a+b'
        ,suffix = '.tmp.mp4'
        ,dir = GetCacheDirFileSpec()
        ,delete = False
        )
###__________________________________________________________________
###
def Get_URL(url
           ,client_header
           ,stream=False
           ,return_response=False
           ,save_cookie=False
           ,send_back_redirect=False
           ,method='GET'
           ,request_body=''):

##    Log(("getUrl url='{}'"
##         ", send_back_redirect='{}'"
##         ", return_response='{}'"
##         ", save_cookie='{}'"
##         ", stream='{}'"
##         ).format(
##        url
##        ,send_back_redirect
##        ,return_response
##        ,save_cookie
##        ,stream))

    global cookieJar
    response = None
    redirected_url = None

##    Log("clientHeader='{}'".format(clientHeader))
    getHtml_headers={}
    if client_header:
        for n,v in client_header:
            getHtml_headers[n]=v

    try:

        # I don't know how to use cookieJar with SOCKS proxy; fake it using headers
        socks_cookies = ''
        for cookie in cookieJar:
            this_domain = urlparse.urlparse(url).netloc
            if cookie.domain.endswith(this_domain):
                socks_cookies += "{}={};".format(cookie.name,cookie.value)
        if 'Cookie' in getHtml_headers:
            socks_cookies = (socks_cookies + getHtml_headers['Cookie']).rstrip(';')
        if not socks_cookies == '':
            getHtml_headers['Cookie'] = (socks_cookies).strip(';')
##        Log("getHtml_headers={}".format(getHtml_headers), xbmc.LOGNONE)

        response = None
        socks_response = None
        socks_proxy_info = Socks_Proxy_Active()
##        Log("Socks_Proxy_Active usehttpproxy='{uhp}', httpproxyserver='{ps}', httpproxyport='{pp}', httpproxyusername='{un}', httpproxypassword='{up}'".format(**Socks_Proxy_Active()) )
        if (socks_proxy_info['uhp'] in (4,5)) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3.contrib.socks import SOCKSProxyManager
            socks_string = "socks5h://{un}:{up}@{ps}:{pp}/".format(**socks_proxy_info)
            s_proxy = SOCKSProxyManager(proxy_url=socks_string)  #Bases: urllib3.poolmanager.PoolManager, urllib3.request.RequestMethods
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.request.html
            socks_response = s_proxy.request(
                method
                ,url = url
                ,headers = getHtml_headers
                ,preload_content = not(stream)
                )
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if stream:
                data = None #must not read data now...it will be streamed
            else:
                data = socks_response.data

            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None

        elif (socks_proxy_info['uhp'] == 0) :

            #https://urllib3.readthedocs.io/en/latest/reference/contrib/socks.html
            from urllib3 import ProxyManager
            proxy_string = "http://{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp'])
            p_proxy = ProxyManager(proxy_url=proxy_string)  #Bases: urllib3.poolmanager.PoolManager, urllib3.request.RequestMethods
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.request.html
            socks_response = p_proxy.request(
                method
                ,url = url
                ,headers = getHtml_headers
                ,preload_content = not(stream)
                ,timeout=urllib3.Timeout(c.HTTP_TIMEOUT)
                )
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if stream:   data = None #must not read data now...it will be streamed
            else:        data = socks_response.data

            redirected_url = socks_response.geturl()
            if not url == redirected_url:                 Log("redirected_url='{}'".format(redirected_url))
            else:                                         redirected_url = None

        elif (socks_proxy_info['uhp'] < 0) :

            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.request.html
            socks_response = proxy.request(
                method
                ,url = url
                ,headers = getHtml_headers
                ,preload_content = not(stream)
                ,timeout=urllib3.Timeout(c.HTTP_TIMEOUT)
                )
            #https://urllib3.readthedocs.io/en/latest/reference/urllib3.response.html
            if stream:   data = None #must not read data now...it will be streamed
            else:        data = socks_response.data

            redirected_url = socks_response.geturl()
            #if (redirected_url is not None) and (not (url == redirected_url)):
            if (not (url == redirected_url)):                
                Log("url='{}'".format(url))
                Log("redirected_url='{}'".format(redirected_url))
            else:
                redirected_url = None
            
            
##        elif (socks_proxy_info['uhp'] < 0) :
##            if (socks_proxy_info['uhp'] == 0):  proxies = {"https": "{}:{}".format(socks_proxy_info['ps'],socks_proxy_info['pp']) }
##            else: proxies = {}
##
##
##            if DEBUG:
##                verify=False
##                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
##            else:
##                verify = certPath
##            #https://requests.readthedocs.io/en/master/api/#requests.Request
##            response = my_http_session.request(
##                method
##                , url=url
##                , headers=getHtml_headers
##                , stream=stream
##                , verify=verify
##                , proxies=proxies) 
##            #prepped = my_http_session.prepare_request(my_request)
##            #https://requests.readthedocs.io/en/master/api/#requests.Response
##            #response = my_http_session.send(prepped, verify=False, proxies=proxies) # https://requests.readthedocs.io/en/master/api/#requests.Response
##
##            if stream:   data = None #must not read data now...it will be streamed
##            else:        data = response.content
##            
##            redirected_url = response.url 
##            if not url == redirected_url: Log("redirected_url='{}'".format(redirected_url))
##            else: redirected_url = None
            
        if save_cookie == True:
            this_domain = urlparse.urlparse(url).netloc
            if cookieJar is not None and response is not None:
##                if 'Set-Cookie' in response.headers:
##                    for cookie in SetCookie_To_Array_Of_Cookie(response.headers[ 'Set-Cookie' ]) :
##                        if cookie.domain.endswith(this_domain) and not cookie.discard:
##                            cookieJar.set_cookie(cookie)
                for cookie in response.cookies:
                    if not cookie.discard:
                        if this_domain.endswith(cookie.domain) and not(cookie.domain == ''):
                            cookieJar.set_cookie(cookie)
                cookieJar.save(cookiePath, ignore_expires=True, ignore_discard=True)


            if cookieJar is not None and socks_response is not None:
                if 'Set-Cookie' in socks_response.headers:
                    for cookie in SetCookie_To_Array_Of_Cookie(socks_response.headers[ 'Set-Cookie' ]) :
                        #Log(repr(cookie))
                        if cookie.domain.endswith(this_domain) and not cookie.discard:
                            #Log(repr(cookie))
                            cookieJar.set_cookie(cookie)
##            Log(cookiePath)
##            cookieJar.save(cookiePath, ignore_expires=True, ignore_discard=True)

    except requests.exceptions.RequestException as e:
        if DEBUG:
            traceback.print_exc()
            Log(repr(getHtml_headers))
            Log(("getUrl url='{}'"
                 ", send_back_redirect='{}'"
                 ", return_response='{}'"
                 ", save_cookie='{}'"
                 ", stream='{}'"
                 ).format(
                url
                ,send_back_redirect
                ,return_response
                ,save_cookie
                ,stream) , xbmc.LOGNONE)
            Log( repr(e) , xbmc.LOGERROR)
        return None
    except:
        Log("It looks like '{}' is down.".format(url), xbmc.LOGERROR)
        raise

    if send_back_redirect == True:
        return data, redirected_url
    
    if return_response:
        if response:
            return response
        else:
            return socks_response

    return data

#__________________________________________________________________
#
def get_gui_setting(minidom_settings, minidom_id, alternate_prefix='network.'):
    gui_setting = None
    try:
        try:
            version = int(minidom_settings.firstChild.attributes["version"].firstChild.data)
        except:
            version = 1
        if version < 2:
            minidom_node = minidom_settings.getElementsByTagName(minidom_id)
            minidom_node = minidom_node[0]
            if minidom_node.lastChild is None:
                gui_setting = minidom_node.lastChild
            else:
                gui_setting = minidom_node.lastChild.data
        else:
            minidom_id = alternate_prefix + minidom_id
            for element in minidom_settings.getElementsByTagName('setting'):
                if element.hasAttribute('id') and element.getAttribute('id') == minidom_id:
                    if len(element.childNodes) > 0:
                        gui_setting = element.childNodes[0].data 
                    break
    except:
        traceback.print_exc()
        #raise
        #pass
    return gui_setting
#__________________________________________________________________
#
def Socks_Proxy_Active():
    from xml.dom import minidom
    usehttpproxy = False
    httpproxytype = -1
    httpproxyserver = None
    httpproxyport = 0
    httpproxyusername = None
    httpproxypassword = None
    try:
        guisettings_xml = minidom.parse(xbmc.translatePath('special://home/userdata/guisettings.xml'))
        usehttpproxy = get_gui_setting(guisettings_xml, 'usehttpproxy')
        if usehttpproxy and usehttpproxy.lower()=='true':
            httpproxytype = get_gui_setting(guisettings_xml, 'httpproxytype')
            httpproxyserver = get_gui_setting(guisettings_xml, 'httpproxyserver')
            httpproxyport = get_gui_setting(guisettings_xml, 'httpproxyport')
            httpproxyusername = get_gui_setting(guisettings_xml, 'httpproxyusername')
            httpproxypassword = get_gui_setting(guisettings_xml, 'httpproxypassword')
    except:
        traceback.print_exc()
##        raise
##        pass
    finally:
        proxy_info = {
             'uhp' : int(httpproxytype)
            , 'ps' : httpproxyserver
            , 'pp' : int(httpproxyport)
            , 'un' : httpproxyusername
            , 'up' : httpproxypassword
            }
##        Log(repr(proxy_info))
        return proxy_info
    
###__________________________________________________________________
###
def SetCookie_To_Array_Of_Cookie(set_cookie_string):
##    Log("set_cookie_string='{}'".format(set_cookie_string))
    cookies_array = []
    #regex = "(?is)(\s?expires=\w\w\w,\s\d\d-\w\w\w-\d{2,4}\s\d{1,2}:\d\d:\d\d(?:\s?\w{3})?;?)"
    regex = "(\s?expires=(.{27,29})(?:;|,)?)"
    regex = "(\s?expires=([^;]+);)"
    
    set_cookie_string_no_expires = re.sub(regex,'',set_cookie_string, flags=re.IGNORECASE)
##    Log("set_cookie_string_no_expires='{}'".format(set_cookie_string_no_expires))
##    return cookies_array
    #https://docs.python.org/2/library/cookielib.html#cookielib.Cookie.is_expired
    for cook in set_cookie_string_no_expires.split(', '):
        if cook == '': break #in case blank cookie
##        Log("cook='{}'".format(repr(cook)))
        morsels = None
        name=None
        value=None
        port=None
        port_specified=False
        domain=''
        domain_specified=False
        domain_initial_dot=False
        path=''
        path_specified=False
        max_age=None
        expire_date=None
        comment=None
        comment_url=None
        discard=False #True if this is a session cookie
        secure=True #True if cookie should only be returned over a secure connection
        for morsel in cook.split('; '):
##            morsel=morsel.rstrip(';') #in case a cookie has only name/value
##            Log("morsel='{}'".format(repr(morsel)))

            if not '=' in morsel:
                ##single word value
                pass ##I am ignoring these ones
            
            else:
                #morsels = morsel.split("=")
                morsels=[morsel[0: morsel.find("=")] , morsel[morsel.find("=")+len("="): (max(morsel.find(";"), len(morsel)))      ] ]
##                Log(str(morsel.find("=")+len("=")))
##                Log(str(morsel.find(";")))
##                Log(str(max(morsel.find(";"), len(morsel))))
                #Log("morsels='{}'".format(repr(morsels)))
                if morsels[0].lower() == 'path':
                    path=morsels[1]
                    path_specified=True
                elif morsels[0].lower() == 'max-age':
                    max_age=morsels[1] #essentially same info as expires; written as seconds(from now, presumably)which means cookie is only good for current session
##                    Log("morsel='{}'".format(repr(morsel)))
##                    Log("morsels[1]='{}'".format(morsels[1]))
##                    Log("max_age='{}'".format(max_age))
                    max_age=int(max_age)
                elif morsels[0].lower() == 'domain':
                    domain=morsels[1]
                    domain_specified=True
                    if domain[0]=='.': domain_initial_dot = True
                elif morsels[0].lower() == 'port':
                    port=morsels[1]
                    port_specified=True
                elif morsels[0].lower() == 'comment':
                    comment=morsels[1]
                elif morsels[0].lower() == 'samesite':
                    pass
                elif morsels[0].lower() == 'comment_url':
                    comment_url=morsels[1]
                else:
                    name=morsels[0]
                    value=morsels[1]
                    regex = "{}={};.*?expires=([^;]+)".format(re.escape(name),re.escape(value))
##                    Log(regex) 
                    try:
                        expire_date_arr= re.compile(regex, re.DOTALL | re.IGNORECASE).findall(set_cookie_string)
                        if len(expire_date_arr)<1:
                            #discard=True
                            Log("Cant find exipre date for regex='{}'".format(regex))
##                            Log("morsel='{}'".format(morsel))
##                            Log("name='{}'".format(name))
##                            Log("value='{}'".format(value))
##                            Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                            Log("cook='{}'".format(cook))
##                            Log("set_cookie_string='{}'".format(set_cookie_string))
##                            Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))

                        else:
                            expire_date = expire_date_arr[0]
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("(type(datetime.datetime.now())='{}'".format(type(datetime.datetime.now())))
##                            Log("{}".format(datetime.datetime(1970,1,1).strftime("%a, %d %b %Y %H:%M:%S %Z")))
##                            Log("(type(expire_date)='{}'".format(type(expire_date)))
##                            Log("expire_date='{}'".format(expire_date))

                            expire_formats = {"%a, %d-%b-%Y %H:%M:%S %Z"
                                              , "%a, %d-%b-%y %H:%M:%S %Z"
                                              , "%a, %d %b %Y %H:%M:%S %Z"
                                              , "%a, %d %b %y %H:%M:%S %Z" }
                            for expire_format in expire_formats:
                                try:
                                    expire_date = datetime.datetime.strptime(expire_date, expire_format)
##                                    Log("morsel='{}'".format(morsel))
##                                    Log("Match on {}".format(expire_format)) 
                                    expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
##                                    Log("expire_date='{}' type={}".format(expire_date,type(expire_date)))  
                                    break
                                except TypeError:
##                                    Log("TypeError") 
                                    try:
                                        expire_date = datetime.datetime(*(time.strptime(expire_date, expire_format)[0:6]))
##                                      Log("Match on {} with bugfix ".format(expire_format)) 
                                        expire_date = int((expire_date - datetime.datetime(1970,1,1)).total_seconds())
                                        break
                                    except:
                                        traceback.print_exc()
                                        pass
                                    
                                except:
                                    traceback.print_exc()
                                    pass
                                
##                                Log("(type(expire_date)='{}'".format(type(expire_date)))
##                                if type(expire_date) == "<type 'datetime.datetime'>":

##                            Log("final (type(expire_date)='{}'".format(type(expire_date)))
##                            Log("final expire_date='{}'".format(expire_date))
                            if not (type(expire_date) == type(0)):
                                Log("Failed to convert expire_date='{}' using format '{}'".format(expire_date,expire_format))  
##                                Log("expire_date='{}'".format(expire_date))  
##                                Log("morsel='{}'".format(repr(morsel)))
##                                Log("name='{}'".format(repr(name)))
##                                Log("value='{}'".format(repr(value)))
##                                Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
##                                Log("cook='{}'".format(cook))
##                                Log("set_cookie_string='{}'".format(set_cookie_string))
##                                Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                                expire_date = 0
                                

                    except:
                        traceback.print_exc()
                        Log("Error parsing expire value for cookie")
                        Log("name='{}'".format(repr(name)))
                        Log("value='{}'".format(repr(value)))
                        Log("expire_date_arr='{}'".format(repr(expire_date_arr)))                    
                        Log("cook='{}'".format(cook))
                        Log("set_cookie_string='{}'".format(set_cookie_string))
                        Log("set_cookie_string_no_expires='{}'".format(repr(set_cookie_string_no_expires)))
                        if expire_date: #might have been set by maxage
                            expire_date = 0
                        pass
                    
        if max_age:
            expire_date = max_age
        
        ck = cookielib.Cookie(version=0,
                      name=name,
                      value=value,
                      port=port,
                      port_specified=port_specified,
                      domain=domain,
                      domain_specified=domain_specified,
                      domain_initial_dot=domain_initial_dot,
                      path=path,
                      path_specified=path_specified,
                      secure=secure,
                      expires=expire_date,
                      discard=discard,
                      comment=comment,
                      comment_url=comment_url,
                      rest={},
                      rfc2109=False)
##        Log("cook='{}'".format(repr(cook)))
##        Log("ck='{}'".format(repr(ck)))
        cookies_array.append(ck)

    return cookies_array

###__________________________________________________________________
###
def parse_m3u_tag(line):
    if ':' not in line:
        return line, []
    tag, attribstr = line.split(':', 1)
    attribs = []
    last = 0
    quote = False
    for i,c in enumerate(attribstr+','):
        if c == '"':
            quote = not quote
        if quote:
            continue
        if c == ',':
            attribs.append(attribstr[last:i])
            last = i+1
    return tag, attribs

###__________________________________________________________________
###
def parse_kv(attribs, known_keys=None):
    d = {}
    for item in attribs:
        k, v = item.split('=', 1)
        k=k.strip()
        v=v.strip().strip('"')
        if known_keys is not None and k not in known_keys:
            raise ValueError("unknown attribute %s"%k)
        d[k] = v
    return d
###__________________________________________________________________
###
def Choose_M3U8_Stream(url, url_contents, maxbitrate, dumpfile, vod):

##    Log("Choose_M3U8_Stream(url='{}' url_contents='{}' maxbitrate='{:,}')".format(url, url_contents, maxbitrate))

    #vod files don't allow us to pick a rate
    if vod == True:
        Log("vod file detected")
        return url, maxbitrate, maxbitrate, maxbitrate        

    maxbitrate = int(maxbitrate)
    variants = []
    variant = None
##    Log(url_contents)
    for line in url_contents.split('\n'): #.iter_lines()
        #we expect some meta-data in a first line; followed by the url in the second
        if line.startswith('#EXT'):
            tag, attribs = parse_m3u_tag(line)
            if tag == '#EXT-X-STREAM-INF':
                #we only want bitrate column
##                Log(repr(dir(attribs)))
                #attribs2 = parse_kv(attribs, ('METHOD', 'URI', 'IV'))
                #Log(repr(attribs2))
                attribs2 = parse_kv(attribs)
##                Log(repr(attribs2))
##                Log(repr(attribs))
                if 'RESOLUTION' in attribs2:
                    variant = (( 'BANDWIDTH='+attribs2['BANDWIDTH'],'RESOLUTION='+attribs2['RESOLUTION']))
                else:
                    variant = (( 'BANDWIDTH='+attribs2['BANDWIDTH'],'RESOLUTION=None'))
        elif variant:
            variants.append((line, variant))
            variant = None
##    Log("variants:{}".format(repr(variants)))
    #make sure _highest_ bitrate is first e.g. [('chunklist_w383802091_b448000_t64RlBTOjMwLjA=.m3u8' , ['BANDWIDTH=488000', 'NAME="FPS:30.0"', 'CODECS="avc1.42c015,mp4a.40.2"', 'RESOLUTION=426x240']), ('chunklist_w383802091_b1148000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=1258000', 'NAME="FPS:30.0"', 'CODECS="avc1.4d401f,mp4a.40.2"', 'RESOLUTION=854x480']), ('chunklist_w383802091_b3096000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=3396000', 'NAME="FPS:30.0"', 'CODECS="avc1.4d401f,mp4a.40.2"', 'RESOLUTION=1280x720']), ('chunklist_w383802091_b5128000_t64RlBTOjMwLjA=.m3u8', ['BANDWIDTH=5628000', 'NAME="FPS:30.0"', 'CODECS="avc1.640028,mp4a.40.2"', 'RESOLUTION=1920x1080'])]
    # [0] is a url; [1][0] is the 'BANDWIDTH=xxx' value
    # [1] is a list of data for the url
    # bandwidth this the first element of the second list
    s_variants = sorted(variants, key=lambda bit_rate: int(
                                                        bit_rate[1][0].lower()
                                                        .split("',")[0]
                                                        .split("=")[1]
                                                        )
                        ,reverse=True)
    Log("s_variants={}".format(repr(s_variants)))

    if len(variants) == 1:
        #url = urlparse.urljoin(url, variants[0][0])
        choice = 0
        lastbitrate=0
    elif len(variants) >= 2:
        #Log("More than one variant of the stream was provided.")        
        choice = None
        lastbitrate=0
        
        for i, (vurl, vattrs) in enumerate(s_variants):
            for attr in vattrs:
                key, value = attr.split('=')
                key = key.strip()
                value = value.strip().strip('"')
                if key == 'BANDWIDTH':
                    value = int(value)
                    if (value <= maxbitrate) and (value>lastbitrate):
                        choice = i
                        lastbitrate = value
                elif key == 'PROGRAM-ID':
                    pass
                elif key == 'CODECS':
##                    Log("STREAM-CODECS attribute {}".format(key))
                    pass
                elif key == 'RESOLUTION':
##                    Log("STREAM-RESOLUTION attribute {}".format(key))
                    pass
                else:
##                    Log("unknown STREAM-INF attribute {}".format(key))
                    pass


    Log("choice='{}' lastbitrate='{:,}' maxbitrate='{:,}'".format(choice, lastbitrate, maxbitrate))
    if choice is None :
        if maxbitrate < 1:
            Log("probably wants minimum rate, which is usually last")
            choice=len(s_variants)-1
        elif lastbitrate == 0:
            Log("if lastbitrate was never set, then probably wants minimum rate, which is usually last")
            choice=len(s_variants)-1
        else:
            Log("probably wants max rate, which is usually first")
            choice=0

    if choice >= 0:
        try:
            slightly_worse = s_variants[choice+1][1]
        except: #when choice is the last in a list, we can't increment
            slightly_worse = s_variants[choice][1]
    else: #last entry has been chosen
        slightly_worse = s_variants[choice][1]
    for attr in slightly_worse:
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            slightly_worse= int(value)
            break
    Log("slightly_worse={}".format(slightly_worse))


    if choice >= 1:
        try:
            slightly_better = s_variants[choice-1][1]
        except: #when choice is first in a list, we can't increment
            slightly_better = s_variants[choice][1]
    else: #last entry has been chosen
        slightly_better = s_variants[choice][1]
    for attr in slightly_better:
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            slightly_better= int(value)
            break
    Log("slightly_better={}".format(slightly_better))


    for attr in (s_variants[choice][1]):
        key, value = attr.split('=')
        key = key.strip()
        value = value.strip().strip('"')
        if key == 'BANDWIDTH':
            chosen_bitrate= int(value)
            break
    Log("chosen_bitrate={}".format(chosen_bitrate))

    url = urlparse.urljoin(url, s_variants[choice][0])
    Log("chosen stream url is '{:,} bps' at '{}' ".format(chosen_bitrate, url))

##    raise Exception('devtesting')
    return url, chosen_bitrate, slightly_better, slightly_worse

###__________________________________________________________________
###
def Clean_Filename(s, include_square_braces=True, delete_first_color=False):
    if not s: return ''
    s = s.strip('\r')
    if delete_first_color:
        s = (re.sub(u'(?i)\[cOLOR \w+?\].+?\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\].?h(?:d|q)\[\/Color\]','',s))
    s = (re.sub(u'(?i)\[cOLOR \w+?\]','',s))
    s = (re.sub(u'(?i)\[\/Color\]','',s))
    if include_square_braces:
        s = (re.sub(u'(?is)[^A-Za-z0-9~\]\[ ,\'.&_\-]',' ',s))
    else:
        s = (re.sub(u'(?is)[^A-Za-z0-9~     ,\'.&_\-]',' ',s))
    while '  ' in s:
        s = s.replace('  ', ' ')
    return s.strip()
###__________________________________________________________________
###
def Make_HLSRETRYSEEK_file(name):
    import tempfile
##    tmp_file = tempfile.mktemp(
##          dir = GetCacheDirFileSpec()
##        , prefix = Clean_Filename(name)+'.'
##        , suffix = c.TEMP_CACHE_FILE_EXT)
    tmp_file = (
        GetCacheDirFileSpec()
        + '\\'
        + Clean_Filename(name)
        + '.' + 'HLSRETRYSEEK'
        + datetime.datetime.now().strftime(".%Y-%m-%d.%H %M %S")
        + c.TEMP_CACHE_FILE_EXT
    )
    tmp_file = xbmc.makeLegalFilename(tmp_file)
    return tmp_file
###__________________________________________________________________
###
def Size_HLSRETRYSEEK_file(filespec):
    size = 0
    try:
        size = os.stat(filespec).st_size
        Log(repr(size))
        size =  os.path.getsize(filespec)
        Log(repr(size))

    except:
        traceback.print_exc()
    return size
    
    
###__________________________________________________________________
###
