'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]sunporno[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.sunporno.com"
SEARCH_URL = ROOT_URL + '/search/{}/page{}.html'
#https://www.sunporno.com/search/lexi+belle/page2.html
URL_CATEGORIES = ROOT_URL + '/channels/'
URL_RECENT = ROOT_URL + '/page{}.html'
URL_RECENT = ROOT_URL + '/most-recent/?mix=true&pageId={}'
#https://www.sunporno.com/most-recent/?mix=true&pageId=2&_=1654963728067


MAIN_MODE          = C.MAIN_MODE_sunporno
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'
#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
##    utils.addDir(
##        name=C.STANDARD_MESSAGE_CATEGORIES
##        ,url = URL_CATEGORIES
##        ,mode = CATEGORIES_MODE
##        ,iconimage=C.category_icon
##        )
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(
          end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if "<p>Make sure that all words are spelled correctly.</p>" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            regex = '(?:|id="search_results_block")(.+?)(?:id="pagination"|id="wrapBlocks")'
            regex = '(?:class="page-content main"|class="search-headers")(.+?(?:>Show More</a>|id="wrapBlocks"))'
            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
##            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    # parse out list items
    regex = 'class="btime">([^<]+)<.+?href="([^"]+)".+?((?:<span class="icon-hd">HD</span>|<img)).+?src="([^"]+)".+?title="([^"]+)"'
    regex = 'class="pp".+?href="([^"]+)".+?class="btime tm">([^<]+)<.+?img data-src="([^"]+)".+?alt="([^"]+)()"'

    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    #for duration, videourl, hd, thumb, label in info:
    for videourl, duration, thumb, label, hd in info:
    
        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        if not thumb.startswith('http'): thumb =  "https:"  + thumb
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    # next page items
    try:
        regex = 'id="pagination"(.+)'
        regex = '(data-get=\'{ "pageId": "\d+" }\')'
        next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = '<li><a class="pag-next" href="([^"]+)\.html">'  #site will use display:none if no more pages exist instead of omitting the Next element
    next_page_regex = '("pageId": "\d+")'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        np_number = int(page) + 1
        np_url = url
        Log("np_number={}".format(np_number))
        Log("np_url={}".format(np_url))
##            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, C.search_text_color, int(np_number))
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= (max_search_depth):
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)


##        for np_url in np_info:
##            Log("np_url={}".format(np_url))
##            np_url = C.html_parser.unescape(np_url)
###            Log("np_url.split('/')={}".format(np_url.split('/')))
##            np_number = '' 
##            if '/' in np_url: np_url = np_url.strip('/').split('/')[-1]
##            Log("np_url={}".format(np_url))
##            if '?page=' in np_url: np_number = np_url.split('?page=')[1]
##            if '&page=' in np_url: np_number = np_url.split('&page=')[1]
##            if 'page' in np_url: np_number = np_url.split('page')[1]
###            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
##            np_url = url
##
##            break # in case there are multiple pagination
##        
##        for np_url in np_info:
##            Log("np_url={}".format(np_url))
##            np_url = C.html_parser.unescape(np_url)
###            Log("np_url.split('/')={}".format(np_url.split('/')))
##            np_number = '' 
##            if '/' in np_url: np_url = np_url.strip('/').split('/')[-1]
##            Log("np_url={}".format(np_url))
##            if '?page=' in np_url: np_number = np_url.split('?page=')[1]
##            if '&page=' in np_url: np_number = np_url.split('&page=')[1]
##            if 'page' in np_url: np_number = np_url.split('page')[1]
###            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
##            np_url = url
##            Log("np_number={}".format(np_number))
##            Log("np_url={}".format(np_url))
####            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, C.search_text_color, int(np_number))
##            if end_directory == True:
##                utils.addDir(
##                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
##                    ,url=np_url 
##                    ,mode=LIST_MODE 
##                    ,iconimage=C.next_icon 
##                    ,page=np_number
##                    ,section = C.INBAND_RECURSE
##                    ,keyword=keyword )
##            else:
##                if int(np_number) <= (max_search_depth):
##                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
##                    List(url=np_url
##                         , page=np_number
##                         , end_directory=end_directory
##                         , keyword=keyword
##                         , progress_dialog=progress_dialog)
##
##            break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+') #.replace(' ','%20')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    listhtml = utils.getHtml(url)
    regex = 'class="thumbs-container"(.+)id="goupBlock"'
    listhtml = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##    Log("listhtml={}".format(listhtml))
    regex = '<a href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl # + "&format=json&number_pages=1&page={}"
        videourl = videourl + 'page{}.html'
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb) #C.search_icon)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))

    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
##    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string'])
def Playvid(url, name, download=None, playmode_string=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
    if playmode_string: max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    source_html1 = utils.getHtml(url, ROOT_URL)
##    regex = 'data-src="([^"]+\.(?:mp4|flv))"'
    regex = "flashvars.video_url = '(.+?)'"
    sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
    Log("sources_list={}".format(sources_list))
    video_url = sources_list[0]

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name))
        return
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    utils.playvid(video_url, name=name, download=download, description=description)
#__________________________________________________________________________
#
