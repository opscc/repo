'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import xbmc
from resources.lib import search
from resources.lib import utils
from resources.lib.utils import Log as Log
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]moviefap[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.moviefap.com"
SEARCH_URL = ROOT_URL + '/search/{}/relevance/'
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/browse/mr/{}'

MAIN_MODE          = C.MAIN_MODE_moviefap
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1' #default first page

#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon)
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml, redirected_url = utils.getHtml(list_url, send_back_redirect=True)
    if redirected_url: list_url = redirected_url
    if "page that you are looking for does not" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('id="browse_full"')[1].split('id="pagination_holder"')[0]
        except:
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    # parse out list items
    regex = ('<a href="([^"]+)" class="videothumb">'
             '.+?<img src="([^"]+)"'
             #' onMouseOver="[^"]+" onMouseOut="[^"]+" width="[^"]+" height="[^"]+" border="[^"]+" '
             '.+?alt="([^"]+)".+?<div class="videoleft">(\d+[:]\d+)<br')
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, duration in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        hd = utils.Normalize_HD_String(label)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = "{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration=duration
            , desc=ROOT_URL
            )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)


    # next page items
    try:
        next_page_html = listhtml.split('id="pagination_holder"')[1]
    except:
        next_page_html = listhtml
    next_page_regex = '<a href="(/[^"]+/\d+)">next &gt;&gt;</a></div></div>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
            np_number = ''
            if not np_number.isdigit(): np_number=np_url.split('/')[-1]
            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth): #search some more, but not forever
                    utils.Notify(msg=np_url)
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword
                         , progress_dialog=progress_dialog)
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword) + '{}'
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)
    regex = '<a href=\"(https://www\.moviefap\.com/[^\"]+)\"><img src=\"([^\"]+)\" alt=\"([^\"]+)\"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE
            ,page=FIRST_PAGE
            ,iconimage=thumb) #C.search_icon)

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))

    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    elif playmode_string == C.PLAYMODE_DIRECT:  max_video_resolution = 99999 #if 'direct' was chosen, use max available resolution
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None
    
    full_html = utils.getHtml(url, ROOT_URL) #, send_back_response=True)
    
    if any(x in full_html for x in C.VIDEO_NOT_AVAILABLE_WARNINGS):
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), xbmc.LOGNONE)
        return

##    regex = (
##        "<item>.+?<res>(?P<res>\d+)"
##        ".+?<videoLink>(?P<url>[^<]+?)</videoLink>"
##        )
##    source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
##    if 

    #Log(repr(full_html))
    
    regex = "jQuery.ajax\(\{\s+async: false,\s+url: '([^']+)'"
    source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
    Log(repr(source_url2))
    if (video_url is None) and source_url2: #2019 version of page
        source_url2 = source_url2[0]
        source_html2 = utils.getHtml(source_url2, url)
        regex = '<res>(?P<res>[^<]+)<.+?<videoLink>(?P<url>[^<]+)<'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
        video_url = utils.SortVideos(
            sources=sources_list
            ,download=download
            ,vid_res_column=0
            ,max_video_resolution=max_video_resolution
            )
        video_url = C.html_parser.unescape(video_url)
        
        #Log("video_url={}".format(video_url))
        
    if (video_url is None): #2018 version
        regex = 'flashvars.config = escape."([^ ]+)&VID='
        try:
            source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
        except:
            Log("source_html1={}".format(source_html1))
##            import traceback
##            traceback.print_exc()
            raise
        source_url2 = source_url2 + utils.Header2pipestring() + '&Referer=' + url
        #Log("source_url2={}".format(source_url2))
        source_html2 = utils.getHtml(source_url2, url)
        regex = '<videoLink>(.+?)</videoLink>'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
        #Log("sources_list={}".format(sources_list))
        video_url = sources_list[0]

    if not video_url:
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        return
    video_url = video_url + utils.Header2pipestring() + '&Referer=' + url
    if video_url.startswith("/"): video_url = 'https:' + video_url

    Log("video_url='{}'".format(video_url))


    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
##        , download_filespec=download_filespec
        , mode = PLAY_MODE
##        , url_factory = url
##        , icon_URI = icon_URI            
        )
#__________________________________________________________________________
#
