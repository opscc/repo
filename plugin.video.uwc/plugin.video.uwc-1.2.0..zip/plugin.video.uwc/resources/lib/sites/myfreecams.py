'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib2
import re
import sys
import random
import urllib


import inputstreamhelper
import time

try:
    import simplejson
except:
    import json as simplejson   

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib import websocket


import socket

@utils.url_dispatcher.register('270')
def Main():
    List('https://www.myfreecams.com/mfc2/php/online_models_splash.php')


@utils.url_dispatcher.register('271', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml2(url)
    except:
        
        return None
    match = re.compile("model_detail=(.*?)&.*?img src=(.*?)jpg.*?</div>", re.DOTALL | re.IGNORECASE).findall(listhtml)
    for name, img in match:
        url = name
        name = utils.cleantext(name)
        img = img + 'jpg'
        #url = img[32:-17]
        img = img.replace('90x90','300x300')
        #if len(url) == 7:
        #    url = '10' + url
        #else:
        #    url = '1' + url
        utils.addDownLink(name, url, 272, img, '', noDownload=True)
    xbmcplugin.endOfDirectory(utils.addon_handle)
    



@utils.url_dispatcher.register('272', ['url', 'name'])
def Playvid(url, name):
    videourl = myfreecam_start(url)
    if videourl:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")

##        if  videourl.endswith('.m3u8'):
##            listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
##            listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
##            listitem.setProperty("IsPlayable","true")
##            listitem.setPath(str(videourl))

        if  videourl.endswith('.mpd') or ('.m3u8'  in videourl):
            listitem = xbmcgui.ListItem(path=videourl)
            listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
            PROTOCOL = 'mpd'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            listitem.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            if  videourl.endswith('.mpd'):
                listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            else:
                listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            listitem.setProperty("IsPlayable","true")


        if int(sys.argv[1]) == -1:
            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            pl.clear()
            pl.add(videourl, listitem)
            xbmc.Player().play(pl)
        else:
            xbmcplugin.setResolvedUrl(utils.addon_handle, True, listitem)

    else:
        utils.notify('Oh oh','Couldn\'t find a playable webcam link')
        
        
#from iptvplayer

vs_str={}
vs_str[0]="PUBLIC"
vs_str[2]="AWAY"
vs_str[12]="PVT"
vs_str[13]="GROUP"
vs_str[90]="CAM OFF"
vs_str[127]="OFFLINE"
vs_str[128]="TRUEPVT"

def fc_decode_json(m):
    try:
        m = m.replace('\r', '\\r').replace('\n', '\\n')
        #xbmc.log("LMM: camgirl m:%s" % simplejson.dumps(m) , xbmc.LOGNONE)
        return simplejson.loads(m[m.find("{"):].decode("utf-8","ignore"))
    except:
        return simplejson.loads("{\"lv\":0}")

def read_model_data(m):
    global CAMGIRLSERVER
    global CAMGIRLCHANID
    global CAMGIRLUID
    usr = ''
    msg = fc_decode_json(m)


    xbmc.log("LMM: camgirl msg:%s" % simplejson.dumps(msg) , xbmc.LOGNONE)

    global CXID
    global CTXENC
    global TKX
    try:
        CXID = msg['cxid']
        CTXENC = urllib2.unquote(msg['ctxenc'])
        TKX = msg['tkx']
    except:
        pass
        
    try:
        sid=msg['sid']
        level  = msg['lv']
    except:
        return

    vs     = msg['vs']

    if vs == 127:
        return

    try:
        usr    = msg['nm']
        CAMGIRLUID    = msg['uid']
        CAMGIRLCHANID = msg['uid'] + 100000000
        camgirlinfo=msg['m']
        flags  = camgirlinfo['flags']
        u_info=msg['u']

        try:
            CAMGIRLSERVER = u_info['camserv']
            if CAMGIRLSERVER >= 500:
                CAMGIRLSERVER = CAMGIRLSERVER - 500
            if vs != 0:
                CAMGIRLSERVER = 0
        except KeyError:
            CAMGIRLSERVER=0

        truepvt = ((flags & 8) == 8)

        buf=usr+" =>"
        try:
            if truepvt == 1:
                buf+=" (TRUEPVT)"
            else:
                buf+=" ("+vs_str[vs]+")"
        except KeyError:
            pass
    except:
        pass

def myfreecam_start(url):
    global CAMGIRL
    global CAMGIRLSERVER
    global CAMGIRLUID
    global CAMGIRLCHANID
    CAMGIRL= url
    CAMGIRLSERVER = 0

    xbmc.log("LMM:" + url)

    #log into the chat/security server as a guest; these are the server names bsed on try and error 
    xchat=[ 7, 8, 9, 10,
            14, 15, 17, 19, 20,
            21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
            31, 32, 33, 34, 35, 36, 38, 39, 40,
            41, 42, 43, 44, 45, 46, 47, 48, 49,
            56, 57, 58, 59, 60,
            61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
            76, 
            80, 81, 83, 86,
            91, 95, 97,
            105,
            122, 124
          ]

    #connect to one of the chat servers; random since we don't know how to parse page
    #we need to use 8080 because the other choice, https, does not work with websocket
    host = "ws://xchat"+str(random.choice(xchat))+".myfreecams.com:8080/fcsl"
    try:
        xbmc.log('attempt connecting to host ' + str(host), xbmc.LOGNONE)
        ws = websocket.WebSocket()
        ws = websocket.create_connection(host)
        ws.send("hello fcserver\n\0")
        #ws.send("1 0 0 20071025 0 guest:guest\n\0")
        ws.send("1 0 0 20071026 0 guest:guest\n\0")
    except:
        #e = sys.exc_info()[0]
        utils.notify('Oh oh','can not connect to host ' + str(host))
        #utils.notify('Oh oh', str(e))
        time.sleep(6)
        return ''

    xbmc.log("LMM:CAMGIRLSERVER after fcsl" + str(CAMGIRLSERVER))

    rembuf=""
    quitting = 0
    while quitting == 0:
        
        sock_buf =  ws.recv()
        sock_buf=rembuf+sock_buf
        
        rembuf=""
        while True:
            #we expect the server to have sent us something like
            #   00281 0 464189515 0 0 Guest63085001833 0 464189515 1 0001833 0 464189515 1 0020830 1 464189515 0 0 {%22_err%22:0,%22ctx%22:[464189515,0,1,0,0,0,0,5080272],%22ctxenc%22:%2262226968dc%252FWzQ2NDE4OTUxNSwwLDEsMCwwLDAsMCw1MDgwMjcyX

            hdr=re.search (r"(\w+) (\w+) (\w+) (\w+) (\w+)", sock_buf)
            if bool(hdr) == 0:
                break #recv() again for the response we need

            fc = hdr.group(1)

            mlen   = int(fc[0:4])
            fc_type = int(fc[4:]) #the fourth byte is the type we need

            msg=sock_buf[4:4+mlen]

            if len(msg) < mlen:
                rembuf=''.join(sock_buf)
                break


            #xbmc.log("LMM: sockbuf:%s" % sock_buf , xbmc.LOGNONE)
            
            msg=urllib.unquote(msg)

            read_model_data(msg)

            if fc_type == 1:
                ws.send("10 0 0 20 0 %s\n\0" % CAMGIRL)
            elif fc_type == 10:
                read_model_data(msg)
                quitting=1

            sock_buf=sock_buf[4+mlen:]

            if len(sock_buf) == 0:
                break

    ws.close()
    
    xbmc.log("LMM:CAMGIRLSERVER after wsclose" + str(CAMGIRLSERVER))
    
    if CAMGIRLSERVER != 0 and CAMGIRLSERVER != 1046:

        #mobile site
        Url="http://video"+str(CAMGIRLSERVER)+".myfreecams.com:1935/NxServer/ngrp:mfc_"+str(CAMGIRLCHANID)+".f4v_mobile/playlist.m3u8" 

##        try:
##            host = "ws://" + "video"+str(CAMGIRLSERVER)+".myfreecams.com:1935"
##            xbmc.log('attempt connecting to host ' + host, xbmc.LOGNONE)
##            ws = websocket.WebSocket()
##            ws = websocket.create_connection(host)
##        except:
##            e = sys.exc_info()[0]
##            xbmc.log(('attempt connecting to host err:%s' % str(e) ), xbmc.LOGNONE)
##            utils.notify('Oh oh','can not connect to host ' + str(host))
##            #time.sleep(6)
##            #return ''

        can_open_mpd = True
        try:
            head = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
            xbmc.log('attempt connecting to host ' + Url, xbmc.LOGNONE)
            #socket.setdefaulttimeout(3)
            req = urllib2.Request(Url)
            req.add_header('User-Agent', head)
            try:
                aa = urllib2.urlopen(req, timeout=2)
                #xbmc.log("aa contents '%s' " % aa.read(),xbmc.LOGNONE)
                return Url
            except:
                xbmc.log("unable to open Url %s" % Url,xbmc.LOGNONE)
                Url = ''
                
            #try new servers
            Url="https://video{}.myfreecams.com:8444/x-hls/{}/{}/{}/mfc_a_{}.m3u8".format(
                str((CAMGIRLSERVER+500)%1000)
                , CXID
                , CAMGIRLCHANID
                , CTXENC
                , CAMGIRLCHANID
                ) 
            xbmc.log('attempt connecting to host ' + Url, xbmc.LOGNONE)
            req = urllib2.Request(Url)
            req.add_header('User-Agent', head)
            try:
                aa = urllib2.urlopen(req, timeout=2)
                Url = Url +('|user-agent='+head)
                xbmc.log('returning URL host ' + Url, xbmc.LOGNONE)
                return Url
            except:
                xbmc.log("unable to open Url %s" % Url,xbmc.LOGNONE)
                #utils.notify( 'Oh oh', ("URL for {} is not responding".format(CAMGIRL)))
                Url = ''


            if Url == '':
                utils.notify( 'Oh oh', ("URL for {} is not responding".format(CAMGIRL)))

                        
        except Exception, e:
            xbmc.log(('attempt connecting to host err:%s' % str(e) ), xbmc.LOGERROR)
            return ''
                                

        #desktop site
        #Url="https://video"+str(CAMGIRLSERVER)+".myfreecams.com/NxServer/ngrp:mfc_"+str(CAMGIRLCHANID)+".f4v_desktop/manifest.mpd"


        #xbmc.log("LMM:" + Url)

        return Url
    else:
        pass




