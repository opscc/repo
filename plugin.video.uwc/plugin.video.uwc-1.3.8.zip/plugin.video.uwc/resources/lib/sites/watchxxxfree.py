'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

addon = utils.addon

BASE_URL = "https://watchxxxfreeinhd.com/"
SEARCH_URL = BASE_URL + "page/1/?s="

@utils.url_dispatcher.register('10')
def WXFMain():

    utils.addDir("[COLOR {}]Search[/COLOR]".format(utils.search_text_color), SEARCH_URL ,14,'','')
    WXFList(url = (BASE_URL + "page/1/?filtre=date&cat=0") )
    utils.add_sort_method()
    utils.endOfDirectory()


@utils.url_dispatcher.register('14', ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 14)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        WXFList(searchUrl, end_directory)
        if end_directory == True:
            utils.add_sort_method()
            utils.endOfDirectory()


@utils.url_dispatcher.register('11', ['url'], ['end_directory'])
def WXFList(url, end_directory=True):

    Log("listing='{}'".format(url))

    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None

    match = re.compile('src="([^"]+)".class="attachment-thumb_site.*?title="([^"]+)".*?<a href="([^"]+)".*?class="time-infos".*?>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)    
    for img, name, videopage, time_info in match:
        name = utils.cleantext(name)
        time_info = utils.cleantext(time_info)
        utils.addDownLink(name, videopage, 13, img, time_info)

    nextp=re.compile('<link rel="next" href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if nextp:
        nextp=nextp[0]
        Log(nextp)
        if "/search/" in nextp: #is a search url
            next_page = nextp.split('/')[6]
        else: #normal url
            next_page = nextp.split('/')[4]
        
        curr_page = str(int(next_page) - 1)
        spacing_for_next = ""
        
        url = url.replace('/page/'+curr_page+'/', '/page/'+next_page+'/')
        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(spacing_for_next,utils.search_text_color, next_page)
        Log(url)
        Log(np_label)

        if end_directory == True:
            utils.addDir(np_label, url, 11, '', Folder=True)
            utils.add_sort_method()
            utils.endOfDirectory()
        else:
            utils.Notify(msg=url, duration=2000)  #let user know something is happening
            WXFList(url, end_directory)


@utils.url_dispatcher.register('13', ['url', 'name'], ['download'])
def WXFVideo(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)


