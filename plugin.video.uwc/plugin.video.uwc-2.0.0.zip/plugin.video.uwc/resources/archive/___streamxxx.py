'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    2022-11 requires login?
'''

import re
from resources.lib import utils
from resources.lib.utils import Log
from resources.lib.utils import cleantext
from resources.lib.utils import get_setting as GetSetting
from resources.lib import constants as C

FRIENDLY_NAME = '[COLOR {}]streamxxx[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_MOVIES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://streamxxx.tv"
SEARCH_URL = ROOT_URL + '/page/{}/?s={}'
URL_CATEGORIES = ROOT_URL + '/top-tags/'
URL_CLIPS = ROOT_URL + '/category/clips/'
URL_RECENT = ROOT_URL + '/page/{}/'

MAIN_MODE          = C.MAIN_MODE_streamxxx
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
##    utils.addDir(
##        name=C.STANDARD_MESSAGE_CATEGORIES 
##        ,url = URL_CATEGORIES
##        ,mode = CATEGORIES_MODE
##        ,iconimage=C.category_icon)
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE)
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, ROOT_URL)
    if "but nothing matched your search" in listhtml:
        video_region = ''
        list_url = ''
    try: #distinguish between adverts and videos
        regex = 'id="search_results"(.+)'
        if not ('new-porn-videos-released' in url):
            video_region = listhtml.split('class="st-site-main')[1].split("class='page-numbers'")[0]
        else:
            video_region = listhtml.split('<div class=webwarez>')[1].split("<aside")[0]
    except:
        video_region = listhtml
    #Log("video_region='{}'".format(video_region))

    # main list items
    if not ('new-porn-videos-released' in url):
        videos_regex = "(?:<article id=|class=\"quadrato\").*?<a href=\"([^\"]+)\".*?title=\"([^\"]+)\".*?src=\"([^\"]+)\"" 
        videos_regex = (
            '(?:<article id=|class="quadrato").+?<a href=(?P<videourl>[^\s]+) title="(?P<label>[^"]+)".+?src=(?P<thumb>[^\s]+)'  #someone removed quotes from template???
            '(?P<hd>)'
            '(?P<duration>)'
            '(?P<desc>)'
            )
    else:
        videos_regex = (
            '<img.+?src=(?P<thumb>.+?\.(?:gif|jpg|png|jpeg))'
            '.+?(?:alt="|<br>)(?P<label>.+?)(?:"|</a)'
            '.+?href=(?P<videourl>.+?)</p>'
            '(?P<hd>)'
            '(?P<duration>)'
            '(?P<desc>)'
            )
        
    info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).finditer(video_region)
    len_info = list()
    for item in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()


        videourl = item.group('videourl')
        thumb = item.group('thumb')
        label = item.group('label')
        len_info.append(videourl)

        if ('new-porn-videos-released' in videourl):
            #2021-05 site now has 'daily' panes that must be sub-searched
            List(url=videourl, end_directory=False, testmode=testmode, progress_dialog=progress_dialog)
            continue
        hd = utils.Normalize_HD_String(label) #2019-07-06 all? of the 4k inside file lockers, so this label may not mean much
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        thumb = thumb.replace(".pixhost.org/", ".pixhost.to/")
        if videourl.startswith('/'): videourl = ROOT_URL + videourl

        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE
            , desc='\n' + ROOT_URL
            , play_method = None #C.DEFAULT_PLAYMODE
            , iconimage = thumb)
            
    utils.Check_For_Minimum(len_info, keyword, MAIN_MODE, ROOT_URL, testmode)

    if (testmode == True) and (len(videourl) > 1):
        Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)


    #
    # next page items
    #
    try:
        next_page_html = listhtml.split("<ul class='page-numbers'")[1]
    except:
        next_page_html = listhtml
    next_page_regex = 'next page-numbers" href="?.+?page/(\d)/.+?>Next<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_number in np_info:
        np_url=url
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth: #search some more, but not forever
                utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)
        break

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format('{}', keyword)
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))        
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    #no categories 2021-05
    return
    
    html = utils.getHtml(url, ROOT_URL)

    clips_regex = 'FILMS(.+)TOP TAGS'
    clips_html = re.compile(clips_regex, re.DOTALL).findall(html)
    #Log("clips_html='{}'".format(clips_html))
    if clips_html:
        clips_html = clips_html[0]
        clips_regex = 'li id="menu-item.+?href="([^"]+)">([^<]+)<'
        info = re.compile(clips_regex, re.DOTALL | re.IGNORECASE).findall(clips_html)
        #Log("info='{}'".format(info))
        for url, label in info:
            if url.startswith('/'): url = ROOT_URL + url
            #Log("url='{}'".format(url))
            utils.addDir(
                name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
                ,url=url 
                ,mode=LIST_MODE 
                ,iconimage=C.search_icon 
                )

    tags_region_regex = '>Top Tags<(.+?)</main>'
    tags_region_html = re.compile(tags_region_regex, re.DOTALL | re.IGNORECASE).findall(html)
    if tags_region_html:
        #Log("tags_region_html='{}'".format(tags_region_html))
        tags_region_html = tags_region_html[0]
        regex = 'a id="tag.+?href="([^"]+)" rel="tag">([^<]+)<'
        regex = 'id=tag.+?href=([^\s]+) rel=tag>([^<]+)<' #some reason, getting rid of quotes
        info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(tags_region_html)
        Log("info='{}'".format(info))
        for url, label in info:
##            label = label.encode('unicode-escape').decode('utf8')
##            label = label.decode('utf8')
##            assert isinstance(label, unicode)
##            label = unicode(label)
##            label = u"{}".format(label.decode('unicode-escape'))
            label = label #.decode('utf8')
            #Log("label='{}'".format(label))
            url = url + '/page/{}/'
            #
            utils.addDir(
                name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
                ,url=url 
                ,mode=LIST_MODE 
                ,iconimage=C.search_icon
                ,page=FIRST_PAGE
                )

    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))

    #force user to specify a keyword to search for because not all searches
    #will 'succeed' or 'fail' reliably
    if not keyword:
        prev_keyword = GetSetting('quick_search_string')
        keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
        if  keyword == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=keyword)
    #self.Categories(URL_CATEGORIES, False)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)

    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    
    utils.endOfDirectory(end_directory=end_directory)
##    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
##    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
##    Categories(URL_CATEGORIES, False)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,cleantext(name),download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None #final playable url

#    videopage = url
    videopage = utils.getHtml(url, ROOT_URL)
    regex = 'class="st-content-area(.+?)class=search-form'
    videopage = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    if videopage:
        videopage = videopage[0]
    else:
        videopage = url
        
##    Log(videopage.encode('utf8'))

    from resources.lib import resolver
    video_url = resolver.resolve_video(videosource=videopage, name=name, url=url)
    if not video_url:
        utils.Notify(u"No video file found for {}".format(name))
        return


    #what if we fail to get a url??
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        return
        
    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return   #during testmode, only ensure that a url can be generated

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , mode = PLAY_MODE
        , url_factory = url
        )
#__________________________________________________________________________
#

