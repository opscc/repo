'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import re
#import internal addon libraries
import utils
from base_website import Base_Website
import constants as C
#define frequenctly used aliases
from utils import Log,LogR

class Specific_Website(Base_Website):
    
    _FRIENDLY_NAME = '[COLOR {}]PornTrex[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True

    _MAIN_MODE = C.MAIN_MODE_porntrex
    
    _ROOT_URL           = "https://www.porntrex.com"
    _URL_RECENT         = _ROOT_URL + "/latest-updates/{}/"
    _URL_CATEGORIES     = _ROOT_URL + '/categories/'
    _SEARCH_URL         = _ROOT_URL + "/search/{}/?mode=async&function=get_block&block_id=list_videos_videos&q={}&category_ids=&sort_by=relevance&from={}"



    _FIRST_PAGE = '1' #Note:site does not support page1.html

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = 'class="porntrex-box"(.+?)class="pagination"'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        'The video you were looking for is no longer exist due to an DMCA claim or simply deleted'
        ]

    #videos on this page    
    _REGEX_list_items = (
        '<img class=\"cover lazyload\"\s*data-src=\"(?P<thumb>[^\"]+)\"'
        '.+?class="quality">(?P<hd>[\d]+)'
        '.+?clock-o\"><\/i>(?P<duration>[^<]+)'
        '.+?href=\"(?P<videourl>[^\"]+)\"'
        '.+?title=\"(?P<label>[^\"]+)\"'
        )

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'class="pagination"(.+)'
    #not working 2024-12-17 _REGEX_next_page_regex =  'class="next"><a href="([^"]+)".+?from(?:_videos\+from_albums|4|):(\d+)"'
    _REGEX_next_page_regex =  'class="next"><a aria-label="pagination" href="([^"]+)"'
    
    #where categories can be found
    _REGEX_categories_region = '"list-categories"(.*)class="footer-margin'
    _REGEX_categories = (
        'href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
        )

    #where playable urls live
    _REGEX_playsearch_01 = (
        "video(?:_alt|)_url\d?: '(?P<url>[^']+)',"
        ".+?"
        "(?:class='|video(?:_alt|)_url\d?_text: ')(?P<res>\d+)"    
       )
##2024 mostly works, but misses when RES is not defined
##        "video(?:_alt|)_url\d?: '(?P<url>[^']+)',"
##        ".+?video(?:_alt|)_url\d?_text: '(?P<res>\d+)"    

    #description for the playable url
    _REGEX_tags = None #"href='/pornstar/.+?>([^<]+)<"
    _REGEX_tags_region = None#'<div id="data-video">(.+?)<div class="clear">'


    #ways to rebuild icon
    _REGEX_icon_search = (
        '.+?property="og:image" content="(?P<thumb>.+?)"'
        )
    #__________________________________________________________________________
    #
    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
        Log(u"Icon_Search url={}, pattern={}, referer={}".format(repr(url),repr(pattern),repr(referer))
            , C.LOGNONE
            )
        if not referer.endswith("/"): referer += "/" #site needs this
        page_content = utils.getHtml(url, referer)
        info = re.compile(pattern, re.DOTALL | re.IGNORECASE).finditer(page_content)
        for item in info:
            thumb = item.group('thumb')
            if thumb and not thumb.startswith('http'): thumb = 'https:' + thumb
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
            return thumb + utils.Header2pipestring(headers)
        return None
    
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return url + '?mode=async&function=get_block&block_id=list_videos_common_videos_list_norm&from4={}'

    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        headers = None #2022-12 thumbs need referrer
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
        if headers:
            thumb = thumb + utils.Header2pipestring(headers)
        return thumb
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        headers = None #2022-12 thumbs need referrer
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
        if headers:
            thumb = thumb + utils.Header2pipestring(headers)
        return thumb
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args)>0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args)>1): keyword = args[1]
        elif (args is not None) and (len(args)>0): keyword = args[0]
        else                                     : keyword = ""

##        keyword_1 = keyword.replace('+',' ').replace(' ','%20')
##        keyword_2 = keyword_1.replace('%20','+')
        keyword_1 = keyword.replace('+',' ').replace(' ','-')
        keyword_2 = keyword_1.replace('-','+')

        return search_url.format(keyword_1,  keyword_2, '{}')

    #__________________________________________________________________________
    # Change LIST to enable max recurse depth
    C.MAX_RECURSE_DEPTH
    def List(self, url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
        Log(u"List(url={}, page={}, end_directory={}, keyword={}".format(repr(url), repr(page), repr(end_directory), repr(keyword)))
        org = C.MAX_RECURSE_DEPTH
        C.MAX_RECURSE_DEPTH = 10
        #py3
##        class Foo(Bar):
##    def baz(self, **kwargs):
##        return super().baz(**kwargs
        #python 2
        super(Specific_Website, self).List(url, page=page, end_directory=end_directory, keyword=keyword, testmode=testmode, progress_dialog=progress_dialog)
        C.MAX_RECURSE_DEPTH = org
##        LogR(locals())

    

#__________________________________________________________________________
#
website = Specific_Website() #always need this
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
    LogR(locals())
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
