'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin

import utils
import search
from utils import Log
import constants as C
import resolver
        
FRIENDLY_NAME = '[COLOR {}]freeomovie[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_MOVIES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.freeomovie.to"
SEARCH_URL = ROOT_URL + '/?s='
URL_RECENT = ROOT_URL + '/page/{}/'
URL_CATEGORIES = ROOT_URL

MAIN_MODE          = C.MAIN_MODE_freeomovie
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , keyword = 'sex'
            )
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=C.category_icon )
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)
#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={})".format(repr(url), repr(page), repr(end_directory), repr(keyword)))

    if not progress_dialog: progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    
    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    listhtml = utils.getHtml(list_url)

    regex = ('class="thumi"'
            '.+?<a href="([^"]+)"'
             '.+?title="([^"]+)">'
             '.+?src="([^"]+)" alt="'
             )

    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label, thumb in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
##        Log(thumb)
        if '.fastpic.' in thumb:
            thumb = thumb+'|Referer%3A+https%3A%2F%2Ffastpic.org%2F' #hoster needs this sometimes

        label = utils.cleantext(label)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    if (testmode == True) and (len(info) > 1):
        Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)


    next_page_regex = "class=\"nextpostslink\".+?href=\"([^\"]+)\""
    next_page_regex = "class=\"pager\".+?(\d+)/' class='page page-next'>"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    for np_url in np_info:
        np_url = url
        np_number = int(page) + 1
        if end_directory == True:
            utils.addDir(
                name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                ,url=np_url 
                ,mode=LIST_MODE 
                ,iconimage=C.next_icon 
                ,page=np_number 
                ,section = C.INBAND_RECURSE
                ,keyword=keyword )
        else:
            if int(np_number) <= max_search_depth:
                utils.Notify(msg=np_url)  #let user know something is happening
                List(url=np_url
                     , page=np_number
                     , end_directory=end_directory
                     , keyword=keyword
                     , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    searchUrl = SEARCH_URL + keyword.replace(' ','+')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))       
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    html = utils.getHtml(url, ROOT_URL)

    regex = '"cat-item.+?href="([^"]+)".*?>([^<]+)'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    for url, label in info:
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=url+'/page/{}' 
            ,mode=LIST_MODE
            , page=FIRST_PAGE
            ,iconimage=C.search_icon
            )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
##def Test(keyword):
##    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
##    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
##    Categories(URL_CATEGORIES, False)
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword=keyword, testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    Categories(URL_CATEGORIES, False)
    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    name = utils.cleantext(name)
    Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None

    needs_resolving_source = utils.getHtml(url, ROOT_URL)




    match = re.search(r'<iframe\s.+src="([^"]+)', needs_resolving_source)
    if match:
        video_url = resolver.resolve_video(
            videosource=match.group(1)
            , name=name
            , download=download
            , url=url
            , ask_which_file_hoster=not(testmode))

    Log("video_url={}".format(video_url))

##    utils.playvid(video_url, name=name, download=download, description=description)
    #we should have a url by now...
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(url, ROOT_URL))
        return

    if video_url and not '|' in video_url:
        headers = C.DEFAULT_HEADERS.copy()
    ##    headers['Connection'] = 'keep-alive'
        headers['Referer'] = url
        headers.pop('verifypeer')
        video_url = video_url + utils.Header2pipestring(headers)

    Log("video_url={}".format(video_url), xbmc.LOGNONE)
    
    #during testmode, only ensure that a url can be generated
    if testmode:
        Log("Would have played video_url; but in test mode")
        return

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
##        , download_filespec=download_filespec
        , mode = PLAY_MODE
##        , url_factory = url
##        , icon_URI = icon_URI            
        )

    
#__________________________________________________________________________
#
