'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import sqlite3
import xbmc
import xbmcvfs
import utils
from utils import Log
import constants as C
import downloader
    
FRIENDLY_NAME = '[COLOR {}]StreamMate[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.streamate.com"
COOKIE_LOADER = ROOT_URL # +'/?Xld_rct=1' #this site needs some cookies to be loaded
#URL_FEMALES = 'http://api.naiadsystems.com/search/v1/list?results_per_page={}' 
##URL_FEMALES = 'https://member.naiadsystems.com/search/v3/performers?domain=streamate.com&from={}&size={}&useProductScore=false&enableProfileScore=false&enableLocalBoostIQForUSOnly=true&filters=gender:f,ff%3Bonline:true&boostedFilters=true&excludedFilters=&country=&language=en&genderSetting=f'
##https://member.naiadsystems.com/search/v3/performers?domain=streamate.com&from=0&size=48&useProductScore=false&enableProfileScore=false&enableLocalBoostIQForUSOnly=false&filters=gender:f,ff,mf,tm2f,g%3Bonline:true&boostedFilters=&excludedFilters=&country=CA&language=en&genderSetting=f
##https://member.naiadsystems.com/search/v3/performers?domain=streamate.com&from=0&size=48&enableLoggedOutRecommender=false&useSearchSnapshot=true&filters=gender:f,ff,mf,tm2f,g%3Bonline:true&boostedFilters=&excludedFilters=&notExactBoostedFilters=&country=CA&language=en&index=default&genderSetting=none  #2022-05
#URL_FEMALES = ROOT_URL + '/search.php?F_0=504&filter_rating=none&results_per_page={}&sort_feature=none&sort_language=none&sort_region=none&pagenum={}&sssjson=1'  #2022-03
#https://www.streamate.com/search.php?filter_rating=none&results_per_page=50&sort_feature=none&sort_language=none&sort_region=none&pagenum=2&sssjson=1
#F_0=503& is male

URL_FEMALES = "https://member.naiadsystems.com/search/v3/performers?domain=streamate.com&from={}&size=48&enableLoggedOutRecommender=false&useSearchSnapshot=true&filters=gender:f,ff%3Bonline:true&boostedFilters=&excludedFilters=&notExactBoostedFilters=&country=&language=en&index=default&genderSetting=none"  #2022-05

SEARCH_URL = 'stub - make all sites consistent'

MAIN_MODE       = C.MAIN_MODE_streamate
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
REFRESH_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)
TEST_MODE       = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

RESULTS_PER_PAGE = 48

THUMBNAILS_FOR_SITE = "object-cdn.icfsys.com"

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():

    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )
        
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_FEMALES, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)
#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page=1, depth=1, notify=False, progress_dialog=None):
    Log(repr((url, page, depth, notify)))

    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    if '{}' in url and page:
        list_url = url.format(int(RESULTS_PER_PAGE) * (int(depth)), page)  #format the string to give us the exact number we need e.g. if depth=2 we should return RESULTS_PER_PAGE*2
        list_url = url.format(int(RESULTS_PER_PAGE) * (int(page)-1))

    Log("list_url='{}'".format(repr(list_url)))

    json_items = json.loads("[]")

    headers = C.DEFAULT_HEADERS.copy()
    headers['Accept'] = 'application/json, text/plain, */*'
    headers['Referer'] = ROOT_URL
    headers['platform'] = "SCP"

    #get a cookie first
    response = utils.getHtml(ROOT_URL
                             , send_back_response=True
                             ) #, cookie_domain="member.naiadsystems.com")
    if response:
        for c in response.cookies:
            if c.name in ('smeid', 'smtid', 'smvid'):
                headers[c.name] = c.value

    #use cookie to get the rest
    json_html = utils.getHtml(list_url
                              , headers=headers
                              , save_cookie=True
                              , cache_duration=C.default_ISONLINE_cache_duration
                              )
    if not json_html: return json_items
    json_items = json.loads(json_html)['performers']
    
    for json_item in json_items:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        performerID = str(json_item['id'])
        icon_image = "https://object-cdn.icfsys.com/smconnect-snapshots/320x240/" + performerID + ".jpg"  #current preformance thumb 2024 this returns invalid an encoding packet; but i could save to disk manually to force it
        icon_image = json_item['thumbnail'] #generic thumb
        video_url = performerID
        name = utils.cleantext(json_item['nickname'])
        camscore = json_item['rating']
        hd = ''
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, name, hd)

        json_item['username'] = name
        json_item['icon_label'] = label
        json_item['icon_image'] = icon_image
        json_item['video_url'] = name
        json_item['camscore'] = camscore
        json_item['mode'] = PLAY_MODE
        json_item['description'] = '\n' + ROOT_URL
        json_item['play_method'] = '' #blank so that defaut method is chosen a play time
        
        
    return json_items

#__________________________________________________________________________
#
##@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
##def List(url, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=None):
##    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page='{}', end_directory='{}', keyword='{}')".format(url, page, end_directory, keyword))
    
    utils.Add_Refresh_Item(REFRESH_MODE, end_directory=end_directory)
        
    models = GetCamgirlList(url=url, page=page, progress_dialog=progress_dialog)
    for model in models:
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            , date = model['username']
            )
    if (progress_dialog is None) or (progress_dialog and not progress_dialog.iscanceled()):
        if (testmode == True) and (len(models) > 1):
            Playvid(model['video_url'], model['icon_label'], icon_URI=model['icon_image'], download=True, playmode_string=None, testmode=testmode)


    #no practical way to find out the last page; always add Next button
    np_number = int(page) + 1
    np_url = url
    if end_directory == True:
        utils.addDir(
            name= C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
            ,url=np_url 
            ,mode=LIST_MODE 
            ,iconimage=C.next_icon 
            ,page=np_number
            ,keyword=keyword )

    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
def clean_database(showdialog=True):
    #return True
    conn = sqlite3.connect(xbmcvfs.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % THUMBNAILS_FOR_SITE)
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % THUMBNAILS_FOR_SITE)
            if showdialog:
                utils.notify('Finished','streamate.com images cleared')
    except:
        pass
#__________________________________________________________________________
#
@C.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name', 'img'], ['playmode_string', 'download', 'play_profile'])
def Playvid(url, name, icon_URI, download=None, playmode_string=None, play_profile=None, testmode=False):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    description = name + '\n' + ROOT_URL
    video_url = None #final playable url


    #
    # do stuff to get a playable url
    #
    name = url

    json_url = "https://manifest-server.naiadsystems.com/live/s:{}.json".format(name)

    Log("json_url='{}'".format(json_url))
    streamate_headers = C.DEFAULT_HEADERS.copy()
    streamate_headers['Referer'] = "{}/cam/{}".format(ROOT_URL, name)
    streamate_headers['Accept'] = "application/json"
    referer = "{}/cam/{}".format(ROOT_URL, name)
    
    json_html = utils.getHtml(json_url, referer=referer, headers=streamate_headers, ignore404=True, ignore403=True)
    if not json_html:
        utils.Notify("{} is unavailable".format(name))
        return

    json_data = json.loads(json_html)

    max_rez = 0
    rez = 0
    if not max_video_resolution:  max_video_resolution = 8888888
    try:
        for opt in json_data['formats']['mp4-hls']['encodings']:
##            Log(repr(type(opt)),C.LOGNONE)
            rez = int(opt['videoWidth'])
            if rez > max_rez and rez <= max_video_resolution:
                max_rez = rez
                video_url = opt['location']
    except:
##        raise
        video_url = json_data['formats']['mp4-hls']['manifest']
        
##    Log("video_url='{}'".format(video_url))
##    raise Exception(video_url)

    if playmode_string == C.PLAYMODE_INPUTSTREAM:
        Log("inputstream does not work for this site ... going direct")
##        playmode_string = C.PLAYMODE_DIRECT

    Log("video_url='{}'".format(video_url)  )

    #calculate potential download name here because I want to include recording date
    download_filespec = downloader.Make_download_path(
        name = name
        , include_date = True
        , file_extension = '.ts'
        )

    Log("video_url='{}'".format(video_url))
    if testmode:
        Log("Would have played video_url; but in test mode")
        return   #during testmode, only ensure that a url can be generated

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI
        , repeat_when_available = True
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'])
def Search(searchUrl, keyword=None, end_directory=True, page=0, progress_dialog=None):
    #stub
    return True
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=False):
    Log("Test(keyword='{}', end_directory='{}')".format(keyword, end_directory))
    return True

    if not keyword:
        prev_keyword = utils.get_setting('quick_search_string')
        if prev_keyword: keyword = prev_keyword
    if not keyword:
        keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
        if  keyword == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=keyword)

    List(URL_FEMALES, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    clean_database()

    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
