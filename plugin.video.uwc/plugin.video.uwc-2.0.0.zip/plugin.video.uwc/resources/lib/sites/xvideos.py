'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import traceback
import xbmc
import utils
from utils import Log as Log
import constants as C

FRIENDLY_NAME = '[COLOR {}]xVideos[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.xvideos.com"
_ROOT_URL = ROOT_URL
SEARCH_URL = ROOT_URL + '/?k={}&p={}'
URL_CATEGORIES = ROOT_URL
URL_RECENT = ROOT_URL  + '/new/{}/'
URL_TOPRATED = ROOT_URL + "/top-rated-porn-videos/page/{}/"
URL_MOSTVIEWED = ROOT_URL + "/most-viewed-porn-videos/page/{}/"

MAIN_MODE       = C.MAIN_MODE_xvideos
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)
TEST_MODE       = str(int(MAIN_MODE) + 5)
REBUILD_ICON       = str(int(MAIN_MODE) + 6)

FIRST_PAGE = '1'
#__________________________________________________________________________
#  
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , keyword = 'sex'
            )
        
    utils.addDir(
        name=C.STANDARD_MESSAGE_CATEGORIES 
        ,url = URL_CATEGORIES
        ,mode = CATEGORIES_MODE
        ,iconimage=C.category_icon
        )
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    # read html
    listhtml = utils.getHtml(list_url, ROOT_URL)
    if ("(No result)" in listhtml) or ("but no results were found" in listhtml):
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        #video_region = listhtml.split('id="main"')[1].split('class="pagination "><ul>')[1]
        regex = 'id="main"(.+)<div class="pagination "><ul>'
        video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
        if video_region: video_region = video_region[0]
        else: video_region = listhtml
##    Log("video_region={}".format(video_region))

    #
    # parse out list items
    #
    regex = (
        'href="(?P<videourl>\/video\d+[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        #'.+?class=\"video-(?:hd|sd)-mark\">([^<]+)<'
        '(?P<hd>)'
        '.+?title="(?P<label>[^"]+)"'
        '.+?class="duration">(?P<duration>[^<]+)<'
        '.+?(?P<desc>)'
        )
    regex = (
        'data-src="(?P<thumb>[^"]+)"'
        '.+?href="(?P<videourl>[^"]+)"'
        '(?P<hd>)'
        '.+?title="(?P<label>[^"]+)"'
        '.+?class="duration">(?P<duration>[^<]+)<'
        '.+?(?P<desc>)'
        )
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for thumb, videourl, hd, label, duration, description in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()
            
        hd = utils.Normalize_HD_String(hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        label = u"{}{} {}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl  
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration
            )
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)
    if (testmode == True) and (len(videourl) > 1):
        Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)
            
    # next page items
    try:
        next_page_html = listhtml.split('class="pagination "><ul>')[2]
    except:
        next_page_html = ""
    next_page_regex = '<li><a href=".+/?(?:(\d+)|.+p=(\d+))/?" class="no-page next-page"><span class="mobile-hide">Next<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            if page: np_number = int(page) + 1
            else: np_number = 1
            np_url = url
            Log("np_url={}".format(np_url))
            if keyword: np_label =  C.STANDARD_MESSAGE_NEXT_PAGE.format(int(np_number))
            else: np_label = C.STANDARD_MESSAGE_NEXT_PAGE.format(int(np_number)) #hack to make things look nice.  Site starts with zero for non-searches
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword
                         , progress_dialog=progress_dialog)
            break # in case there are multiple pagination
                    
    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)
    
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        import search
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page) == '-1'))
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}')".format(url,name,download,playmode_string,play_profile))
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution=int(playmode_string)
    else: max_video_resolution = 999999
##    Log(repr(max_video_resolution))
    description = name + '\n' + ROOT_URL
    video_url = None
    
    source_html = utils.getHtml(url, ROOT_URL)
    
    regex_model = '<a href="(?:/pornstars/|/model-channels/|/models/).+?<span class="name">(?P<model>[^<]+)<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).findall(source_html)
    description = ''
    desc_separator_char = '; '
    for model in source_models:
        if model.lower() not in description.lower():
            description = description + utils.cleantext(model) + desc_separator_char
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))

##    regex = "setVideo.+?\('(http.+?mp4[^']+)'"
##    sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html)
##    Log("sources={}".format(sources))
##    sources = None
##    if not sources: #try again, this time allowing HLS
    regex = "html5player\.setVideo(?:UrlLow|UrlHigh|HLS)\('(http[^']+)'"
    sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html)
    Log("HLS sources={}".format(sources))
    sources_list = {}
    guessed_resolution = 0 #last is usually best; site does not provide res information
    for source in sources:
        guessed_resolution = guessed_resolution + 360
        sources_list[str(guessed_resolution)] = source
    sources_list = [ [q,v] for q, v in sources_list.items() ] #convert dict to list for the next function
    video_url = utils.SortVideos(
        sources=sources_list
        ,download=download
        ,vid_res_column=0
        ,max_video_resolution=max_video_resolution
        )

##    no_hls = []
##    if len(no_hls) > 0:
##        Log("no_hls={}".format(repr(no_hls)))
##        video_url = no_hls[-1]
##    else:
##        video_url = sources[-1]  #last is usually best; site does not provide res information

    #we should have a url by now...
    if not video_url:
        if testmode:
            raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, ROOT_URL))
        else:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(url, ROOT_URL))
        return

    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = url
    video_url = video_url + utils.Header2pipestring(headers)
    Log("video_url='{}'".format(video_url))

    #during testmode, only ensure that a url can be generated
    if testmode:
        Log("Would have played video_url; but in test mode")
        return

    utils.playvid(
        video_url
        , name=name
        , download=download
        , description=description
        , playmode_string=playmode_string
        , play_profile=play_profile
##        , download_filespec=download_filespec
        , mode = PLAY_MODE
        , url_factory = url
        , icon_URI = icon_URI            
        )
        
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    listhtml = utils.getHtml(url, ROOT_URL)
    regex = '<a href="(/c/\w+[-]\d+)" class="btn btn-default">([^"]+)</a>'
    regex = '<a href="([^"]+)" class="btn btn-default">([^"]+)</a>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label in info:
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        videourl += "/{}"
##        Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=C.search_icon
            ,page=FIRST_PAGE
            )
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword=keyword, testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
    #    Categories(URL_CATEGORIES, False)
    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    utils.endOfDirectory(end_directory=end_directory)
#__________________________________________________________________________
#
_REGEX_icon_search = '<meta property="og:image" content="(.*?)"'
@C.url_dispatcher.register(REBUILD_ICON, ['url'])
def Icon_Search(url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
    page_html = utils.getHtml(url, referer=ROOT_URL)
    icon_url = re.compile(pattern, re.DOTALL | re.IGNORECASE).findall(page_html)[0]
    Log(icon_url)
    headers = C.DEFAULT_HEADERS.copy()
    headers['Referer'] = referer
    return icon_url + utils.Header2pipestring(headers)
#__________________________________________________________________________
#
