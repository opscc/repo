'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import search
import utils
from utils import Log
import constants as C
import resolver

FRIENDLY_NAME = '[COLOR {}]FPOxxx[/COLOR]'.format(C.time_text_color)
LIST_AREA = C.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.fpo.xxx"
SEARCH_URL = ROOT_URL +  "/search/{}/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q={}&category_ids=&sort_by=&from_videos={}"
URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + "/new-1/?mode=async&function=get_block&block_id=list_videos_latest_videos_list&sort_by=post_date&from={}"
URL_CATEGORIES_PAGE= ROOT_URL + "/categories/{}/?mode=async&function=get_block&block_id=list_videos_common_videos_list_norm&sort_by=post_date&from4={}"

MAIN_MODE          = C.MAIN_MODE_fpoxxx
LIST_MODE          = str(int(MAIN_MODE) + 1)
PLAY_MODE          = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE        = str(int(MAIN_MODE) + 4)
TEST_MODE          = str(int(MAIN_MODE) + 5)

FIRST_PAGE = '1'

#__________________________________________________________________________
#
@C.url_dispatcher.register(MAIN_MODE)
def Main():
    if C.DEBUG:
        utils.addDir(
            name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
            , url = C.DO_NOTHING_URL 
            , mode = TEST_MODE
            , end_directory = True
            )    
    progress_dialog = utils.Progress_Dialog(C.addon_name, FRIENDLY_NAME)
    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='', progress_dialog=progress_dialog)

#__________________________________________________________________________
#
@C.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False, progress_dialog=None):
    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if progress_dialog and progress_dialog.iscanceled(): return

    (inband_recurse,end_directory,max_search_depth,list_url)=utils.Initialize_Common_Icons(end_directory, keyword, SEARCH_URL, SEARCH_MODE, url, page)

    listhtml = utils.getHtml(list_url, ROOT_URL)
    if "is no data in this list" in listhtml:
        video_region = ''
        listhtml = ''
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('class="porntrex-box"')[1].split('class="pagination"')[0]
        except:
            video_region = listhtml

    # main list items
    regex = 'class="item.+?href="([^"]+)".+?title="([^"]+)".+?data-original="([^"]+)".+?class="duration">([^<]+)<.+?((?:<span class="is-hd">HD</span>|</div>))'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, duration, hd  in info:

        if progress_dialog:
            if progress_dialog.iscanceled(): break
            progress_dialog.increment_percent()

        hd = utils.Normalize_HD_String(hd)
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration = duration)
    utils.Check_For_Minimum(info, keyword, MAIN_MODE, ROOT_URL, testmode)

    Log('h1')
    if (progress_dialog is None) or (progress_dialog and not progress_dialog.iscanceled()) :
        Log('h2')
        try: # next page items
            regex = 'class="pagination"(.+?)</ul>'
            next_page_html = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        except:
            next_page_html = listhtml
        next_page_regex = '(\d">Next</a></li>)'
        np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
        if not np_info:
            Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
        else:
            np_number = int(page) + 1
            np_url=url
            Log("np_url={}".format(np_url))
            if end_directory == True:
                utils.addDir(
                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=C.next_icon 
                    ,page=np_number
                    ,section = C.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number))  #let user know something is happening
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword
                         , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=inband_recurse)                    
#__________________________________________________________________________
#
@C.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0, progress_dialog=None):
    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        search.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword.replace('+','-'),keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List( url=searchUrl
        , page=FIRST_PAGE
        , end_directory=end_directory
        , keyword=keyword
        , progress_dialog=progress_dialog)

    utils.endOfDirectory(end_directory=end_directory,inband_recurse=(str(page)==C.FLAG_RECURSE_NEXT_PAGES))        
#__________________________________________________________________________
#
@C.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    Log("Categories url={}".format(url) )

    html = utils.getHtml(url, ROOT_URL)
    cathtml = re.compile('"list-categories"(.*)class="footer-margin', re.DOTALL).findall(html)[0]
    regex = 'href="([^"]+)" title="([^"]+)".+?src="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(cathtml)
    for videourl, label, thumb in info:
        thumb = "https:" + thumb + C.Header2pipestring()+"&Referer=" + ROOT_URL + '/'
        keyword = videourl.split('/categories/')[1].split('/')[0]
        #Log("videourl={}".format(videourl))
        utils.addDir(
            name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb
            ,keyword=keyword )
        
    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
@C.url_dispatcher.register(TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=False):
    Log(u"Test(keyword={}, end_directory={})".format(repr(keyword), repr(end_directory)))

    if not keyword:
        prev_keyword = utils.get_setting('quick_search_string')
        keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
        if  keyword == '' :
            return False, 0  ## if blank or the user cancelled the keyboard, return
        C.addon.setSetting(id='quick_search_string', value=keyword)
        
    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
##    Categories(URL_CATEGORIES, False)

    if end_directory:
        utils.addDir(
            name="[COLOR {}]Self Test Passed on {}[/COLOR]".format(C.test_passed_text_color, ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,mode=C.NO_ACTION_MODE)
    
    utils.endOfDirectory(end_directory=end_directory)    
#__________________________________________________________________________
#
@C.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile','icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string))
##    if playmode_string: max_video_resolution=int(playmode_string)
##    else: max_video_resolution = None
    if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
    else: max_video_resolution = None
    download_filespec = ''

    description = name + '\n' + ROOT_URL

    try:
    
        full_html = utils.getHtml(url, ROOT_URL)
        regex = "flashvars.+?license_code:.+?'(?P<lic>[^']+)'"
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if sources_list: license_code = sources_list[0]
##        license_code = sources_list.next().group('lic')
        Log("license_code={}".format(license_code))

##        regex = (
##            "(?:video_url|video_alt_url.?): '(?P<url>[^']+)'"
##            ".+?(?:video_url_text|video_alt_url.?_text)?: '(?P<res>\d+p?)'"
##            )
        regex = (
            "(?:video_url|video_alt_url.?): '(?P<url>[^']+)'"
            ".+?(?:video_url_text|video_alt_url.?_text|postfix): '(?P<res>[^']+)'"
            )

        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).finditer(full_html)
        list_key_value = {}
        for source_list in sources_list:
            if source_list.group('res'):
                if source_list.group('res') == 'HQ':
                    list_key_value['720'] = source_list.group('url')
                elif source_list.group('res') in ['LQ','.mp4']:
                    list_key_value['360'] = source_list.group('url')
                else:
                    list_key_value[source_list.group('res')] = source_list.group('url')
            else:
                list_key_value['240'] = source_list.group('url')
        Log("list_key_value={}".format(list_key_value))

        if len(list_key_value) < 1:
            utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
            return
        
        list_key_value = [ [q,v] for q, v in list_key_value.items() ] #convert dict to list for the next function
        video_url = utils.SortVideos(
            sources=list_key_value
            ,download=download
            ,vid_res_column=0
            ,max_video_resolution=max_video_resolution
            )

        if video_url.startswith("function/0/"):
            video_url = video_url.split("function/0/")[1]
            Log("video_url={}".format(video_url))

        description = ''
        desc_separator_char = '; '
        regex_tags_region = '"tab_video_info"(.+?)"tab_comments"'
        regex_tags = '/models/.+?title="([^"]+)"'
        region_html = re.compile(regex_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
        if region_html:
            source_tags = re.compile(regex_tags, re.DOTALL | re.IGNORECASE).findall(region_html[0])
            for tag in source_tags:
                if tag.lower() not in description.lower():
                    description = "{}{}{}".format(description,utils.cleantext(tag),desc_separator_char)
        description = description.strip(desc_separator_char)
        if description == '':  description=name + '\n' + ROOT_URL
        else:           description=description + '\n' + ROOT_URL
        Log("description={}".format(description))

        #test if salt needs to be applied
        probe = utils.getHtml(video_url, ROOT_URL, method="HEAD", send_back_response=True)

        if not ('video' in probe.headers['Content-Type']):
            
            fappy_salt = resolver.FaapySalt(license_code, "")
            Log("fappysalt='{}'".format(fappy_salt))
            encoded_fappy_code =  video_url.split('/')[5][0:32]
            Log("encoded_fappy_code='{}'".format(encoded_fappy_code))
            new_fappy_code = resolver.ConvertFaapyCode(encoded_fappy_code,fappy_salt)
            Log("new_fappy_code='{}'".format(new_fappy_code))
            video_url = video_url.replace(encoded_fappy_code, new_fappy_code)
##            test = utils.getHtml(video_url, ROOT_URL, method="HEAD", send_back_response=True)
##            Log(repr(test))
##            Log(repr(test.headers))

    
        import time
        video_url += "?rnd={}".format(int(time.time()*1000))

        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
        video_url += utils.Header2pipestring(headers)

        Log("video_url='{}'".format(video_url))
    
        utils.playvid(
            video_url
            , name=name
            , download=download
            , description=description
            , playmode_string=playmode_string
            , play_profile=play_profile
##            , download_filespec=download_filespec
            , mode = PLAY_MODE
##            , url_factory = url
            , icon_URI = icon_URI            
            )
        
    except:
        import traceback
        traceback.print_exc()
        utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,ROOT_URL))
        Log("ERROR Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(url,name,download,playmode_string), C.LOGNONE)
#__________________________________________________________________________
#
