'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
#import base libraries
import re
#import internal addon libraries
import utils
from base_website import Base_Website
#define frequenctly used aliases
from utils import Log as Log
import constants as C



import base64
import json

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]HClips[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False

    #same as txx???    
    _ROOT_URL        = "https://hclips.com"
    _URL_CATEGORIES  = _ROOT_URL + '/api/json/categories/14400/str.all.json'
    _URL_RECENT      = _ROOT_URL + '/api/json/videos2/14400/str/latest-updates/120/..{}.all..day.json'
    _SEARCH_URL      = _ROOT_URL + '/api/videos2.php?params=259200/str/relevance/120/search..{}.all..day&s={}'


    _MAIN_MODE = C.MAIN_MODE_hclips

    _FIRST_PAGE = '1'

    _size_filter = 200 #must be at least this many seconds
    
    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = None #'class="bloc-menu-centre(.+?)<script>'

    #which to strings may indicate that there is nothing to be found
##    _ITEMS_NOT_FOUND_INDICATORS = [
##        "<p>Make sure that all words are spelled correctly.</p>"
##        , "No videos found for "
##        ]

    #videos on this page
    _REGEX_list_items = (
        '{"video_id":"(?P<videourl>\d+)"'
        '.+?"title":"(?P<label>[^"]+?)"'
        '.+?"duration":"(?P<duration>[^"]+?)"'
        '.+?"scr":"(?P<thumb>[^"]+?)"'
        '.+?"props":(?P<hd>[^,]+?),'
        #'.+?"models":"(?P<desc>[^"]*?)"'
        '(?P<desc>)"'
        )

    # Which right click properties to add to icon [e.g. present HLS or MP4 play options]
    _Right_Click_Option = None #show all options

    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = '("videos":\[{")'

    #where categories can be found
##    _REGEX_categories_region = (
##        'class="pvicon-categorie"(.+?)>All tags<'
##        )
    _REGEX_categories = (
        '"title":"(?P<label>[^"]+)"'
        '.*?,"dir":"(?P<videourl>[^"]+)"'
        '(?P<thumb>)'
        )

    #where playable urls live
    _REGEX_playsearch_01 = (
        '<source src="(?P<url>[^"]+?)" type='
        '.+?(?P<res>\d)'
        )

    #description for the playable url
    _REGEX_tags = 'class="link12">(?P<tag>[^<]+)<'
    _REGEX_tags_region = '(.+)'

    _REGEX_icon_search = (
        '.+?poster=\\\\"(?P<thumb>[^\\\\]+)\\\\'
        )


    #__________________________________________________________________________
    #
    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
        Log(u"Icon_Search url={}, pattern={}, referer={}".format(repr(url),repr(pattern),repr(referer))
##            , C.LOGNONE
            )
        return None #not vailale on this site
    
        page_content = utils.getHtml(url, referer)
        iframeurl = re.compile(r"nativeplayer\.php\?i=([^']+)", re.DOTALL | re.IGNORECASE).findall(page_content)
        if not iframeurl: return None
        if not (iframeurl[0].startswith('http')): iframeurl = 'https:' + iframeurl[0]
        page_content = utils.getHtml(iframeurl, referer)
        info = re.compile(pattern, re.DOTALL | re.IGNORECASE).finditer(page_content)
        for item in info:
            thumb = item.group('thumb')
            if thumb and not thumb.startswith('http'): thumb = 'https:' + thumb
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = referer
            return thumb + utils.Header2pipestring(headers)
        return None
    
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def ALTERNATE_playsearch_01(self, *args, **kargs):

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        items = json.loads(full_html)

        #stolen from current UWC 2021-02-02
        vidurl = items[0]['video_url']
        Log(u"vidurl='{}'".format(vidurl))
        replacemap = {'M':'\u041c', 'A':'\u0410', 'B':'\u0412', 'C':'\u0421', 'E':'\u0415', '=':'~', '+':'.', '/':','}
        for key in replacemap:
            vidurl = vidurl.replace(replacemap[key], key)
        Log(u"vidurl='{}'".format(vidurl))
        replacemap2 = {u'M':u'\u041c', u'A':u'\u0410', u'B':u'\u0412', u'C':u'\u0421', u'E':u'\u0415', u'=':u'~', u'+':u'.', u'/':u','}
        for key in replacemap2:
            vidurl = vidurl.replace(replacemap2[key], key)

        video_url = self.ROOT_URL + str(base64.b64decode(vidurl),'utf8')

        alt_results.append(  ('240', video_url)  )

        Log("alt_results={}".format(repr(alt_results)))        
        return alt_results

    
##    #__________________________________________________________________________
##    # Change list url as neeeded by website
##    def List_URL_Normalize(self, url):
##        return url.replace('page1.html', '')
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        videourl = self.ROOT_URL + "/api/videofile.php?video_id={}&lifetime=8640000".format( videourl )
        return videourl
    #__________________________________________________________________________
    # Change thumb url created by List as neeeded by website
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        thumb = thumb.replace("\\/", "/")
        return thumb
##    #__________________________________________________________________________
##    # Change label created by List as neeeded by website
##    def Normalize_ListLabel(self, label, hd):
##        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, cleantext(label), hd)
##        return label        
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        return keyword.replace('+',' ').replace(' ','%20')
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format('{}',keyword)
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + "/api/json/videos/86400/str/latest-updates/60/categories.{}.{}.all..day.json".format(url, '{}')

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  best to override code in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.REBUILD_ICON, ['url'])
def Rebuild_Icon(url):
    website.Rebuild_Icon(url)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
