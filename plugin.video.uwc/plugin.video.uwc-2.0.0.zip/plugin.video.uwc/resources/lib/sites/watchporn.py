'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

###
### 2024-12 began using DDOS service
### 2025-02 sometimes works - maybe DDOS has limits
### 2025-04 DDOS service
###


import utils

import constants as C
from base_website import Base_Website
from utils import Log as Log

class Specific_Website(Base_Website):
    
    _FRIENDLY_NAME = '[COLOR {}]watchporn[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_SCENES
    _FRONT_PAGE_CANDIDATE = True

    _ROOT_URL           = u"https://watchporn.to"
    _URL_RECENT         = _ROOT_URL + "/latest-updates/{}/"
    _URL_CATEGORIES     = _ROOT_URL + '/categories/'
    _SEARCH_URL         = _ROOT_URL + "/search/{}/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q={}&category_ids=&sort_by=&from_videos={}"

    _MAIN_MODE = C.MAIN_MODE_watchporn

    _FIRST_PAGE = '1' #Note:site does not support page1.html

    #where we can find videos on this page [exclude advertisement]
    _REGEX_video_region = 'class="main-content"(.+?)class="pagination"'

    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        ]

    #videos on this page    
    _REGEX_list_items = (
        '<div class="item'
        '.+?href=\"(?P<videourl>[^\"]+)\"'
        '.+?title=\"(?P<label>[^\"]+)\"'
        '.+?data-original=\"(?P<thumb>[^\"]+)\"'
        '.+?duration\">(?P<duration>[^\<]+)<'
        #'.+?class="quality">(?P<hd>[\d]+)'
        '(?P<hd>)'
        )

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'class="pagination"(.+)'
    _REGEX_next_page_regex =  'class="next"><a href="([^"]+)".+?from(?:_videos\+from_albums|4|):(\d+)'

    #where categories can be found
    _REGEX_categories_region = '"list-categories"(.*)class="footer-margin'
    _REGEX_categories = (
        'href="(?P<videourl>[^"]+)"'
        '.+?title="(?P<label>[^"]+)"'
        '.+?src="(?P<thumb>[^"]+)"'
        )

    #where playable urls live
    _REGEX_playsearch_01 = None
##        (
##        "(?:video_url|video_alt_url.?): 'function/0/(?P<url>[^']+)"
##        ".+?(?:video_url_text:|video_alt_url_text:) '(?P<res>[^']+)'"
##        )

    #description for the playable url
    _REGEX_tags = None #"href='/pornstar/.+?>([^<]+)<"
    _REGEX_tags_region = None#'<div id="data-video">(.+?)<div class="clear">'


##    #__________________________________________________________________________
##    # Change list url as neeeded by website
##    def List_URL_Normalize(self, url, page=None):
##        return url.replace('page1.html', '')
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):

        #GET /categories/hungarian/?mode=async&function=get_block&block_id=list_videos_common_videos_list_norm&from4=06&_=1671294671387
##        Log(repr(url), C.LOGNONE)
        return url + '?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date&from={}'
                     #?mode=async&function=get_block&block_id=list_videos_common_videos_list&sort_by=post_date&from=2&_=1681157255900

##        return self.ROOT_URL + url + 'page{}.html'

    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        headers = None #2022-12 thumbs need referrer
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
        if headers:
            thumb = thumb + utils.Header2pipestring(headers)
##        Log(repr(thumb), C.LOGNONE)
        return thumb
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        if not thumb.startswith('http'):
            thumb = "https:" + thumb
        headers = None #2022-12 thumbs need referrer
        if '|' not in thumb:
            headers = C.DEFAULT_HEADERS.copy()
            headers['Referer'] = self._ROOT_URL + '/'
        if headers:
            thumb = thumb + utils.Header2pipestring(headers)
##        Log(repr(thumb), C.LOGNONE)
        return thumb
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args)>0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args)>1): keyword = args[1]
        elif (args is not None) and (len(args)>0): keyword = args[0]
        else                                     : keyword = ""

        keyword_1 = keyword.replace('+',' ').replace(' ','-')
        keyword_2 = keyword_1.replace('-','+')

        return search_url.format(keyword_1, keyword_2, '{}')

    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def ALTERNATE_playsearch_01(self, *args, **kargs):
##        Log(repr((args,kargs)))
        import base64
        import json
        import re

        import resolver

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

        license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(full_html)
        if license_code:
            license_code = license_code[0]
            fappy_salt = resolver.FaapySalt(license_code, "")
            Log("fappysalt='{}'".format(fappy_salt))
            Log("license_code='{}'".format(license_code) )
        else:
            Log("url='{}'".format(url), xbmc.LOGNONE)
            Log("No license_code found for {}".format(name))
            return alt_results

        regex = (
            "video(?:_alt|)_url\d?: 'function/0/(?P<url>[^']+)',"
            #".+?video(?:_alt|)_url\d?_text: '(?P<res>\d+)"
            ".+?postfix: '\_(?P<res>[\w]+)"
            )
        sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        if not sources: sources =[] #fake data so that next code can look simpler
        Log(repr(sources))


        headers = C.DEFAULT_HEADERS.copy()
        headers['Referer'] = url
    
        for video_url, res in sources:
            video_url += "?_rnd=" + utils.RandomNumber()
            old_fappy_code =  video_url.split('/')[5][:len(fappy_salt)]
            Log("old_fappy_code='{}'".format(old_fappy_code))
            new_fappy_code = resolver.ConvertFaapyCode( old_fappy_code, fappy_salt)
            Log("new_fappy_code='{}'".format(new_fappy_code))

            video_url = video_url.replace(old_fappy_code, new_fappy_code)
            
            video_url += utils.Header2pipestring(headers)

            alt_results.append(  (res, video_url)  )

        Log("alt_results={}".format(repr(alt_results)))
        return alt_results
    
#__________________________________________________________________________
#




#__________________________________________________________________________
#
website = Specific_Website() #always need this
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE)
def Test():
    website.Test(end_directory=True) 
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )
#__________________________________________________________________________
#
