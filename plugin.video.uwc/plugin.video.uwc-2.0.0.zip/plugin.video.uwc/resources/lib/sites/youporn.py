'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import constants as C
from base_website import Base_Website
from utils import Log as Log

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]Youporn[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = True
    
    _ROOT_URL        = "https://www.youporn.com"
    _URL_CATEGORIES  = _ROOT_URL + '/categories/'
    _URL_RECENT      = _ROOT_URL + '/browse/time/?page={}'
    _SEARCH_URL      = _ROOT_URL + '/search/?query={}&page={}'
#             https://www.youporn.com/search/?query=autumn+falls&page=3
    _MAIN_MODE = C.MAIN_MODE_youporn

    _FIRST_PAGE = '1'

    #where we can find videos on this page [exclude advertisement]
#    _REGEX_video_region = '(?:data-section_name="day_by_day_section" data-espnode|video_row_main_search"|data-espnode="videolist")(.+?)(?:id="pagination"|<footer>)'
# 2024-09 python regex fails.  The page data does not allow ending  (?:id="pagination"|<footer>)
    _REGEX_video_region = 'id="adblock_close_button"(.+)'
    
    #which to strings may indicate that there is nothing to be found
    _ITEMS_NOT_FOUND_INDICATORS = [
        "<p>Make sure that all words are spelled correctly.</p>"
        , "No videos found for "
        ]

    #videos on this page
    _REGEX_list_items = (
        'data-video-id="\d.+?href="(?P<videourl>[^"]+)"'
        '.+?data-src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        #'.+?"video-best-resolution">(?P<hd>\d+)' ##2024-09 no more resulotin
        '(?P<hd>)'
        '.+?class="video-duration.+?>\s+?(?P<duration>[\d:]+)\s<'
        )
##    Log(_REGEX_list_items, C.LOGNONE)

    #where we can find info on whether there is a next page
    _REGEX_next_page_region = 'id="pagination"(.+)'
    _REGEX_next_page_regex = 'id="next".+?href="([^"]+)"'


    #where categories can be found
    _REGEX_categories_region = "id='categoryList'(.+)"
    _REGEX_categories = (
        '<a href="(?P<videourl>[^"]+)"'
        '.+?data-original="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+)"'
        )

    #where playable urls live
    _REGEX_playsearch_01 = None #'mediaDefinition:\s+?(?P<json>\[[^\]]+\]),'

    #description for the playable url
    _REGEX_tags = '"pornstar_tag".+?>([^<]+)<'
    _REGEX_tags_region = 'class="categorieswrapper(.+?)<noscript>'

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants
    def Search_Keyword_Normalize(self, *args, **kargs):
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args) > 0): keyword = args[0]
        else                                     : keyword = ""
        Log("keyword='{}'".format(repr(keyword)))
        
        return keyword.replace(' ','+').replace('_','+')
    
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        #2021-06 site moved data to separate page
        REGEX_playsearch_01 = 'mediaDefinitions":(?P<json>\[[^\]]+\]),'
        source_html = kargs['full_html']
        referer = kargs['referer']
        videos_list = list() #hold multiple video_url when possible
##https://www.youporn.com/api/video/media_definitions/16507250/

        import re
        import json
        from utils import getHtml as getHtml
        
        sources_list = re.compile(REGEX_playsearch_01, re.DOTALL | re.IGNORECASE).finditer(source_html)
        for source in sources_list:
            sources_list = source.group('json')
##            Log("sources_list='{}'".format(repr(sources_list)))
            json_sources_1 = json.loads(sources_list)
##            Log("json_sources_1='{}'".format(repr(json_sources_1)))
            for json_src in json_sources_1:
                if 'videoUrl' in json_src:
                    if json_src['videoUrl'] != '':
##                        Log(repr(json_src['videoUrl']))
                        url_2 = json_src['videoUrl']
                        if not url_2.startswith('http'): url_2 = self._ROOT_URL +  json_src['videoUrl']
                        json_html = getHtml( url_2 , referer)
                        json_sources_2 = json.loads(json_html)
##                        Log("json_sources_2='{}'".format(repr(json_sources_2)))
                        for json_src_2 in json_sources_2:
##                            Log(repr(json_src_2))
                            if json_src_2['videoUrl'] != '' and not isinstance(json_src_2['quality'], list):
                            #and json_src_2['format'] == 'mp4':
                                videos_list.append((json_src_2['quality'], json_src_2['videoUrl']))
                            
                break

        Log("videos_list={}".format(repr(videos_list)))        
        return videos_list
    
    #__________________________________________________________________________
    # Change url found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return self.ROOT_URL + url + '?page={}'

#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):
    website.List(url, page, end_directory, keyword, testmode)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    website.Search(searchUrl, keyword=keyword, end_directory=end_directory, page=page)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['keyword','end_directory'])
def Test(keyword=None, end_directory=True):
    website.Test(end_directory=end_directory)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )

#__________________________________________________________________________
#
