import json
import random
import threading
import traceback
import xbmc

import constants as C
from constants import reload

import downloader
import utils
import webcam_db
import reboot_detection
from utils import Log as Log
from utils import Sleep as Sleep
from utils import get_setting as GetSetting

import downloadServer
    
monitor = xbmc.Monitor()


#__________________________________________________________________________
#
class EndingException(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)
#__________________________________________________________________
#
def recording_service(stop_event):
    try:
        while not monitor.abortRequested():
            sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
            if sleeptime < 1: sleeptime = 1
            Log("{} monitor sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
            if stop_event.isSet():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_recording_service", bool):
                downloader.scan_and_start_db()
    except EndingException as ex:
##        traceback.print_exc()
        Log(ex.value)
    except:
        traceback.print_exc()

#__________________________________________________________________
#
def download_service(stop_event):


    try:
        download_proxy = None
        while not monitor.abortRequested():
            if stop_event.isSet():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_download_service", bool):
                if not download_proxy:
                    Log("starting download_proxy", C.LOGNONE)
                    reload(downloadServer) #reload during development so that I dont have to restart program
                    download_proxy = downloadServer.StartListening()
                else:
                    if download_proxy._BaseServer__shutdown_request:
                        Log('internal download_proxy forcestop')
                        download_proxy.server_close()
                        Log('internal download_proxy server_close')
                        download_proxy.socket.close()
                        Log('internal download_proxy close')
                        download_proxy = None
                    if GetSetting("keepalive_download_service", bool):
                        active_threads = utils.postHtml("http://127.0.0.1:{}/".format(GetSetting("download_server_port_current", int))
                                   ,sent_data= json.dumps({
                                      downloader.ATTRIB_cmd: downloader.CMD_list
                                       })
                                   ,headers={
                                       'Content-Type': 'application/json'
                                       }
                                   )
                        Log(repr(active_threads))
                        
                    pass
            else:
                if download_proxy or download_proxy._BaseServer__shutdown_request:
                    download_proxy.shutdown()
                    download_proxy.server_close()
                    download_proxy.socket.close()
                    Log('download_proxy stopped')
                    download_proxy = None
            sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
            if sleeptime < 1: sleeptime = 1
            Log("{} monitor sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
    except EndingException as ex:
##        traceback.print_exc()
        Log(ex.value)
    except:
        traceback.print_exc()
    finally:
        try:
            if download_proxy:
                download_proxy.shutdown()
                download_proxy.server_close()
                download_proxy.socket.close()
                Log('Finally download_proxy stopped')
                download_proxy = None
        except:
            traceback.print_exc()

#__________________________________________________________________
#
def network_is_online(stop_event):
    sleeptime = C.SERVICE_FIRST_SLEEPTIME
    if monitor.waitForAbort(int(sleeptime)):
        Log("{} ending due to abort".format(threading.current_thread().name))
        return

    try:
        while not monitor.abortRequested():
            if stop_event.isSet():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("reboot_required_detection", bool):
                if C.DEBUG: reload(reboot_detection) #during dev, convenient to force a recompile
                reboot_detection.reboot_required_detection()
            sleeptime1 = random.randint(GetSetting("min_service_interval", int), GetSetting("min_service_interval", int)*5) #sleep betwen X and 5X seconds
            sleeptime = max(sleeptime1, GetSetting("min_service_interval", int) )
##            sleeptime = C.SERVICE_FIRST_SLEEPTIME; Log("Warning: simulating result during a dev test")
            if sleeptime < 1: sleeptime = 1
            Log("{} sleeping {} seconds before next action [not {}]".format(repr(threading.current_thread().name), sleeptime, sleeptime1) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
    except EndingException as ex:
        Log(ex.value)
    except:
        traceback.print_exc()
#__________________________________________________________________
#
def link_crawler(stop_event):
    sleeptime = C.SERVICE_FIRST_SLEEPTIME
    if monitor.waitForAbort(int(sleeptime)):
        Log("{} ending due to abort".format(threading.current_thread().name))
        return
    try:
        while not monitor.abortRequested():
            if stop_event.isSet():
                raise EndingException("{} ending due to stop_event".format(threading.current_thread().name))
            if GetSetting("enable_link_crawler", bool):
                webcam_db.clear_webcam_db()
                webcam_db.fill_webcam_db()
            sleeptime1 = int(GetSetting("service_periodic_interval", int) * (random.random()))*2
            sleeptime1 = random.randint(GetSetting("min_service_interval", int), GetSetting("min_service_interval", int)*5)
            sleeptime = max(sleeptime1, GetSetting("min_service_interval", int) )
            if sleeptime < 1: sleeptime = 1
            Log("{} sleeping {} seconds before next action [not{}]".format(threading.current_thread().name, sleeptime, sleeptime1) ) #heartbeat logging
            if monitor.waitForAbort(sleeptime):
                raise EndingException("{} ending due to abort".format(threading.current_thread().name))
    except EndingException as ex:
        Log(ex.value)
    except:
        traceback.print_exc()
#__________________________________________________________________
#
if __name__ == '__main__':

    C.DEBUG = GetSetting('debug')
    threading.current_thread().name = C.addon_id+".service"

    proxy_thread_recording_service = None
    recording_service_stop_event = None

    proxy_thread_download_service = None    
    download_service_stop_event = None

    proxy_thread_crawler = None
    crawler_stop_event = None

    proxy_reboot_required_detection = None
    reboot_required_detection_stop_event = None


    while not monitor.abortRequested():

        try:
            # start thread for link_crawler service
            if GetSetting("enable_link_crawler", bool):
                try:        
                    if (not proxy_thread_crawler) or (not proxy_thread_crawler.is_alive()) : 
                        crawler_stop_event = threading.Event()
                        proxy_thread_crawler = threading.Thread(
                            target=link_crawler
                            ,args=(crawler_stop_event,)
                            ,name=C.addon_id+".link_crawler"
                            )
                        proxy_thread_crawler.daemon = True
                        proxy_thread_crawler.start()
                    else:
                        pass
                except:
                    traceback.print_exc()
            else:
                if proxy_thread_crawler:
                    if crawler_stop_event: crawler_stop_event.set()
                    proxy_thread_crawler = None


            # start thread for reboot_required_detection
            if GetSetting("reboot_required_detection", bool):
                try:        
                    if (not proxy_reboot_required_detection) or (not proxy_reboot_required_detection.is_alive()) : 
                        reboot_required_detection_stop_event = threading.Event()
                        proxy_reboot_required_detection = threading.Thread(
                            target=network_is_online
                            ,args=(reboot_required_detection_stop_event,)
                            ,name=C.addon_id+".reboot_required_detection"
                            )
                        proxy_reboot_required_detection.daemon = True
                        proxy_reboot_required_detection.start()
                    else:
                        pass
                except:
                    traceback.print_exc()
            else:
                if proxy_reboot_required_detection:
                    if reboot_required_detection_stop_event: reboot_required_detection_stop_event.set()
                    proxy_reboot_required_detection = None
                    

            # start thread for enable_recording_service service
            if GetSetting("enable_recording_service", bool): # and GetSetting("enable_link_crawler", bool):
                try:
                    if (not proxy_thread_recording_service) or (not proxy_thread_recording_service.is_alive()) : # start thread
                        recording_service_stop_event = threading.Event()
                        proxy_thread_recording_service = threading.Thread(
                            target=recording_service
                            ,args=(recording_service_stop_event,)
                            ,name=C.addon_id+".recording_service"
                            )
                        proxy_thread_recording_service.daemon = True
                        proxy_thread_recording_service.start()
                    else:
                        pass
                except:
                    traceback.print_exc()
            else:
                if proxy_thread_recording_service:
                    if recording_service_stop_event: recording_service_stop_event.set()
                    proxy_thread_recording_service = None


            # start thread for enable_download_service service
            if GetSetting("enable_download_service", bool):
                try:
                    if (not proxy_thread_download_service) or (not proxy_thread_download_service.is_alive()) : # start thread
                        download_service_stop_event = threading.Event()
                        proxy_thread_download_service = threading.Thread(
                            target=download_service
                            ,args=(download_service_stop_event,)
                            ,name=C.addon_id+".download_service"
                            )
                        proxy_thread_download_service.daemon = True
                        proxy_thread_download_service.start()
                    else:
                        pass
                except:
                    traceback.print_exc()
            else:
                if proxy_thread_download_service:
                    if download_service_stop_event: download_service_stop_event.set()
                    proxy_thread_download_service = None

        except:
            traceback.print_exc()

        ## sleep then ... do some work
        sleeptime = GetSetting("min_service_interval", int) #sleep can be short-lived because operation is not costly
        if sleeptime < 1: sleeptime = 1
##        Log("{} sleeping {} seconds before next action ".format(threading.current_thread().name, sleeptime) )
        if monitor.waitForAbort(sleeptime):
            Log("{} ending due to abort".format(threading.current_thread().name))
            break

        #must recalc this value if we want to dynamically change debugging verbosity without restart
        C.DEBUG = GetSetting('debug')

    if proxy_thread_crawler:
        if crawler_stop_event: crawler_stop_event.set()
    if proxy_thread_recording_service:
        if recording_service_stop_event: recording_service_stop_event.set()
    if proxy_thread_download_service:
        if download_service_stop_event: download_service_stop_event.set()
    if proxy_reboot_required_detection:
        if reboot_required_detection_stop_event: reboot_required_detection_stop_event.set()
        
#__________________________________________________________________
#
