'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import urllib
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

FRIENDLY_NAME = '[COLOR {}]xVideos[/COLOR]'.format(utils.time_text_color)
LIST_AREA = utils.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.xvideos.com"

SEARCH_URL = ROOT_URL + '/?k={}&p={}'

URL_CATEGORIES = ROOT_URL
URL_RECENT = ROOT_URL  + '/new/{}/'
URL_TOPRATED = ROOT_URL + "/top-rated-porn-videos/page/{}/"
URL_MOSTVIEWED = ROOT_URL + "/most-viewed-porn-videos/page/{}/"

MAIN_MODE       = '530'
LIST_MODE       = '531'
PLAY_MODE       = '532'
CATEGORIES_MODE = '533'
SEARCH_MODE     = '534'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    listhtml = utils.getHtml(list_url, '')
    if ("(No result)" in listhtml) or ("but no results were found" in listhtml):
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword, ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        video_region = listhtml.split('id="main"')[1].split('class="pagination "><ul>')[1]
    #Log("video_region={}".format(video_region))




    #
    # parse out list items
    #
    #id="post.+?
    regex = '"(\/video\d+[^"]+)".+?data-src="([^"]+)".+?class=\"video-(?:hd|sd)-mark\">([^<]+)<.+?title="([^"]+)".+?duration\">([^<]+)<'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, hd, label, duration in info:
        #Log("label={}".format(label))
        if   '2160' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        #thumb = thumb + "|Referer=" + list_url
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        #Log("duration={}".format(duration))
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc='\n' + ROOT_URL
            , duration=duration )

    if len(info) < 1 and testmode:
        utils.addDownLink(
            name="[COLOR {}]{}[/COLOR]".format('orange', 'failed {}'.format(ROOT_URL))
            ,url=list_url
            ,mode=1
            ,iconimage='')
        raise OSError


    #
    # next page items
    #
    #if not video_region == "" and 'class="pagination' in listhtml:
    try:
        next_page_html = listhtml.split('class="pagination "><ul>')[2]
    except:
        next_page_html = ""
    #Log("next_page_html={}".format(next_page_html))
    #next_page_regex = '<li><a href="([^"]+\d+/?)" class="no-page next-page">Next</a></li>'
    #next_page_regex = '<li><a href=".+p=(\d+)/?" class="no-page next-page">Next</a></li>'
    next_page_regex = '<li><a href=".+/?(?:(\d+)|.+p=(\d+))/?" class="no-page next-page"><span class="mobile-hide">Next<'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
            Log("np_url={}".format(np_url))
            if page:
                np_number = int(page) + 1
            else:
                np_number = 1
            np_url = url
            Log("np_url={}".format(np_url))
            if keyword: 
                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number)+1)
            else:
                #hack to make things look nice.  Site starts with zero for non-searches
                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number))

##            np_number=''
##            if ';p=' in np_url: #search result
##                if not np_number.isdigit(): np_number=np_url.split(';p=')[1]
##            if '/' in np_url:
##                if not np_number.isdigit(): np_number=np_url.split('/')[2]
##            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
##            np_url = np_url.replace(' ', '+')
##            np_url = utils.html_parser.unescape(np_url)
            if end_directory == True:
                utils.addDir(
                    name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword,'{}')
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=None, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    videopage = utils.getHtml(url, ROOT_URL)
    regex = "setVideo.+?\('(http[^']+)'"
    sources = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(videopage)
    Log("sources={}".format(sources))
    video_url = sources[-1]  #last is usually best

    if not video_url:
        utils.notify('Oh oh','Couldn\'t find a video')
        return

    regex_model = '<a href="/model-channels/.+?<span class="name">(?P<model>[^<]+)<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(videopage)
    description = ''
    desc_separator_char = '; '
    if source_models:
        for model in source_models:
            description = description + desc_separator_char + model.group('model')
    description = description.strip(desc_separator_char)
    #Log("description={}".format(description))
    if description == '':
        description=name + '\n' + ROOT_URL
    else:
        description=description + '\n' + ROOT_URL
    Log("description={}".format(description))

    
    utils.playvid(video_url, name, download, description=description)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url, '')
 
    regex = '<a href="(/c/\w+[-]\d+)" class="btn btn-default">([^"]+)</a>'
    regex = '<a href="([^"]+)" class="btn btn-default">([^"]+)</a>'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, label in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, label) 
        #if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("thumb={}".format(thumb))
        videourl += "/{}"
        Log("videourl={}".format(videourl))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon
            ,page=1
            )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#
