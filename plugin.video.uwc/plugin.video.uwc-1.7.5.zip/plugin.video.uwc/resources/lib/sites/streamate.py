'''
    Ultimate Whitecream
    Copyright (C) 2017 Whitecream, hdgdl
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import sqlite3
import json

import xbmc
import xbmcplugin
import xbmcgui

from resources.lib import utils
##from resources.lib import favorites
##from resources.lib import websocket
from resources.lib.utils import Log

##MAIN_MODE          = '515'
##LIST_MODE          = '516'
##PLAY_MODE          = '518'
##REFRESH_MODE       = '517'
MAIN_MODE       = '515'
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
REFRESH_MODE    = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)


FRIENDLY_NAME = '[COLOR {}]StreamMate[/COLOR]'.format(utils.time_text_color)
LIST_AREA = utils.LIST_AREA_CAMS
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.streamate.com"

RESULTS_PER_PAGE = 100

URL_FEMALES = 'http://api.naiadsystems.com/search/v1/list?results_per_page={}' 

SEARCH_URL = 'stub - make all sites consistent'

#__________________________________________________________________________
#
@utils.url_dispatcher.register(MAIN_MODE)
def Main():
    #utils.addDir('[COLOR red]Refresh streamate.com images[/COLOR]','',REFRESH_MODE,'',Folder=False)
    #utils.addDir('[COLOR hotpink]Search + Fav add[/COLOR]','https://www.streamate.com/cam/',519,'','')
    List(URL_FEMALES, page='1', end_directory=True, keyword='')
    #xbmcplugin.endOfDirectory(utils.addon_handle)

#__________________________________________________________________________
#
def GetCamgirlList(url=URL_FEMALES, page=1, depth=1, notify=False):

    if notify: utils.Notify("Listing {}".format(ROOT_URL))

    if '{}' in url and page:
        list_url = url.format(int(RESULTS_PER_PAGE) * int(depth)) + "&page_number=" + str(page)
    else:
        list_url = url + "&page_number=" + str(page)

    json_html = utils.getHtml(list_url)

    json_items = json.loads(json_html)['Results']

    for json_item in json_items:
##        Log("json_item='{}'".format(json_item))
        performerID = str(json_item['PerformerId'])
        icon_image = "http://m1.nsimg.net/media/snap/" + performerID + ".jpg"
        video_url = performerID
        name = utils.cleantext(json_item['Nickname'])
        #Log("name='{}'".format(name))
        camscore = json_item['Rating']
        camscore = json_item['SortScore']
        hd = ''
        label = "{}{} {}".format(utils.SPACING_FOR_NAMES, name, hd)

        json_item['username'] = name
        json_item['icon_label'] = label
        json_item['icon_image'] = icon_image
        json_item['video_url'] = name
        json_item['camscore'] = camscore
        json_item['mode'] = PLAY_MODE
        json_item['description'] = '\n' + ROOT_URL
        json_item['play_method'] = '' #blank so that defaut method is chosen a play time
        
        
    return json_items

#__________________________________________________________________________
#
@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=1, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))
    
    if end_directory == True:    
        utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
            utils.SPACING_FOR_TOPMOST, utils.refresh_text_color) 
            ,url='' 
            ,mode=REFRESH_MODE 
            ,iconimage=utils.refresh_icon)
        
    models = GetCamgirlList(url, page)
    for model in models:
        utils.addDownLink( 
            name = model['icon_label'] 
            , url = model['video_url'] 
            , mode = model['mode'] 
            , iconimage = model['icon_image']
            , duration = model['camscore']
            , play_method = model['play_method']
            , desc = model['description']
            , date = model['username']
            )

        
    np_number = int(page) + 1
    np_url = url
    np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(utils.SPACING_FOR_NEXT, utils.search_text_color, np_number)
    if end_directory == True:
        utils.addDir(
            name= np_label
            ,url=np_url 
            ,mode=LIST_MODE 
            ,iconimage=utils.next_icon 
            ,page=np_number
            ,keyword=keyword )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#
def clean_database(showdialog=True):

    return True
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % "m1.nsimg.net")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % "m1.nsimg.net")
            if showdialog:
                utils.notify('Finished','streamate.com images cleared')
    except:
        pass


#__________________________________________________________________________
#
@utils.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')
    
##@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'])
##def Playvid(performerID, name):

#__________________________________________________________________________
#
@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download', 'megabitratebonus'])
def Playvid(url, name, playmode_string = '', download = False, megabitratebonus=0):
    
    Log ("Playvid url='{}', name='{}', playmode_string='{}', megabitratebonus='{}', download='{}'".format(url, name, playmode_string, megabitratebonus, download), xbmc.LOGNONE  )

    #
    # do stuff to get a playable url
    #
    
    name = url
    
    response = utils.getHtml("https://streamate.com/ajax/config/?name=" + name + "&sakey=&sk=streamate.com&userid=0&version=2.2.0&ajax=1")
    data = json.loads(response)
    Log("data='{}'".format(data))
    performerID = int(data['performer']['id'])

    if performerID %2 == 0:
        host = "sea1c"
    else:
        host = "sea1b"
    json_url = ("https://{}-ls.naiadsystems.com/{}-edge-ls/80/live/s:{}.json{}".format(
                    host
                    ,host
                    ,name 
                    ,"?last=load&format=mp4-hls"
                    )
                )
    Log("json_url='{}'".format(json_url))

    streamate_headers = utils.DEFAULT_HEADERS.copy()
    streamate_headers['Referer'] = "{}/cam/{}".format(ROOT_URL, name)
    streamate_headers['Accept'] = "application/json"
##    Log("streamate_headers='{}'".format(streamate_headers))
    referer = "{}/cam/{}".format(ROOT_URL, name)
##    Log("referer='{}'".format(referer))
    
    json_html = utils.getHtml(json_url, referer=referer, headers=streamate_headers, ignore404=True, ignore403=True)
    if not json_html:
        utils.Notify("{} is unavailable".format(name))
        return

    json_data = json.loads(json_html)
    #Log("json_data='{}'".format(json_data))

    video_url = json_data['formats']['mp4-hls']['manifest']
    Log("video_url='{}'".format(video_url))

    #
    # play url as needed
    #

    streamate_headers['Accept'] = "*/*"

    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    listitem.setContentLookup(False)

    max_bit_rate = utils.MAX_BIT_RATE  + int((int(megabitratebonus)) * 1000 * 1000)
    max_bit_rate_download = utils.MAX_BIT_RATE  + int((int(megabitratebonus) + 0.25) * 1000 * 1000)

    if playmode_string == utils.PLAYMODE_F4MPROXY:
        pass
    elif playmode_string == utils.PLAYMODE_INPUTSTREAM:
        pass
    else:
        playmode_string = utils.DEFAULT_PLAYMODE 
    if download == True:
        Log("f4mproxy video_url - only this mode can capture")
        playmode_string = utils.PLAYMODE_F4MPROXY
    Log("playmode_string='{}'".format(playmode_string)  )

    if playmode_string == '': # direct
        video_url = "{}{}".format(video_url, utils.Header2pipestring(streamate_headers) )
        Log("direct video_url")

    elif playmode_string == utils.PLAYMODE_F4MPROXY:
        video_url = "{}{}".format(video_url, utils.Header2pipestring(streamate_headers) )
        Log("f4mproxy video_url")

        if download == True:
            download_path = utils.Make_download_path(name = name, include_date = True, file_extension = '.mp4')
            Log(download_path, xbmc.LOGNONE)
        else:
            download_path = None
            
        from F4mProxy import f4mProxyHelper
        f4mp=f4mProxyHelper()
        streamtype = 'HLSRETRY'
        #streamtype = 'HLSREDIR'
        f4mp.playF4mLink(
            video_url
            , name
            , proxy = None
            , use_proxy_for_chunks = False
            , maxbitrate = max_bit_rate_download
            , simpleDownloader = False
            , auth = None
            , streamtype = streamtype
            , setResolved = False
            , swf = None
            , callbackpath = ""
            , callbackparam = ""
            , iconImage = iconimage
            , download_path = download_path
            )
        return
            
    elif playmode_string == utils.PLAYMODE_INPUTSTREAM:

##        streamate_headers['Accept-Charset'] = ""
##        streamate_headers['Accept'] = "application/x-mpegurl; charset=utf-8; */*"
##        streamate_headers['Connection'] = "keep-alive"
##        streamate_headers['Origin'] = "https://www.streamate.com"
##        Log("streamate_headers='{}'".format(streamate_headers))

        video_url = "{}{}".format(video_url, utils.Header2pipestring(streamate_headers) )
        Log("inputstream does not work for this site ... going direct")
        
##        if ".m3u8" in video_url:
##            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
##            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
##            listitem.setProperty('inputstream.adaptive.stream_headers'
##                                ,  utils.Header2pipestring(streamate_headers)
##                                )
##            Log("using inputstream")
    else:
        utils.notify(name,'Unknown playmode for webcam link')

    Log("video_url='{}'".format(video_url)  )

    #xbmc.Player().stop()
    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( video_url, listitem)
    xbmc.Player().play(myPlayList)
    
        
    return
                
    response = utils.getHtml("https://streamate.com/ajax/config/?name=" + name + "&sakey=&sk=streamate.com&userid=0&version=2.2.0&ajax=1")
    data = json.loads(response)
    Log("data='{}'".format(data))
    
    host = data['liveservices']['host'] + "/socket.io/?puserid=" + performerID + "&EIO=3&transport=websocket"
    ws = websocket.WebSocket()
    Log(host)
    ws = websocket.create_connection(host)





    ws.send('40/live')

    quitting = 0
    while quitting == 0:
        message =  ws.recv()
        Log(message,xbmc.LOGNONE)
        
        match = re.compile('performer offline', re.DOTALL | re.IGNORECASE).findall(message)
        if match:
           quitting=1
           ws.close()
           utils.notify('Model is offline')
           return None

        match = re.compile('isPaid":true', re.DOTALL | re.IGNORECASE).findall(message)
        if match:
           quitting=1
           ws.close()
           utils.notify('Model not in freechat')
           return None
		   
        match = re.compile('roomInfoUpdate', re.DOTALL | re.IGNORECASE).findall(message)
        if match:
           ws.send('42/live,["GetVideoPath",{"nginx":1,"protocol":2,"attempt":1}]')
           while quitting == 0:
              message = ws.recv()
              Log(message,xbmc.LOGNONE)
              match = re.compile('(http[^"]+m3u8)', re.DOTALL | re.IGNORECASE).findall(message)
              if match:
                  videourl = match[0]
                  quitting=1
                  ws.close()

    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    listitem.setProperty("IsPlayable","true")
    if int(sys.argv[1]) == -1:
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()
        pl.add(videourl, listitem)
        xbmc.Player().play(pl)
    else:
        listitem.setPath(str(videourl))
        xbmcplugin.setResolvedUrl(utils.addon_handle, True, listitem)

#__________________________________________________________________________
#

@utils.url_dispatcher.register('519', ['url'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    return True

    if (not keyword):
        keyword = utils._get_keyboard(heading="Searching for...")
        if (not keyword):
            return False, 0

    try:
        response = utils.getHtml(searchUrl + keyword)
    except:
        utils.notify('Model not found - try again')
        return None
    
    match = re.compile("p_signupargs: 'smid%3D([^']+)'", re.DOTALL | re.IGNORECASE).findall(response)
    if match:
        utils.notify('Found ' + keyword + ' adding to favorites now')
        img = "http://m1.nsimg.net/media/snap/" + match[0] + ".jpg"
        performerID = match[0]
        name = keyword
##        favorites.Favorites('add', PLAY_MODE, name, performerID, img)

#__________________________________________________________________________
#

def Test(keyword):

    return True

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#
