'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin,xbmc
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

LIST_AREA = utils.LIST_AREA_MOVIES

FRIENDLY_NAME = '[COLOR {}]jav.guru[/COLOR]'.format(utils.time_text_color)

FRONT_PAGE_CANDIDATE = True


ROOT_URL = "https://jav.guru"

SEARCH_URL = ROOT_URL + '/page/{}/?s={}'
#https://jav.guru/page/1/?s=ai+sayama

URL_RECENT = ROOT_URL + '/page/{}/'
#https://jav.guru/category/english-subbed/page/2/
#https://jav.guru/category/jav-uncensored/

FIRST_PAGE = '1' #default first page

MAIN_MODE       = '960'
LIST_MODE       = str(int(MAIN_MODE) + 1)
PLAY_MODE       = str(int(MAIN_MODE) + 2)
CATEGORIES_MODE = str(int(MAIN_MODE) + 3)
SEARCH_MODE     = str(int(MAIN_MODE) + 4)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

##    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
##                SPACING_FOR_TOPMOST, utils.search_text_color) 
##                ,url = URL_CATEGORIES
##                ,mode = CATEGORIES_MODE
##                ,iconimage=utils.category_icon )

    List(URL_RECENT, page=FIRST_PAGE, end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword', 'testmode'])
def List(url, page=None, end_directory=True, keyword='', testmode=False):

    Log("List [url='{}', page='{}', end_directory='{}', keyword='{}']".format(url,page,end_directory,keyword))

    inband_recurse = (keyword==utils.INBAND_RECURSE)
    if inband_recurse:
        end_directory=False
        max_search_depth = utils.MAX_RECURSE_DEPTH
    else:
        max_search_depth = utils.DEFAULT_RECURSE_DEPTH
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE
            ,page=FIRST_PAGE
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url)) 
    listhtml = utils.getHtml(list_url)
    if "I can't find porn to your request" in listhtml:
        video_region = ""
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on {}".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon )
    else: #distinguish between adverts and videos
        video_region = listhtml.split('<ul class="actions pagination">')[0] # re.compile('(.+)<a href="([^"]+)"[^>]+>Next', re.DOTALL | re.IGNORECASE).findall(listhtml)[0][0]


    #
    # parse out list items
    #
    regex = '<article.+?href="([^"]+)".+?src="([^"]+)".+?alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label in info:
        desc = label
        label = utils.cleantext(label.split(']')[-1]).strip()
        label = "{}{}".format(SPACING_FOR_NAMES, label)
        if not thumb.startswith('http'): thumb = 'https:' + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("desc={}".format(desc))
        desc = u"{}".format(desc.decode('utf8'))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , desc=u"{}\n{}".format(desc,ROOT_URL)
            )
            #, duration=duration )
    #
    # check for a minimum during tesing
    #
    if len(info) < 1:
        name = "[COLOR {}]No results[/COLOR] found {}".format('purple', list_url )
        utils.addDownLink(
            name=name
            ,url=list_url
            ,mode=1
            ,iconimage='')
        if testmode:
            raise OSError
    
        
    #
    # next page items
    #
    next_page_regex = "class=(?:'pages'|\"pagination\").+?class=(?:'|\")current(?:'|\")>(\d+)<"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
##            Log("np_url={}".format(np_url))
            np_url = url
            np_number=int(page)+1
            #Log("np_url={}".format(np_url))
            #Log("np_number={}".format(np_number))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,section = utils.INBAND_RECURSE
                    ,keyword=keyword )
            else:
                if int(np_number) <= (max_search_depth):
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url
                         , page=np_number
                         , end_directory=end_directory
                         , keyword=keyword)
                    
    if end_directory == True or inband_recurse:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=FIRST_PAGE):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format('{}',keyword) 
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=page, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
        
#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    listhtml = utils.getHtml(url, '')
 
    regex = '<a href="([^"]+)"[^<]+<img src="([^"]+)" alt="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label in info:
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, label) 
        if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE 
            ,iconimage=thumb )
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page=FIRST_PAGE, end_directory=False, keyword='', testmode=True)
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=FIRST_PAGE)
##    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=False):

    Log("url='{}',name='{}',download='{}'".format(url,name,download))
    video_url = None
    source_html = utils.getHtml(url, ROOT_URL)


    regex_model_area = 'Actress:(.+)Studio'
    models_html = re.compile(regex_model_area, re.DOTALL | re.IGNORECASE).findall(source_html)
    if models_html: models_html=models_html[0]
    else: models_html = ''
    regex_model = '/actress/.+?rel="tag">(?P<model>[^<]+)<'
    source_models = re.compile(regex_model, re.DOTALL | re.IGNORECASE).finditer(models_html)
    description = ''
    desc_separator_char = '; '
    if source_models:
        for model in source_models:
            description = description + desc_separator_char + model.group('model')
    description = description.strip(desc_separator_char)
    if description == '':  description=name + '\n' + ROOT_URL
    else:           description=description + '\n' + ROOT_URL
    Log("description={}".format(description))



    headers = utils.DEFAULT_HEADERS.copy()
    headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    
    regex_vid_sources = '","iframe_url":"([^"]+)"'
    vid_sources = re.compile(regex_vid_sources, re.DOTALL | re.IGNORECASE).findall(source_html)
    source_html = ''
    sources = {}
    import base64
    for vid_source in vid_sources:
        Log("vid_source={}".format(vid_source))
        src = base64.b64decode(vid_source).split('&bg=')[0]
        Log("src={}".format(src))
        if 'd=' in src:
            src_forward = src.split('d=')[1]
            src_reverse = src.split('d=')[0] + 'r=' + src_forward[::-1]
        else:
            if '?bg=' in src:
                src_reverse = src.split('?bg=')[0]
##        Log("src_forward={}".format(src_forward))
        Log("src_reverse={}".format(src_reverse))
        headers['Referer'] = src
        url = src_reverse
        locker_html, locker_url = utils.getHtml(url, headers=headers, send_back_redirect=True)
        Log("locker_url={}".format(locker_url))
        if not locker_url:
            locker_url = url
        source_html = source_html + locker_url + "  "

    if source_html == '':
        utils.notify('Oh oh','Couldn\'t find a supported videohost')
        return
##    if not video_url.startswith('http'): video_url = 'https:' + video_url

    Log("source_html={}".format(source_html))

    utils.playvideo(videosource=source_html, name=name, download=download, description=description, url=url)

#__________________________________________________________________________
#
