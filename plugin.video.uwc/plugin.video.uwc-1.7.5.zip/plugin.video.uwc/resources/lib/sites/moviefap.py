'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import re
import urllib
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log as Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

FRIENDLY_NAME = '[COLOR {}]moviefap[/COLOR]'.format(utils.time_text_color)
LIST_AREA = utils.LIST_AREA_TUBES
FRONT_PAGE_CANDIDATE = False

ROOT_URL = "https://www.moviefap.com"

SEARCH_URL = ROOT_URL + '/search/{}/relevance/'
#https://www.moviefap.com/search/lexi+belle/relevance/1

URL_CATEGORIES = ROOT_URL + '/categories/'
URL_RECENT = ROOT_URL + '/browse/mr/{}'

MAIN_MODE       = '580'
LIST_MODE       = '581'
PLAY_MODE       = '582'
CATEGORIES_MODE = '583'
SEARCH_MODE     = '584'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.search_text_color) 
                ,url = URL_CATEGORIES
                ,mode = CATEGORIES_MODE
                ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon)
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    listhtml, redirected_url = utils.getHtml(list_url, send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "page that you are looking for does not" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}' on '{}'".format(keyword,ROOT_URL)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
            video_region = listhtml.split('id="browse_full"')[1].split('id="pagination_holder"')[0]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))


    #
    # parse out list items
    #
    regex = '<a href="([^"]+)" class="videothumb">.+?<img src="([^"]+)" onMouseOver="[^"]+" onMouseOut="[^"]+" width="[^"]+" height="[^"]+" border="[^"]+" alt="([^"]+)".+?<div class="videoleft">(\d+[:]\d+)<br'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, thumb, label, duration in info:
        #Log("label={}".format(label))
        #Log("hd={}".format(hd))
        if   '2160' in label: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in label: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '720' in label: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
        #thumb = thumb + "|Referer=" + list_url
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #Log("label={}".format(label))
        #Log("duration={}".format(duration))
        #Log("thumb={}".format(thumb))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration=duration )



    #
    # next page items
    #
    try:
        next_page_html = listhtml.split('id="pagination_holder"')[1]
    except:
        #utils.Notify(msg="Unable to distinguish next_page_html for '{}'".format(list_url), duration=200)  #let user know something is happening
        next_page_html = listhtml
    #Log("next_page_html={}".format(next_page_html))
    next_page_regex = '<a href="(/[^"]+/\d+)">next &gt;&gt;</a></div></div>'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url in np_info:
##            Log("np_url={}".format(np_url))
            np_number = ''
            if not np_number.isdigit(): np_number=np_url.split('/')[-1]
            if not np_url.startswith('http'): np_url = ROOT_URL + np_url
##            Log("np_number={}".format(np_url))
##            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, int(np_number))
            if end_directory == True:
                utils.addDir(
                    name=np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number
                    ,keyword=keyword )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    
    keyword = keyword.replace(' ','+')
    searchUrl = SEARCH_URL.format(keyword) + '{}'
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    listhtml = utils.getHtml(url)

    regex = '<a href=\"(https://www\.moviefap\.com/[^\"]+)\"><img src=\"([^\"]+)\" alt=\"([^\"]+)\"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videourl, thumb, label   in info:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, utils.cleantext(label)) 
        #if not thumb.startswith('http'): thumb = ROOT_URL + thumb
        #if not videourl.startswith('http'): videourl = ROOT_URL + '/ajax/show_category' + videourl + '?page={}'
        #Log("thumb={}".format(thumb))
        utils.addDir(
            name=label
            ,url=videourl
            ,mode=LIST_MODE
            ,page=1
            ,iconimage=thumb) #utils.search_icon)
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    source_html1 = utils.getHtml(url, ROOT_URL)
    regex = "jQuery.ajax\(\{\s+async: false,\s+url: '([^']+)'"
    source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)
    if source_url2: #2019 version of page
        source_url2 = source_url2[0]
        source_html2 = utils.getHtml(source_url2, url)
        regex = '<res>([^<]+)<.*?<videoLink>([^<]+)<'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
        #Log("sources_list={}".format(sources_list))
        video_url = utils.SortVideos(sources_list,download=download,vid_res_column=0)
        video_url = utils.html_parser.unescape(video_url)
        #Log("video_url={}".format(video_url))
        video_url = video_url + utils.Header2pipestring() + '&Referer=' + url
        
    else: #2018 version
        regex = 'flashvars.config = escape."([^ ]+)&VID='
        try:
            source_url2 = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html1)[0]
        except:
            Log("source_html1={}".format(source_html1))
##            import traceback
##            traceback.print_exc()
            raise
        
        
        source_url2 = source_url2 + utils.Header2pipestring() + '&Referer=' + url
        #Log("source_url2={}".format(source_url2))
        source_html2 = utils.getHtml(source_url2, url)
        regex = '<videoLink>(.+?)</videoLink>'
        sources_list = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(source_html2)
        #Log("sources_list={}".format(sources_list))
        video_url = sources_list[0]

    Log("video_url={}".format(video_url))
        
    utils.playvid(video_url, name, download, description='')

    
#__________________________________________________________________________
#
