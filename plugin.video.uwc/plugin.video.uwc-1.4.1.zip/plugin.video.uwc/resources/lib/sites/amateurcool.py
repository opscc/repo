'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils

spacing_for_topmost = ""
spacing_for_names = " "
spacing_for_next = "  "
SEARCH_URL = 'https://www.amateurcool.com/search/videos/{}/page1.html'

@utils.url_dispatcher.register('490')
def Main():
    #utils.addDir('[COLOR {}]Categories[/COLOR]'.format(utils.search_text_color),'http://anybunny.com/',493,'','')

    utils.addDir("{}[COLOR {}]Search[/COLOR]".format(spacing_for_topmost,utils.search_text_color), SEARCH_URL , 494,'','')
    List('https://www.amateurcool.com/most-recent/')
    utils.add_sort_method()
    utils.endOfDirectory()

@utils.url_dispatcher.register('491', ['url'] , ['end_directory'] )
def List(url, end_directory=True):

    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None
    
    match = re.compile(r'data-video="(.+?)">.+?<img src="(.+?)" alt="(.+?)".+?<span>(.+?) Video</span>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if match:
        for videopage, img, name, duration in match:
            #name = utils.cleantext(name + ' [COLOR deeppink]' +  duration + '[/COLOR]' )
            name = spacing_for_names + utils.cleantext(name)
            utils.addDownLink(name, videopage, 492, img, '', duration=duration)
    else:
        utils.addDir("nothing found for {}".format(url), url, 492, "", "", Folder=True)

    try:
        nextp = re.compile("class=\"pagination.+?href='([^\']+)' class=\"next\"", re.DOTALL | re.IGNORECASE).findall(listhtml)
        if nextp:
            utils.Log("nextp="+nextp[0],xbmc.LOGNONE)
            np_label = "{}[COLOR {}]Next Page {}[/COLOR]".format(spacing_for_next,utils.search_text_color, "")
            np_url = url[:url.rfind('/')+1] + nextp[0]
            utils.addDir(np_label, np_url, 491 , '')
    except:
        pass

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register('492', ['url', 'name'], ['download'])
def Playvid(videourl, name, download=None):
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)

@utils.url_dispatcher.register('493')
def Categories():
    cathtml = utils.getHtml('http://www.amateurcool.com/most-recent/', '')
    match = re.compile("<a href=\'http://www.amateurcool.com/channels/(.+?)\'>(.+?)</a>").findall(cathtml)
    for catid, name in match:
        catpage = "http://www.amateurcool.com/channels/"+ catid
        utils.addDir(name, catpage, 491, '')
    utils.add_sort_method()
    utils.endOfDirectory()

@utils.url_dispatcher.register('494', ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    if not keyword:
        utils.Log("not keyword",xbmc.LOGNONE)
        utils.searchDir(url, 494)
    else:
        title = keyword.replace(' ','-')
        title = keyword.replace('+','-')
        searchUrl = SEARCH_URL.format(title)
        utils.Log("searchUrl={}".format(searchUrl) , xbmc.LOGNONE)        
        List(searchUrl, end_directory)
        if end_directory == True:
            utils.add_sort_method()
            utils.endOfDirectory()
            
