# -*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr33m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import urllib, urllib2

from resources.lib import utils
from resources.lib.utils import Log as Log



#play with this to get sorting working the way I want
spacing_for_topmost = ""
spacing_for_names = ""
spacing_for_next = ""
MAX_SEARCH_DEPTH = 10
URL_ROOT = "https://www.xvideospanish.net"
SEARCH_URL="https://www.xvideospanish.net/?s="


@utils.url_dispatcher.register('130')
def Main():
    List(URL_ROOT)
    utils.add_sort_method()
    utils.endOfDirectory()

@utils.url_dispatcher.register('131', ['url'])
def List(url):
    #utils.addDir("  [COLOR {}]Search[/COLOR]".format(utils.search_text_color)
    #, SEARCH_URL,134,'','')
    utils.addDir(name="[COLOR {}]Search[/COLOR]".format( \
        utils.search_text_color) \
        ,url=SEARCH_URL \
        ,mode=134 \
        ,iconimage=utils.search_icon \
        ,Folder=True \
        )
    
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None

    #sometimes the list of items returned will have a 'duration', sometimes not...
    #to get around this, have two regex, for 'search' results, use non-duration
    if "Search results for" in listhtml:
        is_search = True
        list_regex = '<article id=.+?<a href=\"([^\"]+)\" title=\"([^\"]+)\".+?(?:img data-src|poster)=\"([^\"]+)\"'
    else:
        is_search = False
        list_regex = '<article id=.+?<a href=\"([^\"]+)\" title=\"([^\"]+)\".+?(?:img data-src|poster)=\"([^\"]+)\".+?class=\"duration\".+?</i>([^<]+)</span'        


    
    match = re.compile(list_regex, re.DOTALL | re.IGNORECASE | re.DOTALL ).findall(listhtml)
    if is_search:
        for videopage, name, img in match:
            name = " " + utils.cleantext(name)
            img = img.replace('www.xvideos-español.com', 'www.xvideospanish.net')
            videopage = videopage.replace('www.xvideos-español.com', 'www.xvideospanish.net')
            utils.addDownLink(name, videopage, 132, img, '')
    else:
        for videopage, name, img, duration in match:
            name = " " + utils.cleantext(name)
            img = img.replace('www.xvideos-español.com', 'www.xvideospanish.net')
            videopage = videopage.replace('www.xvideos-español.com', 'www.xvideospanish.net')
            utils.addDownLink(name, videopage, 132, img, '', duration=duration)
        
    try:
        nextp=re.compile('<link rel="next" href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
        np_url= nextp[0].replace('www.xvideos-español.com', 'www.xvideospanish.net')
        np_number=nextp[0].split('/')[4]
        #utils.addDir("[COLOR {}]Next Page ({})[/COLOR]".
        #format(utils.search_text_color, np_number), np_url,
        #131, '', np_number)
        utils.addDir(name=" [COLOR {}]Next Page ({})[/COLOR]".format( \
            utils.search_text_color, np_number) \
            ,url=np_url \
            ,mode=131 \
            ,iconimage=utils.next_icon \
            ,page=np_number \
            ,Folder=True \
            )
        
    except:
        pass

    utils.add_sort_method()
    utils.endOfDirectory()


@utils.url_dispatcher.register('134', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 134)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)

@utils.url_dispatcher.register('133', ['url'])
def Categories(url):
    Log(url)
    cathtml = utils.getHtml(url, '')
    match = re.compile('data-original="([^"]+)".*?href="([^"]+)">([^<]+)<.*?strong>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for img, catpage, name, videos in match:
        name = "{} [COLOR {}] {} videos[/COLOR]".format(name, utils.search_text_color, videos)
        utils.addDir(name, catpage, 131, img)
    utils.endOfDirectory()   


@utils.url_dispatcher.register('132', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    cathtml = utils.getHtml(url, url)
    #parse out and ... 
    #2019-02-05
    match1 = re.compile('itemprop="embedURL" content="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(cathtml)

    #2019-05-17 style..
    match = re.compile('<iframe src=\"https://datoporn\.co/([^"]+)\"', re.DOTALL | re.IGNORECASE).findall(cathtml)
    if match:
        utils.PLAYVIDEO("https://datoporn.co/"+match[0], name, download)
        return


    match = re.compile('content=\"https://openload\.co/embed/([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(cathtml)
    if match:
        for iframestring in match:
            embed_url_string = "https://openload.co/embed/" + iframestring
            Log("embed_url_string='{}'".format(embed_url_string))
            utils.playvideo(embed_url_string, name, download, embed_url_string)
        return
    
    match = re.compile('<iframe src=\"https://(openload\.co/embed/|embed\.redtube\.com/\?|datoporn\.co/|www\.pornhub\.com/embed/)([^>]+)\"></iframe>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    if match:
        for hoster, iframestring in match:
            embed_url_string = '<iframe src=\"https://' + hoster + iframestring + "></iframe>"
            Log("embed_url_string='{}'".format(embed_url_string))
            embed_url_string = urllib.quote_plus(embed_url_string)
            Log("embed_url_string='{}'".format(embed_url_string))

            from requests import Request, Session
            s = Session()
            headers = {"User-Agent": utils.USER_AGENT
                       , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                       , "Referer": url
                       }
            data = "action=ctpl_load_player&iframe_index=1&iframe_tag=" + embed_url_string

            req = Request('POST', url, data=data, headers=headers)
            prepped = s.prepare_request(req)
            proxies = {"http": "127.0.0.1:8888"}
            resp = s.send(prepped , proxies=proxies , verify=False)
            Log(resp.status_code)

            Log("resp.content='{}'".format(repr(resp.content)))

            import json
            json_newurl = json.loads(resp.content)['new_content']
            #Log("json_newurl='{}'".format(json_newurl))

            match = None
            match_720 = re.compile('src=\"([^\"]+)\".*?\"720p\"', re.DOTALL | re.IGNORECASE).findall(json_newurl)
            match_480 = re.compile('src=\"([^\"]+)\".*?\"480p\"', re.DOTALL | re.IGNORECASE).findall(json_newurl)
            match_240 = re.compile('src=\"([^\"]+)\".*?\"240p\"', re.DOTALL | re.IGNORECASE).findall(json_newurl)
            match_XXX = re.compile('src=\"([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(json_newurl)
            
            if match_720: match = match_720[0]
            elif match_480: match = match_480[0]
            elif match_240: match = match_240[0]
            elif match_XXX: match = match_XXX[0]
            
            if match:
                utils.playvid(match, name, download)
            else:
                utils.notify('Oh oh','Couldn\'t find a video')
            
                                                                                                                 
        return
    #else:
        #Log(cathtml)
    #    return
    
    if not match1:
        #old style
        #b4 2019-02-05 this was all that was required
        utils.PLAYVIDEO(url, name, download)        
        return
 

    #2019-02-05 style..
    referrer = match1[0]
    Log("referrer="+referrer)
    
    match2 = re.compile('itemprop="embedURL" content="([^&]+)&', re.DOTALL | re.IGNORECASE).findall(cathtml)
    begin_url = match2[0].split('id=')[0]
    id_url = match2[0].split('id=')[1]

    
    Log(match2[0])
    #... reverse the string
    videourl = begin_url + 'ir=' + id_url[::-1]

    Log("videourl="+videourl)
    #add required headers
    headers = { 'Referer': referrer
                , 'User-Agent': utils.USER_AGENT}
    
    #videourl_with_headers = "{}{}&Referer={}".format(videourl, utils.Header2pipestring(), referrer)
    videourl_with_headers = "{}|{}".format(videourl, urllib.urlencode(headers))
    Log("videourl_with_headers="+videourl_with_headers)

    req = urllib2.Request(videourl)
    req.add_header('Referer', referrer)
    req.add_header('User-Agent', utils.USER_AGENT)
    
    response = urllib2.urlopen(req, timeout=60)
    location = response.info().get('Location')
    Log(  repr(response) )
    Log(response.geturl())
    utils.playvideo(response.geturl(), name, download=download, url=videourl)
    

##GET https://openload.co/stream/5xyKI-fNxsg~1549475847~108.175.0.0~N7lYpDic?mime=true HTTP/1.1
##Host: openload.co
##Connection: keep-alive
##DNT: 1
##Accept-Encoding: identity;q=1, *;q=0
##User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36
##chrome-proxy: frfr
##Accept: */*
##Referer: https://openload.co/embed/5xyKI-fNxsg//
##Accept-Language: en-US,en;q=0.9
##Range: bytes=0-
##

        
    #return
    #utils.playvid(videourl_with_headers, name, download)

    return

    #b4 2019-02-05 this was all that was required
    utils.PLAYVIDEO(url, name, download)
