'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc,xbmcplugin,urllib
from resources.lib import utils
from resources.lib.utils import Log as Log

#play with this to get sorting working the way I want
spacing_for_topmost = ""
spacing_for_names = ""
spacing_for_next = ""
MAX_SEARCH_DEPTH = 10
URL_ROOT = "https://www.ero-tik.com"
SEARCH_URL = URL_ROOT+"/search.php?keywords="

@utils.url_dispatcher.register('260')
def Main():

    #utils.addDir('[COLOR hotpink]Categories[/COLOR]','http://www.ero-tik.com',263,'','')
    utils.addDir(name="[COLOR {}]Categories[/COLOR]".format( \
        utils.search_text_color) \
        ,url=URL_ROOT \
        ,mode=263 \
        ,iconimage=utils.search_icon \
        ,Folder=True \
        )
    
    #utils.addDir('[COLOR hotpink]Top Rated[/COLOR]','http://www.ero-tik.com/topvideos.html?page=1',261,'','')
    utils.addDir(name="[COLOR {}]Top Rated[/COLOR]".format( \
        utils.search_text_color) \
        ,url=URL_ROOT + '/topvideos.html?page=1' \
        ,mode=261 \
        ,iconimage=utils.search_icon \
        ,Folder=True \
        )
    
    #utils.addDir('[COLOR hotpink]Most Liked[/COLOR]','http://www.ero-tik.com/topvideos.html?do=rating&page=1',261,'','')
    utils.addDir(name="[COLOR {}]Most Liked[/COLOR]".format( \
        utils.search_text_color) \
        ,url=URL_ROOT + '/topvideos.html?do=rating&page=1' \
        ,mode=261 \
        ,iconimage=utils.search_icon \
        ,Folder=True \
        )
    
    #utils.addDir('[COLOR hotpink]Search[/COLOR]','http://www.ero-tik.com/search.php?keywords=',264,'','')
    utils.addDir(name="[COLOR {}]Search[/COLOR]".format( \
        utils.search_text_color) \
        ,url=URL_ROOT + '/search.php?keywords=' \
        ,mode=264 \
        ,iconimage=utils.search_icon \
        ,Folder=True \
        )
    
    List(URL_ROOT + '/newvideos.html?page=1')

    utils.add_sort_method()
    utils.endOfDirectory()

@utils.url_dispatcher.register('261', ['url'], ['end_directory'])
def List(url, end_directory=True):

    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None

    match = re.compile('pm-li-video.*?href="([^"]+)".*?src="([^"]+)".*?alt="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
        name = spacing_for_names + utils.cleantext(name)
        #utils.addDownLink(name, videopage, 262, img, '')
        utils.addDownLink( \
            name = name \
            , url = videopage \
            , mode = 262 \
            , iconimage = img \
            , desc = '' \
            , stream = False )
        

    try:
        nextp=re.compile('<a href="([^"]+)">&raquo;', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
##        if re.search('http', nextp, re.DOTALL | re.IGNORECASE):
##            next = nextp
##        else:
##            next = "http://www.ero-tik.com/" + nextp
        nextp = nextp.replace(" ", "+") #website does not doe this properly for search pages...
        if not nextp.startswith("http"):
            np_url = URL_ROOT + '/' + nextp
        else:
            np_url = nextp
            
        np_number=nextp.split('&page=')[1]

        #utils.addDir('Next Page', next, 261,'')
        utils.addDir(name="{}[COLOR {}]Next Page ({})[/COLOR]".format( \
            spacing_for_next, utils.search_text_color, np_number) \
            ,url=np_url \
            ,mode=261 \
            ,iconimage=utils.next_icon \
            ,page=np_number \
            ,Folder=True \
            )
        
    except:
        import traceback
        traceback.print_exc()
        pass

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()


@utils.url_dispatcher.register('264', ['url'], ['keyword'])    
def EROSearch(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 264)
        return

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    print "Searching URL: " + searchUrl
    List(searchUrl)


@utils.url_dispatcher.register('263', ['url'])
def EROCat(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<ul class="dropdown-menu">(.*?)</ul>', re.DOTALL | re.IGNORECASE).findall(cathtml)[0]
    match1 = re.compile('href="(http://www.ero-tik.com/browse-[^"]+)"[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(match)
    for catpage, name in match1:
        utils.addDir(name, catpage, 261, '')

    utils.add_sort_method()
    utils.endOfDirectory()


@utils.url_dispatcher.register('262', ['url', 'name'], ['download'])
def EROPlayvid(url, name, download=None):
    videosource = utils.getHtml(url, '')
    match = re.compile("embed_url: \"([^\"]+?)\"", re.DOTALL | re.IGNORECASE).findall(videosource)
    #Log("match='{}'".format(match), xbmc.LOGNONE) 
    videosource = utils.getHtml(url=match[0], referer=url)
    utils.playvideo(videosource, name, download=download, url=match[0])
    #utils.PLAYVIDEO(url, name, download)
