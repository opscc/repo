'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

addon = utils.addon

sortlistxt = [addon.getLocalizedString(30022), addon.getLocalizedString(30023), addon.getLocalizedString(30024),
            addon.getLocalizedString(30025)]   

SEARCH_URL = 'https://xtheatre.org/page/1/?filtre=title&display=extract&s='
URL_ROOT = "https://xtheatre.org/{}"
URL_SUFFIX_PAGE1 = 'hdporn/1'
URL_SUFFIX_GIRLS = "porn-actress.php"
URL_SUFFIX_STUDIOS = "porn-actress.php"
#;url=https://xtheatre.org/page/1/?filtre=title&display=extract&s=">



#play with this to get sorting working the way I want
spacing_for_topmost = ""
spacing_for_names = ""
spacing_for_next = ""

@utils.url_dispatcher.register('20')
def Main():

    utils.addDir('[COLOR {}]Categories[/COLOR]'.format(utils.search_text_color),'https://xxxmoviestream.com/categories/',22,'','')
    utils.addDir('[COLOR {}]Search[/COLOR]'.format(utils.search_text_color),SEARCH_URL,24,'','')
    #XTList('https://xxxmoviestream.com/category/movies/?filtre=date&display=extract',1)
    List('https://xtheatre.org/category/movies/?filtre=date&display=extract&filtre=title&display=extract')
    utils.add_sort_method()
    utils.endOfDirectory()

##@utils.url_dispatcher.register('25')
##def XTSort():
##    addon.openSettings()
##    XTMain()

##@utils.url_dispatcher.register('22', ['url'])
##def XTCat(url):
##    cathtml = utils.getHtml(url, '')
##
##    #match = re.compile('src="([^"]+)"[^<]+</noscript>.*?<a href="([^"]+)"[^<]+<span>([^<]+)</s.*?">([^<]+)', re.DOTALL | re.IGNORECASE).findall(cathtml)
##    #for img, catpage, name, videos in match:
##    match = re.compile('src="([^"]+)".*?title="([^"]+)".*?<a href="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(cathtml)
##    for img, name, videos in match:
##        #catpage = catpage + 'page/1/'
##        #name = name + ' [COLOR deeppink]' + videos + '[/COLOR]'
##        utils.addDir(name, videos, 21, img, 1)
##
##    #xbmcplugin.endOfDirectory(utils.addon_handle)

@utils.url_dispatcher.register('24', ['url'], ['keyword', 'end_directory'])
def Search(url, keyword=None, end_directory=True):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 24)
        return
    
    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("Searching URL: " + searchUrl)
    List(searchUrl)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

@utils.url_dispatcher.register('21', ['url'], ['end_directory'])
def List(url, end_directory=True):
##    sort = getXTSortMethod()
##    if re.search('\?', url, re.DOTALL | re.IGNORECASE):
##        url = url + '&filtre=' + sort + '&display=extract'
##    else:
##        url = url + '?filtre=' + sort + '&display=extract'
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None

    #match = re.compile(r'src="([^"]+?)" class="attachment.*?<a href="([^"]+)" title="([^"]+)".*?<div class="right">(.*?)</div>\s+</li>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    #for img, videopage, name, desc in match:
    match = re.compile('class=\"left\".*?src=\"http([^\"]+)\".*?title=\"([^\"]+)\".*?<a href=\"([^\"]+)\".*?<p>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match_len=len(match)
    #i = 0

    for img, name, videopage, desc in match:
        #i = i + 1
        img = "http" + img
        name = utils.cleantext(name)
        desc = utils.cleanhtml(desc)
        desc = utils.cleantext(desc)
        videopage = videopage.replace('#038;','&')
        Log("videopage={}".format(videopage))
        utils.addDownLink(name, videopage, 23, img, desc)

    next_page_regex = "class=\"pagination\".*?class=\"current\".*?href='([^']+)' class=\"inactive\">(([^<]+))<"
    match = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for url,pagenum,t2 in match:
        npage_url = url
        npage_url = npage_url.replace('#038;','&')
        Log("npage_url={}".format(npage_url))
        utils.addDir("[COLOR {}]Page {}[/COLOR]".format(utils.search_text_color, pagenum), npage_url, 21, '', '')

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()


@utils.url_dispatcher.register('23', ['url', 'name'], ['download'])
def XTVideo(url, name, download=None):
    utils.PLAYVIDEO(url, name, download)


def getXTSortMethod():
    sortoptions = {0: 'date',
                   1: 'title',
                   2: 'views',
                   3: 'likes'}
    sortvalue = addon.getSetting("sortxt")
    return sortoptions[int(sortvalue)]    
