'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin
from resources.lib import utils
from resources.lib.utils import Log

addon = utils.addon

sortlistxt = [addon.getLocalizedString(30022), addon.getLocalizedString(30023), addon.getLocalizedString(30024),
            addon.getLocalizedString(30025)]   

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://xtheatre.org"

SEARCH_URL = ROOT_URL + '/page/1/?filtre=title&display=extract&s='

URL_RECENT = ROOT_URL + '/category/movies/?filtre=date&display=extract&filtre=title&display=extract'

URL_SUFFIX_PAGE1 = 'hdporn/1'
URL_SUFFIX_GIRLS = "porn-actress.php"
URL_SUFFIX_STUDIOS = "porn-actress.php"
URL_CATEGORIES = ROOT_URL + "/categories/"


MAIN_MODE       = '20'
LIST_MODE       = '21'
PLAY_MODE       = '23'
CATEGORIES_MODE = '22'
SEARCH_MODE     = '24'

#__________________________________________________________________________
#  

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon )
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)        

    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url, ignore404=True)#, ignore404=True , send_back_redirect=True)
    
    #
    # parse out list items
    #
    regex = 'class=\"left\".*?src=\"http([^\"]+)\".*?title=\"([^\"]+)\".*?<a href=\"([^\"]+)\".*?<p>([^<]+)<'
    match = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    for img, name, videopage, desc in match:
        img = "http" + img #this site still requiers http only
        name = utils.cleantext(name)
        desc = utils.cleanhtml(desc)
        desc = utils.cleantext(desc)
        videopage = videopage.replace('#038;','&')
##        Log("videopage={}".format(videopage))
        utils.addDownLink( 
            name = name 
            , url = videopage 
            , mode = PLAY_MODE 
            , iconimage = img
            , desc=desc)


    next_page_regex = "class=\"pagination\".*?class=\"current\".*?href='([^']+)' class=\"inactive\">([^<]+)<"
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(list_url))
    else:
        for np_url, np_number in np_info:
            np_url = np_url.replace('#038;','&')
            Log("np_url={}".format(np_url))
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)

            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH
                if int(np_number) <= (MAX_SEARCH_DEPTH): #search some more, but not forever
                    utils.Notify(msg=np_url.format(np_number), duration=200)  #let user know something is happening
                    List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
            break # in case there are multiple pagination
        
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    
    cathtml = utils.getHtml(url)
    
    cat_page_regex = 'data-lazy-src.*?src=\"([^\"]+)\".*?href=\"([^\"]+)\".*?title=\"([^\"]+)\"'
    match = re.compile(cat_page_regex, re.DOTALL).findall(cathtml)
    for thumb, videourl, label in match:
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_NAMES, utils.search_text_color, label)
        utils.addDir(
            name=label
            ,url=videourl 
            ,mode=LIST_MODE 
            ,iconimage=thumb)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    
    utils.PLAYVIDEO(url, name, download)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
        
    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()
