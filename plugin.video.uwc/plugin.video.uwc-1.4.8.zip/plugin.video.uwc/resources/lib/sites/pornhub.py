'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 anton40

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

ROOT_URL = "https://www.pornhub.com"

SEARCH_URL = ROOT_URL + '/video/search?search='

# insert &o=mr  for mos recent vids
URL_CATEGORIES = ROOT_URL + '/categories?o=al'
URL_RECENT = ROOT_URL + '/video?o=cm'

MAIN_MODE       = '390'
LIST_MODE       = '391'
PLAY_MODE       = '392'
CATEGORIES_MODE = '393'
SEARCH_MODE     = '394'

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( \
            SPACING_FOR_TOPMOST, utils.search_text_color) \
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon )
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=SEARCH_URL 
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)        

        
    #
    # read html
    #
    if '{}' in url and page:
        list_url = url.format(page)
    else:
        list_url = url
    redirected_url = None
    Log("list_url={}".format(list_url))    
    listhtml = utils.getHtml(list_url)#, ignore404=True , send_back_redirect=True)
    if redirected_url:
        list_url = redirected_url
    if "but you can check other awesome vid" in listhtml:
        video_region = ''
        label = ""
        if not keyword == '': label = "Nothing found for '{}'".format(keyword)
        utils.addDir(
            name=label
            ,url=''
            ,mode=''
            ,iconimage=utils.next_icon)
    else: #distinguish between adverts and videos
        try:
##            regex = '(?:class="pages-nav-border"|id="vidresults")(.+?)(?:class="numlist2"|id="wrapBlocks")'
##            video_region = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
            video_region = listhtml.split('"sectionWrapper"')[1]
        except:
            utils.Notify(msg="Unable to distinguish video region for '{}'".format(list_url), duration=200)  #let user know something is happening
            video_region = listhtml
    #Log("video_region={}".format(video_region))
            
    #
    # parse out list items
    #    
    regex = 'class=\"preloadLine\".+?href=\"\/view_video\.php\?viewkey=([^\"]+)\" title=\"([^\"]+)\".+?data-thumb_url = \"([^\"]+)\".+?\"duration\">([^<]+)<\/'
    regex = 'videoblock.+?href="(/view_video\.php\?viewkey=[^"]+).+?title="([^"]+)".+?data-thumb_url = "([^"]+)".+?"duration">([^<]+)</.+?((?:<span class="hd-thumbnail">HD</span>|</div>))'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, thumb, duration, hd in info:
        if   '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif '1080' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  '>HD<' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        duration = duration.replace(' min','s').replace(':','m ')
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        #label = "{}{} {}".format(SPACING_FOR_NAMES, label, hd)
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration)

        
    #
    # next page items
    #
    next_page_regex = '<li class="page_next"><a href="(.+?)" class="orangeButton">Next'
    np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    if not np_info:
        Log("np_info not found in url='{}'".format(url))
    else:
        for np_url in np_info:
            np_number = np_url.split('=')[2]
            if not np_number.isdigit(): np_number=np_url.split('=')[3]
            if not np_number.isdigit(): np_number=np_url.split('=')[4]
            if not np_number.isdigit(): np_number=np_url.split('=')[5]
            if np_url.startswith('/'): np_url = ROOT_URL + np_url
            np_url= np_url.replace('&amp;','&')
            np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)

##            Log("np_number={}".format(np_number))
            if end_directory == True:
                utils.addDir(name= np_label
                    ,url=np_url 
                    ,mode=LIST_MODE 
                    ,iconimage=utils.next_icon 
                    ,page=np_number )
            else:
                MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH #set here to support 'search_all'
                if int(np_number) < (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                    utils.Notify(msg=np_url, duration=100)  #let user know something is happening
                    List(url=np_url, end_directory=end_directory, keyword=keyword)
                    
    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return
    
    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title
    Log("searchUrl='{}'".format(searchUrl))
    List(url=searchUrl, page=1, end_directory=end_directory, keyword=keyword)

    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):

    html = utils.getHtml(url, '')

    regex = '<div class="category-wrapper ">\s*?<a href="([^"]+)"\s*?alt="([^"]+)".*?<img.*?data-thumb_url="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(html)
    #Log("info='{}'".format(info))
    for url, label, thumb in info:
        if url.startswith('/'): url = ROOT_URL + url
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        if '?' in url:
            url = url + "&o=cm"
        else:
            url = url + "?o=cm"
##        Log("thumb='{}'".format(thumb))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color, label)
            ,url=url 
            ,mode=LIST_MODE 
            ,iconimage=thumb )

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
    
#__________________________________________________________________________
#

def Test(keyword):

    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])    
def Playvid(url, name, download=None):
    Log("url='{}'".format(url))
    html = utils.getHtml(url, '')
    match = re.compile(r"""quality_([0-9]{3,4})p\s*=(?:"|')?([^'";]+)(?:"|')?;""", re.DOTALL | re.IGNORECASE).findall(html)

    match = sorted(match, key=lambda x: int(x[0]), reverse=True)
    #Log("match='{}'".format(match))
    videolink = match[0][1]
    #Log("videolink='{}'".format(videolink))
    if "/*" in videolink:
        videolink = re.sub(r"/\*[^/]+/", "", videolink).replace("+","")

        linkparts = re.compile(r"(\w+)", re.DOTALL | re.IGNORECASE).findall(videolink)
        for part in linkparts:
            partval = re.compile(part+'="(.*?)";', re.DOTALL | re.IGNORECASE).findall(html)[0]
            partval = partval.replace('" + "','')
            videolink = videolink.replace(part, partval)

    videourl = videolink.replace(" ","")

    utils.playvid(videourl, name, download)

#__________________________________________________________________________
#
