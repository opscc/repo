#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmcplugin
from resources.lib import utils


@utils.url_dispatcher.register('460')
def Main():
    utils.addDir('[COLOR hotpink]Categories[/COLOR]','http://hentaihaven.org/pick-your-poison/',463,'','')
    utils.addDir('[COLOR hotpink]A to Z[/COLOR]','http://hentaihaven.org/pick-your-series/',464,'','')
    utils.addDir('[COLOR hotpink]Uncensored[/COLOR]','http://hentaihaven.org/ajax.php?action=pukka_infinite_scroll&page_no=1&grid_params=infinite_scroll=on&infinite_page=2&infinite_more=true&current_page=taxonomy&front_page_cats=&inner_grid%5Buse_inner_grid%5D=on&inner_grid%5Btax%5D=post_tag&inner_grid%5Bterm_id%5D=53&inner_grid%5Bdate%5D=&search_query=&tdo_tag=uncensored&sort=date',461,'','')
    List('http://hentaihaven.org/ajax.php?action=pukka_infinite_scroll&page_no=1&grid_params=infinite_scroll=on')
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('461', ['url'])
def List(url):
    try:
        listhtml = utils.getHtml(url, '')
    except:
        
        return None
    listhtml = listhtml.replace('\\','')
    match1 = re.compile('<a\s+class="thumbnail-image" href="([^"]+)".*?data-src="([^"]+)"(.*?)<h3>[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, other, name in match1:
        name = utils.cleantext(name)
        if 'uncensored' in other:
            name = name + " [COLOR hotpink]Uncensored[/COLOR]"        
        utils.addDownLink(name, videopage, 462, img, '')
    try:
        page = re.compile('page_no=(\d+)', re.DOTALL | re.IGNORECASE).findall(url)[0]
        page = int(page)
        npage = page + 1
        maxpages = re.compile(r'max_num_pages":(\d+)', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
        if int(maxpages) > page:
            nextp = url.replace("no="+str(page),"no="+str(npage))
            utils.addDir('Next Page ('+str(npage)+')', nextp,461,'')
    except: pass
    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register('462', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    videopage = utils.getHtml(url)
    if "<source" in videopage:
        videourl = re.compile('<source.*?src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    else:
        videourl = re.compile('class="btn btn-1 btn-1e" href="([^"]+)" target="_blank"', re.DOTALL | re.IGNORECASE).findall(videopage)[0]
    if videourl:
        videourl = "{}{}".format(videourl, utils.Header2pipestring())
        utils.playvid(videourl, name, download)
    else:
        utils.notify('Oh oh','Couldn\'t find a video')


@utils.url_dispatcher.register('463', ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('/tag/([^/]+)/" cla[^>]+>([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        catpage = "http://hentaihaven.org/ajax.php?action=pukka_infinite_scroll&page_no=1&grid_params=infinite_scroll=on&infinite_page=2&infinite_more=true&current_page=taxonomy&front_page_cats=&inner_grid%5Buse_inner_grid%5D=on&inner_grid%5Btax%5D=post_tag&inner_grid%5Bterm_id%5D=53&inner_grid%5Bdate%5D=&search_query=&tdo_tag=" + catpage + "&sort=date" 
        utils.addDir(name, catpage, 461, '')    
    xbmcplugin.endOfDirectory(utils.addon_handle)


#__________________________________________________________________________
#

def Test(keyword):
    return True
    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register('464', ['url'])
def A2Z(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile(r'class="cat_section"><a\s+href="([^"]+)"[^>]+>([^<]+)<.*?src="([^"]+)"(.*?)</div>', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name, img, other in match:
        if 'uncensored' in other:
            name = name + " [COLOR hotpink]Uncensored[/COLOR]"
        utils.addDir(name, catpage, 461, img)    
    xbmcplugin.endOfDirectory(utils.addon_handle)




##HTTP/1.1 200 OK
##Server: nginx
##Date: Sat, 29 Jun 2019 12:37:53 GMT
##Content-Type: text/html; charset=UTF-8
##Connection: keep-alive
##Vary: Accept-Encoding
##X-Powered-By: PHP/7.0.32
##Expires: Thu, 19 Nov 1981 08:52:00 GMT
##Cache-Control: no-store, no-cache, must-revalidate
##Pragma: no-cache
##Access-Control-Allow-Origin: *
##Content-Length: 2764
##
##<!doctype html><html> <head> <meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <title>Lilitales - Episode 2</title> <script src="https://stream.lewd.host/templates/jwplayer/assets/juicycodes.js"></script>
##
##<script>jwplayer.key = "";</script> </head> <body> <div id="video_player"></div><link href="./skins/flat.css" rel="stylesheet" type="text/css"/><script type="text/javascript" src="https://content.jwplatform.com/libraries/0P4vdmeO.js"></script>
##
##<style>html, body, .jwplayer.jw-flag-aspect-mode { height: 100%!important; }</style><script type="text/javascript">JuicyCodes.Run("ZXZhbChmdW5jdGlvbihwLGEsYyxrLGUsZCl7ZT1mdW5jdGlvbihjKXtyZXR1cm4oYzxhPycnOmUocGFyc2VJbnQoYy9hKS"+"kpKygoYz1jJWEpPjM1P1N0cmluZy5mcm9tQ2hhckNvZGUoYysyOSk6Yy50b1N0cmluZygzNikpfTtpZighJycucmVwbGFj"+"ZSgvXi8sU3RyaW5nKSl7d2hpbGUoYy0tKXtkW2UoYyldPWtbY118fGUoYyl9az1bZnVuY3Rpb24oZSl7cmV0dXJuIGRbZV"+"19XTtlPWZ1bmN0aW9uKCl7cmV0dXJuJ1xcdysnfTtjPTF9O3doaWxlKGMtLSl7aWYoa1tjXSl7cD1wLnJlcGxhY2UobmV3"+"IFJlZ0V4cCgnXFxiJytlKGMpKydcXGInLCdnJyksa1tjXSl9fXJldHVybiBwfSgnbSBwPTF0KCJEIik7bSBrPXtFOiJvJS"+"IsRzoibyUiLEg6IjE2OjkiLEo6SyxNOk4sTzoiUyIsVDoiRiBSIixROiJqOi8vaS5sLyIsUDoiMzovL0wuSS5xL3Itcz10"+"LXUtbiIsdjp7dzoieCIseToieiIsQToiIix9LEI6e0M6eyJVIjoiVyhhLGEsYSwxLjApIiwiMWgiOiIjMiIsIjFpIjoiIz"+"IiLH0sMWo6eyIxayI6IiMyIiwiViI6IiMyIn0sMW46eyIxZyI6IiMyIn19LDFvOlt7IjUiOiIzOi8vaC5nLmYuZS80L2Mv"+"MXAvZC8iLCI3IjoiMXEiLCJiIjoiNi84In0seyI1IjoiMzovL2guZy5mLmUvNC9jLzFyL2QvIiwiNyI6IjFzIiwiYiI6Ij"+"YvOCJ9LHsiNSI6IjM6Ly9oLmcuZi5lLzQvYy8xbS9kLyIsIjciOiIxZiIsImIiOiI2LzgifV0sWDoxZSwxZDp7NToiIiw0"+"OiJqOi8vaS5sLyIsMWM6IjFiLTFhIix9LDE5OnsxODoiIzE3IiwxNToiMTQiLDEzOiIxMiAxMSwgMTAgWiIsWToiIix9fT"+"twLjFsKGspOycsNjIsOTIsJ3x8YmYxZTJkfGh0dHBzfGxpbmt8ZmlsZXx2aWRlb3xsYWJlbHxtcDR8fDI1NXx0eXBlfE1K"+"dGdNUlRvYklKUHh3R3xkN2I2N2Q1NTgzYjZlODgxNGI2ODMyOGFiNjNhZmNkNHxob3N0fGxld2R8c3RyZWFtfGVkZ2UwNn"+"xoZW50YWloYXZlbnxodHRwfGNvbmZpZ3xvcmd8dmFyfHwxMDB8cGxheWVyfGNvbXx3TkFsaHMzTklUMkRrQ0VUYjBoU2VG"+"Y3NrZHd8N1Q5YWc3NUc1NHlBV1pjb0QyNlR1UFNad2tNczhCWHJlQmhyMVJOdUNaNllIbUF8dzEyODB8aDcyMHxhZHZlcn"+"Rpc2luZ3xjbGllbnR8dmFzdHxvZmZzZXR8cHJlfHRhZ3xza2lufGNvbnRyb2xiYXJ8dmlkZW9fcGxheWVyfHdpZHRofEhI"+"fGhlaWdodHxhc3BlY3RyYXRpb3xnb29nbGV1c2VyY29udGVudHxhdXRvc3RhcnR8ZmFsc2V8bGgzfGNvbnRyb2xzfHRydW"+"V8cHJpbWFyeXxpbWFnZXxhYm91dGxpbmt8UGxheWVyfGh0bWw1fGFib3V0dGV4dHxpY29uc3x0ZXh0YWN0aXZlfHJnYmF8"+"dHJhY2tzfGJhY2tncm91bmRDb2xvcnxTZXJpZnxTYW5zfE1TfFRyZWJ1Y2hldHxmb250RmFtaWx5fHxmb250U2l6ZXx8Zm"+"ZmZmZmfGNvbG9yfGNhcHRpb25zfGxlZnR8dG9wfHBvc2l0aW9ufGxvZ298bnVsbHw3MjBQfHRleHR8aWNvbnNBY3RpdmV8"+"aWNvbnNhY3RpdmV8bWVudXN8dGV4dEFjdGl2ZXxzZXR1cHw3MjB8dG9vbHRpcHN8c291cmNlc3wzNjB8MzYwUHw0ODB8ND"+"gwUHxqd3BsYXllcicuc3BsaXQoJ3wnKSwwLHt9KSkK");</script> </body></html>
##
##
##"eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('m p=W("D");m k={E:"o%",G:"o%",H:"16:9",J:K,M:N,O:"S",T:"F R",Q:"j://i.l/",P:"3://L.I.q/r=s-t-n",u:{v:"w",x:"y",z:"",},A:{B:{"C":"U(a,a,a,1.0)","1m":"#2","1p":"#2",},1q:{"1r":"#2","1g":"#2"},V:{"1o":"#2"}},1n:[{"5":"3://h.g.f.e/4/c/1l/d/","7":"1k","b":"6/8"},{"5":"3://h.g.f.e/4/c/1j/d/","7":"1i","b":"6/8"},{"5":"3://h.g.f.e/4/c/1h/d/","7":"1f","b":"6/8"}],X:1e,1d:{5:"",4:"j://i.l/",1c:"1b-1a",},19:{18:"#17",15:"14",13:"12 11, 10 Z",Y:"",}};p.1s(k);',62,91,'||bf1e2d|https|link|file|video|label|mp4||255|type|MJtgMRTobIJPxwG|d7b67d5583b6e8814b68328ab63afcd4|host|lewd|stream|edge14|hentaihaven|http|config|org|var||100|player|com|ADXa1MqN14K54ZrNZ7QjV79C_RLOAqs0mFXupD7qGpNjWm2SIAi1VS9ndxrRHslYDbreuBMaYNA|w1280|h720|advertising|client|vast|offset|pre|tag|skin|controlbar|icons|video_player|width|HH|height|aspectratio|googleusercontent|autostart|false|lh3|controls|true|primary|image|aboutlink|Player|html5|abouttext|rgba|tooltips|jwplayer|tracks|backgroundColor|Serif|Sans|MS|Trebuchet|fontFamily||fontSize||ffffff|color|captions|left|top|position|logo|null|720P|textactive|720|480P|480|360P|360|iconsActive|sources|text|iconsactive|menus|textActive|setup'.split('|'),0,{}))
##"
##
##"eval(
##
##function(p,a,c,k,e,d){
##e=function(c){
##return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}(
##'m p=W("D");m k={E:"o%",G:"o%",H:"16:9",J:K,M:N,O:"S",T:"F R",Q:"j://i.l/",P:"3://L.I.q/r=s-t-n",u:{v:"w",x:"y",z:"",},A:{B:{"C":"U(a,a,a,1.0)","1m":"#2","1p":"#2",},1q:{"1r":"#2","1g":"#2"},V:{"1o":"#2"}}
##,1n:[
##{"5":"3://h.g.f.e/4/c/1l/d/","7":"1k","b":"6/8"},
##{"5":"3://h.g.f.e/4/c/1j/d/","7":"1i","b":"6/8"},
##{"5":"3://h.g.f.e/4/c/1h/d/","7":"1f","b":"6/8"}],X:1e,1d:
##{5:"",4:"j://i.l/",1c:"1b-1a",},19:{18:"#17",15:"14",13:"12 11, 10 Z",Y:"",}};p.1s(k);',62,91,'||bf1e2d|
##https
##3
##|link|file|video|label|mp4||255|type|
##MJtgMRTobIJPxwG
##11
##|d7b67d5583b6e8814b68328ab63afcd4|host|lewd|stream|edge01
##|hentaihaven|http|config|org|
##var
##21
##||100|player|com|ADXa1MqN14K54ZrNZ7QjV79C_RLOAqs0mFXupD7qGpNjWm2SIAi1VS9ndxrRHslYDbreuBMaYNA|w1280|h720|advertising|client|vast|offset|pre|tag|skin|controlbar|icons|
##video_player|width|HH|height|aspectratio|googleusercontent|autostart|false|lh3|controls|true|primary|image|aboutlink|Player|html5|abouttext|rgba|tooltips|jwplayer|tracks|backgroundColor|Serif|Sans|MS|Trebuchet|fontFamily||fontSize||ffffff|color|captions|left|top|position|logo|null|720P|textactive|720|480P|480|360P|360|iconsActive|sources|text|iconsactive|menus|textActive|setup'.split('|'),0,{})
##
##)
##"
##
##
##eval(function(p, a, c, k, e, d) {
##    e = function(c) {
##        return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
##    }
##    ;
##    if (!''.replace(/^/, String)) {
##        while (c--) {
##            d[e(c)] = k[c] || e(c)
##        }
##        k = [function(e) {
##            return d[e]
##        }
##        ];
##        e = function() {
##            return '\\w+'
##        }
##        ;
##        c = 1
##    }
##    ;while (c--) {
##        if (k[c]) {
##            p = p.replace(new RegExp('\\b' + e(c) + '\\b','g'), k[c])
##        }
##    }
##    return p
##}('m p=W("D");m k={E:"o%",G:"o%",H:"16:9",J:K,M:N,O:"S",T:"F R",Q:"j://i.l/",P:"3://L.I.q/r=s-t-n",u:{v:"w",x:"y",z:"",},A:{B:{"C":"U(a,a,a,1.0)","1m":"#2","1p":"#2",},1q:{"1r":"#2","1g":"#2"},V:{"1o":"#2"}},1n:[{"5":"3://h.g.f.e/4/c/1l/d/","7":"1k","b":"6/8"},{"5":"3://h.g.f.e/4/c/1j/d/","7":"1i","b":"6/8"},{"5":"3://h.g.f.e/4/c/1h/d/","7":"1f","b":"6/8"}],X:1e,1d:{5:"",4:"j://i.l/",1c:"1b-1a",},19:{18:"#17",15:"14",13:"12 11, 10 Z",Y:"",}};p.1s(k);', 62, 91, '||bf1e2d|https|link|file|video|label|mp4||255|type|MJtgMRTobIJPxwG|d7b67d5583b6e8814b68328ab63afcd4|host|lewd|stream|edge01|hentaihaven|http|config|org|var||100|player|com|ADXa1MqN14K54ZrNZ7QjV79C_RLOAqs0mFXupD7qGpNjWm2SIAi1VS9ndxrRHslYDbreuBMaYNA|w1280|h720|advertising|client|vast|offset|pre|tag|skin|controlbar|icons|video_player|width|HH|height|aspectratio|googleusercontent|autostart|false|lh3|controls|true|primary|image|aboutlink|Player|html5|abouttext|rgba|tooltips|jwplayer|tracks|backgroundColor|Serif|Sans|MS|Trebuchet|fontFamily||fontSize||ffffff|color|captions|left|top|position|logo|null|720P|textactive|720|480P|480|360P|360|iconsActive|sources|text|iconsactive|menus|textActive|setup'.split('|'), 0, {}))
##
##
##p = "var player=jwplayer("video_player");var config={width:"100%",height:"100%",aspectratio:"16:9",autostart:false,controls:true,primary:"html5",abouttext:"HH Player",aboutlink:"http://hentaihaven.org/",image:"https://lh3.googleusercontent.com/ADXa1MqN14K54ZrNZ7QjV79C_RLOAqs0mFXupD7qGpNjWm2SIAi1VS9ndxrRHslYDbreuBMaYNA=w1280-h720-n",advertising:{client:"vast",offset:"pre",tag:"",},skin:{controlbar:{"icons":"rgba(255,255,255,1.0)","iconsActive":"#bf1e2d","iconsactive":"#bf1e2d",},menus:{"textActive":"#bf1e2d","textactive":"#bf1e2d"},tooltips:{"text":"#bf1e2d"}},sources:[{"file":"https://edge01.stream.lewd.host/link/MJtgMRTobIJPxwG/360/d7b67d5583b6e8814b68328ab63afcd4/","label":"360P","type":"video/mp4"},{"file":"https://edge01.stream.lewd.host/link/MJtgMRTobIJPxwG/480/d7b67d5583b6e8814b68328ab63afcd4/","label":"480P","type":"video/mp4"},{"file":"https://edge01.stream.lewd.host/link/MJtgMRTobIJPxwG/720/d7b67d5583b6e8814b68328ab63afcd4/","label":"720P","type":"video/mp4"}],tracks:null,logo:{file:"",link:"http://hentaihaven.org/",position:"top-left",},captions:{color:"#ffffff",fontSize:"14",fontFamily:"Trebuchet MS, Sans Serif",backgroundColor:"",}};player.setup(config);", e = ƒ ()
##
##
##
##
##https://edge06.stream.lewd.host/link/MJtgMRTobIJPxwG/360/d7b67d5583b6e8814b68328ab63afcd4/
