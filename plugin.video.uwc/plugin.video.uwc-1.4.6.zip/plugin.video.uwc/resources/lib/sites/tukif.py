'''
    Ultimate Whitecream
    Copyright (C) 2016 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT

#2019-07-21 site similar to porndig 
ROOT_URL = "https://tukif.com"

SEARCH_URL = ROOT_URL + '/search/{}'
#https://tukif.com/search/lexi+belle

URL_CATEGORIES_PRO = ROOT_URL

URL_CATEGORIES_AMATURE = ROOT_URL + '/amateur/videos/'
URL_CHANNELS = ROOT_URL + '/channels/'

MAIN_MODE       = '770'
LIST_MODE       = '771'
PLAY_MODE       = '772'
CATEGORIES_MODE = '773'
SEARCH_MODE     = '774'
CHANNELS_MODE   = '775'
STUDIOS_MODE    = '776'
PORNSTARS_MODE  = '777'


main_category_id_AMATURES = '4'
main_category_id_PROFESSIONALS = '1'
SECTION_DEFAULT = 0
SECTION_PORNSTARS = 2

SITE_HEADERS = {
            'User-Agent': utils.USER_AGENT
            ,'X-Requested-With': 'XMLHttpRequest'
            ,'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            ,'Accept': '*/*'
            ,'Accept-Encoding': 'gzip, deflate'
            ,'Accept-Language': 'en-US,en;q=0.8,nl;q=0.6'
            ,'Connection': 'keep-alive'
            ,'Cookie': ''
            }

#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE, ['channel'])
def Main(porn_amatuer):
    porn_amatuer = main_category_id_PROFESSIONALS
    porn_amatuer = str(porn_amatuer)
    Log("VideoListData() porn_amatuer={}".format(porn_amatuer))
    
    if porn_amatuer == main_category_id_PROFESSIONALS:
        URL_CATEGORIES = URL_CATEGORIES_PRO
    else:
        URL_CATEGORIES = URL_CATEGORIES_AMATURE

    utils.addDir(name="{}[COLOR {}]Categories[/COLOR]".format( 
        SPACING_FOR_TOPMOST, utils.search_text_color) 
        ,url=URL_CATEGORIES
        ,mode=CATEGORIES_MODE 
        ,iconimage=utils.search_icon 
        ,channel=porn_amatuer
        )

    #def List(channel, section, page=1, end_directory=True):
    List(porn_amatuer=porn_amatuer
         , category_or_star=SECTION_DEFAULT
         , page=1
         , end_directory=True)


#__________________________________________________________________________
#

def VideoListData(page, channel):
    Log("VideoListData() page={} channel={}".format(page,channel))
    
    sort = 'date'
    offset = (page-1) * 100
##    if addon.getSetting("pdsection") == '1':
##        catid = 4
##    else:
##        catid = 1
    values = {'main_category_id': channel,
              'type': 'post',
              'name': 'category_videos',
              'filters[filter_type]': sort,
              'filters[filter_period]': '',
              'offset': offset}
    return urllib.urlencode(values)

#__________________________________________________________________________
#

def CatListData(page, porn_amatuer, category_id):
    Log("CatListData() page={} channel={} category_id={}".format(page,porn_amatuer,category_id))
    sort = 'date'
    offset = (page-1) * 50
    values = {
              'main_category_id': porn_amatuer
              ,'type': 'post'
              ,'name': 'category_videos'
              ,'filters[filter_type]': sort
              ,'filters[filter_period]': ''
              ,'filters[filter_quality][]': '270'
              ,'offset': offset
              ,'category_id[]': category_id
              ,'filters[filter_duration][t1]': '45'
              ,'filters[filter_duration][t2]': '26'
              ,'filters[filter_duration][t3]': '15'
              ,'filters[filter_duration][t4]': '14'
              }
##    import collections
##    v = collections.OrderedDict()
##    v['main_category_id'] = porn_amatuer
##    v['type'] =  'post'
##    v['name'] =  'category_videos'
##    v['filters[filter_type]'] =  'date'
##    v['filters[filter_period]'] = ''
##    v['filters[filter_quality][]'] =  '270'
##    v['filters[filter_duration][t1]'] =  '45'
##    v['filters[filter_duration][t2]'] =  '26'
##    v['filters[filter_duration][t3]'] =  '15'
##    v['filters[filter_duration][t4]'] =  '14'
##    v['category_id[]'] =  category_id
##    v['offset'] =  offset
##    Log(v)
##    data = urllib.urlencode(v).replace('t1','').replace('t2','').replace('t3','').replace('t4','')
##    Log(data)
##    #return data
##    Log(values)
    data = urllib.urlencode(values).replace('t1','').replace('t2','').replace('t3','').replace('t4','')
##    Log(data)
    return data
#__________________________________________________________________________
#

def SearchData(page, channel, keyword):
    offset = (page-1) * 50
    values = {'main_category_id': channel,
              'type': 'post',
              'name': 'search_posts',
              'filters[filter_type]': 'date',
              'search': keyword,
              'offset': offset}
    return urllib.urlencode(values)

#__________________________________________________________________________
#

def VideoListStudio(page, channel):
    sort = 'date'
    offset = (page-1) * 65
    values = {'main_category_id': channel,
              'type': 'post',
              'name': 'studio_related_videos',
              'filters[filter_type]': sort,
              'filters[filter_period]': '',
              'offset': offset,
              'content_id': channel}
    return urllib.urlencode(values)




##def VideoListPornstar(page, channel, content_id):
##    sort = 'date'
##    offset = (page-1) * 30
##    values = {'main_category_id': channel,
##              'type': 'post',
##              'name': 'pornstar_related_videos',
##              'filters[filter_type]': sort,
##              'filters[filter_period]': '',
##              'offset': offset,
##              'content_id': content_id}
##    #content_id is the numeric value for the pornstar
##    return urllib.urlencode(values)
##
##def StudioListData(page, channel):
##    offset = (page-1) * 60
##    values = {'main_category_id': channel,
##              'type': 'studio',
##              'name': 'top_studios',
##              'filters[filter_type]': 'likes',
##              'starting_letter': '',
##              'offset': offset}
##    return urllib.urlencode(values)
##
##def PornstarListData(page, channel):
##    offset = (page-1) * 30
##    #main_category_id=1&type=pornstar&name=top_pornstars&filters%5Bfilter_type%5D=likes&country_code=&starting_letter=&offset=30
##    values = {'main_category_id': channel,
##              'type': 'pornstar',
##              'name': 'top_pornstars',
##              'filters[filter_type]': 'likes',
##              'country_code': '',
##              'starting_letter': '',
##              'offset': offset}
##    return urllib.urlencode(values)


#__________________________________________________________________________
#

@utils.url_dispatcher.register(PORNSTARS_MODE, ['url', 'channel'], ['page'])
def Pornstars(url, channel, page=1):
    data = PornstarListData(page, channel)
    urldata = utils.getHtml(url, ROOT_URL, hdr=SITE_HEADERS, data=data)
    urldata, has_more = ParseJson(urldata)
    i = 0
    match = re.compile(r'pornstar_([\d]+).*?alt="([^"]+)".*?Videos</div> <div class="value">([\d]+)',
                       re.DOTALL | re.IGNORECASE).findall(urldata)
    for ID, studio, videos in match:
        title = studio + " Videos: [COLOR deeppink]" + videos + "[/COLOR]"
        img = "http://static-push.porndig.com/media/default/pornstars/pornstar_" + ID + ".jpg"
        utils.addDir(title, '', LIST_MODE, img, 0, ID, 2)
        i += 1
    if i >= 60:
        page += 1
        utils.addDir('Page ' + str(page), url, PORNSTARS_MODE, '', page)
    xbmcplugin.endOfDirectory(utils.addon_handle)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(STUDIOS_MODE, ['url'], ['page'])
def Studios(url, page=1):

    data = StudioListData(page)
    urldata = utils.getHtml(url, referer=ROOT_URL, hdr=SITE_HEADERS, data=data)
    urldata, has_more = ParseJson(urldata)
    i = 0
    match = re.compile(r'studio_([\d]+).*?alt="([^"]+)".*?Videos</div> <div class="value">([\d]+)',
                       re.DOTALL | re.IGNORECASE).findall(urldata)
    for ID, studio, videos in match:
        title = studio + " Videos: [COLOR deeppink]" + videos + "[/COLOR]"
        img = "http://static-push.porndig.com/media/default/studios/studio_" + ID + ".jpg"
        utils.addDir(title, '', LIST_MODE, img, 0, ID, 1)
        i += 1
    if i >= 60:
        page += 1
        utils.addDir('Page ' + str(page), url, STUDIOS_MODE, '', page)
    xbmcplugin.endOfDirectory(utils.addon_handle)

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CATEGORIES_MODE, ['url', 'channel'])
def Categories(url, porn_amatuer):

    html = utils.getHtml(url, '')

    video_region = html.split('class="sidebar_category_list_wrapper"')[1]
    video_region = video_region.split('class="sidebar_section_title"')[0]

    regex = 'href="/channels/([^/]+)/.+?title="([^"]+)"'
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    Log("info='{}'".format(info))
    for category_or_star, label in info:
        #Log("category_or_star='{}'".format(category_or_star))
        label = utils.cleantext(label)
        label = "{}[COLOR {}]{}[/COLOR]".format(SPACING_FOR_TOPMOST, utils.search_text_color, label)
        utils.addDir(
            name=label
            ,url=porn_amatuer 
            ,mode=LIST_MODE 
            ,iconimage=utils.search_icon 
            ,Folder=True
            ,section=category_or_star
            ,page=1
            )

    utils.add_sort_method()
    utils.endOfDirectory()
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url', 'section'], ['page', 'keyword', 'end_directory'])
def List(porn_amatuer, category_or_star, page=1, keyword='', end_directory=True):

    Log("porn_amatuer={}".format(porn_amatuer))
    Log("category_or_star={}".format(category_or_star))
    Log("page={}".format(page))
    Log("keyword={}".format(keyword))
    Log("end_directory={}".format(end_directory))
    
    if end_directory == True:
        utils.addDir(name="{}[COLOR {}]Search[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=porn_amatuer
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon )
        utils.addDir(name="{}[COLOR {}]Search Recursive[/COLOR]".format( 
            SPACING_FOR_TOPMOST, utils.search_text_color) 
            ,url=porn_amatuer
            ,mode=SEARCH_MODE 
            ,iconimage=utils.search_icon
            ,end_directory=False, page=-1)        
        
    if category_or_star == SECTION_DEFAULT:
        data = VideoListData(page, porn_amatuer)
        post_url_suffix = "/posts/load_more_posts"
        regex = '<a.*?href="([^"]+)" title="([^"]+)".*?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)" title="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
    elif category_or_star == 1:
        data = VideoListStudio(page, porn_amatuer)
    elif category_or_star == SECTION_PORNSTARS:
        data = VideoListPornstar(page, porn_amatuer, category_or_star)
        post_url_suffix = "/pornstars/load_more_pornstars"
        regex = '<a href="([^"]+)" title="([^"]+)".*?img src="([^"]+)".*?(0)'
    elif category_or_star == 3:
        data = CatListData(page, channel)
    elif str(category_or_star) == SEARCH_MODE:
        data = SearchData(page, porn_amatuer, keyword)
        post_url_suffix = "/posts/load_more_posts"
        regex = '<a.*?href="([^"]+)" title="([^"]+)".*?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)" title="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
    else:
        data = CatListData(page, porn_amatuer, category_or_star)
        post_url_suffix = "/posts/load_more_posts"
        regex = '<a.*?href="([^"]+)" title="([^"]+)".*?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'
        regex = '<a.*?href="([^"]+)" title="([^"]+)".+?class="icon.+?qlt_(\S+).+?img src="([^"]+)".*?<span class="pull-left">([^<]+)<'

    #Log("data='{}'".format(data))

##    SITE_HEADERS['Cookie'] = 'main_category_id='+str(porn_amatuer)
##    urldata = utils.getHtml(ROOT_URL + post_url_suffix
##                            , hdr=(SITE_HEADERS)
##                            , data=data)
##
    SITE_HEADERS['Cookie'] = 'main_category_id='+str(porn_amatuer)
    urldata = utils.getHtml(ROOT_URL + post_url_suffix
                            , data=data)


    video_region, has_more = ParseJson(urldata)

    #Log("video_region ={}".format(video_region))
    
    info = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(video_region)
    for videourl, label, hd, thumb, duration in info:

        if   '4K' in hd or '2160' in hd or '1440' in hd: hd = "[COLOR {}]uhd[/COLOR]".format(utils.search_text_color)
        elif 'full_hd' in hd: hd = "[COLOR {}]fhd[/COLOR]".format(utils.refresh_text_color)
        elif  'hd' in hd: hd = "[COLOR {}]hd[/COLOR]".format(utils.time_text_color)
        else: hd = ""
        
##        label = utils.cleantext(label)
##        label = "{}{}".format(SPACING_FOR_NAMES, label)
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        
        if videourl.startswith('/'): videourl = ROOT_URL + videourl
        if thumb.startswith('/'): thumb = ROOT_URL + thumb
        #thumb = thumb + utils.Header2pipestring(SITE_HEADERS)
        duration = duration.replace(' min','')
##        Log("videourl={}".format(videourl))
##        Log("label={}".format(label))
##        Log("thumb={}".format(thumb))
##        Log("duration={}".format(duration))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration = duration
            , noDownload=False)
##        break

    if has_more == False:
        Log("np_info not found in url='{}'".format(porn_amatuer))
    else:
        np_number = page+1
        np_url = ROOT_URL + '/page=' + str(np_number) # this is a _FAKE_ url for this site only, used for Notify()
##        Log("np_url={}".format(np_url))
##        Log("np_number={}".format(np_number))
        np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
        if end_directory == True:
            utils.addDir(name= np_label
                ,url=porn_amatuer 
                ,mode=LIST_MODE 
                ,iconimage=utils.next_icon 
                ,page=np_number 
                ,Folder=True 
                ,channel=porn_amatuer
                ,section=category_or_star
                ,keyword=keyword
                )
        else:
            MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH
            if int(np_number) <= (MAX_SEARCH_DEPTH):    #search some more, but not forever  
                utils.Notify(msg=np_url, duration=100)  #let user know something is happening
                List(porn_amatuer=porn_amatuer
                     , keyword=keyword
                     , category_or_star=category_or_star
                     , page=np_number
                     , end_directory=end_directory)

    if  end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(SEARCH_MODE, ['url'], ['keyword', 'end_directory', 'page'])
def Search(searchUrl, keyword=None, end_directory=True, page=0):

    Log("Search(searchUrl={}, page={}, end_directory={}, keyword={}".format(searchUrl, page, end_directory, keyword))

    if not keyword:
        #utils.searchDir(searchUrl, SEARCH_MODE)
        utils.searchDir(url=searchUrl, mode=SEARCH_MODE, page=page, end_directory=end_directory)
        return

    title = keyword.replace(' ','+')
    Log("searchUrl='{}'".format(SEARCH_URL.format(title)))
    List(porn_amatuer=searchUrl, category_or_star=SEARCH_MODE, keyword=title, end_directory=end_directory)

    #if end_directory == True:
    if end_directory == True or str(page) == '-1':
        utils.add_sort_method()
        utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['download'])
def Playvid(url, name, download=None):

    videopage = utils.getHtml(url, referer=url, hdr=SITE_HEADERS, data='')
    links = re.compile('<a href="([^"]+)" class="post_download_link clearfix">[^>]+>.*?(\d+p).*?<',
                       re.DOTALL | re.IGNORECASE).findall(videopage)
    videourl = getVideoUrl(links)
    videourl = utils.getVideoLink(videourl, url)
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)

#__________________________________________________________________________
#

def getVideoUrl(testquality):
    #Log("testquality={}".format(testquality))
    if utils.addon.getSetting("allow_super_high_resolution").lower() == "true":
        s2160p_string = "2160p"
        s3840p_string = "3840p"
    else:
        s2160p_string = "60p"
        s3840p_string = "40p"

    sources = sorted(testquality, key=lambda tup: int(tup[1].replace('720p','719p').replace('7p',s2160p_string).replace('20p',s3840p_string).replace('20P','3840').replace('p','').replace('P','')), reverse=True)
    selected_source = sources[0][0]
    Log("selected_source={}".format(selected_source))
    return selected_source

def ParseJson(urldata):

    import json
    items = json.loads(urldata)
    success = items['success']
    Log("success={}".format(success))
    has_more = items['data']['has_more']
    Log("has_more={}".format(has_more))
    data = items['data']['content']
    if len(data) == 0: data = ''
    data = re.sub(r"(?si)\\/", "/", data)
    data = re.sub(r'(?si)\\"', '"', data)
    data = re.sub(r"(?si)\\t", " ", data)
    data = re.sub(r"(?si)\\n", " ", data)
    #Log(data)
    #needed? data = re.sub(r"(?si)\s{2,}", " ", data) #needed? 
    #Log(data)
    return data, has_more
