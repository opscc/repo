'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 NothingGnome

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log as Log

#play with this to get sorting working the way I want
spacing_for_topmost = ""
spacing_for_names = ""
spacing_for_next = ""
MAX_SEARCH_DEPTH = 10
URL_ROOT = 'https://spankbang.com'
SEARCH_URL = URL_ROOT+'/s/'

MAIN_MODE = 440
LIST_MODE =  441
PLAY_MODE = 442
CATEGORIES_MODE = 443
SEARCH_MODE = 444


@utils.url_dispatcher.register(str(MAIN_MODE))
def Main():

    utils.addDir(name="[COLOR {}]Categories[/COLOR]".format( \
        utils.search_text_color) \
        ,url=URL_ROOT + '/categories/' \
        ,mode=CATEGORIES_MODE \
        ,iconimage=utils.search_icon \
        ,Folder=True \
        )

    List(URL_ROOT+'/new_videos/1/')

@utils.url_dispatcher.register(str(LIST_MODE), ['url'], ['end_directory'])
def List(url, end_directory=True):
    
    try:
        listhtml = utils.getHtml(url, '')
        listhtml = re.compile('<div class=\"results(.+)', re.DOTALL).findall(listhtml)[0] #skip the header/banners
    except:
        return None

    if end_directory:
        utils.addDir(name="[COLOR {}]Search[/COLOR]".format( \
            utils.search_text_color) \
            ,url=SEARCH_URL \
            ,mode=SEARCH_MODE \
            ,iconimage=utils.search_icon \
            ,Folder=True \
            )
    
    match = re.compile('div class=\"video-item\".+?<a href=\"([^\"]+)\".+?data-src=\"([^\"]+)\".alt=\"([^\"]+)\"' \
                       + '.+?fa fa-clock-o\"></i>([^<]+)<', re.DOTALL).findall(listhtml)
    for videopage, img, name, duration in match:
        if not img.startswith("http"): img = "https:" + img
        #utils.addDownLink(name, URL_ROOT + videopage, PLAY_MODE, img, '', duration=duration+'m')
        utils.addDownLink( \
            name = name \
            , url = URL_ROOT + videopage \
            , mode = PLAY_MODE \
            , iconimage = img \
            , desc = '' \
            , duration=duration+'m'
            , stream = False )

    nextp=re.compile('<a href="([^"]+)">&raquo;', re.DOTALL | re.IGNORECASE).findall(listhtml)
    if nextp:
        nextp = nextp[0]
        nextp = nextp.replace(" ", "+") #website does not doe this properly for search pages...
        if not nextp.startswith("http"):
            np_url = URL_ROOT + nextp
        else:
            np_url = nextp
        Log("np_url='{}'".format(np_url))

        np_number=nextp.split('/')[2]
        if not np_number.isdigit(): np_number=nextp.split('/')[3]
        if not np_number.isdigit(): np_number=nextp.split('/')[4]

        utils.addDir(name="{}[COLOR {}]Next Page ({})[/COLOR]".format( \
            spacing_for_next, utils.search_text_color, np_number) \
            ,url=np_url \
            ,mode=LIST_MODE \
            ,iconimage=utils.next_icon \
            ,page=np_number \
            ,Folder=True \
            )


    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()

        
@utils.url_dispatcher.register(str(SEARCH_MODE), ['url'], ['keyword', 'end_directory'] )
def Search(searchUrl, keyword=None, end_directory=True):
    Log("searchUrl='{}'".format(searchUrl))
    if not keyword:
        utils.searchDir(searchUrl, SEARCH_MODE)
        return

    title = keyword.replace(' ','+')
    searchUrl = searchUrl + title + '/'
    Log("searchUrl='{}'".format(searchUrl))    
    List(searchUrl)

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()
        

@utils.url_dispatcher.register(str(CATEGORIES_MODE), ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('<a href="(/category/[^"]+)"><img src="([^"]+)"><span>([^<]+)</span>', re.DOTALL).findall(cathtml)
    for catpage, img, name in match:
        if not catpage.startswith("http"): catpage = URL_ROOT + catpage
        if not img.startswith("http"): img = URL_ROOT + img
        Log("catpage='{}'".format(catpage))
        utils.addDir(name="{}[COLOR {}]{}[/COLOR]".format( \
            spacing_for_names, utils.search_text_color, name) \
            ,url=catpage \
            ,mode=LIST_MODE \
            ,iconimage=img \
            ,Folder=True \
            )

    utils.add_sort_method()
    utils.endOfDirectory()

##    for catpage, img, name in match:
##        utils.addDir(name, base_url + '/category/' + catpage, list_mode, base_url + img, '')
##    xbmcplugin.endOfDirectory(utils.addon_handle)


@utils.url_dispatcher.register(str(PLAY_MODE), ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    html = utils.getHtml(url, '')
    stream_key = re.compile("data-streamkey=\"([^\"]+)\"").findall(html)[0]
    Log(stream_key)
    from requests import Request, Session
    s = Session()
    url = URL_ROOT + "/api/videos/stream"
    headers = {"User-Agent": utils.USER_AGENT
               , "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
               , "Referer": url
               }
    data = "id={}&data=0".format(stream_key)
    Log(data)
    req = Request('POST', url, data=data, headers=headers)
    prepped = s.prepare_request(req)
    resp = s.send(prepped , verify=False)
    Log(resp.status_code)
    Log("resp.content='{}'".format(repr(resp.content)))

    import json
    json_urls = json.loads(resp.content)
    Log(json_urls)
    match = None
    match_4k = None #json_urls["stream_url_4k"] #comment because I dont want this res
    match_1080 = json_urls["stream_url_1080p"]
    match_720 = json_urls["stream_url_720p"]
    match_480 = json_urls["stream_url_480p"]
    match_320 = json_urls["stream_url_320p"]
    match_240 = json_urls["stream_url_240p"]

    if match_4k: match = match_4k
    elif match_1080: match = match_1080
    elif match_720: match = match_720
    elif match_480: match = match_480
    elif match_320: match = match_320
    elif match_240: match = match_240

    Log(match)
    if match:
        utils.playvid(match, name, download)
    else:
        utils.notify('Oh oh','Couldn\'t find a video')

