'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream
    Copyright (C) 2015 Fr40m1nd

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

import xbmc
import xbmcplugin
import xbmcgui
import traceback
from resources.lib import utils
from resources.lib.utils import Log as Log

#play with this to get sorting working the way I want
spacing_for_topmost = ""
spacing_for_names = ""
spacing_for_next = ""
MAX_SEARCH_DEPTH = 10
URL_ROOT = "https://www.mrsexe.com"
SEARCH_URL = URL_ROOT+"/?search="

@utils.url_dispatcher.register('400')
def Main():
    #utils.addDir('[COLOR hotpink]Classiques[/COLOR]','http://www.mrsexe.com/classiques/', 401, '', '')
    utils.addDir(name="[COLOR {}]Classiques[/COLOR]".format( \
        utils.search_text_color) \
        ,url=URL_ROOT+'/classiques/' \
        ,mode=401 \
        ,iconimage=utils.refresh_icon \
        ,Folder=True \
        )

    #utils.addDir('[COLOR hotpink]Categories[/COLOR]','http://www.mrsexe.com/', 403, '', '')
    utils.addDir(name="[COLOR {}]Categories[/COLOR]".format( \
        utils.search_text_color) \
        ,url=URL_ROOT+'/' \
        ,mode=403 \
        ,iconimage=utils.refresh_icon \
        ,Folder=True \
        )
    
    #utils.addDir('[COLOR hotpink]Stars[/COLOR]','http://www.mrsexe.com/filles/', 405, '', '')
    utils.addDir(name="[COLOR {}]Stars[/COLOR]".format( \
        utils.search_text_color) \
        ,url=URL_ROOT+'/filles/' \
        ,mode=405 \
        ,iconimage=utils.refresh_icon \
        ,Folder=True \
        )
    
    #utils.addDir('[COLOR hotpink]Search[/COLOR]','http://www.mrsexe.com/?search=', 404, '', '')
    utils.addDir(name="[COLOR {}]Search[/COLOR]".format( \
        utils.search_text_color) \
        ,url=SEARCH_URL \
        ,mode=404 \
        ,iconimage=utils.search_icon \
        ,Folder=True \
        )

    List(URL_ROOT)
    utils.add_sort_method()
    utils.endOfDirectory()

@utils.url_dispatcher.register('401', ['url'], ['end_directory'])
def List(url, end_directory=True):

    #Log(url, xbmc.LOGNONE)
    
    try:
        listhtml = utils.getHtml(url, '')
    except:
        return None

    match = re.compile('thumb-list(.*?)<ul class="right pagination">', re.DOTALL | re.IGNORECASE).findall(listhtml)
    match1 = re.compile(r'<li class="[^"]*">\s<a class="thumbnail" href="([^"]+)">\n<script.+?</script>\n<figure>\n<img  id=".+?" src="([^"]+)".+?/>\n<figcaption>\n<span class="video-icon"><i class="fa fa-play"></i></span>\n<span class="duration"><i class="fa fa-clock-o"></i>([^<]+)</span>\n(.+?)\n', re.DOTALL | re.IGNORECASE).findall(match[0])
    for videopage, img, duration, name in match1:
        if img.startswith('//'): img = 'http:' + img
        name = utils.cleantext(name) #+ ' [COLOR deeppink]' + duration + '[/COLOR]'
        duration = duration.strip().split(" ")[0] + ":00"
        #Log("duration='{}'".format(duration), xbmc.LOGNONE) 
        #utils.addDownLink(name, 'http://www.mrsexe.com' + videopage, 402, img, '')
        utils.addDownLink( \
            name = name \
            , url = URL_ROOT + videopage \
            , mode = 402 \
            , iconimage = img \
            , desc = '' \
            , stream = False \
            , duration = duration)
        
    try:
        nextp=re.compile("<li class=\"arrow\"><a href=\"([^\.]+?)\.html\">suivant</li>").findall(listhtml)
        np_url= URL_ROOT + nextp[0] + '.html'
        np_number=nextp[0].split('/page')[1]
        #utils.addDir('Next Page', 'http://www.mrsexe.com/' + nextp[0], 401,'')
        utils.addDir(name="{}[COLOR {}]Next Page ({})[/COLOR]".format( \
            spacing_for_next, utils.search_text_color, np_number) \
            ,url=np_url \
            ,mode=401 \
            ,iconimage=utils.next_icon \
            ,page=np_number \
            ,Folder=True \
            )
    except:
        traceback.print_exc()
        pass

    if end_directory == True:
        utils.add_sort_method()
        utils.endOfDirectory()


@utils.url_dispatcher.register('404', ['url'], ['keyword'])    
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        utils.searchDir(url, 404)
    else:
        title = keyword.replace(' ','+')
        searchUrl = searchUrl + title
        print "Searching URL: " + searchUrl
        List(searchUrl)


@utils.url_dispatcher.register('403', ['url'])
def Categories(url):
    cathtml = utils.getHtml(url, '')
    match = re.compile('value="(/cat[^"]+)">([^<]+)<', re.DOTALL | re.IGNORECASE).findall(cathtml)
    for catpage, name in match:
        #if img.startswith('//'): img = 'https:' + img
        utils.addDir(name, URL_ROOT + catpage, 401, '')

    utils.add_sort_method()
    utils.endOfDirectory()


@utils.url_dispatcher.register('405', ['url'])
def Stars(url):
    #Log("mrsexe::Stars ", xbmc.LOGNONE)
    
    starhtml = utils.getHtml(url, '')

    #match = re.compile(r'<h3 class="filles">Les Filles de MrSexe</h3>(.*?)</ul>', re.DOTALL | re.IGNORECASE).findall(starhtml)
    match = re.compile("<h3 class=\"filles\">Les Filles de MrSexe</h3>(.*?)class=\"right pagination\"", re.DOTALL | re.IGNORECASE).findall(starhtml)
    #match1 = re.compile(r'<div class="thumbnail"><a href=\"([^\"]+?)\".+?<img src="(.+?)" alt=""\s/></a>\s</figure>.+?</div>\s<div class="infos">\s<h5><a href=".+?">([^<]+)</a></h5>\s([0-9]+) vid', re.DOTALL | re.IGNORECASE).findall(match[0])
    match1 = re.compile("<div class=\"thumbnail\"><a href=\"([^\"]+?)\".+?<img src=\"([^\"]+?)\".+?h5>.+?>([^<)]+).+?h5>([^<)]+)<", re.DOTALL | re.IGNORECASE).findall(match[0])

    for starpage, img, name, vidcount in match1:
        if img.startswith('//'): img = 'https:' + img
        name = name # + " (" + vidcount + " Videos)"
        #utils.addDir(name, URL_ROOT + starpage, 401, img)
        np_url = URL_ROOT + starpage
        utils.addDir( \
            name=name \
            ,url=np_url \
            ,mode=401 \
            ,iconimage=img \
            ,Folder=True \
            )

    try:
        #nextp=re.compile(r'<li class="arrow"><a href="(.+?)">suivant</li>').findall(starhtml)
        #utils.addDir('Next Page', 'http://www.mrsexe.com/' + nextp[0], 405,'')
        nextp=re.compile("<li class=\"arrow\"><a href=\"([^\.]+?)\.html\">suivant</li>").findall(starhtml)
        np_url = URL_ROOT + nextp[0] + '.html'
        np_number=nextp[0].split('/page')[1]
        utils.addDir(name="{}[COLOR {}]Next Page ({})[/COLOR]".format( \
            spacing_for_next, utils.search_text_color, np_number) \
            ,url=np_url \
            ,mode=405 \
            ,iconimage=utils.next_icon \
            ,page=np_number \
            ,Folder=True \
            )
    except:
        traceback.print_exc()
        pass

    utils.add_sort_method()
    utils.endOfDirectory()

@utils.url_dispatcher.register('402', ['url', 'name'], ['download'])
def Playvid(url, name, download=None):
    #xbmc.log(url, xbmc.LOGNOTICE)
    #print "mrsexe::Playvid " + url
    html = utils.getHtml(url, '')
    videourl = re.compile(r"src='(/inc/clic\.php\?video=.+?&cat=mrsex.+?)'").findall(html)
    html = utils.getHtml('https://www.mrsexe.com' + videourl[0], '')
    #pre 2019-05-21
    #videourls = re.compile(r"'file': \"(.+?)\",.+?'label': '(.+?)'", re.DOTALL).findall(html)
    #videourls = sorted(videourls, key=lambda tup: tup[1], reverse=True)
    #videourl = videourls[0][0]

    #2019-05-21
    videourls = re.compile("HDtoggle\(('[^\)]+)", re.DOTALL).findall(html)
    if videourls:
        videourl = videourls[0].split(",")[-1].strip("'")
        #videourls = sorted(videourls, key=lambda tup: tup[1], reverse=True)
        #videourl = videourls[0][0]
    else:
        videourls = re.compile("\.src\(\"([^\"]+)\"", re.DOTALL).findall(html)
        videourl = videourls[0]

    #xbmc.log(videourl, xbmc.LOGNOTICE)
    #return
    if videourl.startswith('//'): videourl = 'http:' + videourl
    if download == 1:
        utils.downloadVideo(videourl, name)
    else:    
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        xbmc.Player().play(videourl, listitem)
