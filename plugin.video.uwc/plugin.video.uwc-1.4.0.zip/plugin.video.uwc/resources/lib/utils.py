#-*- coding: utf-8 -*-
'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

__scriptname__ = "Ultimate Whitecream"
__author__ = "Whitecream"
__scriptid__ = "plugin.video.uwc"
__credits__ = "Whitecream, Fr33m1nd, anton40, NothingGnome"
__version__ = "1.1.55"

import urllib
import urllib2
import re
import cookielib
import os.path
import sys
import time
import tempfile
import sqlite3
import urlparse
import base64
from StringIO import StringIO
import gzip
import traceback
import threading

import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import cloudflare
from jsunpack import unpack

if sys.version_info >= (3, 0):
    from html.parser import HTMLParser
else:
    from HTMLParser import HTMLParser
html_parser = HTMLParser()

from url_dispatcher import URL_Dispatcher

url_dispatcher = URL_Dispatcher()



USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'

headers = { 'User-Agent': USER_AGENT,
        'Accept': '*/*',
        'Accept-Encoding': 'gzip'
       }

openloadhdr = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
       'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
       'Accept-Encoding': 'none',
       'Accept-Language': 'en-US,en;q=0.8'       }

addon_handle = int(sys.argv[1])

this_addon = xbmcaddon.Addon()
addon_id = str(this_addon.getAddonInfo('id'))
addon_name = this_addon.getAddonInfo('name')

addon = xbmcaddon.Addon(id=__scriptid__)

progress = xbmcgui.DialogProgress()
dialog = xbmcgui.Dialog()

rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)
resDir = os.path.join(rootDir, 'resources')
imgDir = os.path.join(resDir, 'images')

uwcicon = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))
uwcchange = xbmc.translatePath(os.path.join(rootDir, 'uwcchange.txt'))

profileDir = addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')
kodiver = xbmc.getInfoLabel("System.BuildVersion").split(".")[0]

refresh_text_color = addon.getSetting('refresh_text_color').lower()
search_text_color = addon.getSetting('search_text_color').lower()
time_text_color = addon.getSetting('time_text_color').lower()
icon_set = addon.getSetting('icon_set').lower()

sort_order = int(addon.getSetting('sortxt'))
if sort_order == 1:
    sort_order = xbmcplugin.SORT_METHOD_DURATION
elif sort_order == 2:
    sort_order = xbmcplugin.SORT_METHOD_DATE
elif sort_order == 3:
    sort_order = xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS
elif sort_order == 4:
    sort_order = xbmcplugin.SORT_METHOD_PLAYCOUNT
elif sort_order == 5:
    sort_order = xbmcplugin.SORT_METHOD_SONG_RATING
else:
    sort_order = xbmcplugin.SORT_METHOD_UNSORTED

refresh_icon = os.path.join(imgDir, "library_update_{}.png".format(icon_set) )
search_icon = os.path.join(imgDir, "search_{}.png".format(icon_set) )
next_icon = os.path.join(imgDir, "next_{}.png".format(icon_set) )

if not os.path.exists(profileDir):
    os.makedirs(profileDir)

urlopen = urllib2.urlopen
cj = cookielib.LWPCookieJar(xbmc.translatePath(cookiePath))
Request = urllib2.Request

handlers = [urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler()]

if (2, 7, 8) < sys.version_info < (2, 7, 12):
    try:
        import ssl; ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        handlers += [urllib2.HTTPSHandler(context=ssl_context)]
    except:
        pass

if cj != None:
    if os.path.isfile(xbmc.translatePath(cookiePath)):
        try:
            cj.load()
        except:
            try:
                os.remove(xbmc.translatePath(cookiePath))
                pass
            except:
                dialog.ok('Oh oh','The Cookie file is locked, please restart Kodi')
                pass
    cookie_handler = urllib2.HTTPCookieProcessor(cj)
    handlers += [cookie_handler]

opener = urllib2.build_opener(*handlers)
opener = urllib2.install_opener(opener)

favoritesdb = os.path.join(profileDir, 'favorites.db')



def uwcimage(filename):
    img = os.path.join(imgDir, filename)
    return img

class StopDownloading(Exception):
    def __init__(self, value): self.value = value
    def __str__(self): return repr(self.value)



def downloadVideo(url, name):

    Log("{}{}".format(url,name), xbmc.LOGNONE)

    def _pbhook(downloaded, filesize, name=None,dp=None):
        try:
            percent = min((downloaded*100)/filesize, 100)
            currently_downloaded = float(downloaded) / (1024 * 1024)
            kbps_speed = int(downloaded / (time.clock() - start))

            if kbps_speed > 0:  eta = (filesize - downloaded) / kbps_speed
            else:           eta = 0

            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            mbs = "[{:20}]".format(name)
            mbs += ' %.00f MB/%.00f MB' % (currently_downloaded, total)
            e = ' %.0fKbps' % kbps_speed
            #e += ' ETA:%01:%01d' % divmod(eta, 60)
            e += ' ETA:%01d' % (eta // 60)
            #dp.update(percent,'',mbs,e)
            dp.update(percent,'',mbs + e)
        except:
            traceback.print_exc()
            percent = 100
            dp.update(percent)
            dp.close()

    def getResponse(url, headers2, size):
        #Log("getResponse:{}".format(url))
        try:
            if size > 0:
                size = int(size)
                headers2['Range'] = 'bytes=%d-' % size

            req = Request(url, headers=headers2)
            #req.add_header('Range', 'bytes=0-100') #only get a few bytes to test for redirection
            resp = urlopen(req, timeout=30)
            #Log("getResponse:urlopen:{}".format(url))
            return resp
        except:
            traceback.print_exc()
            return None

    def doDownload(url, dest, dp, name):
        try:

            #url may have include headers to be passed during transaction
            try:
                headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
            except:
                #traceback.print_exc()
                headers = dict('')


            if      'openload' in url:  headers = openloadhdr

            if 'spankbang.com' in url:  url = getVideoLink(url,url)

            url = url.split('|')[0]
            file = dest.rsplit(os.sep, 1)[-1]

            resp = getResponse(url, headers, 0)

            if not resp:
                Notify("Download failed: {}".format(url))
                #xbmcgui.Dialog().ok("Ultimate Whitecream", 'Download failed', 'No response from server')
                return False

            try:    content = int(resp.headers['Content-Length'])
            except: content = 0

            try:    resumable = ('bytes' in resp.headers['Accept-Ranges'].lower()) or ('bytes' in resp.headers['Content-Range'].lower())
            except: resumable = False
            if resumable: Log("Download is resumable: {}".format(url))

            if content < 1:
                Notify("Unknown filesize: {}".format(url))
                content = 1024*1024
                #xbmcgui.Dialog().ok("Ultimate Whitecream", 'Unknown filesize', 'Unable to download')
                #return False

            size = 8192
            mb   = content / (1024 * 1024)

            if content < size:
                size = content

            total   = 0
            errors  = 0
            count   = 0
            resume  = 0
            sleep   = 0

            Log('Download File Size : %dMB %s ' % (mb, dest))
            f = xbmcvfs.File(dest, 'w')

            chunk  = None
            chunks = []

            while True:

                # kill the download if kodi monitor tells us to
                monitor = xbmc.Monitor()
                if monitor.abortRequested():
                    if monitor.waitForAbort(1):
                        Log("shutting down '{}' download thread for '{}'".format(addon_id,url), xbmc.LOGNOTICE)
                        return

                downloaded = total
                for c in chunks:
                    downloaded += len(c)
                percent = min(100 * downloaded / content, 100)

                _pbhook(downloaded,content,name,dp)

                chunk = None
                error = False

                try:
                    chunk  = resp.read(size)
                    if not chunk:
                        if percent < 99:
                            error = True
                        else:
                            while len(chunks) > 0:
                                c = chunks.pop(0)
                                f.write(c)
                                del c

                            f.close()
                            Log( '%s download complete' % (dest) )
                            return True

                except Exception as e:
                    traceback.print_exc()
                    error = True
                    sleep = 10
                    errno = 0

                    if hasattr(e, 'errno'):
                        errno = e.errno

                    if errno == 10035: # 'A non-blocking socket operation could not be completed immediately'
                        pass

                    if errno == 10054: #'An existing connection was forcibly closed by the remote host'
                        errors = 10 #force resume
                        sleep  = 30

                    if errno == 11001: # 'getaddrinfo failed'
                        errors = 10 #force resume
                        sleep  = 30

                if chunk:
                    errors = 0
                    chunks.append(chunk)
                    if len(chunks) > 5:
                        c = chunks.pop(0)
                        f.write(c)
                        total += len(c)
                        del c

                if error:
                    errors += 1
                    count  += 1
                    #Log ('%d Error(s) whilst downloading %s' % (count, dest))
                    #xbmc.sleep(sleep*1000)
                    xbmc.sleep(sleep*1000)

                if (resumable and errors > 0) or errors >= 500:
                    if (not resumable and resume >= 500) or resume >= 500:
                        #Give up!
                        Log ('%s download canceled - too many error whilst downloading' % (dest))
                        f.close()
                        return False

                    resume += 1
                    errors  = 0

                    if resumable:
                        chunks  = []
                        #create new response
                        Log ('Download resumed (%d) %s' % (resume, dest) )
                        resp = getResponse(url, headers, total)
                    else:
                        #use existing response
                        pass

        except:
            traceback.print_exc()

    def clean_filename(s):
        if not s:
            return ''
        badchars = '\\/:*?\"<>|\''
        for c in badchars:
            s = s.replace(c, '')
        return s.strip();

    Log(name)
    url = url.strip('\r') #sometimes url lists will insert this hidden character which can break things later on
    name = name.strip('\r')

    download_path = this_addon.getSetting('download_path')
    if download_path == '':
        try:
            download_path = xbmcgui.Dialog().browse(0, "Download Path", 'myprograms', '', False, False)
            this_addon.setSetting(id='download_path', value=download_path)
            if not os.path.exists(download_path): os.mkdir(download_path)
        except:
            raise #pass

    if download_path != '':
        dp = xbmcgui.DialogProgressBG()
        if ']' in name:
            try:
                name = name.split("/COLOR]")[1].split('[')[0]
            except:
                pass
        dp.create(addon_name,name[:50])
        tmp_file = tempfile.mktemp(dir=download_path, suffix=".mp4")
        tmp_file = xbmc.makeLegalFilename(tmp_file)
        start = time.clock()
        try:
            #urllib.urlretrieve(url,tmp_file,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
            kodilog(url)
            downloaded = doDownload(url, tmp_file, dp, name)
            if downloaded:
                vidfile = xbmc.makeLegalFilename(download_path + clean_filename(name) + ".mp4")
                Log(vidfile)
                try:
                    os.rename(tmp_file, vidfile)
                    dp.close()
                    return vidfile
                except Exception as e:
                    traceback.print_exc()
                    Notify("'{}' name:{} tmp:{}".format(e,vidfile,tmp_file), 20000)
                    dp.close()
                    return tmp_file
            else:
                raise StopDownloading('Stopped Downloading')
        except:
            while os.path.exists(tmp_file):
                try:
                    os.remove(tmp_file)
                    dp.close()
                    break
                except:
                    traceback.print_exc()
                    break
                    pass
            dp.close()



def PLAYVIDEO(url, name, download=None):
    progress.create('Play video', 'Searching videofile.')
    progress.update( 10, "", "Loading video page", "" )
    videosource = getHtml(url, url)
    playvideo(videosource, name, download, url)


def playvideo(videosource, name, download=None, url=None):
    #traceback.print_exc()
    xbmc.log("utils.playvideo ({},{},{},{}".format("<bunchofhtml>" , name, download, url), xbmc.LOGNONE)
    #return

    if progress:
        progress.create('Play video', 'Searching videofile.')

    #import urlresolver
    hosts = []
    videourl=None


    if re.search('watchxfree\.(?:eu|io|info|stream)?/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Watchxfree')

    if re.search('o(?:pen)?load\.(?:co|io|info|stream)?/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('OpenLoad')

    if re.search('"(http[s]?:\/\/\S+?.pw\/\S+)"', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('OpenLoad2')

    if re.search('oload\.(?:co|io|tv)?/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('OpenLoad')


    if re.search('0load\.(?:asia|io|tv)?/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('OpenLoad')

    if re.search('streamin\.to/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamin')

    if re.search('1fichier\.com/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('1fichier')


    if re.search('flashx\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('FlashX')

    if re.search('mega3x\.net/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Mega3X')
    if re.search('streamcloud\.eu/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('StreamCloud')
    if re.search('jetload\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Jetload')
    if re.search('videowood\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Videowood')
    if re.search('streamdefence.com/view\.php', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamdefence')
    if re.search('strdef.world', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamdefence')
    if re.search('dato\.?porn.\.?', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Datoporn')
    if re.search('zstream\.to/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('ZStream')
    if re.search('rapidvideo\.com/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Rapidvideo')

    if re.search('vidlox\.tv/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Vidlox')

    if re.search('streamcherry\.com', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Streamcherry')
    if re.search('<source', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Direct Source')

    if not 'keeplinks' in url:
        if re.search('keeplinks\.eu/p', videosource, re.DOTALL | re.IGNORECASE):
            hosts.append('Keeplinks <--')

    if re.search('filecrypt.cc/Container', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('Filecrypt')

    #iframe src="https://verystream.com/e/N3DnRCksHaR/younfn.mp4"
    if re.search('verystream.com/e/', videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('verystream')

    #src="https://www.vipporns.com/embed/685" frameborder="0" allowfullscreen></iframe>
    if re.search("\.vipporns\.com\/embed\/", videosource, re.DOTALL | re.IGNORECASE):
        hosts.append('vipporns')
        
        

    #if re.search('hqq\.tv\/player', videosource, re.DOTALL | re.IGNORECASE):
    #    hosts.append('HQQ')

    if len(hosts) == 0:
        progress.close()
        notify('Oh oh','Couldn\'t find any video hoster')
        return
    elif len(hosts) > 1:
        if addon.getSetting("dontask") == "true":
            vidhost = hosts[0]
        else:
            vh = dialog.select('Videohost:', hosts)
            if vh == -1:
                return
            vidhost = hosts[vh]
    else:
        vidhost = hosts[0]


    if vidhost == 'vipporns':
        #Log("url='{}'".format(url))
        vipporns_url = re.compile('src=\"(https:\/\/www\.vipporns\.com\/embed\/[^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videosource)
        #Log("vipporns_url='{}'".format(vipporns_url))
        vipporns_url = vipporns_url[0]
        #Log("vipporns_url='{}'".format(vipporns_url))
        v_s = getHtml(vipporns_url)

        deb = re.compile("license_code:(.+)preload:", re.DOTALL | re.IGNORECASE).findall(v_s)
        Log("deb='{}'".format(deb[0]))
        
        license_code = re.compile("license_code: '([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("license_code='{}'".format(license_code))

        vipporns_url = re.compile("video_url: 'function\/0\/([^']+)'", re.DOTALL | re.IGNORECASE).findall(v_s)[0]
        #Log("vipporns_url='{}'".format(vipporns_url))

        fappy_salt = FaapySalt(license_code, "")
        #Log("fappysalt='{}'".format(fappy_salt))

        old_fappy_code = vipporns_url.split('/')[5]
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        old_fappy_code = old_fappy_code[0:len(fappy_salt)]  #not sure if this applies to all sites
        #Log("old_fappy_code='{}'".format(old_fappy_code))

        new_fappy_code = ConvertFaapyCode( old_fappy_code, fappy_salt)
        #Log("new_fappy_code='{}'".format(new_fappy_code))

        vipporns_url = vipporns_url.replace(old_fappy_code, new_fappy_code)
        vipporns_url = vipporns_url + "&rnd=" + str(time.time()*100)
        #Log("vipporns_url='{}'".format(vipporns_url))

        videourl = vipporns_url



    if vidhost == 'verystream':


        Log("url='{}'".format(url))
        verystream_url = re.compile('class=\"video-container\".+?src=\"([^\"]+)\"', re.DOTALL | re.IGNORECASE).findall(videosource)
        if verystream_url:
            verystream_url = verystream_url[0]
            Log("verystream_url='{}'".format(verystream_url))
            v_s = getHtml(verystream_url)
            playvideo(v_s, name=name, download=download, url=url)
            return
    
        verystream_url = re.compile('id=\"videolink\">([^\<]+)<\/p>', re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("verystream url='{}'".format(verystream_url))
        verystream_url = verystream_url[0]
        Log("verystream url='{}'".format(verystream_url))
        verystream_url = "https://verystream.com/gettoken/{}?mime=true".format(verystream_url)
        
        Log("verystream url='{}'".format(verystream_url))
        videourl = verystream_url

        
    if vidhost == 'Watchxfree':
        xbmc.log(url, xbmc.LOGNONE)
        progress.update( 40, "", "Loading {}".format(vidhost) , "" )
        watchxfree_url = re.compile(r"//(?:www\.)?watchxfree\.(?:eu|io|tv|info|stream)?/(?:embed|f)/([0-9a-zA-Z-_]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        watchxfree_url = chkmultivids(watchxfree_url)
        watchxfree_url_1 = 'http://openload.io/embed/%s/' % watchxfree_url
        progress.update( 50, "", "Loading {}".format(vidhost), "Sending it to urlresolver" )
        try:
            import urlresolver
            video = urlresolver.resolve(watchxfree_url_1)
            if video:
                progress.update( 80, "", "Loading {}".format(vidhost), "Found the video" )
                videourl = video
        except:
            notify('Oh oh','Couldn\'t find playable OpenLoad link')
            return

    if vidhost == 'OpenLoad':
        Log("url={}".format(url), xbmc.LOGNONE)
        progress.update( 40, "", "Loading Openload", "" )
        Log("videosource={}".format(videosource), xbmc.LOGNONE)
        openloadurl = re.compile(r"//(?:www\.)?(?:o|0)(?:pen)?load\.(?:co|io|tv|info|stream|asia)?/(?:embed|f)/([0-9a-zA-Z-_]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        Log("openloadurl={}".format(openloadurl), xbmc.LOGNONE)
        openloadurl = chkmultivids(openloadurl)

        openloadurl1 = 'http://openload.io/embed/%s/' % openloadurl
        progress.update( 50, "", "Loading Openload", "Sending it to urlresolver" )
        try:
            import urlresolver
            video = urlresolver.resolve(openloadurl1)
            if video:
                progress.update( 80, "", "Loading Openload", "Found the video" )
                videourl = video
        except:
            notify('Oh oh','Couldn\'t find playable OpenLoad link')
            return

    elif vidhost == 'OpenLoad2':
        xbmc.log(url, xbmc.LOGNONE)

        matches = re.findall('"(http[s]?:\/\/\S+?.pw\/\S+)"', videosource, re.DOTALL | re.IGNORECASE)
        for m in matches:
            OpenLoad2_url = m
        OpenLoad2_src = getHtml(OpenLoad2_url, '', openloadhdr)
        progress.update( 40, "", "Loading Openload2", "" )
        openloadurl = re.compile(r"//(?:www\.)?o(?:pen)?load\.(?:co|io|tv|info|stream)?/(?:embed|f)/([0-9a-zA-Z-_]+)", re.DOTALL | re.IGNORECASE).findall(OpenLoad2_src)
        openloadurl = chkmultivids(openloadurl)

        openloadurl1 = 'http://openload.io/embed/%s/' % openloadurl
        progress.update( 50, "", "Loading Openload2", "Sending it to urlresolver" )
        try:
            import urlresolver
            video = urlresolver.resolve(openloadurl1)
            if video:
                progress.update( 80, "", "Loading Openload2", "Found the video" )
                videourl = video
        except:
            notify('Oh oh','Couldn\'t find playable OpenLoad2 link')
            return



    elif vidhost == '1fichier':
        progress.update( 40, "", "Loading {}".format(vidhost), "" )
        streaminurl = re.compile("https:\/\/1fichier\.com\/(?:embed-)?\?(?:[0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        kodilog("{}:{}".format(vidhost, repr(streaminurl)))
        streaminurl = chkmultivids(streaminurl)
        kodilog("{}:{}".format(vidhost, repr(streaminurl)))
        progress.update( 50, "", "Loading {}".format(vidhost), "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(streaminurl)
        if video:
            progress.update( 80, "", "Loading {}".format(vidhost), "Found the video" )
            videourl = video

    elif vidhost == 'Streamin':
        progress.update( 40, "", "Loading Streamin", "" )
        streaminurl = re.compile(r"//(?:www\.)?streamin\.to/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        streaminurl = chkmultivids(streaminurl)
        streaminurl = 'http://streamin.to/embed-%s-670x400.html' % streaminurl
        progress.update( 50, "", "Loading Streamin", "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(streaminurl)
        if video:
            progress.update( 80, "", "Loading Streamin", "Found the video" )
            videourl = video

    elif vidhost == 'FlashX':
        progress.update( 40, "", "Loading FlashX", "" )
        flashxurl = re.compile(r"//(?:www\.)?flashx\.tv/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        media_id = chkmultivids(flashxurl)
        flashxurl = 'http://www.flashx.tv/%s.html' % media_id
        progress.update( 50, "", "Loading FlashX", "Sending it to urlresolver" )
        import urlresolver
        video = urlresolver.resolve(flashxurl)
        if video:
            progress.update( 80, "", "Loading FlashX", "Found the video" )
            videourl = video

    elif vidhost == 'Mega3X':
        progress.update( 40, "", "Loading Mega3X", "" )
        mega3xurl = re.compile(r"(https?://(?:www\.)?mega3x.net/(?:embed-)?(?:[0-9a-zA-Z]+).html)", re.DOTALL | re.IGNORECASE).findall(videosource)
        mega3xurl = chkmultivids(mega3xurl)
        mega3xsrc = getHtml(mega3xurl,'', openloadhdr)
        mega3xjs = re.compile("<script[^>]+>(eval[^<]+)</sc", re.DOTALL | re.IGNORECASE).findall(mega3xsrc)
        progress.update( 80, "", "Getting video file from Mega3X", "" )
        mega3xujs = unpack(mega3xjs[0])
        videourl = re.compile('file:\s?"([^"]+m3u8)"', re.DOTALL | re.IGNORECASE).findall(mega3xujs)
        videourl = videourl[0]

    elif vidhost == 'Datoporn':
        progress.update( 40, "", "Loading Datoporn", "" )
        datourl = re.compile("\/\/(?:www\.)?dato\.?porn\.(?:com|co)?\/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        if datourl:
            datourl = chkmultivids(datourl)

            datourl = "http://datoporn.co/embed-" + datourl + ".html"
            #Log(datourl)
            datosrc = getHtml(datourl,'', openloadhdr)
            if datosrc == '':
                datourl = "http://datoporn.com/embed-" + datourl + ".html"
                Log(datourl)
                datosrc = getHtml(datourl,'', openloadhdr)

            if "File was deleted" in datosrc:
                notify('Oh oh','File is deleted from Datoporn')
                return

            try:
                #datojs = re.compile("<script[^>]+>(eval[^<]+)</sc", re.DOTALL | re.IGNORECASE).findall(datosrc)
                datojs = re.compile("<script>.var player.+?(player.updateSrc[^<]+)</sc", re.DOTALL | re.IGNORECASE).findall(datosrc)

                datoujs = unpack(datojs[0])
            except:
                datoujs = datosrc

            progress.update( 80, "", "Getting video file from Datoporn", "" )
            videourl = re.compile('file:"([^"]+mp4)"', re.DOTALL | re.IGNORECASE).findall(datoujs)
            if not videourl:
                videourl = re.compile('{src: "([^"]+)"', re.DOTALL | re.IGNORECASE).findall(datoujs)
            Log(videourl)
            videourl = videourl[0]
            videourl = "{}{}&Referer={}".format(videourl, Header2pipestring(), datourl)
            Log(videourl)


    elif vidhost == 'StreamCloud':
        Log("Opening Streamcloud")
        streamcloudurl = re.compile(r"//(?:www\.)?streamcloud\.eu?/([0-9a-zA-Z-_/.]+html)", re.DOTALL | re.IGNORECASE).findall(videosource)
        streamcloudurl = chkmultivids(streamcloudurl)
        streamcloudurl = "http://streamcloud.eu/" + streamcloudurl
        Log("Getting Streamcloud page")
        schtml = postHtml(streamcloudurl)

        form_values = {}
        match = re.compile('<input.*?name="(.*?)".*?value="(.*?)">', re.DOTALL | re.IGNORECASE).findall(schtml)
        for name, value in match:
            form_values[name] = value.replace("download1","download2")

        Log("Grabbing video file")
        newscpage = postHtml(streamcloudurl, form_data=form_values)

        videourl = re.compile('file:\s*"(.+?)",', re.DOTALL | re.IGNORECASE).findall(newscpage)[0]
        streamcloud_headers = { "Accept-Encoding" : "identity;q=1, *;q=0" \
                    , "User-Agent" : USER_AGENT \
                    , "Accept" : "*/*" \
                    , "Referer" :  streamcloudurl \
                    }
        videourl = videourl + Header2pipestring(streamcloud_headers)
        Log("videourl='{}'".format(videourl), xbmc.LOGNONE)
        
    elif vidhost == 'Jetload':
        progress.update( 40, "", "Loading Jetload", "" )
        jlurl = re.compile(r'jetload\.tv/([^"]+)', re.DOTALL | re.IGNORECASE).findall(videosource)
        jlurl = chkmultivids(jlurl)
        jlurl = "http://jetload.tv/" + jlurl
        progress.update( 50, "", "Loading Jetload", "" )
        jlsrc = getHtml(jlurl, url)
        videourl = re.compile(r'file: "([^"]+)', re.DOTALL | re.IGNORECASE).findall(jlsrc)
        if videourl:
            videourl = videourl[0]
        else:
            notify('Oh oh','File was deleted from: {}'.format(vidhost))
            return

    elif vidhost == 'Videowood':
        progress.update( 40, "", "Loading Videowood", "" )
        vwurl = re.compile(r"//(?:www\.)?videowood\.tv/(?:embed|video)/([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        vwurl = chkmultivids(vwurl)
        vwurl = 'http://www.videowood.tv/embed/' + vwurl
        progress.update( 50, "", "Loading Videowood", "Sending it to urlresolver" )
        import urlresolver
        video = urlresolver.resolve(vwurl)
        if video:
            progress.update( 80, "", "Loading Videowood", "Found the video" )
            videourl = video

    elif vidhost == 'Keeplinks <--':
        progress.update( 40, "", "Loading Keeplinks", "" )
        klurl = re.compile(r"//(?:www\.)?keeplinks\.eu/p([0-9a-zA-Z/]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        klurl = chkmultivids(klurl)
        klurl = 'http://www.keeplinks.eu/p' + klurl
        kllink = getVideoLink(klurl, '')
        kllinkid = kllink.split('/')[-1]
        klheader = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
           'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
           'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
           'Accept-Encoding': 'none',
           'Accept-Language': 'en-US,en;q=0.8',
           'Connection': 'keep-alive',
           'Cookie': 'flag['+kllinkid+'] = 1;'}
        klpage = getHtml(kllink, klurl, klheader)
        playvideo(klpage, name, download, klurl)
        return
    
    elif vidhost == 'Streamdefence':

        progress.update( 40, "", "Loading Streamdefence", "" )
        sdurl = re.compile(r'streamdefence\.com/view.php\?ref=([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videosource)
        if sdurl:
            sdurl = chkmultivids(sdurl)
            sdurl = 'http://www.streamdefence.com/view.php?ref=' + sdurl
        else:
            sdurl = re.compile('\.strdef\.world/([^"]+)"', re.DOTALL | re.IGNORECASE).findall(videosource)
            if sdurl:
                sdurl = 'https://www.strdef.world/' + sdurl[0]
        #sdurl = "https://strdef.world/player.php?id=1ebd0d89-6813-40ed-a014-c0e2bec7252b"

        Log("Getting video file from Streamdefence url:'{}' referrer:'{}'".format(sdurl, url), xbmc.LOGNONE)
        sdsrc = getHtml(sdurl, url)
        progress.update( 80, "", "Getting video file from Streamdefence", "" )
        sdpage = streamdefence(sdsrc)
        playvideo(sdpage, name, download, sdurl)
        return

    elif vidhost == 'Filecrypt':
        progress.update( 40, "", "Loading Filecrypt", "" )
        fcurl = re.compile(r'filecrypt\.cc/Container/([^\.]+)\.html', re.DOTALL | re.IGNORECASE).findall(videosource)
        fcurl = chkmultivids(fcurl)
        fcurl = 'http://filecrypt.cc/Container/' + fcurl + ".html"
        fcsrc = getHtml(fcurl, url)
        fcmatch = re.compile(r"onclick=\"openLink.?'([\w\-]*)',", re.DOTALL | re.IGNORECASE).findall(fcsrc)
        progress.update( 80, "", "Getting video file from Filecrypt", "" )
        fcurls = ""
        for fclink in fcmatch:
            fcpage = "http://filecrypt.cc/Link/" + fclink + ".html"
            fcpagesrc = getHtml(fcpage, fcurl)
            fclink2 = re.search('<iframe .*? noresize src="(.*)"></iframe>', fcpagesrc)
            if fclink2:
                try:
                    fcurl2 = getVideoLink(fclink2.group(1), fcpage)
                    fcurls = fcurls + " " + fcurl2
                except:
                    pass
        playvideo(fcurls, name, download, fcurl)
        return

    elif vidhost == 'Vidlox':
        if sys.version_info < (2, 7, 9):
            progress.close()
            notify('Oh oh','Python version to old, update to Krypton')
            return
        progress.update( 40, "", "Loading Vidlox", "" )
        vlurl = re.compile(r"(?://|\.)vidlox\.tv/(?:embed-|)([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        media_id = chkmultivids(vlurl)
        vlurl = 'http://vidlox.tv/%s' % media_id
        progress.update( 50, "", "Loading Vidlox", "Sending it to urlresolver" )
        import urlresolver
        video = urlresolver.resolve(vlurl)
        if video:
            progress.update( 80, "", "Loading Vidlox", "Found the video" )
            videourl = video

    elif vidhost == 'ZStream':
        progress.update( 40, "", "Loading Zstream", "" )
        zstreamurl = re.compile(r"(?://|\.)zstream\.to/(?:embed-)?([0-9a-zA-Z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        zstreamurl = chkmultivids(zstreamurl)
        zstreamurl = 'http://zstream.to/embed-%s.html' % zstreamurl
        progress.update( 50, "", "Loading ZStream", "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(zstreamurl)
        if video:
            progress.update( 80, "", "Loading ZStream", "Found the video" )
            videourl = video

    elif vidhost == 'Streamcherry':
        progress.update( 40, "", "Loading Streamcherry", "" )
        scstreamurl = re.compile(r"(?://|\.)streamcherry\.com/(?:embed|f)/(\w+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        scstreamurl = chkmultivids(scstreamurl)
        scstreamurl = 'https://streamcherry.com/embed/%s' % scstreamurl
        progress.update( 50, "", "Loading Streamcherry", "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(scstreamurl)
        if video:
            progress.update( 80, "", "Loading Streamcherry", "Found the video" )
            videourl = video

    elif vidhost == 'Rapidvideo':
        if sys.version_info < (2, 7, 9):
            progress.close()
            notify('Oh oh','Python version to old, update to Krypton')
            return
        progress.update( 40, "", "Loading Rapidvideo", "" )
        rpvideourl = re.compile(r"(?://|\.)(?:rapidvideo|raptu)\.com/(?:embed/|[ev]/|\?v=)?([0-9A-Za-z]+)", re.DOTALL | re.IGNORECASE).findall(videosource)
        rpvideourl = chkmultivids(rpvideourl)
        rpvideourl = 'https://www.rapidvideo.com/embed/%s' % rpvideourl
        progress.update( 50, "", "Loading Rapidvideo", "Sending it to urlresolver")
        import urlresolver
        video = urlresolver.resolve(rpvideourl)
        if video:
            progress.update( 80, "", "Loading Rapidvideo", "Found the video" )
            videourl = video

    elif vidhost == 'Direct Source':
        progress.update( 40, "", "Loading Direct source", "" )
        dsurl = re.compile("""<source.*?src=(?:"|')([^"']+)[^>]+>""", re.DOTALL | re.IGNORECASE).findall(videosource)
        dsurl = chkmultivids(dsurl)
        videourl = dsurl


    progress.update( 100, "", videourl, "" )

    progress.close()

    if videourl:
        playvid(videourl, name, download)
    else:
        notify('Oh oh','Couldn\'t find a link')
        return


def playvid(videourl, name, download=None):

    if download == 1:
        downloadVideo(videourl, name)
        return

    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})

    log("playing URL: {}".format(videourl) )

    if ".m3u8" in videourl:
        listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
        xbmc.log("using inputstream for URL: " + videourl, xbmc.LOGNONE  )

    xbmc.Player().play(videourl, listitem)


def chkmultivids(videomatch):
    videolist = list(set(videomatch))
    if len(videolist) > 1:
        i = 1
        hashlist = []
        for x in videolist:
            hashlist.append('Video ' + str(i))
            i += 1
        mvideo = dialog.select('Multiple videos found', hashlist)
        if mvideo == -1:
            return
        return videolist[mvideo]
    else:
        return videomatch[0]

@url_dispatcher.register('9', ['name', 'url'])
def PlayStream(name, url):
    item = xbmcgui.ListItem(name, path = url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    return


def getHtml(url, referer='', hdr=None, NoCookie=None, data=None):
    try:
        if not hdr:       req = Request(url, data, headers)
        else:         req = Request(url, data, hdr)

        if len(referer) > 1:  req.add_header('Referer', referer)

        if data:          req.add_header('Content-Length', len(data))

        Log(url)
        response = urlopen(req, timeout=30)

        if response.info().get('Content-Encoding') == 'gzip':
            buf = StringIO( response.read())
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            f.close()
        else:
            data = response.read()

        if not NoCookie:
            # Cope with problematic timestamp values on RPi on OpenElec 4.2.1
            try:
                cj.save(cookiePath)
            except: pass

        response.close()
    except urllib2.HTTPError as e:
        data = e.read()
        notify('Oh oh',data)
        if e.code == 503 and 'cf-browser-verification' in data:
            data = cloudflare.solve(url,cj, USER_AGENT)
        else:
            raise urllib2.HTTPError()
    except Exception as e:
        if 'SSL23_GET_SERVER_HELLO' in str(e):
            notify('Oh oh','Python version to old - update to Krypton or FTMC')
            raise urllib2.HTTPError()
        else:
            notify('Oh oh','It looks like this website is down.')
            raise
        return None
    return data


def postHtml(url, form_data={}, headers={}, compression=True, NoCookie=None):
    try:
        _user_agent = 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 ' + \
                  '(KHTML, like Gecko) Chrome/13.0.782.99 Safari/535.1'
        req = urllib2.Request(url)
        if form_data:
            form_data = urllib.urlencode(form_data)
            req = urllib2.Request(url, form_data)
        req.add_header('User-Agent', _user_agent)
        for k, v in headers.items():
            req.add_header(k, v)
        if compression:
            req.add_header('Accept-Encoding', 'gzip')
        response = urllib2.urlopen(req)
        data = response.read()
        if not NoCookie:
            try:
                cj.save(cookiePath)
            except: pass
        response.close()
    except Exception as e:
        if 'SSL23_GET_SERVER_HELLO' in str(e):
            notify('Oh oh','Python version to old - update to Krypton or FTMC')
            raise urllib2.HTTPError()
        else:
            notify('Oh oh','It looks like this website is down.')
            raise urllib2.HTTPError()
        return None
    return data


def getHtml2(url):
    req = Request(url)
    response = urlopen(req, timeout=60)
    data = response.read()
    response.close()
    return data


def getVideoLink(url, referer, hdr=None, data=None):
    if not hdr:
        req2 = Request(url, data, headers)
    else:
        req2 = Request(url, data, hdr)
    if len(referer) > 1:
        req2.add_header('Referer', referer)
    url2 = urlopen(req2).geturl()
    return url2


def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q

def cleantext(text):
    #Log(text,xbmc.LOGNONE)
    text = text.replace('&#8211;','-')
    text = text.replace('&ndash;','-')
    #text = html_parser.unescape(text)
    if not isinstance(text, unicode):
        text = unicode(text, "utf-8")
#    Log(text,xbmc.LOGNONE)
    text = text.replace('&amp;','&')
    text = text.replace('&#038;','&')
    text = text.replace('&#8217;','\'')
    text = text.replace('&#8216;','\'')
    text = text.replace('&#8230;','...')
    text = text.replace('&quot;','"')
    text = text.replace('&#039;','`')
    text = text.replace(u'ñ','n')

    #Log(text,xbmc.LOGNONE)
    #xbmc.log(  u'ñ'.encode("utf-8").decode("utf-8") , xbmc.LOGNONE)
    #text = text.encode("utf-8").replace('&ntilde;','\xf1').decode("utf-8")
    text = text.replace('&rsquo;','\'')
    text = text.encode('ascii', 'ignore').strip()
    #Log(text,xbmc.LOGNONE)

    return text


def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext

def Set_ListItem_Duration(listitem, duration):
    duration=duration.strip()
    duration_seconds = 0
    #Log("'{}'".format(duration), xbmc.LOGNONE)

    #somethimes format will be hh:mm:ss: normalize it to what I want
    timearr= ['s ','m ','h ']
    if ':' in duration:
        duration_arr = duration.split(':')
        duration = ""
        #Log("len '{}'".format(len(duration_arr)), xbmc.LOGNONE)
        i = 0
        for duration_elem in reversed(duration_arr):
            #Log("'{}'".format(duration_elem), xbmc.LOGNONE)
            duration = duration_elem + timearr[i] + duration
            i = i+1

    duration=duration.strip()
    #Log("'{}'".format(duration), xbmc.LOGNONE)

    #assume format will be Xh Ym Zs
    duration_arr = duration.split(' ')
    for duration_elem in duration_arr:
        #Log(duration_elem)
        if 'h' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('h',''))*3600
        elif 'm' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('m',''))*60
        elif 's' in duration_elem:
            duration_seconds = duration_seconds + int(duration_elem.replace('s',''))
        else:
            duration_seconds = duration_seconds + int(duration_elem)
    #Log(duration_seconds)
    listitem.setInfo(type="Video", infoLabels={"duration": duration_seconds} )

def addDownLink(name, url, mode, iconimage, desc='', stream=None, fav='add', noDownload=False, duration=None, date=None, views=None, likes=None, bitrate=None ):

    if fav == 'add': favtext = "Add to"
    elif fav == 'del': favtext = "Remove from"

    u = (sys.argv[0] +
     "?url=" + urllib.quote_plus(url) +
     "&mode=" + str(mode) +
     "&name=" + urllib.quote_plus(name)
          )

    dwnld = (sys.argv[0] +
     "?url=" + urllib.quote_plus(url) +
     "&mode=" + str(mode) +
     "&download=" + str(1) +
     "&name=" + urllib.quote_plus(name)
          )

    favorite = (sys.argv[0] +
     "?url=" + urllib.quote_plus(url) +
     "&fav=" + fav +
     "&favmode=" + str(mode) +
     "&mode=" + str('900') +
     "&img=" + urllib.quote_plus(iconimage) +
     "&name=" + urllib.quote_plus(name)
        )

    ok = True

    if len(iconimage) < 1: iconimage = uwcicon
    if not '|' in iconimage and 'http' in iconimage:
        iconimage = "{}{}".format(iconimage, Header2pipestring())


    liz = xbmcgui.ListItem(name) #, thumbnailImage=iconimage, iconImage="DefaultVideo.png")
    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    fanart = os.path.join(rootDir, 'fanart.jpg')
    if addon.getSetting('posterfanart') == 'true':
        fanart = iconimage
        liz.setArt({'poster': iconimage})

    liz.setContentLookup(False)

    liz.setArt({'fanart': fanart})

    if duration:
        Set_ListItem_Duration(liz, duration)

    if stream:
        liz.setProperty('IsPlayable', 'true')

    if len(desc) < 1:
        liz.setInfo(type="Video", infoLabels={"Title": name})
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name, "plot": desc, "plotoutline": desc})

    liz.addStreamInfo('video', {'codec': 'h264'})

    contextMenuItems = []
    contextMenuItems.append(("[COLOR {}]{} favorites[/COLOR]".format(time_text_color, favtext), "xbmc.RunPlugin({})".format(favorite)))
    time_text_color
    if noDownload == False:
        contextMenuItems.append(("[COLOR {}]Download Video[/COLOR]".format(time_text_color), "xbmc.RunPlugin({})".format(dwnld)))
    liz.addContextMenuItems(contextMenuItems, replaceItems=False)

    #xbmc.log("addDownLink: " + u, xbmc.LOGNONE)

    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=False)
    return ok


def addDir(name, url, mode, iconimage, page=None, channel=None, section=None, keyword='', Folder=True, duration=None):
    #return
    u = (sys.argv[0] +
     "?url=" + urllib.quote_plus(url) +
     "&mode=" + str(mode) +
     "&page=" + str(page) +
     "&channel=" + str(channel) +
     "&section=" + str(section) +
     "&keyword=" + urllib.quote_plus(keyword) +
     "&name=" + urllib.quote_plus(name))
    ok = True

    if len(iconimage) < 1: iconimage = uwcicon

    if not '|' in iconimage and 'http' in iconimage:
        iconimage = "{}{}".format(iconimage, Header2pipestring())

    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)

    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    fanart = os.path.join(rootDir, 'fanart.jpg')

    #liz.setProperty("IsPlayable","false")

    if addon.getSetting('posterfanart') == 'true':
        fanart = iconimage
        liz.setArt({'poster': iconimage})

    liz.setArt({'fanart': fanart})

    if duration:
        Set_ListItem_Duration(liz, duration)

    #setting type = music instead of video means no icon to the right of the label
    #liz.setInfo(type="music", infoLabels={"Title": name})

    if len(keyword) >= 1:
        keyw = (sys.argv[0] +
            "?mode=" + str('904') +
            "&keyword=" + urllib.quote_plus(keyword))
        contextMenuItems = []
        contextMenuItems.append( ("[COLOR {}]Remove keyword[/COLOR]".format(time_text_color), "xbmc.RunPlugin({})".format(keyw) )  )
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)

    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=Folder)
    return ok

def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode(keyboard.getText(), "utf-8")
    return default



# videowood decode copied from: https://github.com/schleichdi2/OpenNfr_E2_Gui-5.3/blob/4e3b5e967344c3ddc015bc67833a5935fc869fd4/lib/python/Plugins/Extensions/MediaPortal/resources/hosters/videowood.py
def videowood(data):
    parse = re.search('(....ωﾟ.*?);</script>', data)
    if parse:
        todecode = parse.group(1).split(';')
        todecode = todecode[-1].replace(' ','')

        code = {
            "(ﾟДﾟ)[ﾟoﾟ]" : "o",
            "(ﾟДﾟ) [return]" : "\\",
            "(ﾟДﾟ) [ ﾟΘﾟ]" : "_",
            "(ﾟДﾟ) [ ﾟΘﾟﾉ]" : "b",
            "(ﾟДﾟ) [ﾟｰﾟﾉ]" : "d",
            "(ﾟДﾟ)[ﾟεﾟ]": "/",
            "(oﾟｰﾟo)": '(u)',
            "3ﾟｰﾟ3": "u",
            "(c^_^o)": "0",
            "(o^_^o)": "3",
            "ﾟεﾟ": "return",
            "ﾟωﾟﾉ": "undefined",
            "_": "3",
            "(ﾟДﾟ)['0']" : "c",
            "c": "0",
            "(ﾟΘﾟ)": "1",
            "o": "3",
            "(ﾟｰﾟ)": "4",
            }
        cryptnumbers = []
        for searchword,isword in code.iteritems():
            todecode = todecode.replace(searchword,isword)
        for i in range(len(todecode)):
            if todecode[i:i+2] == '/+':
                for j in range(i+2, len(todecode)):
                    if todecode[j:j+2] == '+/':
                        cryptnumbers.append(todecode[i+1:j])
                        i = j
                        break
                        break
        finalstring = ''
        for item in cryptnumbers:
            chrnumber = '\\'
            jcounter = 0
            while jcounter < len(item):
                clipcounter = 0
                if item[jcounter] == '(':
                    jcounter +=1
                    clipcounter += 1
                    for k in range(jcounter, len(item)):
                        if item[k] == '(':
                            clipcounter += 1
                        elif item[k] == ')':
                            clipcounter -= 1
                        if clipcounter == 0:
                            jcounter = 0
                            chrnumber = chrnumber + str(eval(item[:k+1]))
                            item = item[k+1:]
                            break
                else:
                    jcounter +=1
            finalstring = finalstring + chrnumber.decode('unicode-escape')
        stream_url = re.search('=\s*(\'|")(.*?)$', finalstring)
        if stream_url:
            return stream_url.group(2)
    else:
        return


def streamdefence(html):

    #Log("streamdefence(html)={}".format(html), xbmc.LOGNONE)

    if html == "":
        return html


    #iframe src="https://verystream.com/e/N3DnRCksHaR/younfn.mp4"
    verystream_url = re.compile('iframe src="([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    if verystream_url:
        verystream_url = verystream_url[0]
        Log("verystream_url={}".format(verystream_url))
        return getHtml(verystream_url)

    second_streamdefence_url = re.compile('strdef\.world/player([^"]+)"', re.DOTALL | re.IGNORECASE).findall(html)
    if second_streamdefence_url:
        second_streamdefence_url = 'https://www.strdef.world/player' + second_streamdefence_url[0]
        Log("second_streamdefence_url={}".format(second_streamdefence_url))
        #sdurl = "https://strdef.world/player.php?id=1ebd0d89-6813-40ed-a014-c0e2bec7252b"
        sdsrc = getHtml(second_streamdefence_url)
        return streamdefence(sdsrc)
    
    openloadurl = re.compile(r"//(?:www\.)?o(?:pen)?load\.(?:co|io|tv|info|stream)?/(?:embed|f)/([0-9a-zA-Z-_]+)", re.DOTALL | re.IGNORECASE).findall(html)
    if openloadurl:
        openloadurl = openloadurl[0]
        #Log("openloadurl={}".format(openloadurl))
        return "https://openload.co/embed/{}/".format(openloadurl)

    dhYas638H_code = re.compile('\(dhYas638H\(\"([0-9a-zA-Z/-_\+\=]+)\"', re.DOTALL | re.IGNORECASE).findall(html)
    if dhYas638H_code:
        Log("second encoding")
        dhYas638H_code = dhYas638H_code[0]
        try:
            dhYas638H_code = 'base64decoded(dhYas638H("' + base64.b64decode(dhYas638H_code) + '"'
            Log("base 64 decode successful")
            return streamdefence(dhYas638H_code)
        except:
            pass
        
        #Log("dhYas638H_code={}".format(dhYas638H_code) )
        dhYas638H_decoded = dhYas638H(dhYas638H_code)

        html = html.replace('dhYas638H("'+dhYas638H_code+'")', '"' + dhYas638H_decoded + '"' )
        #Log("html_after_replace={}".format(html) )
        return html

    else:
        Log("second encoding NOT found")

    dhYas638H_code = None
    dhYas638H_code = re.compile('= dhYas638H\(\"?([0-9a-zA-Z-/_\+\=]+)\"?\)', re.DOTALL | re.IGNORECASE).findall(html)
    if dhYas638H_code:
        dhYas638H_code = dhYas638H_code[0]
        #Log("dhYas638H_code={}".format(dhYas638H_code), xbmc.LOGNONE)
        third_redirect = None

        third_redirect = re.compile(dhYas638H_code+'=\"([0-9a-zA-Z/-_\+\=]+)\"'  , re.DOTALL | re.IGNORECASE).findall(html)
        if third_redirect:
            third_redirect = third_redirect[0]
            #Log("third_redirect={}".format(third_redirect), xbmc.LOGNONE)        
            dhYas638H_decoded = dhYas638H(third_redirect)
            return streamdefence(dhYas638H_decoded)
    else:
        Log("no third_redirect found")        
    html = re.compile('"(https?:\/\/[^\"]+)"', re.DOTALL | re.IGNORECASE).findall(html)[0]

    #Log("decoded={}".format(html), xbmc.LOGNONE)
    return html

def streamdefence2(html):
    return None

def from_char_code(*args):
    return ''.join(map(unichr, args))

def dhYas638H(input_string):
    base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    output = "";
    i = 0;
    #Log("input_string={}".format(input_string), xbmc.LOGNONE)        
    input_string = re.sub("[^A-Za-z0-9+/=]", "", input_string, re.DOTALL)
    while i < len(input_string) :

        #Log("i+0={},input_stringi+0={}".format(i,input_string[i+0]), xbmc.LOGNONE)        
        enc1 = base64.index(  input_string[i+0]  )
        #Log("enc1={}".format(enc1), xbmc.LOGNONE)        
        enc2 = base64.index(  input_string[i+1]  )
        enc3 = base64.index(  input_string[i+2]  )
        enc4 = base64.index(  input_string[i+3]  )

        i = i+4

        ch1 = (enc1 << 2) | (enc2 >> 4)
        ch2 = ((enc2 & 15) << 4) | (enc3 >> 2)
        ch3 = ((enc3 & 3) << 6) | enc4

        output = output + from_char_code(ch1)

        if (enc3 != 64):
            output = output + from_char_code(ch2)
        if (enc4 != 64):
            output = output + from_char_code(ch3)

        ch1 = ""
        ch2 = ""
        ch3 = ""
        enc1 = ""
        enc2 = ""
        enc3 = ""
        enc4 = ""

    Log("dhYas638H_output={}".format(output), xbmc.LOGNONE)        
    return output


def searchDir(url, mode, page=None):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()

    refresh_text_color = addon.getSetting('refresh_text_color').lower()
    search_text_color = addon.getSetting('search_text_color').lower()
    time_text_color = addon.getSetting('time_text_color').lower()

    try:
        c.execute("SELECT * FROM keywords")
        for (keyword,) in c.fetchall():
            name = "[COLOR {}]{}[/COLOR]".format(time_text_color, urllib.unquote_plus(keyword))
            addDir(name, url, mode, uwcimage('uwc-search.png'), page=page, keyword=keyword)
    except:
        traceback.print_exc()
        pass

    addDir("[COLOR {}]Add Keyword[/COLOR]".format(time_text_color), '', 902, uwcimage('uwc-search.png'), '', mode, Folder=False)
    addDir("[COLOR {}]Clear list[/COLOR]".format(time_text_color), '', 903, uwcimage('uwc-search.png'), Folder=False)

    endOfDirectory()

#@url_dispatcher.register('902', ['url', 'channel'])
#def newSearch(url, channel):
@url_dispatcher.register('902' )
def newSearch():
    vq = _get_keyboard(heading="Searching for...")
    if (not vq): return False, 0
    title = urllib.quote_plus(vq)
    addKeyword(title)
    xbmc.executebuiltin('Container.Refresh')

@url_dispatcher.register('903')
def clearSearch():
    delallKeyword()
    xbmc.executebuiltin('Container.Refresh')


def addKeyword(keyword):
    xbmc.log(keyword)
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("INSERT INTO keywords VALUES (?)", (keyword,))
    conn.commit()
    conn.close()


def delallKeyword():
    yes = dialog.yesno('Warning','This will clear all the keywords', 'Continue?', nolabel='No', yeslabel='Yes')
    if yes:
        conn = sqlite3.connect(favoritesdb)
        c = conn.cursor()
        c.execute("DELETE FROM keywords;")
        conn.commit()
        conn.close()

@url_dispatcher.register('904', ['keyword'])
def delKeyword(keyword):
    xbmc.log('keyword: ' + keyword)
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM keywords WHERE keyword = '%s'" % keyword)
    conn.commit()
    conn.close()
    xbmc.executebuiltin('Container.Refresh')


def textBox(heading,announce):
    class TextBox():
        WINDOW=10147
        CONTROL_LABEL=1
        CONTROL_TEXTBOX=5
        def __init__(self,*args,**kwargs):
            xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
            self.win=xbmcgui.Window(self.WINDOW)
            xbmc.sleep(500)
            self.setControls()
        def setControls(self):
            self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
            try: f=open(announce); text=f.read()
            except: text=announce
            self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
            return
    TextBox()
    while xbmc.getCondVisibility('Window.IsVisible(10147)'):
        xbmc.sleep(500)

def kodilog(msg, loglevel=None):
    Log(msg,loglevel)
def log(msg='', loglevel=None):
    Log(msg, loglevel)
def Log(msg='', loglevel=None):
    #xbmc.log(repr(msg),xbmc.LOGERROR)
    #xbmc.log(msg.decode('utf8',errors='ignore').encode('ascii',errors='ignore'),xbmc.LOGNONE)
    try:    debug = (this_addon.getSetting('debug').lower() == "true")
    except: debug = True
    msg = "{}: {}".format(addon_id, msg)
    if loglevel: xbmc.log(msg , loglevel)
    elif debug:  xbmc.log(msg , xbmc.LOGNONE)
    else:    xbmc.log(msg)

def Notify(header=None, msg='', duration=5000, sound=False):
    if msg == '':
        msg = header
        header = ''
    notify(header, msg, duration, sound)
def notify(header=None, msg='', duration=5000, sound=False):
    debug = (this_addon.getSetting('debug').lower() == "true")
    if threading.current_thread().name == "MainThread":
        Log( msg, xbmc.LOGNOTICE)
        xbmcgui.Dialog().notification(addon_name, msg, uwcicon, duration, sound=False )
    elif debug:
        Log( msg, xbmc.LOGNOTICE)

def Header2pipestring(header=headers):
    q = "|{}".format( urllib.urlencode(header)  )
    return q
    q = "|{}".format( repr(header) )
    q = q.replace( "{'", "")
    q = q.replace( "'}", "")
    q = q.replace( "': '", "=" )
    q = q.replace( "', '", "&" )

    return q

def add_sort_method():
    xbmcplugin.addSortMethod(addon_handle,sortMethod=sort_order) #use preferred method first
    xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    #xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_FOLDERS)
    xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(addon_handle,sortMethod=xbmcplugin.SORT_METHOD_DURATION)


def FaapySalt(licencekey, video_url):
    #m is a salt used later
    #d=licencecode
    #k = first 8 numbs of licence key
    #l= last 8
    c = "16px"
    #$3790 8681 2506 737
    #3790868 12506737
    #c =  video_url: 'function/0/https://faapy.com/get_file/1/1209b8bc708dea4836ab494685daf627/10000/10267/10267.mp4/',
    d = licencekey

#    f = licencekey without dollar sign, but then get changed
#        g = 1; g < d.length; g++)
#        f += o(d[g]) ? o(d[g]) : 1;
    g = 1 # starts at 1 because of dollar sign
    f = ""
    while g < len(licencekey):
        f += licencekey[g]
        g += 1

    #return f #for debugging
    j = len(f)/2
    #return j
    f = oo(f)

    k=''
    for i in range(1,9):
        k += licencekey[i]
    k = oo(k)
    #return k

    L=''
    
    for i in range(8,16):
        L += licencekey[i]

    L = oo(L)
    #return L
    g = abs(L - k)
#    return g
##    g < 0 && (g = -g)
    f = g

    g = abs(k - L)
##    g < 0 && (g = -g)

    f += g
    f *= 2
    f = str(f)
#    return f
    i = oo(c) / 2 + 2
    #return i
    m = ""
####    g = 0; g < j + 1; g++)
####        for (h = 1; h <= 4; h++)
####        n = o(d[g + h]) + o(f[g]),
####        n >= i && (n -= i),
####        m += n;
####    return m
    g = 0
    while g < (j+1) :
        #xbmc.log('g=%s' % g, xbmc.LOGNONE)
        h = 1
        while h <= 4:
            #xbmc.log('h=%s' % h, xbmc.LOGNONE)
            n = oo(d[g + h]) + oo(f[g])
            if n >= i:
                n -= i
            m = m + str(n)
            h += 1

        g += 1

    return m
####o =    return function(n, r) {
####            var o = String(n).trim()
####              , i = Number(r) || (t.test(o) ? 16 : 10);
####            return e(o, i)
####            }
##    return m



def oo(val):
    return int(filter(str.isdigit, val))

def ConvertFaapyCode(code, salt):
# h = code
# i = salt
##for (var j = h, k = h.length - 1; k >= 0; k--) {
##    for (var l = k, m = k; m < i.length; m++)
##        l += parseInt(i[m]);
##    for (; l >= h.length; )
##        l -= h.length;
##    for (var n = "", o = 0; o < h.length; o++)
##        n += o == k ? h[l] : o == l ? h[k] : h[o];
##    h = n
##    }
## 1209b8bc708dea4836ab494685daf627
## 12345678901234567890123456789012
#fappysalt 48017908019764248681358958928927

    #xbmc.log("salt='{}', length={}".format(salt, len(salt)), xbmc.LOGNONE)
    #xbmc.log("code='{}', length={}".format(code, len(code)), xbmc.LOGNONE)
    j = salt
    h = code
    k = len(h)-1
    while k >= 0:

        L = k
        m = k
        while m < len(salt) :
            L = L + int(salt[m])
            m += 1

        while L >= len(h):
            L = L - len(h)

        n = ""
        o = 0
        while o < len(h):
            if o == k:
                n = n + h[L]
            else:
                if o == L:
                    n = n + h[k]
                else:
                    n = n + h[o]
                    
            o += 1

        h = n

        k -=1

    return n

@url_dispatcher.register('9999')
def configure_addon():
    xbmcaddon.Addon(id='inputstream.adaptive').openSettings()

def endOfDirectory(cacheToDisc=True):
    global addon_handle
    if int(sys.argv[1]) > 0:
        addon_handle = int(sys.argv[1])
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=cacheToDisc)

    
