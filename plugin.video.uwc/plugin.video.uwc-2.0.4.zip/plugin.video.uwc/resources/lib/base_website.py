#-*- coding: utf-8 -*-
'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#import base libraries
import json
import re
import sys
import time
import traceback
import uuid

import xbmc
import xbmcgui
import xbmcplugin
#import internal addon libraries
import resolver

import search
import constants as C
#define frequenctly used aliases
from utils import Log,LogR
from utils import get_setting as GetSetting
from constants import unquote_plus
from constants import reload

import utils
reload(utils)

class ProgressDialogCancelException(Exception):
    _msg = ""
    def __init__(self, message):
        _msg = message
        

class Base_Website(object):
    
    def __init__(self):
        #don't set these; they are set in the sub-class
        pass
    @property
    def FRIENDLY_NAME(self):
        return self._FRIENDLY_NAME
    @property
    def LIST_AREA(self):
        return self._LIST_AREA
    @property
    def LIST_METHOD(self):
        return self._LIST_METHOD
    _LIST_METHOD = "GET"

    @property
    def MAX_RECURSE_DEPTH(self):
        return self._MAX_RECURSE_DEPTH
    _MAX_RECURSE_DEPTH = C.DEFAULT_RECURSE_DEPTH

    @property
    def LIST_HEADERS(self):
        return self._LIST_HEADERS
    _LIST_HEADERS = None
    @property
    def PLAY_HEADERS(self):
        return self._PLAY_HEADERS
    _PLAY_HEADERS = None
    @property
    def SHOW_PLAY_URL(self):
        return self._SHOW_PLAY_URL
    _SHOW_PLAY_URL = True
    @property
    def IGNORE_404(self):
        return self._IGNORE_404
    _IGNORE_404 = True
    @property
    def LIST_REDIRECTED_URL_BECOMES_LISTURL(self):
        return self._LIST_REDIRECTED_URL_BECOMES_LISTURL  
    _LIST_REDIRECTED_URL_BECOMES_LISTURL = True
    @property
    def FRONT_PAGE_CANDIDATE(self):
        return self._FRONT_PAGE_CANDIDATE
    @property
    def ROOT_URL(self):
        return self._ROOT_URL
    @property
    def SEARCH_URL(self):
        return self._SEARCH_URL  #_ROOT_URL + '/search/?query={}&page={}')
    @property
    def URL_CATEGORIES(self):
        return self._URL_CATEGORIES   #_ROOT_URL + '/categories/'
    _URL_CATEGORIES = None
    @property
    def URL_RECENT(self): #must be defined
        return self._URL_RECENT  #_ROOT_URL + '/browse/time/?page={}'




    @property
    def SAVE_COOKIES(self):
        return self._SAVE_COOKIES
    _SAVE_COOKIES = False

    @property
    def MAIN_MODE(self):
        return self._MAIN_MODE
    @property
    def LIST_MODE(self):
        return str(int(self._MAIN_MODE) + C.MODE_LIST_OFFSET)
    @property
    def PLAY_MODE(self):
        return str(int(self._MAIN_MODE) + C.MODE_PLAY_OFFSET)
    @property
    def CATEGORIES_MODE(self):
        return str(int(self._MAIN_MODE) + C.MODE_CATEGORY_OFFSET)
    @property
    def SEARCH_MODE(self):
        return str(int(self._MAIN_MODE) + C.MODE_SEARCH_OFFSET)
    @property
    def TEST_MODE(self):
        return str(int(self._MAIN_MODE) + C.MODE_TEST_OFFSET)
    @property
    def REBUILD_ICON(self):
        return str(int(self._MAIN_MODE) + C.MODE_ICON_OFFSET)


    @property
    def FIRST_PAGE(self):
        return self._FIRST_PAGE
    _FIRST_PAGE = "1"

    @property
    def ITEMS_NOT_FOUND_INDICATORS(self):
        return self._ITEMS_NOT_FOUND_INDICATORS
    _ITEMS_NOT_FOUND_INDICATORS = []
    @property
    def REGEX_video_region(self):
        return self._REGEX_video_region
    _REGEX_video_region = None
    @property
    def REGEX_list_items(self):
        return self._REGEX_list_items
    #no default; instance must override or see an error
    
    @property
    def REGEX_next_page_region(self):
        return self._REGEX_next_page_region
    _REGEX_next_page_region = '(.+)'
    @property
    def REGEX_next_page_regex(self):
        return self._REGEX_next_page_regex
    #no default; instance must override or see an error
    
    @property
    def REGEX_play_region(self):
        return self._REGEX_play_region
    _REGEX_play_region = '(.+)'
    @property
    def REGEX_playsearch_01(self):
        return self._REGEX_playsearch_01
    _REGEX_playsearch_01 = None
    _REGEX_playsearch_02 = None
    #originally no default; instance must override or see an error
    

    @property  #if we happen to be using json to search for playable vids, expect the json item that specifies the url to be labeled as...
    def REGEX_playsearch_JSON_urlstring(self):
        return self._REGEX_playsearch_JSON_urlstring
    _REGEX_playsearch_JSON_urlstring = 'videoUrl'
    @property #if we happen to be using json to search for playable vids, expect the json item that specifies quality to be labeled as...
    def REGEX_playsearch_JSON_qualitystring(self):
        return self._REGEX_playsearch_JSON_qualitystring
    _REGEX_playsearch_JSON_qualitystring = 'quality'


    @property
    def MIN_VALID_IMAGE_SIZE(self):
        return self._MIN_VALID_IMAGE_SIZE
    _MIN_VALID_IMAGE_SIZE = C.MIN_VALID_IMAGE_SIZE

    @property
    def REGEX_tags_region(self):
        return self._REGEX_tags_region
    _REGEX_tags_region = None
    @property
    def REGEX_tags(self):
        return self._REGEX_tags
    _REGEX_tags = None #default is not to look for this

    @property
    def REGEX_categories_region(self):
        return self._REGEX_categories_region
    _REGEX_categories_region = '(.+)'
    @property
    def REGEX_categories(self):
        return self._REGEX_categories
    _REGEX_categories = None #default is not to look for this


    @property
    def size_filter(self):
        return self._size_filter
    _size_filter = C.minimum_scene_duration #default is show movies longer than this many seconds

    #__________________________________________________________________________
    #
    @property
    def REGEX_icon_search(self):
        return self._REGEX_icon_search
    _REGEX_icon_search = '<meta property="og:image" content="(?P<thumb>[^"]+)"' #default is not to look for this
    #__________________________________________________________________________
    # change thumb as needed by website
    def Normalize_Icon_Search_Icon(self, thumb):
        return thumb
    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=None):
        LogR((__name__, locals())
##             ,C.LOGNONE
             )
        if not referer: referer = self._ROOT_URL
        page_content = utils.getHtml(url, referer)
        thumb = re.compile(self.REGEX_icon_search, re.DOTALL | re.IGNORECASE).findall(page_content)
        thumb = thumb[0]
        thumb = self.Normalize_Icon_Search_Icon(thumb)
        LogR(
            thumb
##             ,C.LOGNONE
             )
        return thumb

    #__________________________________________________________________________
    # sometimes we need a POST+data instead of a GET
    _LIST_DATA = None
    def LIST_DATA(self,*args,**kargs):
##        LogR(locals())
        if self._LIST_DATA:
            return self._LIST_DATA(self, *args, **kargs)
        else:
            return None
    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    _ALTERNATE_playsearch_01 = None
    def ALTERNATE_playsearch_01(self, *args, **kargs):
        if self._ALTERNATE_playsearch_01:
            return self._ALTERNATE_playsearch_01(self, *args, **kargs)
        else:
            Log('ALTERNATE_playsearch_01 not coded')
            return None
    #__________________________________________________________________________
    # Which right click properties to add to icon
    # C.PLAYMODE_VARIABLE, None #adds properies such as play480, play1080
    # "" #adds properies such as C.PLAYMODE_F4MPROXY C.PLAYMODE_INPUTSTREAM
    @property
    def Right_Click_Option(self):
        return self._Right_Click_Option
    _Right_Click_Option = None
    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants
    def Search_Keyword_Normalize(self, *args, **kargs):
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args) > 0): keyword = args[0]
        else                                     : keyword = ""
##        Log("keyword='{}'".format(repr(keyword)))
        return keyword.replace(' ','+')
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, *args, **kargs):
        #search_url = kwargs.pop("search_url", None)
        if                  "search_url" in kargs: search_url = kargs["search_url"]
        elif (args is not None) and (len(args) > 0): search_url = args[0]
        else                                     : search_url = self.SEARCH_URL
        if                     "keyword" in kargs: keyword = kargs["keyword"]
        elif (args is not None) and (len(args) > 1): keyword = args[1]
        elif (args is not None) and (len(args) > 0): keyword = args[0]
        else                                     : keyword = ""
##        Log(repr(args))
##        Log(repr(kargs))
##        Log("search_url='{}'".format(repr(search_url)))
##        Log("keyword='{}'".format(repr(keyword)))
        if C.PY3: search_url = str(search_url)
        if C.PY2: search_url = unicode(search_url)
        return search_url.format(keyword, '{}')
    #__________________________________________________________________________
    # Change listing url as neeeded by website
    def List_URL_Normalize(self, url, page=None):
        return url #do nothing by default
    #__________________________________________________________________________
    # Change categoryurl found in via regex with structure neeeded by website
    def Category_URL_Normalize(self, url):
        return url #do nothing by default
    #__________________________________________________________________________
    # Change thumbnail found in via regex with structure neeeded by website
    def Category_THUMB_Normalize(self, thumb):
        return thumb #do nothing by default
    #__________________________________________________________________________
    # Change video source url found in via regex with a structure used by site
    def Video_Source_URL_Normalize(self, url):
        return utils.cleantext(url) 
    #__________________________________________________________________________
    # Construct save file path when default is not good enough
    def Make_Download_Path(self, *args, **kargs):
        return None 
    #__________________________________________________________________________
    # Change video url created by List as neeeded by website
    def Normalize_VideoURL(self, videourl):
        if not videourl.startswith('http'): videourl = self.ROOT_URL + videourl
        return videourl
    #__________________________________________________________________________
    # Change thumb url created by List as neeeded by website; not all params must be used
    def Normalize_ThumbURL(self, thumb, duration=None, videourl=None):
        if not thumb.startswith('http'): thumb = "https:" + thumb
        return thumb
    #__________________________________________________________________________
    # Change duration information neeeded by website; not all params must be used
    def Normalize_Duration(self, duration):
        duration = duration.replace(' min','s')#.replace(':','m ')
        return duration

    #__________________________________________________________________________
    # Change label created by List as neeeded by website
    def Normalize_ListLabel(self, label, hd):
##        if C.PY2: raise Exception('test his for tukif')
##        if C.PY3:
##            LogR((type(label),label))
##            label = label.replace("\\\\","\\")
##            LogR((type(label),label))
##            label = label.encode('utf8').decode('utf8')
##            LogR((type(label),label))
        label = u"{}{}{}".format(C.SPACING_FOR_NAMES, utils.cleantext(label), hd)
        label = label.replace("\\\"", "'")
        return label        
    #__________________________________________________________________________
    #
    def Main(self):
        if C.DEBUG:
            utils.addDir(
                name = "[COLOR {}]{}[/COLOR]".format(C.highlight_text_color, "Self Test")
                , url = C.DO_NOTHING_URL 
                , mode = self.TEST_MODE
                , keyword = ''
                )
        if self.URL_CATEGORIES is not None:
            if type(self.URL_CATEGORIES ) == str:
                utils.addDir(
                    name = C.STANDARD_MESSAGE_CATEGORIES 
                    ,url = self.URL_CATEGORIES
                    ,mode = self.CATEGORIES_MODE
                    ,iconimage=C.category_icon
                    )
            elif str(type(self.URL_CATEGORIES)) == "<type 'instancemethod'>":
                self.URL_CATEGORIES()

        Log('3')
        progress_dialog = utils.Progress_Dialog(C.addon_name, self._FRIENDLY_NAME)
        Log('4')
        self.List(
            self.URL_RECENT
            , page_start=self.FIRST_PAGE
            , end_directory=True
            , keyword=''
            , progress_dialog=progress_dialog
            , bulk_operation=False
            )

        utils.endOfDirectory(succeeded=True)
    #__________________________________________________________________________
    #
    def Rebuild_Icon(url, referer=ROOT_URL):
        Log(u"Rebuild_Icon(url={}".format(repr(url)))
        if self._REGEX_icon_search and self.Icon_Search:
            icon_uri = self.Icon_Search(url=url
                                        , pattern=self._REGEX_icon_search
                                        , referer=referer)
            return icon_uri
    #__________________________________________________________________________
    #
    def List( self
        , url
        , bulk_operation=False
        , page_start=_FIRST_PAGE
        , page_end=_FIRST_PAGE
        , end_directory=True
        , keyword=''
        , testmode=False
        , progress_dialog=None
        ):

        LogR(locals())

        u = ''
        set_default_view = {}

        if url == C.DO_NOTHING_URL:
            return

        try:

            t_start = time.time()
            page_start = int(page_start)
            if not page_end: page_end = page_start
            else: page_end = int(page_end)
            
            if progress_dialog and progress_dialog.iscanceled():
                raise ProgressDialogCancelException('starting')

            list_url = utils.Initialize_Common_Icons(
                url=url
                , keyword=keyword
                , SEARCH_URL=self.SEARCH_URL
                , SEARCH_MODE=self.SEARCH_MODE
                , page_start=page_start
                , page_end=page_end
                , first_page = self.FIRST_PAGE
                , recurse_depth = self.MAX_RECURSE_DEPTH
                , bulk_operation=bulk_operation
                , end_directory=end_directory
                )
            LogR((url,list_url))

            if progress_dialog and progress_dialog.iscanceled():
                raise ProgressDialogCancelException('listing')

            redirected_url = None
            full_html = ''
            list_url = self.List_URL_Normalize(list_url, page_start)
            LogR((list_url,page_start))
            full_html, redirected_url = utils.getHtml(
                list_url
                , referer = self.ROOT_URL + '/'
                , headers = self.LIST_HEADERS
                , ignore404 = self.IGNORE_404 
                , save_cookie = self.SAVE_COOKIES
                , method = self.LIST_METHOD
                , sent_data = self.LIST_DATA(page=page_start,keyword=keyword)
                , send_back_redirect = True
                )
            if redirected_url: list_url = redirected_url
            LogR((url,redirected_url))
            if redirected_url and self.LIST_REDIRECTED_URL_BECOMES_LISTURL:
                LogR((url,list_url,redirected_url))
                url = url.replace(url.split('{}')[0], redirected_url)
                LogR((url,list_url,redirected_url))
                

            #delted video?
            if any(x in full_html for x in self.ITEMS_NOT_FOUND_INDICATORS):
                video_region = ''
                full_html = ''
                Log("_ITEMS_NOT_FOUND_INDICATORS discovered...clearing list")

            #distinguish between adverts and videos
            try:
                if self.REGEX_video_region:
                    video_region = re.compile(
                        self.REGEX_video_region
                        , re.DOTALL | re.IGNORECASE).findall(
                            full_html
                            )
                if video_region:
                    video_region = video_region[0]
##                    LogR(type(video_region))
                else:
                    video_region = full_html
                    
##                Log('infinite regex debug')
##                traceback.print_stack()
##                Log(video_region)                
            except:
##                traceback.print_exc()
                video_region = full_html
                if self.REGEX_video_region:
                    Log('video region via regex empty', C.LOGWARNING)
                if not video_region: #weird case when site returns blank page
                    video_region = '  '


##            Log(full_html, C.LOGNONE)
##            Log("error")
##            return False
        
            # parse out list items
            try:
##                Log('infinite regex debug')
##                info = re.compile(self.REGEX_list_items, re.DOTALL | re.IGNORECASE).findall(video_region)
##                LogR(len(info))
##                return False
##                LogR(self.REGEX_list_items,include_type=True)
##                LogR(video_region,include_type=True)
                info = re.compile(
                    self.REGEX_list_items
                    , re.DOTALL | re.IGNORECASE
                    ).finditer(video_region)
            except:
                LogR(self.REGEX_list_items, C.LOGWARNING)
                raise
##            Log('infinite regex debug')
            if int(time.time() - t_start) > 60 :
                Log(u"listitem regex much too slow for {} using {}".format(repr(self.ROOT_URL), repr(self.REGEX_list_items))
                , C.LOGWARNING
                )

            if progress_dialog and progress_dialog.iscanceled(): raise ProgressDialogCancelException('recursion')
            
            videourl = ''
            items_list = list()
            added_at_least_one_item = False #movie size filter might not find something long enough; but I want at leas one item  as proof of life

##            Log('infinite regex debug')
            for item in info:

                if progress_dialog:
                    if progress_dialog.iscanceled(): raise ProgressDialogCancelException('additems')
                    else: progress_dialog.increment_percent()

##                Log('infinite regex debug')
                
                videourl = item.group('videourl')
                thumb = item.group('thumb')
                label = item.group('label')
##                LogR(label, C.LOGNONE, include_type=True)
##                try:
##                    label = bytes(item.group('label'),encoding='ascii').decode('raw_unicode_escape ').encode('utf8').decode('utf8')
##                    LogR(label, C.LOGNONE, include_type=True)
##                except:
##                    pass

                hd = item.group('hd')
                duration = item.group('duration')
##                LogR(duration)
                duration = self.Normalize_Duration(duration)
##                LogR(duration)
                duration = utils.Parse_Duration(duration)
##                LogR(duration)

##                Log('infinite regex debug')
                
                thumb = self.Normalize_ThumbURL(thumb, duration, videourl) #must run before videourl normalized
                hd = utils.Normalize_HD_String(hd)
                videourl = self.Normalize_VideoURL(videourl)
                label = self.Normalize_ListLabel(label, hd)

                if duration and self.size_filter and (duration < self.size_filter):
##                    Log(u"item '{}' does not satisfy search filter size".format(repr((label, duration, self.size_filter))))
                    if added_at_least_one_item: #movie size filter might not find something long enough; but I want at leas one item  as proof of life
                        continue
                    else:
                        Log(u'...but add it anyway to have at least one entry')
                
                items_list.append(
                    utils.addDownLink(
                        name = label 
                        , url = videourl 
                        , mode = self.PLAY_MODE 
                        , iconimage = thumb
                        , desc = '\n' + self.ROOT_URL
                        , duration = duration
                        , play_method = self.Right_Click_Option
                        , return_listitem = True
##                        , uuid=str(uuid.uuid4())
                        )
                    )
                
                added_at_least_one_item = True

            if not added_at_least_one_item:
                Log("warning: not added_at_least_one_item")
                Log(self.REGEX_list_items)

            if progress_dialog and progress_dialog.iscanceled(): raise ProgressDialogCancelException('min_val')

            utils.Check_For_Minimum(videourl, keyword, self.MAIN_MODE, self.ROOT_URL, testmode)
            if (testmode == True) and (len(videourl) > 1):
                self.Playvid(videourl, label, download=True, playmode_string=None, testmode=testmode)
            
            if progress_dialog and progress_dialog.iscanceled(): raise ProgressDialogCancelException('next page')

            # next page items
            try:
                next_page_html = re.compile(self.REGEX_next_page_region
                                            , re.DOTALL | re.IGNORECASE
                                            ).findall(full_html)[0]
            except:
                next_page_html = full_html
            np_info = re.compile(self.REGEX_next_page_regex
                                 , re.DOTALL | re.IGNORECASE
                                 ).findall(next_page_html)
            np_url = url
            np_number = int(page_start) + 1
            LogR((np_url, np_number, page_end))
##            LogR((end_directory, np_number, page_end))
            if not np_info:
                Log(C.STANDARD_MESSAGE_NP_INFO.format(list_url))
            else:
                if (len(items_list) < 1): #ensure another List does not happen if we were not able to fill the current one
                    if C.PY3: np_number = sys.maxsize 
                    if C.PY2: np_number = sys.maxint


                possible_recurse_depth = self.MAX_RECURSE_DEPTH

                if not bulk_operation:
                    if end_directory or (end_directory==False and page_start==page_end) : #next may not be required when searching/recursing
                        if (np_number > page_end):
                            if (len(items_list) > 0): #only add 'more' when 'some' have been found
                                #add a next page link
                                u,liz,folder = utils.addDir(
                                    name=C.STANDARD_MESSAGE_NEXT_PAGE.format(np_number)
                                    ,url=np_url 
                                    ,mode=self.LIST_MODE 
                                    ,iconimage=C.next_icon 
                                    ,page_start=np_number
                                    ,page_end=page_end
                                    ,section = None
                                    ,keyword=keyword
                                    ,end_directory=not bulk_operation
                                    ,possible_recurse_depth=possible_recurse_depth
                                    ,return_listitem=True
                                    )
                                items_list.append((u,liz,folder))

            xbmcplugin.addDirectoryItems(handle=C.addon_handle, items=items_list)

            if progress_dialog and progress_dialog.iscanceled(): raise ProgressDialogCancelException('b4 recurse')

##            if  (end_directory == False) and (np_number <= page_end) :

            we_should_recurse = (np_number <= page_end) and full_html
            if we_should_recurse:
                LogR("recursing")
                if not full_html:
                    Log("#stop if full_html is blank because that means that 'end of content' was reached earlier")
##                    end_directory = True
                    pass
                else:
                    if '{}' in np_url:
                        msg = np_url.format(np_number)
                    else: #some sites don't have a page_start number here, but I want to show it
                        msg = np_url + "page_start={}".format(np_number)
                    utils.Notify(msg=msg)
                    self.List(
                          url=np_url
                        , page_start=np_number
                        , page_end=page_end
                        , end_directory=False
                        , keyword=keyword
                        , progress_dialog=progress_dialog
                        , bulk_operation=bulk_operation
                        )
            if not we_should_recurse : #don't change view when we are recursing
                if not testmode: #never change view during testmode
                    set_default_view = {
                        "path": u,
                        "sortmethod" : C.INITIAL_SORTMETHOD
                        ,"sortdirection" : True #toggle to descending [because when blank,  default is ascending]
                        ,"viewmode"      : C.INITIAL_VIEWMODE 
                        }
            
        except ProgressDialogCancelException:
            pass
        except:
##            LogR(locals())
            traceback.print_exc()
        finally:
            LogR(end_directory)
            utils.endOfDirectory(
                end_directory=end_directory
                ,set_default_view=set_default_view
                ,succeeded=True
                #,cacheToDisc=False
                )
##            LogR('ss',C.LOGERROR)

    #__________________________________________________________________________
    #
    def Search(self
               , searchUrl
               , bulk_operation #=False #temp no default during dev
               , keyword=None
               , end_directory=True
               , page_start=_FIRST_PAGE
               , page_end=None
               , progress_dialog=None
               ):
        LogR(locals())

        if not searchUrl:
            return

        if not keyword:
            search.searchDir(
                  url=searchUrl
                , mode=self.SEARCH_MODE
                , page_start=page_start
                , page_end=page_end
                , end_directory=end_directory
                , bulk_operation=bulk_operation
                )
            return

        if page_end is None: #durign dev only - look items when this was not defined but should be
            raise Exception('page_end was not defined')
            
        keyword = unquote_plus(keyword)
        keyword = self.Search_Keyword_Normalize(keyword=keyword)
        searchUrl = self.Search_URL_Normalize(search_url=self.SEARCH_URL, keyword=keyword)
        LogR(searchUrl)
        self.List(
            url=searchUrl
            , page_start=page_start
            , page_end = page_end 
            , end_directory=False #will always be false during Search because Search ends it
            , keyword=keyword
            , progress_dialog=progress_dialog
            , bulk_operation=bulk_operation  
        )

##        LogR(end_directory,C.LOGERROR)
        utils.endOfDirectory(
            end_directory=end_directory
            , cacheToDisc=False
            )
    #__________________________________________________________________________
    #
    def Categories(self, url, end_directory=True):
        Log("Categories(url='{}', end_directory='{}')".format(url, end_directory))
        if not url: return
##        traceback.print_stack()

        category_html = utils.getHtml(url=url, referer=self.ROOT_URL, save_cookie=self.SAVE_COOKIES)
        category_html = re.compile(self.REGEX_categories_region, re.DOTALL | re.IGNORECASE).findall(category_html)
        if category_html: category_html = category_html[0]
        else: category_html = ''
##        Log(category_html[:100])

        info = re.compile(self.REGEX_categories, re.DOTALL | re.IGNORECASE).finditer(category_html)
        for item in info:
            videourl = item.group('videourl')
            thumb = item.group('thumb')
            label = item.group('label')
            videourl = self.Category_URL_Normalize(videourl)
            thumb = self.Category_THUMB_Normalize(thumb)
            utils.addDir(
                name=C.STANDARD_MESSAGE_CATEGORY_LABEL.format(utils.cleantext(label))
                ,url=videourl
                ,mode=self.LIST_MODE
                ,page_start=self.FIRST_PAGE
                ,iconimage=thumb
            )

        utils.endOfDirectory(end_directory=end_directory, succeeded=True)
    #__________________________________________________________________________
    #
    def Test(
        self
        , bulk_operation
        , progress_dialog
        , keyword=None
        , end_directory=False
        , page_start=_FIRST_PAGE
        , page_end=_MAX_RECURSE_DEPTH

        ):
        LogR(locals())

        bulk_operation=True #will always be True during tests

        if not progress_dialog:
            progress_dialog = utils.Progress_Dialog(C.addon_name, self._FRIENDLY_NAME)

        #force user to specify a keyword to search for because not all searches
        #will 'succeed' or 'fail' reliably
        if not keyword:
            keyword = GetSetting('quick_search_string')
        if not keyword:
            #prev_keyword = C.addon.get_xxx__Setting(id='quick_search_string')
            prev_keyword = GetSetting('quick_search_string')
            keyword = utils._get_keyboard(heading="Search query", default=prev_keyword)
            if  keyword == '' :
                return False, 0  ## if blank or the user cancelled the keyboard, return
            C.addon.setSetting(id='quick_search_string', value=keyword)

        self.List(
            self.URL_RECENT
            , bulk_operation=bulk_operation
            , page_start=page_start
            , page_end=page_end
            , end_directory=False
            , keyword=''
            , testmode=True
            , progress_dialog=progress_dialog
            )            
        self.Categories(
            self.URL_CATEGORIES
            , end_directory=False
            )
        self.Search(
            searchUrl=self.SEARCH_URL
            , bulk_operation=bulk_operation
            , keyword=keyword
            , end_directory=False
            , page_start=page_start
            , page_end=page_end
            , progress_dialog=progress_dialog
            )

        utils.addDir(
            name="[COLOR {}]Test Passed {}[/COLOR]".format(C.test_passed_text_color, self.ROOT_URL)
            ,url=C.DO_NOTHING_URL
            ,duration=C.STANDARD_DURATION_REFRESH
            ,mode=C.NO_ACTION_MODE)
            
        utils.endOfDirectory(end_directory=end_directory, succeeded=True)
    #__________________________________________________________________________
    #
    def Playvid(self, url, name, icon_URI=None, download=None, playmode_string=None, play_profile=None, testmode=False):

        t_start = time.time()
        name = utils.cleantext(name)
        Log(u"Playvid(url='{}',name='{}',download='{}',playmode_string='{}',play_profile='{}',icon_URI='{}')".format(
            url,name,download,playmode_string,play_profile,icon_URI))

        try:
            progress_dialog = xbmcgui.DialogProgressBG()
            progress_dialog.create(C.addon_name,name[:50])
        

            if playmode_string and playmode_string[0].isdigit(): max_video_resolution = int(playmode_string)
            else: max_video_resolution = None
            description = u"{}\n{}".format(name, self.ROOT_URL)
            video_url = None #final playable url
            sources_list = None #intermediate var
            download_filespec = self.Make_Download_Path(name=name) #
            videos_list = list() #hold multiple video_url when possible

            full_html = utils.getHtml(url
                                      , self.ROOT_URL
                                      , save_cookie=self.SAVE_COOKIES
                                      , ignore404=True
                                      )
            Log('infinite regex debug')

            


            if any(x in full_html for x in self.ITEMS_NOT_FOUND_INDICATORS):
                   #C.VIDEO_NOT_AVAILABLE_WARNINGS):
                utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name,self.ROOT_URL))
##                LogR(("Playvid",locals()), C.LOGNONE)
                Log("Playvid(url='{}',name='{}',download='{}',playmode_string='{}')".format(
                        url
                        ,name
                        ,download
                        ,playmode_string
                        )
                    , C.LOGNONE
                    )
                return
            Log(u"The time spent to VIDEO_NOT_AVAILABLE {} is {}".format(
                    name, time.time() - t_start
                    )
                )

            #sometimes it is useful to only look in one part of the page
            if self.REGEX_play_region:
                Log('infinite regex debug')
                source_html = re.compile(self.REGEX_play_region, re.DOTALL | re.IGNORECASE).findall(full_html)[0]
                Log('infinite regex debug')
            else:
                Log('play region regex failed. Using full html')
                source_html = full_html

            #... sometimes we can get full list via regex
            if self.REGEX_playsearch_01:
                LogR(self.REGEX_playsearch_01)
                sources_list = re.compile(self.REGEX_playsearch_01, re.DOTALL | re.IGNORECASE).finditer(source_html)
                Log('infinite regex debug')
                
            #... sometimes the page itself contains direct video file links
            if sources_list and '(?P<res>' in self.REGEX_playsearch_01:
                for source in sources_list:
                    if 'res' in source.groupdict():
                        videos_list.append((source.group('res') , self.Video_Source_URL_Normalize(source.group('url'))))

            #... sometimes the page itself contains direct video file links encoded as
            #json
            if sources_list and '(?P<json>' in self.REGEX_playsearch_01:
                for source in sources_list:
                    if 'json' in source.groupdict():
                        Log("converting json to a list; with items (res,url)")
                        sources_list = source.group('json')
                        json_sources = json.loads(sources_list)




                        for json_src in json_sources:
                            if self._REGEX_playsearch_JSON_urlstring in json_src:
                                if json_src[self._REGEX_playsearch_JSON_urlstring] != '':
                                    if self._REGEX_playsearch_JSON_qualitystring in json_src:
                                        q = json_src[self._REGEX_playsearch_JSON_qualitystring]
                                        if type(json_src[self._REGEX_playsearch_JSON_qualitystring]) == list:
                                            #sometimes this happens...for quality 1
                                            q = '1'
                                    else:
                                        q = '1'
                                    videos_list.append((q, json_src[self._REGEX_playsearch_JSON_urlstring]))

            Log(repr((video_url, type(video_url))))
            #sometimes this is defined
            if (len(videos_list) < 1) and self.ALTERNATE_playsearch_01:
                Log("using ALTERNATE_playsearch_01")
                alt_results = self.ALTERNATE_playsearch_01(
                    full_html=full_html
                    , referer=url
                    , download=download
                    , ask_which_file_hoster=not(testmode)
                    , name=name                
                    )
                Log("alt_results='{}'".format(repr(alt_results)))
                if alt_results:
                    #playmode_string = None #allow playvid to figure out best player
                    for alt_res, alt_url in alt_results:
                        videos_list.append((alt_res, alt_url))

##            Log(full_html)
##            Log(repr((video_url, type(video_url))))
##            Log(repr((videos_list, type(video_url))))

            #if 'direct' was chosen, use max available resolution
            if playmode_string == C.PLAYMODE_DIRECT:
                max_video_resolution = 99999
                
            #when multiple videos are available; use the best/worst resolution
            if len(videos_list) > 0:
##                Log("videos_list='{}'".format(repr(videos_list)))
                video_url = utils.SortVideos(
                    sources=videos_list
                    ,download=download
                    ,vid_res_column=0
                    ,max_video_resolution=max_video_resolution)
            Log("videos_list='{}'".format(repr(videos_list)))
            Log(video_url)

            #sometimes the page can only be resolved by another tool
            if self.REGEX_playsearch_01 == C.FLAG_USE_RESOLVER_ONLY:
                resolver_source = None
                if self._REGEX_playsearch_02:
                    LogR(self._REGEX_playsearch_02)
                    resolver_source = re.compile(self._REGEX_playsearch_02, re.DOTALL | re.IGNORECASE).findall(source_html)
                LogR(resolver_source)
                if resolver_source:
                    video_url = resolver.resolve_video(
                        videosource="   ".join(resolver_source)
                        , name=name
                        , download=download
                        , url=url
                        , ask_which_file_hoster=not(testmode)
                        )
                else:
                    #hail mary
                    video_url = resolver.resolve_video(
                        videosource=source_html
                        , name=name
                        , download=download
                        , url=url
                        , ask_which_file_hoster=not(testmode)
                        )

            #what if we fail to get a url??
            if not video_url:
                if testmode:
                    raise Exception(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, self.ROOT_URL))
                else:
                    utils.Notify(C.STANDARD_MESSAGE_NO_VIDEO_FILE.format(name, url))
##                    Log(repr(sys.argv),C.LOGNONE)
                    if C.addon_handle > 0:
##                        Log('here3',C.LOGNONE)
                        listitem = xbmcgui.ListItem(
                            label = name
                            , path=sys.argv[0]+sys.argv[2]
                            )
                        listitem.setProperty('IsPlayable', 'true')
                        xbmcplugin.setResolvedUrl(C.addon_handle, True, listitem)
                return False

            #sometimes the page has a list of actors
            if self.REGEX_tags_region is not None:
                description = u''
                desc_separator_char = u', '
                region_html = re.compile(self.REGEX_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
##                LogR(region_html)
                if region_html:
                    source_tags = re.compile(self.REGEX_tags, re.DOTALL | re.IGNORECASE).findall(region_html[0])
                    for tag in source_tags:
                        tag = utils.cleantext(tag)
                        if tag.lower() not in description.lower():
                            description = u"{}{}{}".format(description,tag,desc_separator_char)
                description = description.strip(desc_separator_char)
                if description and download:
                    description = description[0:150] #size limit when we are downloading
                    name = u"{} - {}".format(description, name)
                if description == '':  description = name + '\n' + self.ROOT_URL
                else:           description = description + '\n' + self.ROOT_URL
            Log(u"description={}".format(description))
            if self._SHOW_PLAY_URL:
                description = description + u'[CR]' #2024-04 test to use [CR]
                Log(repr((video_url, type(video_url))))
                if '|' in video_url:
                    description = description + video_url.split('|')[0]
                else:
                    description = description + video_url
            Log(u"description={}".format(description))
##            raise Exception()

            #always set referrer so that 'kodi' does not appear to the target server
            headers = None
            if '|' not in video_url:
                headers = C.DEFAULT_HEADERS.copy()
                headers['Referer'] = url
            if headers:
                video_url = video_url + utils.Header2pipestring(headers)
            if self._PLAY_HEADERS:
                #url will already have | symbol; we should append to existing
                video_url = video_url + '&' +utils.Header2pipestring(self._PLAY_HEADERS)[1:]


            #during testmode, only ensure that a url can be generated
            Log("video_url='{}'".format(video_url))
            if testmode:
                Log("video_url not played due to test mode")
                return   


            utils.playvid(
                video_url
                , name=name
                , download=download
                , description=description
                , playmode_string=playmode_string
                , play_profile=play_profile
                , download_filespec=download_filespec
                , mode = self.PLAY_MODE
                , url_factory = url
                , icon_URI = icon_URI            
                )

            Log(u"The time spent to play {} is {}".format(name, time.time() - t_start)
                , C.LOGNONE
                )

        except:
            traceback.print_exc()
        finally:
            if progress_dialog:
                progress_dialog.close()
            progress_dialog = None
##        finally:
####            utils.Sleep(2000)
##            xbmc.executebuiltin('Dialog.Close(busydialog)')
##            pass

        return False

    #__________________________________________________________________________
    #

