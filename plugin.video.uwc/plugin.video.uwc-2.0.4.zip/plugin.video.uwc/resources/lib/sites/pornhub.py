'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json, re
import utils

import constants as C
from base_website import Base_Website
from utils import Log,LogR,Sleep

class Specific_Website(Base_Website):

    _FRIENDLY_NAME = '[COLOR {}]pornhub[/COLOR]'.format(C.search_text_color)
    _LIST_AREA = C.LIST_AREA_TUBES
    _FRONT_PAGE_CANDIDATE = False
    _ROOT_URL        = "https://www.pornhub.com"

    _URL_RECENT      = _ROOT_URL + '/video?o=cm&page={}'
    _SEARCH_URL      = _ROOT_URL + '/video/search?search={}&page={}' #generic search
    _SEARCH_URL      = _ROOT_URL + '/pornstar/{}?page={}' #specific pornstar search
    _SEARCH_URL      = _ROOT_URL + '/pornstar/{}/videos?page={}' #specific pornstar search
    
    _MAIN_MODE = C.MAIN_MODE_pornhub
    _FIRST_PAGE = 1
    _Right_Click_Option = None #C.DEFAULT_PLAYMODE # Which right click properties to add to icon [e.g. present HLS or MP4 play options].  None allows all possiblities
    _SAVE_COOKIES = True       #if we need to save html cookies
    _ITEMS_NOT_FOUND_INDICATORS = [
        "This video was deleted."
        ] #which to strings may indicate that there is nothing to be found

    _URL_CATEGORIES  = 'https://www.pornhub.com/categories' # insert &o=mr  for mos recent vids
##    #override category from a basic url to custom function
##    def _URL_CATEGORIES(self):
##        cat_url = self._ROOT_URL + '/categories?o=al' # insert &o=mr  for most recent vids
##        addDir(
##            name = C.STANDARD_MESSAGE_CATEGORIES
##            ,url = self.URL_CATEGORIES
##            ,mode = self.CATEGORIES_MODE
##            ,page = self._FIRST_PAGE
##            ,iconimage=C.category_icon)
##        pass
####    def Categories(self, url, end_directory=True):
####        return True
        
    #__________________________________________________________________________
    #videos on this page
    _REGEX_video_region = (
        '(?:id="profileContent"|class="profileVids"|class="mainSection"|filters)'
        '(.+?)'
        '(?:id="moreMostRecentVids"|class="pagination|class="footerContentWrapper")'
        )
    _REGEX_list_items = (
#'videoblock.+?href="(/view_video\.php\?viewkey=[^"]+).+?title="([^"]+)".+?data-thumb_url = "([^"]+)".+?"duration">([^<]+)</.+?((?:<span class="hd-thumbnail">HD</span>|</div>))'
        #videoblock.+?
        'videoblock.+?href="(?P<videourl>/view_video\.php\?viewkey=[^"]+)'
        '.+?title="(?P<label>[^"]+)"'
        '.+?img\s+?src="(?P<thumb>[^"]+)"'
        '.+?duration">(?P<duration>[^<]+)</'
        '(?P<hd>)'
        #'.+?(?P<hd>(?:<span class="hd-thumbnail">HD</span>|</div>))'
        '(?P<desc>)'
        )
    _IGNORE_404 = True
    #__________________________________________________________________________
    # hack url to remove page=1 - site behaves weird during search
    def List_URL_Normalize(self, url, page=None):
##        if int(page) == 1:
##            if url.endswith('&page=1'):
##                url = url[:-len('&page=1')]
        Sleep(1000) # seems to prevent duplicates/ maybe a slightly smaller number would be better
        return url
    
##    _LIST_METHOD = "POST"
##    _LIST_HEADERS = {
##        "User-Agent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0'
##        , "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
##        , "Referer": _ROOT_URL
##        , "Accept-Encoding": "gzip, deflate"
##        , "Accept-Language": "en-US,en;q=0.9"
##    }
##    def LIST_DATA(self, **kargs):
##        page = kargs["page"]
##        keyword = kargs["keyword"]
##        return "action=action_ajax_filter&query_vars=null&paged={}&order=latest&search={}".format(page,keyword)
    #__________________________________________________________________________
    #where we can find info on whether there is a next page
    #_REGEX_next_page_region = 'id="w_pagination"(.+?)class="footer"'
    _REGEX_next_page_regex = (
##        '(?:(id="moreMostRecentVids")|<li class="page_next">'
##        '.+<a href="(.+?)" class="orangeButton">)' #as long as result is not empty
    '<li class="page_next">.+<a href="(.+?)" class="orangeButton">' #as long as result is not empty
    )
##    #__________________________________________________________________________
##    _REGEX_categories_region = 
##        (
##        'class="main_category_header"(.+)'
##        )
    _REGEX_categories = (
        '<div class="category-wrapper'
        '.+?<a href="(?P<videourl>[^"]+)"'
        '.+?<img.+?src="(?P<thumb>[^"]+)"'
        '.+?alt="(?P<label>[^"]+) Porn Category"'        
        )
    def Category_URL_Normalize(self, url): # Change url found in via regex with structure neeeded by website
        if '?' in url:
            url = self._ROOT_URL + url + "&o=cm&page={}"
        else:
            url = self._ROOT_URL + url + "?o=cm&page={}"
        return url

    #__________________________________________________________________________
    # Change keyword to replace spaces with a char that website wants  
    def Search_Keyword_Normalize(self, keyword):
        keyword = keyword.replace(' ','+').replace('+','-')
        return keyword
    #__________________________________________________________________________
    # Change SEARCH_URL to replace spaces with a char that website wants
    def Search_URL_Normalize(self, search_url, keyword):
        return search_url.format(keyword.lower(),'{}')

##    #__________________________________________________________________________
##    #where playable urls live

    _REGEX_play_region = None
##    (
##        'var qualityItems_\d+ = (\[.+?\]);'
##        )
    _REGEX_playsearch_JSON_urlstring = 'url'
    _REGEX_playsearch_JSON_qualitystring = 'text'
    _REGEX_playsearch_01 = None #(
##        #None #not for this site
##        '(?P<json>.+)'
####        ',?"?mediaDefinitions?"?:(?P<json>.+?\]),'  #sample video data as json
####        'data-hls-src(?P<res>\d+)'                #sample video data as res+url
####        '="(?P<url>[^"]+)"'
##        )
    #description for the playable url
    #_REGEX_tags = 'data-mxptype="Pornstar".+?data-mxptext="(?P<model>[^"]+)"' #'<div class ="pornstar-name.+?href.+?>(?P<model>[^<]+)<'
    _REGEX_tags_region = 'class="pornstarsWrapper(.+?)class="responseContainer"'
    
    _REGEX_tags = 'alt="avatar">(?P<model>[^<]+)<'


    #__________________________________________________________________________
    # add an alternative way to resolve a playable video url
    # returned items must be a list of (res, url) items
    def _ALTERNATE_playsearch_01(self, *args, **kargs):
        Log("_ALTERNATE_playsearch_01(args='{}',kargs='{}'".format(repr(args)[0:250], repr(kargs)[0:250]))

        alt_results = list()
        full_html = kargs["full_html"]
        url = kargs["referer"]

####        Log(repr(full_html))  #site does not like fiddler
##
##        ra_vars = re.compile(self._REGEX_tags_region, re.DOTALL | re.IGNORECASE).findall(full_html)
##        Log(repr(ra_vars))
##        ra_vars = re.compile(self._REGEX_tags, re.DOTALL | re.IGNORECASE).findall(ra_vars[0])
##        Log(repr(ra_vars))
##        return

        headers = {"Accept-Language": "en-US,en;q=0.9"
                ,"Accept-Encoding":"gzip, deflate"
                ,"Accept": "*/*"
                ,"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15"
                ,"Referer": url
                }

        regex='var (ra\w+)="(.+?)";'
##        regex='id="main-container"(.+?)";'
        
        ra_vars = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
        variables = {}
##        Log(repr(ra_vars))
        for var_name, var_value in ra_vars:
            variables[var_name]=var_value.replace('" + "','')

        regex='var media_(\d)=(.+?);'
        regex='var flashvars_(\d+?) =(.+?"autoFullscreen":true});'
        regex='var flashvars_(\d+?) =.+?"mediaDefinitions":(\[{".+?}\])'
        encoded_vids = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(full_html)
##        Log(repr(encoded_vids))
        #first capture is a number we may need to mung later

##        regex='"mediaDefinitions":(\[\{"\}\])'
##        Log(repr(regex))
##        media = re.compile(regex, re.DOTALL | re.IGNORECASE).findall(encoded_vids[0][1])
##        Log(repr(media))


        for match_number, encoded_url in encoded_vids:
            match_number = int(match_number)
##            Log("match_number='{}'".format(match_number))

            if "/*" in encoded_url:
                encoded_url = re.sub(r"/\*[^/]+/", "", encoded_url).replace("+","")
                linkparts = re.compile(r"(\w+)", re.DOTALL | re.IGNORECASE).findall(encoded_url)
                for part in linkparts:
                    encoded_url = encoded_url.replace(part, variables[part])
            decoded_url = encoded_url.replace(" ","")
            Log("decoded_url='{}'".format(decoded_url))

            if not '.m3u8' in decoded_url:
                continue
       
            #2021-10-15 needs bs=12342341234 cookie to get data
            mobile_json =''
            try:
                if decoded_url.startswith("http"):
                    mobile_json = utils.getHtml(decoded_url, headers=headers)
                    Log(repr(mobile_json))
                    if mobile_json:
                        json_sources = json.loads(mobile_json)
                        for json_src in json_sources:
                            if json_src['videoUrl'] != '':
                                if type(json_src['quality']) != list:
                                    alt_results.append( (json_src['quality'], json_src['videoUrl']) )
            except:
                Log('not json assuming a m38u file')
                res = None
                res = mobile_json.split('RESOLUTION=')
                if res: res = res[1]
                if res: res = res.split('x')[1]
                if res: res = res.split(',')[0]
                if not res: res = '1'
                alt_results.append( (res, decoded_url) )

            if not mobile_json:
##                Log(repr(encoded_url))
                json_sources = json.loads(encoded_url)
##                Log(repr(json_sources))
                #for json_src in json_sources["mediaDefinitions"]:
                for json_src in json_sources:
                        if json_src['videoUrl'] != '':
                            if type(json_src['quality']) != list:
                                alt_results.append( (json_src['quality'], json_src['videoUrl']) )


##        Log(repr(alt_results))
##        raise Exception()
##        return None
        return alt_results
            
##        links_regex = 'var stream_data = (.+?\]})'
##        links_json_html = re.compile(links_regex, re.DOTALL | re.IGNORECASE).findall(full_html)
##        if links_json_html: links_json_html=links_json_html[0]
##        else: links_json_html='{}'
##    ##    Log("links_json_html={}".format(links_json_html))
##        links_json_html = links_json_html.replace('\'','"')
##        json_urls = json.loads(str(links_json_html))
##        Log("json_urls={}".format(repr(json_urls)))
##
##        list_key_value = {} 
##        for json_url in json_urls:
##            q = json_url
##            v = json_urls[json_url]
##            if (q.endswith('0p') and not q.startswith('m3u8')) or q == '4k':
##                if len(v) > 0:
##                    v = v[0]
##                    list_key_value[q] = v
##                
##                    alt_results.append( (q, v) )
##
##                
##        return alt_results
    #__________________________________________________________________________
    #


    #__________________________________________________________________________
    #
    _REGEX_icon_search = (
        '<meta property="og:image" content="([^"]+)"'
        )
    def Icon_Search(self, url, pattern=_REGEX_icon_search, referer=_ROOT_URL):
        Log(repr((__name__, locals()))
##            , C.LOGNONE
            )
        page_content = utils.getHtml(url, referer)
        thumb = re.compile(pattern, re.DOTALL | re.IGNORECASE).findall(page_content)
        thumb = thumb[0]
        Log(repr(thumb,)
##            , C.LOGNONE
            )
        return thumb
    
#__________________________________________________________________________
#__________________________________________________________________________
#__________________________________________________________________________
#
website = Specific_Website()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.MAIN_MODE)    
def Main():
    #these exist so that we can use the url_dispatcher.register feature;
    #  but we could also override code here instead of in the 'website' class
    website.Main()
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.LIST_MODE, ['url'], ['page_start', 'page_end', 'end_directory', 'keyword', 'testmode', 'bulk_operation'])
def List(url, page_start=None, page_end=None, end_directory=True, keyword='', testmode=False, bulk_operation=False):
    website.List(url, page_start=page_start, page_end=page_end, end_directory=end_directory, keyword=keyword, testmode=testmode, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(
    website.SEARCH_MODE
    , ['url']
    , ['keyword'
       , 'end_directory'
       , 'page_start'
       , 'page_end'
       , 'bulk_operation'
       ]
    )
def Search(
    searchUrl
    , keyword=None
    , end_directory=True
    , page_start=website._FIRST_PAGE
    , page_end=website._FIRST_PAGE
    , progress_dialog=None
    , bulk_operation=False
    ):
    website.Search(
        searchUrl
        , keyword=keyword
        , end_directory=end_directory
        , page_start=page_start
        , page_end=page_end
        , progress_dialog=progress_dialog
        , bulk_operation=bulk_operation
        )
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.CATEGORIES_MODE, ['url'], ['end_directory'])
def Categories(url, end_directory=True):
    website.Categories(url, end_directory=True)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.TEST_MODE, [], ['progress_dialog', 'bulk_operation'])
def Test(end_directory=True,progress_dialog=None, bulk_operation=False):
    website.Test(end_directory=True, progress_dialog=progress_dialog, bulk_operation=bulk_operation)
#__________________________________________________________________________
#
@C.url_dispatcher.register(website.PLAY_MODE, ['url', 'name'], ['download', 'playmode_string', 'play_profile', 'icon_URI'])
def Playvid(url, name, download=None, playmode_string=None, play_profile=None, testmode=False, icon_URI=None):
    website.Playvid( url
                    , name
                    , download=download
                    , playmode_string=playmode_string
                    , play_profile=play_profile
                    , testmode=testmode
                    , icon_URI=icon_URI
                    )

#__________________________________________________________________________
#
