'''
    Ultimate Whitecream
    Copyright (C) 2015 Whitecream

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import sqlite3
import urllib
import urllib2
import gzip
import StringIO
import xbmc
import xbmcplugin
import xbmcgui
from resources.lib import utils
from resources.lib.utils import Log

SPACING_FOR_TOPMOST = utils.SPACING_FOR_TOPMOST
SPACING_FOR_NAMES =  utils.SPACING_FOR_NAMES
SPACING_FOR_NEXT = utils.SPACING_FOR_NEXT
MAX_SEARCH_DEPTH = utils.DEFAULT_RECURSE_DEPTH

ROOT_URL = "https://chaturbate.com"

SEARCH_URL = ROOT_URL + '/?s={}'

URL_RECENT = ROOT_URL + "/female-cams/?page={}"

URL_COUPLES = ROOT_URL + "/couple-cams/?page={}"


MAIN_MODE          = '220'
LIST_MODE          = '221'
PLAY_MODE          = '222'
REFRESH_MODE       = '224'
CLEANDATABASE_MODE = '223'


cbheaders = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
    'Accept': '*/*',
    'Referer': ROOT_URL,
    'Accept-Encoding': 'gzip'
     }
#__________________________________________________________________________
#

@utils.url_dispatcher.register(MAIN_MODE)
def Main():

    utils.addDir(
        name="{}[COLOR {}]Couples[/COLOR]".format(SPACING_FOR_TOPMOST,utils.search_text_color) 
        ,url=URL_COUPLES
        ,page='1'
        ,mode=LIST_MODE
        ,iconimage=utils.category_icon )
    
    List(URL_RECENT, page='1', end_directory=True, keyword='')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(LIST_MODE, ['url'], ['page', 'end_directory', 'keyword'])
def List(url, page=None, end_directory=True, keyword=''):

    Log("List(url={}, page={}, end_directory={}, keyword={}".format(url, page, end_directory, keyword))

    if int(page) % 2 == 1:
        if end_directory == True:    
            utils.addDir(name="{}[COLOR {}]Refresh[/COLOR]".format( 
                SPACING_FOR_TOPMOST, utils.refresh_text_color) 
                ,url='' 
                ,mode=REFRESH_MODE 
                ,iconimage=utils.refresh_icon)


    if '{}' in url and page: list_url = url.format(page)
    else: list_url = url
    listhtml = utils.getHtml(list_url, ROOT_URL)


    hq_bonus = int(utils.addon.getSetting("hq_bonus").lower())
    
    #
    # main list items
    #
    videos_regex = '<li class="room_list_room".*?<a href="([^"]+)">.*?img src="([^"]+)".*?<div[^>]+>([^<]+)<\/div>.*?href[^>]+> ([^<]+)<.*?age[^>]+>([^<]+).*?,\s(\d+)\sviewers'
    videos_regex = '<li class="room_list_room".+?<a href="([^"]+)".+?data-room="([^"]+)".+?' \
                +  'img src="([^"]+)".+?class="cams".+?(\d+)\sviewers'
##    <div[^>]+>([^<]+)<\/div>.*?href[^>]+> ([^<]+)<.*?age[^>]+>([^<]+).*?,\s(\d+)\sviewers'
    info = re.compile(videos_regex, re.DOTALL | re.IGNORECASE).findall(listhtml)
    #for videourl, thumb, stats, label, age, viewers in info:
    for videourl, label, thumb, viewers in info:
        hd = ''
        label = "{}{} {}".format(SPACING_FOR_NAMES, utils.cleantext(label), hd)
        if not videourl.startswith('http'): videourl = ROOT_URL + videourl
##        Log("label='{}'".format(label))
        utils.addDownLink( 
            name = label 
            , url = videourl 
            , mode = PLAY_MODE 
            , iconimage = thumb
            , duration=int(viewers)*hq_bonus
            , bitrate='fmproxy')
        

    if int(page) % 2 == 1:
        #Log("page mod {}".format(int(page) % 2), xbmc.LOGNONE)
        List(url, page=int(page)+1, end_directory=end_directory, keyword=keyword)
    else:
        #
        # next page items
        #
        if not listhtml == "": 
            next_page_html = listhtml.split('class="paging"')[1]
        else:
            next_page_html = ""
##        next_page_regex = 'href="([^"]+)" class="next endless_page_link">next</a>'
        next_page_regex = 'href="([^"]+)" class="next endless_page_link".+?>next</a>'
        np_info = re.compile(next_page_regex, re.DOTALL | re.IGNORECASE).findall(next_page_html)
        if not np_info:
            Log("np_info not found in url='{}'".format(list_url))
        else:
            for np_url in np_info:
                np_number = int(page) + 1
                np_url = url
                np_label = "{}[COLOR {}]Next Page ({})[/COLOR]".format(SPACING_FOR_NEXT, utils.search_text_color, np_number)
                if end_directory == True:
                    utils.addDir(
                        name= np_label
                        ,url=np_url 
                        ,mode=LIST_MODE 
                        ,iconimage=utils.next_icon 
                        ,page=np_number
                        ,keyword=keyword )
                else:
                    if int(np_number) <= MAX_SEARCH_DEPTH: #search some more, but not forever
                        utils.Notify(msg=np_url, duration=200)  #let user know something is happening
                        List(url=np_url, page=np_number, end_directory=end_directory, keyword=keyword)
                    else:
                        utils.add_sort_method()
                        utils.endOfDirectory()
                    
        if end_directory == True:
            utils.add_sort_method()
            utils.endOfDirectory()

#__________________________________________________________________________
#

@utils.url_dispatcher.register(REFRESH_MODE)
def refresh_page():
    clean_database(showdialog=False)
    xbmc.executebuiltin('Container.Refresh')

#__________________________________________________________________________
#

@utils.url_dispatcher.register(CLEANDATABASE_MODE)
def clean_database(showdialog=True):
    return #don't clean up image database until we figure out how to get images for off-line models
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".highwebmedia.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".highwebmedia.com")
            if showdialog:
                utils.notify('Finished','Chaturbate images cleared')
    except:
        pass

#__________________________________________________________________________
#
def Search(searchUrl, keyword=None, end_directory=True, page=0):
    return True

#__________________________________________________________________________
#

def Test(keyword):

    return True
    List(URL_RECENT, page='1', end_directory=False, keyword='')
    Search(searchUrl=SEARCH_URL, keyword=keyword, end_directory=False, page=0)
    Categories(URL_CATEGORIES, False)
    
#__________________________________________________________________________
#

@utils.url_dispatcher.register(PLAY_MODE, ['url', 'name'], ['playmode_string', 'download'])
def Playvid(url, name, playmode_string = '', download = False):

    Log ("Playvid url='{}', name='{}', playmode_string='{}', download='{}'".format(url, name, playmode_string, download), xbmc.LOGNONE  )

##    m3u8url = ( '{'
##                '"allow_group_shows": false, "needs_supporter_to_pm": true'
##                ', "ads_zone_ids": {"300x250,centre": "", "300x250,right": "", "300x250,left": "", "468x60": "", "160x600,top": "", "160x600,bottom": "", "160x600,middle": ""}'
####                ', "edge_auth":     "{\"username\":\"__anonymous__YVf1fv1\",\"org\":\"A\",\"expire\":1589498584,\"sig\":\"e975fe44c98e716a0dd11c51998d48dc0cbd69256620300162b5d08a729dcc53\",\"room\":\"cleopatra_sinns\"}"'
####                ', "chat_password": "{\"username\":\"__anonymous__YVf1fv1\",\"org\":\"A\",\"expire\":1589498584,\"sig\":\"e975fe44c98e716a0dd11c51998d48dc0cbd69256620300162b5d08a729dcc53\",\"room\":\"cleopatra_sinns\"}"'
##
##                ', "chat_settings": {"sort_users_key": "a", "silence_broadcasters": "false", "highest_token_color": "darkpurple", "emoticon_autocomplete_delay": "0", "ignored_users": "", "show_emoticons": true, "font_size": "9pt", "b_tip_vol": "10", "allowed_chat": "all", "room_leave_for": "org", "font_color": "#494949", "font_family": "default", "room_entry_for": "org", "v_tip_vol": "80"}'
##                ', "is_age_verified": true, "flash_host": "edge176.stream.highwebmedia.com"'
##                ', "tips_in_past_24_hours": 0, "dismissible_messages": []'
##                ', "show_mobile_site_banner_link": false, "last_vote_in_past_90_days_down": false, "server_name": "103"'
##                ', "num_users_required_for_group": 3, "group_show_price": 30, "is_mobile": false'
##                ', "chat_username": "__anonymous__YVf1fv1", "recommender_hmac": "fc2db481d53b62d9db2fca52aab8c44bc3794c7eb19c4c421b06a77fc43219ea"'
##                ', "broadcaster_gender": "female"'
##                ', "hls_source": "https://edge176.stream.highwebmedia.com/live-hls/amlst:cleopatra_sinns-sd-71197cb52138753daab4b3b9eba2b7800f4c1eb44a3956e9ea29c9162ef4ae2c_trns_h264/playlist.m3u8"'
##                ', "allow_show_recordings": true, "is_moderator": false, "room_status": "public"'
##
##                ', "is_supporter": false'
##
##                ', "room_pass": "d37490af7ac5cbfeefadc8eb91b8e3f04e73dedc8aa50b02a7292b0dc9343ef8", "low_satisfaction_score": false, "tfa_enabled": false'
##                ', "room_title": "#lovense #bigass #pussyplay  #tease #blowjob At Goal: tease me / play with my pussy / 100 boobs/ 155 ass doggy / 666 snap4life [every 100 tokens]."'
##                ', "satisfaction_score": {"down_votes": 1, "up_votes": 144, "percent": 100, "max": 30849773}'
##                ', "viewer_username": "AnonymousUser", "hidden_message": "", "following": false, "wschat_host": "https://chatws-52.stream.highwebmedia.com/ws", "has_studio": false'
##                ', "num_followed": 0, "spy_private_show_price": 30, "hide_satisfaction_score": false, "broadcaster_username": "cleopatra_sinns", "ignored_emoticons": []'
##
##                ', "token_balance": 0, "private_min_minutes": 0, "viewer_gender": "m"'
##                ', "allow_anonymous_tipping": false, "num_users_waiting_for_group": 0, "last_vote_in_past_24_hours": null, "is_widescreen": true, "num_viewers": 10487'
##                ', "broadcaster_on_new_chat": false, "private_show_price": 90, "num_followed_online": 0, "allow_private_shows": false'
##                '}')
##    
##    Log("m3u8url='{}'".format(m3u8url))
##    
##    import json
##    m = json.loads(m3u8url)
##    Log("m='{}'".format(m))  #.decode('unicode_escape')
##    Log("hls_source='{}'".format(m['hls_source']))
##    Log("room_status='{}'".format(m['room_status']))    
##
##    return


    listhtml = utils.getHtml(url, hdr=cbheaders)
    #Log("listhtml='{}'".format(listhtml), xbmc.LOGNONE)

    iconimage = xbmc.getInfoImage("ListItem.Thumb")

    #allow playmode to be forced by input command, or use default from addon settings
    if playmode_string == 'fmproxy':
        playmode = 1
        Log("using fmproxy")
    elif playmode_string == 'rtmp':
        playmode = 2
    elif playmode_string == 'inputstream':
        playmode = 3
        Log("using inputstream")
    else:
        playmode = int(utils.addon.getSetting('chatplay'))
    if download == True:
        playmode = 1 #force this mode to capture

    #m3u8url = re.compile(r"jsplayer, '([^']+)", re.DOTALL | re.IGNORECASE).findall(listhtml)  #pre 2019-11-09
#    


    #we skip a few regex sections because json can't parse them
    regex = 'window.initialRoomDossier = "({.+), \\\\u0022edge_auth\\\\u0022.+?\\\\u0022}\\\\u0022(.+), \\\\u0022chat_password\\\\u0022.+?\\\\u0022}\\\\u0022(.+), \\\\u0022apps_running\\\\u0022.+?\\\\u0022\]\\]\\\\u0022(.+})";'
    #Log("regex='{}'".format(regex))
    m3u8url = re.compile(regex, re.DOTALL).findall(listhtml)
    if m3u8url:
        m3u8url = m3u8url[0]

    if m3u8url:
        qq = ""
        for a in m3u8url:
            Log(a)
            qq += a.decode('unicode_escape')

        m3u8url = qq
        #Log("m3u8url='{}'".format(m3u8url)) #can't log this because my logger can't handle some of the escape sequences
        #Log("m3u8url='{}'".format(m3u8url))

        import json
        m = json.loads(m3u8url)
        Log("m='{}'".format(m))
        
        Log("hls_source='{}'".format(m['hls_source']))
        Log("room_status='{}'".format(m['room_status']))    

        if m['room_status'] == 'public':
            m3u8stream = m['hls_source']
        else:
            m3u8stream = None
    else:
        m3u8stream = None


####    m3u8url = json.loads('{' + unicode(m3u8url.decode('utf-8', 'ignore')) + '}' )["hls_source"]
##    Log("m3u8url='{}'".format(m3u8url))
####    return
##
###hls_source\u0022: \u0022https://edge172.stream.highwebmedia.com/live\u002Dhls/amlst:sweet_ary\u002Dsd\u002D31a2c07ce9404bbc1e26ce1c874083ac22e09d30d4609a8cd240d745b3886f5b_trns_h264/playlist.m3u8\u0022, \u0022
##    if m3u8url:
##        m3u8stream = m3u8url[0].decode('unicode_escape')
##        Log("m3u8stream='{}'".format(m3u8stream))        
##        m3u8stream = m3u8stream.replace('_fast','')
##    else:
##        m3u8stream = None

    listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
    
    if playmode == 0: # direct

        m3u8stream = "{}{}".format(m3u8stream, utils.Header2pipestring(cbheaders) )
        Log("direct m3u8stream='{}'".format(m3u8stream), xbmc.LOGNONE)

        if m3u8stream:
            videourl = m3u8stream
            listitem.setPath(videourl)
        else:
            utils.notify('Oh oh','Couldn\'t find a playable webcam link')
            return
        
    elif playmode == 1: # F4mProxy

        if m3u8stream:

            m3u8stream = "{}{}".format(m3u8stream, utils.Header2pipestring(cbheaders) )
            Log("fmproxy m3u8stream='{}'".format(m3u8stream), xbmc.LOGNONE)

            if download == True:
                import datetime
                name = name.strip()
                name_regex = "(?:\[color\s*\w*\]|)([A-Za-z0-9_\-\. ]+)(?:\[\/color\s*\]|)"
                name = re.compile(name_regex, re.DOTALL | re.IGNORECASE).findall(name)[0]
                name = name.strip()
                download_path = 'c:\\temp\\' + name + datetime.datetime.now().strftime(".%Y-%m-%d") + '.mp4'
                Log(download_path, xbmc.LOGNONE)
            else:
                download_path = None
                
            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            f4mp.playF4mLink(
                m3u8stream
                , name
                , proxy = None
                , use_proxy_for_chunks = False
                , maxbitrate = int(utils.addon.getSetting('max_bit_rate'))*1000*1000
                , simpleDownloader = False
                , auth = None
                , streamtype = 'HLSREDIR'
                , setResolved = False
                , swf = None
                , callbackpath = ""
                , callbackparam = ""
                , iconImage = iconimage
                , download_path = download_path
                )
            
            
            return
        
        else:
            utils.notify('Oh oh','Couldn\'t find a playable webcam link')
            return        
    
    elif playmode == 2:  # RTMP
        flv_info = []
        embed = re.compile(r"EmbedViewerSwf\(*(.+?)\);", re.DOTALL).findall(listhtml)[0]
        for line in embed.split("\n"):
            #data = re.search("""\s+["']([^"']+)["'],""", line)
            data = re.search('["\']([^"\']+)["\'],*', line)
            if data:
                flv_info.append(data.group(1))
        
        streamserver = "rtmp://%s/live-edge"%(flv_info[2])
        modelname = flv_info[1]
        username = flv_info[8]
        password = urllib.unquote(flv_info[12].replace('\u0022', '"'))
        unknown = flv_info[13]
        swfurl = ROOT_URL + '/static/flash/CBV_2p690.swf'
        swfurl = ROOT_URL + flv_info[0]

        
        videourl = "{} app=live-edge swfUrl={} tcUrl={}"\
                   .format( streamserver, swfurl, streamserver )
        videourl += " pageUrl=" + ROOT_URL + "/{}/ conn=S:AnonymousUser"\
                    .format(modelname)
        videourl += " conn=S:{} conn=S:2.690 conn=S:{}"\
                    .format(modelname ,username)
        videourl += " conn=S:{} playpath=mp4".format(password)

    elif playmode == 3: #inputstream

        m3u8stream = "{}{}".format(m3u8stream, utils.Header2pipestring(cbheaders) )
        videourl = m3u8stream
        listitem.setPath(videourl)
        if ".m3u8" in videourl:
            listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            #liz.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+__user_agent__)
            #listitem.setProperty('inputstream.adaptive.stream_headers', utils.Header2pipestring().replace("|", '') + "&Accept-Encoding=gzip, deflate, br"  )
            #listitem.setProperty('inputstream.adaptive.stream_headers', 'user-agent='+HTTP_HEADERS_IPAD  )
            listitem.setProperty('inputstream.adaptive.stream_headers'
                                , 'user-agent=' + 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/538.22 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36'
                                + "&Referer=".format(ROOT_URL)
                                )

##cbheaders = {
##    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
##    'Accept': '*/*',
##    'Referer': ROOT_URL,
##    'Accept-Encoding': 'gzip'
##     }

            
            Log("using inputstream for URL:{}".format(videourl)  )
        else:
            utils.notify('Oh oh','Couldn\'t find a playable webcam link')
            return


    Log("playing:{}".format(videourl)  )

    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()

##            myplaylist.clear()
##            myplaylist.add(listitem.getPath(), listitem)
##            mplayer.play(myplaylist)



    myPlayList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    myPlayList.add( listitem.getPath(), listitem)
    xbmc.Player().play(myPlayList)
    #xbmcplugin.setResolvedUrl(utils.addon_handle, True, listitem)
    #xbmc.Player().play(videourl, listitem)

#__________________________________________________________________________
#

def camgirl_page():

    Log("\n chaturbate camgirl_page {} \n".format(''))
    
    user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
    contents = ""

    FIRST_SEARCH_PAGE = 1
    LAST_SEARCH_PAGE = 4
    for i in range(FIRST_SEARCH_PAGE,LAST_SEARCH_PAGE):    
        url = URL_RECENT.format(i)
        myrequest= urllib2.Request(url)
        myrequest.add_header('User-Agent', user_agent)
        myrequest.add_header('Accept-Encoding', 'gzip')
        myrequest.add_header('Referer', ROOT_URL)
        myrequest.add_header('Accept-Language', 'en-US,en;q=0.9')
        myrequest.add_header('Connection', 'keep-alive')
        try:
            response = urllib2.urlopen(myrequest, timeout=15)
            data=''
            if response.info().get('Content-Encoding') == 'gzip':
                buf = StringIO.StringIO( response.read())
                f = gzip.GzipFile(fileobj=buf)
                data = f.read()
                f.close()
            else:
                data = response.read()
            contents=contents+data
        except Exception, e:
            Log("attempt connecting to err:'{}'".format(str(e)), xbmc.LOGERROR)

    return contents
